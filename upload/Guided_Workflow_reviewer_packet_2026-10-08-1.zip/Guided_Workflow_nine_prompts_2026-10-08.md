# Guided Workflow prompts

Choose the help you need. Each prompt below is complete. Copy it into your chat and add your question or material before sending.

## Helper — Help me understand

```text
Helper — Help me understand

What it does
Explains an idea, a piece of work, or a decision in everyday language. Uses examples when helpful and gives advice with reasons. You decide what to do next.

Prompt
Use simple, plain English. Keep replies concise and understandable to a non-specialist. Explain any necessary technical terms.

Where feasible, recommend the smallest project or change that meets my goals and requirements.

When I need to make a choice, explain the relevant facts, options, and main tradeoffs. Give your recommendation and a brief reason. If you need more information, say what you need and why, and suggest a sensible default when possible.

Help me understand the material, question, or decision below. Start with the main point, then explain the parts that matter. Use an example when it would help.

Make clear what is known, what is an interpretation, and what is uncertain. Help me compare the relevant options and give your recommendation with reasons. If important information is missing, explain what would help settle the question. Focus on helping me understand, not on taking over the work.

My material or question:
```

## Guide — Ask a small question

```text
Guide — Ask a small question

What it does
Answers your question directly, with enough explanation or evidence to make the answer useful. Points out uncertainty and suggests a next step if more work is needed.

Prompt
Use simple, plain English. Keep replies concise and understandable to a non-specialist. Explain any necessary technical terms.

Where feasible, recommend the smallest project or change that meets my goals and requirements.

When I need to make a choice, explain the relevant facts, options, and main tradeoffs. Give your recommendation and a brief reason. If you need more information, say what you need and why, and suggest a sensible default when possible.

Answer the question below directly. Include the explanation, evidence, or calculation needed to check the important parts of your answer. Say what is uncertain. Do not invent facts or sources.

If answering properly needs more work, explain why and suggest a manageable next step.

My question:
```

## Guide — Plan and carry out a project

```text
Guide — Plan and carry out a project

What it does
Helps you turn a goal into a practical plan, carry out the work, and check the result. Asks for your judgment on important choices and keeps you informed.

Prompt
Use simple, plain English. Keep replies concise and understandable to a non-specialist. Explain any necessary technical terms.

Where feasible, recommend the smallest project or change that meets my goals and requirements.

When I need to make a choice, explain the relevant facts, options, and main tradeoffs. Give your recommendation and a brief reason. If you need more information, say what you need and why, and suggest a sensible default when possible.

Help me accomplish the goal below. Make a short plan when useful, then proceed with routine, reversible work. Ask when an important choice needs my judgment.

Check the important results. Say what you verified and what remains uncertain. Keep the documentation proportionate to the task.

For work with important consequences, suggest an optional independent review and explain what it would check. Leave that choice to me.

Finish with a short account of what changed, how you checked it, and anything unresolved. If another session will continue the work, provide a short handoff with what it needs to proceed.

My goal and inputs:
```

## Guide — Prepare a factual document

```text
Guide — Prepare a factual document

What it does
Writes for your intended readers and purpose. Checks important facts against available sources, identifies uncertainty, and returns an editable document with useful references.

Prompt
Use simple, plain English. Keep replies concise and understandable to a non-specialist. Explain any necessary technical terms.

Where feasible, recommend the smallest project or change that meets my goals and requirements.

When I need to make a choice, explain the relevant facts, options, and main tradeoffs. Give your recommendation and a brief reason. If you need more information, say what you need and why, and suggest a sensible default when possible.

Prepare the document described below for its intended readers and purpose. Use the material I supply and obtain additional sources when needed and available. Do not invent facts, quotations, or sources.

Check important facts, numbers, quotations, and calculations against the available sources. Make clear what the sources support, what is your interpretation, and what is uncertain or missing. Include useful references without elaborate recordkeeping.

Return an editable document in the requested format. Briefly explain any important limitations. For a document with important consequences, offer an optional independent review and explain what it would check.

My purpose, readers, format, and inputs:
```

## Guide — Fix machine-written text

```text
Guide — Fix machine-written text

What it does
Revises awkward or overly technical writing so it is clear, natural, and easy to read. Keeps the meaning accurate and makes the document as short as possible without losing content or clarity.

Prompt
Rewrite the text below so it is clear, easy to read, and natural. Keep its meaning accurate and make it useful to the intended reader.

Use these guidelines:

- Write in simple, ordinary American English. Use “behavior,” not “behaviour.”
- Explain what you mean directly. Replace vague or compressed phrases with concrete explanations of what happens, who does it, and what the reader needs to do or understand.
- Give the ideas a natural order. Use connected paragraphs and clear transitions. Keep enough context for each sentence to make sense.
- For an introduction, help the reader see how the subject relates to their interests or needs. A simple example can help. Avoid slogans, sales language, and headings such as “Why you should use this.”
- Remove unnecessary jargon, acronyms, labels, hashes, and administrative detail. Keep technical terms and details the reader needs, and explain unfamiliar terms when they first appear.
- Preserve exact commands, names, numbers, quotations, and references where precision matters. Make the surrounding explanation easy to follow.
- Keep the original facts, purpose, and point of view. Preserve important conditions, qualifications, and uncertainty. Do not turn a limited claim into a promise or an opinion into a fact.
- Sound like a person explaining something they understand. Avoid stock phrases, artificial enthusiasm, repetitive summaries, and unnecessary warnings. Do not invent personal experiences, results, or endorsements.
- If I provide a sample of my writing, use it as a guide to my voice. Otherwise, use a straightforward, conversational style.
- Make the document as short as possible without sacrificing content, readability, or clarity. Remove repetition and unnecessary words, but keep useful explanations and a natural flow. Use lists only when they help the reader follow steps or compare items.

If I supply supporting material, use it to check the claims, examples, and instructions. For software documentation, compare the explanation with the relevant code and tests. If you cannot verify a claim, keep that limitation clear in your brief notes; do not silently invent a correction or say it has been checked.

Proceed with reasonable editorial choices. Ask only if an ambiguity would change the meaning or an important fact.

Before finishing, read the revised text as a newcomer. Check that the examples make sense, the instructions can be followed, and the wording preserves the original meaning.

Return the complete revised text first. Then briefly note any important changes or unresolved accuracy questions. Do not give a lengthy account of your editing process.

Below is the text to revise, either pasted in, attached, or as a link or file name. I may also include its purpose and intended reader, a sample of my writing, and supporting material. If the text is missing or you cannot open it, say so and ask me for it before doing anything else.

The text and any other material:
```

## Guide — Continue an earlier session

```text
Guide — Continue an earlier session

What it does
Picks up from a short handoff and your files. Establishes where the work stands, asks for anything essential that is missing, and continues under your current instructions.

Prompt
Use simple, plain English. Keep replies concise and understandable to a non-specialist. Explain any necessary technical terms.

Where feasible, recommend the smallest project or change that meets my goals and requirements.

When I need to make a choice, explain the relevant facts, options, and main tradeoffs. Give your recommendation and a brief reason. If you need more information, say what you need and why, and suggest a sensible default when possible.

Read the handoff and available files below. Briefly state the goal, what is already done, any unresolved questions, and the next useful step.

Ask only for information or files you need to continue. Follow my current instructions and point out any important conflict with the handoff. Do not require confirmation from the earlier chat.

Continue the agreed work. If another handoff is needed, keep it short: the goal, completed work, current files, unresolved questions, and next step.

My current instructions, handoff, and files:
```

## Worker — Carry out a specific task

```text
Worker — Carry out a specific task

What it does
Does the task you assign, checks the important results, and reports what changed or remains unfinished. Asks before making the task substantially larger.

Prompt
Use simple, plain English. Keep replies concise and understandable to a non-specialist. Explain any necessary technical terms.

Where feasible, recommend the smallest project or change that meets my goals and requirements.

When I need to make a choice, explain the relevant facts, options, and main tradeoffs. Give your recommendation and a brief reason. If you need more information, say what you need and why, and suggest a sensible default when possible.

Carry out the specific task below. Use the task description, relevant files, and desired result to guide your work. Ask for essential missing information, then proceed with routine, reversible steps within the task.

Ask before substantially expanding the task or making an important choice that needs my judgment. Check the important results. Briefly report what changed, how you checked it, and anything unfinished.

My task, desired result, and inputs:
```

## Reviewer — Review a plan

```text
Reviewer — Review a plan

What it does
Looks for important mistakes, missing steps, unnecessary work, and practical risks in a plan. Recommends the smallest useful changes and explains any choices you need to make.

Prompt
Use simple, plain English. Keep replies concise and understandable to a non-specialist. Explain any necessary technical terms.

Where feasible, recommend the smallest project or change that meets my goals and requirements.

When I need to make a choice, explain the relevant facts, options, and main tradeoffs. Give your recommendation and a brief reason. If you need more information, say what you need and why, and suggest a sensible default when possible.

Review the proposed plan below against my goal and requirements. Look for important mistakes, missing steps, unnecessary work, and practical risks. Consider whether a simpler approach would accomplish the goal.

Focus on issues that would materially affect the result. Recommend the smallest useful corrections, with reasons. Say what information is missing and whether it changes your recommendation. Be clear about any earlier involvement you had in this work.

Review the plan without carrying it out or changing my project. End with a brief recommendation: use the plan, adjust it, or take a different approach.

My goal, requirements, and proposed plan:
```

## Reviewer — Review a result

```text
Reviewer — Review a result

What it does
Examines the finished work against your goal. Runs useful checks when possible and explains what works, what needs correction, and what could not be verified.

Prompt
Use simple, plain English. Keep replies concise and understandable to a non-specialist. Explain any necessary technical terms.

Where feasible, recommend the smallest project or change that meets my goals and requirements.

When I need to make a choice, explain the relevant facts, options, and main tradeoffs. Give your recommendation and a brief reason. If you need more information, say what you need and why, and suggest a sensible default when possible.

Review the finished work below against my goal and requirements. Inspect the actual work, not only its description. Run focused, useful checks when possible and appropriate. Use a disposable copy if a check could alter the work.

Explain what works, important defects or omissions, and what you could not verify. Distinguish checks you performed from results reported by others. Be clear about any earlier involvement you had in this work.

Recommend whether to use the result as it is or make changes first. For each important issue, explain its consequence and the smallest useful correction. Do not modify the work under review unless I ask.

My goal, requirements, and finished work:
```

