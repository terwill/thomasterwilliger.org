const fs = require('fs');
const vm = require('vm');
const assert = require('assert');
const page = fs.readFileSync('site/guided_workflow/index.html', 'utf8');
const source = page.match(/<script>([\s\S]*?)<\/script>/)[1];
const keys = ['explain', 'small', 'work', 'doc', 'rewrite', 'continue', 'worker', 'before', 'after'];
function setup(mode) {
  const elements = {};
  const buttons = keys.map(key => ({dataset: {copy: key}, handlers: {}, addEventListener(n, f) {this.handlers[n] = f;}, focus() {}}));
  for (const key of keys) {
    elements['prompt-' + key] = {value: fs.readFileSync('site/guided_workflow/prompts/' + key + '-prompt.txt', 'utf8'), focus() {this.focused = true;}, select() {this.selected = true;}};
    elements['status-' + key] = {textContent: ''};
    elements['view-' + key] = {hidden: key === 'after'};
    elements['panel-' + key] = {open: false, matches(selector) {return selector === 'details.gw-prompt';}};
  }
  elements['review-mode'] = {value: 'before', handlers: {}, addEventListener(n, f) {this.handlers[n] = f;}};
  const writes = [];
  const window = {location: {hash: '#panel-rewrite'}, handlers: {}, addEventListener(n, f) {this.handlers[n] = f;}};
  const document = {getElementById(id) {return elements[id];}, querySelectorAll(selector) {assert.equal(selector, '[data-copy]');return buttons;}, execCommand(cmd) {assert.equal(cmd, 'copy'); return mode === 'fallback';}};
  const navigator = mode === 'modern' ? {clipboard: {async writeText(value) {writes.push(value);}}} : {};
  vm.runInNewContext(source, {window, document, navigator});
  return {elements, buttons, writes, window};
}
(async () => {
  const s = setup('modern');
  assert.equal(s.elements['panel-rewrite'].open, true);
  s.window.location.hash = '#panel-explain';s.window.handlers.hashchange();
  assert.equal(s.elements['panel-explain'].open, true);
  for (const b of s.buttons) {
    await b.handlers.click.call(b);
    const key = b.dataset.copy;
    assert.equal(s.writes.at(-1), s.elements['prompt-' + key].value);
    assert.equal(s.elements['status-' + key].textContent, 'Copied. Paste into your chat and add your inputs.');
  }
  const mode = s.elements['review-mode'];
  for (const id of ['after', 'before']) {
    mode.value = id;mode.handlers.change.call(mode);
    assert.equal(s.elements['view-' + id].hidden, false);
    assert.equal(s.elements['view-' + (id === 'after' ? 'before' : 'after')].hidden, true);
  }
  for (const fallback of ['fallback', 'manual']) {
    const s = setup(fallback);const b = s.buttons.find(b => b.dataset.copy === 'rewrite');
    await b.handlers.click.call(b);
    assert.equal(s.elements['prompt-rewrite'].selected, true);
    assert(s.elements['status-rewrite'].textContent.startsWith(fallback === 'fallback' ? 'Copied.' : 'The prompt is selected.'));
  }
  console.log('Controls pass in a simulated document: all nine copy handlers, both reviewer views, linked-panel opening, clipboard fallback, and manual-copy message. This is not a browser layout or native clipboard check.');
})().catch(e => {console.error(e);process.exit(1);});
