# Guided Coding: installation and first task

Start with `guided_coding/docs/GUIDED_CODING_USER_GUIDE.md` in this folder.
It is the same User Guide shown on the website. It tells you how to check
this download, make the /guided_coding command available (registration), set
up your project and try a task. The general setup card,
GENERAL_DEVELOPER_CARD.md, is optional. Keep project settings and task
records in your project. Do not put them in the guided_coding folder.

For the one-time registration, open Claude Code on your computer (without
/guided_coding) and send:

Please set up GuidedCoding from ~/Downloads/GuidedCoding/guided_coding for this Claude Code configuration. Read docs/GUIDED_CODING_COMMAND_REFERENCE.md there. Verify the source and release, check the Claude Code version for this session, and inspect the existing personal skill. If a working shared Guided Coding registration already exists, keep it and show its resolved source. Otherwise register the central link only if the destination is unoccupied. Show what changed. Do not connect to servers, change permission settings, or start a coding task.

If Claude Code is already helping you install Guided Coding, it can perform this registration in the same conversation. Open a new conversation only afterward, to use /guided_coding.

Supported systems: Guided Coding runs on macOS and Linux. On Linux its tests
run, but a real /guided_coding session there has not yet been observed. Auto
mode runs only on macOS. Windows is not supported.

To open a new conversation in your Git project with the Claude app on a Mac:

1. In the Claude app, open the Code tab and start a new session.
2. Under Environment, choose Local, then My computer.
3. At the bottom of the page, use the folder selector to choose your project
   folder. In the Mac folder window, press Cmd+Shift+G and paste the full path.
4. Type your message and send it.

In Terminal on macOS or Linux, change to the project folder and run claude.

Then, in that new conversation, enter /guided_coding help and follow the User
Guide. Start each task with one message that contains /guided_coding and
the task. For outside review, use a separate chat, preferably with a different
AI assistant. You decide whether to keep or publish each change.

Guided Coding needs Claude Code 2.1.281 or newer. In the Claude app, it
checks the app's built-in Claude Code; if it cannot read the version, it
reports NOT CHECKED. In Terminal, it checks the claude command you run.
This registration covers Claude Code on your computer only. A cloud session
needs its own copy of the kit.

For updates and removal, follow the User Guide. Before updating, finish any
active tasks. Unzip the update into a new folder, and keep the old folder
until you have checked that the new one works. Do not edit or add files
inside guided_coding/.

The kit commands resolve TMPDIR because macOS temporary paths can pass through symbolic links.
The exact source and adaptations are in PACKAGE_INFO.json.
General-edition source manifest SHA-256: 3c3fa2e5698474ed7acf90614087f896a1f126764be7ae71559064427138aec5
