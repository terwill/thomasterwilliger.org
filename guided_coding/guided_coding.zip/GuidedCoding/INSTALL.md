# Guided Coding: installation and first task

Start with `guided_coding/docs/GUIDED_CODING_USER_GUIDE.md` in this folder.
It is the same User Guide shown on the website. It tells you how to check
this download, make the command available, set up your project and try a task.
The general setup card is optional. Keep project settings and task records
in your project, outside the verified kit.

For the one-time setup, open ordinary Claude Code on your computer and send:

Please set up GuidedCoding from ~/Downloads/GuidedCoding/guided_coding for this Claude Code configuration. Read docs/GUIDED_CODING_COMMAND_REFERENCE.md there. Verify the source and release, check the Claude Code version for this session, and inspect the existing personal skill. If a working shared Guided Coding registration already exists, keep it and show its resolved source. Otherwise register the central link only if the destination is unoccupied. Show what changed. Do not connect to servers, change permission settings, or start a coding task.

Then open a fresh conversation in your Git project, enter /guided_coding help,
and follow the User Guide. Start each new task with /guided_coding and the
task together in one message. For outside review, use a separate chat,
preferably with a different AI assistant. You decide whether to keep or publish.

The client minimum is 2.1.281. The app checks its own engine and reports
NOT CHECKED when that version cannot be read; Terminal checks its PATH client.
A cloud session can obtain its own source copy; creating this local link does
not set up that session.

For updates and removal, follow the User Guide. Finish active tasks, extract
an update separately and keep the old folder until the new link is checked.
Do not edit or add files inside guided_coding/.

The kit commands resolve TMPDIR because macOS temporary paths can pass through symbolic links.
The exact source and adaptations are in PACKAGE_INFO.json.
General-edition source manifest SHA-256: 5b208c04e5986a3f87c68de151f70ca0e613190f9f42c4ab00e0de0411b1b665
