# Guided Coding for Claude Code

This is the complete general Guided Coding kit. Python 3.10+, Git, Bash and shasum are needed.
Documentation and installation examples are adapted automatically for this edition.
Its own source manifest covers the packaged files; PACKAGE_INFO.json records the changes.
Claude Code must be 2.1.281 or newer when its version can be checked.

1. Install/update Claude Code: use the Claude app's Local Code tab on a Mac, or the
   Terminal CLI on macOS/Linux. Sign in or supply your own API key for the Terminal route.
2. Download guided_coding.zip into ~/Downloads and verify the website's checksum.
   Unzip it there and keep ~/Downloads/GuidedCoding. The procedure directory is
   ~/Downloads/GuidedCoding/guided_coding. For another location, change the path below.
3. In an ordinary local Claude Code session, send this registration request:

Please set up GuidedCoding from ~/Downloads/GuidedCoding/guided_coding for this Claude Code configuration. Read docs/GUIDED_CODING_USER_GUIDE.md there. Verify the source and release, check the Claude Code version for this session, and inspect the existing personal skill. If a working shared Guided Coding registration already exists, keep it and show its resolved source. Otherwise register the central link only if the destination is unoccupied. Show what changed. Do not connect to servers, change permission settings, or start a coding task.

4. Open a fresh session in the Git repository you intend to change. Confirm with
   /guided_coding help. Supply GENERAL_DEVELOPER_CARD.md and enter /guided_coding setup.
   Review the proposed settings and let Claude finish saving and checking them.
5. In a new session in that repository, send /guided_coding followed by your task.
   Keep the task, requirements and any bug report in ONE message.
6. Review the plan, results and decisions. Pass the two reviewer files to a separate
   capable LLM when asked, preferably a different LLM, then paste its complete review back.

The personal skill link is normally ~/.claude/skills/guided_coding; one registration
covers projects in that configuration. Cloud sessions cannot use this local installation.
The app checks its own engine; if unreadable, NOT CHECKED is printed and it continues.
Terminal sessions still require the claude command on PATH. Review the work and the
project tests before accepting a result.

To update: finish active tasks, extract the next kit separately, and ask Claude to
verify that source and inspect the existing link before changing it. Keep the old
folder until the new registration is checked, then start a fresh session. Do not
edit the verified guided_coding subfolder or place extra files inside it.

User guide: ~/Downloads/GuidedCoding/guided_coding/docs/GUIDED_CODING_USER_GUIDE.md
General-edition source manifest SHA-256: acad8065b54fe6cc9081527a2bb67f5b07b9ddc1efc7211672fba42737dbbf35
Historical source revision: fc1682a9029dab083f20ded47724831812d406e1 (see PACKAGE_INFO.json and LICENSE.txt).
