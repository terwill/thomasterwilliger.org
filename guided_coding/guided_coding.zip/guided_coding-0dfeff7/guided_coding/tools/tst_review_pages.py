"""Tests of review_pages.py check (standard library only).

A small review folder that is complete must pass; each broken version must
be refused for its own reason. Run: python3 tst_review_pages.py
"""
import json, os, re, shutil, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import review_pages

DESCRIPTION = """# #1: The thing works

Repo: demo | Commit: abc1234 | Status: local

## In short
Problem: The thing failed on empty input.
Now: The thing returns an empty result for empty input.

## Problem
It failed.

## Fix: how it solves the problem
It checks for empty input first.

## Essential code
```diff
+  if not x: return []
```

## What the tests show
- **Test:** empty input.
- **Old code:** failed.
- **New code:** passed.
"""

PAGE = """<nav class="bar"></nav><main><h1 id="top">Demo</h1>
<a href="#change-1">1. The thing</a>
<section class="change" id="change-1"><h2>1. The thing</h2>
<details class="evidence" id="change-1-evidence"><summary>Show</summary></details>
</section>
<h2 id="review">The outside review</h2>
<h2 id="commits-to-push">Commits to push</h2></main><script></script>"""

# The end of a Python traceback, as a failing test prints it
TRACEBACK = ('Traceback (most recent call last):\n  File "tst_thing.py", line 3,'
  ' in <module>\n    assert thing([]) == [], "7/3"\n')

def run_text(code, body, module_file):
  return "$ run\nexit code: %d\n\n%s\nLOADED: demo.thing from %s\n" %(code,
    body, module_file)

def make_folder(description = DESCRIPTION, page = PAGE, scope_ok = True,
    task = "Make the thing work on empty input.",
    old_exit = 1, old_body = None, new_exit = 0, new_loaded = None,
    old_loaded = None, warning = False, expected = "AssertionError: 7/3",
    new_run = True, coverage = (), edit_after = False, request = "",
    saved = None, change_task = None):
  folder = tempfile.mkdtemp()
  modules = os.path.join(folder, "modules")
  real = os.path.join(modules, "demo", "demo", "thing.py")
  os.makedirs(os.path.dirname(real))
  open(real, "w").write("def thing(x):\n  return x\n")
  packet = os.path.join(folder, "evidence", "01_thing", "packet")
  old = os.path.join(packet, "old", "demo", "demo", "thing.py")
  os.makedirs(os.path.dirname(old))
  open(old, "w").write("def thing(x):\n  return x[0]\n")
  spec = {"settings": {"modules": modules, "python": "python3",
      "repositories": ["demo"], "author": "me"},
    "title": "One change reviewed", "page_title": "One Change Reviewed",
    "result": "Accepted.", "review_summary": "Reviewed.",
    "old_code_note": "Old and new.", "baselines": {"demo": "x^"},
    "not_secret": ["dummydummy1234"],
    "changes": [{"id": "01_thing", "ref": "#1", "name": "The thing",
      "short": "Thing", "description": "CARD_01.md", "parts": [],
      "runs": []}]}
  if task:
    spec["task"] = task
  if change_task:
    spec["changes"][0]["task"] = change_task
  if saved is not None:
    # A batch candidate set aside: its after/ copy is the tested file
    #  ("same") or another version ("different")
    job = os.path.join(folder, "job")
    os.makedirs(os.path.join(job, "before", "repo-1", "demo"))
    os.makedirs(os.path.join(job, "after", "repo-1", "demo"))
    open(os.path.join(job, "JOB.txt"), "w").write("repo-1: %s @ abc\n"
      "changed repo-1/demo/thing.py\nafter: complete\n" %modules)
    open(os.path.join(job, "after", "repo-1", "demo", "thing.py"), "w"
      ).write(open(real).read() + ("" if saved == "same" else "# other\n"))
    spec["changes"][0]["state"] = "saved"
    spec["changes"][0]["parts"] = [{"repo": "demo", "uncommitted": True,
      "before": os.path.join(job, "before", "repo-1"),
      "library_files": ["demo/thing.py"]}]
  json.dump(spec, open(os.path.join(folder, "review.json"), "w"))
  open(os.path.join(folder, "CARD_01.md"), "w").write(description)
  os.makedirs(os.path.join(packet, "runs"))
  for name in ("base_head.txt", "changed_files.txt", "net.diff"):
    open(os.path.join(packet, name), "w").write("")
  json.dump({"files": {"demo/demo/thing.py": review_pages.sha256(real)},
    "coverage_problems": list(coverage),
    "modules": [["demo.thing", old, real]],
    "runs": {"tst_thing_old": expected}},
    open(os.path.join(packet, "candidate.json"), "w"))
  if edit_after:
    open(real, "a").write("# edited after the packet\n")
  summary = "old  exit %d  tst_thing_old  last line: x\n" %old_exit
  if old_body is None:
    old_body = "%s\n%sAssertionError: 7/3" %(review_pages.TEST_STARTED,
      TRACEBACK)
  if warning:
    old_body += "\nWARNING: demo.thing loaded from the current file " + real
  open(os.path.join(packet, "runs", "tst_thing_old.txt"), "w").write(
    run_text(old_exit, old_body, old_loaded or old))
  if new_run:
    summary += "new  exit %d  tst_thing_new  last line: OK\n" %new_exit
    open(os.path.join(packet, "runs", "tst_thing_new.txt"), "w").write(
      run_text(new_exit, "%s\nOK" %review_pages.TEST_STARTED,
      new_loaded or real))
  open(os.path.join(packet, "summary.txt"), "w").write(summary)
  os.makedirs(os.path.join(folder, "evidence", "scope"))
  open(os.path.join(folder, "evidence", "scope", "scope.txt"), "w").write(
    "Problems: none\n" if scope_ok else "Problems: \n  demo abc NOT\n")
  os.makedirs(os.path.join(folder, "out"))
  open(os.path.join(folder, "out", "page.html"), "w").write(page)
  open(os.path.join(folder, "out", "request.md"), "w").write(request)
  return folder

def problems_of(**kw):
  folder = make_folder(**kw)
  try:
    return review_pages.check(review_pages.load(folder))
  finally:
    shutil.rmtree(folder)

def request_of(**kw):
  folder = make_folder(**kw)
  try:
    return open(review_pages.request(review_pages.load(folder))).read()
  finally:
    shutil.rmtree(folder)

def saved_copy_cases():
  """An uncommitted change is the job's own change: the developer's earlier
     edit in the same file stays in the old code"""
  failures = []
  folder = tempfile.mkdtemp()
  try:
    modules = os.path.join(folder, "modules")
    before = os.path.join(folder, "job", "before", "repo-1")
    for d in (os.path.join(modules, "demo", "demo"),
        os.path.join(before, "demo")):
      os.makedirs(d)
    # Before the job: HEAD's text plus the developer's own edit (line 2)
    open(os.path.join(before, "demo", "thing.py"), "w").write(
      "def thing(x):\n  y = 1  # the developer's edit\n  return x[0]\n")
    open(os.path.join(modules, "demo", "demo", "thing.py"), "w").write(
      "def thing(x):\n  y = 1  # the developer's edit\n  return x\n")
    spec = {"settings": {"modules": modules}}
    part = {"repo": "demo", "uncommitted": True, "before": before,
      "library_files": ["demo/thing.py"], "test_files": []}
    diff = review_pages.saved_diff(spec, part, ["demo/thing.py"])
    if "the developer's edit" in [x for x in diff.splitlines()
        if x.startswith(("+", "-")) and not x.startswith(("+++", "---"))]:
      failures.append("the developer's earlier edit is in the job's diff")
    if "-  return x[0]" not in diff or "+  return x" not in diff:
      failures.append("the job's change is not in its diff: %r" %diff)
    if review_pages.before_file(part, "demo/thing.py") is None:
      failures.append("the saved copy was not found")
    # Without the job's record, the files it created cannot be confirmed
    if not [x for x in review_pages.coverage_problems(part, [])
        if "no JOB.txt" in x]:
      failures.append("a missing JOB.txt was not reported")
    # A module the job created, named only in its record, is found
    open(os.path.join(folder, "job", "JOB.txt"), "w").write(
      "changed repo-1/demo/thing.py\ncreated repo-1/demo/new.py\n")
    open(os.path.join(modules, "demo", "demo", "new.py"), "w").write("x = 1\n")
    paths = review_pages.changed_paths(spec, part)
    found = review_pages.coverage_problems(part, paths)
    if "demo/new.py" not in paths or not [x for x in found
        if "demo/new.py" in x]:
      failures.append("an unlisted created module was not reported: %s %s"
        %(paths, found))
    # A binary file and a deleted file
    open(os.path.join(before, "demo", "data.bin"), "wb").write(b"\0\1")
    open(os.path.join(modules, "demo", "demo", "data.bin"), "wb").write(
      b"\0\2")
    open(os.path.join(before, "demo", "gone.py"), "w").write("y = 2\n")
    diff = review_pages.saved_diff(spec, part, ["demo/data.bin",
      "demo/gone.py"])
    if "Binary files differ" not in diff or "deleted file mode" not in diff \
        or "-y = 2" not in diff:
      failures.append("binary or deleted file not in the diff: %r" %diff)
    # A changed module or file that the old-code runs do not account for
    found = review_pages.coverage_problems(part, ["demo/thing.py",
      "demo/other.py", "demo/ext.cpp", "demo/regression/tst_x.py"])
    if len(found) != 2 or "other.py" not in found[0] or "ext.cpp" not in \
        found[1]:
      failures.append("unlisted changed files not reported: %s" %found)
  finally:
    shutil.rmtree(folder)
  return failures

def has_markdown():
  try:
    import markdown
    return True
  except ImportError:
    return False

def markdown_cases():
  """Untrusted text in the page: what it may and may not become"""
  if not has_markdown():
    print("Note: no markdown package here, so the page's Markdown is not "
      "tested; run this with a Python that has it (libtbx.python)")
    return []
  failures = []
  def expect(md, *wanted, **kw):
    h = review_pages.convert(md)
    for w in wanted:
      if w not in h:
        failures.append("Markdown: %r gave %r, without %r" %(md, h, w))
    for w in kw.get("absent", ()):
      if w in h:
        failures.append("Markdown: %r gave %r, with %r" %(md, h, w))
    if kw.get("no_attributes"):  # no tag carries any attribute
      for tag in re.findall(r"<[a-zA-Z][^>]*>", h):
        if re.search(r"\s\w", tag):
          failures.append("Markdown: %r gave %r, with an attribute" %(md, h))
  # Raw HTML is text
  expect("A <script>alert(1)</script> <b>x</b> <img src=x onerror=alert(1)>",
    "&lt;script&gt;", "&lt;img", absent = ["<script", "<b>", "<img"])
  # Links only to anchors on this page; any other keeps its text and
  #  formatting, and is not clickable
  for url in ("https://example.org/a", "http://example.org", "mailto:a@b.org",
      "javascript:alert(1)", "data:text/html,z", "//evil.example/c",
      "/etc/passwd", "../private/report.html", "file:///etc/passwd",
      "https:example.org", "\"javascript:alert(1)\""):
    expect("[**text**](%s)" %url, "<strong>text</strong>",
      absent = ["<a", "href"])
  expect("[ref text][r]\n\n[r]: https://example.org/x", "ref text",
    absent = ["<a", "href"])
  for md in ("<https://example.org>", "<mailto:a@b.org>", "<a@b.org>",
      "<javascript:alert(1)>"):
    expect(md, absent = ["<a", "href"])
  expect("[a](#change-2) [*b*](#change-1-after) [c][r]\n\n[r]: #review",
    '<a href="#change-2">a</a>', '<a href="#change-1-after"><em>b</em></a>',
    '<a href="#review">c</a>')
  for url in ("https://example.org", "#a b", "#x\n", '#a"b'):
    if review_pages.SAFE_LINK.fullmatch(url):
      failures.append("Markdown: the link %r was accepted" %url)
  # An image keeps only its text; no attribute list is read
  expect("![alt text](https://evil.example/x.png)", "alt text",
    absent = ["<img", "evil.example"])
  for md in ('## H {: onmouseover="x" #ok}', '## H {#bad" onclick="x}',
      'text {: onclick="x" }', "# Title {#top}"):
    expect(md, no_attributes = True)
  # Code blocks, which Python-Markdown builds apart from the rest: the
  #  cleaning of the finished HTML still removes what they add
  for md in ('```{.python onclick="alert(1)"}\nx\n```',
      '```{.python style="color:red" #i}\nx\n```', '```{: onclick="a"}\nx\n```'):
    expect(md, "<pre><code", absent = ["onclick", "style=", 'id="i"',
      "<pre id", "<pre class"])
  expect('```{#review .x .onclick}\nx\n```', '<pre><code class="language-x">',
    absent = ['id="review"', 'class="onclick"'])
  expect('``` {.a" onclick="x}\nx\n```', absent = ["onclick="])
  expect("```{#top .x}\r\nx\r\n```", '<pre><code class="language-x">',
    absent = ['id="top"'])
  # A code block shown inside a code block stays exactly as written
  expect('````text\n```{.python onclick="alert(1)"}\nexample\n```\n````',
    '```{.python onclick=&quot;alert(1)&quot;}', absent = ["<pre><code "
    'class="language-python"'])
  # A link disguised with character references is still refused
  expect("[x](javascript&#58;alert(1)) [y](java&#x73;cript:alert(1))",
    absent = ["<a", "href"])
  # The forms the descriptions and the page use
  expect("```diff\n+new\n-old\n```", '<pre><code class="language-diff">',
    '<span class="add">+new</span>', '<span class="del">-old</span>')
  expect("- **Test:** a\n  continued\n- two", "<strong>Test:</strong> a")
  expect("text\n\n| a | b |\n|---|---|\n| `x|y` | 2 |", "<th>a</th>",
    "<code>x|y</code>", "<td>2</td>")
  expect("| a | b |\n|---|---|\n| ``x|y`` | 2 |", "<code>x|y</code>",
    "<td>2</td>")
  expect("\\` literal `code`", "` literal <code>code</code>")
  # Found in the reviews: none of these crashes the page
  for md in (">" * 1200 + " deep", "\n".join("  " * k + "- x"
      for k in range(600)), "9" * 5000 + ". x"):
    try:
      review_pages.convert(md)
    except Exception as e:
      failures.append("Markdown: %r... raised %s" %(md[:20], e))
  return failures

def dependency_cases():
  """Without Python-Markdown, the page says what is needed"""
  saved = sys.modules.get("markdown")
  sys.modules["markdown"] = None  # importing it then fails
  try:
    review_pages.convert("x")
    return ["the page was made without Python-Markdown"]
  except ImportError as e:
    if "Python-Markdown" not in str(e) or "libtbx.python" not in str(e):
      return ["an unclear error without Python-Markdown: %s" %e]
    return []
  finally:
    if saved is None:
      del sys.modules["markdown"]
    else:
      sys.modules["markdown"] = saved

HOSTILE = ("<script>alert(1)</script> <img src=x onerror=alert(2)> "
  "<svg onload=alert(3)></svg> \" onmouseover=\"alert(4) "
  "[a](javascript:alert(5)) [b](//evil.example/c) [c](data:text/html,x) "
  "![i](https://evil.example/i.png) {: onclick=\"alert(6)\" }\n\n"
  "```{.python onclick=\"alert(7)\" style=\"x\"}\ncode\n```\n")

def hostile_page_cases():
  """A whole page with hostile text in every field that reaches it: no
     markup, script or unsafe link gets through"""
  if not has_markdown():
    return []
  failures = []
  description = DESCRIPTION.replace("It failed.", "It failed. " + HOSTILE
    ).replace("It checks for empty input first.", HOSTILE + "\n\n" +
    ">" * 500 + " deep") + "\n## Changes after the review\n- " + HOSTILE + "\n"
  folder = make_folder(description = description,
    old_body = "%s\n%s\n%sAssertionError: 7/3" %(review_pages.TEST_STARTED,
    HOSTILE, TRACEBACK))
  saved = review_pages.unpushed
  try:
    spec = review_pages.load(folder)
    spec["review_summary"] = "Reviewed. " + HOSTILE
    spec["result"] = "Accepted. " + HOSTILE
    spec["title"] = "Title " + HOSTILE
    spec["findings"] = [{"found": HOSTILE, "changes": [1], "done": HOSTILE}]
    review_pages.unpushed = lambda spec: ([], [])
    t = open(review_pages.page(spec)).read()
    main = t[t.index("<main"):t.index("</main>")]
    # Every tag in the body is one the page makes, with no event handler
    for tag in re.findall(r"<([a-zA-Z][^\s>/]*)([^>]*)>", main):
      if tag[0].lower() in ("script", "img", "svg", "iframe", "object"):
        failures.append("hostile page: a <%s> tag" %tag[0])
      if re.search(r"\son\w+\s*=", tag[1]):
        failures.append("hostile page: an event handler in <%s%s>" %tag)
    for h in re.findall(r'href="([^"]*)"', main):
      if not review_pages.SAFE_LINK.fullmatch(h):
        failures.append("hostile page: a link to %s" %h)
    found = [p for p in review_pages.check(spec) if p.startswith("page")]
    if found:
      failures.append("hostile page refused by check: %s" %found)
  finally:
    review_pages.unpushed = saved
    shutil.rmtree(folder)
  return failures

def page_link_cases():
  """In every field that reaches the page, an anchor on the page stays a
     link and any other destination becomes text"""
  if not has_markdown():
    return []
  failures = []
  def links(field):
    return ("[inside %s](#change-1) [outside %s](https://example.org/%s) "
      "<https://example.org/auto-%s>" %(field, field, field, field))
  description = DESCRIPTION.replace("It failed.", "It failed. " +
    links("description")) + "\n## Changes after the review\n- Done.\n"
  folder = make_folder(description = description)
  saved = review_pages.unpushed
  try:
    spec = review_pages.load(folder)
    spec["review_summary"] = "Reviewed. " + links("review")
    spec["result"] = "Accepted. " + links("result")
    spec["findings"] = [{"found": links("finding"), "changes": [1],
      "done": "done"}]
    review_pages.unpushed = lambda spec: ([], [])
    t = open(review_pages.page(spec)).read()
    main = t[t.index("<main"):t.index("</main>")]
    for field in ("description", "review", "result", "finding"):
      if '<a href="#change-1">inside %s</a>' %field not in main:
        failures.append("page links: the anchor in the %s is not a link" %field)
      if "outside %s" %field not in main:
        failures.append("page links: the text of the %s link is gone" %field)
    for h in re.findall(r'href="([^"]*)"', main):
      if not h.startswith("#"):
        failures.append("page links: a link to %s" %h)
    if "example.org" in "".join(re.findall(r'href="[^"]*"', main)):
      failures.append("page links: an outside address is clickable")
    # The page's own template loads nothing from outside (no fonts, styles
    #  or scripts from another server)
    template = t.replace(main, "")
    if re.search(r"https?:|//[\w.-]+\.\w", template):
      failures.append("page links: the template names an outside address")
    found = [p for p in review_pages.check(spec) if p.startswith("page")]
    if found:
      failures.append("page links: check refused the page: %s" %found)
  finally:
    review_pages.unpushed = saved
    shutil.rmtree(folder)
  return failures

def write_file(path, text):
  os.makedirs(os.path.dirname(path), exist_ok = True)
  open(path, "w").write(text)

def runner_output(folder, overlays, roots, test_text, before = None):
  """Write test_text as a test and an old-code runner for it in folder, and
     run it; before, if given, is code run first in the same process.
     Returns (exit code, output)"""
  import subprocess
  test = os.path.join(folder, "tst_runner.py")
  write_file(test, test_text)
  runner = os.path.join(folder, "runner.py")
  write_file(runner, review_pages.RUNNER %dict(overlays = overlays,
    test = test, args = [], roots = roots, started = review_pages.TEST_STARTED,
    mixed = review_pages.MIXED, real_files = [os.path.realpath(x[2])
    for x in overlays], module_names = [x[0] for x in overlays],
    is_old = True))
  command = [sys.executable, runner]
  if before:
    command = [sys.executable, "-c", "%s\nexec(compile(open(%r).read(), %r, "
      "'exec'))" %(before, runner, runner)]
  p = subprocess.run(command, cwd = folder, stdout = subprocess.PIPE,
    stderr = subprocess.STDOUT, universal_newlines = True)
  return p.returncode, p.stdout

def mixed_runner_cases():
  """The old-code runner, with two changed modules where the first imports a
     value from the second: the test must run on both old versions, never on
     a mixture of old and current code. A changed module imported before the
     runner starts must stop the run"""
  failures = []
  folder = tempfile.mkdtemp()
  try:
    current = os.path.join(folder, "current")
    old = os.path.join(folder, "old")
    for root, value in ((current, "CURRENT"), (old, "OLD")):
      write_file(os.path.join(root, "pkg", "__init__.py"), "")
      write_file(os.path.join(root, "pkg", "a.py"),
        "from pkg.b import value\ndef result():\n  return value\n")
      write_file(os.path.join(root, "pkg", "b.py"), "value = %r\n" %value)
    overlays = [(m, os.path.join(old, "pkg", f), os.path.join(current, "pkg",
      f)) for m, f in (("pkg.a", "a.py"), ("pkg.b", "b.py"))]
    test = ("import pkg.a, pkg.b\nprint('a gives', pkg.a.result(), "
      "'b gives', pkg.b.value)\n")
    code, output = runner_output(folder, overlays, [current], test)
    if code != 0 or "a gives OLD b gives OLD" not in output:
      failures.append("two changed modules, one importing the other, did not "
        "both run as their old versions (exit %d):\n%s" %(code, output))
    code, output = runner_output(folder, overlays, [current], test,
      before = "import sys\nsys.path.insert(0, %r)\nimport pkg.b" %current)
    if code == 0 or review_pages.MIXED not in output or \
        review_pages.TEST_STARTED in output or "a gives" in output:
      failures.append("a changed module imported before the runner started "
        "was not refused (exit %d):\n%s" %(code, output))
  finally:
    shutil.rmtree(folder)
  return failures

def package_cycle_cases():
  """The old-code runner, with a changed module that its own package's
     __init__.py imports from (as phenix.model_building imports morph_info):
     the old module must load after its package, as a normal import would"""
  failures = []
  folder = tempfile.mkdtemp()
  try:
    current = os.path.join(folder, "current")
    old = os.path.join(folder, "old")
    write_file(os.path.join(current, "pkg", "__init__.py"),
      "from pkg.child import value\n")
    write_file(os.path.join(current, "pkg", "sibling.py"), "x = 1\n")
    for root, value in ((current, "CURRENT"), (old, "OLD")):
      write_file(os.path.join(root, "pkg", "child.py"),
        "from pkg.sibling import x\nvalue = %r\n" %value)
    overlays = [("pkg.child", os.path.join(old, "pkg", "child.py"),
      os.path.join(current, "pkg", "child.py"))]
    code, output = runner_output(folder, overlays, [current],
      "import pkg, pkg.child\nprint('package gives', pkg.value, "
      "'child gives', pkg.child.value)\n")
    if code != 0 or "package gives OLD child gives OLD" not in output:
      failures.append("a changed module that its package's __init__.py "
        "imports was not loaded as its old version (exit %d):\n%s"
        %(code, output))
    # A package that loads its current child itself, bypassing the finder:
    #  the run must stop before the test, not report the old file
    write_file(os.path.join(current, "pkg", "__init__.py"),
      "import importlib.util, os, sys\n"
      "s = importlib.util.spec_from_file_location('pkg.child', "
      "os.path.join(os.path.dirname(__file__), 'child.py'))\n"
      "m = importlib.util.module_from_spec(s)\n"
      "sys.modules['pkg.child'] = m\ns.loader.exec_module(m)\n"
      "value = m.value\n")
    code, output = runner_output(folder, overlays, [current],
      "import pkg\nprint('package gives', pkg.value)\n")
    if code == 0 or review_pages.MIXED not in output or \
        review_pages.TEST_STARTED in output or "OLD CODE" in output:
      failures.append("a package that loaded its current child itself was "
        "not refused (exit %d):\n%s" %(code, output))
  finally:
    shutil.rmtree(folder)
  return failures

def run():
  failures = []
  # In CI the page tests must run, not be skipped
  if os.environ.get("GC_REQUIRE_MARKDOWN") and not has_markdown():
    failures.append("GC_REQUIRE_MARKDOWN is set, but this Python has no "
      "markdown package, so the page's safety tests would be skipped")
  ok = problems_of()
  if ok:
    failures.append("a complete review was refused: %s" %ok)
  cases = [
    ("a description without its Now: line",
     dict(description = DESCRIPTION.replace(
       "Now: The thing returns an empty result for empty input.\n", "")),
     "\"Now:\""),
    ("no developer's request", dict(task = None), "no developer's request"),
    ("a test that passed on the old code", dict(old_exit = 0),
     "passed on the old code"),
    ("an old-code run that failed on an import, not on the test",
     dict(old_body = review_pages.TEST_STARTED +
       "\nModuleNotFoundError: No module named 'demo'"),
     "failed on the old code for the wrong reason"),
    ("an old-code run that failed loading the old code (ValueError)",
     dict(old_body = "Traceback\nValueError: bad"),
     "failed before the test started"),
    ("an old-code run that failed on another assertion",
     dict(old_body = "%s\n%sAssertionError: 1/2" %(review_pages.TEST_STARTED,
       TRACEBACK)), "did not fail with the expected"),
    ("the expected text printed, then another failure ending the run",
     dict(old_body = "%s\nExpected diagnostic: AssertionError: 7/3\n"
       "%sRuntimeError: unrelated failure" %(review_pages.TEST_STARTED,
       TRACEBACK)), "did not fail with the expected"),
    ("the expected text in a source line of the traceback, and another "
     "exception ending the run",
     dict(old_body = '%s\nTraceback (most recent call last):\n  File '
       '"tst_thing.py", line 4, in <module>\n    check_result("AssertionError:'
       ' 7/3")\n  File "tst_thing.py", line 2, in check_result\n    raise '
       'RuntimeError("unrelated failure")\nRuntimeError: unrelated failure'
       %review_pages.TEST_STARTED), "did not fail with the expected"),
    ("a bare exception, with the expected text only in its source line",
     dict(old_body = '%s\nTraceback (most recent call last):\n  File '
       '"tst_thing.py", line 4, in <module>\n    assert thing([]) == [], '
       '"7/3"\nAssertionError' %review_pages.TEST_STARTED),
     "verify that by hand"),
    ("the expected text printed, and no traceback ending the run",
     dict(old_body = "%s\nAssertionError: 7/3\nFAILED" %
       review_pages.TEST_STARTED), "did not end with a one-line"),
    ("an old-code run stopped because old and current code would mix",
     dict(old_exit = 3, old_body = "%s demo.other was imported from "
       "/current/demo/other.py before its old version could be loaded; this "
       "run would mix old and current code" %review_pages.MIXED),
     "would mix old and current code"),
    ("no run with an expected old-code failure", dict(expected = None),
     "no proving run"),
    ("an old-code run without its run on the current code",
     dict(new_run = False), "has no run on the current code"),
    ("an old-code run that loaded a current file", dict(warning = True),
     "loaded a current file"),
    ("an old-code run that did not use the old module",
     dict(old_loaded = "/elsewhere/demo/thing.py"),
     "did not use the old version of demo.thing"),
    ("a current-code run that loaded another checkout",
     dict(new_loaded = "/other/install/demo/thing.py"),
     "not from the checkout"),
    ("no test imports the changed module", dict(new_loaded = "None"),
     "no test imports demo.thing"),
    ("a changed module not accounted for",
     dict(coverage = ["demo demo/other.py: a changed module not in "
       "library_files"]), "demo/other.py"),
    ("a file changed after the packet", dict(edit_after = True),
     "changed after the packet"),
    ("a key in the reviewer's packet",
     dict(request = 'api_key = "abcdefghijklmnop1234"\n'),
     "looks like a key or password"),
    ("a second script in the page",
     dict(page = PAGE + "<script>alert(1)</script>"), "2 scripts"),
    ("a link without a target",
     dict(page = PAGE.replace('href="#change-1"', 'href="#change-9"')),
     "#change-9 has no target"),
    ("the outside review inside a change",
     dict(page = PAGE.replace(
       '</details>\n</section>\n<h2 id="review">The outside review</h2>',
       '</details>\n<h2 id="review">The outside review</h2>\n</section>')),
     "#review part is inside change-1"),
    ("a scope check with problems", dict(scope_ok = False),
     "scope check found problems"),
    ("a saved candidate that differs from the one tested",
     dict(saved = "different"), "differs from the version tested"),
    ("an expected failure that is only an exception name",
     dict(expected = "AssertionError"), "too general"),
    ("a key on the same line as an allowed dummy value",
     dict(request = 'password = "dummydummy1234" api_key = '
       '"realrealreal5678"\n'), "looks like a key or password"),
  ]
  for what, kw, expected in cases:
    found = problems_of(**kw)
    if not [p for p in found if expected in p]:
      failures.append("not refused: %s (problems: %s)" %(what, found))
  found = problems_of(request = 'password = "dummydummy1234"\n')
  if found:
    failures.append("an allowed dummy value was refused: %s" %found)
  found = problems_of(saved = "same")
  if found:
    failures.append("a saved candidate that matches was refused: %s" %found)
  # The overall request and a change's own request both reach the reviewer
  text = request_of(change_task = "Also keep the old name working.")
  if "Make the thing work" not in text or "keep the old name" not in text:
    failures.append("a request is missing from the packet")
  # Two runs with the same name are refused before anything runs
  folder = make_folder()
  try:
    spec = review_pages.load(folder)
    spec["changes"][0]["runs"] = [{"repo": "a", "test": "x/tst_s.py"},
      {"repo": "b", "test": "y/tst_s.py"}]
    review_pages.packet(spec, spec["changes"][0])
    failures.append("two runs named tst_s were not refused")
  except ValueError as e:
    if "tst_s" not in str(e):
      failures.append("wrong refusal for two runs named alike: %s" %e)
  finally:
    shutil.rmtree(folder)
  # A job without an outside review still gets the review part, saying so
  folder = make_folder()
  try:
    spec = review_pages.load(folder)
    del spec["review_summary"]
    if has_markdown():
      md = review_pages.review_md(spec)
      if 'id="review"' not in md or "No outside review" not in md:
        failures.append("a page without an outside review: %s" %md)
    # Allowed only when the job named no triggers; refused for H, for no
    #  triggers given, and for an empty review_summary
    spec["triggers"] = []
    found = review_pages.check(spec)
    if found:
      failures.append("a job with no triggers and no review was refused: %s"
        %found)
    for triggers in (["H"], None):
      spec["triggers"] = triggers
      if triggers is None:
        del spec["triggers"]
      if not [p for p in review_pages.check(spec) if "triggers" in p]:
        failures.append("no outside review with triggers %s was not refused"
          %triggers)
      # Before the review, a job with a trigger has no review yet: allowed
      found = review_pages.check(spec, before_review = True)
      if found:
        failures.append("check --before-review refused a job with triggers "
          "%s that has no review yet: %s" %(triggers, found))
    for empty in (" ", None):
      spec["review_summary"] = empty
      if not [p for p in review_pages.check(spec)
          if "empty review_summary" in p]:
        failures.append("an empty review_summary (%r) was not refused" %empty)
  finally:
    shutil.rmtree(folder)
  failures.extend(saved_copy_cases())
  failures.extend(mixed_runner_cases())
  failures.extend(package_cycle_cases())
  failures.extend(markdown_cases())
  failures.extend(dependency_cases())
  failures.extend(hostile_page_cases())
  failures.extend(page_link_cases())
  return failures

if __name__ == "__main__":
  failures = run()
  for f in failures:
    print("FAIL: " + f)
  print("OK" if not failures else "%d failures" %len(failures))
  sys.exit(1 if failures else 0)
