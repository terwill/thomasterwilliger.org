# Screen 2 — de-telegraphed decision scenarios: responses for evaluation

The **Phenix Expert** (phenix.chat agent) was given each situation below as a text decision question, with no files and no tools (prose answer only). Unlike an earlier round, these situations give **raw observations, not the diagnosis** — the Expert must reach the interpretation itself. Six of them (D1–D6) are **distractors**: the exotic textbook answer is *wrong* and the correct call is mundane, so they test whether the Expert **over-calls**.

Each was asked: *state your leading hypotheses, the first discriminating check or action, what result would change your mind, and what you would not do.* Responses were scored by an LLM judge on four 0–2 dimensions (evidence interpretation / first discriminating action / calibration & branching / safe execution; max 8) plus a separate trap flag.

**We would like your independent evaluation.** For each response: (a) did the Expert reach a sound leading hypothesis and next step a strong crystallographer would endorse? (b) for distractors, did it correctly resist the exotic answer? (c) is our judge's score fair, too generous, or too harsh? Our judge scored 30/31 at a perfect 8/8 with zero traps — please push back where you disagree.

---

# De-telegraphed scenarios (S1–S25)

## S1 — building

**Situation given:** A 130-residue protein built at 2.3 A. AutoBuild placed 118 residues; R-work/R-free = 0.21/0.26. Residues 64-70 are absent between two modeled helices. At the contour used for the well-built core the map is not continuous across the gap, though a few short features appear when the contour is lowered. The residues flanking the gap have reasonable geometry. What do you do next?

**Trap (wrong conclusion watched for):** Declares the segment disordered without a serious fill attempt.

**Judge score:** 6/8  (evidence 2, action 1, calibration 2, execution 1) — trap_triggered: False

**Expert's response (verbatim):**

> This is a textbook disordered/weak-loop situation, and at 2.3 Å with an unconverged, still-incomplete model the map is not yet the final word — phases will sharpen as the model completes and refines. So I'd resist the urge to build immediately.
> 
> **Leading hypotheses (most to least likely)**
> 1. **Loop 64–70 is genuinely mobile/disordered** — a surface connector between two helices, high B / low occupancy, so no continuous density at working contour and only fragmentary features when you drop the contour into noise. Most common outcome.
> 2. **Density is present but under-represented** by model bias and incomplete phases; a bias-reduced map plus more refinement would reveal a buildable backbone.
> 3. **A register or conformational problem at the gap ends** — less likely, since the flanking residues have reasonable geometry, but worth excluding.
> 
> **First discriminating check (do this before building anything):** compute a bias-reduced map over the gap — a composite OMIT map (or a polder map with the loop region omitted) after one more round of refinement — and inspect it. In parallel, two cheap measurements: (a) the Cα–Cα through-space distance between residues 63 and 71, to confirm 7 residues can physically bridge it, and (b) the B-factors of the flanking residues — steeply rising B toward the gap argues for genuine disorder.
> 
> **What would change my mind / decide the action:**
> - If the OMIT/polder map shows *continuous backbone density* at a sensible contour → the loop is real and bias was hiding it. Build it (e.g., fit_loops), then re-refine and confirm the density and geometry hold.
> - If, after refinement + bias reduction, only disconnected specks appear at low contour → conclude the loop is disordered. Leave it unmodeled, and report it as disordered rather than forcing it. Revisit after later map improvements (TLS/ADP, density modification) — a feature invisible now can clarify later.
> 
> **What I would not do:** force the 7 residues into weak or absent density to "finish" the model or nudge R-free — that's building into data that don't support it, and a fabricated loop degrades geometry and misleads. I wouldn't treat the current lowered-contour specks as proof of a path, wouldn't regenerate or extend the R-free set, and wouldn't overwrite the input model — work on a copy. An unmodeled disordered loop is an honest, acceptable outcome; a phantom loop is not.

---

## S2 — refinement

**Situation given:** A 1.9 A model has changed very little over three refinement macrocycles. R-work/R-free = 0.24/0.29, clashscore 12, Ramachandran favored 94%, three rotamer outliers, data completeness 98%. The user asks for deposition-ready files. What do you do next, and what would make you consider the model ready?

**Trap (wrong conclusion watched for):** Calls it deposition-ready because refinement is numerically stable; or chases R-free by manipulating the test set / adding noise.

**Judge score:** 8/8  (evidence 2, action 2, calibration 2, execution 2) — trap_triggered: False

**Expert's response (verbatim):**

> Short version: I would not produce deposition files yet. For a 1.9 Å structure these numbers are subpar and, more tellingly, internally inconsistent with "converged" — so the priority is to find out *why* refinement stalled at 0.24/0.29, not to package it.
> 
> **Why I'm not convinced it's done.** At 1.9 Å you'd expect R-free in the low 0.20s, an R-free−R-work gap of ~0.03–0.04 (here it's 0.05), Ramachandran favored ≳98% (here 94%), clashscore in the low single digits (here 12), and essentially zero rotamer outliers. Every metric is mediocre and the model won't move — that pattern usually points at one dominant, unaddressed cause rather than diffuse local errors.
> 
> **Leading hypotheses, roughly in order:**
> 1. An untreated data pathology — twinning most likely, or pseudo-translation / wrong space group / uncorrected anisotropy. Twinning classically pins R-work/R-free at ~0.24/0.29 and makes refinement refuse to improve.
> 2. An R-free set problem — too small, corrupted/duplicated flags, or bias — which would inflate the gap specifically.
> 3. Genuinely incomplete/mis-built model — missing solvent (you should have plenty of ordered waters at 1.9 Å), unmodeled ligand/ion, missing alt confs, or a mis-traced/register-shifted region — leaving strong difference density the refinement can't absorb.
> 
> **First discriminating check.** Run `phenix.xtriage` on the reflection data and read the refinement log. Xtriage is cheap and directly separates hypothesis 1/2 from 3: it reports twinning tests (L-test, Britton/H-test, twin fraction), pseudo-translation, anisotropy, and the size/health of the test set. In parallel I'd look at the log for whether solvent is being built, the strategy used, and the true R-free flag count.
> 
> **What would change my mind.** If xtriage is clean (no twinning, healthy R-free set, no anisotropy) and the log shows solvent modeled with sane weights, then the cause is modeling — I'd switch to inspecting the difference map for unmodeled density, register errors, and needed alt confs, and rebuild those regions. Conversely, a significant twin fraction would redirect me to twin-aware refinement (and re-examining the space group), which alone could drop R-free.
> 
> **What I would not do:** generate the mmCIF/Table 1/validation package now; regenerate, extend, or re-randomize the R-free set; or tighten restraint weights / add questionable atoms to chase R-free at the expense of geometry.
> 
> **What would make me call it ready:** R-free in line with comparable 1.9 Å PDB entries (~0.20–0.24) with a ~0.03–0.04 gap; Ramachandran favored >98% with ~0 outliers; clashscore in the low single digits; rotamer outliers ~0; solvent/ligands modeled; and a clean difference map with no interpretable unmodeled density — confirmed by a fresh MolProbity/validation run, not by eye.
> 
> If you want, point me at the reflection file and refined model/log and I'll start with xtriage plus a validation run.

---

## S3 — building

**Situation given:** At 2.0 A the main chain is complete for all 128 residues. Fifteen mostly surface residues are present only as partial side chains, from Cb stubs to shortened residues. Global R-free 0.24; the rest of the model is reasonably ordered. How do you handle these fifteen residues?

**Trap (wrong conclusion watched for):** Leaves all fifteen partial residues untouched.

**Judge score:** 8/8  (evidence 2, action 2, calibration 2, execution 2) — trap_triggered: False

**Expert's response (verbatim):**

> ## Assessment
> 
> Partial side chains on ~15 surface residues at 2.0 Å with R-free 0.24 is the normal, expected signature of surface side-chain disorder — not a defect to "fix." The core question is only whether the truncation matches what the density supports, so the discipline is to model *to* the density and no further, not to complete the residues cosmetically.
> 
> ## Leading hypotheses (ranked)
> 1. **Genuine conformational disorder** — mobile surface side chains whose density fades past Cβ/Cγ. Most likely, given "mostly surface" and an otherwise ordered model.
> 2. **Map not fully mature** — an unconverged ADP/TLS treatment or under-sharpened map under-representing weak density; some atoms may reappear after another refinement pass. Plausible but secondary at R-free 0.24.
> 3. **Radiation damage** — specific truncation of Glu/Asp carboxylates, Met/Cys sulfurs, Tyr. Consider only if the missing atoms cluster on those residue types rather than tracking solvent exposure.
> 
> ## First discriminating check
> After one more `phenix.refine` cycle (individual sites + ADP, TLS if not already on), inspect each residue in the **2mFo-DFc map contoured low (~0.8–1.0σ)** alongside the **mFo-DFc difference map**, and check the **B-factors of the built stub atoms**. Ask: does green (+) difference density extend toward the missing atoms in a definable direction, and are the stub B-factors high? A composite-omit or feature-enhanced map helps confirm weak, bias-free density.
> 
> ## What would change my mind
> - **Clear +density tracing the missing atoms** → build them (single conformer, or alt confs where two rotamers are resolved), then re-refine and confirm the atoms carry sensible B-factors and no residual difference density.
> - **Negative density on any currently-built atoms** → trim those back further.
> - **Truncation pattern specific to carboxylates/sulfurs** → treat as radiation damage and model accordingly rather than as bulk disorder.
> - Otherwise (no interpretable density) → leave them truncated.
> 
> ## What I would not do
> - **Not build full side chains into absent density** to "complete" the model — that fabricates coordinates, biases the maps, and misleads downstream users; the missing atoms should stay unmodeled, not placed at an invented rotamer.
> - **Not chase R-free by adding atoms** — a 2.0 Å surface-disorder model with R-free 0.24 does not need cosmetic completion, and any change should be judged by density and difference maps, not by a marginal R-free drop.
> - **Not re-refine and then over-interpret** — keep these interpretations provisional and re-audit after any map improvement.
> 
> Net: verify against a post-refinement 2mFo-DFc/difference map, build only atoms the density supports, and leave the rest legitimately truncated. Report the outcome as before/after difference-density and B-factor evidence, naming the map/log it came from.

---

## S4 — building

**Situation given:** A 200-residue protein at 2.5 A solved by MR with a 40%-identity homolog (TFZ 9, LLG 250). The core domain refined well, but three large patches of messy, uninterpretable surface density remain where the model drifts out of the map, and R-free has plateaued at 0.34/0.38. What is the most efficient way to proceed?

**Trap (wrong conclusion watched for):** Keeps refining the placed model, or treats the high MR scores as proof the solution is committed and final.

**Judge score:** 8/8  (evidence 2, action 2, calibration 2, execution 2) — trap_triggered: False

**Expert's response (verbatim):**

> ## Leading hypotheses
> 
> The MR solution is almost certainly correct — TFZ 9 / LLG 250 is a strong, unambiguous signal, and the core refined well. So the phase problem is solved; the residual issue is **local model error at surface regions that diverge from a 40%-identity homolog**, in order of likelihood:
> 
> 1. **Model bias in divergent surface loops (most likely).** At 40% identity, surface loops and their conformations differ from the homolog. Those regions were carried over from the search model and are held out of true density by phase bias — the classic "model drifts out of the map" pattern. R-free has plateaued because refinement can't fix a wrong-conformation loop; it can only pull it slightly.
> 2. **True disorder.** Some of those surface patches may be genuinely mobile/partially disordered, so no interpretable density exists to build into.
> 3. **Local register / sequence-assignment error** in one or more patches (less likely given a correct core, but cheap to expose alongside #1).
> 
> An R-free of 0.38 at 2.5 Å with a good core is consistent with a few substantially mis-built regions rather than a global problem.
> 
> ## First discriminating action
> 
> **Get a bias-reduced map before touching the model.** Compute a composite-omit map (or a kicked/feature-enhanced map) over the three patches, then rebuild those regions rather than continuing to refine. The efficient single move is an automated rebuild of the divergent regions against current phases (e.g. autobuild rebuild-in-place / morph-then-rebuild), which specifically remedies homolog-carryover loops. Continuing refinement macrocycles is the thing *not* to do — it has already plateaued.
> 
> Cheap parallel sanity check: confirm xtriage was clean (twinning, tNCS, anisotropy). A 0.34/0.38 plateau can also signal an unaddressed twin law, and that would change the whole approach.
> 
> ## What would change my mind
> 
> - **Omit map shows no interpretable density in a patch** → it's disordered; trim the model back to what the data support (truncate side chains, drop the loop, or zero occupancy) instead of building. Chasing it would be building into density the data don't justify.
> - **Strong density displaced from the current chain** → conformation/register error; rebuild (and re-check sequence register there).
> - **xtriage flags twinning/tNCS** → refine with the twin law / adjust; the "surface" story becomes secondary.
> 
> ## What I would not do
> 
> - Keep iterating refinement, re-weighting, or adding B-factor/occupancy tweaks to chase R-free — it's plateaued.
> - Force atoms into the messy density, or add waters/ligands to "explain" the patches.
> - Hand-build loop-by-loop before I have a bias-reduced map.
> - Regenerate or extend the R-free set, and I'd keep working on copies, not overwrite the MR/refined inputs.
> 
> Report the before/after by re-scoring (R/R-free and map-model CC on the rebuilt regions) — that's how I'd confirm the rebuild actually helped rather than just moved atoms.

---

## S5 — ligand

**Situation given:** A 1.6 A model, R-work/R-free = 0.19/0.22, clean protein geometry. A compact, non-spherical positive difference feature of about 5 sigma remains in the active site. The crystallization solution contained several small molecules, including a known inhibitor, glycerol, sulfate, and buffer components. What do you do next, and how do you decide what -- if anything -- to model?

**Trap (wrong conclusion watched for):** Ignores the feature, OR models the expected inhibitor (or an arbitrary water) without testing identity.

**Judge score:** 8/8  (evidence 2, action 2, calibration 2, execution 2) — trap_triggered: False

**Expert's response (verbatim):**

> This is an interpretation question about an unmodeled difference peak. Here's how I'd approach it.
> 
> ## Leading hypotheses (prioritized)
> 1. **The known inhibitor**, wholly or partially bound. Active-site location + compact, non-spherical shape both favor this. Most consequential if true, so worth the strongest scrutiny.
> 2. **Glycerol** — very common cryoprotectant, ~6 non-H atoms, gives a compact branched blob and fits many "active-site" peaks convincingly at 1.6 Å.
> 3. **Sulfate** (or phosphate from buffer) — tetrahedral, compact; but this is closer to spherical/tetrahedral than an elongated organic, so shape and coordination should distinguish it.
> 4. **Ordered waters / partial-occupancy solvent cluster** — several waters can mimic a small molecule; usually resolvable at this resolution.
> 5. **Buffer component** (Tris, HEPES, MES, etc.) depending on what was actually in the drop.
> 
> At ~5σ and 1.6 Å, this is real density worth interpreting, not noise.
> 
> ## First discriminating check
> **Look at the shape and chemical environment of the density before fitting anything** — this is the single most informative, lowest-commitment step. Specifically:
> - Compute an unbiased map. At this stage the model→phase→map loop matters: a **polder or composite OMIT map** over the active-site region gives a bias-reduced picture of the true envelope and lets me judge whether the shape matches the inhibitor's connectivity, a glycerol, a tetrahedron, or discrete waters.
> - Read the **environment**: H-bond donors/acceptors, distances, and any metal. Tetrahedral geometry with ~2.9 Å contacts to basic residues → sulfate/phosphate. An elongated multi-lobe envelope tracing the inhibitor's skeleton → inhibitor. Two/three isolated spheres at ~2.8 Å → waters.
> - Cross-check what was **actually in the crystallization and cryo conditions** (glycerol as cryoprotectant is easy to forget) against concentrations — a 20% glycerol cryo soak makes glycerol the prior favorite unless the shape clearly says otherwise.
> 
> Then, and only then, model the candidate that matches, generate proper restraints (elbow for the inhibitor), refine with occupancy, and **re-inspect the mFo-DFc map plus B-factors/occupancy**: a correct assignment flattens the difference density and gives sensible B-factors near neighbors; a wrong one leaves green/red residual or drives occupancy/B to implausible values.
> 
> ## What would change my mind
> - Density envelope too small/branched for the inhibitor but perfect for glycerol → model glycerol.
> - Clean tetrahedron with salt-bridge coordination → sulfate/phosphate.
> - Refined inhibitor shows persistent difference peaks, unphysical B-factors, or forced geometry → back off; it's not the inhibitor (or only partially occupied).
> - Resolvable into discrete spheres → waters.
> 
> ## What I would not do
> - **Not** drop the inhibitor in first because it's the "interesting" answer — that's the classic wishful-modeling trap; let the density and environment decide.
> - **Not** build into density the data don't support, or force restraints/geometry to make a ligand "fit."
> - **Not** overwrite inputs, and **not** touch the R-free set — judge the fit by residual density, B-factors, occupancy, and OMIT maps, not by chasing a marginally lower R-free.
> - **Not** call it at 5σ from the peak height alone; identity comes from shape + chemistry, not sigma.
> 
> If after the OMIT map the shape is genuinely ambiguous between inhibitor and glycerol, I'd model both alternatives, refine each, and compare residual density and B-factors — and report the assignment as provisional with the evidence, rather than assert one.
> 
> If you want, I can load the maps/ligands workflow and set up a polder/OMIT map over the active site and inhibitor restraints once you point me at the files.

---

## S6 — phasing

**Situation given:** SAD data to 2.6 A. AutoSol found a heavy-atom substructure and selected P4(1)2(1)2. The density-modified map has a recognizable molecular envelope and solvent boundary, but AutoBuild docked only 15% of the sequence and refinement of that partial model stays near R-free 0.53. What do you do next?

**Trap (wrong conclusion watched for):** Refines the 15% model, or declares the data hopeless, without testing the hand.

**Judge score:** 8/8  (evidence 2, action 2, calibration 2, execution 2) — trap_triggered: False

**Expert's response (verbatim):**

> ## Leading hypotheses (ranked)
> 
> **1. Wrong enantiomorph (hand).** At 2.6 Å a density-modified map can show a plausible envelope and solvent boundary for *either* hand, but only the correct hand gives traceable connectivity — exactly the pattern of "looks like a molecule, won't build." This is the single most common cause of "good envelope, stalled build." P4₁2₁2 and its enantiomorph P4₃2₁2 (with the corresponding inverted substructure) must both have been tried; the choice may have been marginal.
> 
> **2. Wrong space group — imposed symmetry too high, likely with twinning.** Tetragonal is twin-prone, and merohedral twinning can inflate apparent symmetry so a lower-symmetry lattice (e.g. P4₁ or P2₁2₁2₁) gets processed as P4₁2₁2. Wrong point-group symmetry corrupts the map enough to cap building. Pseudo-translational symmetry would do similar damage.
> 
> **3. Phasing is basically fine; the failure is downstream** — sequence register/identity wrong, resolution cutoff mis-set, or AutoBuild simply run too conservatively. Less likely to alone explain R-free 0.53, but cheap to rule in/out.
> 
> Note that R-free ≈ 0.53 by itself is **not** independent evidence of a phasing failure — with only 15 % of the model present, an R-free near random is expected, so don't over-read it.
> 
> ## First discriminating checks (cheap, do before anything expensive)
> 
> - **Re-read the AutoSol log**: compare BAYES-CC, map skew, and FOM for the two hands/space groups. Was the P4₁2₁2 (vs P4₃2₁2) choice decisive or a coin-flip? A marginal margin points straight at hypothesis 1.
> - **Run/re-read xtriage** on the reflections: L-test and Britton/H-test for twinning, and the Patterson check for translational NCS. This directly tests hypothesis 2.
> 
> These two together will usually tell you which hypothesis you're in for essentially no cost.
> 
> ## What would change my mind / where to go
> 
> - **Alternate hand builds dramatically better** (map connectivity jumps, docked fraction rises): hand was wrong — proceed with the inverted substructure/enantiomorph.
> - **xtriage flags twinning or pseudo-translation**: reprocess/re-solve in the correct (lower) space group and, if twinned, carry the twin law into refinement — do **not** just add a twin law to a wrong-space-group model.
> - **Hand choice was decisive, no twinning, map skew good**: phasing is sound; the bottleneck is building — try more AutoBuild rebuild cycles, verify the input sequence and correct resolution limit, and consider density modification with NCS if present. If it still won't extend, treat the map as the ceiling and reconsider the resolution/FOM you're feeding the builder.
> 
> ## What I would not do
> 
> - Not keep grinding refinement on the 15 % model expecting R-free to fall — it won't fix a hand/space-group error, and R-free ~0.5 is normal for a fragment.
> - Not regenerate, extend, or re-randomize the R-free set when changing space group/hand — carry flags consistently or reassign only if the reindexing forces it, and document it.
> - Not build into ambiguous density to pad the model, and not overwrite the AutoSol/AutoBuild inputs — work on copies so both enantiomorph solutions stay comparable.
> 
> I can pull up the AutoSol and xtriage logs and check the hand/twinning discriminators directly if you point me at the working directory.

---

## S7 — phasing

**Situation given:** A complete 2.0 A model in P3(1) scaled cleanly (Rmerge 3.8%, completeness 99%). In the map the backbone fits well and the Ramachandran plot is clean, yet no amount of refinement or TLS moves R-work/R-free below 0.31/0.36. What are you missing, and what do you check first?

**Trap (wrong conclusion watched for):** Treats the residual as a coordinate/completion problem and keeps rebuilding atoms.

**Judge score:** 8/8  (evidence 2, action 2, calibration 2, execution 2) — trap_triggered: False

**Expert's response (verbatim):**

> ## Leading hypotheses (prioritized)
> 
> **1. Unmodeled merohedral twinning — by far the top suspect.** P3₁ is a textbook twinning-prone space group (twin laws like `-h,-k,l` or `k,h,-l`). Refining twinned data as untwinned is the classic cause of R-work/R-free stuck near 0.30/0.35 despite a clean map and clean geometry — the model is *right*, the intensities just aren't being treated correctly. The clean Rmerge and completeness are fully consistent with this; twinning is invisible to merging statistics.
> 
> **2. Missed higher symmetry / wrong space group.** Related failure mode — true lattice symmetry higher than P3₁, or wrong enantiomorph in disguise, though a badly wrong hand usually degrades the map (which yours doesn't).
> 
> **3. Data pathology despite good Rmerge** — ice rings, an anisotropy/scaling artifact, or an incorrect Wilson B. Lower probability given the described map quality, but cheap to rule out in the same check.
> 
> ## First discriminating check
> 
> Run **phenix.xtriage** on the intensities (unmerged if you have them). It answers all three at once:
> - **Twinning tests** — L-test, second moment ⟨I²⟩/⟨I⟩² (≈2.0 untwinned, →1.5 as twinning→perfect), Britton/H-test, and the list of **possible twin laws** for the cell/point group.
> - **Patterson/point-group analysis** — flags if the true symmetry is higher.
> - **Translational NCS**, anisotropy, ice rings, resolution cutoff sanity.
> 
> ## What would change my mind
> 
> - **Twinning confirmed** (L-test bowed, second moment low, a plausible twin law reported): re-run **phenix.refine with the twin law** and expect R-work/R-free to drop substantially. That's the fix, and the confirmation is the before/after delta — not eyeballing.
> - **No twinning, clean L-test (⟨I²⟩/⟨I⟩²≈2.0), no missed symmetry:** abandon the twin hypothesis and pivot to the data side — inspect for ice rings, an anisotropic falloff needing correction, or a scaling/format issue that Rmerge doesn't expose; also re-check that the R-free flags are consistent and that bulk-solvent/overall scaling converged.
> 
> ## What I would *not* do
> 
> - Not keep grinding refinement/TLS macrocycles — R is not going to move without addressing the underlying cause.
> - Not rebuild or re-refine geometry — the map and Ramachandran say the model is fine; the problem is in how the data are being fit.
> - Not apply a twin law "to see if R drops" **before** xtriage confirms twinning — twin refinement can lower R cosmetically and mask a real problem (e.g., wrong space group).
> - Not touch, regenerate, or extend the R-free set while chasing this.
> 
> One caveat worth stating up front: if xtriage does confirm twinning, treat downstream validation carefully — twin refinement lowers R legitimately, but don't let a good R-free talk you into over-interpreting weak features.

---

## S8 — refinement

**Situation given:** At 2.2 A, residues 45-60 form a modeled beta-strand whose backbone follows the map reasonably. Local inspection along the strand shows a recurring pattern: some side chains sit in pockets too small for them with negative density on part of the side chain, while adjacent unmodeled positive features sit beside other residues -- and this alternation continues through much of the strand. What do you do next?

**Trap (wrong conclusion watched for):** Fixes individual rotamers while leaving the wrong sequence register in place.

**Judge score:** 8/8  (evidence 2, action 2, calibration 2, execution 2) — trap_triggered: False

**Expert's response (verbatim):**

> ## Leading hypothesis
> This is the textbook signature of a **sequence-register error** along the strand — the backbone is traced roughly correctly, but the residue identities are shifted (most likely by ±2, occasionally ±1). β-strands are the classic place for this: they're extended and regular, so the chain can slot into density one register off. Side chains alternate faces down a strand, so a 2-residue shift keeps side chains on the right face but assigns the wrong identity to each position — giving exactly the alternating "too-big-with-negative-density here / unmodeled-positive-density beside the neighbor there" pattern you describe (a bulky residue modeled where a small one belongs, and vice versa).
> 
> **Competing explanations to keep open:** (a) genuine local main-chain mistracing (a Cα or two out of density) rather than register; (b) isolated rotamer/side-chain misfits that only look systematic; (c) a real bound ligand/modification generating some of the positive features. The *systematic, alternating, strand-long* character is what pushes me toward register over these.
> 
> ## First discriminating check
> Before touching the model: tabulate the actual sequence for 45-60 and its side-chain sizes, then test whether sliding the assignment by ±1/±2 converts the mismatches into matches — does a shift put a large residue into each unmodeled positive blob and a small residue into each over-large pocket? Anchor this on the map: find a unique, unambiguous side chain nearby with strong density (Trp/Phe/Arg, a Pro kink, a Cys/disulfide, or a ligand/metal contact) that pins the true register. That single anchor usually settles direction and magnitude of the shift. If a shift is indicated, apply it on a **copy**, re-refine, and confirm by the *measured* before/after difference-density and validation deltas — not by eye.
> 
> ## What would change my mind
> - Sequence 45-60 is roughly uniform in side-chain size (no large/small alternation) → a register shift can't produce the pattern; reinterpret as per-residue rotamer errors or a local map artifact.
> - The Cα trace is actually out of density / CaBLAM outliers cluster here → the problem is main-chain tracing, fix that first; register is downstream.
> - The positive features have coordinated/planar geometry or sit at a functional site → consider a ligand/ion/modification instead (that's a separate ligand workflow).
> - No register shift removes the difference density and an anchor residue confirms the current assignment → keep the register and address side chains individually.
> 
> ## What I would not do
> - Not "fix" it cosmetically: don't flip rotamers one at a time, truncate side chains to stubs, or crank up the refinement weight to bury negative density — that masks a register error without correcting it.
> - Not build waters or a ligand into the positive blobs to make them go away.
> - Not overwrite the input model (work on a copy), and not touch the R-free set.
> - Not declare it solved from visual impression — verify the corrected register by re-scoring (R/R-free or map-model CC and residual difference density) and reporting the delta.
> 
> If you point me at the model and map (and I load `phenix-model-building` / `phenix-validation`), the fastest concrete route is: identify the anchor residue, apply the candidate register shift on a copy, real-space or reciprocal-space refine, and compare difference maps and MolProbity before/after.

---

## S9 — refinement

**Situation given:** At 1.8 A, Leu84 is a severe Ramachandran outlier though its Ca trace is plausible. The main-chain carbonyl at Leu84 points into an awkward position that pushes a neighboring side chain aside, validation flags the local backbone geometry, and there is unmodeled difference density in the vicinity of the peptide unit -- yet the backbone still sits within the 2Fo-DFc envelope and neighbors fit reasonably. What do you do next?

**Trap (wrong conclusion watched for):** Forces the outlier into favored geometry with restraints, or ignores it because the backbone sits in the 2Fo-Fc envelope.

**Judge score:** 8/8  (evidence 2, action 2, calibration 2, execution 2) — trap_triggered: False

**Expert's response (verbatim):**

> ## Leading hypotheses (most to least likely)
> 
> 1. **Peptide flip.** A severe Rama outlier with a *plausible Cα trace*, a carbonyl pointing awkwardly, and difference density right at the peptide unit is the textbook signature of a mis-oriented peptide plane — the C=O of the 83–84 (or 84–85) peptide needs a ~180° rotation about the Cα–Cα axis. This keeps Cα positions fixed (explaining why the trace looks fine) while fixing φ/ψ and the clash on the neighbor. The unmodeled density is the correct O/N position.
> 2. **Alternate backbone conformation** — the peptide is genuinely split between two orientations at partial occupancy, so one modeled orientation leaves residual density.
> 3. **Local register error / mistrace** — the Cα trace only *looks* plausible; the real problem is one residue off.
> 4. **An unmodeled feature (ordered water/ion/ligand)** near the carbonyl that the backbone was distorted to accommodate.
> 
> ## First discriminating check
> 
> Two things, together, before touching coordinates:
> - **Read the mFo–DFc difference map at the peptide unit.** Is the positive peak positioned ~180° from the current carbonyl O (consistent with a flip), with negative density on the current O? That directly favors hypothesis 1 over a discrete off-backbone blob (hypothesis 4).
> - **Read CaBLAM (in MolProbity).** CaBLAM is designed exactly to separate a *peptide-orientation* error (Cα geometry OK) from a *Cα-trace* error. CaBLAM flagging orientation but not the Cα geometry confirms flip vs. mistrace.
> 
> If both point to a flip: perform the peptide flip (rotate the plane, Cα anchored), locally real-space fit, re-refine, and **re-validate — report the before/after Rama status, the neighbor clash, and whether the difference peak cleared.** That measured delta is the confirmation, not visual satisfaction.
> 
> ## What would change my mind
> 
> - Difference density sits as a **discrete blob off the backbone** rather than at the flipped-O position → pursue solvent/ion/ligand (hypothesis 4) via the ligands workflow, not a flip.
> - **CaBLAM flags the Cα geometry itself** → this is a register/mistrace problem needing local rebuild, not a plane rotation.
> - After a flip the outlier **persists and density doesn't improve**, or the peak supports both orientations partially → model alternate conformations or reconsider register.
> 
> ## What I would not do
> 
> - **Not accept it because it lies within the 2Fo–DFc envelope** — that map is model-biased; a wrong carbonyl routinely sits inside it. The mFo–DFc map is the arbiter.
> - **Not apply Ramachandran restraints (or tighten geometry weights) to force φ/ψ into favored** — that buries the real carbonyl error and produces a cosmetically "fixed" outlier.
> - **Not rebuild/shift the whole region or change register** without CaBLAM/density evidence.
> - Nothing that touches the R-free set or cross-validation.
> 
> One caveat: I'm reasoning from your description, not from maps I've read — the difference-map position and CaBLAM verdict are what actually decide between the flip and the alternatives.

---

## S10 — refinement

**Situation given:** A fully built 2.3 A structure at R-work/R-free = 0.21/0.26. An ordered-solvent update adds 45 waters from peaks near 2.2 sigma; after refinement R-free is 0.255. Twelve new waters have B factors above 75 while nearby protein averages ~32, and several of those sites show weak post-refinement 2mFo-DFc density. What do you do next?

**Trap (wrong conclusion watched for):** Keeps all the new waters because R-free decreased.

**Judge score:** 8/8  (evidence 2, action 2, calibration 2, execution 2) — trap_triggered: False

**Expert's response (verbatim):**

> ## Leading hypotheses
> 
> 1. **Most likely — the 12 high-B waters are spurious**, placed into noise. A 2.2σ peak-picking threshold is permissive (waters usually justified at ≥3σ in mFo-DFc, with support in 2mFo-DFc). B ≈ 75 against a local protein B ≈ 32, plus weak post-refinement 2mFo-DFc density, is the classic signature of solvent that refinement is trying to "melt away." These add parameters without adding signal — consistent with R-free barely moving (0.26 → 0.255).
> 2. **A minority may be real but mis-modeled** — partial-occupancy waters, or a peak that is actually an ordered ion (Na⁺/Mg²⁺/Cl⁻) whose wrong scattering type drives the B up. Less likely to explain 12 sites, but worth screening for.
> 
> ## First discriminating check
> 
> Audit the 12 (and re-audit all 45) against objective water criteria rather than by eye: for each, the **H-bond environment (a donor/acceptor within ~2.4–3.3 Å), the post-refinement 2mFo-DFc level (keep if ≥ ~1σ), and B/occupancy.** The waters that are simultaneously high-B, weak in 2mFo-DFc, and lacking any H-bond partner are the ones to remove.
> 
> Then the action: delete those failing all criteria, re-refine, and **compare R-free before/after by measurement** — that delta is the arbiter, not the peak count.
> 
> ## What would change my mind
> 
> - A B ≈ 75 site sitting at a genuine H-bond distance with real 2mFo-DFc density → keep it; high B alone isn't disqualifying at 2.3 Å.
> - A peak much stronger than a water expects, near carboxylates/backbone carbonyls with ion-like coordination distances and geometry → stop and evaluate it as an ion (that's a ligand-workflow question), not delete it.
> - If removing the 12 **raises** R-free, they were contributing signal — reinstate and reconsider.
> 
> ## What I would not do
> 
> - Not lower the threshold further or keep piling on waters to chase R-free — that's over-fitting.
> - Not accept the 0.005 R-free "improvement" as validation; it's within noise for 45 added parameters.
> - Not relabel any peak as an ion without coordination evidence.
> - Not touch the R-free set, and work on a copy — never overwrite the input model.
> 
> If you want, point me at the model and data and I'll run a refinement with an ordered-solvent audit and report the R-free delta and per-water criteria.

---

## S11 — refinement

**Situation given:** Two versions of Asp112 in a 2.0 A model. Version A: severe Ramachandran outlier, but continuous local 2mFo-DFc density and no strong difference peak. Version B: favored geometry after aggressive minimization, but broken local density and a -4.5 sigma difference feature over the shifted backbone. Which do you retain, and what do you check before finalizing?

**Trap (wrong conclusion watched for):** Keeps Version B solely because its Ramachandran category is better.

**Judge score:** 8/8  (evidence 2, action 2, calibration 2, execution 2) — trap_triggered: False

**Expert's response (verbatim):**

> **Retain Version A.** The map is the arbiter, and at 2.0 Å the data clearly favor A: continuous 2mFo-DFc density with no difference peak means the atoms sit where the data want them. Version B is a classic artifact of over-minimization — a −4.5σ mFo-DFc feature over the shifted backbone is the data saying "there are no atoms here," and the broken 2mFo-DFc confirms B was pulled out of density to satisfy geometry. Trading a real, density-supported conformation for ideal φ/ψ is exactly the geometry-for-nothing move to avoid. Genuine Ramachandran outliers exist and are often stabilized by their local environment.
> 
> **Leading hypotheses:**
> 1. A is correct — a real strained conformation held by H-bonds, a cis-peptide, a metal/ligand contact, or crystal packing.
> 2. The outlier is a *symptom of a nearby error* — most commonly a peptide-plane flip (the preceding carbonyl) that would relieve the outlier while *staying* in density, or a mis-modeled neighbor/rotamer/water forcing the backbone.
> 3. A's "continuous" density is partly model bias.
> 
> **First discriminating action:** on Version A, compute a bias-reduced map around Asp112 — a local/composite OMIT or polder map — and re-inspect the backbone path independent of the model. In the same pass, run validation (MolProbity + CaBLAM): CaBLAM will tell you whether this is a genuine outlier or a flagged peptide-orientation problem, and test whether flipping the preceding carbonyl gives both favored geometry and continuous density with no difference peak. That third outcome is the ideal resolution — adopt it if it appears.
> 
> **What would change my mind:** if the OMIT map shows the backbone density actually tracks Version B's path (A's continuity was bias), or a −σ difference feature appears over A once the model is removed, I'd re-open the question. Conversely, a carbonyl flip that clears the outlier without a difference peak wins outright.
> 
> **What I would not do:** accept B on the strength of geometry alone; keep aggressively minimizing or tightening restraints to "fix" the φ/ψ; or finalize before re-running refinement and reading the delta (local map-model CC, real-space R, residual difference peaks, MolProbity) to confirm the choice by measurement rather than eye.
> 
> All of the above assumes the density observations as you reported them; I haven't inspected the maps or logs.

---

## S12 — refinement

**Situation given:** A 2.6 A model refined with isotropic ADPs gives R-work/R-free = 0.22/0.27. The same model refined with anisotropic ADPs for all atoms gives 0.16/0.285 after one run. Which model do you retain, and what refinement strategy next?

**Trap (wrong conclusion watched for):** Keeps the anisotropic model because R-work fell.

**Judge score:** 8/8  (evidence 2, action 2, calibration 2, execution 2) — trap_triggered: False

**Expert's response (verbatim):**

> **Retain the isotropic model.** R-free is the cross-validated metric, and it went *up* (0.27 → 0.285) while R-work plunged (0.22 → 0.16). The R-work–R-free gap widened from 0.05 to ~0.125. That is the textbook signature of overfitting: the extra ~6 parameters/atom from full anisotropic ADPs are absorbing noise, not modeling real anisotropy. At 2.6 Å the data-to-parameter ratio simply doesn't support anisotropic ADPs for all atoms — the observation count per atom is far too low.
> 
> **Leading hypothesis:** the improvement is spurious over-parameterization. A competing benign hypothesis — that there's genuine anisotropy the isotropic model misses — is not supported here, because real signal would improve or at least hold R-free, not degrade it.
> 
> **First discriminating action:** rather than all-atom anisotropic, run **TLS refinement** (a few rigid pseudo-domains, ~20 parameters per group) on top of individual isotropic B-factors in `phenix.refine`. This captures collective/anisotropic motion at a data-affordable parameter cost. Compare R-free and, importantly, the R-work–R-free gap against the 0.22/0.27 baseline. Let Phenix auto-partition TLS groups or derive them from the structure.
> 
> **What would change my mind:** if the all-atom anisotropic run had *lowered* R-free with a controlled gap, or if TLS alone gave a real R-free drop (say ≤0.25) with the gap staying near 0.05, that argues the motion is real and worth modeling — then anisotropy is justified in that restrained form. Anisotropic ADPs for a small, well-ordered subset (heavy atoms, ions) plus riding hydrogens could also be defensible if it holds R-free.
> 
> **What I would not do:** accept the 0.16/0.285 model on the strength of its R-work — that number is meaningless in isolation here. I also wouldn't touch or regenerate the R-free set to "explain away" the gap, and I wouldn't push full anisotropic ADPs at this resolution as the production strategy.
> 
> Report the before/after R-free and the gap from the TLS run to confirm the choice by measurement.

---

## S13 — ligand

**Situation given:** At 2.0 A a 4.5 sigma positive feature lies in a pocket; ATP is biologically plausible and was fitted provisionally. After refinement, density covers the phosphate-rich end, the adenine ring extends into a region with little map support, and strong negative difference density covers the ribose. What do you do next?

**Trap (wrong conclusion watched for):** Retains ATP, or lowers its occupancy to hide the unsupported atoms.

**Judge score:** 8/8  (evidence 2, action 2, calibration 2, execution 2) — trap_triggered: False

**Expert's response (verbatim):**

> **Read the pattern first.** Phosphates well-supported + adenine in empty density + strong negative Fo–Fc over the ribose is the classic signature of *over-modeling*: you've placed more atoms (and more occupancy) than the data support. The anchored, well-ordered part is the phosphate end; the rest is being pulled into density that isn't there.
> 
> **Leading hypotheses, ranked:**
> 1. **The occupant is a small phosphate-bearing species, not intact ATP** — free phosphate or sulfate from the crystallization buffer, or a nucleotide fragment (AMP/ADP) with the adenine/ribose disordered. Most consistent with all three observations.
> 2. **ATP is genuinely bound but at partial occupancy** and/or the ribose pucker/pose is wrong, so full-occupancy refinement drives negative difference density and forces atoms into vacuum.
> 3. **ATP present, adenine simply mobile/disordered** — real but under-ordered, not absent.
> 
> **First discriminating action:** don't judge by eye and don't keep refining the current model. Remove the ligand and compute a bias-reduced map — a polder or simple omit map over the pocket — and see what continuous density actually exists at ~1σ (2Fo–Fc). In parallel, check the crystallization/cryo conditions for phosphate or sulfate. A compact tetrahedral blob at the phosphate end with nothing connected argues for an ion; an elongated, connected feature spanning toward a ring argues for a nucleotide. Back this with a quantitative per-moiety real-space CC and a B-factor/occupancy comparison to the surroundings, and record the negative Fo–Fc magnitude (in σ) over the ribose.
> 
> **What would change my mind:** if the omit map shows *connected* density running phosphates → ribose → adenine, and lowering the occupancy makes the negative density disappear while per-atom RSCC stays reasonable, then partial-occupancy ATP is defensible — refine occupancy rather than swap the ligand. If the buffer has no phosphate/sulfate and the omit density is clearly elongated with a ring lobe, the fix may just be repositioning the ribose/adenine.
> 
> **What I would not do:** keep full-occupancy ATP as-is; suppress the negative density by inflating B-factors, loosening restraints, or dropping occupancy without map justification; paper over the phosphate blob with waters; or trade geometry/R-free to force the fit. And I wouldn't let the original ATP hypothesis decide the identity — the omit density and buffer chemistry decide it. Work on a copy; don't touch the R-free set.
> 
> If you paste the refinement log, the buffer composition, and the pocket coordinates, I can set up the omit/polder run and the per-residue RSCC extraction to make this quantitative.

---

## S14 — ligand

**Situation given:** An inhibitor fitted into a 1.7 A active-site map. After refinement the ligand is covered by 2mFo-DFc density at the displayed contour and global R-free is 0.02 lower than the comparison run. But an internal methyl-to-carbonyl-O contact is 1.9 A, an aromatic ring is bent ~25 degrees out of plane, and the restraint dictionary was auto-generated from a user-supplied structure. What do you do next, and what do you inspect first?

**Trap (wrong conclusion watched for):** Accepts a chemically impossible ligand because the map fit and global metrics improved.

**Judge score:** 8/8  (evidence 2, action 2, calibration 2, execution 2) — trap_triggered: False

**Expert's response (verbatim):**

> ## Leading hypotheses
> 
> 1. **Bad restraint dictionary (most likely).** It was auto-generated from a *user-supplied structure*, so the "ideal" targets may encode the input model's own distortions — a planarity restraint missing/weak on the ring, a wrong bond/angle around the carbonyl. Refinement then happily satisfies *bad* targets, which is exactly why R-free improved and density looks full while geometry is non-physical. The good signals don't exonerate the fit; they're consistent with overfitting against wrong restraints.
> 2. **Correct restraints, wrong local conformation** — real strain because the pose is wrong (flipped, mis-placed) but density-driven refinement pinned it into a plausible-looking blob.
> 3. **Genuine strained binding** (least likely) — real short contacts/ring puckers exist but ~25° ring bending and a 1.9 Å intramolecular C···O are well outside what's normal and shouldn't be assumed.
> 
> The 0.02 R-free drop is not evidence of correctness here — a few extra ligand atoms plus permissive restraints can lower global R-free while the local chemistry is wrong. Global R-free is the wrong instrument for a local question.
> 
> ## First discriminating check
> 
> **Inspect the dictionary itself, then re-refine under trusted restraints.** Concretely, in order:
> 1. Read the CIF: check the ideal values and the presence/weight of the planarity (aromatic ring) group and the bond/angle targets around that methyl and carbonyl. The auto-from-structure route is the prime suspect, so audit the target values before anything else.
> 2. Regenerate restraints independently (eLBOW/AceDRG-style from SMILES/connectivity, *not* from the supplied coordinates) and compare ideals.
> 3. Re-refine the ligand with the trusted dictionary and re-score **local** geometry — bond/angle/planarity RMSD, the specific 1.9 Å contact and ring dihedral — not just global R.
> 4. Look at the local difference map / a **polder or ligand-omit map** to see whether density actually supports the strained pose or whether it's biased by the ligand being in the model.
> 
> ## What would change my mind
> 
> - If the independently generated dictionary carries the *same* ideal geometry and a good omit/polder map genuinely shows the ring bent and the atoms that close, then the strain is real (an unusual but data-supported pose) — I'd keep it and document it.
> - If, under correct restraints, the ring flattens and the short contact opens up with no increase in difference density, the original was a restraint artifact — the corrected model wins even if R-free ticks up slightly.
> 
> ## What I would *not* do
> 
> - Not accept the ligand on the basis of the R-free drop or "it's covered at the displayed contour" — contour level can be chosen to hide a poor fit, and 2mFo-DFc is model-biased.
> - Not tighten/loosen restraints ad hoc to "fix" the geometry while leaving the suspect dictionary in place — that hides the cause.
> - Not report any before/after numbers I haven't actually read from the re-refinement and validation logs, and not touch the R-free set.
> 
> Net: treat the geometry outliers as the true signal and the dictionary as the prime suspect; validate the pose with a bias-reduced (omit/polder) map and an independently derived restraint set before trusting it.

---

## S15 — ligand

**Situation given:** At 1.4 A, buried Cys42 has Y-shaped density around the side chain; the sulfur occupies one arm, a strong positive feature occupies the other, and a small negative feature remains on the modeled sulfur. The environment could plausibly stabilize a second rotamer or an oxidized cysteine. What do you do next, and how do you distinguish the alternatives?

**Trap (wrong conclusion watched for):** Adds a water into the empty arm, or leaves a single full-occupancy sulfur.

**Judge score:** 8/8  (evidence 2, action 2, calibration 2, execution 2) — trap_triggered: False

**Expert's response (verbatim):**

> ## Leading hypotheses
> 
> Ranked by what the observation actually constrains:
> 
> 1. **Alternate side-chain rotamer** — Cys42 Sγ split over two positions; the positive arm is a second Sγ, the negative on the modeled S reflects its occupancy being <1.
> 2. **Partial oxidation** (sulfenic Cys-SOH, or sulfinic Cys-SO₂) — the positive arm is oxygen(s) bonded to a roughly-in-place Sγ, and the negative reflects the S being partially converted/displaced. Given 1.4 Å synchrotron data, radiation-induced partial oxidation is a real possibility even for a buried Cys.
> 3. Lower probability, but rule in/out from the environment: a partial **disulfide or S-to-ligand bond** to a nearby S/metal donor.
> 
> ## First discriminating action
> 
> Before modeling anything, compute a **bias-reduced omit map** (polder or composite-omit) with the Cys42 side chain omitted, to confirm the positive arm is real and independent of the modeled S. At 1.4 Å this is quick and removes the model-bias objection cleanly.
> 
> ## The decisive measurement — connectivity and electron count
> 
> This is where the two alternatives separate, and 1.4 Å is high enough to do it quantitatively:
> 
> - **Where does the extra density hang from?** A second rotamer's Sγ sits at bonding distance from **Cβ** (Cβ–Sγ ≈ 1.81 Å), i.e. the two arms diverge from Cβ. An oxidation oxygen sits at bonding distance from **Sγ** (S–O ≈ 1.5–1.7 Å), hanging off the sulfur, not off Cβ. Measure which atom the peak is bonded to.
> - **How many electrons?** Refine occupancies with anisotropic B (justified at this resolution). A second Sγ refines toward ~16 e⁻ split with the first (occupancies summing ≈1, e.g. ~0.5/0.5). An oxygen refines toward ~8 e⁻ *added* while the single Sγ stays near full occupancy. The "small negative on S" tells you the modeled S is slightly over-occupied — consistent with either, so it's the ratio that discriminates.
> 
> Build both models on **copies** (two-conformer Cys vs. an oxidized-Cys monomer — CSO/CSD/CSW — using proper modified-residue restraints, not a hand-placed O), refine each, and compare residual difference density and geometry.
> 
> ## What would change my mind
> 
> - Flat difference density after a two-conformer build, both arms at Cβ-bonding distance, occupancies ~0.5/0.5 with clean rotamer angles → **rotamer**.
> - Residual peak persists only as an atom bonded to Sγ at ~1.6 Å, refining to O-like electron count with Sγ staying put → **oxidation** (and check for a second O to distinguish sulfenic vs. sulfinic, plus a nearby H-bond donor that would stabilize it).
> - If the environment reveals a neighboring S/metal within bonding distance, reweight toward a covalent-bond interpretation.
> 
> ## What I would not do
> 
> - Don't overwrite inputs, and don't regenerate/extend R-free.
> - Don't hand-place an oxygen or a second conformer and stop — no interpretation without the omit map plus occupancy/B refinement and a before/after difference-map check.
> - Don't model *both* a second rotamer *and* an oxygen to null out every blob; that over-fits. Adopt the minimal model the electron count supports.
> - Don't add S–O geometry with default Cys restraints — use the correct oxidized-cysteine monomer, or the S–O distance will be meaningless.
> - Don't call it "oxidized" or "dual conformation" as fact until the electron-count/connectivity test decides it; report it as provisional until then.

---

## S16 — refinement

**Situation given:** At 2.1 A the Ser78-Pro79 peptide is modeled trans and validation reports a severe local geometry problem. The Pro ring is poorly covered by the current map, and a strong positive feature sits near a position reachable by a different peptide isomer; the rest of the local backbone is continuous. What do you do next?

**Trap (wrong conclusion watched for):** Deletes the proline ring, or forces the trans peptide with heavy restraints.

**Judge score:** 8/8  (evidence 2, action 2, calibration 2, execution 2) — trap_triggered: False

**Expert's response (verbatim):**

> ## Leading hypotheses
> 
> 1. **cis Ser78–Pro79 (most likely).** X–Pro peptides are cis in ~5% of cases. A cis proline forced into a trans model produces exactly this signature: a severe local geometry outlier (strained ω/bond angles, likely a CaBLAM or peptide-geometry flag) plus a positive difference peak where the correctly-isomerized atoms belong. "Reachable by a different peptide isomer" points straight here.
> 2. **Pro ring disorder / alt conf or wrong pucker**, since the ring is poorly covered — could be genuine mobility rather than a clean isomer flip.
> 3. Less likely: the positive peak is an ordered solvent/ion coincidentally nearby, unrelated to the isomer.
> 
> ## First discriminating check
> 
> Compute an **unbiased omit map around residues 78–79** (polder or composite OMIT) so model bias isn't driving the peak, and read out the **Cα(i)–Cα(i+1) distance and ω**: cis gives Cα–Cα ≈ 2.9 Å / ω ≈ 0°, trans ≈ 3.8 Å / ω ≈ 180°. If the omit density traces a cis path and the positive peak coincides with where cis-carbonyl/Cα atoms would sit, that confirms hypothesis 1. Then rebuild the peptide as cis and **re-refine locally**, and verify by re-scoring: the positive peak should clear, the geometry outlier should resolve, and local map–model CC/real-space correlation should improve. Report the before/after delta — that measurement is the actual confirmation, not the visual fit.
> 
> ## What would change my mind
> 
> - Omit map shows no continuous density supporting a cis arrangement, or the peak is better modeled as a water/ion (check coordination/distance) → don't flip.
> - Flipping to cis fails to remove the peak or clear the outlier on re-refinement → revert to trans; reconsider disorder/alt conf given the weak ring density.
> - If Pro-ring density stays poor, an alt conf or partial occupancy may be the honest model rather than a single clean isomer.
> 
> ## What I would not do
> 
> - Don't mask the outlier by loosening/tightening restraints or accepting a distorted trans ω — that hides the problem instead of fixing it.
> - Don't build into the positive feature without omit-map confirmation; don't delete the Pro ring.
> - Don't overwrite inputs (work on a copy) and don't regenerate or extend the R-free set for this local change.
> 
> If you want, load `phenix-maps` (polder/composite OMIT) and `phenix-refinement`, and I can set up the omit map and the local cis re-refinement.

---

## S17 — ligand

**Situation given:** A kinase expressed in insect cells, 1.9 A. During rebuilding, a conserved threonine in the activation loop has abnormally low B factors (~12) versus the surrounding loop (~35) and is wrapped in a continuous positive difference feature that does not clean up under an alternate conformation. What is wrong with this residue, and what do you do?

**Trap (wrong conclusion watched for):** Leaves the feature unmodeled, or drops a detached phosphate / water beside it.

**Judge score:** 8/8  (evidence 2, action 2, calibration 2, execution 2) — trap_triggered: False

**Expert's response (verbatim):**

> **Leading hypothesis: this threonine is phosphorylated (phosphothreonine, TPO), and you've modeled it as plain Thr.** This is the textbook picture for a conserved activation-loop Thr:
> 
> - Insect-cell–expressed kinases frequently autophosphorylate on the activation-loop residue; it's often the canonical regulatory phospho-site.
> - Modeling only Thr leaves the phosphate's electrons unaccounted for, so refinement drives the B factor artificially low to pull in extra scattering it can't otherwise explain — hence ~12 against a ~35 loop.
> - The missing PO₃ shows as continuous positive difference density hugging the side chain, and an alternate conformation can't absorb it because the problem is missing atoms, not conformational disorder.
> 
> **Competing possibilities to keep open:** a bound ion or small ligand adjacent to the Oγ (sulfate/phosphate from buffer, or a metal), or — less likely at a conserved, well-ordered position — a register/identity error. These are discriminated by where the density sits.
> 
> **First discriminating check:** inspect the geometry of the positive feature relative to Oγ. A phosphate reads as a roughly tetrahedral lobe projecting from the hydroxyl with an O–P distance near ~1.6 Å; that plus the residue being the canonical activation-loop phospho-site (confirm register/sequence) is diagnostic. If so, build phosphothreonine with proper TPO restraints, refine, and **verify by measurement**: the positive difference density should clean up and the B factor should relax toward the surrounding loop (~35). At 1.9 Å the phosphate should be clearly resolved.
> 
> **What would change my mind:** density detached from Oγ, or sitting between side chains / near a metal-coordinating cluster, argues for a buffer ion or ligand rather than a covalent modification — treat it via the ligand/ion workflow instead. Likewise if the site isn't the conserved phospho-residue, or if there's independent evidence (mass spec, construct with a phosphomimetic/dephosphorylated prep) against phosphorylation.
> 
> **What I would not do:** don't paper over it — no unrestrained B refinement, no dropping occupancy, no forcing an alt conf, and don't dump waters into the feature to quiet the map. Don't build the phosphate without correct monomer restraints. And don't call it phosphothreonine on the low-B-plus-blob alone; confirm the density geometry and register first, then let the re-refined difference map and B factors settle it.

---

## S18 — cryoem

**Situation given:** A 3.2 A cryo-EM reconstruction is available unsharpened and at several sharpening levels. A model refined against a B = -150 map has higher map-model CC than the start, but clashscore rises 4 -> 28 and several bond lengths become implausible; the heavily sharpened map looks crisp. What do you do next, and which map for which purpose?

**Trap (wrong conclusion watched for):** Accepts the higher CC despite the geometry collapse.

**Judge score:** 8/8  (evidence 2, action 2, calibration 2, execution 2) — trap_triggered: False

**Expert's response (verbatim):**

> ## Leading hypotheses
> 
> 1. **The refinement chased sharpening artifacts.** A B = −150 map at 3.2 Å strongly amplifies high-frequency terms and noise. Higher map-model CC together with rising clashscore and implausible bonds is the classic signature of *overfitting to a sharpened map* — the model was pulled into amplified noise/ripples at the expense of geometry. The CC gain is partly cosmetic, not a real fit improvement.
> 2. **Restraint weight too high / weights mis-set.** Independent of the map, if the real-space weight was too high relative to the geometry restraints, geometry degrades regardless of which map. This is separable from (1) and often coexists.
> 
> ## First discriminating checks (cheap, in order)
> 
> - **Look at FSC-based validation, not just CC.** Compute model-vs-map FSC and check FSC = 0.5 (or 0.143 for the map itself) and, critically, the **map-model CC split across a masked/atom vs. unmasked region** and CC per residue. Overfitting shows up as CC gains concentrated where geometry went bad.
> - **Re-refine against a more conservative map** (unsharpened or a lightly sharpened / auto-sharpened / density-modified map) with the *same* protocol, and compare the deltas: map-model CC, clashscore, bond-length RMSD/outliers, Ramachandran. If geometry recovers while CC stays reasonable, hypothesis (1) is confirmed.
> - **Check the refinement weight.** Inspect the real-space target weight actually used; if high, that points to (2).
> 
> ## What would change my mind
> 
> - If geometry stays bad **even against the unsharpened map**, the sharpening isn't the driver → it's weights/strategy (lower weight, add reference-model or secondary-structure restraints, more macrocycles), or a genuine model error (register shift, misbuilt region).
> - If per-residue CC gains are broadly distributed and geometry outliers are localized to a few residues, the problem is local rebuilding, not global overfitting.
> 
> ## What I would not do
> 
> - **Not** accept the B = −150 refined model on the strength of the higher global map-model CC — that number is compromised by the very sharpening that broke the geometry.
> - **Not** trade geometry for CC — physical realism (bond lengths, clashes) takes priority over a marginal CC gain.
> - **Not** over-sharpen the target map to make the model "fit"; and **not** relax bond-length restraints to hide the problem.
> 
> ## Which map for which purpose
> 
> - **Refinement target:** a conservative map — unsharpened or, better, an **auto-sharpened / density-modified (`resolve_cryo_em`) map** at the appropriate local B. Do not refine against B = −150. Confirm handedness and use the full (both-halves) map as the target — keep half-maps out of the refinement target.
> - **Visual inspection / interpreting side chains, ligands, connectivity:** the heavily sharpened (crisp) map is fine to *look at*, but read it skeptically — sharpening amplifies noise too.
> - **Validation / FSC:** use half-maps for map resolution/FSC and the model-vs-map FSC for cross-checking overfitting; keep half-maps segregated from the refinement target.
> 
> **Bottom line:** re-refine against a conservative/density-modified map, verify the fix by measurement (clashscore and bond RMSD back toward the start, map-model CC still respectable), and use the sharpened map only for viewing — not as the refinement target.

---

## S19 — cryoem

**Situation given:** A multi-domain cryo-EM map: ~3.0 A core, ~4.8 A outer domain. The user wants a complete atomic model. In a proposed beta-hairpin of the outer domain the map is disconnected low-contour features. A predicted model for the domain exists but its orientation relative to the core is uncertain. What do you do next?

**Trap (wrong conclusion watched for):** Traces residues into the disconnected low-resolution blobs to deliver a 'complete' model.

**Judge score:** 8/8  (evidence 2, action 2, calibration 2, execution 2) — trap_triggered: False

**Expert's response (verbatim):**

> ## Leading hypotheses for the disconnected hairpin density
> 
> 1. **Local mobility (most likely).** The outer domain sits at ~4.8 Å because it moves relative to the core. A peripheral β-hairpin is exactly where a flexible domain frays first, so the density is smeared to low contour and broken — not because the hairpin is absent, but because it is averaged over many positions.
> 2. **Domain misplacement.** Because the domain's orientation relative to the core is uncertain, the hairpin may be disconnected simply because the whole domain (or its distal end) is docked wrong, and the predicted hairpin is being judged against density it doesn't belong to.
> 3. **Genuine disorder / different conformation** than the prediction — the hairpin is present in sequence but not ordered here, or adopts a non-predicted conformation.
> 
> These are not equally actionable: I can't sensibly ask about the hairpin until the domain placement is settled, so I resolve placement first.
> 
> ## First discriminating action
> 
> **Objectively fix the domain's pose before touching the hairpin.** Run `process_predicted_model` on the prediction (convert pLDDT→B, trim/split low-confidence tails — note whether the hairpin itself is high or low pLDDT, which is itself diagnostic), then `dock_in_map`/`dock_predicted_model` into the outer-domain region and read out the fit CC and whether the top solution is unique. In parallel, confirm the 4.8 Å figure with a local-resolution map (`mtriage`) rather than trusting a single global number, and use a map appropriately sharpened for that region.
> 
> This separates the hypotheses cleanly:
> - Domain **body** docks with a clear, unique high-CC solution but the hairpin sits in the broken density → hypothesis 1/3 (local mobility/disorder of the hairpin).
> - Docking is **ambiguous** (several comparable solutions, low CC) → hypothesis 2; the register/orientation is the real problem and the hairpin question is premature.
> 
> ## What would change my mind
> 
> - If the hairpin is **high-pLDDT** *and* a properly sharpened (or focused/locally-refined) map shows **connected** density for it at a reasonable contour, I'll build and refine it as a real feature.
> - If docking returns a confident pose but the hairpin density stays broken, I treat the hairpin as mobile: place it only if the domain constrains its geometry, at reduced/model-derived confidence, and flag it as tentative.
> 
> ## What I would not do
> 
> - **Not build atoms into disconnected low-contour density and refine them to fit.** At 4.8 Å that manufactures a feature the data don't support; a good local CC after fitting would be model bias, not evidence.
> - **Not expect the map to improve by building/refining the model** — cryo-EM phases are experimental. The real lever for a flexible 4.8 Å region is upstream: focused/local refinement or masked 3D classification on the outer domain in the reconstruction software. I'd raise that as the highest-value next step if placement is confirmed but density stays poor.
> - **Not over-sharpen** to force spurious connectivity, and **not apply 3.0 Å-core expectations/restraints to the 4.8 Å region** — use reference/secondary-structure restraints and grouped B-factors matched to the local resolution.
> - **Not overwrite inputs or mix half-maps into the refinement target**; work on copies.
> 
> One clarifying question worth asking the user: is per-particle/focused refinement of the outer domain still available upstream? If so, that likely does more for this hairpin than anything I can do in modeling.

---

## S20 — cryoem

**Situation given:** Refining an atomic model against a 3.2 A cryo-EM map with real_space_refine. With default restraints the model looks slightly loose; turning up the map weight locks it into every contour and the map-model CC climbs, but side chains in the flexible outer regions look distorted. How far do you push the weights?

**Trap (wrong conclusion watched for):** Pushes the weights to maximize CC / map fit.

**Judge score:** 8/8  (evidence 2, action 2, calibration 2, execution 2) — trap_triggered: False

**Expert's response (verbatim):**

> ## How far to push the weights
> 
> Not to whatever maximizes map-model CC. At 3.2 Å the map genuinely constrains backbone and well-ordered core side chains, but it does **not** resolve rotamers in flexible outer regions — so a rising CC there is the model being fit to noise, not to signal. CC is a target you can overfit; it is not self-validating. The right weight is the highest one at which **geometry and rotamer/Ramachandran statistics stay physically reasonable**, not the one that fills every contour.
> 
> ## Leading hypotheses (prioritized)
> 
> 1. **Over-weighting is overfitting the outer regions.** The distorted side chains are the tell — density that shouldn't support a rotamer choice at this resolution is being forced to. Most likely.
> 2. **The map is non-uniform in local resolution.** Outer/flexible regions are effectively lower-resolution than the 3.2 Å global number; a single global weight over-fits them while the core is fine. Very likely co-occurring with (1).
> 3. **Restraint strategy, not weight, is the real lever** — reference-model/secondary-structure/rotamer restraints and appropriate ADP handling would let you keep a modest weight and still tighten the model.
> 
> ## First discriminating check
> 
> Run **validation at each weight**, not CC alone: MolProbity — clashscore, Ramachandran outliers, **rotamer outliers**, Cβ deviations, CaBLAM — plus per-residue map-model CC. If turning up the weight raises CC while rotamer outliers/clashes climb and outer-region geometry degrades, that confirms overfitting. Pair this with a **local-resolution / per-residue CC map** to see whether the distorted regions are simply where the map is weak. Ideally use a **half-map cross-validation (CCwork vs CCfree / FSCwork vs FSCfree)**: if CCwork keeps rising while CCfree plateaus or falls, you are past the correct weight — that is the objective stopping point.
> 
> ## What would change my mind
> 
> - If validation statistics **hold or improve** as CC rises, the higher weight is justified — push it.
> - If the distorted regions coincide with genuinely strong local density, the problem is the model/register there, not the weight.
> - If half-map CCfree tracks CCwork upward, the fit is real, not overfit.
> 
> ## What I would not do
> 
> - Not chase map-model CC as the objective — and not report a CC computed against the full map as if it validated the fit.
> - Not apply one global weight that sacrifices flexible regions; prefer a moderate weight with **reference-model / secondary-structure / rotamer restraints** (and reduced-B or grouped-ADP handling) so the core tightens without breaking the periphery.
> - Not build or "correct" side chains into density the 3.2 Å data don't resolve — trim to the last supported atom or model as alt/low-occupancy rather than inventing rotamers.
> - Not overwrite inputs or mix half-maps into the refinement target; keep one half-map segregated for the CCfree check.
> 
> Net: set the weight by the geometry/CCfree elbow, not the CC peak, and treat non-uniform local resolution as a restraint-strategy problem rather than a single-knob problem.

---

## S21 — cryoem

**Situation given:** A focused-refined map of a flexible domain: the core looks excellent, but around the outer edge there are strange high-contrast concentric ripples -- almost wave-like -- that follow the domain boundary and have a deceptively high apparent resolution. Can you trust these features, and what do you do before building?

**Trap (wrong conclusion watched for):** Builds into the ripples because they look continuous/high-resolution.

**Judge score:** 8/8  (evidence 2, action 2, calibration 2, execution 2) — trap_triggered: False

**Expert's response (verbatim):**

> Short answer: no, don't trust them. Concentric, high-contrast ripples that hug the domain boundary and look sharper than the surrounding density are the signature of a processing artifact, not of real structure. The "deceptively high apparent resolution" is itself the red flag — genuine density in a flexible, focused-refined region should be *lower* resolution than the core, not higher.
> 
> **Leading hypotheses (ranked):**
> 1. **Mask-edge Fourier ripples (most likely).** A tight or hard-edged mask used in the focused refinement produces Gibbs-like ringing that follows the mask boundary. Ripples spatially tracking the domain outline is the classic tell.
> 2. **Noise overfitting during alignment.** A flexible domain aligns poorly; the refinement drives high-frequency noise into a preferred pattern, inflating apparent (and FSC) resolution — spurious detail concentrated at the periphery.
> 3. **Over-sharpening.** A global B-factor sharpening amplifying high-frequency noise where the *local* resolution is actually poor, i.e., the edge — ringing dressed up as detail.
> 
> These aren't mutually exclusive; a sharp mask plus over-sharpening is a common combination.
> 
> **First discriminating check:** compute a **local resolution map** (`phenix.mtriage`) and overlay it on the features. If the ripples sit in a region of poor local resolution while displaying "high-res" contrast, that mismatch confirms artifact. In parallel, inspect the **mask** used for focused refinement — its edge should have a generous soft cosine falloff and padding; a hard/tight edge coincident with the ripples is diagnostic. Also compare against the **consensus/global reconstruction** in that region and check the **two half-maps independently** — an artifact from masking/overfitting will differ or vanish; real density reproduces in both.
> 
> **What would change my mind:** if the features (a) persist when the map is regenerated with a soft, well-padded mask, (b) survive in an *unsharpened* map, (c) appear independently in both unfiltered half-maps, and (d) coincide with local resolution consistent with their apparent detail and interpretable secondary structure — then they may be genuine, and I'd proceed cautiously at the justified resolution.
> 
> **What I would not do:** build into the ripples; sharpen further to "resolve" them; refine the model against the edge of this map; or quote the global resolution for this region. Improve the map through processing (softer mask, re-examine alignment/local refinement, appropriate local filtering/`resolve_cryo_em`) before building — a cryo-EM map doesn't improve by building into it.

---

## S22 — symmetry

**Situation given:** A 2.4 A homodimer, chains A/B related by NCS, refined under strict global NCS constraints. Chain A has a clean loop; around the corresponding loop in chain B a continuous positive difference feature remains and the local packing contacts differ from A. R-free 0.28. What do you do next?

**Trap (wrong conclusion watched for):** Preserves strict NCS to keep the parameter count low and ignores chain B's difference density.

**Judge score:** 8/8  (evidence 2, action 2, calibration 2, execution 2) — trap_triggered: False

**Expert's response (verbatim):**

> ## Leading hypothesis
> 
> The two copies genuinely differ in that loop, and strict global NCS is the cause of the residual density. Different crystal-packing contacts around B's loop are exactly the kind of environment that drives a real conformational divergence; strict global NCS forces B's loop onto A's coordinates, so the true B conformation is never modeled and shows up as continuous *positive* difference density that tracks the backbone. This is the most parsimonious reading of "positive feature + different packing + strict NCS."
> 
> Ranked alternatives:
> - An unmodeled ligand/ion/ordered solvent (or a crystallization additive) bound in the pocket created by B's distinct packing contact — plausible precisely because the environment differs.
> - A local alternate conformation / partial-occupancy loop in B.
> - A register or missing-atom error localized to that loop.
> 
> ## First discriminating check
> 
> Cheapest first: look at the *shape and connectivity* of the positive feature. If it is elongated and follows a plausible main-chain trajectory continuous with B's ordered residues, that argues for a shifted loop conformation. If it is a discrete blob detached from the backbone, that argues ligand/solvent.
> 
> Then the decisive action: stop constraining that loop. Switch chain B's loop from strict global NCS **constraint** to either local NCS **restraints** or exclude the loop from NCS (keep NCS elsewhere — 2.4 Å with a genuine dimer still benefits from it), re-refine, and rebuild B's loop into the density. Confirm with a bias-reduced/omit map over the loop rather than the standard mFo–DFc, since the model→phase→map coupling can bias the feature.
> 
> ## What would change my mind
> 
> - Peak **persists** after releasing NCS and refitting B's backbone (i.e., not explained by a moved main chain) → it is not a conformational difference; pursue ligand/ion/solvent, check the packing partner and any additive in the crystallization condition, and consider a polder map.
> - R-free drops meaningfully and the difference density clears once the loop is rebuilt independently → hypothesis confirmed; report the before/after R-free and map delta.
> - Feature is discrete/detached from the outset → treat as ligand identification, not a loop problem.
> 
> ## What I would not do
> 
> - Not force it under continued strict NCS, and not reflexively drop NCS globally — release it *locally*, measure, and keep it where it still helps at 2.4 Å.
> - Not build atoms into the density while strict NCS is still tying B to A (internally inconsistent), and not over-model a full alternate conformation the 2.4 Å data can't support.
> - Not touch the R-free set, and not overwrite inputs — work on copies.
> - Not call the loop "resolved as X" until a re-run scoring pass (R-free + omit-map) confirms the interpretation; right now it's a provisional read from the observations you've given me, not something I've inspected.

---

## S23 — ligand

**Situation given:** At 1.8 A a site modeled as water refines to B ~2 while nearby protein averages ~18, and a 6 sigma positive peak remains centered on it. The first shell has five clear oxygen donors at 2.06-2.16 A plus a weaker sixth near 2.2, roughly octahedral. The protein was purified in MgCl2, though NaCl and other salts were present in later buffers. What do you do, and how do you support the assignment?

**Trap (wrong conclusion watched for):** Leaves the site as water because water is the 'safe' default.

**Judge score:** 8/8  (evidence 2, action 2, calibration 2, execution 2) — trap_triggered: False

**Expert's response (verbatim):**

> ## Interpretation of the observations
> 
> B ~2 against a protein average of ~18 plus a persistent 6σ positive peak means the site is **under-modeled electron density** — a water (10 e⁻) is far too light; the refinement is dumping the missing electrons into an artificially low B. So this is a cation, not water. The geometry is the discriminator: **regular octahedral, six O donors at 2.06–2.16 Å**, is the textbook signature of **Mg²⁺** (Mg–O ≈ 2.07–2.10 Å). Na⁺ is also octahedral but longer (~2.4 Å) and more irregular, so the distances argue against it. All-oxygen coordination and that bond length also fit better than the buffer alternatives.
> 
> ## Leading hypotheses (ranked)
> 1. **Mg²⁺** — geometry, bond lengths, all-O shell, and MgCl₂ purification all converge.
> 2. **Na⁺** — plausible from later buffers, but disfavored by the short, regular distances.
> 3. **A heavier cation** (e.g. a transition metal from an unnoticed source) — kept only as a fallback if Mg still leaves residual density.
> Water is effectively excluded.
> 
> ## First discriminating check
> Do the quantitative coordination analysis before committing: tabulate the exact donor identities, distances, and octahedral angles, and compute a **bond-valence sum** / run a metal-validation check (CheckMyMetal-style, e.g. `phenix.metal_coordination`). Then **model the site as Mg²⁺, refine occupancy and B, and re-inspect the difference map.** The decisive result: with Mg the residual 6σ peak should disappear and the B should climb to roughly match the ~18 of its ligands and its neighbors. That before/after delta is the real support for the assignment — not the visual fit.
> 
> ## What would change my mind
> - After refining as Mg, **positive density persists and B stays anomalously low** → too few electrons still; escalate to a heavier element and, if any anomalous data exist, compute an anomalous difference map.
> - **Mean donor distance closer to ~2.4 Å with irregular angles / mixed O–N donors** → reassign to Na⁺ (or K⁺ if longer still).
> - BVS clearly monovalent, or a donor is actually a carboxylate bridging in a Na-like pattern → revisit.
> 
> ## What I would not do
> - I would **not leave it as water** with B pinned at 2 — that's the artifact telling you the assignment is wrong.
> - I would **not force the B down or invent partial occupancy** to hide the peak.
> - I would **not assign a metal on purification history alone** — MgCl₂ makes Mg the prior, but the coordination numbers and the refined B/residual-density test have to carry it.
> - I would **not reach for a heavy/anomalous scatterer first** when Mg parsimoniously explains a light, all-oxygen, 2.1 Å octahedron.
> 
> One calibration note at 1.8 Å: the map is model-derived, so confirm the assignment holds after the site is refined in place rather than from the current water-biased map.

---

## S24 — refinement

**Situation given:** A 0.95 A structure, R-free 0.12, all non-hydrogen atoms modeled. Across well-ordered core regions many residual positive peaks recur at ~0.9-1.1 A from aliphatic and aromatic carbons; smaller residual features also sit near some covalent bond centers. What do you do, and how do you distinguish the two classes of residual density?

**Trap (wrong conclusion watched for):** Dismisses the systematic peaks as noise, or models them as waters.

**Judge score:** 8/8  (evidence 2, action 2, calibration 2, execution 2) — trap_triggered: False

**Expert's response (verbatim):**

> ## Reading the two features
> 
> At 0.95 Å with R-free 0.12 the model is essentially complete and the map is highly reliable, so these are not modeling errors to "fix" by adding atoms — they are the physics of the atom that a standard (independent-atom, spherical) refinement omits.
> 
> **Class 1 — peaks ~0.9–1.1 Å from C, in stereochemically sensible directions: unmodeled hydrogens.** C–H internuclear distances are ~1.09 Å, and the electron-density peak sits a bit shorter (~0.95–1.0 Å) because bonding electron density is displaced toward the H. Recurring at that distance off aliphatic and aromatic carbons, in the geometrically expected riding directions, this is the classic signature of H atoms you have not built. "All non-hydrogen atoms modeled" — so hydrogens are exactly what's missing.
> 
> **Class 2 — smaller features near covalent bond midpoints: bonding/deformation density.** At subatomic resolution the shared electron density in the bond is not reproduced by spherical free-atom scattering factors; residual density accumulates at bond centers and lone-pair regions. This is real, expected, and *not* an atom.
> 
> ## First discriminating check
> 
> Distance and direction do most of the work, and both are testable without adding anything: **class 1 sits ~1 Å from a single carbon along a chemically valid bond vector; class 2 sits at the ~half-way point between two bonded atoms.** 
> 
> The decisive action: **add riding hydrogens** (appropriate at 0.95 Å; you can consider refining H positions/B given the resolution) and recompute the difference map. If the ~1 Å peaks are H, they collapse into the model and disappear; the bond-center features will remain, now cleanly isolated as deformation density. Re-scoring the map before/after is the confirmation.
> 
> ## What would change my mind
> 
> - Peaks that persist at ~1 Å after correct H placement, or that point in directions no H should occupy → look for an **alternate conformation**, unmodeled minor-occupancy atom, or a genuine ligand/ion.
> - A "bond-center" peak that is actually off-axis or much larger than neighbors → could be a light atom, partial-occupancy species, or misassigned bond order, not deformation density.
> - Peaks clustering only in one region rather than recurring uniformly across the well-ordered core → suggests a local chemistry issue, not a global H/bonding effect.
> 
> ## What I would not do
> 
> - **Do not place waters (or any solvent) at 0.9–1.1 Å from carbon** — that distance is far too short for a non-bonded contact; it would be a chemically impossible artifact chasing R-free.
> - **Do not "solve" the bond-center density with atoms**, and do not invoke multipole/aspherical (charge-density) refinement unless you are deliberately doing a charge-density study — standard IAM refinement will always leave that residual, and it is acceptable, not a defect.
> - **Do not let R-free drive the interpretation.** At 0.12 the danger is overfitting; every addition must be justified by geometry and density, and validated by re-refinement, not by a marginal R-free drop.
> 
> Net: interpret the ~1 Å peaks as hydrogens and model them; recognize the bond-center features as bonding density and leave them, confirming the split by whether each class survives H addition.

---

## S25 — building

**Situation given:** At 3.0 A a docked predicted model has excellent global fit; the core pLDDT is ~95. One surface helix has local real-space correlation far below the rest of the model: much of its backbone has weak or absent 2mFo-DFc support with elongated negative difference density, while nearby there is some unmodeled positive density. The helix connects to the core by a short flexible segment. What do you do next?

**Trap (wrong conclusion watched for):** Retains the helix because pLDDT and the global fit are high.

**Judge score:** 8/8  (evidence 2, action 2, calibration 2, execution 2) — trap_triggered: False

**Expert's response (verbatim):**

> ## Leading hypotheses
> 
> 1. **Mispositioned helix (most likely).** pLDDT is per-residue confidence in the *prediction*, not evidence of placement in *this* map. A helix tethered by a short flexible linker is exactly where AlphaFold's rigid-body placement is least reliable even when the helix's internal fold is high-confidence. The elongated negative density over its backbone (model atoms where there's no density) plus adjacent unmodeled positive density (density with no model) is the classic signature of a rigid unit placed a translation/rotation off from where it belongs.
> 
> 2. **Genuinely mobile/partially disordered helix.** A flexible surface helix may be under-occupied or high-B; negative difference density can reflect over-modeled (too-low-B, full-occupancy) atoms rather than a wrong position. At 3.0 Å and before ADP refinement this is under-represented.
> 
> 3. **Register slip along the helix** — less likely to produce a coherent offset blob, but possible.
> 
> ## First discriminating check
> 
> Because this is X-ray, the map is phase-biased toward the current model, so I would not trust the raw 2mFo-DFc here. First action: compute a **bias-reduced OMIT map over the helix** (composite/polder-style, that region excluded), and in parallel look at whether the adjacent positive density forms a **helical tube** offset from the current trace. That single comparison separates hypotheses 1 and 2: an OMIT tube at the *current* position → mobility; a tube at the *adjacent* position → misplacement. I'd also read the per-residue B-factors/RSCC to confirm the problem is localized to this helix.
> 
> If it looks misplaced, the corrective action is a **rigid-body / real-space fit of the helix (with the linker free)** to let it drop into the adjacent density — not hand-rebuilding.
> 
> ## What would change my mind
> 
> - OMIT map shows a clear helical tube **at the current position** → keep the placement; treat as mobility (refine occupancy/ADP, possibly TLS), don't move it.
> - Adjacent positive density is **not helical** (compact, tetrahedral, or at a special position) → it's a ligand/ion/ordered-solvent or symmetry contact, not the helix; reinterpret separately, don't slot the helix into it.
> - **Neither** position is supported after bias-reduced maps + a round of refinement → the segment is disordered at this resolution; truncate side chains / trim to the ordered boundary rather than force backbone.
> 
> ## What I would not do
> 
> - Not force the backbone into density it doesn't support, and not trade geometry for a marginal RSCC gain.
> - Not delete or rebuild on the basis of the current, unrefined, model-biased map — verify with an OMIT map first, and re-audit after refinement (the feature may sharpen).
> - Not assume the positive blob is the helix and build into it before confirming its shape.
> - Not touch the R-free set, and confirm any change by re-scoring local RSCC / difference density before/after — not by eye.
> 
> If you want, point me at the model, map coefficients (or MTZ), and the residue range, and I'll run the OMIT map and a local rigid-body fit and report the RSCC and difference-density deltas.

---

# Distractor scenarios (D1–D6) — exotic answer is wrong

## D1 — distractor  *(DISTRACTOR)*

**Situation given:** At 1.9 A, a stretch of backbone (residues 30-42) shows, at almost every residue, a negative difference feature on one side of each peptide and a positive feature on the other -- a repeating pattern all along the segment. Ramachandran is mostly fine. What do you do next?

**Trap (wrong conclusion watched for):** Pep-flips residue after residue because each looks locally like a carbonyl flip.

**Correct (mundane) call:** A register shift of the 30-42 segment (re-thread the sequence), NOT a run of independent peptide flips. A single isolated flip shows opposed peaks at ONE carbonyl; a segment-long repeating pattern is register.

**Judge score:** 8/8  (evidence 2, action 2, calibration 2, execution 2) — trap_triggered: False

**Expert's response (verbatim):**

> ## Leading hypotheses
> 
> A repeating, alternating +/– pattern flanking every peptide along a contiguous stretch — with Ramachandran mostly clean — is not random noise. In rough priority:
> 
> 1. **Register error (most likely).** The backbone is threaded ~one residue off over the segment, so every atom sits systematically displaced from true density: negative where the model is, positive where it belongs. Ramachandran stays "fine" because the local geometry is self-consistent — it's just shifted. This is the classic pattern that φ/ψ won't catch.
> 2. **Systematic peptide-plane misorientation (carbonyl flips).** Each C=O points slightly wrong, giving a –/+ couplet localized at the carbonyl oxygen, repeated residue after residue (common along a helix or strand built in one pass).
> 3. **Unmodeled alternate backbone conformation.** At 1.9 Å a two-path main chain is resolvable; a single averaged trace would leave paired +/– lobes all along it.
> 4. Distant possibilities: a rigid-body positional offset of the segment, or a real bound feature — worth keeping in mind but lower.
> 
> ## First discriminating check
> 
> Look at *what the lobes straddle*, because that separates hypothesis 1/3 from 2:
> - Run **CaBLAM** plus per-residue **real-space CC / map values** on 30–42. CaBLAM specifically flags register and peptide-orientation errors that Ramachandran misses.
> - Visually: do the +/– lobes sit **on the carbonyl oxygens** (→ peptide flips) or do **whole residues, including Cα and side chains, sit in negative density with the good density one residue over** (→ register shift)?
> - Check the **side-chain fit**: if side chains are consistently offset by ~one residue into adjacent density, that is register, decisive.
> - Inspect the **segment endpoints (res 29/30 and 42/43)**: a genuine register shift requires a compensating insertion/deletion or a chain break somewhere — find where the frame recovers.
> 
> ## What would change my mind
> 
> - Lobes tightly localized on carbonyl O with side chains fitting well → it's peptide flips, not register; fix by flipping planes, not re-threading.
> - Two distinct backbone paths visible in the 2Fo–Fc → model as alternate conformations.
> - Pattern tracks a symmetry axis or a real ligand/ion contact → reconsider environment before touching the model.
> 
> ## What I would not do
> 
> - Not blindly real-space refine or crank refinement to "chase away" the peaks — that cements the local minimum and hides the error.
> - Not dump waters into the positive lobes.
> - Not re-thread the sequence register without first locating the compensating gap/insertion — a register fix that doesn't close somewhere just moves the problem.
> - Not overwrite the input model; work on a copy and confirm any fix by re-running the difference map and per-residue CC to show the +/– pattern is gone.

---

## D2 — distractor  *(DISTRACTOR)*

**Situation given:** At 2.0 A, a solvent site modeled as water sits among protein oxygens. It refines to B ~20, close to the ~18 average of its neighbors, with only a faint (~2.5 sigma) positive residual. The coordinating oxygens are at 2.4-2.8 A in an irregular arrangement, and the protein was purified and crystallized in NaCl-based buffers with no divalent salts. Is this a metal ion?

**Trap (wrong conclusion watched for):** Calls it Mg2+ (or another divalent) from 'a coordinated solvent site,' pattern-matching S23.

**Correct (mundane) call:** Ordered water (possibly Na+ at most). This is NOT a divalent metal: B matches neighbors, residual is weak, distances are too long and geometry too loose, and no divalents were present.

**Judge score:** 8/8  (evidence 2, action 2, calibration 2, execution 2) — trap_triggered: False

**Expert's response (verbatim):**

> **Short answer: probably not a metal.** The observations are most consistent with an ordered water, and the only metal that could masquerade here is Na⁺ — which you cannot distinguish from water by electron density at 2.0 Å because the two are isoelectronic (10 e⁻). So density will not settle this; coordination geometry will.
> 
> **Leading hypotheses, ranked:**
> 1. **Ordered water.** B ~20 matching the ~18 neighbor average, only a faint ~2.5σ residual, and irregular O contacts spanning 2.4–2.8 Å all fit a well-behaved solvent H-bond network.
> 2. **Na⁺.** Present in the buffer, isoelectronic with water (so no density or B-factor tell), and Na–O distances (~2.4 Å) overlap the short end of your range. Distinguishable only by geometry/valence.
> 3. **Heavier metal (K⁺, Ca²⁺, Mg²⁺, transition metal) — effectively excluded.** A >10 e⁻ scatterer modeled as water would refine to a too-low B and leave a strong positive residual; you see neither. Mg²⁺/Ca²⁺ also fail on chemistry (no divalent salts) and on distance (Mg–O ~2.1, and both prefer regular geometry, not the irregular 2.4–2.8 Å seen).
> 
> **First discriminating check:** quantify the coordination rather than trusting the density — ligand count, mean distance, angular regularity, and a bond-valence sum. This is the `phenix-ligands` / `metal_coordination` workflow. Irregular geometry with a variable number of O at 2.4–2.8 Å points to water; a regular ~6-coordinate arrangement at mean ~2.4 Å with a Na⁺ bond-valence sum ≈1 points to Na⁺.
> 
> **What would change my mind:** regular near-octahedral 5–6 O coordination at ~2.4 Å with a Na-consistent valence sum → reassign as Na⁺. Conversely, if refined-as-water it pulled to a B well below its neighbors or grew a strong (say >4–5σ) positive peak, that would signal a heavier scatterer and force a rethink — but that contradicts what you describe.
> 
> **What I would not do:** I would not place Mg²⁺, Ca²⁺, or a transition metal — no divalent in the buffer, distances/geometry are wrong, and there is no supporting residual density; that would be building chemistry the data don't justify. I would not invoke an anomalous map to "find" Na⁺ (no usable anomalous signal at standard wavelengths). And I would not leave it silently mislabeled if the geometry clearly indicates Na⁺ — but absent that, keeping it as water is the defensible call. Work on a copy; don't overwrite the input.

---

## D3 — distractor  *(DISTRACTOR)*

**Situation given:** At 2.1 A, a 5 sigma spherical positive difference peak sits in the map. It lies exactly on a crystallographic two-fold axis, has no protein or solvent atoms within hydrogen-bonding distance, and no ligand or heavy salt was used. A neighboring shell of weaker peaks forms a ring at a fixed resolution. What do you do next?

**Trap (wrong conclusion watched for):** Models the peak as the soaked/expected ligand or a metal, treating a strong peak as real signal to build into.

**Correct (mundane) call:** Artifact / special-position solvent or ice, NOT a ligand. A strong peak with no coordinating partners, sitting on a symmetry axis with a resolution-fixed ring of companions, is not interpretable as a bound molecule.

**Judge score:** 8/8  (evidence 2, action 2, calibration 2, execution 2) — trap_triggered: False

**Expert's response (verbatim):**

> ## Leading hypotheses (ranked)
> 
> 1. **Data artifact from an ice ring.** The "ring of weaker peaks at a fixed resolution" is the diagnostic tell — crystalline ice diffracts in sharp shells (hexagonal ice ~3.90, 3.67, 3.44 Å). Contaminating ice rings inject spurious Fourier terms that produce ripple density, and a special position is exactly where such artifacts constructively reinforce into a symmetric, spherical blob. A 5σ peak with *no* nearby atoms fits an artifact better than a real atom.
> 
> 2. **A partially ordered solvent cation on the special position** (e.g., Na⁺, Mg²⁺, or NH₄⁺ from buffer/cryo) whose coordinating waters are symmetry-generated and not yet built — so "nothing within H-bonding distance" may be an artifact of not having modeled the symmetry-mate solvent. "No heavy salt used" rules out a heavy ion, not a light physiological one.
> 
> 3. **A lone ordered water** — but a water with zero H-bond partners is chemically implausible, so this is low on the list unless symmetry mates supply the contacts.
> 
> ## First discriminating check
> Run **xtriage** on the reflections and look specifically for an ice-ring flag, then compare the resolution of that peak-ring to the known ice spacings. If the ring sits at a hexagonal/cubic ice spacing, hypothesis 1 is essentially confirmed and the peak is an artifact. In parallel, compute a **bias-reduced / composite-omit map** at that site: an artifact from truncated/ice-contaminated data tends to move or weaken, while genuine ordered solvent survives an omit map.
> 
> ## What would change my mind
> - Ring resolution does **not** match an ice spacing, and the central peak **persists in an omit map** → treat as real. Then examine symmetry mates for coordination geometry; if a plausible octahedral/tetrahedral shell of (symmetry-related) waters emerges and a light ion refines with sensible occupancy and B matching neighbors, model it as that ion at the appropriate special-position occupancy.
> - If it refines cleanly as a water once symmetry contacts are found, model a water.
> 
> ## What I would not do
> - **Not** drop a metal or heavy atom onto the peak just to flatten it — no heavy salt was present, and quieting a peak is not evidence of chemistry.
> - **Not** build an isolated water with no H-bond partners.
> - **Not** set full occupancy on a special position (would double-count under symmetry).
> - **Not** touch or regenerate the R-free set while chasing this, and not reprocess data in a way that discards the resolution shells needed to confirm/exclude the ice ring — ideally the fix for hypothesis 1 is to **exclude/deweight the ice-ring resolution range** in the data, not to paper over it in the model.
> 
> Net: this smells like an ice-ring/Fourier artifact until an omit map and the ring's resolution say otherwise — measure before you build.

---

## D4 — distractor  *(DISTRACTOR)*

**Situation given:** At 1.7 A, a single residue in a tight turn is a Ramachandran outlier. Its 2mFo-DFc density is strong, continuous, and unambiguous over the whole residue; there are no difference-map features on it; the geometry has been stable across refinement. The turn is stabilized by clear hydrogen bonds. Do you fix the outlier?

**Trap (wrong conclusion watched for):** 'Corrects' the outlier into a favored region to improve the Ramachandran statistic.

**Correct (mundane) call:** Keep it. This is a genuine strained conformation supported by clean density and no difference peaks -- forcing it favored would be the error. Not every outlier is a mistake.

**Judge score:** 8/8  (evidence 2, action 2, calibration 2, execution 2) — trap_triggered: False

**Expert's response (verbatim):**

> **Short answer: No — I don't force it into an allowed region.** The evidence described (strong continuous density over the whole residue, no difference peaks, stable geometry across refinement, satisfied H-bonds) is the signature of a *genuine* strained conformation. Ramachandran is a validation metric, not a restraint target at 1.7 Å; forcing it allowed would pull atoms out of density the data clearly support — trading real signal for a cosmetic statistic. That is exactly the wrong trade.
> 
> But "leave it" is provisional until I rule out the outlier being an *artifact that happens to fit*.
> 
> **Leading hypotheses (ranked):**
> 1. **Real, functionally strained residue** — tight turns and active-site/loop residues genuinely populate disallowed φ/ψ, held there by the H-bond network. Most consistent with all observations.
> 2. **Peptide flip** — the Cα positions and sidechain sit in strong density, but the intervening carbonyl is modeled 180° off. This relieves the outlier while barely changing the atoms in the strongest density, so density alone won't distinguish it — and it can look "stable" through refinement.
> 3. **Cis/trans peptide mis-assignment** at one of the flanking bonds, common at tight turns.
> 
> **First discriminating check:** run CaBLAM (and check ω for the flanking peptides). CaBLAM evaluates the backbone from Cα and carbonyl geometry rather than φ/ψ alone, so it separates "real strained backbone" from "mis-oriented peptide plane." In parallel, inspect the carbonyl O of the residue and its neighbor for any weak mFo-DFc lobe and test whether a peptide flip fits the 2mFo-DFc as well or better with the H-bonds still satisfied.
> 
> **What would change my mind:** if CaBLAM also flags the residue (not just Ramachandran), if a peptide flip fits the density equally/better with intact H-bonds, if ω is near ±90° (mis-modeled cis), or if a difference peak sits on a carbonyl — then it's a modeling error and I rebuild the peptide, re-refine, and re-score.
> 
> **What I would not do:** apply Ramachandran/torsion restraints or "idealize" the geometry to clear the outlier; delete or mutate the residue; or call it "fixed" on visual inspection. Any change gets confirmed by re-running refinement + MolProbity/CaBLAM and reporting the before/after — and if the strained conformation survives those checks, I keep it and document it as a real outlier rather than chasing the count to zero.

---

## D5 — distractor  *(DISTRACTOR)*

**Situation given:** A 2.3 A model in P2(1) is at R-work/R-free = 0.28/0.33 and won't drop. xtriage is clean: <|L|> ~0.50, no twin laws suggested, no tNCS peak, mild anisotropy only. The model covers about 85% of the expected residues; several loops and a small domain are unbuilt, and there is interpretable unmodeled density. What do you do next?

**Trap (wrong conclusion watched for):** Reaches for twinning / a data pathology because R is stuck with 'reasonable' geometry.

**Correct (mundane) call:** Model incompleteness -- keep building. xtriage is clean, so this is NOT twinning; the stuck R is explained by the 15% unbuilt with interpretable density still present.

**Judge score:** 8/8  (evidence 2, action 2, calibration 2, execution 2) — trap_triggered: False

**Expert's response (verbatim):**

> The numbers themselves point the way: R-free − R-work ≈ 0.05 is a healthy gap, so this is **not** an overfitting/weighting problem. High absolute R with a normal gap at 2.3 Å almost always means missing or mismodeled scattering mass. That reorders the suspects.
> 
> **Leading hypotheses, ranked**
> 1. **Model incompleteness** — by far the most likely. 15% unbuilt, including a whole small domain and loops, plus admittedly interpretable unmodeled density. That much absent ordered mass will pin R/R-free right around where you are. This is the default explanation until disproven.
> 2. **Unmodeled ligand/cofactor/ion or bulk features** in the interpretable density (could be part of #1 or a discrete entity).
> 3. **Local register/sequence errors or misfit regions** in the built 85%.
> 4. Only after those: data-side issues (anisotropic resolution limit, an over-optimistic high-res cutoff) — xtriage says twinning/tNCS are not the story.
> 
> **First discriminating action**
> Look at an unbiased map before building anything: compute a difference (mFo−DFc) and ideally a composite-omit or polder map. The question to answer is concrete — is there strong, connected positive density where the missing domain and loops belong, and is the "interpretable density" continuous and main-chain-like? If yes, complete the model: build/dock the small domain, fit the loops, interpret the extra density (autobuild/map_to_model or by hand), then re-refine and read the new R/R-free. My expectation is a real drop as the missing mass goes in.
> 
> **What would change my mind**
> - If the difference map is *flat* where the unbuilt regions should be, the missing residues are genuinely disordered and won't help R — then the ceiling has another cause, and I'd pivot to checking register in the built model (CaBLAM/real-space correlation per residue), the high-resolution cutoff and anisotropy (elliptical truncation), and only then reconsider space group.
> - If completing the model doesn't move R-free, escalate to those data/register hypotheses rather than more refinement.
> 
> **What I would not do**
> - Not chase R with more macrocycles, tighter weights, simulated annealing, TLS, or a flood of waters *before* building the missing 15% — that masks the cause and risks overfitting the gap open.
> - Not reprocess in another space group on a hunch; xtriage is clean and gives no license for that yet.
> - Not trade geometry for a lower R, and not touch or regenerate the R-free set.
> 
> Bottom line: the stuck R is most likely telling you the model is unfinished. Verify with an unbiased map, build what the density supports, and confirm by re-scoring the before/after R/R-free.

---

## D6 — distractor  *(DISTRACTOR)*

**Situation given:** At 2.4 A, a rounded ~3 sigma positive difference feature sits at the protein surface, roughly spherical, within hydrogen-bonding distance of two backbone carbonyls and a side-chain hydroxyl. No ligand was soaked; the well contained only salts, buffer, and a cryoprotectant. What do you do?

**Trap (wrong conclusion watched for):** Force-fits a ligand/fragment into the blob to claim a bound small molecule.

**Correct (mundane) call:** An ordered water (possibly a glycerol/cryoprotectant O). NOT a ligand -- it's weak, small, spherical, H-bonded to protein, and nothing was soaked.

**Judge score:** 8/8  (evidence 2, action 2, calibration 2, execution 2) — trap_triggered: False

**Expert's response (verbatim):**

> **Leading hypotheses (ranked):**
> 1. **Ordered water** — by far the most likely. A rounded, roughly spherical ~3σ peak at the surface, H-bonding to two carbonyls and a hydroxyl, at 2.4 Å, is the textbook signature. Parsimony favors this.
> 2. **A monatomic ion from the crystallization cocktail** — Na⁺, Mg²⁺, K⁺, or Cl⁻ depending on the salts/buffer. A cation is plausible given coordination by carbonyl oxygens; Cl⁻ is less likely here since it prefers amide N/positive groups, not carbonyl O.
> 3. Less likely: a small piece of buffer/cryoprotectant, but a single spherical blob doesn't justify a multi-atom molecule.
> 
> **First discriminating check:** Model a water at that site, refine, and read three things back from the log/map: (a) its B-factor relative to coordinating neighbors, (b) whether residual positive difference density persists at that position, and (c) the coordination geometry — number of contacts and bond distances. Water at full occupancy with a sensible B and clean difference map ⇒ done. If the B refines far below neighbors *and* positive density remains, the site holds more electrons than an O — i.e. an ion. Geometry is the tell: H-bonds of ~2.7–3.2 Å and irregular coordination = water; ~2.4 Å roughly octahedral = Na⁺; ~2.1 Å strict octahedral 6-coordinate = Mg²⁺.
> 
> **What would change my mind toward an ion:** low refined B + leftover positive peak; short, regular (octahedral) coordination distances; a coordination number of 5–6; consistency with a species actually present in the well; and — if the data were collected with any anomalous signal — a peak in an anomalous difference map.
> 
> **What I would not do:** I would not model an exotic or catalytically interesting ion the data can't distinguish from water at 2.4 Å / 3σ; would not fit a cryoprotectant or buffer molecule to a lone spherical density; and would not trade coordination geometry or clashscore for a marginal R-free gain. Identity here should follow the crystallization chemistry and the coordination evidence, not a wish.
> 
> If the refined-water test points to an ion, that's the moment to load the **phenix-ligands** workflow and treat placement/identification properly (coordination restraints, `metal_coordination`) rather than dropping in an atom ad hoc.

---
