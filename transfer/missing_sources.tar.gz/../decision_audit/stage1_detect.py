"""
Stage 1 — candidate-decision detection.

Two detectors, run over the SAME transcript, results merged:

  A. self_flag_extractor  — pulls out places the AGENT itself expressed uncertainty,
     reconsidered, rejected its own work, or flagged a risk. High precision on
     ACKNOWLEDGED problems. Blind to confident errors (the agent won't flag what it
     doesn't realize is wrong).

  B. transcript_pass      — an INDEPENDENT model reads the whole transcript and flags
     decision points that look problematic REGARDLESS of whether the agent noticed.
     This is the detector that can catch confident errors. High recall, lower precision
     — it's meant to over-flag; stage 2 filters.

Both emit DecisionPacket objects. A decision flagged by both gets flagged_by="both".

These are the PROMPTS + orchestration. In production each detector is an LLM call over
the transcript (chunked if needed). The prompts are the deliverable here; wiring them to
a specific API is a thin layer left to the runner.
"""

# ---------------------------------------------------------------------------
# Detector A — self-flag extractor
# ---------------------------------------------------------------------------
SELF_FLAG_PROMPT = """You are extracting SELF-FLAGGED decision points from a crystallography agent's run transcript.

Find every place where the AGENT ITSELF did any of:
- expressed uncertainty or hedged about a choice it was making
- reconsidered, reversed, or rejected its own earlier action
- named a risk, caveat, or "trap" in what it was about to do
- chose between alternatives and said why

For EACH, output a JSON object with these fields (leave unknown fields as ""):
- transcript_span: the line-range where this occurs
- information_basis: what the agent had SEEN at that moment (logs, maps, metrics) — only what
  was available THEN, do not use anything stated later in the transcript
- decision_made: the concrete choice/action
- stated_rationale: the agent's own words for why (quote briefly)
- concern: what the agent itself said was uncertain/risky (its framing, not yours)
- flagged_by: "self"

Do NOT judge whether the decision was correct — that is a later stage. Only extract what the
agent flagged. Be thorough; include borderline cases. Output a JSON array.
"""

# ---------------------------------------------------------------------------
# Detector B — independent transcript pass
# ---------------------------------------------------------------------------
TRANSCRIPT_PASS_PROMPT = """You are an expert crystallographer auditing another agent's structure-determination run for
DECISIONS THAT MAY BE PROBLEMATIC — including ones the agent itself did NOT notice.

Read the transcript. Flag every decision point where a competent crystallographer might have
done something different, ESPECIALLY confident decisions the agent made without hesitation.
You are looking for:
- choices that trade cross-validation (R-free) for a better-looking R-work
- building or keeping model features the data may not support (waters, ligands, side chains)
- accepting/rejecting a metric or map feature on weak grounds
- resolution, weighting, restraint, or occupancy choices that could be wrong
- register, hand, space-group, or symmetry calls
- anything where the stated rationale does not actually justify the action taken
- steps where the agent seemed confident but the evidence at that point was thin

CRITICAL: judge each decision ONLY on the information available AT THAT POINT in the transcript.
Do not use later results as hindsight. A decision that turned out fine can still have been
poorly grounded when made, and vice versa.

For EACH candidate output a JSON object:
- transcript_span: line-range
- information_basis: what was known at that moment
- decision_made: the concrete choice
- stated_rationale: the agent's reason (quote briefly), or "(none given)"
- concern: why THIS decision looks problematic to you, the auditor
- counterfactual: the alternative(s) and what evidence would distinguish them
- severity_hint: low | medium | high
- flagged_by: "transcript_pass"

Over-flag rather than under-flag: a later independent judge will filter. Include confident
decisions even if they look right, if the grounding at that moment was thin. Output a JSON array.
"""

# ---------------------------------------------------------------------------
# Merge logic
# ---------------------------------------------------------------------------
def merge_candidates(self_flagged, transcript_flagged, overlap_lines=8):
    """Merge the two detectors' outputs. Candidates whose transcript_span overlaps
    (within overlap_lines) are treated as the same decision and marked flagged_by='both'.
    Returns a deduplicated list. (Span parsing is simple int-range here; production can
    use a more robust locator.)"""
    def span_ints(s):
        import re
        nums = [int(x) for x in re.findall(r"\d+", s or "")]
        return (min(nums), max(nums)) if nums else (None, None)

    merged = []
    used_t = set()
    for a in self_flagged:
        a_lo, a_hi = span_ints(a.get("transcript_span"))
        match = None
        for i, b in enumerate(transcript_flagged):
            if i in used_t:
                continue
            b_lo, b_hi = span_ints(b.get("transcript_span"))
            if None in (a_lo, b_lo):
                continue
            if a_lo - overlap_lines <= b_hi and b_lo - overlap_lines <= a_hi:
                match = (i, b); break
        if match:
            i, b = match; used_t.add(i)
            rec = dict(a)
            rec["flagged_by"] = "both"
            # keep the auditor's concern + counterfactual from the independent pass
            rec["concern"] = (a.get("concern","") + " || AUDITOR: " + b.get("concern","")).strip(" |")
            rec["counterfactual"] = b.get("counterfactual","")
            rec["severity_hint"] = b.get("severity_hint","unknown")
            merged.append(rec)
        else:
            merged.append(dict(a))
    for i, b in enumerate(transcript_flagged):
        if i not in used_t:
            merged.append(dict(b))
    return merged
