#!/usr/bin/env python3
"""
decision_ledger.py — the DENOMINATOR the review queues lack.

The G0 self-critique's forward walk already rates EVERY decision
(well-justified / got-lucky / weakly-justified / wrong). run_finder ingests only the flagged
tail; this extracts the whole inventory — good and bad — so the queue can be read in context
("N decisions, most well-founded, a few worth review") instead of as a bare problem list.

Deterministic: it parses ratings already written in self_analysis.md, so NO LLM call and NO
cost. Run it over existing and future runs alike.

For each runs/<case>/<arm>/run_<n>/artifacts/self_analysis.md it writes
runs/<case>/<arm>/run_<n>/CANDIDATES/decision_ledger.jsonl and prints a per-case tally.

CAVEATS (honest framing — keep these when you present it):
  * These are the Expert grading ITSELF (correlated self-critique) — good context/denominator,
    NOT independent verification. Bad decisions get three-vantage scrutiny; good ones rest on
    the Expert's own word. Label them "self-assessed", and spot-check a sample if you want
    harder evidence.
  * The forward walk under-enumerates silent defaults / failed launches, so the count is a
    LOWER BOUND — fair context, not a validated rate.

Usage: RUNS_ROOT=runs python decision_ledger.py
"""
import os, re, json, pathlib

RUNS_ROOT = os.environ.get("RUNS_ROOT", "runs")
BUCKETS = ["well-justified", "got-lucky", "weakly-justified", "wrong", "unknown"]
_HDR = re.compile(r"^\s*#{2,4}\s*(D\d+[a-z]?)\s*[—\-–]\s*(.*)$", re.I)


def classify(text):
    """Map a free-text classification line to one bucket. Order matters: 'well-justified as
    chemistry ... misjudged' is well-justified; 'weakly-justified' must not match 'well'."""
    s = (text or "").lower()
    if "wrong" in s:
        return "wrong"
    if "got-lucky" in s or "got lucky" in s:
        return "got-lucky"
    if "weakly" in s:
        return "weakly-justified"
    if "well" in s and "justif" in s:
        return "well-justified"
    return "unknown"


def _field(block, key_regex):
    pat = re.compile(rf"^\s*[-*]\s*(?:{key_regex})\s*[:\-—]\s*(.*)$", re.I)
    for ln in block:
        m = pat.match(ln)
        if m:
            return m.group(1).strip()
    return ""


def parse_forward_walk(text):
    lines = text.splitlines()
    # bound to the "## Forward walk" section if the doc has one
    start, end = 0, len(lines)
    for i, ln in enumerate(lines):
        if re.match(r"^\s*##\s+forward walk", ln, re.I):
            start = i + 1
        elif start and re.match(r"^\s*##\s+(backward trace|candidate weakness)", ln, re.I):
            end = i
            break
    body = lines[start:end] if start else lines

    # split into ### D<n> blocks
    blocks, header, buf = [], None, []
    for ln in body:
        m = _HDR.match(ln)
        if m:
            if header is not None:
                blocks.append((header, buf))
            header, buf = m, []
        elif header is not None:
            buf.append(ln)
    if header is not None:
        blocks.append((header, buf))

    out = []
    for m, blk in blocks:
        cls_raw = _field(blk, "classification")
        sev = _field(blk, "severity")
        cand = _field(blk, "candidate")
        evidence = _field(blk, r"judged[^:]*") or _field(blk, r"basis[^:]*")
        out.append({
            "id": m.group(1),
            "label": m.group(2).strip(),
            "classification": classify(cls_raw),
            "classification_raw": cls_raw,
            "severity": (sev.split()[0].lower().strip("*") if sev else ""),
            "candidate": ("yes" in cand.lower()[:8]) if cand else None,
            "evidence": evidence[:400],
        })
    return out


def find_self_analysis(run_dir):
    for c in (run_dir / "artifacts" / "self_analysis.md", run_dir / "self_analysis.md"):
        if c.exists():
            return c
    return None


def main():
    root = pathlib.Path(RUNS_ROOT)
    any_found = False
    for run_dir in sorted({p.parent.parent for p in root.glob("*/*/run_*/CANDIDATES")}
                          | {p for p in root.glob("*/*/run_*")}):
        if not run_dir.is_dir():
            continue
        case = run_dir.parts[-3]
        sa = find_self_analysis(run_dir)
        if not sa:
            continue
        decisions = parse_forward_walk(sa.read_text(errors="replace"))
        if not decisions:
            print(f"{case:22} self_analysis.md found but no rated decisions parsed")
            continue
        any_found = True
        for d in decisions:
            d["case"] = case
        outdir = run_dir / "CANDIDATES"
        outdir.mkdir(exist_ok=True)
        (outdir / "decision_ledger.jsonl").write_text(
            "\n".join(json.dumps(d, ensure_ascii=False) for d in decisions))
        counts = {b: sum(1 for d in decisions if d["classification"] == b) for b in BUCKETS}
        n = len(decisions)
        well = counts["well-justified"]
        tally = ", ".join(f"{counts[b]} {b}" for b in BUCKETS if counts[b])
        print(f"{case:22} {n} decisions ({100*well//n if n else 0}% well-justified) — {tally}")
    if not any_found:
        print(f"No self_analysis.md with rated decisions found under {RUNS_ROOT}/", )


if __name__ == "__main__":
    main()
