#!/usr/bin/env python3
"""
summarize_queues.py — one combined view across all candidate-finder review queues.

Scans RUNS_ROOT for every <case>/<arm>/run_<n>/CANDIDATES/ and rolls the per-case leads up into:
  1. a per-case table (kept leads by severity, plus how many triage dropped),
  2. a vantage-coverage matrix (which detector legs are carrying each case),
  3. a cross-case "look here first" list — every kept lead ranked by corroboration
     (n_vantages) then severity, so the multi-vantage / high-severity leads float to the top.

Reads triaged.jsonl when present (structured: has triage call + n_vantages); otherwise parses
review_queue.md. Dependency-free.

Usage:
    python summarize_queues.py                 # prints markdown to stdout
    python summarize_queues.py --out SUMMARY.md
    RUNS_ROOT=runs python summarize_queues.py  # default RUNS_ROOT=runs
"""
import os, re, sys, json, pathlib

RUNS_ROOT = os.environ.get("RUNS_ROOT", "runs")
SEV_ORDER = ["critical", "major", "moderate", "minor"]
SEV_RANK = {s: i for i, s in enumerate(SEV_ORDER)}
BASE_VANTAGES = ["self_critique", "self", "transcript_pass"]   # G0, G1a, G1b
VLABEL = {"self_critique": "G0 self-critique", "self": "G1a self-flag",
          "transcript_pass": "G1b independent"}


def _vantages(flagged_by):
    """flagged_by string -> set of base vantage tokens ('both' expands to self+transcript_pass)."""
    fb = flagged_by
    if isinstance(fb, (list, tuple)):
        fb = "+".join(str(x) for x in fb)
    fb = (str(fb) if fb is not None else "").strip().lower()
    out = set()
    for part in re.split(r"[+/]| and ", fb):
        part = part.strip()
        if part == "both":
            out |= {"self", "transcript_pass"}
        elif part:
            out.add(part)
    return out


def _lead(case, severity, flagged_by, n_vantages, decision, call):
    vs = _vantages(flagged_by)
    nv = n_vantages if isinstance(n_vantages, int) and n_vantages else (len(vs) or 1)
    return {"case": case, "severity": (severity or "unknown").lower().strip(),
            "flagged_by": flagged_by, "vantages": vs, "n_vantages": nv,
            "decision": (decision or "").strip(), "call": (call or "keep").lower().strip()}


def from_jsonl(case, path):
    leads = []
    for ln in path.read_text(errors="replace").splitlines():
        ln = ln.strip()
        if not ln:
            continue
        try:
            it = json.loads(ln)
        except Exception:
            continue
        t = it.get("triage") or {}
        leads.append(_lead(case, t.get("severity"), it.get("flagged_by"),
                            it.get("n_vantages"), it.get("decision_made"), t.get("call")))
    return leads


_HDR = re.compile(r"^##\s*\d+\.\s*\[([^\]]+)\]\s*(.*)$")

def from_md(case, path):
    leads = []
    sev = decision = None
    for line in path.read_text(errors="replace").splitlines():
        m = _HDR.match(line)
        if m:
            sev, decision = m.group(1), m.group(2)
            continue
        if sev is not None and line.startswith("- flagged_by:"):
            fb = (re.search(r"flagged_by:\s*([^·]+)", line) or [None, ""])[1].strip()
            nvm = re.search(r"(\d+)\s+vantages", line)
            callm = re.search(r"triage:\s*(\w+)", line)
            leads.append(_lead(case, sev, fb, int(nvm.group(1)) if nvm else None,
                               decision, callm.group(1) if callm else "keep"))
            sev = decision = None
    return leads


def discover():
    root = pathlib.Path(RUNS_ROOT)
    cases = {}
    for cdir in sorted(root.glob("*/*/run_*/CANDIDATES")):
        case = cdir.parts[-4]
        jl, md = cdir / "triaged.jsonl", cdir / "review_queue.md"
        if jl.exists():
            leads = from_jsonl(case, jl)
        elif md.exists():
            leads = from_md(case, md)
        else:
            continue
        cases.setdefault(case, []).extend(leads)
    return cases


LEDGER_BUCKETS = ["well-justified", "got-lucky", "weakly-justified", "wrong"]

def load_ledgers():
    """Load per-case decision_ledger.jsonl (written by decision_ledger.py) — the full
    good+bad decision inventory, for the denominator/context sections."""
    root = pathlib.Path(RUNS_ROOT)
    ledgers = {}
    for p in sorted(root.glob("*/*/run_*/CANDIDATES/decision_ledger.jsonl")):
        case = p.parts[-5]
        rows = []
        for ln in p.read_text(errors="replace").splitlines():
            ln = ln.strip()
            if ln:
                try:
                    rows.append(json.loads(ln))
                except Exception:
                    pass
        if rows:
            ledgers.setdefault(case, []).extend(rows)
    return ledgers


def render(cases, ledgers=None):
    ledgers = ledgers or {}
    kept = {c: [l for l in ls if l["call"] in ("keep", "ambiguous")] for c, ls in cases.items()}
    total_kept = sum(len(v) for v in kept.values())
    total_drop = sum(len(cases[c]) - len(kept[c]) for c in cases)
    out = ["# Candidate-finder cross-case summary",
           f"_{len(cases)} cases · {total_kept} kept leads"
           + (f" · {total_drop} dropped by triage_" if total_drop else "_"), ""]

    # 0. decision-ledger denominator (self-assessed) — frame the leads in context
    if ledgers:
        out += ["## Decision ledger — self-assessed denominator",
                "_The Expert's own forward-walk rating of every decision. Correlated "
                "self-critique, not independent verification, and a lower bound (silent "
                "defaults under-enumerated) — read it as context for the leads, not a rate._", "",
                "| case | decisions | well-justified | got-lucky | weakly | wrong | % well |",
                "|---|---|---|---|---|---|---|"]
        tot = {b: 0 for b in LEDGER_BUCKETS}
        tot_n = 0
        for c in sorted(ledgers):
            rows = ledgers[c]
            n = len(rows)
            cc = {b: sum(1 for r in rows if r.get("classification") == b) for b in LEDGER_BUCKETS}
            for b in LEDGER_BUCKETS:
                tot[b] += cc[b]
            tot_n += n
            pw = f"{100 * cc['well-justified'] // n}%" if n else "—"
            out.append(f"| {c} | {n} | {cc['well-justified']} | {cc['got-lucky']} | "
                       f"{cc['weakly-justified']} | {cc['wrong']} | {pw} |")
        if len(ledgers) > 1:
            pw = f"{100 * tot['well-justified'] // tot_n}%" if tot_n else "—"
            out.append(f"| **all** | {tot_n} | {tot['well-justified']} | {tot['got-lucky']} | "
                       f"{tot['weakly-justified']} | {tot['wrong']} | {pw} |")
        out.append("")

    # 1. per-case severity table
    out += ["## Per-case", "",
            "| case | kept | critical | major | moderate | minor | dropped |",
            "|---|---|---|---|---|---|---|"]
    for c in sorted(cases):
        ks = kept[c]
        counts = {s: sum(1 for l in ks if l["severity"] == s) for s in SEV_ORDER}
        drop = len(cases[c]) - len(ks)
        out.append(f"| {c} | {len(ks)} | {counts['critical']} | {counts['major']} | "
                   f"{counts['moderate']} | {counts['minor']} | {drop or ''} |")

    # 2. vantage coverage matrix
    out += ["", "## Vantage coverage (kept leads; a multi-vantage lead counts in each column)", "",
            "| case | G0 self-critique | G1a self-flag | G1b independent | multi (≥2) |",
            "|---|---|---|---|---|"]
    for c in sorted(cases):
        ks = kept[c]
        col = {v: sum(1 for l in ks if v in l["vantages"]) for v in BASE_VANTAGES}
        multi = sum(1 for l in ks if l["n_vantages"] >= 2)
        out.append(f"| {c} | {col['self_critique']} | {col['self']} | "
                   f"{col['transcript_pass']} | {multi} |")

    # 3. cross-case "look here first"
    all_kept = [l for ks in kept.values() for l in ks]
    all_kept.sort(key=lambda l: (-l["n_vantages"], SEV_RANK.get(l["severity"], 9), l["case"]))
    out += ["", "## Look here first (all cases, by corroboration then severity)", ""]
    for l in all_kept:
        nv = f"{l['n_vantages']} vantages" if l["n_vantages"] >= 2 else "1 vantage"
        dec = l["decision"][:100] + ("…" if len(l["decision"]) > 100 else "")
        out.append(f"- **[{l['severity']} · {nv}]** {l['case']} — {dec}  "
                   f"_({l['flagged_by']})_")

    # 4. notable good decisions (the mirror-images of the failure classes)
    if ledgers:
        out += ["", "## Notable good decisions (self-assessed well-justified, not flagged)", ""]
        for c in sorted(ledgers):
            goods = [r for r in ledgers[c]
                     if r.get("classification") == "well-justified"
                     and r.get("candidate") is False and r.get("evidence")]
            for r in goods[:3]:
                out.append(f"- **{c}** · {r['label'][:80]} — _{r['evidence'][:220]}_")
    return "\n".join(out) + "\n"


def main():
    cases = discover()
    ledgers = load_ledgers()
    if not cases and not ledgers:
        print(f"No CANDIDATES/ queues or decision_ledger.jsonl found under {RUNS_ROOT}/ "
              f"(run run_finder and/or decision_ledger.py first)", file=sys.stderr)
        sys.exit(1)
    report = render(cases, ledgers)
    out_path = None
    if "--out" in sys.argv:
        out_path = sys.argv[sys.argv.index("--out") + 1]
    if out_path:
        pathlib.Path(out_path).write_text(report)
        print(f"wrote {out_path}  ({len(cases)} cases, {len(ledgers)} ledgers)")
    else:
        print(report)


if __name__ == "__main__":
    main()
