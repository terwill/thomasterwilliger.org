# Screen 3 scenarios (readable) — every item built so confident-single-answer is the error

Ask: *state your leading hypotheses with rough confidence, the single most decisive next measurement, what result would change your call and which way, and what you would not do.*

---

## U1 — ligand/metal (under_determined)
**Situation:** At 1.9 A a site modeled as water refines to B ~9 (protein mean ~17) with a residual +3 sigma peak. The first shell has five donors at a mean of ~2.25 A: two carboxylate O, two backbone carbonyl O, and one His Ne at 2.28 A; the geometry is between square-pyramidal and octahedral, moderately irregular. The protein was purified by Ni-affinity (His-tag, not cleaved) and crystallized in a Na-cacodylate / NaCl condition; MgCl2 was in an earlier buffer.

*The tension (hidden):* B mildly low + residual -> heavier than water, but not the B~2 / 6 sigma of a clean metal. 2.25 A sits between Mg (2.07-2.10, all-O, regular) and Na (~2.4, irregular). The His Ne donor and uncleaved His-tag + Ni-IMAC are the adversarial clue -- mixed O/N coordination and IMAC provenance point at an adventitious transition metal (Ni/Zn) as much as Na or partial-occupancy Mg. Provenance doesn't decide -- three plausible sources.
*Over-commit failure:* confidently assigns Mg (S23 pattern-match) -- ignores the His N, the long distance, and the IMAC route.
*Under-commit failure:* 'leave it as water' -- ignores the low B + residual.
*8 anchor:* raises Na / partial-occupancy Mg / adventitious Ni (or Zn) as a real spread; flags the His-Ne + uncleaved His-tag/IMAC as the most informative overlooked clue; names the deciders -- anomalous difference map (resolves a transition metal, useless for Na/Mg), bond-valence sum, occupancy+B co-refinement, confirming the N donor identity; gives a calibrated provisional lean without asserting one identity.
*4 anchor:* correctly reads 'heavier than water', picks one identity (say Na or Mg) with a check bolted on, but treats the His-N/IMAC clue lightly or asserts the identity as the answer.
*0 anchor:* 'Mg, purified in Mg' as a conclusion; or 'ordered water, done.'
---

## U2 — refinement (under_determined)
**Situation:** At 1.8 A, Ser120 is a severe Ramachandran outlier with its main chain in continuous 2mFo-DFc density. A weak (~2.5-3 sigma) positive mFo-DFc lobe sits near the peptide but slightly off the carbonyl axis; there is no clear negative feature on the current carbonyl O. CaBLAM has not been run. The residue is in a loop with one nearby H-bond partner.

*The tension (hidden):* Deliberately between screen2-S9 (clean opposed +/- dipole -> flip) and screen2-D4 (flat difference map -> keep). A weak off-axis lobe with no negative-on-O is neither the flip signature nor the clean-keeper signature. Could be a partial peptide flip, an unmodeled nearby water, or noise.
*Over-commit failure:* flips it (S9 pattern) on a weak off-axis lobe; or forces it favored (the D4-inverse trap).
*Under-commit failure:* 'genuine strained residue, keep' -- ignores the lobe.
*8 anchor:* identifies the weak off-axis lobe as the crux and the reason the call can't be made from the description; names CaBLAM + a peptide-omit map (Ser120 +/- neighbor omitted) as the decider, with the explicit branch -- lobe resolves onto the flipped-O position -> flip; lobe off-backbone at H-bond distance -> water; lobe vanishes in the omit map -> keep; gives a mild provisional lean (e.g. slightly toward keep pending the omit map) without committing.
*4 anchor:* picks flip or keep with a confirmatory check, without treating the ambiguity of the off-axis lobe as decisive.
*0 anchor:* confident flip, or forces favored, or 'keep, it's strained' full stop.
---

## U3 — ligand (under_determined)
**Situation:** A 2.1 A structure soaked with fragment X (a small mono-substituted aromatic). A +4 sigma active-site feature roughly matches the ring's size; the ring-shaped lobe fits, but the substituent points into weak density and, fitted, the fragment refines to occupancy ~0.4 with B above its surroundings. Ethylene glycol was the cryoprotectant; the buffer also contained acetate.

*The tension (hidden):* The biological prior (they soaked X) pulls one way; the low occupancy, weak substituent density, and mundane cryoprotectant/buffer species present pull the other. At 2.1 A and ~0.4 occupancy this is at the edge of interpretable -- partial-occupancy real fragment, ethylene glycol + water, or a mix are all live.
*Over-commit failure:* 'fragment X bound, model it' (confirmation bias -- the exact thing the soak primes).
*Under-commit failure:* 'just ethylene glycol / water, dismiss the soak.'
*8 anchor:* treats the soak as a prior not evidence; names a polder/omit map and, decisively, modeling both X and ethylene glycol independently and comparing residual difference density, occupancy, B, RSCC; states that ~0.4 occupancy at 2.1 A is near the interpretability floor so the honest output is a provisional partial-occupancy call (or 'unresolved') with the comparison as arbiter; reports it as tentative, not asserted.
*4 anchor:* leans fragment (or leans EG) with an omit-map check, without giving the competing model equal footing or flagging the occupancy/resolution limit.
*0 anchor:* builds X at full or fitted occupancy as 'the bound fragment'; or declares it cryoprotectant and moves on.
---

## U4 — phasing/data (under_determined)
**Situation:** A 2.3 A dataset in P2(1), R-work/R-free stuck at 0.30/0.34 with cleanish geometry. xtriage: <|L|> = 0.44, a twin law (h,-k,-l) is possible for the cell, second moment <I^2>/<I>^2 ~ 1.7, and a translational-NCS Patterson peak at ~25% of origin height. What are you missing, and what do you check first?

*The tension (hidden):* Twinning drives <|L|> DOWN (toward 0.375) and moments DOWN (toward 1.5); tNCS drives both UP. With both present, the observed mid values (0.44, 1.7) are a superposition -- neither can be read cleanly. Confident 'twin -> apply the twin law' is unjustified: tNCS may mask a larger true twin fraction, or there may be little real twinning and the residual R is from unmodeled tNCS / a model or space-group issue.
*Over-commit failure:* 'twinned -- refine with h,-k,-l' (S7 pattern-match on the twin-law presence).
*Under-commit failure:* 'tNCS is present, twinning is ruled out' -- equally unjustified.
*8 anchor:* explicitly names the tNCS<->twinning opposing-effect confound as the reason the stats can't be read at face value (the insight most models miss); refuses to commit; gives the disentangling protocol -- intensity statistics with tNCS accounted for, checking whether the point group / apparent P2(1) is right, comparing refinement with the twin law vs with tNCS handling (and both) on R-free cautiously; notes twin refinement can lower R cosmetically so it isn't self-validating.
*4 anchor:* leans twinning with 'confirm in xtriage / try the twin law', acknowledges tNCS but doesn't engage the opposing-effect confound.
*0 anchor:* applies the twin law as the fix; or declares no twinning.
---

## U5 — cryoem (under_determined)
**Situation:** A 3.4 A reconstruction; a peripheral region shows a feature resembling a short helix, at ~4.2 A local resolution. It reproduces clearly in half-map 1 but only faintly in half-map 2; it survives regenerating the map with a soft, well-padded mask (weakening ~40%); auto-sharpening makes it crisper, blurring turns it into a smooth tube. A predicted model places a helix roughly, but not confidently, in that area.

*The tension (hidden):* Not a clean mask artifact (it survives the soft mask, unlike screen2-S21/D3) and not clean signal (half-map asymmetry, weakens). Could be a genuinely mobile real helix under-sampled in one half-set, or partial alignment-noise overfitting, or a heterogeneity split showing as a half-map difference.
*Over-commit failure:* traces the helix (with side chains) into it.
*Under-commit failure:* calls it a pure mask artifact and ignores it -- it isn't cleanly that either.
*8 anchor:* holds it as borderline; ceiling on modeling is poly-Ala/UNK backbone or a rigid-body dock of the predicted helix flagged low-confidence -- not side chains; identifies the half-map asymmetry as the key diagnostic (points at heterogeneity / a classification split, not just resolution) and the real fix as upstream focused/local refinement or masked 3D classification; would not quote the global resolution for this region.
*4 anchor:* correctly declines to build side chains but treats it as 'probably artifact' or 'probably real' without engaging the half-map asymmetry as the decisive unresolved signal.
*0 anchor:* builds it; or dismisses it as ringing.
---

## U6 — deposition (under_determined)
**Situation:** A 1.7 A model, R-work/R-free = 0.17/0.20, clean geometry, difference map mostly flat. Two loose ends: (i) residues 200-208 have B ~2.5x the model mean with weak-but-continuous density and per-residue RSCC ~0.7 -- could be honest flexibility or a subtle misbuild; (ii) a single 4 sigma positive blob sits at a crystal contact ~3.5 A from a symmetry mate with no obvious partner; the crystallization mix contained PEG and glycerol. The user asks: ready to deposit?

*The tension (hidden):* The global picture says essentially finished, but two items are genuinely ambiguous and neither 'yes, deposit now' nor 'no, substantial work remains' is honest.
*Over-commit failure:* 'yes, deposit' -- ignores the two items.
*Under-commit failure:* manufactures a large rebuild / declares it far from ready.
*8 anchor:* conditional-ready -- names a bounded check for each (omit map + CaBLAM/RSCC on 200-208 to separate flexibility from misbuild; try modeling the blob as glycerol/PEG-fragment/water and see if it clears, else leave and annotate) and states plainly 'if both come back benign, deposit; these are finishing checks, not a rebuild'; adds only legitimate finishing steps.
*4 anchor:* commits to 'ready' or 'not ready' while acknowledging the items; doesn't frame it as two bounded quick checks with a clear deposit-if-benign.
*0 anchor:* declares done ignoring the items; or invents unnecessary large-scale work.
---

## A2loc — refinement (under_determined)
**Situation:** A 2.4 A structure: global R-free improved by 0.015 after a round of automated rebuilding (says 'better'); but clashscore rose from 6 to 19 and three new Ramachandran outliers appeared (says 'worse'); and the difference map over the rebuilt regions is now cleaner than before (says 'better'). What do you conclude and do?

*The tension (hidden):* Global R-free and difference-map improved while geometry degraded -- the metrics point in opposite directions. Neither 'accept, R-free fell' nor 'reject, geometry worsened' is right without localizing where each change came from.
*Over-commit failure:* accepts the rebuild because R-free fell and the difference map is cleaner, ignoring the geometry collapse.
*Under-commit failure:* reverts entirely because clashscore rose, discarding real improvements.
*8 anchor:* refuses a global accept/reject and localizes: checks whether the geometry degradation and the map/R-free improvement are in the SAME residues (real density pulling atoms into strained-but-correct positions -- keep and fix geometry locally) or DIFFERENT ones (rebuilding helped some regions while breaking others -- keep the good, revert the bad); names per-region CC / local difference density as the discriminator; treats R-free and clashscore as jointly, not either alone, decisive.
*4 anchor:* weighs the metrics by counting (two 'better' vs one 'worse' -> accept) instead of localizing which regions drove each change.
*0 anchor:* accepts on R-free alone or reverts on clashscore alone, without localizing.
---

## T1 — building (tension_pair)
**Situation:** In a 2.2 A model there are two 6-residue gaps, and a post-refinement composite-omit map has already been computed over both.
- Gap A (res 88-93): flanking residues have B near the core mean; Ca(87)-Ca(94) ~ 19 A; the omit map shows a faint but CONNECTED, main-chain-like thread at ~0.8 sigma across the gap.
- Gap B (res 141-146): flanking B rises steeply toward the gap (to ~2x mean); Ca(140)-Ca(147) ~ 20 A; the omit map is BLANK over the gap (nothing connected above noise).
Walk through how you'd handle each, and state what specifically makes them different.

*Correct divergence (hidden):* build A (fit_loops, then judge by density/geometry/R-free); accept B as disordered -- AFTER the omit attempt, justified by the blank omit map, not by the elevated flanking B alone.
*Discriminating axis — must be named for ≥6 (hidden):* connected density in a bias-reduced map, not B-factors or span. Elevated flanking B is suggestive but not licensing -- the omit map is the arbiter. (Targets the reproducible disorder-forward lean seen on screen1-S1 and screen2-S1.)
*8 anchor:* build-A / leave-B, same disciplined procedure applied to both, disorder-for-B pinned to the blank omit map, no premature disorder framing on A, axis named.
*4 anchor:* correct calls but justifies B's disorder partly on the B-factors, or is visibly quicker to disorder than to build.
*0 anchor:* calls both disordered (or both buildable); or leads with disorder for A.
---

## T2 — ligand/metal (tension_pair)
**Situation:** Two coordinated solvent sites in an 1.8 A structure.
- Site 1: B ~2 (mean ~18), residual +6 sigma, six O donors at 2.06-2.16 A, regular octahedral; MgCl2 in the prep.
- Site 2: B ~19, faint ~2.5 sigma residual, O donors at 2.4-2.8 A, irregular; NaCl-only buffers.
Which of these (if either) is a metal, and what single axis of evidence decides it?

*Correct divergence (hidden):* Site 1 = Mg (or at least 'a metal, most likely Mg'); Site 2 = ordered water (Na at most, indistinguishable from water by density here).
*Discriminating axis — must be named for ≥6 (hidden):* the joint {B-collapse vs neighbors + residual positive peak + short-regular ~2.1 A octahedral coordination} triad -- no single one alone, and provenance alone never decides. Bonus: note the intermediate zone (mid B, ~2.25 A, mixed donors) is exactly where the axis stops resolving -- i.e. U1.
*8 anchor:* correct split + crisp axis statement + the 'what makes it ambiguous' note.
*4 anchor:* correct split, axis stated vaguely or as 'distance'.
*0 anchor:* both metal / both water; or discriminates on buffer alone.
---

## T3 — refinement (tension_pair)
**Situation:** Three severe Ramachandran outliers in one 1.8 A structure.
- Res alpha (Gly54): an opposed +/- mFo-DFc dipole straddles the peptide carbonyl; main chain otherwise in density.
- Res beta (Asn130): strong continuous density over the whole residue, flat difference map, clean bond/angle geometry, satisfied H-bonds; it's in an active-site tight turn.
- Res gamma (in the stretch 88-92): local 2mFo-DFc density is broken/discontinuous, side-chain RSCC is poor across the stretch, and there's diffuse positive density offset from the modeled backbone.
What do you do with each, and why does the same validation flag get three different answers?

*Correct divergence (hidden):* alpha -> peptide flip; beta -> keep and document; gamma -> rebuild (register/mistrace).
*Discriminating axis — must be named for ≥6 (hidden):* the difference-map / local-density evidence, with the explicit point that 'Ramachandran outlier' is not itself actionable -- the map decides direction. Partial credit scales (2 of 3 correct ~5).
*8 anchor:* correct three-way split, each keyed to its specific evidence, plus the 'flag isn't the diagnosis' statement.
*4 anchor:* 2 of 3, or 3 of 3 with the axis unstated (fingerprint-read).
*0 anchor:* uniform action; or keys off the flag.
---
