# Scenario-Screen Project — Full Plan (reviewable)

*A harness to measure the Phenix Expert's endgame decision quality, isolated from pipeline variance,
and to test whether short prompt statements improve it. For review by Tom, Claude, and Gemini.*

---

## 1. Goal and rationale

The 40-minute full-pipeline runs conflate two things: whether the Expert *decides* well, and whether
phasing/building happened to go well that run. We have spent the pilot watching the second swamp the
first — run-to-run variance dominates single outcomes. A **scenario probe** severs them: it poses a
described mid-run state and asks only "what do you do next," so the sole thing that can move the answer
is the Expert's reasoning (and, in phase B, the prompt). Probes cost seconds, not 40 minutes, so we can
run enough reps to get **rates** instead of anecdotes.

Two phases:
- **Phase A — screen:** run all 25 scenarios at baseline to find which failure modes the Expert
  *actually* falls for (most catalogued traps are plausible-but-unobserved; this converts them to
  observed/not).
- **Phase B — fix test:** for each real failure, test whether its candidate statement lowers the
  failure rate, without harming the others.

**Deployment note (shapes the whole design):** in production the Expert runs one *fixed* base system
prompt. We will never deliver a "variable prompt" at runtime. The candidate statements are an
experiment: winners get folded into the fixed base prompt. So phase B measures whether a statement's
*content* changes decisions — nothing here depends on a runtime prompt-swapping mechanism.

---

## 2. What a scenario is

Each of the 25 scenarios (S1–S25, reviewed and approved; full text in `scenario_probes_screen.md`)
carries four parts:
- **given_text** — a self-contained mid-run state (resolution, metrics, what the map/density shows) +
  "what do you do next?";
- **trap** — the specific wrong/lazy conclusion we're watching for;
- **rubric** — hidden ideal-move features a strong crystallographer would hit (used only for scoring);
- **candidate_statement** — the short prompt text we hypothesize fixes that failure mode.

**Two scores per response:**
- **trap flag (binary)** — did it reach the wrong conclusion. *Primary failure detector.*
- **good-feature fraction (continuous)** — of the rubric features, how many are present. Secondary in
  phase A, primary when comparing statements in phase B.

---

## 3. The Expert and how a scenario reaches it

**Expert = the real `phenix.chat` agent (Claude Code), one-shot, non-interactive, no Coot.** The
invocation is exactly the pilot's `run_job.sh` line with the Coot pieces removed:

```bash
cat "$prompt_file" | phenix.chat --auto-approve --conversation "$probe_id" \
    --timeout "$TIMEOUT" --max-turns "$MAX_TURNS" --prompt
```

- `--auto-approve` makes it run unattended. `--coot` is dropped; the Coot/DEPOSIT notes are dropped.
- **Everything we add goes into the `-p`/`--prompt` text — the base system prompt is fixed and cannot be
  altered.** So both the scenario and (Phase B) the candidate statement are piped inline. The piped
  prompt is:
  `[candidate statement, only on an Sx arm] + [scenario given_text] + [decision-question ask]`.
- **Decision-question ask:** *"Describe what you would do next and why. This is a decision question —
  explain your reasoning and the specific steps; you do not have the files in front of you. Respond in
  prose only: do not emit tool calls or shell commands."* The last clause matters — `phenix.chat` is an
  agent hardwired to act, and with `--auto-approve` it *can* run tools, so the constraint reduces but
  does not guarantee prose-only. **The adapter is therefore defensive:** it captures the final assistant
  prose answer regardless of whether the transcript also contains tool activity, rather than assuming
  the constraint held.
- **Baseline arm** = scenario + ask, no statement. **Sx arm** = statement Sx prepended to the same piped
  prompt. The only thing that varies between arms is the statement text.

**Isolation (load-bearing, from `run_job.sh`'s own note): agent memory is keyed by the working-directory
path, not folder contents.** So every probe must run in a **unique directory path**, or two probes
share a memory and contaminate each other. Layout mirrors the pilot: `runs/<scenario>/<arm>/rep_<k>/`.
Distinct paths → independent memories → the fresh-session guarantee, and six can run at once safely.

**`--conversation` is unique per probe** (`"<scenario> <arm> rep_<k>"`), mirroring the pilot's
`"$case_id $arm run_$run_n"`, so conversations don't collide in the list.

**Output capture (also from `run_job.sh`): the scorable answer is NOT stdout** (that is only a progress
log). It is the stored Claude session `.jsonl` under `~/.claude/projects/<encoded-cwd>/`, where the cwd
is encoded by replacing `/`, `.`, and `_` with `-`. The adapter reuses the pilot's exact capture: drop a
`.start_marker`, take the newest `*.jsonl` for that project dir, fall back to the newest session
`-newer` the marker. From that transcript it extracts the **final assistant message** = the response the
judge scores. (Same content `pilot capture` already trusts.)

---

## 4. Isolation and parallelism

- **process-per-probe + unique cwd path = full isolation.** No "reset your reasoning" line; the OS gives
  us clean separation.
- **No Coot → no shared resource → safe to parallelize.** `run_all.sh` runs sequentially *only* to
  protect the single Coot on port 9090; that constraint is gone. `runner.py` is the same orchestration
  (job list; skip-existing = resume; continue-on-nonzero; final tally; then `capture`) with the Coot
  serialization removed and a **6-wide process pool** in its place.
- **Robustness:** per-probe timeout is low (minutes — there is no pipeline now); on timeout, kill the
  process, mark `invocation_ok=false`, continue — one hang never stalls the run. Records are written on
  completion (crash-safe); `--resume` skips probe_ids already on disk. Agent invocation retried once on
  nonzero/timeout; judge retried once on malformed JSON.

---

## 5. Scoring — the judge

- **A separate Anthropic API call, not the agent.** Strongest available model (150 judge calls are
  cheap; judgment quality matters).
- **Input:** the scenario's rubric (features + trap definition) + the agent's raw answer.
- **Concept, not keywords:** the judge's system prompt instructs it to credit a rubric feature if its
  *concept* is present under any standard crystallographic synonym, alternate nomenclature, or parameter
  spelling — not by literal string match. (E.g. S7: "activate twin refinement" = "turn on the twin law"
  = "include `refinement.twinning.twin_law`" = "account for the hemihedral twinning" all satisfy the
  same feature.) This avoids false negatives from vocabulary variance.
- **Output:** JSON only — `{features:{fid:bool}, trap_triggered:bool, evidence:{fid:short quote}}`.
  Strip code fences; one retry on malformed JSON.
- **The judge is blind to the arm** — it never learns whether a statement was present. This prevents it
  from grading "treated" answers generously and manufacturing an effect. Non-negotiable in phase B.
- **Spot-check before trusting:** the report flags a handful of responses (borderline scores, or
  trap/feature disagreement) for human verification. A judge can be fooled by an answer that *says* "I
  would inspect the map" without meaning it, so we verify the judge before believing the rates.

---

## 6. Phase A — the screen (find real failures)

- `arms = ["baseline"]`, 25 scenarios × **N = 6** reps = **150 probes**, dispatched 6 in parallel.
- **Output** (see §8): ranked failure table (trap rate k/N per scenario), per-scenario detail with raw
  response excerpts + judge evidence, a variance note (scenarios where reps disagree), judge-reliability
  flags.
- **Triage:** scenarios that pass (low trap rate) drop out of scope for free. Scenarios that fail
  (roughly ≥ half the reps trapped, and any that trap consistently) advance to phase B. A failure seen
  at N=6 is a candidate; unstable ones (e.g. 3/6) get more reps before we act.

---

## 7. Phase B — test candidate statements (the fix)

For each real failure, test its statement as a **paired baseline-vs-treatment rate comparison across
all 25 scenarios** — never a single run.

- **Design:** `arms = ["baseline", "Sx"]`, full 25 under both, N reps each. Same scenarios, same N,
  differing only by the statement text → the difference is the statement's effect.
- **On-target:** Δtrap_rate and Δfeature_fraction on the scenario Sx targets. Sx helps if the trap rate
  falls / feature fraction rises across reps.
- **Off-target guardrail:** the *same* metrics on the other 24. A statement that fixes its target but
  raises the trap rate elsewhere is a net loss — this is where over-correction shows (e.g. "always fill
  the gap" over-building the cryo-EM noise scenarios S19/S21; "trust the difference density" breaking the
  geometry-revert case S11). The other 24 being the guardrail is the whole reason we built a broad
  suite.
- **Reading honestly at N=6:** N=6 detects **large** shifts, not subtle ones — 5/6 → 1/6 is real, 4/6 →
  3/6 is noise. Report effects as rate differences with k/N visible, not p-value theater. **Confirm any
  apparent winner at higher N (≈12–20)** before trusting it. Screen wide, confirm narrow.
- **Combined statements are a separate experiment.** After individual statements pass, test the winning
  *set* together — statements interact and a pile of them bloats the prompt and can wash out (the
  guide-length effect we already measured). Three individual wins do not sum to a combined win.
- **Decision rule — adopt Sx iff**, at confirmatory N, its target trap rate drops by a large, consistent
  margin **and** no other scenario's trap rate rises beyond noise. Otherwise reject or revise the
  wording and re-test.

---

## 8. Outputs (built for Claude + Gemini analysis)

In `runs/<timestamp>/`:
- **results.jsonl** — one line per probe, everything (programmatic analysis).
- **scores.csv** — `scenario, arm, rep, trap, feature_fraction, feat_*` — quick pivot/tabulation.
- **report.md** — the analysis document:
  - run metadata (agent command, judge model, N, seed, counts, timeouts/failures);
  - **phase A:** ranked failure table (scenario | trap rate k/N | mean feature fraction | one-line
    read); per-scenario detail worst-first (given_text, per-feature pass rate vs the rubric wording,
    trap rate, 1–2 representative raw responses incl. a failing rep, with judge evidence quotes);
    judge-reliability spot-check list; variance note;
  - **phase B (per statement):** an on-target effect line (Δtrap_rate, Δfeature_fraction, with k/N) and
    an **off-target harm table** (Δtrap_rate for each of the other 24), so the tradeoff is visible at a
    glance.

---

## 9. Per-probe data model (JSONL)

`{probe_id, scenario_id, category, arm, rep, prompt_sent, agent_cmd, cwd, conversation,
invocation_ok, session_jsonl_path, raw_response, response_tokens, wall_s,
judge:{features:{fid:bool}, feature_fraction, trap_triggered, evidence:{fid:quote}, judge_model,
judge_tokens}, error?}`

Raw responses are kept in full — they are what Claude and Gemini read to see *why* a scenario failed and
what the judge is spot-checked against.

---

## 10. File layout (mirrors phenix_pilot conventions)

```
scenario_screen/
  cli.py                 # subcommands: build, run, judge, aggregate, all
  config.example.json    # scenarios file, arms, reps, concurrency, agent cmd, judge model, timeouts, seed
  scenarios.json         # the reviewed 25, structured (given_text, trap, rubric_features[], candidate_statement)
  probes.py              # matrix expansion + per-probe prompt assembly (statement + scenario + ask, piped)
  adapter.py             # phenix.chat one-shot (run_job.sh minus Coot) + session-.jsonl capture
  runner.py              # run_all.sh orchestration minus Coot serialization, + 6-wide pool, resume
  judge.py               # rubric -> JSON booleans (blind to arm)
  aggregate.py           # trap rates, feature fractions, on/off-target deltas, ranking
  report.py              # results.jsonl, scores.csv, report.md
  scripts/run_probe.sh   # thin bash wrapper around the invocation (parallel sibling of run_job.sh)
  runs/<ts>/ ...
  tests/test_smoke.py    # matrix expansion + judge-parse on a canned response; no live calls
```

---

## 11. Build order (each step independently verifiable)

1. **scenarios.json + loader + smoke test** — 25 load, rubrics well-formed. *Gate: 25 valid.*
2. **probes.py** — matrix expansion + prompt assembly; dump the baseline 6×25 prompts to a file to
   eyeball. *Gate: prompts read like real decision questions; no calls made.*
3. **adapter.py on ONE probe** — real `phenix.chat` invocation minus Coot + the session-capture block;
   capture one agent answer. *Gate: one clean final-message response on disk.*
4. **judge.py on that response** — rubric → JSON booleans. *Gate: valid parse, sane scores, you eyeball
   the evidence quotes.*
5. **runner.py** — 6-wide parallel, crash-safe, resume; full 150-probe phase-A screen completes.
   *Gate: 150 records, timeouts handled.*
6. **aggregate.py + report.py** — *Gate: report.md ranks failures with excerpts + judge-reliability
   flags.*
7. **phase-B wiring** — add `Sx` arms, on/off-target deltas in aggregate + report. *Gate: a baseline-vs-
   Sx report with the harm table.*
8. **tests/test_smoke.py.**

---

## 12. Risks and honest caveats

- **N=6 detects big effects only.** Subtle statement effects will not survive this screen; that is by
  design, but it means "no effect at N=6" is not "no effect ever."
- **Paper decisions ≠ live behaviour.** A scenario gives the Expert a *summary*; a live run gives it the
  actual map and logs. A statement that helps on described scenarios must be confirmed on a live run or
  two before we trust it — the same screen-cheap / confirm-expensive shape as the rest of the project.
- **Placement caveat.** Phase B pipes the statement inline (user turn); production would fold a winner
  into the base *system* prompt. Placement can change potency, so a winner should get one confirmation
  in its final base-prompt-integrated form. (Minor, but stated.)
- **Judge reliability is assumed until spot-checked.** The rates are only as good as the judge; verify
  it on a sample before believing them.
- **The rubrics are authored, not field-validated.** They encode our (and Gemini's) notion of the ideal
  move. A wrong rubric trains a wrong fix — the trap flag is more robust than the feature scoring, which
  is why it is the primary detector.
- **Every number is a rate over reps, never a single response.** One probe's answer is still variance-
  prone; the unit of evidence is the k/N rate.

---

## 13. Open items to confirm (you)

1. **Two machine paths** — `PKG` and `PHENIX_SETUP`, the same two you already set in `run_job.sh`. (No
   new unknowns; the invocation is settled.)
2. **N** — confirmed 6 reps for the screen (→ 150 probes)?
3. **Judge model** — strongest available unless you prefer otherwise.
4. **Probe timeout / max-turns** — with no pipeline these finish fast; I'll default `--timeout` low
   (a few minutes) and `--max-turns` modest to cap runaways. Override if you want headroom.
