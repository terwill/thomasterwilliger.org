# Architecture

How the scenario screen is put together and why. Written against the code, not an ideal.

## The core idea

A full pipeline run conflates two things: does the Expert *decide* well, and did the pipeline
happen to succeed this time. Run-to-run variance dominates the second and swamps the first. A
**scenario probe** removes the pipeline entirely: it hands the Expert a described state and asks
only "what next?". The sole thing that can move the answer is the Expert's reasoning -- and, in
Phase B, an added prompt statement. That isolation is the whole design.

## Data flow

```
scenarios.json ──► probes.build_probes ──► [probe specs]
                                               │  (scenario x arm x rep, shuffled)
                                               ▼
                          runner.run_screen  (ThreadPool, N-wide)
                            │
                            ├─ adapter.run_probe ──► phenix.chat (fresh dir) ──► session.jsonl ──► raw answer
                            └─ judge.score ──► Anthropic API (rubric) ──► {features, trap, evidence}
                                               │
                                               ▼
                                        results.jsonl  (one line per probe, crash-safe)
                                               │
                          aggregate.aggregate ─┤──► scores.csv
                                               └──► report.md
```

## Components

### `scenarios.json` -- the 25, structured
Each: `id`, `category`, `given_text` (what the Expert sees), `trap` (the wrong conclusion),
`rubric_features` (hidden ideal-move features, each `{id, text}`), `candidate_statement` (the
Phase-B fix hypothesis). The judge consumes `given_text + trap + rubric_features`; it never sees
`candidate_statement` (that would leak the arm).

### `probes.py` -- matrix + prompt assembly
`build_probes(scenarios, arms, reps, seed)` expands scenarios x arms x reps into probe specs and
**shuffles them deterministically** (seeded), so dispatch order is decoupled from scenario order
-- in Phase B this keeps arm uncorrelated with position. `assemble_prompt` builds the piped `-p`
text: `[statement if Sx] + [given_text] + [ASK]`, where ASK constrains the answer to prose
("you do not have the files ... respond in prose only"). `arms_from_config` resolves an arm value
of `null` (baseline), a literal string, or `{"statement_of": "S7"}` (reuse that scenario's
statement) into the text to prepend.

### `adapter.py` -- one real agent call, captured
Distilled from the pilot's `run_job.sh`, Coot removed. Per probe:
- **Fresh, unique working directory.** Agent memory is keyed by the working-directory *path*,
  not its contents, so a unique path == a fresh session. The adapter refuses a non-empty dir
  rather than risk a contaminated session -- this is load-bearing, not hygiene.
- Pipes the prompt into `phenix.chat --auto-approve --conversation <id> --timeout --max-turns
  --prompt` (sourcing `phenix_setup` first if given).
- **Captures from the session transcript, not stdout.** stdout is only a progress log; the real
  answer is the stored Claude session `.jsonl` under `~/.claude/projects/<encoded-cwd>/`, where
  the cwd path has `/`, `.`, `_` replaced by `-`. `encoded_project_dir` reproduces that encoding;
  `_newest_session` finds the transcript (with a marker-`-newer` fallback);
  `extract_final_assistant_text` pulls the last non-empty assistant message.
- **Defensive:** returns `invocation_ok=False` with an error rather than raising, on timeout,
  nonzero exit, or a missing/empty answer -- one probe never stops the run. Because
  `--auto-approve` lets the agent run tools despite the prose-only ask, capture takes the final
  assistant text regardless of any tool activity in the transcript.

### `judge.py` -- rubric scoring via the Anthropic API
A separate model call (stdlib `urllib`, no SDK). Input: the situation, the rubric features, the
trap, and the raw answer -- **blind to the arm**. Grades by **concept, not keywords** (a feature
is credited under any standard crystallographic synonym / parameter spelling). Returns
`{features:{fid:bool}, evidence:{fid:quote}, feature_fraction, trap_triggered, trap_evidence}`.
`parse_judge_json` tolerates fences/preamble; one retry on malformed JSON, then a clean failure
record (`judge_ok=False`) so a judge miss is recoverable via `rejudge`.

### `runner.py` -- parallel dispatch, crash-safe, resumable
Same shape as `run_all.sh` (job list, skip-done = resume, continue-on-error, tally) with the
Coot serialization replaced by a `ThreadPoolExecutor` of `concurrency` workers (threads suffice
-- each probe is I/O-bound: a subprocess then an HTTP call). Each result is written to
`results.jsonl` **the instant it completes** (locked), so a crash loses at most the in-flight
probes; `load_done` lets a re-run skip everything already complete. `_fresh_dir` suffixes a path
on collision so a re-attempted probe gets clean agent memory. `rejudge` re-scores existing
answers without re-running agents -- cheap, for after a rubric edit.

### `aggregate.py` / `report.py` -- rates and the write-up
`aggregate` groups by `(scenario, arm)` and computes trap rate (`k/N`), mean feature fraction,
and per-feature pass rate; ranks Phase-A scenarios worst-first; and for each Phase-B arm computes
the on-target and off-target trap-rate deltas vs baseline. `report` renders `scores.csv` (one row
per probe) and `report.md`: the ranked failure table, per-scenario detail with example answers
(preferring a trapped rep) and judge evidence, a **judge-reliability spot-check** list (borderline
0.3-0.7 fractions), a **variance** note (split trap outcomes), and the Phase-B effect tables.

### `cli.py` -- entry point
Subcommands `build` (dump prompts, no calls), `run`, `rejudge`, `aggregate`, `all`. Resolves
`scenarios_file` relative to the config so the package is location-independent.

## Design decisions and their reasons

- **Real agent, not an API stand-in.** We test the shipped Expert's decisions, so a probe invokes
  the real `phenix.chat`. The cost (a heavier process per probe) is affordable because there's no
  pipeline -- ~45 s/probe, ~20 min for 150 at 6-wide.
- **Process-per-probe = isolation for free.** Unique cwd path per probe gives an independent agent
  memory with no "reset" hack; it's also what makes parallelism safe.
- **The judge is blind and concept-based.** Blindness stops it manufacturing a Phase-B effect;
  concept-matching stops false negatives from crystallographic synonym variance.
- **Everything is a rate.** One answer is variance-prone; the unit of evidence is `k/N` over reps.
  N=6 screens for large effects; winners get confirmed at higher N.

## Known limitations (see README "Reading results honestly")

- N=6 detects big effects only; subtle ones need more reps.
- Scenario answers are decisions on a *summary*, not on live data -- a screen finding needs a
  live-run confirmation.
- Phase B injects the statement in the `-p` prompt; production folds it into the fixed base
  system prompt -- placement can change potency, so confirm a winner in final form.
- The rubrics are authored, not field-validated; the trap flag is more robust than the per-feature
  scoring, which is why it is the primary signal.
