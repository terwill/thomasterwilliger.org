# Scenario screen — responses for external evaluation

The **Phenix Expert** (phenix.chat agent) was given each scenario below as a text decision question — *"here is a mid-run structure-determination state; what do you do next?"* — with no files and no tools (prose answer only). Each scenario targets a known **trap** (a specific wrong/lazy conclusion). Shown below, per scenario: the situation as given, the trap, the hidden ideal-move rubric, the Expert's **first** response verbatim, and our judge's verdict (trap triggered? / fraction of rubric features present).

**We are asking you to evaluate independently:** for each response, did the Expert (a) avoid the trap, and (b) give a scientifically sound next step a strong crystallographer would endorse? Please flag any response you think is weaker than our judge scored it, any trap you think it actually fell into, and — importantly — whether you think the *scenario itself* is too easy (e.g. it telegraphs the diagnosis a real map would force the Expert to discover). Our judge scored 24/25 at feature-fraction 1.0 and zero traps; we want a skeptical second opinion.

---

## S1 — mine

**Situation given to the Expert:** A 130-residue protein at 2.3 A. AutoBuild placed 118/130; R-work/R-free = 0.21/0.26. There is a break at residues 64-70 (7 residues) between two well-built helices. The 2Fo-Fc map is weak there, with broken, fragmentary density along a plausible main-chain path. What do you do next?

**Trap (wrong conclusion we watch for):** Reports 64-70 as a disordered loop and moves on, with no fill attempt.

**Ideal-move rubric (hidden from the Expert):**
- treats a 7-residue gap between built segments as a buildable loop by default, not disorder
- names a concrete fill tool (phenix.fit_loops, or Coot protein_db_loops then mutate-to-sequence + real-space refine)
- inspects the actual map at those residues, or tries an improved map (post-density-mod, feature-enhanced, prime-and-switch), before judging
- concludes disordered only after a fill attempt fails, and reports the map evidence and what was tried
- does not infer disorder from a blob count or eyeballed span alone

**Our judge's verdict:** trap_triggered = **False**, feature_fraction = **1.0**

**Expert's response (verbatim, first rep):**

> Here's how I'd approach it, and the reasoning behind the order.
> 
> ## First, reframe what the weak density means
> 
> At 2.3 Å a 7-residue loop connecting two helices is a classic candidate for genuine disorder — surface loops are often mobile and simply not visible. But the map here is model-derived: 12 residues are still missing and I shouldn't assume refinement has converged. So the weakness could be (a) real disorder, or (b) an artifact of incomplete phases. I don't yet know which, and I won't force backbone into fragmentary density before finding out — building unsupported atoms inflates the model, hurts geometry, and can nudge R-free the wrong way. The goal is to let the data decide.
> 
> ## Step 1 — Improve the phases before interpreting
> 
> The cheapest, highest-value move is to make the map better rather than build into the current one:
> 
> - Continue/finish `phenix.refine` to convergence (individual XYZ + ADP; at 2.3 Å consider TLS with a few groups), add well-ordered waters, and confirm R-free is still dropping. As the rest of the model tightens, phases improve everywhere, including the gap.
> - Then compute a **bias-reduced map** over 64–70: a composite omit map (`phenix.composite_omit_map`) or a polder/OMIT map that specifically excludes the loop region and its bulk-solvent contribution. Since these residues were never built, a polder map is particularly informative — it tells me whether there's connected main-chain density the flat bulk solvent is currently masking.
> 
> I'd look at that unbiased map before touching the model.
> 
> ## Step 2 — Verify the anchors
> 
> A 7-residue insertion is only as good as its endpoints. I'd confirm the sequence register and geometry of the last well-built residue before the gap (≈63) and the first after (≈71) — correct Cα positions, sensible φ/ψ, density that matches the assigned side chains. If an anchor is misregistered, no loop build will be right.
> 
> ## Step 3 — Attempt an automated, density-guided build
> 
> If the improved/omit map shows a plausible connected path, I'd let the software thread it rather than hand-place atoms into ambiguous density:
> 
> - `phenix.fit_loops`, which uses the sequence and the two anchors to build the missing residues into density, or a targeted `phenix.autobuild` rebuild-in-place over that stretch.
> - If only the backbone path is supported and side chains aren't resolved, keep it as the correct sequence but expect to truncate side chains (or set them to low/zero occupancy) rather than invent rotamers.
> 
> ## Step 4 — Validate by measurement, then decide
> 
> After any build, re-refine and compare **before/after**: R-work/R-free deltas, local geometry (Ramachandran, clashes for 64–70), real-space CC / map-model correlation for those residues, and ADPs (a loop refining to very high B relative to its neighbors is telling me it's barely there). A build that lowers R-free and shows reasonable local CC and B-factors is real; one that raises R-free or produces outlier geometry and runaway B's is not supported.
> 
> ## Step 5 — Accept disorder if the data don't support it
> 
> If the omit map stays broken after phase improvement and automated fitting can't place backbone with acceptable geometry/CC, the honest outcome is to **leave 64–70 unmodeled** (a disordered loop) rather than build into noise. I'd note the gap explicitly. This is a legitimate, common result at this resolution — and I'd re-audit the region after any later map improvement, since a feature invisible now can become clear as the model completes.
> 
> Net: improve phases → look at an unbiased/omit map → build only what density genuinely supports (preferably with `fit_loops`) → confirm with a re-scored R-free and local map-model CC → otherwise leave it disordered.

---

## S2 — mine

**Situation given to the Expert:** A 1.9 A structure has converged at R-work/R-free = 0.24/0.29 after three macrocycles. The R-work/R-free gap is 0.05. MolProbity clashscore 12, Ramachandran favored 94%, 3 rotamer outliers. The user asked for a deposition-ready model. Do you stop here, and if not, what specifically do you do?

**Trap (wrong conclusion we watch for):** Declares converged / deposition-ready and stops; or chases R-free by adding waters into noise or loosening the test set.

**Ideal-move rubric (hidden from the Expert):**
- recognizes R-free 0.29 at 1.9 A is high for the resolution and not done
- diagnoses before acting: reads the R-work/R-free gap, the outliers, and the difference map
- proposes evidence-tied next steps (fix rotamer outliers, address clashes, look for unmodeled solvent/ligand, reconsider ADP/TLS or weights), not just more macrocycles
- distinguishes converged (numerically stable) from as-good-as-the-data-support
- refuses to lower R-free by overfitting (waters into noise, test-set manipulation)

**Our judge's verdict:** trap_triggered = **False**, feature_fraction = **1.0**

**Expert's response (verbatim, first rep):**

> No — I would not stop. Several numbers say this model still has interpretable problems, and at 1.9 Å the data can support a substantially better model.
> 
> **Why it's not done**
> 
> - **R-free ≈ 0.29 at 1.9 Å is high.** For a well-behaved 1.9 Å structure you'd typically expect R-free in the low 0.20s. A value of 0.29 signals unmodeled features, mis-modeled regions, or a suboptimal refinement strategy — not a converged, deposition-ready model. (The 0.05 R-work/R-free gap itself is unremarkable at this resolution; the problem is the absolute R-free.)
> - **Ramachandran favored 94%** is below what 1.9 Å should give (you'd want ≳97–98% favored, near-zero outliers). 94% favored implies real outliers to inspect.
> - **Clashscore 12** is mediocre; at this resolution single digits are achievable.
> - **3 rotamer outliers** are individually fixable.
> 
> "Converged after three macrocycles" only means refinement stopped moving — it does not mean the model is right. So the goal now is to find what the R-free and geometry are pointing at.
> 
> **What I'd do, in order**
> 
> 1. **Check the data first, not just the model.** Before chasing the model I'd confirm the R-free isn't being inflated by a data pathology — run/look at xtriage output for twinning, pseudotranslation, anisotropy, and ice rings, and confirm the resolution cutoff and the R-free flag set are sane (and that the flags were never regenerated during refinement). A missed twin law, for example, would explain an R-free stuck near 0.29 and would change the refinement target rather than the model.
> 
> 2. **Read the validation in detail, not just the summary numbers.** Run a full MolProbity/validation pass and get the per-residue lists — Ramachandran outliers, rotamer outliers, clashes, Cβ deviations, CaBLAM, and bond/angle RMSD/RMSZ. That tells me whether the R-free comes from a few bad regions or is diffuse.
> 
> 3. **Inspect difference density where the model is weak.** Compute/examine the 2mFo–DFc and mFo–DFc maps. Look specifically for: green (positive) mFo–DFc peaks that are unmodeled solvent, ions, or ligand; red peaks over atoms that shouldn't be there or are in the wrong place; backbone that needs a peptide flip or register shift; and alternate conformations, which at 1.9 Å are often justified and are a common hidden contributor to elevated R-free. I'd treat ion/ligand identity as provisional and confirm with a bias-reduced (polder/omit) map before committing.
> 
> 4. **Fix the flagged geometry by rebuilding into density,** not by tightening restraints. Real-space fit the rotamer outliers and Ramachandran outliers, resolve clashes, and add alt confs where the density supports them. Physical realism first — I won't push geometry to chase R-free.
> 
> 5. **Audit the solvent model.** Under- or over-built water is a classic driver of R-free at ~1.9 Å. Check that waters have real density and reasonable coordination, and that plausible ions haven't been mis-modeled as water.
> 
> 6. **Revisit the refinement strategy.** At 1.9 Å, individual ADPs are appropriate; I'd also test TLS (with sensible groups), confirm ordered-solvent updating, and make sure automatic weight optimization is on so geometry weights aren't arbitrarily loose or tight. Then re-run several macrocycles.
> 
> 7. **Re-measure, report the delta, iterate.** After each build+refine round I'd report before/after R-work/R-free, clashscore, Ramachandran, rotamers, and geometry RMSD from the actual logs — verifying by measurement, never by eye — and loop until R-free and validation plateau and the difference map is clean.
> 
> **When I'd call it deposition-ready:** R-free consistent with 1.9 Å (roughly low-0.20s) with a modest gap, Ramachandran favored ≳97–98% with no outliers, clashscore in the low single digits, no rotamer outliers without density justification, and no significant unexplained difference peaks. Only then would I move to the deposition workflow (table one, mmCIF).
> 
> One caveat: I'm reasoning from the summary numbers you gave, not the files. The single most important next check is the data/xtriage step — if there's a twin or other pathology, it reframes everything above.
> 
> If you point me at the reflection file and model, I'll start with xtriage and a full validation run and report the actual numbers.

---

## S3 — mine

**Situation given to the Expert:** A 2.0 A structure with complete main chain (128/128 residues) but 15 surface side chains truncated to stubs by AutoBuild because their density was weak. R-free 0.24. What do you do?

**Trap (wrong conclusion we watch for):** Leaves all 15 as disordered side chains, no completion attempt.

**Ideal-move rubric (hidden from the Expert):**
- recognizes 2.0 A generally supports side chains, so truncation is a to-do not a verdict
- names the concrete tool (phenix.fill_partial_residues / real-space rotamer fit, then refine)
- inspects density per residue, completes those with density, and labels only the genuinely-absent ones explicitly
- verifies by measurement (per-residue map CC / rotamer status / R-free before-after), not by eye

**Our judge's verdict:** trap_triggered = **False**, feature_fraction = **1.0**

**Expert's response (verbatim, first rep):**

> Short version: I would **not** rebuild the 15 side chains just to make the model "look complete." AutoBuild truncated them for a legitimate reason, and the governing principle is to model only what the data support. But I also wouldn't leave the question there — at 2.0 Å most side chains should be orderable, and the map I'm judging them against right now is not yet the best map I can make. So the plan is: improve the map, judge each stub in a bias-reduced map, rebuild only what's genuinely supported, and confirm by measurement.
> 
> **1. Converge refinement before judging anything.** After AutoBuild the model usually isn't fully refined. I'd run `phenix.refine` to convergence with a sensible 2.0 Å strategy (individual XYZ + individual ADP, TLS groups for the domains, add ordered solvent), keeping the existing R-free flags untouched and working on a copy. Phases — and therefore the map — improve as the model improves in X-ray, so weak surface density is often under-represented until the bulk model is settled and waters are placed. R-free 0.24 at 2.0 Å is a little high; the 15 stubs are almost certainly not the main driver, so I also want to see whether waters, ADP/TLS model, or an unmodeled solvent/ligand feature is holding R-free up.
> 
> **2. Look at the stubs in a bias-reduced map, not the standard 2mFo–DFc.** Because these atoms were deleted by AutoBuild, the ordinary map is biased toward their absence. I'd compute a composite OMIT map (`phenix.composite_omit_map`) so I'm judging the missing atoms honestly, and I'd also inspect the mFo–DFc difference map for positive peaks along the expected side-chain path.
> 
> **3. Decide residue by residue.** For each of the 15:
> - If the OMIT/2mFo–DFc density at ~1σ traces the side chain (or clear green mFo–DFc peaks appear), rebuild the atoms — into the best-supported rotamer, and as an alternate conformation or with partial occupancy if the density is split or weak.
> - If density stops at Cβ/Cγ, leave it truncated. Modeling atoms into noise adds scattering that isn't there, degrades geometry, and misrepresents genuine surface disorder — a worse outcome than an honest stub. Truncated side chains are perfectly acceptable to the PDB.
> 
> **4. Re-refine and verify the delta.** After any rebuilding, re-refine and check R-work/R-free (rebuilt real density should help or at least not hurt R-free) and run MolProbity — the rebuilt residues must not introduce rotamer outliers or clashes. If a rebuild raises R-free or adds outliers, that atom wasn't supported; revert it.
> 
> **5. Re-audit after the map improves.** Because the map is a moving target, I'd re-check both the rebuilt and the still-truncated residues after solvent/TLS refinement. A side chain invisible now can sharpen up later — "not resolvable yet" is different from "absent."
> 
> The mindset throughout: completeness is not the goal, correctness is. I'd rather deposit 15 honest stubs than 15 fabricated side chains that improve a cosmetic completeness number while misrepresenting what the 2.0 Å data actually show.

---

## S4 — mine

**Situation given to the Expert:** Molecular replacement with a 40%-identity homolog gave a clear solution (TFZ 9, LLG 250) for a 200-residue protein at 2.5 A. After one round of refinement R-work/R-free = 0.34/0.38 and stuck. The model still carries the homolog's sequence in places and several loops that don't match the target. What's your next move?

**Trap (wrong conclusion we watch for):** Keeps refining the placed model, or concludes data limited, without rebuilding to the target.

**Ideal-move rubric (hidden from the Expert):**
- reads R-free 0.38 after distant-homolog MR as needs-rebuilding, not more refinement and not a data limitation
- identifies homolog side chains + non-matching loops as the cause (sequence/register must be corrected)
- names a concrete rebuild action (phenix.autobuild rebuild / rebuild-in-place, or morph-then-rebuild), correcting register vs map+sequence
- checks the map for register anchors (bulky residues in density) rather than trusting the placed sequence

**Our judge's verdict:** trap_triggered = **False**, feature_fraction = **1.0**

**Expert's response (verbatim, first rep):**

> ## Diagnosis first
> 
> R-work/R-free of 0.34/0.38 that won't budge at 2.5 Å, on a model that still carries homolog sequence and non-matching loops, is the classic signature of **model bias + an incomplete/incorrect model** — not a refinement-strategy problem. The ~0.04 R-work–R-free gap is actually reasonable; the issue is that *both* numbers are high because a substantial fraction of atoms are in the wrong place or are the wrong atom. More refinement macrocycles cannot fix wrong sequence or misplaced loops — refinement only relaxes within the current basin, so you're stuck in a local minimum. The move is to **rebuild**, not to re-refine harder.
> 
> ## Before rebuilding — two quick integrity checks
> 
> - **Run xtriage on the data.** At this stage you want to rule out twinning, translational pseudo-symmetry, or severe anisotropy, any of which independently inflates R and would change how you interpret "stuck." This is a one-shot, cheap check and it conditions everything downstream.
> - **Confirm the R-free set is intact.** Verify the flags were carried through MR and refinement unchanged — never let a rebuild regenerate or re-randomize them, or cross-validation is compromised. Work on copies of the MR solution throughout.
> 
> ## The rebuild plan
> 
> 1. **Get the sequence right.** The model must carry the *target* sequence, not the homolog's. Everywhere the homolog differs, don't leave wrong side chains sitting in the map — they bias the phases. The cleaner approach is to trim mismatched side chains back to Cβ/poly-Ala and **delete the loops that don't match the target** entirely, rather than force-fitting them.
> 
> 2. **Reduce model bias in the map.** Compute a composite OMIT map (or use Phaser's LLG-weighted / feature-enhanced maps) so you're judging the questionable loops against density the deleted atoms didn't contribute to. This is what lets you honestly tell "real density we haven't built into" from "phase bias echoing the homolog."
> 
> 3. **Automated rebuild from the MR solution.** This is exactly the job for `phenix.autobuild` in rebuild mode — starting from the placed model plus the correct target sequence, it iterates build/refine with density modification and bias-reduced maps, correcting the register-independent side-chain identities and rebuilding loops into real density. That typically breaks the R-free plateau in one job. I'd load the model-building skill and set it up rather than run it ad hoc.
> 
> 4. **Manual repair + real-space fit** for whatever autobuild leaves as gaps — rebuild the remaining loops by hand into the OMIT density.
> 
> 5. **Then refine, with a strategy matched to 2.5 Å:** individual XYZ + individual isotropic B, riding hydrogens, and NCS restraints if there's more than one copy in the ASU. Save TLS/finer ADP treatment for after the model is chemically correct.
> 
> ## Why this order
> 
> At 2.5 Å with a genuinely clear MR solution (TFZ 9, LLG 250 is unambiguous), the placement is trustworthy — so the register is likely fine and the problem is sequence identity and loop conformation. Fixing those is a *building* task. Watch R-free as the arbiter: it should drop meaningfully once the correct sequence is in and the wrong loops are gone. And keep physical realism first — build loops only where the OMIT density actually supports them; leave them out where it doesn't, rather than chasing a marginally lower R-free with atoms the data don't justify.
> 
> If you'd like, tell me the file names and I can set up xtriage and the autobuild rebuild.

---

## S5 — mine

**Situation given to the Expert:** A 1.6 A structure refines to R-work/R-free = 0.19/0.22 with clean Ramachandran and rotamers. There is a strong (5 sigma) positive Fo-Fc peak in the active site, roughly the size and shape of a small molecule; the crystal was grown with a known inhibitor in the buffer. Is the model finished? If not, what do you do?

**Trap (wrong conclusion we watch for):** Reports finished and ignores the peak; or drops a water into obvious ligand density.

**Ideal-move rubric (hidden from the Expert):**
- does not declare finished; a 5 sigma Fo-Fc peak is unmodeled signal that must be explained
- connects the peak to the known inhibitor (buffer context) as the leading hypothesis
- names a concrete action (generate ligand restraints via eLBOW/ReadySet, fit + real-space refine, confirm with polder/omit map)
- distinguishes ligand from water/ion by size/shape/coordination, not just a water
- verifies occupancy/B-factor and map fit after building

**Our judge's verdict:** trap_triggered = **False**, feature_fraction = **1.0**

**Expert's response (verbatim, first rep):**

> No — the model is not finished. A 5 σ positive Fo–Fc peak the size of a small molecule is, by definition, ordered scattering matter that your model does not account for. Good R-factors, Ramachandran, and rotamers describe the protein you *did* build; they say nothing about the feature you *didn't*. Leaving that density unmodeled is both incomplete and a small systematic error dragging on the phases and the surrounding solvent.
> 
> That said, "an inhibitor was in the buffer" is a hypothesis, not evidence. The discipline here is to prove what the density is before committing atoms to it. Here is what I'd do and why.
> 
> **1. Interpret the peak provisionally, not from expectation.** At 1.6 Å the map is mature enough to trust shape, so I'd inspect the peak in Coot against both the Fo–Fc and 2Fo–Fc maps. Key questions: does the peak's size, shape, and branching actually match the inhibitor's connectivity, or could it be explained by more mundane occupants — ordered waters, a buffer/cryoprotectant molecule (glycerol, PEG, sulfate, phosphate, acetate), or a metal/anion from the crystallization mix? A single spherical peak with octahedral waters around it is an ion, not a drug. The active-site chemistry (nearby charged residues, coordinating geometry, plausible H-bonds/contacts) should be consistent with the inhibitor before I accept it.
> 
> **2. Confirm with a bias-reduced map.** Because I want to rule out model bias from the density I'm about to build into, I'd compute a polder OMIT map (`phenix.polder`) over the active-site region — polder excludes bulk solvent from the omitted volume, which is exactly the situation for a small molecule sitting in a partly solvent-exposed pocket. If the ligand density persists strongly with nothing built there, that's real, bias-free support for placing it. A composite OMIT map is the alternative if I'm worried about the whole-model bias.
> 
> **3. Generate proper restraints.** Before fitting, I'd build geometry restraints for the inhibitor from its known chemistry (`phenix.elbow` from a SMILES string or coordinate file, ideally checked against the published/ideal geometry). Fitting a ligand without a correct restraint dictionary is how you get a chemically wrong molecule that "refines fine."
> 
> **4. Fit, then refine, then measure.** Place the ligand into the density (real-space fit in Coot, or `phenix.ligandfit`), then run `phenix.refine` including the new restraints, refining occupancy and individual B-factors. At 1.6 Å I can afford this. Then I judge success by *measurement*, not eye: does the Fo–Fc peak clear (no residual positive density where I added atoms, no negative density saying I over-built)? Do the ligand's real-space CC and B-factors match the surrounding protein? Do R-work/R-free drop, or at least not rise? I'd report the before/after delta explicitly.
> 
> **5. Validate the addition.** Check for clashes with protein, sensible contacts, and that the occupancy/B-factor combination is physically reasonable (a refined occupancy well below 1.0 with high B may mean partial binding — worth noting, not forcing to full occupancy). Watch the R-free specifically; if it doesn't respond, the ligand identity or placement is suspect.
> 
> **Calibrated conclusion:** treat the inhibitor as the leading candidate but keep the assignment provisional until the OMIT map, the fit quality, and the residual-density check all agree. If the shape doesn't fit the inhibitor, follow the density to what does — an ordered water cluster, a buffer molecule, or an ion — rather than building the answer you expected. Only once the peak is explained by a chemically sensible, well-supported model, with the difference density flat and validation clean, is the model finished.

---

## S6 — phasing

**Situation given to the Expert:** SAD data at 2.6 A. phenix.autosol found a heavy-atom substructure in P4(1)2(1)2. The experimental map shows clear solvent channels, but autobuild docked only 15% of the sequence and R-free sits at 0.53 and won't drop. What do you do next?

**Trap (wrong conclusion we watch for):** Declares the data unphasable / data-limited; keeps refining the 15% model.

**Ideal-move rubric (hidden from the Expert):**
- raises the enantiomorph (P4(3)2(1)2) as a candidate cause of an unbuildable-but-channeled map
- either proposes testing the other hand or confirms whether autosol already evaluated both hands (credit both)
- checks map hand via helix handedness / secondary structure
- does not conclude data-limited without addressing hand

**Our judge's verdict:** trap_triggered = **False**, feature_fraction = **0.75** (missing sub-features noted)

**Expert's response (verbatim, first rep):**

> ## Diagnosis first — what R-free 0.53 with a channeled map is telling you
> 
> R-free of 0.53 that won't move is effectively random: refinement is not improving because the model is mostly wrong, not because the strategy is off. But "clear solvent channels" is genuinely encouraging — a wrong-hand or wrong-space-group experimental map usually looks like featureless noise, whereas a defined solvent boundary means your phases are good enough to see the *envelope* but not yet good enough to *trace chain*. That combination — interpretable solvent, uninterpretable protein — points to marginal phase quality and/or a build that was given the wrong assumptions, not necessarily a failed experiment. So I would not refine further against this model, and I would not treat 15% as a starting point to grow from. I'd step back and verify the phasing before building anything else.
> 
> ## What I'd check, in order, and why
> 
> **1. Read the AutoSol log for the numbers, not the impression.** I want the figure of merit, the estimated map quality (AutoSol's Bayesian map CC / BAYES-CC), the skew/connectivity score, how many sites it placed and at what occupancy, and — critically — **which hand it chose and whether it scored both enantiomorphs.** SAD phasing is intrinsically hand-ambiguous, and in this point group the pair is P4₁2₁2 ↔ P4₃2₁2 (plus the substructure hand). If the two hands scored close, the "solvent channels" could be coming from the wrong one. A low BAYES-CC (say ≲25–30) tells me the ceiling is phasing quality, and building was never going to work until the map improves.
> 
> **2. Confirm the anomalous signal is real to a usable resolution (xtriage).** I'd look at measurability, anomalous CC between half-sets, and d″/σ as a function of resolution. At 2.6 Å the signal may only extend to ~3.5–4 Å; if so, the substructure is fine but the phasing power is limited, which is fully consistent with a channeled-but-untraceable map. This also tells me the resolution to which density modification and phase extension can honestly reach.
> 
> **3. Check the Matthews coefficient / copy number and the sequence file.** Only 15% docked is a red flag for a copy-number or sequence mismatch. If the ASU actually holds multiple copies and AutoBuild built into one poorly while missing NCS, or if the sequence given doesn't match, building stalls regardless of map quality. I'd reconcile the expected molecular weight, solvent fraction (the visible channels suggest fairly high solvent), and number of copies. High solvent content is good news for density modification.
> 
> ## What I'd actually do next
> 
> **4. Nail down the hand.** If the log shows AutoSol didn't decisively separate the enantiomorphs, I'd generate maps for both hands / both space-group enantiomorphs and compare connectivity and solvent flatness directly. Building into the wrong hand is the single most common way to get exactly this symptom, and it's cheap to rule out.
> 
> **5. Improve the map before touching the model again.** Run density modification (RESOLVE / resolve density modification) with the correct solvent fraction, and turn on NCS averaging if there is more than one copy — that is often where a marginal SAD map becomes traceable. Phase extension to the full 2.6 Å where the native signal supports it.
> 
> **6. Then rebuild against the improved map — and bring in an AlphaFold model.** Rather than trusting de novo AutoBuild that already stalled, at 2.6 Å with a defined envelope the high-percentage move is to dock a predicted model into the experimental (density-modified) map — `phenix.dock_predicted_model` or `phenix.predict_and_build` seeded with the experimental phases (and `process_predicted_model` to trim by pLDDT first). A correctly placed, confidence-trimmed AlphaFold model docked into a real experimental map typically breaks through exactly this kind of AutoBuild stall, and gives an honest cross-check: if it docks into density and R-free drops sharply, your hand and space group are right.
> 
> ## The decision logic
> 
> The one thing I would *not* do is keep refining or keep re-running AutoBuild on the current 15% model hoping R-free falls — a 0.53 that "won't drop" is a signal to fix phasing/hand/copies upstream, not to push harder downstream. The branch point is the map-quality metrics and the hand test: if BAYES-CC is decent and one hand is clearly better, the fix is density modification + model docking; if the signal is weak or the hands are ambiguous, the fix is upstream in the experimental phasing itself.
> 
> I'd load the `phenix-phasing-experimental` and `phenix-data-quality` skills to pin the exact parameters, and `phenix-predicted-models`/`phenix-docking` for the AlphaFold route. Every number I've referenced (FOM, BAYES-CC, measurability, Matthews) I'd read from the actual logs before acting — the above is the reasoning I'd apply once I see them.

---

## S7 — phasing

**Situation given to the Expert:** A 2.1 A dataset in space group P3(1), refined against a complete model with excellent geometry (clashscore 2, Ramachandran 98%). R-work/R-free stuck at 0.29/0.34. xtriage reports the L-test statistic <|L|> at 0.40. What do you do next?

**Trap (wrong conclusion we watch for):** Blames model errors/incompleteness; keeps adding solvent or editing coordinates.

**Ideal-move rubric (hidden from the Expert):**
- reads <|L|> = 0.40 as a twinning indicator (untwinned 0.5, perfect twin 0.375)
- attributes the high R with clean geometry to a data effect, not a model defect
- either enables twin refinement (twin_law in phenix.refine) or questions whether the point group/symmetry was over-assigned (credit both)
- re-reads R only after addressing the data issue

**Our judge's verdict:** trap_triggered = **False**, feature_fraction = **1.0**

**Expert's response (verbatim, first rep):**

> ## The diagnosis first
> 
> The pattern you describe is the textbook fingerprint of **unmodeled merohedral twinning**, not a model problem:
> 
> - For an untwinned acentric dataset, the Padilla–Yeates statistic <|L|> ≈ **0.5**. For a perfect (twin fraction 0.5) merohedral twin it drops to ≈ **0.375**. Your value of **0.40** sits close to the perfect-twin limit, implying a large twin fraction.
> - **P3₁ is a prime candidate** — point group 3 (Laue -3) has merohedral twin operators available that make the lattice mimic higher apparent symmetry.
> - Twinning *lowers* <|L|>; translational NCS and anisotropy push it the *other* way (toward or above 0.5). So 0.40 points cleanly at twinning rather than at tNCS or anisotropy masking something.
> - R-work/R-free **stuck near 0.29/0.34 despite excellent geometry** (clashscore 2, Rama 98%) is the classic signature: the model is fine, so the residual is coming from how the intensities are being treated, not from the atoms. Untwinned refinement of a genuinely twinned crystal characteristically plateaus around R ≈ 0.30 (roughly ~2× the twin fraction offset).
> 
> ## What I'd do next, in order
> 
> **1. Re-read the full xtriage output before touching refinement.** I want the specific things the <|L|> summary alone doesn't give me:
> - The **twin law(s)** xtriage lists for P3₁ (e.g. a two-fold that maps the reflections), and
> - The **twin-fraction estimates** from the Britton plot, the H-test, and the ML method — do they agree, and is the fraction well above ~0.05?
> - The **N(Z) cumulative-intensity** and <I²>/<I>² curves for corroboration, plus a check for an off-origin Patterson peak (tNCS), which changes how the L-test should be read.
> 
> **2. Rule out the "wrong space group" alternative before committing to twin refinement.** Apparent merohedral twinning in P3₁ can also be a symptom of a *misassigned* space group — the true symmetry may be higher (e.g. P3₁21/P3₂21) or you may be in the wrong enantiomorph (P3₁ vs P3₂). This matters because if it's really higher symmetry, reprocessing/reindexing fixes the R-factors *without* any twin law, whereas imposing a twin law on already-correct symmetry is wrong. I'd check xtriage's space-group suggestions (and would want the reindexing/pointless-style analysis from data processing). If higher symmetry is real, that's the fix; if the systematic absences and merging genuinely support P3₁, then it's true twinning.
> 
> **3. If twinning is confirmed, re-refine in `phenix.refine` with the twin_law** reported by xtriage (working on a copy, not overwriting the current model/data). If twinning is the culprit, R-work/R-free should drop substantially — this is the measurement that confirms the diagnosis. I'd report the before/after delta rather than declaring success from the geometry.
> 
> **4. Guard against being fooled, and protect cross-validation.** Two cautions:
> - Twin refinement can lower R-factors somewhat artificially, so I'd confirm the improvement is real by checking that maps and geometry stay clean — not chase R alone.
> - With twinning, twin-related reflections ideally belong to the *same* R-free set; otherwise the free set is partially "seen" through its twin mate and the gap is misleadingly small. I would **not** regenerate or re-randomize the existing R-free set. If it was built as a simple random set, I'd note that the cross-validation is somewhat compromised under twinning and interpret R-free cautiously, rather than rebuild it and destroy the flag continuity.
> 
> ## Bottom line
> The excellent geometry tells you the model isn't the problem; the <|L|> = 0.40 in a P3₁ crystal tells you the intensities almost certainly carry a large merohedral twin fraction. Confirm the twin law and fraction in xtriage, exclude a space-group/enantiomorph misassignment, then re-refine with the twin law and let the R-free drop verify the diagnosis. Would you like me to pull up the xtriage report and confirm the twin law and fraction so we can set up the twin refinement?

---

## S8 — refinement

**Situation given to the Expert:** Refining a 2.2 A structure. Residues 45-60 are built as a beta-strand; global R-free 0.26. Along the strand there is a persistent alternating positive/negative Fo-Fc pattern at every side-chain position. The main chain fits density, but Tyr52's ring is jammed into a narrow pocket while neighbouring Val53 sits in a large empty bulb of positive density. What do you do next?

**Trap (wrong conclusion we watch for):** Edits individual rotamers or real-space refines the strand while it stays out of register.

**Ideal-move rubric (hidden from the Expert):**
- reads alternating side-chain +/- difference density along a continuous backbone as a register shift, not independent rotamer errors
- identifies the direction (Tyr must shift toward the Val53 bulb)
- proposes shifting the sequence assignment by 1-2 residues and rebuilding
- re-checks the local Fo-Fc to confirm the alternation clears

**Our judge's verdict:** trap_triggered = **False**, feature_fraction = **1.0**

**Expert's response (verbatim, first rep):**

> ## Diagnosis first — this reads as a sequence-register error, not a refinement problem
> 
> A persistent, *alternating* positive/negative Fo–Fc pattern at **every** side-chain position along a contiguous strand, with the main chain fitting well, is the textbook signature of the side chains being systematically offset from their true positions. The clincher is the mismatch you describe: a bulky Tyr crammed into a pocket too small for it, and a small Val sitting in a large empty bulb that clearly wants a bigger side chain. That is not something you fix with weights, B-factors, occupancies, or alt confs — the chemistry is in the wrong place. So before touching refinement strategy, I'd treat this as a register (or possibly directionality) error in 45–60 and confirm it, rather than continuing to refine a wrong model into a lower R-free.
> 
> ## Confirm and pin down the shift
> 
> 1. **Reduce model bias before I trust the density.** At 2.2 Å register is resolvable, but the current map is phased by the wrong side chains. I'd compute a composite OMIT or a local OMIT map over 45–60 so the positive bulbs and negative peaks aren't biased by what's modeled.
> 
> 2. **Get per-residue numbers, not an eyeball.** Real-space CC / map-model CC per residue across 45–60 should be uniformly poor for side chains but decent for main chain — consistent with register, and it brackets exactly where the bad stretch starts and stops.
> 
> 3. **Find anchor landmarks in the true sequence.** I'd pull the actual sequence for 45–60 and look for unambiguous pins — a Trp/Phe/Tyr (large density lobe), Gly (no side chain / backbone conformation), Pro (kinked backbone), Cys near a partner. These tell me *which way* and *by how much* to shift so the aromatics land in the large empty bulbs and the small residues fall into the tight pockets.
> 
> 4. **Decide the direction and magnitude.** On a β-strand, side chains alternate faces, so a shift of ±1 flips every side chain to the opposite face while ±2 keeps the same face — the observed alternating +/- helps distinguish these. I'd also explicitly test whether the strand was built **backwards** (N→C reversed), which produces a similar systematic mismatch; the backbone carbonyl directions and any Pro/Gly landmark settle that.
> 
> 5. **Look for the root cause.** A register slip usually starts at a missing or extra residue, or a mis-modeled loop, at one end of the strand. I'd check the flanking residues (before 45, after 60) to find where the correct register resumes, so I fix the *cause* and don't just smear the error.
> 
> ## Fix
> 
> Re-thread the sequence through the fixed backbone — physically move the register by the amount the landmarks dictate (or reverse the strand if that's the problem), rebuilding side chains into the density. I'd **anchor** the rebuild at the first correctly-registered residue on each side so the shift isn't propagated into neighboring secondary structure, then let the corrected fragment relax with local real-space refinement / a round of refinement.
> 
> ## Verify by measurement
> 
> Re-refine and recompute Fo–Fc and per-residue CC over 45–60. If the diagnosis was right, the alternating difference peaks collapse, Tyr52 (or wherever the aromatic truly belongs) fills the large bulb, the small residues fit the tight pockets, and per-residue CC rises. Global R-free should tick down, but I'd judge the fix on the *local* map and geometry — not on R-free alone, since the whole point is that a wrong model can be refined to a deceptively decent global number. I'd report the before/after difference-map state and per-residue CC as the evidence the register is now correct.
> 
> One caution on confidence: I'd hold the exact shift provisional until the OMIT map and a distinctive landmark residue agree — register direction is precisely the kind of consequential assumption worth confirming rather than asserting.

---

## S9 — refinement

**Situation given to the Expert:** In a 1.8 A refinement, loop residue Leu84 is a severe Ramachandran outlier. The main chain fits 2Fo-Fc at 1 sigma, but a clear 4 sigma positive Fo-Fc peak points opposite the current carbonyl O, with a negative peak on the O itself. What do you do next?

**Trap (wrong conclusion we watch for):** Ignores the outlier because the main chain is in the 2Fo-Fc cage; forces it favored with harsh restraints.

**Ideal-move rubric (hidden from the Expert):**
- reads the opposed +/- peaks on the carbonyl as a peptide flip
- names the tool (Coot peptide flip / backbone dihedral)
- real-space refines so the O satisfies the positive peak
- confirms the Ramachandran flag clears

**Our judge's verdict:** trap_triggered = **False**, feature_fraction = **1.0**

**Expert's response (verbatim, first rep):**

> ## Diagnosis first
> 
> This is the textbook signature of a **misoriented backbone carbonyl — a peptide flip**, not a mistraced loop. Three observations converge:
> 
> - A **severe Ramachandran outlier** localized to one residue in a flexible loop.
> - Main chain that already sits in 2Fo-Fc, so the Cα trace is essentially right — the *connectivity* is correct.
> - A **positive Fo-Fc peak opposite the carbonyl O with a matching negative peak on the O itself** — the difference map is telling you the oxygen is modeled pointing the wrong way and wants to be ~180° across.
> 
> The peptide unit spanning Cα(84)–C(84)=O···N(85) is rotated roughly 180° from where the density wants it. Flipping it changes ψ84 (and φ85), which is exactly the dihedral driving the Ramachandran outlier. At 1.8 Å the carbonyl orientation is genuinely resolved by the data, so I'd trust this signal rather than rationalizing the outlier as "just a strained loop." I'd also expect CaBLAM to flag this same peptide, which is worth checking as independent corroboration.
> 
> ## What I'd do
> 
> 1. **Work on a copy of the model** — never edit the deposited/input coordinates in place.
> 2. **Flip the peptide** between Leu84 and residue 85 (the Coot "pep-flip" tool, or ISOLDE, is the natural place; equivalently edit the ω/carbonyl and let refinement settle it). Confirm I'm flipping the Leu84 carbonyl specifically, since that's the peptide whose ψ produces the outlier.
> 3. **Local real-space regularization** of the flipped zone against the map to relieve any strain introduced, then a **full reciprocal-space refinement** (`phenix.refine`) so the change is evaluated globally against the R-free set — which I would *not* regenerate or extend.
> 
> ## How I'd confirm it worked (measurement, not eye)
> 
> I'd re-run validation and read the numbers, comparing before/after:
> 
> - **Ramachandran**: Leu84 should move from outlier into favored/allowed.
> - **Difference map**: both the +4σ and the negative peak at the carbonyl should flatten — that's the direct proof the O is now correctly placed.
> - **2Fo-Fc**: the carbonyl O should sit in density.
> - **R-work/R-free**: should be unchanged-to-slightly-improved globally, with local map-model agreement better. If R-free worsened I'd stop and reconsider.
> - **Clashscore / neighboring residues**: check the flip didn't introduce a clash or push residue 85 out.
> 
> ## Caveats
> 
> If flipping *doesn't* clear the difference peaks, or the surrounding density is broken, the problem may be larger than one carbonyl — a register/rotamer error or a genuinely mistraced loop — and I'd step back to rebuild the segment rather than force the flip. I'd also sanity-check it isn't a *cis*-peptide or an alternate conformation before committing. But given the clean, localized dipole of positive/negative density opposite the O plus the single-residue outlier, a peptide flip is the high-confidence first move.

---

## S10 — refinement

**Situation given to the Expert:** A 2.3 A structure at R-work/R-free = 0.21/0.26, fully built. To push R-free down, ordered solvent placed 45 waters into 2.2 sigma peaks. R-free drops to 0.255, but 12 of these waters now have B-factors above 75 while the average protein B is 32. What do you do next?

**Trap (wrong conclusion we watch for):** Accepts the lower R-free and keeps all the waters.

**Ideal-move rubric (hidden from the Expert):**
- flags waters with B far above the local protein B as refining into noise
- names it micro-overfitting (small R-free gain for lost realism)
- prunes waters lacking spherical 2Fo-Fc density at ~1 sigma or with runaway B
- sets a conservative solvent peak threshold for the resolution

**Our judge's verdict:** trap_triggered = **False**, feature_fraction = **1.0**

**Expert's response (verbatim, first rep):**

> The short version: I would not bank that 0.005 R‑free drop. A B of 75 against an average protein B of 32 at 2.3 Å is a red flag that a chunk of those 45 waters are fitting noise rather than ordered solvent, and lowering R‑free by adding poorly‑supported atoms is exactly the trade I don't want to make. Here's how I'd work through it.
> 
> **1. Separate real from cosmetic gain.** First I'd look at how R‑work moved alongside R‑free. A 0.005 R‑free improvement is small and near the noise of a single refinement run; if R‑work dropped substantially more than R‑free, that widening gap is a signature of overfitting, not of a better model. The 0.21/0.26 spread was already a normal ~0.05 gap for 2.3 Å, so there isn't much legitimate solvent-driven headroom to chase.
> 
> **2. Audit the 12 high‑B waters individually, on evidence.** For each I'd check, from the maps and geometry:
> - Is there real **2Fo‑Fc density** at the site after refinement (not just the original difference peak)? A water that refines to B=75 usually has faint-to-absent 2Fo‑Fc density — the refinement is spreading it out to explain nothing.
> - Is there a **hydrogen‑bond partner** at 2.4–3.5 Å (protein donor/acceptor or another water)? A water with no plausible H‑bond partner and no coordination is almost certainly spurious.
> - Does the B **balloon** relative to its neighbors, and is occupancy dropping? Diffuse B plus low occupancy = not an ordered water.
> 
> **3. Reconsider the placement threshold.** Picking peaks at 2.2σ is permissive — below the ~3σ Fo‑Fc cutoff that ordered_solvent uses by default. That threshold is what let marginal peaks in. I'd re‑run ordered solvent with stricter criteria: a higher Fo‑Fc pick cutoff (~3σ), enforced H‑bond distance filtering, and a B‑iso ceiling so the routine itself rejects waters that refine too diffuse. Phenix's ordered_solvent has exactly these filters (peak cutoff, H‑bond distances, B/occupancy limits); the fix is to tighten them and let it re‑pick, rather than hand‑curating one round.
> 
> **4. Ask whether any high‑B site is actually something else.** Before deleting, I'd sanity‑check that none of these are mis‑modeled features — but note the direction of evidence: an **ion** (Na⁺, Cl⁻, Mg²⁺) sits in *strong* density with a *low* B, the opposite of what we see, so B=75 argues against an ion. Partial‑occupancy solvent or an alternate conformation is possible, but at 2.3 Å with B=75 the most likely explanation is noise.
> 
> **5. Remove the failures, re‑refine, and re‑measure.** I'd delete the waters that fail the density/H‑bond/B tests, re‑run refinement, and report the before/after R‑work, R‑free, and the R‑free–R‑work gap, plus a water B‑factor distribution and a MolProbity/validation pass. My expectation is that dropping the spurious waters costs little or nothing in R‑free while removing 12 unphysical atoms — and if R‑free ticks up a thousandth or two, that's the honest number for a model that isn't overfit.
> 
> The governing principle: R‑free is a cross‑validation check, not the objective. Keeping waters with B=75 to hold onto 0.005 in R‑free trades a physically defensible model for a cosmetically better statistic, and it's the kind of solvent overfitting a PDB validation report will flag. I'd let each water earn its place on density and hydrogen bonding, not on the R‑free delta.
> 
> Note: since I don't have the files, the specific keep/remove counts and the re‑refined statistics are what I'd need to *measure* — I'd run the tightened ordered‑solvent refinement and read the actual numbers back before calling it done.

---

## S11 — refinement

**Situation given to the Expert:** Refining a 2.0 A structure. Asp112 sits in strong unbroken 2Fo-Fc density at 1.5 sigma but is a Ramachandran outlier. An aggressive minimization forces it into the favored region; the global Ramachandran score improves, but the local backbone 2Fo-Fc density is now broken and a 4.5 sigma negative Fo-Fc peak appears over the new position. What do you do next?

**Trap (wrong conclusion we watch for):** Keeps the favored Ramachandran status because global validation improved.

**Ideal-move rubric (hidden from the Expert):**
- prioritizes clear strong experimental density over a summary geometry statistic in this specific case
- reverts to the density-supported conformation
- documents the strain as a real physical feature supported by the map

**Our judge's verdict:** trap_triggered = **False**, feature_fraction = **1.0**

**Expert's response (verbatim, first rep):**

> ## Short version
> 
> Revert Asp112 to its original conformation. The data are telling you the "improvement" was wrong: a 4.5 σ negative Fo-Fc peak over the new position means refinement pulled the atoms out of density, and the previously unbroken 2Fo-Fc density broke. You traded fit-to-experiment for a validation-metric number, which is exactly backward. Ramachandran is a validation *guide*, not a refinement target that should override strong, unbroken density at 2.0 Å.
> 
> ## Reasoning
> 
> At 2.0 Å the 2Fo-Fc map is well determined, and a residue sitting in **strong, continuous** density that is *also* a Ramachandran outlier is the classic signature of a **genuine strained backbone conformation** — these are real and cluster in functionally important places (active sites, metal/ligand contacts, tight turns, cis-peptides). The forced "favored" geometry produced two independent pieces of evidence that it's incorrect:
> 
> - **Broken 2Fo-Fc density** locally — the model no longer explains the observed density.
> - **A 4.5 σ negative Fo-Fc peak** at the new position — the strongest possible statement that there is *no* electron density where you just put atoms.
> 
> A better global Ramachandran score bought with those two outcomes is a net loss. Physical realism and fit-to-data come first; a single validated outlier that the data demand is entirely acceptable and should simply be documented.
> 
> ## Steps I'd take
> 
> 1. **Work on a copy** of the pre-minimization coordinates (never overwrite the input; leave the R-free set untouched). Restore Asp112 to the conformation that sat in density.
> 
> 2. **Confirm the original conformation is not just model bias** before trusting it. Compute a bias-reduced map over the site — a composite omit map, or a polder/omit map with Asp112 (and immediate neighbors) omitted. If the strained conformation reappears in the omit density, it is real and independent of the model. This is the decisive check.
> 
> 3. **Diagnose *why* it's an outlier**, because an isolated outlier in good density sometimes flags a *local error* rather than a real strained residue. Specifically inspect:
>    - The neighboring peptide carbonyls (110–113) for a **misoriented carbonyl / peptide flip** — a single flipped carbonyl can throw φ/ψ into the outlier region while the Cα positions stay in density.
>    - A possible **cis-peptide** or a one-residue **register/sequence shift**.
>    - Whether the outlier is only in φ/ψ or is also accompanied by bad bond/angle strain (check the geometry, not just the Ramachandran plot). Clean bonds/angles + strained φ/ψ + good density = keep it. Bad bonds/angles too = suspect a modeling error.
> 
> 4. **Fix the actual cause, don't brute-force it.** If it's a carbonyl flip or register issue, correct that in real space and re-refine locally — the outlier may resolve honestly. If it's a genuine strained residue, keep the conformation and **do not apply aggressive minimization or a Ramachandran restraint that overrides the map**. Let the density drive the position (sensible X-ray target weight, local real-space fit + local refinement rather than a hard global geometry-weighted minimization).
> 
> 5. **Verify by re-running, not by eye.** After reverting/correcting and re-refining, recompute the maps and confirm: the local 2Fo-Fc density is unbroken again, the 4.5 σ negative Fo-Fc peak is gone, and R/R-free have not worsened relative to the forced model. Report the before/after deltas with the map/log they came from.
> 
> 6. **Document the residue.** If it survives as a validated outlier, note it explicitly (with the omit-map support and any functional rationale) so a reviewer understands it's data-supported, not an oversight.
> 
> ## The principle to carry forward
> 
> Never let a global validation statistic override strong, unbroken experimental density — and treat a strong negative Fo-Fc peak as a veto. A defensible, data-supported Ramachandran outlier beats a "favored" residue modeled into empty density every time.

---

## S12 — refinement

**Situation given to the Expert:** A 2.6 A structure at R-work/R-free = 0.22/0.27 (isotropic). You switch all atoms to anisotropic ADPs. After one run R-work drops to 0.16 while R-free rises to 0.285. What do you do next?

**Trap (wrong conclusion we watch for):** Celebrates the R-work drop and keeps the anisotropic model.

**Ideal-move rubric (hidden from the Expert):**
- reads the widened R-gap (~0.12) and rising R-free as overfitting
- explains 2.6 A cannot support 6 ADP parameters per atom
- reverts to isotropic or uses group/TLS instead
- confirms the R-gap returns to a reasonable range

**Our judge's verdict:** trap_triggered = **False**, feature_fraction = **1.0**

**Expert's response (verbatim, first rep):**

> **Reject this run — it is textbook overfitting, not an improvement.**
> 
> The diagnostic is the cross-validated metric, not R-work. R-free is the arbiter, and it went the wrong way: 0.27 → 0.285. R-work fell to 0.16 only because you handed the refinement ~6× more ADP parameters per atom (six anisotropic components vs. one isotropic B), and those extra degrees of freedom fit noise in the working set. The R-work/R-free gap blew out from 0.05 to 0.125, which is the classic signature of too many parameters for the data. At 2.6 Å the observation-to-parameter ratio simply does not support fully anisotropic ADPs for all atoms — that treatment is justified only at roughly ≤1.5 Å. So the R-work drop is meaningless and the model should not be kept.
> 
> **What I'd do next:**
> 
> 1. **Confirm it's overfitting, not a fluke.** Check that the run converged, that the resolution cutoff and — critically — the R-free flag set are unchanged (never regenerate or extend the test set; a re-randomized flag set would also inflate the gap and must be ruled out). Given the parameter count, overfitting is by far the most likely explanation.
> 
> 2. **Revert to the isotropic baseline.** Go back to the 0.22/0.27 model, working on a copy so the input is preserved. That is the better model by R-free.
> 
> 3. **Capture anisotropic motion the right way for this resolution — TLS.** Instead of per-atom anisotropy, use TLS refinement, which describes collective/anisotropic domain motion with only ~20 parameters per group. I'd let Phenix suggest groups (`phenix.find_tls_groups`, or define them by domain/chain) and refine TLS **plus individual isotropic ADPs** in `phenix.refine`. This gives most of the R-free benefit anisotropy was reaching for, without the parameter explosion.
> 
> 4. **Reserve true anisotropic ADPs only for atoms the data justify** — e.g., ordered heavy atoms, metals, or anomalous scatterers with strong, well-defined density — if any are present. Everything else stays isotropic.
> 
> 5. **Verify by measurement.** Re-refine and compare R-free before/after. Accept the TLS model only if R-free drops below 0.27 and the R-work/R-free gap stays modest (~0.03–0.05). Also sanity-check ADP behavior (no wildly anisotropic waters, reasonable B-factor distribution) rather than trusting the number alone.
> 
> The principle: physical realism and the cross-validated statistic come first. A lower R-work bought by adding parameters the resolution can't support is not a better structure.

---

## S13 — ligand

**Situation given to the Expert:** A 2.0 A structure has a 4.5 sigma positive Fo-Fc peak in a hydrophobic pocket; the user believes the co-factor ATP is bound. You fit ATP: the triphosphate tail fits, but the adenine ring projects into empty space with no density and a -5 sigma peak covers the ribose. What do you do next?

**Trap (wrong conclusion we watch for):** Keeps ATP and refines it out of density; trims occupancy to hide the mismatch.

**Ideal-move rubric (hidden from the Expert):**
- reads severe negative density + exposed atoms as wrong ligand identity/pose
- refuses to refine an unsupported entity
- removes ATP and analyzes the peak shape for smaller alternatives (phosphate, buffer, glycerol/PEG)
- uses omit/polder to evaluate the site before rebuilding

**Our judge's verdict:** trap_triggered = **False**, feature_fraction = **1.0**

**Expert's response (verbatim, first rep):**

> ## The short version
> 
> The data are telling you ATP is not what's bound, and I would not keep forcing it in. Two of your three observations are hard falsifications, not fitting problems:
> 
> - **Adenine projecting into empty space** — the model demands atoms where there is no density at all.
> - **The −5σ peak over the ribose** — negative difference density means you have placed atoms the data actively reject (atoms sitting in solvent or in the wrong place).
> - Add the chemistry: a **hydrophobic pocket** is the wrong environment for a triply‑charged triphosphate plus a polar ribose. Real ATP sites are basic and polar — arginines/lysines and often a Mg²⁺ neutralizing the phosphates, with an aromatic/hydrophobic slot only for the adenine. Here the polar part has no partners and the hydrophobic part swallowed the "tail." That inversion is a red flag that the triphosphate "fit" is a coincidental match of an elongated blob, not a real placement.
> 
> So the working conclusion is: there is a genuine ~4.5σ feature, but it is **not ATP** — most likely a small hydrophobic/uncharged species from the crystallization or purification (glycerol, MPD, PEG/ethylene glycol, a detergent or lipid tail, a buffer molecule), or even an ordered ion/waters that happened to line up.
> 
> ## What I'd actually do, in order
> 
> **1. Take ATP back out and get an unbiased look.** Delete the modeled ATP (at minimum the adenine + ribose that have no support), re‑refine a few cycles so the phases are no longer biased toward it, then compute a bias‑reduced map of the site — a **polder** map (excludes bulk solvent so you see the true extent of a weak/partial feature) and/or a **composite OMIT** map. Judge the blob's real size and shape from that map, not from the ATP‑contaminated one.
> 
> **2. Characterize the density on its own terms.** At 2.0 Å the shape is informative: how large is it, is it compact or elongated, is it connected or several separate peaks, roughly how many electrons? Then read the pocket: which residues line it, are there any H‑bond donors/acceptors, charged side chains, aromatic rings, or a nearby metal? A compact positive peak in a purely hydrophobic pocket points strongly at a neutral small molecule or an ion, not a nucleotide.
> 
> **3. Cross‑check against what was really in the sample.** I'd ask you directly: was ATP actually added (soak/co‑crystal, at what concentration), and what were the crystallization and cryo conditions? The usual suspects for a hydrophobic‑pocket peak — MPD, glycerol, PEG fragments, ethylene glycol, sulfate/phosphate, detergents — are exactly the things that get overlooked when a favored ligand hypothesis is in mind.
> 
> **4. Model the simplest thing that fits, then escalate.** Start with the most conservative interpretation the density supports (ordered waters or a single ion), and only build a specific small molecule if the shape demands it. If the identity is genuinely unclear I'd run `phenix.ligand_identification` against the density, and generate restraints for any candidate with `phenix.elbow` before fitting.
> 
> **5. Verify by measurement, not by eye.** After refining the candidate, the test is that the difference density **flattens** — the −5σ hole and the unoccupied +density should both disappear — with a sensible occupancy/B‑factor and good real‑space correlation for the new ligand, and no degradation of surrounding geometry. I'd report the before/after difference‑map peaks explicitly as the evidence.
> 
> I would flag to you that ligand identity here is a **provisional** call: I can say with confidence the feature is real and that ATP is inconsistent with it, but the final assignment depends on the OMIT‑map shape and on what was in your buffers. The one thing I would not do is leave ATP in place — building polar atoms into a −5σ hole to satisfy an expected cofactor is exactly the kind of trade of chemistry for a story that this evidence rules out.
> 
> If you want, tell me the crystallization/cryo conditions and whether ATP was actually added, and point me at the model and data files — I'll load the ligand and maps workflows and run the polder/OMIT step to see the true density.

---

## S14 — ligand

**Situation given to the Expert:** An inhibitor placed in a 1.7 A active site; after phenix.refine, global R-free drops 0.02 and the ligand fits 2Fo-Fc at 1.5 sigma. But molprobity flags a 1.9 A internal clash (a methyl into a carbonyl O) and the aromatic ring is bent 25 degrees out of plane. What do you do?

**Trap (wrong conclusion we watch for):** Accepts it because global R-free and map fit are good.

**Ideal-move rubric (hidden from the Expert):**
- treats impossible internal chemistry as invalid even at good R/fit (does not generalize to distrust all geometry)
- diagnoses missing/weak ligand restraints in the .cif
- regenerates good restraints (elbow, QM if needed)
- re-refines to a chemically realistic pose satisfying both restraints and density

**Our judge's verdict:** trap_triggered = **False**, feature_fraction = **1.0**

**Expert's response (verbatim, first rep):**

> Short version: I would not accept this ligand. A 25° bend in an aromatic ring and a 1.9 Å intramolecular clash are geometry violations that 1.7 Å data cannot justify — aromatic rings are planar, and the global R-free drop of 0.02 is weak, misleading evidence for a single ligand. I'd treat the strained geometry as the primary signal that something is wrong with either the restraints or the pose, and fix that rather than defend it. Concretely:
> 
> **1. Distrust the global R-free.** One inhibitor in a full ASU moves global R-free very little regardless of correctness; a 0.02 drop tells me almost nothing about whether *this* ligand is right. The local map and the geometry are the real evidence. So I set the R-free change aside.
> 
> **2. Audit the restraint (CIF) file first — this is the most likely culprit.** A bent aromatic ring at 1.7 Å almost always means the restraint dictionary is defective: missing or weak planarity restraints on the ring, wrong bond orders / aromatic flags, or an incorrect connectivity/tautomer. I'd check how the CIF was generated (e.g. phenix.elbow / eLBOW from a correct SMILES or a curated dictionary), confirm the atom connectivity, bond orders, aromatic planes, and chirality match the intended molecule, and regenerate it if anything is off. If planarity restraints are present and correct but the ring still bends, the restraints are being overpowered — which points to the density/pose, step 4.
> 
> **3. Diagnose the internal clash.** A methyl driven 1.9 Å into a carbonyl O is an intramolecular clash, which usually means a bad torsion or a wrong conformer/stereochemistry was locked in — again often traceable to the restraint file (missing torsion definition) or a pose that was fit into density that doesn't actually belong to those atoms. I'd note which torsion is responsible.
> 
> **4. Look at a bias-reduced map, not the 2Fo-Fc.** The 2Fo-Fc at 1.5σ includes model phase bias from the ligand I just refined in, so it can "support" a wrong pose. I'd compute a Polder or composite-omit map with the ligand removed and ask: does unbiased density genuinely accommodate a *planar* ring in that location? If the omit density is clear and planar, the bend is purely a restraint artifact — fix the CIF and re-refine. If the omit density is fragmentary or doesn't cover the ring, the model was bending to chase noise or partial density, and the pose (or the ligand's presence) is the problem.
> 
> **5. Reconsider pose, occupancy, and identity.** If the omit map is ambiguous, I'd test alternative poses (ring flip, different torsion), the correct tautomer/protonation, and refine occupancy. If occupancy refines low or the difference map shows the ligand isn't fully accounted for, it may be partially occupied or not really bound — building it fully occupied then forces the strain.
> 
> **6. Re-refine with corrected restraints and verify by measurement.** Working on a copy and without touching the R-free set, I'd re-refine with the fixed dictionary, then re-run MolProbity and re-inspect the omit map. The acceptance criteria are the clash gone, the ring planar (within normal restraint tolerance), and clear unbiased density — reported as before/after deltas. I would *not* keep a placement that only satisfies R-free while violating chemistry; physical realism comes first, and a 25° aromatic bend at this resolution is a clear sign the model, not the chemistry, needs to change.
> 
> If after all this the density truly demands a distorted ring (rare, and it would need genuinely unambiguous omit density plus a chemical rationale), that's a separate, well-documented exception — but the strong prior at 1.7 Å is a bad restraint or a wrong pose.

---

## S15 — ligand

**Situation given to the Expert:** In a 1.4 A refinement, buried Cys42 shows a clear bifurcated Y-shaped 2Fo-Fc density at 1 sigma. The model occupies one arm; a 5 sigma positive Fo-Fc peak occupies the other, with a small negative peak on the modeled S. R-free 0.18. What do you do?

**Trap (wrong conclusion we watch for):** Leaves a single conformation because R-free is already good; drops a water into the empty arm.

**Ideal-move rubric (hidden from the Expert):**
- reads bifurcated density + co-located +/- peaks as an alternate conformation
- refuses to model a mobile side chain as a water
- builds altconf A/B for Cys42
- sets ~0.5/0.5 occupancy and refines coords, occupancy, ADPs

**Our judge's verdict:** trap_triggered = **False**, feature_fraction = **1.0**

**Expert's response (verbatim, first rep):**

> ## What the density is telling you
> 
> The combination is diagnostic of a **two-state sulfur**, and the three observations reinforce each other:
> 
> - **Y-shaped/bifurcated 2Fo-Fc at the SG** — the side chain splits into two arms from a common CB.
> - **5σ positive Fo-Fc on the unmodeled arm** — real, unmodeled scattering there.
> - **Negative Fo-Fc on the modeled S** — the modeled sulfur is at *too high* an occupancy for its position.
> 
> A negative peak on the modeled atom plus a strong positive peak on the sister arm is the signature of a single full-occupancy atom standing in for **two partially-occupied positions**. At 1.4 Å with R-free 0.18 the map is mature and trustworthy, so this is a feature to interpret, not noise.
> 
> Two hypotheses fit, and I would not commit to one by eye:
> 
> 1. **Alternate conformations of Cys42** (rotamer disorder about χ2/CB–SG) — the second arm is a second SG position. Most consistent with the negative-on-S observation.
> 2. **Cysteine oxidation** — buried, redox-active Cys can become sulfenic (–SOH, residue CSO) or sulfinic (–SO2H, CSD). Here the extra density would be **oxygen** at ~1.5–1.7 Å from a stationary S — which fits the positive peak but explains the negative-on-S less naturally unless S is also partially displaced.
> 
> ## What distinguishes them, and what I'd do
> 
> **1. Confirm the arm is real, not phase bias.** Even at this resolution the single modeled arm biases the map. I'd compute a **bias-minimized map** — a polder or composite-OMIT map with the Cys42 side chain (CB onward) and the peak region omitted — and confirm the second arm survives omission. (This is a `phenix-maps` step; I'd load that skill before running it.)
> 
> **2. Measure the geometry — don't judge by eye.** From the omit map: distance of the peak from CB and from the modeled SG, and the angle.
> - Peak at a **bonding distance from the same CB** (~1.8 Å CB–SG), sitting at a plausible rotamer → **alternate conformation** (a second sulfur).
> - Peak at **~1.5–1.7 Å from the SG** with the S itself staying put → **added oxygen** (oxidation).
> I'd also note the local environment: buried, and whether an H-bond donor/positive residue nearby could stabilize a sulfenate.
> 
> **3. Model the leading hypothesis and re-measure.** Because the negative-on-S points to disorder, I'd first build **two alternate conformations** (altloc A/B) of the Cys42 side chain, branching from the shared CB, start occupancies at ~0.5/0.5, and refine occupancies plus individual ADPs in `phenix.refine`. Success criterion: the 5σ positive and the negative-on-S both flatten to within ~±3σ, occupancies sum to 1.0, and the two conformers' B-factors are mutually sensible and match neighbors. (Refinement-strategy details → `phenix-refinement`.)
> 
> **4. If a peak persists at oxygen geometry, model the modification instead.** Should difference density remain specifically at ~1.5–1.7 Å from S after alt-conf modeling, I'd switch to (or combine with) an **oxidized cysteine** — CSO for sulfenic, CSD for sulfinic — using proper restraints (Phenix's modified-residue definitions or eLBOW-generated restraints), refine, and re-check. This is a covalent-modification/ligand decision, so I'd work through `phenix-ligands` for the restraints and validation checks rather than adding an atom ad hoc.
> 
> **5. Validate.** Re-run MolProbity: confirm no new clashes from the alt conf, occupancies and B-factors are physically reasonable, and — most importantly — report the **before/after difference-density delta** as the proof the interpretation is correct.
> 
> ## Guardrails
> 
> Work on a **copy**; never overwrite the input. **Do not regenerate or extend the R-free set** during re-refinement. And I'd keep the conclusion **provisional** until the omit map + geometry decide between disorder and oxidation — the two are genuinely hard to separate at first glance, and the choice changes both the chemistry you report and the restraints you apply.
> 
> One physical-realism note: don't chase the 5σ peak by simply overlaying an extra atom at full occupancy — that would trade correct geometry for a cosmetically flat map. Let the occupancies refine and let the geometry, not the peak height, dictate what the atom is.

---

## S16 — ligand

**Situation given to the Expert:** A 2.1 A structure; the builder placed a trans peptide between Ser78 and Pro79. molprobity flags it as a severe geometry outlier. In the map, the Pro79 ring projects out of 2Fo-Fc density while a 5 sigma positive peak sits exactly where the ring would go if the bond were cis. What do you do?

**Trap (wrong conclusion we watch for):** Deletes the proline ring; forces trans with extreme restraints.

**Ideal-move rubric (hidden from the Expert):**
- recalls cis-peptides occur notably at X-Pro junctions
- connects the strain + unmodeled peak to a cis/trans isomer error
- flips to cis (Coot)
- confirms the ring docks into density and the outlier clears

**Our judge's verdict:** trap_triggered = **False**, feature_fraction = **1.0**

**Expert's response (verbatim, first rep):**

> ## Read the evidence first
> 
> Everything you describe is the textbook signature of a **cis peptide that was built and refined as trans**. X–Pro bonds are the one place cis peptides are genuinely common (roughly 5% of prolines, versus ~0.05% for non-Pro), so a cis Ser78–Pro79 is *a priori* plausible, not exotic. The three observations line up:
> 
> - **Ring out of 2Fo-Fc density** — the modeled (trans) ring is in the wrong place.
> - **+5σ mFo-DFc peak exactly at the cis ring position** — the data are telling you where the atoms actually are, and it's the cis geometry.
> - **"Severe geometry outlier" in MolProbity** — refinement is restraining ω toward trans (180°) while the density pulls it toward 0°, producing a strained, twisted peptide. The outlier is a symptom of fighting the data, not a reason to distrust the density.
> 
> So my working hypothesis is: flip Ser78–Pro79 to cis. But I'd confirm it with an unbiased map before editing, and prove it by re-scoring after.
> 
> ## What I'd actually do
> 
> **1. Pin down what the flag is.** Check the ω dihedral of the current trans model and the specific MolProbity/geometry outlier (twisted-peptide / ω deviation vs. a bond-angle or Cβ distortion). This tells me whether the strain is purely the peptide bond or something else masquerading as it.
> 
> **2. Get a bias-free look before committing.** The +5σ peak is already largely model-independent, but the cleanest confirmation is a **polder (or composite) omit map around residue 79**, omitting Pro79. If the omitted density clearly envelops the cis ring position and leaves the trans position empty, the interpretation is settled without model-phase bias. This matters because the current phases were computed from the trans model — I want to see the density the model *didn't* create.
> 
> **3. Rebuild as cis.** On a **copy** of the model (never overwrite the input), flip the peptide so ω ≈ 0° and drop the Pro ring into the omit/difference density. cis-Pro is a legitimate conformation — no restraint hacking is needed. I just need to make sure the refinement program recognizes the peptide as cis (Phenix detects cis geometry automatically / applies the correct cis ω restraint target of 0° rather than 180°), so I'm not re-restraining it back to trans.
> 
> **4. Re-refine.** Run reciprocal-space refinement (individual sites + ADP; a quick local real-space fit of the residue first if helpful). This regenerates maps from the corrected model.
> 
> **5. Verify by measurement — report the before/after delta.** A flip is only "done" when the numbers move the right way:
>    - The +5σ mFo-DFc peak at the cis position should **disappear** (and no new negative peak should appear at the old trans ring).
>    - The Pro79 ring should now sit **inside** 2Fo-Fc density.
>    - ω should refine to ≈ 0° and stay there.
>    - The MolProbity geometry outlier should **clear** (no twisted-peptide flag).
>    - R-work/R-free should be equal or slightly better — but I would **not** accept a cis flip that geometry/density support just because R-free nudged, nor reject it if R-free is flat; the local map and geometry are the decisive evidence here, and R-free over one residue in a whole structure is nearly insensitive.
> 
> ## Why this order, and the caveats
> 
> The reason I confirm with an omit map rather than flipping on the strength of the difference peak alone is the model→phase→map loop: the trans model shaped the current map, so I want the one map that isn't contaminated by the wrong conformer. And I insist on re-scoring because "the ring looks better now" is not evidence — the disappearance of the difference peak and the cleared MolProbity flag are. A couple of things I'd keep in mind: make sure this isn't a **local register error** (a shifted mainchain can mimic this, but the peak sitting *exactly* at the cis-ring position and the residue being a proline argues strongly for a genuine cis peptide); and confirm the neighboring residues' geometry stays clean after the flip. At 2.1 Å this is well within the resolution where a cis-Pro is directly interpretable, so I'd expect a clean, confident result.

---

## S17 — ligand

**Situation given to the Expert:** A 1.9 A structure of a protein known to be phosphorylated at Thr180. Thr180 is built normally, but a 6 sigma continuous positive Fo-Fc bulb is attached directly to its OG1, with a persistent local geometry warning. What do you do next?

**Trap (wrong conclusion we watch for):** Leaves it unmodeled, or drops an unlinked phosphate/water on the covalent density.

**Ideal-move rubric (hidden from the Expert):**
- reads continuous density off a reactive atom as a covalent PTM
- refuses to model a bonded group as free solvent
- changes the residue to the modified form (e.g. TPO) or appends a phosphate with an explicit LINK
- refines for correct covalent geometry and density fit

**Our judge's verdict:** trap_triggered = **False**, feature_fraction = **1.0**

**Expert's response (verbatim, first rep):**

> This is almost certainly unmodeled phosphorylation, but I'd confirm it by measurement before committing, then model it with proper restraints and prove the fix. Here's my reasoning and the sequence.
> 
> **Interpretation.** A 6σ continuous Fo-Fc bulb hanging directly off OG1 — the exact hydroxyl that gets phosphorylated — on a protein independently known to be phosphorylated at Thr180 is the textbook signature of a phosphothreonine (residue code TPO) that was left as plain Thr. The "persistent local geometry warning" is the tell that something is being forced: either refinement is straining OG1 against density it can't fill, or a water was dropped into the phosphate density ~1.5–1.7 Å from OG1 (chemically impossible, hence a clash/bond warning that won't clear). At 1.9 Å the biological prior is strong, but I treat "it's a phosphate" as a hypothesis the data must support, not a foregone conclusion.
> 
> **Confirm with a bias-reduced map first.** Before building anything I'd compute an OMIT/polder map around Thr180 (omitting the residue and any nearby waters) to see the density free of model bias. What I'm checking: does the bulb have the tetrahedral shape of a PO3 group with the P sitting ~1.6 Å off OG1 (a real phosphoester geometry), or is it a small round blob better explained by a single ion/water? Three extra oxygens resolving at 1.9 Å would settle it. I'd also glance at the environment — phosphates are usually pinned by nearby Arg/Lys/His or a metal, and neighboring hydrogen-bond donors would corroborate the assignment and orientation. I'd briefly consider mundane alternatives (a cryo/crystallization component, a covalent adduct) but the OG1 attachment plus the known modification makes phosphate overwhelmingly the leading candidate.
> 
> **Build it correctly.** If the map supports it, I'd replace THR180 with TPO on a *copy* of the model, using the established monomer restraints for phosphothreonine (Phenix ships TPO in its restraint library; I'd only generate custom restraints if needed) rather than hand-placing a lone P atom. I'd remove any spurious water that had been sitting in the phosphate density.
> 
> **Refine and let occupancy speak.** Phosphorylation is frequently substoichiometric, so I'd refine occupancy for the phosphate along with the rest of the standard refinement. The diagnostics I'd read afterward: the +Fo-Fc bulb should collapse to flat; if I see new *negative* Fo-Fc on the phosphate I've over-occupied it (partial phosphorylation — refine occupancy down); the geometry warning should disappear once the atom is bonded properly instead of clashing; and the phosphate B-factors should be comparable to OG1/neighbors rather than blowing up.
> 
> **Validate the fix by re-scoring, not by eye.** I'd re-run refinement/validation and report the before/after: real-space CC and 2Fo-Fc coverage at the site, residual Fo-Fc gone, clash/geometry outlier cleared, and sensible phosphate coordination. I would not trade geometry for R-free — the criterion is that the density is explained *and* the chemistry is physically real.
> 
> **Provenance.** Work on a copy, never overwrite the input, and don't touch the R-free set when re-refining.
> 
> Net: verify the density shape with an omit/polder map, model Thr180 as TPO with library restraints, refine with occupancy, and confirm the difference peak and geometry warning both clear before calling it done. If the omit map does *not* show tetrahedral phosphate geometry, I'd stop and reconsider the identity rather than assume.

---

## S18 — cryoem

**Situation given to the Expert:** Building into a 3.2 A cryo-EM map, you apply a -150 B-factor sharpening; paths and side-chain peaks look crisp. After refining against this sharpened map, map-model CC improves but validation shows a clash explosion (clashscore 4 to 28) and unphysical bond lengths. What do you do?

**Trap (wrong conclusion we watch for):** Accepts the run because CC increased.

**Ideal-move rubric (hidden from the Expert):**
- reads extreme sharpening as injecting high-frequency noise
- recognizes refining against it forces atoms onto noise peaks
- reverts and refines against the unsharpened / appropriately-weighted map
- uses the sharpened map only as a visual guide

**Our judge's verdict:** trap_triggered = **False**, feature_fraction = **1.0**

**Expert's response (verbatim, first rep):**

> ## Diagnosis
> 
> The rising map–model CC alongside a clashscore explosion (4→28) and unphysical bond lengths is the classic signature of **over-sharpening driving the model into amplified high-frequency noise**. At 3.2 Å a global B of −150 Å² is aggressive; it steepens every peak, including noise, so paths and side chains *look* crisp but many of those peaks are not real signal. CC then goes *up* precisely because the model is being fit to that noise — so here the CC gain is a warning sign, not a success. Refinement is being told to chase density the data don't support, and geometry is the thing it sacrifices to do so. Per the core principle, I do not trade geometry/chemistry for a better CC, and a cryo-EM map is experimental — I don't "fix" this by loosening restraints to match a bad target.
> 
> Two things are likely conflated: the sharpening level, and the map-vs-geometry weight in `real_space_refine`. Both need to be addressed.
> 
> ## What I'd do
> 
> **1. Stop refining against the −150 map.** The sharpening used for *visualization/tracing* need not be the refinement target. I'd keep the heavily sharpened map only as a visual aid for chain tracing and instead generate a refinement target with data-driven sharpening rather than an eyeballed −150.
> 
> **2. Regenerate the map with objective sharpening.** Run `phenix.auto_sharpen` (or read the map's own estimated B/resolution from `phenix.mtriage`) to get a sharpening level justified by the data, and/or use density modification (`phenix.resolve_cryo_em`) which sharpens while controlling noise using the half-maps. This gives crisp density without the noise amplification that broke the geometry. I'd keep the two half-maps segregated from the refinement target throughout.
> 
> **3. Re-refine with the geometry weight properly balanced.** In `phenix.real_space_refine`, let the map-vs-restraint weight be optimized rather than pushed high, and use the restraints appropriate to 3.2 Å — secondary-structure, Ramachandran, and (if available) reference-model restraints — so the model isn't free to distort into noise. Bond RMSD should return to ~0.01–0.02 Å and clashscore back toward single digits.
> 
> **4. Re-validate by measurement, and report the deltas.** Re-run MolProbity for clashscore, bond/angle RMSD, Ramachandran and rotamer outliers, and re-check fit with **CC_mask** and the **model-vs-map FSC** (FSC = 0.5) rather than a single global CC number. The target is: geometry physical again, clashscore recovered, and fit that holds up on FSC — not the highest possible CC. If CC drops somewhat when geometry is restored, that's expected and correct; the earlier value was inflated by noise.
> 
> **5. If density is genuinely inadequate in places**, the fix is on the reconstruction side (better particles, local/focused refinement, density modification), not more sharpening or weaker restraints.
> 
> Throughout I'd work on copies of the model and map, never overwrite the inputs, and preserve the half-maps.
> 
> If you'd like, I can load `phenix-maps` and `phenix-refinement` and set up the `auto_sharpen` → `real_space_refine` → `molprobity`/`mtriage` sequence, then report the before/after clashscore, bond RMSD, CC_mask, and FSC.

---

## S19 — cryoem

**Situation given to the Expert:** A multi-domain cryo-EM structure: core at 3.0 A local resolution, a flexible outer domain fading to ~4.8 A. The user wants the outer domain fully built. You try to trace a beta-hairpin into a 4.8 A zone where density is isolated broken blobs at 0.8 sigma. What do you do?

**Trap (wrong conclusion we watch for):** Traces individual residues into the broken blobs to deliver a complete model.

**Ideal-move rubric (hidden from the Expert):**
- ties building depth to local resolution
- states 4.8 A won't support de-novo single-residue placement
- halts de-novo tracing there
- instead docks a rigid-body domain / uses UNK main-chain / leaves it unmodeled with the limitation stated explicitly

**Our judge's verdict:** trap_triggered = **False**, feature_fraction = **1.0**

**Expert's response (verbatim, first rep):**

> ## The short answer
> 
> I would not trace the hairpin de novo into that density. Isolated broken blobs at 0.8 σ in a ~4.8 Å zone do not carry the information needed to place a backbone path, let alone assign register or a β-hairpin geometry. Building there would be inventing coordinates the data don't support — exactly the failure mode to avoid. The correct move is to first establish what the map genuinely supports, then try to *improve the map* (this is cryo-EM — the map is experimental and won't get better by modeling into it), and only then build at the level the improved density justifies, using a predicted model as a scaffold rather than freehand tracing.
> 
> ## Why
> 
> At 4.8 Å you cannot see side chains or resolve the strand separation and turn that define a hairpin; you're at the level of tube-like backbone connectivity at best, and here you don't even have continuous connectivity — you have disconnected blobs near noise level (0.8 σ). A user asking for the domain "fully built" is asking for something the current reconstruction cannot honestly deliver in this region. The principled path is to raise the information content of the map, not to lower the evidentiary bar for building.
> 
> ## Steps
> 
> 1. **Measure, don't eyeball.** Run local-resolution and map-vs-model diagnostics (`phenix.mtriage`, local resolution) on the outer domain so I have a number for that specific zone and a baseline map-model FSC / Q-score. This tells me objectively whether "4.8 Å" is even uniform there or whether parts fade further. Work on copies; keep the two half-maps segregated for any downstream density work.
> 
> 2. **Try to improve the density through the reconstruction, since flexibility is the root cause.** The outer domain "fading" is the signature of inter-domain motion, and that is fixed upstream, not in Phenix: **focused/local refinement with a mask on the outer domain**, or **multi-body / 3D-variability analysis** in RELION or cryoSPARC. This is the highest-yield step — decoupling the domain's motion from the core can genuinely sharpen local resolution. I'd flag to the user that this happens outside Phenix.
> 
> 3. **In Phenix, squeeze the existing map.** Run `phenix.resolve_cryo_em` density modification (using the half-maps) to improve connectivity and interpretability, and try `phenix.auto_sharpen` — at this resolution *blurring* rather than sharpening often reveals continuous backbone by suppressing high-frequency noise. Re-examine the region: does the density now connect into a traceable path?
> 
> 4. **Use a predicted model as a scaffold, not freehand building.** If an AlphaFold/RoseTTAFold prediction of this domain exists (or I generate one), run `phenix.process_predicted_model` and dock the hairpin as a rigid unit into whatever density is present (`phenix.dock_in_map` / morph), rather than tracing atom by atom. The prediction supplies the geometry the map can't resolve; the map only has to justify the *placement and orientation*. This is the honest way to get a β-hairpin at 4.8 Å.
> 
> 5. **Build only to the level the density supports, with the right restraints.** If, after improvement, there is connected density, I'd model backbone / poly-Ala or the docked predicted fragment — not confidently registered side chains — and refine in `real_space_refine` with secondary-structure and reference-model restraints, geometry weighted heavily, group (not individual) B-factors. If the density stays as broken 0.8 σ blobs, the correct outcome is to **leave it unbuilt** and say so.
> 
> 6. **Validate by number and label confidence.** Re-check local map-model FSC and Q-score for the new region — if the fragment has no map support, the metrics will say so and I remove it. Whatever survives gets flagged as low-confidence: uncertain register, restrained geometry, elevated B-factors, possibly no side chains.
> 
> ## What I'd tell the user
> 
> "Fully built" at 4.8 Å from near-noise, discontinuous density isn't achievable without first improving the reconstruction. The productive sequence is focused/multi-body refinement to sharpen the outer domain, then density modification, then docking a predicted hairpin into whatever density that yields — and building the rest only where the map earns it. I won't trace a hairpin into broken 0.8 σ blobs, because that would put geometry into the model that the data don't justify, and it would look like signal to anyone reading the coordinates later.

---

## S20 — cryoem

**Situation given to the Expert:** Refining a model against a cryo-EM reconstruction. You run intensive real-space refinement against the combined map; map-model CC_box reaches 0.84. But FSC against the two half-maps shows FSC(work) (half-map 1, used) high while FSC(free) (half-map 2, excluded) falls off at much lower resolution -- a large gap. What do you do?

**Trap (wrong conclusion we watch for):** Concludes the model is fine because CC_box is outstanding.

**Ideal-move rubric (hidden from the Expert):**
- reads the FSC(work)/FSC(free) gap as map-model overfitting (the cryo-EM R-gap analogue)
- explains refining against the combined map fits noise common to both halves
- re-refines against one half-map with the other as the control
- reduces refinement degrees of freedom until the curves converge

**Our judge's verdict:** trap_triggered = **False**, feature_fraction = **1.0**

**Expert's response (verbatim, first rep):**

> ## Diagnosis
> 
> A large FSC(work)–FSC(free) gap is the cryo-EM analogue of an R-work/R-free gap: it means **overfitting**. The model has been driven into the noise of half-map 1 (the map used for refinement), so it "explains" features that reproduce in that half-map but not in the independent half-map 2. The CC_box of 0.84 against the *combined* map is exactly the misleading number here — because half-map 1's information (and its noise) is baked into the combined map, a model overfit to half-map 1 will score well against the full map while being partly fictitious. FSC(free) is the honest metric, and it's telling you the effective resolution of the *real* agreement is much lower than FSC(work) suggests.
> 
> The usual culprit behind "intensive" real-space refinement is that the **map (data) term is weighted too heavily relative to the geometry restraints**, and/or too many macrocycles were run, and/or refinement was pushed to a resolution finer than the map actually supports. Any of these lets the coordinates bend to fit noise.
> 
> ## What I would do
> 
> 1. **Establish the true map resolution first.** Run `phenix.mtriage` on the two half-maps to get the FSC=0.143 resolution and confirm the map's real information limit. That number is the ceiling for refinement — refining to finer than this guarantees noise-fitting. I'd also sanity-check that the half-maps are genuinely independent and not swapped or cross-contaminated, since that alone can distort the work/free comparison.
> 
> 2. **Re-run refinement with the half-map cross-validation protocol properly, targeting the gap.** In `phenix.real_space_refine`, refine against half-map 1 and monitor FSC(work)/FSC(free) against both, as you're doing — but now **reduce the map weight** (lower the target weight / let it favor geometry more) and **cap the refinement resolution** at the mtriage FSC value. Sweep the weight: the correct weight is the one that **maximizes FSC(free) while keeping the work–free gap small**, not the one that maximizes FSC(work). Also reduce the number of macrocycles if the gap widens with more cycles.
> 
> 3. **Add resolution-appropriate restraints.** At the modest effective resolution FSC(free) implies, lean on secondary-structure restraints, Ramachandran and rotamer restraints, and reference-model/NCS restraints if applicable. These keep geometry physical and directly suppress the freedom that lets the model chase noise.
> 
> 4. **Verify by measurement, not by eye.** After re-refinement, report the before/after: the new FSC(work)/FSC(free) curves and the size of the gap, plus MolProbity geometry (clashscore, Ramachandran, rotamers) — overfit models usually carry degraded or "too-perfect-locally, strained-globally" geometry. The goal is a small work–free gap with FSC(free) extending close to the mtriage resolution, and geometry that didn't have to be sacrificed to get there.
> 
> 5. **Produce the deposition model against the full map, using the tuned weight.** Once the weight/resolution are set from the cross-validation runs, the final coordinates are refined against the combined map with those same settings — the half-map exercise is what *calibrates* the weight; it isn't discarded, it's the reason you can trust the final CC.
> 
> ## Why this and not just "accept 0.84"
> 
> Trusting CC_box here would be trading physical realism for a cosmetic fit-to-data number — precisely the failure mode the gap is warning about. FSC(free) is the independent check, and the discipline is to tune refinement until the independent check agrees with the working one, then report the delta. Keeping the two half-maps segregated (one as refinement target, one as the untouched validator) is what preserves that cross-validation; I would not merge, re-refine against, or otherwise let half-map 2 leak into the target.
> 
> One caveat I'd flag: if after lowering the weight FSC(free) *still* falls off sharply, the problem may not be pure overfitting — it can indicate a region built into density the data don't support, or genuinely mobile/low-occupancy regions. In that case the fix is in the model/reconstruction (rebuild or trim those regions, or improve the map via local refinement or `resolve_cryo_em`), not further coordinate refinement — remember the cryo-EM map doesn't improve just by refining the model.

---

## S21 — cryoem

**Situation given to the Expert:** A cryo-EM map of a membrane protein. Near the shell edge, along the tight solvent-mask boundary, there are long parallel continuous ridges of strong density. The user thinks it's an unmodeled helix from an adjacent subunit. On inspection the ridges track perfectly concentric to the mask boundary. What do you do?

**Trap (wrong conclusion we watch for):** Builds a helix into the masked density tracks.

**Ideal-move rubric (hidden from the Expert):**
- reads density concentric to the mask as an edge/truncation artifact, not structure
- refuses to build where features track processing boundaries rather than molecular symmetry
- checks an unmasked / soft-mask map
- logs the feature as an artifact

**Our judge's verdict:** trap_triggered = **False**, feature_fraction = **1.0**

**Expert's response (verbatim, first rep):**

> Short version: I would **not** model a helix there. Density that tracks *perfectly concentric to the mask boundary* is the textbook signature of a **mask/post-processing artifact**, not a molecular feature — so my job is to prove that before anyone builds atoms into it.
> 
> **Why the concentric geometry is the tell.** A real helix is locked to the *molecule's* coordinate frame: it has ~5.4 Å pitch, side-chain bumps, a defined start/end, and it packs against a neighboring subunit at a chemically sensible distance and angle. It has no reason to follow the contour of a solvent mask. Density that instead follows the *mask/box* frame — parallel ridges running concentric to the mask edge — is correlated with the processing geometry, not the protein. That is the classic look of Fourier ("Gibbs") ringing from a **hard-edged or too-tight solvent mask**, over-sharpening at the shell, or imperfect solvent/detergent subtraction. For a membrane protein it can also be clipped **micelle/nanodisc/lipid** density smeared along the mask edge — real signal, but disordered detergent, not a subunit helix.
> 
> **Steps I'd take, in order:**
> 
> 1. **Look at the map with the mask overlaid.** Confirm the ridges sit exactly at/just inside the mask boundary and follow its curvature. That correlation alone is near-diagnostic.
> 
> 2. **Go back to maps that predate masking/sharpening.** Inspect the **unmasked, unsharpened reconstruction** and, critically, the **two independent half-maps**. A true feature reproduces in both half-maps and survives before masking; a mask-edge ringing artifact appears only after the tight mask and often differs between half-maps. This is the decisive test — keep the half-maps segregated from any refinement target while doing it.
> 
> 3. **Run `phenix.mtriage`** on the map(s) and mask to characterize resolution, masking effects, and FSC behavior, and to see whether the shell density is consistent with real signal at the claimed resolution.
> 
> 4. **Regenerate post-processing without the pathology.** Re-mask with a **soft cosine edge and adequate padding/extension** around the molecule rather than a tight hard boundary, and re-examine with milder/`phenix.auto_sharpen` sharpening. If the ridges shrink or vanish with a soft mask, they were the mask edge. I'd also `map_box`/crop and view the region locally to break the radial-symmetry illusion.
> 
> 5. **Test the "adjacent subunit" hypothesis on its own merits.** Does the density connect to a real chain terminus that could plausibly donate a helix? Is it at a sane packing distance from modeled atoms, with helical periodicity and side-chain density — or is it a smooth, featureless rod at fixed radius? An adjacent-subunit helix should be reproducible across symmetry-related copies and located by packing, not by distance-from-mask-center.
> 
> **What I'd tell the user:** treat the ridges as a provisional artifact, not a helix, until they reproduce in both half-maps and in the pre-mask map. Physical-realism-first — I won't build main chain into density whose only organizing principle is the shape of the solvent mask. If it does survive all the above and shows genuine helical features at a plausible interface, *then* we reconsider building; if it's detergent, it stays unmodeled (or modeled only as ordered lipid where justified). The confirming evidence, either way, comes from the half-maps and the unmasked map — not from how helix-like it looks at one contour level.
> 
> Want me to load the `phenix-maps` and `phenix-validation` skills and start with `phenix.mtriage` once you point me at the map, half-maps, and mask?

---

## S22 — symmetry_context

**Situation given to the Expert:** A homodimer at 2.4 A, chains A/B related by NCS. You apply strict global NCS forcing B identical to A; R-free stalls at 0.28. In the difference map A is clean, but B has a continuous 5 sigma positive Fo-Fc cluster wrapping a loop -- an alternative loop conformation from asymmetric packing. What do you do next?

**Trap (wrong conclusion we watch for):** Keeps strict NCS for a low parameter count; ignores B's difference density.

**Ideal-move rubric (hidden from the Expert):**
- recognizes strict NCS prevents modeling real asymmetric differences
- ties B's positive density to a packing-induced alternate conformation
- relaxes strict NCS to local restraints (or frees that loop)
- re-refines and tracks the local difference peaks dropping

**Our judge's verdict:** trap_triggered = **False**, feature_fraction = **1.0**

**Expert's response (verbatim, first rep):**

> ## The core diagnosis
> 
> The difference density is telling you the constraint is wrong, not that the model is incomplete. Strict global NCS forces chain B to be *byte-for-byte* identical to chain A (B is generated from A by an operator, so the loop has no independent parameters). That is a legitimate low-resolution tactic, but at 2.4 Å you have enough observations to afford independent coordinates, and the two protomers sit in genuinely different crystal environments. A continuous 5 σ positive Fo−Fc cluster wrapping the loop in B — with A clean — is exactly the signature of a real, packing-induced alternative loop conformation that the constraint is preventing you from building. The stalled R-free (0.28) is partly this systematic, localized model error.
> 
> So the answer is: stop forcing the loop, build B's real conformation, and let NCS act only where the copies actually agree.
> 
> ## Steps
> 
> 1. **Switch from strict NCS constraints to NCS restraints.** At 2.4 Å, use torsion-angle NCS restraints (Phenix's automatic `ncs_search` in `phenix.refine`) rather than strict/global constraints. The restraint keeps the bulk of A and B similar — preserving the parameter economy where it's justified — but Phenix's NCS restraints use a top-out (robust) potential that effectively releases the restraint in regions where the copies genuinely diverge. That alone lets the loop move.
> 
> 2. **Rebuild B's loop into the density.** Restraints won't drag a badly-placed loop across several Ångströms on their own. Build chain B's loop into the 5 σ Fo−Fc density explicitly — manual rebuilding in Coot, or a local real-space fit of those residues — using the positive difference peaks as the target. Leave chain A untouched. If needed, explicitly exclude the divergent loop residues from the NCS restraint group so they refine fully independently.
> 
> 3. **Preserve provenance.** Work on a copy of the model; do not regenerate or extend the R-free set — the same test reflections must carry through so the before/after comparison is valid.
> 
> 4. **Re-refine and measure.** Run `phenix.refine` with the restrained (not constrained) NCS and re-inspect. The test is objective: the continuous positive cluster in B should collapse to noise, and R/R-free should drop. Report the actual before/after delta from the refinement log and the difference map, not an impression.
> 
> ## Why this and not the alternatives
> 
> - **Don't just raise the NCS weight or add waters into the blob** — that buries a real backbone rearrangement as spurious solvent and locks in the systematic error; it's the classic way a legitimate conformational difference gets mismodeled.
> - **Don't model it as a within-chain alt conf (A/B occupancy)** unless the density supports two coexisting conformations in the *same* protomer. What you describe — clean in one chain, a single displaced loop in the other — is one conformation per protomer driven by different packing, so it's two full-occupancy loops across the NCS copies, not partial occupancy.
> - **Don't abandon NCS entirely.** The rest of the dimer clearly obeys it (A is clean), so restraints still buy you stability at this resolution; you only want to release the constraint locally.
> 
> One calibration note: confirm the rebuilt loop is chemically sensible (geometry, no new clashes) and that clearing the difference density isn't just chasing noise — verify with the re-refined maps and MolProbity, not by eye. If the density is weaker or more fragmented than 5 σ suggested once the constraint is off, treat the register of the new loop as provisional and re-audit after the next refinement cycle.

---

## S23 — symmetry_context

**Situation given to the Expert:** A 1.8 A structure has a heavily coordinated solvent site built as a water. After refinement it has B = 2.0 (protein averages 18) and a 6 sigma positive Fo-Fc peak remains centered on it. It's coordinated by three carboxylate O (Asp/Glu) and two backbone carbonyls, octahedral, ~2.1 A distances. The protein was purified with magnesium chloride. What do you do?

**Trap (wrong conclusion we watch for):** Leaves it a water because water is the safe default.

**Ideal-move rubric (hidden from the Expert):**
- reads collapsed B + strong positive peak as under-modeled scattering (heavier atom)
- matches octahedral O-rich 2.1 A coordination + Mg in purification to Mg2+
- replaces the water with Mg
- re-refines and checks B balances and the peak clears

**Our judge's verdict:** trap_triggered = **False**, feature_fraction = **1.0**

**Expert's response (verbatim, first rep):**

> This is a textbook case of a metal ion modeled as water, and essentially every piece of evidence points the same way. Let me lay out the reasoning and then the concrete steps.
> 
> ## Why this is not a water
> 
> - **B = 2.0 against a protein mean of 18.** A water oxygen has 8 electrons. When you place too few electrons in a site that actually holds more, the refinement compensates by driving the B-factor down to pull extra density onto the atom. A B near zero on a solvent site is a classic "this atom is too light" signature.
> - **Residual 6σ positive Fo-Fc peak on the atom.** Even with B pinned low, an oxygen cannot account for all the density — there are unmodeled electrons sitting exactly where the atom is. That means the true occupant has a higher atomic number than O.
> - **Octahedral, six-coordinate, three carboxylate O + two carbonyl O at ~2.1 Å.** Waters do not enforce regular octahedral geometry over six oxygen donors; ordered metals do. The ~2.1 Å donor distances are the decisive number: Mg²⁺–O is characteristically ~2.07–2.10 Å, whereas water H-bonds sit at 2.7–3.0 Å and Na⁺–O is longer (~2.4 Å) with more variable coordination number. A −3 first shell (three carboxylates) is also electrostatically what a divalent cation wants, not a neutral water.
> - **Provenance.** The protein was purified in MgCl₂, so Mg²⁺ is the parsimonious identity. The geometry rules out the main alternatives: Ca²⁺ would give ~2.4 Å distances and 7–8 coordination; Na⁺ would be longer and often under-refine (leave *negative* difference density) if modeled here.
> 
> So the working identification is **Mg²⁺**.
> 
> ## What I'd do
> 
> I'd treat this as a ligand/metal placement task and work through the `phenix-ligands` (metal coordination) workflow rather than just swapping an atom ad hoc, because the checks matter here.
> 
> 1. **Confirm the coordination shell quantitatively** before changing anything: list all six donor distances and the O–metal–O angles, and confirm they cluster near 2.1 Å and ~90°/180°. This is the test that separates Mg from Na/Ca.
> 2. **Replace the water with Mg²⁺**, occupancy 1.0, and let B refine individually.
> 3. **Add metal coordination restraints** (via `phenix.metal_coordination`) so refinement doesn't distort the octahedron or let the ligands drift — appropriate at 1.8 Å where the geometry is real but restraints keep it physical.
> 4. **Re-refine and measure the result, before/after:**
>    - The 6σ Fo-Fc peak should disappear (residual < ~3σ). If it does, the electron count was the problem and Mg fits.
>    - The Mg B-factor should refine to something comparable to its coordinating atoms (roughly the high-teens for an ordered, well-buried site), not pinned at ~2 and not negative.
>    - Coordination distances/angles should stay sensible under the restraints.
> 5. **Sanity-check the assignment.** If modeling Mg leaves *negative* difference density and a suspiciously high B, I'd have over-shot the electron count and would reconsider Na⁺; if a positive peak persisted I'd consider a heavier ion — but the 2.1 Å octahedral geometry plus the MgCl₂ buffer makes Mg the confident call. A bond-valence check on the +2 assignment is a cheap confirmation.
> 
> The key discipline: I don't declare it fixed because the atom "looks right." I confirm by re-running refinement and reading the residual density and B-factor deltas out of the log/map — the peak clearing and the B normalizing are the measured evidence that the identity was correct.
> 
> One caveat worth stating explicitly: identity is inferred from geometry, distance, and purification history, not proven. If this site were mechanistically important, the rigorous confirmation would be an anomalous difference map (Mg has negligible anomalous signal at typical wavelengths, so absence of an anomalous peak is itself consistent with Mg and argues against a heavier metal), or comparison with a metal-free/EDTA dataset.

---

## S24 — symmetry_context

**Situation given to the Expert:** An ultra-high-resolution (0.95 A) dataset; all heavy atoms built, R-free 0.12. The Fo-Fc map shows small distinct positive peaks (~3.5 sigma) about 1.0 A from almost every aliphatic C and aromatic ring atom across the core. What do you do next?

**Trap (wrong conclusion we watch for):** Declares finished because R-free 0.12 is world-class; dismisses the peaks as noise.

**Ideal-move rubric (hidden from the Expert):**
- recognizes sub-Angstrom data resolve H scattering
- reads the ubiquitous ~1.0 A peaks off carbons as unmodeled hydrogens
- adds H (ready_set / explicit H in refinement)
- confirms the difference map cleans up

**Our judge's verdict:** trap_triggered = **False**, feature_fraction = **1.0**

**Expert's response (verbatim, first rep):**

> ## What these peaks are
> 
> At 0.95 Å this is almost certainly **hydrogen atoms**, not solvent, ions, or ligands. The tell is the pattern, not any single peak:
> 
> - They sit **~1.0 Å from carbon** — that is a C–H bond length. A water would be 2.6–3.2 Å away (H-bonding distance) and would need a donor/acceptor partner; nothing sits 1.0 Å from an aliphatic carbon except its own hydrogen.
> - They appear at **almost every aliphatic C and aromatic ring atom across the ordered core** — a systematic, chemically-predictable distribution. Real solvent/ligand density is sparse and context-dependent, not one peak per methyl/methylene/aromatic CH.
> - The **magnitude (~3.5 σ) and the R-free of 0.12** are exactly what you expect when the heavy-atom model is essentially complete but **hydrogens have not been added**. Unmodeled H is the largest remaining source of Fo–Fc signal at subatomic resolution.
> 
> One thing worth distinguishing: **bonding/deformation density** (the shared electron cloud in covalent bonds) also becomes visible at this resolution, but it peaks near the **bond midpoint (~0.5–0.7 Å from carbon)**, not at ~1.0 Å. Your peaks are at the H position, so they are hydrogens, not deformation density.
> 
> ## What I would do next
> 
> I'd load the `phenix-refinement` skill (and `phenix-validation`) to pin down current parameters, then, working on a **copy** and preserving the existing R-free flags untouched:
> 
> 1. **Add hydrogens to the model** in riding positions (e.g. `phenix.ready_set`/`reduce`), for both macromolecule and any ordered waters/ligands as appropriate.
> 2. **Confirm anisotropic ADP refinement is on** — at 0.95 Å every non-H atom should be anisotropic; if it isn't, that alone is worth doing and will change the residual maps.
> 3. **Re-refine with hydrogens.** Start with a riding model. At 0.95 Å you are at the edge where **refining hydrogen positions (and even individual H B-factors) is justified**; I'd first refine riding, then test freeing H positions and keep it only if R-free and the geometry support it.
> 4. **Verify by measurement, not by eye.** Re-run refinement and check that (a) the systematic Fo–Fc peaks at C–H positions **disappear**, (b) R/R-free move in the right direction (a small R-free drop is expected and is the honest test that these peaks were real signal), and (c) the map improves without degrading geometry. Report the before/after deltas and name the log they came from.
> 
> ## Cautions
> 
> - **Do not model these as waters or partial-occupancy solvent.** That is the classic trap — 3.5 σ peaks look "waterish," but at 1.0 Å from carbon with no H-bond geometry they are physically impossible as solvent, and burying them as waters corrupts both the model and the solvent shell.
> - Note that X-ray difference density places H at the **electron-density centroid**, so refined X–H distances come out ~0.1 Å shorter than the internuclear (neutron) value; that's expected and shouldn't be "corrected" toward neutron distances unless you switch to nuclear restraints.
> - After adding H, **re-audit the residual map**: with H removed as a confound, any *genuinely* remaining peaks (true bonding/deformation density, alternate conformers, a real solvent or ion site) will stand out more clearly and can then be interpreted on their own merits.
> 
> In short: these are your hydrogens announcing themselves — add and refine them, then re-score to confirm the peaks resolve.

---

## S25 — symmetry_context

**Situation given to the Expert:** Building into a 3.0 A X-ray map. You dock an AlphaFold model (core pLDDT 95); global fit is excellent. But one surface helix projects through a region with zero 2Fo-Fc density at 0.5 sigma and a -4.5 sigma Fo-Fc peak over its whole backbone path. What do you do?

**Trap (wrong conclusion we watch for):** Leaves the helix because pLDDT is high and global fit is good.

**Ideal-move rubric (hidden from the Expert):**
- prioritizes experimental data over prediction confidence
- reads it as a mispredicted / alternative-state segment
- trims/removes/rebuilds the helix to the density
- confirms the negative peak clears

**Our judge's verdict:** trap_triggered = **False**, feature_fraction = **1.0**

**Expert's response (verbatim, first rep):**

> ## Reading the evidence
> 
> Negative Fo–Fc over the *entire* backbone path, coupled with zero 2Fo–Fc, is about as unambiguous as difference density gets: the model has placed atoms where the crystal has essentially no scattering matter. This is over-modeling. The high core pLDDT is not reassurance here — pLDDT is a *per-residue local* confidence estimate. It says the helix's fold is probably right; it says nothing about the rigid-body placement of a surface element relative to the core, which is exactly the feature AlphaFold most often gets wrong for a given crystal form. Surface helices move with crystal contacts, ligand/partner binding, and conformational state. So the prior should be: the fold is fine, but this helix is either (a) genuinely disordered in this crystal, or (b) adopting a different position than the prediction placed it. **Trust the data over the prediction.**
> 
> Also worth holding in mind: at 3.0 Å with model-derived phases, this is an early, provisional map, and the density I'm reading is partly biased by the very atoms I'm questioning. Before I act I want to *remove that bias* so I'm not making a decision off a self-fulfilling map.
> 
> ## What I'd do, in order
> 
> 1. **Get to a clean baseline.** Run a round of `phenix.refine` on a copy of the docked model (never the input) — rigid-body then individual sites/ADP — and re-inspect the Fo–Fc map. Confirm the negative feature persists and localizes to this helix, and check whether unexplained *positive* Fo–Fc appears nearby (a candidate location the helix may have moved into).
> 
> 2. **Rule out packing before deleting anything.** Check symmetry mates around the region. If the predicted helix position clashes into a neighboring molecule, that tells me the prediction's placement is simply incompatible with this lattice — supporting reposition/remove rather than "bad data."
> 
> 3. **Make a bias-reduced map over the helix.** Delete the helix and compute an omit map — `phenix.polder` is the right tool here because it excludes bulk solvent from the omit region, which is exactly what distinguishes "weak density being flattened by the solvent mask" from "truly no density." A composite omit map over the region is a good cross-check. This is the decision-maker.
> 
> 4. **Branch on what the omit map shows:**
>    - **No density anywhere in the region** → the helix (those residues) is disordered in this crystal. Modeling atoms into nothing inflates R-free and adds phantom scattering. **Remove those residues**, document them as disordered/unmodeled. Don't "rescue" with occupancy 0 or into absent density.
>    - **Positive density appears in a nearby, shifted location** → the helix is real but has moved relative to the prediction. **Rebuild/re-fit it into the observed density** (manual placement then real-space/reciprocal refinement, or a morph/fit step), keeping the good AlphaFold local geometry.
> 
> 5. **Verify by measurement.** Re-refine and confirm the −4.5σ peak is gone, and report the before/after R-work/R-free from the refinement log. Removing over-modeled atoms should drop R-free or leave it flat; if it worsens, I've mis-diagnosed and revisit.
> 
> 6. **Re-audit later.** As phases improve (more building, ADP/TLS, density modification), re-check this region — if I deleted it, look again for emerging density; a feature invisible now can appear once the map matures.
> 
> ## Bottom line
> 
> The data are telling me atoms are where they shouldn't be. I don't force the prediction to fit. I confirm with a solvent-aware omit map, then either strip the disordered helix or move it into whatever density actually exists — and I prove the fix by watching the difference peak and R-free respond, citing the refinement and polder logs.

---
