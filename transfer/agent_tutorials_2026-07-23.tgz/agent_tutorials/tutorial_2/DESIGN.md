# Tutorial Design Document: "Trust But Verify"

## Validation Layers for LLM Agents in Scientific Workflows

---

## 1. Requirements and Constraints

**Setting:** Workshop on AI and Crystallography, tutorial track

**Duration:** 1 hour total (including setup and discussion)

**Format:** Hands-on, self-paced with instructor support. All materials
pre-packaged in a virtual environment distributed to students in advance.

**Audience:** Programmers, mostly graduate students. They can write Python
and use a terminal. They may or may not know crystallography. They
are likely familiar with LLMs as users but have not built agent systems.

**Constraint:** No network access required during the session. No LLM
API keys needed. Everything runs locally with deterministic, scripted
"LLM" decisions so every student sees the same behavior.

**Deliverable:** A directory that can be distributed as a tarball or
included in a pre-built VM image. Students need only Python 3.9+ with
the standard library — no pip installs, no virtual environments,
no requirements.txt.

---

## 2. Who This Is For

**Primary audience:** Graduate students in structural biology, bioinformatics,
or computational chemistry who write code as part of their research. They
are comfortable editing Python files and running commands in a terminal,
but are not software engineers by training. They've used ChatGPT or
similar tools and want to understand how to build reliable automated
systems with LLMs.

**Secondary audience:** Postdocs and staff scientists who write or
maintain scientific analysis pipelines and are considering adding
LLM-based decision-making to their workflows.

**What they bring:** Python fluency, intellectual curiosity about AI
agents, and domain knowledge about iterative scientific workflows
(even if not specifically crystallography).

**What they don't bring:** Experience with agent frameworks (LangChain,
LangGraph, etc.), production software engineering practices, or deep
understanding of LLM failure modes.

---

## 3. Materials Required

### For the Organizer (Advance Preparation)

- A virtual machine image or container with Python 3.9+. No additional
  packages are needed — the tutorial uses only the standard library.

- The tutorial directory (9 files, ~55KB total):

```
tutorial/
├── README.md              Walkthrough instructions (the "textbook")
├── programs.json          Domain definition: 5 programs, pipeline phases
├── validators.py          Student's work file — 5 exercise functions
├── test_validators.py     Test suite, runnable per-exercise
├── run_agent.py           Agent scaffold — calls validate_decision()
├── mock_runner.py         Simulates program execution with fake metrics
├── chaos_mode.py          Injects deterministic LLM failures
├── catchup.py             Escape hatch for students who fall behind
└── solutions/
    └── validators_complete.py   Reference solution (hidden from students)
```

### For Each Student

- A terminal emulator
- A text editor (VS Code, nano, vim — anything that can edit `.py` files)
- The tutorial directory in their home folder

### For the Instructor

- A projector for the 8-minute intro and 5-minute reveal
- Optionally: the PHENIX AI agent architecture diagram for the
  reveal discussion

### Not Required

- Network access (everything is local)
- LLM API keys (decisions are scripted and deterministic)
- PHENIX installation (programs are mocked)
- Any Python packages beyond the standard library

---

## 4. Goal

### Learning Objectives

By the end of this tutorial, students will:

1. **Understand that LLMs fail predictably** in agent systems —
   hallucinated actions, temporal confusion (referencing future state),
   state tracking failures, and inability to recognize convergence.
   These aren't rare edge cases; they happen routinely.

2. **Internalize that validation is architecture, not afterthought.**
   Building safety layers around an LLM is a design decision that
   affects system structure. The order in which validators run, whether
   they can suggest corrections (not just reject), and how they interact
   with each other are engineering problems with non-obvious solutions.

3. **Be able to implement validation layers** for any iterative
   scientific workflow — not just crystallography. The pattern
   (name check → state check → precondition check → convergence check)
   transfers to molecular dynamics, genomics pipelines, materials
   science workflows, and any domain where an LLM orchestrates a
   sequence of computational steps.

4. **Know the difference between a guard rail and a co-pilot.**
   A validator that only says "no" creates a stuck agent. A validator
   that says "try this instead" keeps the pipeline moving. Students
   will experience this difference firsthand when their early
   validators block everything and their later validators enable
   self-correction.

### Non-Goals

- Teaching crystallography. The domain is simplified to 5 programs
  and students need no domain expertise.

- Teaching prompt engineering. The LLM's prompt is not part of the
  tutorial; the point is that better prompts alone don't solve the
  reliability problem.

- Teaching a specific agent framework. The scaffold uses plain Python
  with no dependencies. The patterns transfer to any framework.

---

## 5. Overall Strategy

### Core Insight

The tutorial inverts the usual AI tutorial narrative. Most tutorials
say: "Here's an LLM, let's make it do something smart." This one
says: "Here's an LLM that's already doing something — badly. Your
job is to make it reliable."

This reframing is important for a scientific audience. Scientists
care about correctness. They've seen LLMs hallucinate and are
skeptical of agent systems. By starting from failure and building
toward reliability, the tutorial meets them where they are.

### Pedagogical Structure

The tutorial uses a **test-driven, incremental reveal** pattern:

1. **See the problem.** Students run the unguarded agent and watch
   it crash. The scorecard shows "LLM correct: 2, Execution failed: 4."
   The failure is visceral — they watch cycles of an agent
   confidently making wrong decisions.

2. **Fix one thing at a time.** Each exercise addresses one failure
   mode. Students implement a validator, run the tests (immediate
   feedback), and wire it into the agent (immediate impact). The
   test runner tells them what to do next.

3. **Discover interactions.** Exercise 5 presents pre-written
   validator blocks in the wrong order. A single test failure with
   the label "ORDERING: correction suggested (workflow before files?)"
   leads students to discover that validator ordering determines
   whether the system can self-correct.

4. **See the complete picture.** The final run with all validators
   shows the pipeline completing with `★ Pipeline complete! ★`. The
   scorecard shows most cycles were corrected by validators, not
   the LLM. The reveal connects each exercise to a real production
   component.

### Immunizing Against Skepticism

Grad students will notice immediately that the "LLM" is scripted.
Rather than hiding this, the tutorial owns it upfront and reframes
it as scientific necessity:

**The "Frozen in Amber" framing.** The README and the instructor
intro both say: "Live LLMs are non-deterministic, which makes
debugging impossible in a workshop. What you're looking at is a
forensic replay — real patterns of an LLM confidently making
mistakes while running a crystallography pipeline. We froze its bad
decisions so you can build the guardrails to catch them."

This works because:

- It's honest. The students know it's scripted, and the framing
  respects that.
- It's scientifically motivated. Reproducibility matters to this
  audience. "We controlled the variable" is a better story than
  "we faked the LLM."
- The scripted errors are hyper-realistic. The reasoning strings
  are verbose, confident, and domain-specific — they read like
  real LLM output. When the LLM references `best_model.pdb`
  (a file that doesn't exist yet) and explains "which should have
  the lowest R-free from our previous rounds," students will nod
  because they've seen ChatGPT do exactly that.

### Why This Works for 1 Hour

- **No boilerplate.** Students edit one file (`validators.py`).
  Everything else is pre-built.

- **Zero setup friction.** No packages to install — just Python 3
  standard library. The setup check is `python3 run_agent.py --max=3`.

- **Immediate feedback loops.** Every edit → test cycle is under
  30 seconds. Students never wait.

- **Graduated difficulty.** Exercises 1–2 are trivial (5 lines each,
  5 minutes). Exercise 3 introduces suggestions (10 minutes).
  Exercise 4 requires reasoning about convergence (10 minutes).
  Exercise 5 is a 5-minute block-reordering task, not a coding task.
  Fast students finish everything; slower students get through
  Exercise 3 and see the pipeline complete.

- **Escape hatch for stragglers.** `python3 catchup.py N` fills in
  all exercises before N with reference solutions, so a student stuck
  on Exercise 2 can jump to Exercise 4 without missing the integration
  reveal.

- **No LLM API dependency.** The scripted decisions and chaos
  injections are deterministic. Every student sees the same
  behavior. No one is stuck waiting for API rate limits.

- **Clean happy path.** When students finish all exercises, the
  agent completes successfully in both chaos and no-chaos modes.
  No caveat-ridden edge cases to confuse the victory moment.

---

## 6. Detailed Implementation

### 6.1 The Simplified Domain (programs.json)

Five programs model a generic iterative scientific pipeline. Each
has declared inputs, outputs, valid phases, and mock metrics:

| Program | Inputs | Outputs | Valid Phases | Notes |
|---------|--------|---------|-------------|-------|
| analyze_data | data.mtz | analysis_report.txt | analyze | Entry point |
| phaser | sequence.fa | predicted_model.pdb | find_model | Molecular replacement (phenix.phaser) |
| place_model | predicted_model.pdb, data.mtz | placed_model.pdb | place_model | Positions model |
| refine | placed_model.pdb, data.mtz | refined_model.pdb | refine | Iterative; R-free decreases |
| validate | refined_model.pdb | validation_report.txt | refine, validate | Terminal step |

**Key design decisions:**

- The domain definition is stored as JSON (`programs.json`) rather
  than YAML. This eliminates the only external dependency (PyYAML),
  making the tutorial truly zero-install. The JSON is human-readable
  enough for students to understand by inspection.

- `refine` has `advances_phase: false` — it stays in the refine phase,
  enabling multiple refinement cycles and creating the loop problem
  for Exercise 4.

- `validate` is valid in both `refine` and `validate` phases — so the
  loop detector can suggest it as an escape from refinement without
  violating workflow rules.

- The mock runner decreases R-free with diminishing returns:
  0.28, 0.255, 0.24, 0.24, 0.24... This creates a natural plateau
  that students must detect.

### 6.2 The Chaos Injection System (chaos_mode.py)

Three failure modes are injected at specific cycles. These are
not random — they're chosen to trigger exactly when the student's
validator for that exercise would catch them:

| Cycle | Failure | Tag | Which Exercise |
|-------|---------|-----|---------------|
| 2 | `find_model` (invented program; real MR program is `phenix.phaser`) | HALLUCINATED_NAME | Exercise 1 |
| 5 | `analyze_data` in wrong phase (tries to go backwards) | WRONG_PHASE | Exercise 3 |
| 7 | References `best_model.pdb` (invented filename) | MISSING_FILE | Exercise 2 |
| 8+ | Repeated `refine` with plateau | (natural behavior) | Exercise 4 |

**Design principle: the happy path is clean.** With all validators
active, the pipeline completes successfully in chaos mode. There are
no intentional edge-case failures that would make students think their
code is broken. The scorecard shows LLM correct: 2/9, Corrected: 5/9,
Blocked: 2/9 — a clean story of validators catching and fixing the
LLM's mistakes. More subtle failure modes (like gaps between what the
LLM claims to use and what a program actually requires) are discussed
during the final reveal, not experienced as confusing bugs during
the exercises.

**Hyper-realistic reasoning strings.** Every scripted decision includes
multi-sentence reasoning that reads like real LLM output — verbose,
domain-specific, and confident even when wrong. For example, the
cycle-7 MISSING_FILE injection says: "I'll continue with best_model.pdb
which should have the lowest R-free from our previous rounds of
refinement." The file doesn't exist, but the reasoning is exactly
what a real LLM would produce. The refine-loop decisions escalate
from "there's still significant room for improvement" through
"one more cycle should push us below 0.25" to "it can't hurt to
run one final cycle" — mimicking the optimistic non-convergence
students have seen from ChatGPT in their own work.

Non-chaos cycles use scripted "perfect" decisions that follow the
correct pipeline order. In `--no-chaos` mode, the LLM always wants
to keep refining (realistic: LLMs are optimistic), which triggers
the loop detector.

### 6.3 The Validator Stubs (validators.py)

Exercises 1–4 each follow the same pattern:
- Clear docstring with Args, Returns, and Examples
- A `# --- YOUR CODE HERE ---` marker
- A stub that accepts everything (returns True/valid)

Exercise 5 is structurally different: the code is pre-written but
the blocks are in the wrong order (see Section 6.3.5).

**Function signatures and expected implementations:**

**Exercise 1: `validate_program_name(decision, known_programs)`**
- Complexity: ~5 lines
- Core logic: `decision.get("program", "")` → check membership in `known_programs`
- Edge cases: empty string, missing key
- Returns: `(bool, error_string_or_None)`

**Exercise 2: `validate_files_exist(decision, available_files)`**
- Complexity: ~5 lines
- Core logic: iterate `decision["files"].values()`, check against `available_files` set
- Returns: `(bool, list_of_missing_filenames)`

**Exercise 3: `validate_workflow_order(decision, current_phase, program_defs)`**
- Complexity: ~10 lines
- Core logic: check if `current_phase` is in program's `valid_phases`;
  if not, find a program that IS valid for this phase
- Key insight: returns a **suggestion**, not just a rejection
- Returns: `(bool, error_or_None, suggested_program_or_None)`

**Exercise 4: `validate_no_loop(decision, history, metrics_history)`**
- Complexity: ~15 lines
- Two checks: (a) 3+ consecutive identical programs; (b) R-free
  plateau (improvement < 0.005 between last two runs)
- Requires iterating backwards through aligned history and metrics lists
- Returns: `(bool, reason_or_None)`

**Exercise 5: `validate_decision(decision, state)` — reorder, don't write**

This function is pre-written with four labeled blocks (A through D)
that call the four validators. The blocks are shipped in the wrong
order: A (name) → B (files) → C (workflow) → D (loop). The correct
order is A → C → B → D.

The key test creates a decision that has both the wrong phase AND
a missing file. In wrong order (B before C), the file validator
fires first, blocks the decision, and returns no correction. In
correct order (C before B), the workflow validator fires first,
catches the wrong phase, and suggests the right program. The test
label says `ORDERING: correction suggested (workflow before files?)`
to point students directly at the issue.

This redesign (from "write 20 lines from scratch" to "swap two
blocks") reduces Exercise 5 from 10 minutes to 5, ensures every
student reaches the final run, and still teaches the core lesson
about validator ordering.

### 6.4 The Catch-Up Script (catchup.py)

`python3 catchup.py N` fills in exercises 1 through N-1 with
reference solutions, so a student stuck on an early exercise can
jump ahead. Valid values: 2, 3, 4, or 5.

The script works by string-replacing the stub patterns in
`validators.py` with solution code. It's idempotent — running it
twice doesn't break anything. Solutions are marked with
`# --- FILLED IN BY CATCHUP ---` so students can distinguish
their own code from catch-up code.

**Workshop pacing note:** The instructor should announce the
catchup script at the 25-minute mark (after Exercise 3), so anyone
still stuck on Exercise 2 can jump to Exercise 4 and not miss the
loop detection exercise or the final reveal.

### 6.5 The Test Suite (test_validators.py)

29 tests total, distributed across 5 exercises (6+6+6+5+6).

Each exercise's tests cover:
- Valid inputs that should pass
- The specific failure mode the exercise targets
- Edge cases (empty inputs, missing keys)

Tests are runnable per-exercise: `python3 test_validators.py N`

Output features:
- Color-coded PASS/FAIL with expected vs. got on failures
- On all-pass: "Next: implement Exercise N+1" with the exact command
- On failure: "Fix the failing tests, then re-run: `python3 test_validators.py N`"

This eliminates the "what do I type next?" problem entirely.

### 6.6 The Agent Scaffold (run_agent.py)

The main loop:
1. Build state summary (phase, files, metrics, history)
2. Get decision from chaos_mode (scripted or injected)
3. Call `validate_decision()` — the student's code
4. If invalid with correction → use corrected decision
5. If invalid without correction → skip cycle
6. If valid → execute via mock runner
7. Update state and advance phase

**Scorecard:** At the end of every run, the agent prints:
```
SCORECARD
  LLM correct:        2 / 9
  Validator corrected: 5 / 9
  Validator blocked:   2 / 9
```

This gives students a quantitative feel for how much work the
validators are doing vs. the LLM.

**Command-line options:**
- `python3 run_agent.py` — chaos mode (default)
- `python3 run_agent.py --no-chaos` — scripted perfect decisions
- `python3 run_agent.py --max=N` — limit to N cycles

### 6.7 Session Flow

| Time | Activity | Student Action |
|------|----------|----------------|
| 0:00 | Instructor intro: what's crystallography, what's the pipeline, what can go wrong when an LLM runs it | Listen |
| 0:08 | Step 0: run the unguarded agent | `python3 run_agent.py` |
| 0:13 | Exercise 1: program name validation | Edit → test → pass |
| 0:18 | Exercise 2: file existence validation | Edit → test → pass |
| 0:23 | Exercise 3: workflow order validation | Edit → test → pass |
| 0:33 | Exercise 4: loop detection | `--no-chaos` to see plateau, then edit → test |
| 0:43 | Exercise 5: reorder the blocks | `test 5` → swap B and C → `test 5` |
| 0:48 | Final run | `python3 run_agent.py` → ★ Pipeline complete! ★ |
| 0:50 | Reveal: real PHENIX agent architecture | Listen + discuss |
| 0:55 | Discussion: validator ordering, when LLMs add value, what's still missing | Group discussion |
| 1:00 | End | |

**Pacing notes:** Fast students will finish Exercise 5 by 0:45 and
can explore the code, try breaking things, or read `chaos_mode.py`.
Slower students should reach Exercise 3 by 0:33 — from there,
`catchup.py 5` gets them to Exercise 5 in seconds. The critical
moment is the final `python3 run_agent.py` showing `★ Pipeline
complete! ★` — every student should reach this.

### 6.8 Key "Aha" Moments

1. **Step 0: "It's completely broken."** The unguarded agent fails
   most cycles. The LLM sounds confident every time. Students see
   that fluent reasoning ≠ correct decisions.

2. **After Exercise 2: "Everything is blocked."** Validators 1–2 catch
   every error but never suggest fixes. The agent is *safer* but
   *completely stuck*. Safety without recovery is useless.

3. **After Exercise 3: "It works — but I only wrote 20 lines."** If
   students wire up and run at this point, the pipeline can complete
   for the first time, and the scorecard shows the LLM got very few
   decisions right on its own. The validators did nearly all the work.

4. **Exercise 4, --no-chaos: "The LLM doesn't know when to stop."**
   R-free plateaus at 0.24 but the LLM confidently requests more
   refinement. Each time its reasoning sounds plausible. Students
   realize that convergence detection must be external to the LLM.

5. **Exercise 5: "Oh, the order matters."** Swapping two blocks
   changes the test from FAIL to PASS. The wrong order prevents
   corrections from working even though every individual validator
   is correct. Composition matters.

6. **The reveal: "There are 15 more validators."** Students built 4
   and caught most errors. The real system has ~15 and still discovers
   new edge cases after months of production use. Validation is
   never "done."

### 6.9 What the Tutorial Doesn't Cover (Discuss During Reveal)

These points are intentionally omitted from the exercises to keep
the happy path clean, but are worth discussing in the final 5-minute
reveal:

- **Gap between claimed and actual file requirements.** The LLM's
  `files` dict lists what the LLM *thinks* it needs, but the program
  definition in `programs.json` lists what's *actually* required.
  A real system validates both. This is a design issue in production
  agents and a good segue to "defense in depth."

- **Error recovery.** What happens when a program crashes mid-run?
  The real PHENIX agent has error-recovery validators that detect
  common failure patterns (bad MTZ data arrays, crystal symmetry
  mismatches) and inject fix-up steps. Our tutorial only prevents
  bad decisions; it doesn't recover from bad executions.

- **Parameter validation.** The real agent also validates the
  *parameters* passed to each program, not just the program name
  and phase. Blacklisting dangerous parameters, injecting required
  symmetry parameters, and preventing incompatible option
  combinations are all separate validator layers.

---

## 7. Distribution Checklist

- [ ] `validators.py` has all stubs (Exercises 1–4) and wrong-order
      blocks (Exercise 5), no solutions
- [ ] `solutions/validators_complete.py` has correct implementations,
      hidden from students
- [ ] `programs.json` (not `.yaml`) — zero external dependencies
- [ ] `catchup.py` tested for values 2, 3, 4, and 5
- [ ] `__pycache__/` removed from the tarball
- [ ] Test suite: 29/29 passing with solved validators
- [ ] Agent completes (`★ Pipeline complete! ★`) in both chaos and
      no-chaos modes with solved validators
- [ ] README reviewed for accuracy against current file contents
- [ ] VM/container tested: `python3 run_agent.py --max=3` works
      with no prior setup
- [ ] No network-dependent code anywhere in the tutorial
- [ ] No pip-installable dependencies anywhere in the tutorial
