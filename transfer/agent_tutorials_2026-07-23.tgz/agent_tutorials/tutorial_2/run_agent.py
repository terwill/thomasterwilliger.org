#!/usr/bin/env python3
"""
run_agent.py — The unguarded LLM agent scaffold.

This runs a simplified crystallographic pipeline where an "LLM" makes
decisions each cycle.  WITHOUT your validators, it crashes and burns.
WITH them, it catches errors and self-corrects.

Usage:
    python run_agent.py              # Run with chaos mode (injected failures)
    python run_agent.py --no-chaos   # Run with perfect scripted decisions
    python run_agent.py --max=6      # Limit to 6 cycles
"""

import os as _os
import sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
import safe_io  # noqa: F401  survive a non-UTF-8 terminal
import sys
import json
import textwrap
from mock_runner import MockRunner
from chaos_mode import get_decision
from validators import validate_decision


def load_config():
    with open("programs.json", "r") as f:
        return json.load(f)


def advance_phase(current_phase, phases, program_defs, completed_program):
    """Move to the next phase if the completed program's phase matches current."""
    for prog_name, defn in program_defs.items():
        if prog_name == completed_program:
            # Programs with advances_phase: false stay in current phase
            if defn.get("advances_phase") is False:
                return current_phase
            if current_phase in defn["valid_phases"]:
                idx = phases.index(current_phase)
                if idx + 1 < len(phases):
                    return phases[idx + 1]
    return current_phase


def format_state_summary(state):
    """Build a human-readable summary of the current state."""
    lines = [
        "  Phase:     %s" % state["current_phase"],
        "  Files:     %s" % ", ".join(sorted(state["available_files"])),
    ]
    # Show latest metrics
    for m in reversed(state["metrics_history"]):
        if m:
            lines.append("  Metrics:   %s" % m)
            break
    if state["history"]:
        progs = [h["program"] for h in state["history"]]
        lines.append("  History:   %s" % " → ".join(progs))
    return "\n".join(lines)


def run_agent(chaos_enabled=True, max_cycles=12):
    """Main agent loop."""
    config = load_config()
    program_defs = config["programs"]
    phases = config["phases"]
    runner = MockRunner(program_defs)

    # Initial state
    state = {
        "available_files": {"data.mtz", "sequence.fa"},
        "current_phase": "analyze",
        "program_defs": program_defs,
        "history": [],
        "metrics_history": [],
    }

    print("\n" + "=" * 60)
    print("  TUTORIAL AGENT — %s" % (
        "CHAOS MODE (failures injected)" if chaos_enabled
        else "PERFECT MODE (scripted decisions)"))
    print("=" * 60)
    print("\nStarting files: data.mtz, sequence.fa")
    print("Goal: analyze → find_model → place → refine → validate\n")

    # Scorecard counters
    score = {"llm_correct": 0, "corrected": 0, "blocked": 0, "exec_fail": 0}

    for cycle in range(1, max_cycles + 1):
        if state["current_phase"] == "done":
            print("\n\033[32m★ Pipeline complete! ★\033[0m\n")
            break

        print("─" * 60)
        print("CYCLE %d" % cycle)
        print("─" * 60)
        print("\nCurrent state:")
        print(format_state_summary(state))

        # ── Get LLM decision ──
        decision = get_decision(cycle, chaos_enabled)
        chaos_tag = decision.pop("_chaos_tag", None)
        chaos_desc = decision.pop("_chaos_desc", None)

        print("\nLLM says: run '%s'" % decision["program"])
        reasoning = decision.get("reasoning", "")
        wrapped = textwrap.fill(reasoning, width=56, initial_indent="  Reasoning: ",
                                subsequent_indent="    ")
        print(wrapped)
        if chaos_tag:
            print("  \033[33m[CHAOS: %s — %s]\033[0m" % (chaos_tag, chaos_desc))

        # ── VALIDATE ──
        is_valid, error, corrected = validate_decision(decision, state)

        if not is_valid:
            print("\n  \033[31m✗ VALIDATOR CAUGHT: %s\033[0m" % error)
            if corrected:
                print("  \033[36m→ Corrected to: %s\033[0m" % corrected["program"])
                score["corrected"] += 1
                decision = corrected
            else:
                print("  \033[31m→ No correction available, skipping cycle\033[0m")
                score["blocked"] += 1
                state["history"].append({"program": decision["program"],
                                         "cycle": cycle, "status": "blocked"})
                state["metrics_history"].append({})
                continue
        else:
            print("\n  \033[32m✓ Validators passed\033[0m")
            score["llm_correct"] += 1

        # ── EXECUTE ──
        result = runner.execute(decision["program"], state["available_files"])
        print("\n%s" % result["log"])

        if result["success"]:
            # Update state
            for f in result["output_files"]:
                state["available_files"].add(f)
            state["history"].append({"program": decision["program"], "cycle": cycle})
            state["metrics_history"].append(result["metrics"])
            state["current_phase"] = advance_phase(
                state["current_phase"], phases, program_defs, decision["program"])
        else:
            print("  \033[31mExecution failed: %s\033[0m" % result["log"])
            score["exec_fail"] += 1
            # This passed validation but failed execution — count as LLM error
            score["llm_correct"] -= 1
            state["history"].append({"program": decision["program"],
                                     "cycle": cycle, "status": "failed"})
            state["metrics_history"].append({})

    else:
        print("\n\033[33m⚠ Reached max cycles (%d) without completing!\033[0m\n"
              % max_cycles)

    # Final summary
    print("=" * 60)
    print("FINAL STATE")
    print("=" * 60)
    print(format_state_summary(state))

    # Scorecard
    total = score["llm_correct"] + score["corrected"] + score["blocked"] + score["exec_fail"]
    if total > 0:
        print("\n" + "─" * 60)
        print("SCORECARD")
        print("─" * 60)
        print("  LLM correct:        %d / %d" % (score["llm_correct"], total))
        print("  Validator corrected: %d / %d" % (score["corrected"], total))
        print("  Validator blocked:   %d / %d" % (score["blocked"], total))
        if score["exec_fail"]:
            print("  Execution failed:    %d / %d  (passed validation but crashed)"
                  % (score["exec_fail"], total))
        print()


if __name__ == "__main__":
    chaos = "--no-chaos" not in sys.argv
    max_c = 12
    for arg in sys.argv[1:]:
        if arg.startswith("--max="):
            max_c = int(arg.split("=")[1])
    run_agent(chaos_enabled=chaos, max_cycles=max_c)
