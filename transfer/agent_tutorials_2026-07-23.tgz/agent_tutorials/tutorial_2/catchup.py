#!/usr/bin/env python3
"""
catchup.py — Catch up to a specific exercise.

If you're stuck or falling behind, this fills in the solutions
for earlier exercises so you can jump ahead.

Usage:
    python3 catchup.py 3     Fill in Exercises 1-2, start fresh at 3
    python3 catchup.py 4     Fill in Exercises 1-3, start fresh at 4
    python3 catchup.py 5     Fill in Exercises 1-4, start fresh at 5

This overwrites your validators.py — your current work will be lost!
"""

import os as _os
import sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
import safe_io  # noqa: F401  survive a non-UTF-8 terminal
import sys
import os

# Solutions for each exercise (just the function body, replacing the stub)
SOLUTIONS = {
    1: (
        '    # --- YOUR CODE HERE ---\n'
        '    return True, None  # Stub: accepts everything',
        '    # --- FILLED IN BY CATCHUP ---\n'
        '    program = decision.get("program", "")\n'
        '    if not program:\n'
        '        print("  [validate_program_name] No program specified → BLOCKED")\n'
        '        return False, "No program specified"\n'
        '    if program not in known_programs:\n'
        '        print("  [validate_program_name] \'%s\' not in system → BLOCKED" % program)\n'
        '        return False, "Unknown program \'%s\'" % program\n'
        '    print("  [validate_program_name] \'%s\' exists → OK" % program)\n'
        '    return True, None'
    ),
    2: (
        '    # --- YOUR CODE HERE ---\n'
        '    return True, []  # Stub: accepts everything',
        '    # --- FILLED IN BY CATCHUP ---\n'
        '    files = decision.get("files", {})\n'
        '    missing = []\n'
        '    for slot, filename in files.items():\n'
        '        if filename not in available_files:\n'
        '            missing.append(filename)\n'
        '    if missing:\n'
        '        print("  [validate_files_exist] Missing files: %s → BLOCKED" % missing)\n'
        '        return False, missing\n'
        '    print("  [validate_files_exist] All %d files present → OK" % len(files))\n'
        '    return True, []'
    ),
    3: (
        '    # --- YOUR CODE HERE ---\n'
        '    return True, None, None  # Stub: accepts everything',
        '    # --- FILLED IN BY CATCHUP ---\n'
        '    program = decision.get("program", "")\n'
        '    defn = program_defs.get(program)\n'
        '    if defn is None:\n'
        '        print("  [validate_workflow_order] \'%s\' not found → BLOCKED" % program)\n'
        '        return False, "Unknown program \'%s\'" % program, None\n'
        '    if current_phase not in defn["valid_phases"]:\n'
        '        suggestion = None\n'
        '        for name, d in program_defs.items():\n'
        '            if current_phase in d["valid_phases"]:\n'
        '                suggestion = name\n'
        '                break\n'
        '        print("  [validate_workflow_order] \'%s\' not valid in \'%s\' → CORRECTED to \'%s\'"\n'
        '              % (program, current_phase, suggestion))\n'
        '        return (False,\n'
        '                "\'%s\' not valid in \'%s\' phase" % (program, current_phase),\n'
        '                suggestion)\n'
        '    print("  [validate_workflow_order] \'%s\' valid in \'%s\' phase → OK"\n'
        '          % (program, current_phase))\n'
        '    return True, None, None'
    ),
    4: (
        '    # --- YOUR CODE HERE ---\n'
        '    return False, None  # Stub: never detects loops',
        '    # --- FILLED IN BY CATCHUP ---\n'
        '    program = decision.get("program", "")\n'
        '    if len(history) >= 3:\n'
        '        last_three = [h["program"] for h in history[-3:]]\n'
        '        if all(p == program for p in last_three):\n'
        '            print("  [validate_no_loop] \'%s\' ran 3 times consecutively → LOOP" % program)\n'
        '            return True, "%s has run 3 times consecutively" % program\n'
        '    if len(history) >= 2 and len(metrics_history) >= 2:\n'
        '        recent_rfree = []\n'
        '        for i in range(len(history) - 1, -1, -1):\n'
        '            if history[i]["program"] == program:\n'
        '                m = metrics_history[i] if i < len(metrics_history) else {}\n'
        '                if "r_free" in m:\n'
        '                    recent_rfree.append(m["r_free"])\n'
        '            if len(recent_rfree) >= 2:\n'
        '                break\n'
        '        if len(recent_rfree) >= 2:\n'
        '            improvement = recent_rfree[1] - recent_rfree[0]\n'
        '            if abs(improvement) < 0.005:\n'
        '                print("  [validate_no_loop] R-free plateau (%.4f < 0.005) → LOOP"\n'
        '                      % abs(improvement))\n'
        '                return True, "R-free plateau: improvement %.4f < 0.005" % abs(improvement)\n'
        '    print("  [validate_no_loop] No loop detected → OK")\n'
        '    return False, None'
    ),
}


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in "2345":
        print("Usage: python3 catchup.py N")
        print("  Fills in Exercises 1 through N-1, so you start fresh at N.")
        print("  N can be 2, 3, 4, or 5.")
        sys.exit(1)

    target = int(sys.argv[1])

    with open("validators.py", "r") as f:
        content = f.read()

    filled = 0
    for ex in range(1, target):
        old, new = SOLUTIONS[ex]
        if old in content:
            content = content.replace(old, new)
            filled += 1
        elif "FILLED IN BY CATCHUP" in new.split("\n")[0] and new.split("\n")[0] in content:
            pass  # Already filled
        else:
            # Student may have their own implementation — leave it
            pass

    with open("validators.py", "w") as f:
        f.write(content)

    print("Filled in Exercises 1-%d. You're ready for Exercise %d." % (target - 1, target))
    print("Run: python3 test_validators.py %d" % target)


if __name__ == "__main__":
    main()
