"""
validators_complete.py — Fully working reference solution.

If you get stuck, you can copy this file over validators.py:
    cp solutions/validators_complete.py validators.py

Or compare it with your code to find differences.
"""


# =====================================================================
# EXERCISE 1: Is this even a real program?
# =====================================================================

def validate_program_name(decision, known_programs):
    """Check if the LLM chose a program that actually exists."""
    program = decision.get("program", "")
    if not program:
        print("  [validate_program_name] No program specified → BLOCKED")
        return False, "No program specified"
    if program not in known_programs:
        print("  [validate_program_name] '%s' not in system → BLOCKED" % program)
        return False, "Unknown program '%s'" % program
    print("  [validate_program_name] '%s' exists → OK" % program)
    return True, None


# =====================================================================
# EXERCISE 2: Do the input files exist?
# =====================================================================

def validate_files_exist(decision, available_files):
    """Check if every file the LLM referenced is actually available."""
    files = decision.get("files", {})
    missing = []
    for slot, filename in files.items():
        if filename not in available_files:
            missing.append(filename)
    if missing:
        print("  [validate_files_exist] Missing files: %s → BLOCKED" % missing)
        return False, missing
    print("  [validate_files_exist] All %d files present → OK" % len(files))
    return True, []


# =====================================================================
# EXERCISE 3: Is this allowed right now?
# =====================================================================

def validate_workflow_order(decision, current_phase, program_defs):
    """Check if the chosen program is valid in the current workflow phase."""
    program = decision.get("program", "")
    defn = program_defs.get(program)
    if defn is None:
        print("  [validate_workflow_order] '%s' not found → BLOCKED" % program)
        return False, "Unknown program '%s'" % program, None

    if current_phase not in defn["valid_phases"]:
        # Find a program that IS valid for the current phase
        suggestion = None
        for name, d in program_defs.items():
            if current_phase in d["valid_phases"]:
                suggestion = name
                break
        print("  [validate_workflow_order] '%s' not valid in '%s' → CORRECTED to '%s'"
              % (program, current_phase, suggestion))
        return (False,
                "'%s' not valid in '%s' phase" % (program, current_phase),
                suggestion)

    print("  [validate_workflow_order] '%s' valid in '%s' phase → OK"
          % (program, current_phase))
    return True, None, None


# =====================================================================
# EXERCISE 4: Are we going in circles?
# =====================================================================

def validate_no_loop(decision, history, metrics_history):
    """Detect if the agent is stuck in a loop."""
    program = decision.get("program", "")

    # Check 1: Repetition — same program 3+ times consecutively
    if len(history) >= 3:
        last_three = [h["program"] for h in history[-3:]]
        if all(p == program for p in last_three):
            print("  [validate_no_loop] '%s' ran 3 times consecutively → LOOP" % program)
            return True, "%s has run 3 times consecutively" % program

    # Check 2: Plateau — R-free barely improving
    if len(history) >= 2 and len(metrics_history) >= 2:
        # Find last two R-free values for the same program
        recent_rfree = []
        for i in range(len(history) - 1, -1, -1):
            if history[i]["program"] == program:
                m = metrics_history[i] if i < len(metrics_history) else {}
                if "r_free" in m:
                    recent_rfree.append(m["r_free"])
            if len(recent_rfree) >= 2:
                break

        if len(recent_rfree) >= 2:
            improvement = recent_rfree[1] - recent_rfree[0]
            if abs(improvement) < 0.005:
                print("  [validate_no_loop] R-free plateau (%.4f < 0.005) → LOOP"
                      % abs(improvement))
                return True, "R-free plateau: improvement %.4f < 0.005" % abs(improvement)

    print("  [validate_no_loop] No loop detected → OK")
    return False, None


# =====================================================================
# EXERCISE 5: Put them in the right order
# =====================================================================

def validate_decision(decision, state):
    """
    Run all validators and return the first failure.

    Correct order: A (name) → C (workflow) → B (files) → D (loop)

    Workflow must come before files because workflow can suggest
    corrections, but files can only reject.
    """
    progs = state["program_defs"]

    # ── Block A: check program name ──
    ok, err = validate_program_name(decision, progs)
    if not ok:
        return False, err, None

    # ── Block C: check workflow order ──  (BEFORE files!)
    ok, err, suggestion = validate_workflow_order(
        decision, state["current_phase"], progs)
    if not ok:
        corrected = None
        if suggestion:
            corrected = {"program": suggestion, "files": {},
                         "reasoning": "Corrected: " + err}
        return False, err, corrected

    # ── Block B: check files exist ──
    ok, missing = validate_files_exist(decision, state["available_files"])
    if not ok:
        return False, "Missing files: %s" % ", ".join(missing), None

    # ── Block D: check for loops ──
    is_looping, reason = validate_no_loop(
        decision, state["history"], state["metrics_history"])
    if is_looping:
        corrected = {"program": "validate", "files": {},
                     "reasoning": "Loop detected: " + reason}
        return False, reason, corrected

    return True, None, None
