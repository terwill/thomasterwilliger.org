"""
test_validators.py — Test your validator implementations.

Run after each exercise:
    python3 test_validators.py           # all tests
    python3 test_validators.py 1         # exercise 1 only
    python3 test_validators.py 2         # exercise 2 only
    ...
"""

import os as _os
import sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
import safe_io  # noqa: F401  survive a non-UTF-8 terminal
import sys
import json
from validators import (
    validate_program_name,
    validate_files_exist,
    validate_workflow_order,
    validate_no_loop,
    validate_decision,
)


def load_programs():
    with open("programs.json", "r") as f:
        data = json.load(f)
    return data["programs"]


PASS = 0
FAIL = 0


def check(name, got, expected):
    global PASS, FAIL
    if got == expected:
        PASS += 1
        print("  \033[32mPASS\033[0m: %s" % name)
    else:
        FAIL += 1
        print("  \033[31mFAIL\033[0m: %s" % name)
        print("        expected: %s" % repr(expected))
        print("             got: %s" % repr(got))


# =================================================================
# EXERCISE 1 TESTS
# =================================================================

def test_exercise_1():
    print("\n--- Exercise 1: validate_program_name ---")
    progs = load_programs()

    # Valid program
    ok, err = validate_program_name({"program": "refine"}, progs)
    check("'refine' is valid", (ok, err), (True, None))

    # Valid program
    ok, err = validate_program_name({"program": "analyze_data"}, progs)
    check("'analyze_data' is valid", (ok, err), (True, None))

    # Hallucinated program name (invented, not in registry)
    ok, err = validate_program_name({"program": "refine_model"}, progs)
    check("'refine_model' is invalid", ok, False)

    # Completely made up
    ok, err = validate_program_name({"program": "optimize_structure"}, progs)
    check("'optimize_structure' is invalid", ok, False)

    # Empty
    ok, err = validate_program_name({"program": ""}, progs)
    check("empty string is invalid", ok, False)

    # Missing key
    ok, err = validate_program_name({}, progs)
    check("missing 'program' key is invalid", ok, False)


# =================================================================
# EXERCISE 2 TESTS
# =================================================================

def test_exercise_2():
    print("\n--- Exercise 2: validate_files_exist ---")

    available = {"data.mtz", "sequence.fa", "placed_model.pdb"}

    # All files exist
    decision = {"program": "refine", "files": {"model": "placed_model.pdb", "data": "data.mtz"}}
    ok, missing = validate_files_exist(decision, available)
    check("all files present", (ok, missing), (True, []))

    # One file missing
    decision = {"program": "validate", "files": {"model": "refined_model.pdb"}}
    ok, missing = validate_files_exist(decision, available)
    check("refined_model.pdb missing", ok, False)
    check("reports the missing file", "refined_model.pdb" in missing, True)

    # Multiple files missing
    decision = {"program": "refine", "files": {"model": "best.pdb", "data": "scaled.mtz"}}
    ok, missing = validate_files_exist(decision, available)
    check("two files missing", ok, False)
    check("reports both missing", len(missing), 2)

    # No files in decision (edge case)
    decision = {"program": "analyze_data", "files": {}}
    ok, missing = validate_files_exist(decision, available)
    check("empty files dict is valid", (ok, missing), (True, []))


# =================================================================
# EXERCISE 3 TESTS
# =================================================================

def test_exercise_3():
    print("\n--- Exercise 3: validate_workflow_order ---")
    progs = load_programs()

    # Valid: analyze in analyze phase
    ok, err, sug = validate_workflow_order(
        {"program": "analyze_data"}, "analyze", progs)
    check("analyze_data in analyze phase", ok, True)

    # Invalid: refine in find_model phase
    ok, err, sug = validate_workflow_order(
        {"program": "refine"}, "find_model", progs)
    check("refine blocked in find_model phase", ok, False)
    check("suggests a valid program", sug is not None, True)

    # Valid: validate in refine phase (allowed — so loop detector can suggest it)
    ok, err, sug = validate_workflow_order(
        {"program": "validate"}, "refine", progs)
    check("validate allowed in refine phase", ok, True)

    # Valid: refine in refine phase
    ok, err, sug = validate_workflow_order(
        {"program": "refine"}, "refine", progs)
    check("refine in refine phase", ok, True)

    # Valid: place_model in place_model phase
    ok, err, sug = validate_workflow_order(
        {"program": "place_model"}, "place_model", progs)
    check("place_model in place_model phase", ok, True)


# =================================================================
# EXERCISE 4 TESTS
# =================================================================

def test_exercise_4():
    print("\n--- Exercise 4: validate_no_loop ---")

    # Not a loop — only 1 previous refine
    ok, reason = validate_no_loop(
        {"program": "refine"},
        [{"program": "analyze_data", "cycle": 1},
         {"program": "refine", "cycle": 2}],
        [{}, {"r_free": 0.32}])
    check("2 total refines — not a loop", ok, False)

    # Repetition loop — 3 consecutive refines, about to do 4th
    ok, reason = validate_no_loop(
        {"program": "refine"},
        [{"program": "place_model", "cycle": 1},
         {"program": "refine", "cycle": 2},
         {"program": "refine", "cycle": 3},
         {"program": "refine", "cycle": 4}],
        [{}, {"r_free": 0.32}, {"r_free": 0.28}, {"r_free": 0.26}])
    check("3 consecutive refines — is a loop", ok, True)

    # Plateau — R-free barely moving
    ok, reason = validate_no_loop(
        {"program": "refine"},
        [{"program": "refine", "cycle": 1},
         {"program": "refine", "cycle": 2}],
        [{"r_free": 0.262}, {"r_free": 0.259}])
    check("R-free plateau (0.003 < 0.005)", ok, True)

    # Still improving — not a plateau
    ok, reason = validate_no_loop(
        {"program": "refine"},
        [{"program": "refine", "cycle": 1},
         {"program": "refine", "cycle": 2}],
        [{"r_free": 0.32}, {"r_free": 0.28}])
    check("R-free improving (0.04 > 0.005)", ok, False)

    # Different programs — not consecutive
    ok, reason = validate_no_loop(
        {"program": "refine"},
        [{"program": "refine", "cycle": 1},
         {"program": "analyze_data", "cycle": 2},
         {"program": "refine", "cycle": 3}],
        [{"r_free": 0.32}, {}, {"r_free": 0.31}])
    check("non-consecutive refines — not a loop", ok, False)


# =================================================================
# EXERCISE 5 TESTS
# =================================================================

def test_exercise_5():
    print("\n--- Exercise 5: validate_decision (ordering) ---")
    progs = load_programs()

    # Valid decision — should pass
    state = {
        "available_files": {"data.mtz", "placed_model.pdb"},
        "current_phase": "refine",
        "program_defs": progs,
        "history": [{"program": "place_model", "cycle": 1}],
        "metrics_history": [{"r_free": 0.48}],
    }
    ok, err, corrected = validate_decision(
        {"program": "refine", "files": {"model": "placed_model.pdb"}}, state)
    check("valid decision passes", ok, True)

    # Bad program name — should fail
    ok, err, corrected = validate_decision(
        {"program": "refine_model", "files": {"model": "placed_model.pdb"}}, state)
    check("hallucinated name caught", ok, False)

    # ORDERING TEST: This decision has the wrong phase AND missing files.
    # If file-check runs first: blocked, no correction (files can't suggest)
    # If workflow-check runs first: caught, corrected to phaser ← CORRECT
    state2 = {
        "available_files": {"data.mtz", "sequence.fa"},
        "current_phase": "find_model",
        "program_defs": progs,
        "history": [{"program": "analyze_data", "cycle": 1}],
        "metrics_history": [{}],
    }
    ok, err, corrected = validate_decision(
        {"program": "refine", "files": {"model": "placed_model.pdb"}}, state2)
    check("wrong phase + missing files: caught", ok, False)
    check("ORDERING: correction suggested (workflow before files?)",
          corrected is not None, True)

    # Loop detection
    state3 = {
        "available_files": {"data.mtz", "placed_model.pdb", "refined_model.pdb"},
        "current_phase": "refine",
        "program_defs": progs,
        "history": [
            {"program": "refine", "cycle": 1},
            {"program": "refine", "cycle": 2},
            {"program": "refine", "cycle": 3},
        ],
        "metrics_history": [
            {"r_free": 0.30},
            {"r_free": 0.268},
            {"r_free": 0.265},
        ],
    }
    ok, err, corrected = validate_decision(
        {"program": "refine", "files": {"model": "refined_model.pdb"}}, state3)
    check("loop caught", ok, False)
    check("suggests validate", corrected is not None, True)


# =================================================================
# SUMMARIES — What works now that didn't before
# =================================================================

EXERCISE_SUMMARIES = {
    1: """
\033[36m╔══════════════════════════════════════════════════════════╗
║  EXERCISE 1 COMPLETE: validate_program_name              ║
╠══════════════════════════════════════════════════════════╣
║                                                          ║
║  What you built:                                         ║
║    A validator that catches hallucinated program names.   ║
║                                                          ║
║  What works now:                                         ║
║    ✓ 'refine' and 'analyze_data' → accepted              ║
║    ✓ 'refine_model' (invented name) → BLOCKED            ║
║    ✓ 'optimize_structure' (invented name) → BLOCKED      ║
║    ✓ Empty strings and missing keys → BLOCKED            ║
║                                                          ║
║  Before this exercise:                                   ║
║    ✗ ALL program names were accepted, even fake ones      ║
║    ✗ The agent tried to run 'find_model' (not a          ║
║      real program); the real one is phenix.phaser        ║
║                                                          ║
║  Next: python3 test_validators.py 2                      ║
╚══════════════════════════════════════════════════════════╝\033[0m""",
    2: """
\033[36m╔══════════════════════════════════════════════════════════╗
║  EXERCISE 2 COMPLETE: validate_files_exist               ║
╠══════════════════════════════════════════════════════════╣
║                                                          ║
║  What you built:                                         ║
║    A validator that catches references to missing files.  ║
║                                                          ║
║  What works now:                                         ║
║    ✓ References to existing files → accepted              ║
║    ✓ 'best_model.pdb' (invented filename) → BLOCKED      ║
║    ✓ 'refined_model.pdb' (not yet created) → BLOCKED     ║
║    ✓ Reports exactly WHICH files are missing              ║
║                                                          ║
║  Before this exercise:                                   ║
║    ✗ ALL file references were accepted, even fake ones    ║
║    ✗ The agent tried to use 'best_model.pdb' and         ║
║      crashed because the file didn't exist               ║
║                                                          ║
║  Note: Validators 1-2 can only say "no." They can't      ║
║  suggest what to do instead. That changes next.          ║
║                                                          ║
║  Next: python3 test_validators.py 3                      ║
╚══════════════════════════════════════════════════════════╝\033[0m""",
    3: """
\033[36m╔══════════════════════════════════════════════════════════╗
║  EXERCISE 3 COMPLETE: validate_workflow_order            ║
╠══════════════════════════════════════════════════════════╣
║                                                          ║
║  What you built:                                         ║
║    A validator that catches wrong-phase programs AND      ║
║    suggests the correct program to run instead.          ║
║                                                          ║
║  What works now:                                         ║
║    ✓ 'analyze_data' in analyze phase → accepted          ║
║    ✓ 'refine' in find_model phase → CORRECTED to         ║
║      'phaser' (the right program for that phase)         ║
║    ✓ 'analyze_data' in refine phase → CORRECTED          ║
║                                                          ║
║  The big shift:                                          ║
║    Exercises 1-2 could only REJECT bad decisions.        ║
║    Exercise 3 can CORRECT them — it says "try this       ║
║    instead." That's the difference between a guard       ║
║    rail and a co-pilot.                                  ║
║                                                          ║
║  Next: python3 test_validators.py 4                      ║
╚══════════════════════════════════════════════════════════╝\033[0m""",
    4: """
\033[36m╔══════════════════════════════════════════════════════════╗
║  EXERCISE 4 COMPLETE: validate_no_loop                   ║
╠══════════════════════════════════════════════════════════╣
║                                                          ║
║  What you built:                                         ║
║    A convergence detector that catches infinite loops.    ║
║                                                          ║
║  What works now:                                         ║
║    ✓ 3+ consecutive runs of same program → LOOP          ║
║    ✓ R-free improvement < 0.005 → PLATEAU detected       ║
║    ✓ Active improvement (R-free dropping) → allowed      ║
║    ✓ Non-consecutive runs → not flagged as a loop        ║
║                                                          ║
║  Before this exercise:                                   ║
║    ✗ The LLM kept saying "one more cycle" forever         ║
║    ✗ R-free plateaued at 0.24 but refinement continued   ║
║    ✗ No way to detect convergence and stop               ║
║                                                          ║
║  Try it: python3 run_agent.py --no-chaos --max=10        ║
║  (Compare before and after implementing this validator)  ║
║                                                          ║
║  Next: python3 test_validators.py 5                      ║
╚══════════════════════════════════════════════════════════╝\033[0m""",
    5: """
\033[36m╔══════════════════════════════════════════════════════════╗
║  EXERCISE 5 COMPLETE: validate_decision (ordering)       ║
╠══════════════════════════════════════════════════════════╣
║                                                          ║
║  What you fixed:                                         ║
║    The validator execution order — workflow checks must   ║
║    run BEFORE file checks so corrections aren't lost.    ║
║                                                          ║
║  What works now:                                         ║
║    ✓ Valid decisions pass all validators                  ║
║    ✓ Hallucinated names → blocked (Block A)              ║
║    ✓ Wrong phase → CORRECTED to right program (Block C)  ║
║    ✓ Missing files → blocked (Block B)                   ║
║    ✓ Infinite loops → CORRECTED to 'validate' (Block D)  ║
║    ✓ Wrong phase + missing files → CORRECTED (not just   ║
║      blocked), because workflow check runs first         ║
║                                                          ║
║  The lesson:                                             ║
║    Validator order = A (name) → C (workflow) → B (files)  ║
║    → D (loop). Validators that can CORRECT must run      ║
║    before validators that can only REJECT.               ║
║                                                          ║
║  ALL EXERCISES COMPLETE! Now run the full agent:         ║
║    python3 test_validators.py   (all 29 tests)           ║
║    python3 run_agent.py         (watch it complete!)     ║
╚══════════════════════════════════════════════════════════╝\033[0m""",
}


# =================================================================
# MAIN
# =================================================================

if __name__ == "__main__":
    exercise = int(sys.argv[1]) if len(sys.argv) > 1 else 0

    tests = {
        1: test_exercise_1,
        2: test_exercise_2,
        3: test_exercise_3,
        4: test_exercise_4,
        5: test_exercise_5,
    }

    if exercise:
        tests[exercise]()
    else:
        for t in tests.values():
            t()

    print("\n" + "=" * 40)
    total = PASS + FAIL
    if FAIL == 0:
        print("\033[32mAll %d tests passed!\033[0m" % total)
        if exercise and exercise in EXERCISE_SUMMARIES:
            print(EXERCISE_SUMMARIES[exercise])
        elif exercise == 0:
            print(EXERCISE_SUMMARIES[5])
    else:
        print("\033[31m%d passed, %d failed\033[0m" % (PASS, FAIL))
        print("\nFix the failing tests in validators.py, then re-run:")
        if exercise:
            print("  python3 test_validators.py %d" % exercise)
        else:
            print("  python3 test_validators.py")
    print("=" * 40)
