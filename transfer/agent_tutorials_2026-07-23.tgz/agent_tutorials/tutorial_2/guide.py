"""
guide.py — Tutorial 2, guided walkthrough.

    python3 guide.py
"""

import os as _os
import sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
import safe_io  # noqa: F401  survive a non-UTF-8 terminal
import contextlib
import io
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from guide_engine import (Guide, main, fresh, run_exercise_tests,   # noqa: E402
                          run_filtered, said, GRN, RED, YEL, BOLD, RST, DIM)

HERE = os.path.dirname(os.path.abspath(__file__))
CFG = json.load(open(os.path.join(HERE, "programs.json")))
PROGS = CFG["programs"]

sys.path.insert(0, HERE)
from chaos_mode import (INJECTED_FAILURES,  # noqa: E402  the LLM's own words
                        SCRIPTED_DECISIONS)

STATE = {"available_files": {"data.mtz", "sequence.fa", "placed_model.pdb"},
         "current_phase": "refine", "program_defs": PROGS,
         "history": [], "metrics_history": []}


def quiet(fn, *a):
    with contextlib.redirect_stdout(io.StringIO()):
        return fn(*a)


CHECKS = {
    1: "unknown names, invented programs, empty",
    2: "missing files, files not yet produced",
    3: "wrong phase, out-of-order steps",
    4: "repeats, plateaus, no-progress loops",
    5: "the order the validators must run in",
}


def _looping_reason():
    """The LLM's actual words on the last refine of the loop. Not paraphrased —
    it really does say 'it can't hurt to run one final cycle'."""
    refines = [d for d in SCRIPTED_DECISIONS if d.get("program") == "refine"]
    return refines[-1].get("reasoning", "") if refines else ""


def _tests(g, n):
    p, f = run_exercise_tests(g.test_file, n, cwd=g.cwd)
    if f == 0 and p > 0:
        return "  %s✓ %d checks: %s%s" % (GRN, p, CHECKS.get(n, ""), RST)
    return "  %s✗ %d passed, %d FAILED%s" % (RED, p, f, RST)


# ══════════════════════════════════════════════════════════ RUN bodies

def s3_body(g):
    hits = run_filtered(["run_agent.py", "--max=6"],
                        [r"Execution failed", r"Unknown program",
                         r"Missing required"], cwd=g.cwd, limit=3)
    return ([
        "  The LLM proposes. The agent runs it. No questions.",
        "",
    ] + ["    %s%s%s" % (DIM, h[:52], RST) for h in hits] + [
        "",
        "  Those got through because %snothing checked them%s." % (YEL, RST),
        "  validators.py is empty — there is no trust boundary,",
        "  so whatever the LLM says goes straight to the tools.",
    ])


def s5_body(g):
    m = fresh("validators")
    d = INJECTED_FAILURES[2]
    ok, err = quiet(m.validate_program_name, d, PROGS)
    verdict = ("    %s⚠ ALLOWED THROUGH — your check missed it%s" % (RED, RST)
               if ok else "    %s✗ BLOCKED — %s%s" % (YEL, err, RST))
    return ([
        "  %sCycle 2. The LLM says:%s" % (BOLD, RST),
        "",
    ] + said(d["reasoning"]) + [
        "",
        "    → %s%s%s" % (YEL, d["program"], RST),
        "",
        verdict,
        "",
        "  The reasoning is fine! The NAME is invented. There is",
        "  no find_model program — that is the phase; the real",
        "  MR program is phenix.phaser. Same failure as Tut 1.",
        "",
        _tests(g, 1),
    ])


def s7_body(g):
    m = fresh("validators")
    d = INJECTED_FAILURES[7]
    ok, missing = quiet(m.validate_files_exist, d, STATE["available_files"])
    verdict = ("    %s⚠ ALLOWED THROUGH — your check missed it%s" % (RED, RST)
               if ok else "    %s✗ BLOCKED — no such file: %s%s"
               % (YEL, ", ".join(missing), RST))
    return ([
        "  %sCycle 7. The LLM says:%s" % (BOLD, RST),
        "",
    ] + said(d["reasoning"]) + [
        "",
        "    → refine   model = %s%s%s" % (YEL, d["files"].get("model"), RST),
        "",
        verdict,
        "",
        "  We have data.mtz, sequence.fa, placed_model.pdb.",
        "  It invented a filename that SOUNDS right. It has no",
        "  filesystem — it is guessing, confidently.",
        "",
        _tests(g, 2),
    ])


def s9_body(g):
    m = fresh("validators")
    d = INJECTED_FAILURES[5]
    ok, err, fix = quiet(m.validate_workflow_order, d, "refine", PROGS)
    lines = ([("    %s⚠ ALLOWED THROUGH — your check missed it%s" % (RED, RST))]
             if ok else
             ["    %s✗ not valid in the 'refine' phase%s" % (YEL, RST),
              "    %s→ CORRECTED to: %s%s" % (GRN, fix or "—", RST)])
    return ([
        "  %sCycle 5, in the refine phase. The LLM says:%s" % (BOLD, RST),
        "",
    ] + said(d["reasoning"]) + [
        "",
        "    → %s%s%s" % (YEL, d["program"], RST),
        "",
    ] + lines + [
        "",
        "  It is not wrong, exactly. It is going %sBACKWARDS%s." % (BOLD, RST),
        "  Note this one does not block — it %scorrects%s." % (GRN, RST),
        "",
        _tests(g, 3),
    ])


def s11_body(g):
    m = fresh("validators")
    hist = [{"program": "refine"}] * 3
    mets = [{"r_free": 0.24}] * 3
    is_loop, why = quiet(m.validate_no_loop, {"program": "refine"}, hist, mets)
    # Report what the STUDENT'S code actually decided — not what we hope it did.
    verdict = ("    %s✗ LOOP: %s%s" % (YEL, why, RST) if is_loop
               else "    %s… no loop detected%s" % (DIM, RST))
    return ([
        "  R-free:  0.48 → 0.28 → 0.2554 → %s0.24 → 0.24 → 0.24%s" % (YEL, RST),
        "",
        "  %sThe LLM says, for the third time:%s" % (BOLD, RST),
        "",
    ] + said(_looping_reason()) + [
        "",
        "    → %srefine%s" % (YEL, RST),
        "",
        verdict,
        "",
        "  It cannot see that nothing is improving. It has no",
        "  memory. %sOnly your code can notice.%s" % (BOLD, RST),
        "",
        _tests(g, 4),
    ])


def s13_body(g):
    """Show every intervention: which check fired, and what it did."""
    import re as _re
    import subprocess
    from guide_engine import _utf8_env
    p = subprocess.run([sys.executable, "run_agent.py"], cwd=g.cwd,
                       capture_output=True, timeout=120, env=_utf8_env())
    txt = _re.sub(r"\033\[[0-9;]*m", "",
                  (p.stdout + p.stderr).decode("utf-8", "replace"))
    acts = []
    for line in txt.splitlines():
        m = _re.search(r"\[validate_(\w+)\].*?→ (BLOCKED|CORRECTED to '([^']*)')",
                       line)
        if m:
            which = {"program_name": "name", "workflow_order": "order",
                     "files_exist": "files", "no_loop": "loop"}.get(m.group(1),
                                                                    m.group(1))
            if m.group(2) == "BLOCKED":
                acts.append("%-7s %sBLOCKED%s" % (which, YEL, RST))
            else:
                acts.append("%-7s corrected → %s" % (which, m.group(3)))
    hits = run_filtered(["run_agent.py"],
                        [r"LLM correct", r"Validator corrected",
                         r"Validator blocked"], cwd=g.cwd, limit=3)
    return ([
        "  Every time your boundary fired:",
        "",
    ] + ["    %s" % a for a in acts[:6]] + [
        "",
    ] + ["    %s" % h for h in hits] + [
        "",
        "  The LLM got 2 of 9 right. Your validators caught the",
        "  other 7. %sThe LLM did not get better — the system did.%s" % (BOLD, RST),
        _tests(g, 5),
    ])


# ══════════════════════════════════════════════════════════════ steps

STEPS = [
    dict(n=1, kind="IDEA", title="OVERVIEW — one line is not a boundary", body=[
        "  Tutorial 1's entire trust boundary was one line:",
        "",
        "      %sif d.program in valid%s" % (YEL, RST),
        "  It checked the NAME — and let through a file that did",
        "  not exist, and never saw refine → refine → refine.",
        "",
        "  THE JOB — a real boundary:",

        "     name   does the program exist?    (T1 had this)",
        "     %sfiles  do the inputs exist?       (T1 did NOT)%s" % (GRN, RST),
        "     %sorder  legal in this phase?       (T1 half-did)%s" % (GRN, RST),
        "     %sloop   going in circles?          (T1 did NOT)%s" % (GRN, RST),
        "",
        "  %sStill simulated:%s these LLM mistakes are scripted" % (YEL, RST),
        "  replays of ones real LLMs make. A real run in T3.",
        "",
        "  13 steps.   YOU FILL IN: validators.py",
    ], prompt="[Enter] to see the boundary's real job"),

    dict(n=2, kind="IDEA", title="where the boundary goes", body=[
        "      for cycle in range(12):",
        "          d = decide(state)            ← Tutorial 1",
        "",
        "          ok, err, fix = %svalidate_decision(d)%s  ← HERE" % (YEL, RST),
        "          if not ok:",
        "              d = fix                  ← CORRECT it, or",
        "              if d is None: continue   ← block it",
        "",
        "          result = run_program(d)",
        "",
        "  Note what is new. Tutorial 1's check could only ACCEPT",
        "  or DISCARD — reject the LLM and fall back to rules,",
        "  throwing its reasoning away.",
        "",
        "  A real boundary can %scorrect%s. Everything above that call" % (BOLD, RST),
        "  is a suggestion. Everything below it is an action.",
    ], prompt="[Enter] to run the agent with NO boundary"),

    dict(n=3, kind="RUN", title="no boundary — the LLM runs wild", body=s3_body,
         prompt="[Enter] to build the first check"),

    dict(n=4, kind="IDEA", title="validate_program_name",
         fill="validate_program_name", body=[
        "  THE GOAL",
        "    Does this program actually exist?",
        "",
        "  The LLM keeps proposing %sfind_model%s — that is the" % (YEL, RST),
        "  phase name, not a program. The real MR program is",
        "  %sphenix.phaser%s. It named the goal, not the tool." % (GRN, RST),
        "",
        "  THE IDEA                     full code → validators.py",
        "",
        "      if decision['program'] not in known_programs:",
        "          return False, \"unknown program\", None",
        "",
        "  Every validator returns the same 3 things:",
        "      (ok, why_not, a_corrected_decision_or_None)",
    ], prompt="[Enter] to try it on the LLM's proposal"),

    dict(n=5, kind="RUN", title="the name check", body=s5_body),

    dict(n=6, kind="IDEA", title="validate_files_exist",
         fill="validate_files_exist", body=[
        "  THE GOAL",
        "    Does every file it named actually exist?",
        "",
        "  An LLM will happily reference %sbest_model.pdb%s because" % (YEL, RST),
        "  that is what a good file would be called. It has no",
        "  filesystem. It is guessing.",
        "",
        "  THE IDEA                     full code → validators.py",
        "",
        "      for f in decision['files'].values():",
        "          if f not in available_files:",
        "              return False, \"missing: \" + f, None",
        "",
        "  Cheap, boring, and it prevents a crash every time.",
    ], prompt="[Enter] to try it"),

    dict(n=7, kind="RUN", title="the file check", body=s7_body),

    dict(n=8, kind="IDEA", title="validate_workflow_order",
         fill="validate_workflow_order", body=[
        "  THE GOAL",
        "    Is this step legal in the phase we are in?",
        "",
        "  Mid-refinement the LLM will suggest re-analyzing the",
        "  data. It sounds reasonable. It is going BACKWARDS.",
        "",
        "  THE IDEA                     full code → validators.py",
        "",
        "      if phase not in defn['valid_phases']:",
        "          fix = first_valid_program(phase)",
        "          return False, \"wrong phase\", fix   ← CORRECT it",
        "",
        "  Note: this one does not just block. It %sproposes a fix%s." % (BOLD, RST),
        "  A good boundary corrects where it can.",
    ], prompt="[Enter] to try it"),

    dict(n=9, kind="RUN", title="the order check", body=s9_body),

    dict(n=10, kind="IDEA", title="validate_no_loop", fill="validate_no_loop",
         body=[
        "  THE GOAL",
        "    Is it going round in circles?",
        "",
        "  This is the failure that killed the LLM-only agent in",
        "  Tutorial 1: refine → refine → refine → refine, forever.",
        "",
        "  THE IDEA                     full code → validators.py",
        "",
        "      same program 3x in a row?",
        "      AND R-free has not improved?",
        "          → it is stuck. Move it on.",
        "",
        "  The LLM cannot see that it is looping. It has no",
        "  memory. Only your code can notice.",
    ], prompt="[Enter] to try it"),

    dict(n=11, kind="RUN", title="the loop check", body=s11_body),

    dict(n=12, kind="IDEA", title="validate_decision — the order matters",
         fill="validate_decision", body=[
        "  THE GOAL",
        "    Run all four — but %sNOT in the order you wrote them%s." % (BOLD, RST),
        "",
        "    you wrote them:   name → files → order → loop",
        "    you must RUN them: name → %sorder → files%s → loop" % (YEL, RST),
        "                              %s↑ swapped%s" % (YEL, RST),
        "",
        "  Why? The ORDER check can %sREWRITE%s the decision — it" % (BOLD, RST),
        "  turns analyze_data into refine. If you check the FILES",
        "  first, you are checking the files of a decision that is",
        "  about to be thrown away.",
        "",
        "  Cheap checks first. Checks that rewrite, before checks",
        "  that depend on what was rewritten.",
    ], prompt="[Enter] to run the whole agent"),

    dict(n=13, kind="RUN", title="the agent, with a trust boundary",
         body=s13_body, prompt="[Enter] to finish"),
]


if __name__ == "__main__":
    main(Guide(
        title="Tutorial 2 — Trust But Verify",
        student_file="validators.py",
        solution_file="solutions/validators_complete.py",
        test_file="test_validators.py",
        stub_file="solutions/validators_stub.py",
        steps=STEPS,
        cwd=HERE,
        outro=[
            "  Go and look at what you now own:",
            "",
            "     %sless validators.py%s      the 83 lines." % (BOLD, RST),
            "                             validate_no_loop is the",
            "                             subtle one — read it.",
            "",
            "  Then break it on purpose:",
            "",
            "     Open validators.py and in validate_decision(),",
            "     swap the order: run the FILE check before the",
            "     ORDER check. Re-run:",
            "",
            "     %spython3 run_agent.py%s",
            "",
            "     It now blocks a decision it should have CORRECTED,",
            "     because it checked files on a decision that was",
            "     about to be rewritten. Order is not cosmetic.",
            "",
            "     %spython3 guide.py --reset%s   to put it back." % (BOLD, RST),
            "",
            "  %sBut notice what you still have: the loop.%s You call" % (YEL, RST),
            "  the LLM, you check it, you decide what runs. You can",
            "  inspect every single move it makes.",
            "",
            "  In Tutorial 3 the agent takes the loop away from you.",
            "  %sYou will not see the moves any more.%s" % (BOLD, RST),
        ],
    ))
