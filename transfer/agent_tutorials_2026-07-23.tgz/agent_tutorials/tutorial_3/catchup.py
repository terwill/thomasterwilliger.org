#!/usr/bin/env python3
"""
catchup.py — Catch up to a specific exercise.

Fills in the solutions for earlier exercises so you can jump ahead.

Usage:
    python3 catchup.py 3     Fill in Exercises 1-2, start fresh at 3
    python3 catchup.py 5     Fill in Exercises 1-4, start fresh at 5
                             (Exercise 5 is a re-order — you still do it)

This overwrites your policy.py — your current work will be lost!
"""

import os as _os
import sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
import safe_io  # noqa: F401  survive a non-UTF-8 terminal
import sys

SOLUTIONS = {
    1: (
        '    # --- YOUR CODE HERE ---\n'
        '    # Stub: permissive defaults \u2014 nothing gated, nothing in scope, no\n'
        '    # rollback (tolerance huge). The agent runs UNGOVERNED until you\n'
        '    # implement this.\n'
        '    return {"r_free_tolerance": 999.0, "max_gap": 999.0, "max_iterations": 12,\n'
        '            "gated_actions": [], "in_scope_actions": []}',
        '    # --- FILLED IN BY CATCHUP ---\n'
        '    policy = {"r_free_tolerance": 999.0, "max_gap": 999.0, "max_iterations": 12,\n'
        '              "gated_actions": [], "in_scope_actions": []}\n'
        '    list_keys = ("gated_actions", "in_scope_actions")\n'
        '    for line in guideme_text.splitlines():\n'
        '        if ":" not in line:\n'
        '            continue\n'
        '        key, _, value = line.partition(":")\n'
        '        key = key.strip(); value = value.strip()\n'
        '        if key not in policy:\n'
        '            continue\n'
        '        if key in list_keys:\n'
        '            policy[key] = [p.strip() for p in value.split(",") if p.strip()]\n'
        '        elif key == "max_iterations":\n'
        '            policy[key] = int(value)\n'
        '        else:\n'
        '            policy[key] = float(value)\n'
        '    return policy'
    ),
    2: (
        '    # --- YOUR CODE HERE ---\n'
        '    return False, None  # Stub: gates nothing',
        '    # --- FILLED IN BY CATCHUP ---\n'
        '    kind = action.get("kind", "")\n'
        '    if kind in policy.get("gated_actions", []):\n'
        '        return True, "\'%s\' requires sign-off" % kind\n'
        '    if action.get("expensive"):\n'
        '        return True, "\'%s\' is expensive \u2014 needs sign-off" % kind\n'
        '    return False, None'
    ),
    3: (
        '    # --- YOUR CODE HERE ---\n'
        '    return True, None  # Stub: allows everything',
        '    # --- FILLED IN BY CATCHUP ---\n'
        '    kind = action.get("kind", "")\n'
        '    if kind == "done":\n'
        '        return True, None\n'
        '    if kind in policy.get("in_scope_actions", []):\n'
        '        return True, None\n'
        '    return False, "\'%s\' is outside the approved plan" % kind'
    ),
    4: (
        '    # --- YOUR CODE HERE ---\n'
        '    return False, None  # Stub: never rolls back (overfit slips through)',
        '    # --- FILLED IN BY CATCHUP ---\n'
        '    tol = policy.get("r_free_tolerance", 999.0)\n'
        '    max_gap = policy.get("max_gap", 999.0)\n'
        '    rise = after.get("r_free", 0) - before.get("r_free", 0)\n'
        '    gap_before = before.get("r_free", 0) - before.get("r_work", 0)\n'
        '    gap_after = after.get("r_free", 0) - after.get("r_work", 0)\n'
        '    if rise > tol:\n'
        '        return True, "R-free rose %.3f (> tolerance %.3f)" % (rise, tol)\n'
        '    if gap_after > max_gap and gap_after > gap_before:\n'
        '        return True, ("R-work/R-free gap widened %.3f -> %.3f (> %.3f)"\n'
        '                      % (gap_before, gap_after, max_gap))\n'
        '    return False, None'
    ),
}


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in "2345":
        print("Usage: python3 catchup.py N   (N = 2, 3, 4, or 5)")
        print("  Fills in Exercises 1 through N-1.")
        sys.exit(1)

    target = int(sys.argv[1])
    with open("policy.py") as f:
        content = f.read()

    for ex in range(1, target):
        old, new = SOLUTIONS[ex]
        if old in content:
            content = content.replace(old, new)

    with open("policy.py", "w") as f:
        f.write(content)

    print("Filled in Exercises 1-%d. You're ready for Exercise %d." % (target - 1, target))
    if target == 5:
        print("Exercise 5 is a re-order in pre_act — you still need to do that one.")
    print("Run: python3 test_policy.py")


if __name__ == "__main__":
    main()
