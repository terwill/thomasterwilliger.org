"""
policy.py — YOUR CODE GOES HERE

Tutorials 1 and 2 built an orchestrated agent: you wrote the loop and the
validators in code.  This is the other archetype — a SELF-DIRECTED agent.
The model drives (see transcript.py).  You don't write its loop.  You
write the POLICY that governs it: the gate, the scope check, and the
cross-validation guardrail.

This is the lecture's slide-20 lesson made hands-on: the same disciplines
as the orchestrated agent, but relocated out of a code loop and into a
system prompt (GUIDEME.md) plus a thin guardrail (this file).

Run the tests after each exercise:
    python3 test_policy.py

Run the agent to see your policy govern the model:
    python3 run_agent.py              # governed by your policy
    python3 run_agent.py --ungoverned # the model with no policy at all
    python3 run_agent.py --compare    # both, side by side
"""


# =====================================================================
# EXERCISE 1: Read the policy out of the system prompt
# =====================================================================

def load_policy(guideme_text):
    """Parse the OPERATING PARAMETERS block out of GUIDEME.md.

    The system prompt *is* configuration.  Four lines in GUIDEME.md look
    like "key: value".  Pull them into a dict the harness can use:

        r_free_tolerance : float   (e.g. 0.01)
        max_gap          : float   (e.g. 0.06)  max healthy R-work/R-free gap
        max_iterations   : int     (e.g. 12)
        gated_actions    : list    (comma-separated, e.g. extend_resolution, deposit)
        in_scope_actions : list    (comma-separated)

    Args:
        guideme_text: the full text of GUIDEME.md

    Returns:
        dict with the four keys above.

    Hint: iterate over lines; for each line that contains ":", split once
          on ":" into key/value. Convert the two list-valued keys with
          [p.strip() for p in value.split(",")]. Ignore any other lines.
    """
    # --- YOUR CODE HERE ---
    # Stub: permissive defaults — nothing gated, nothing in scope, no
    # rollback (tolerance huge). The agent runs UNGOVERNED until you
    # implement this.
    return {"r_free_tolerance": 999.0, "max_gap": 999.0, "max_iterations": 12,
            "gated_actions": [], "in_scope_actions": []}


# =====================================================================
# EXERCISE 2: The approval gate
# =====================================================================

def needs_approval(action, policy):
    """Decide whether an action needs human sign-off before it runs.

    An action needs approval if EITHER:
      - its `kind` is in policy["gated_actions"], OR
      - it is flagged expensive (action.get("expensive") is True).

    Args:
        action: an action dict from transcript.py
        policy: the dict from load_policy()

    Returns:
        tuple: (needs_gate: bool, reason: str or None)

    Examples:
        extend_resolution (in gated_actions) → (True, "...")
        refine                               → (False, None)
    """
    # --- YOUR CODE HERE ---
    return False, None  # Stub: gates nothing


# =====================================================================
# EXERCISE 3: Stay in scope
# =====================================================================

def check_scope(action, policy):
    """Block actions outside the approved plan.

    The model is creative and will sometimes propose work that is outside
    what was agreed — re-phasing, a new experiment, changing the space
    group.  An action is in scope only if its `kind` is listed in
    policy["in_scope_actions"].  Anything else is blocked and escalated.

    Note: "done" is always allowed (it just ends the run).

    Args:
        action: an action dict
        policy: the dict from load_policy()

    Returns:
        tuple: (ok: bool, reason: str or None)

    Examples:
        refine          (in scope)     → (True, None)
        new_experiment  (not in scope) → (False, "...out of scope...")
    """
    # --- YOUR CODE HERE ---
    return True, None  # Stub: allows everything


# =====================================================================
# EXERCISE 4: The cross-validation guardrail   (write this one yourself)
# =====================================================================

def should_rollback(before, after, policy):
    """Catch a change that looks like an improvement but breaks cross-validation.

    THE OBVIOUS RULE IS WRONG. The tempting rule is "roll back if R-free rose
    by more than 0.01" — and 0.01 is the RIGHT number, it is the tolerance you
    will end up using. We tried that rule against three real overfits on real
    crystallographic data. R-free rose by +0.012, by +0.004, and in one case BY
    NOTHING AT ALL — R-work crashed from 0.192 to 0.137 while R-free never
    budged. That rule catches one of the three.

    The threshold is not too big or too small. A THRESHOLD IS THE WRONG KIND OF
    RULE: no value of r_free_tolerance can catch overfit 3, because R-free did
    not move at all.

    What caught all three: **R-work fell, but R-free did not follow.** When a
    model starts fitting noise in the working set, R-work drops and the held-out
    R-free stalls or rises — so the GAP between them widens. A healthy gap at
    ~2.6 A is about 0.04-0.06; a gap past ~0.08 means overfitting.

    So roll back if EITHER:
      (a) R-free rose by more than policy["r_free_tolerance"], OR
      (b) the gap (r_free - r_work) grew beyond policy["max_gap"].

    Args:
        before: metrics before, e.g. {"r_free": 0.239, "r_work": 0.203}
        after:  metrics after,  e.g. {"r_free": 0.256, "r_work": 0.172}
        policy: from load_policy() — uses "r_free_tolerance" and "max_gap"

    Returns:
        tuple: (rollback: bool, reason: str or None)

    Examples (tol 0.01, max_gap 0.06):
        0.239/0.203 -> 0.256/0.172  gap 0.036->0.084  → (True, "...")
        0.252/0.216 -> 0.244/0.208  gap 0.036->0.036  → (False, None)  improved
        0.240/0.198 -> 0.244/0.150  gap 0.042->0.094  → (True, "...")  R-free
                                    barely moved, but R-work collapsed: OVERFIT
        0.239/0.203 -> 0.243/0.206  gap 0.036->0.037  → (False, None)  noise

    This is the heart of the tutorial — try to write it without peeking. The
    third example is the one a naive threshold gets wrong. If you get stuck:
    `python3 catchup.py 5`, or see solutions/policy_complete.py.
    """
    # --- YOUR CODE HERE ---
    return False, None  # Stub: never rolls back (overfit slips through)


# =====================================================================
# EXERCISE 5: Put the gate and the scope check in the right order
# =====================================================================

def pre_act(action, state, policy):
    """Decide what to do with a proposed action BEFORE it runs.

    Returns one of three verdicts:
        "proceed" — run it normally
        "gate"    — run it, but only after human sign-off
        "block"   — refuse it and escalate (do not run)

    The two blocks below are ALREADY WRITTEN — but in the WRONG ORDER.
    Run the tests to see what breaks:

        python3 test_policy.py 5

    Then swap the blocks so the tests pass.  Think about it: if an action
    is out of scope, should you ever bother asking a human to approve it?
    """
    if action.get("kind") == "done":
        return "proceed", None

    # ── Block G: gate expensive / listed actions ──
    gate, reason = needs_approval(action, policy)
    if gate:
        return "gate", reason

    # ── Block S: refuse out-of-scope actions ──
    ok, reason = check_scope(action, policy)
    if not ok:
        return "block", reason

    return "proceed", None
