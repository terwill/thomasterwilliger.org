"""
mock_tools.py — Simulates the tools the self-directed agent calls.

The agent's *reasoning* is real in live mode, but its *tools* are still
mocked here so the tutorial runs in seconds with no PHENIX install. (In
production you'd swap this for a real PHENIX MCP server or CLI.)

Two ways an action gets its effect:

  * SIMULATED mode replays transcript.py, where each action carries an
    explicit absolute `effect` (e.g. {"r_free": 0.239}). Used as-is.

  * LIVE / --demo mode lets the model propose arbitrary actions, so we
    compute a plausible effect from the action kind and current metrics.
    The world has a simple, deterministic "physics":
        refine            - drops R-free with diminishing returns WHILE the
                            model is still poor; but once you are near
                            convergence, further re-refinement lets ordered
                            solvent ride in and OVERFITS the free set
                            (R-work falls, R-free rises) — this is what your
                            guardrail must catch
        coot_edit         - a well-supported edit; helps, or is neutral. (Real
                            measurement on gene-5: clean rotamer fits moved
                            R-free 0.4518 -> 0.4495. Good edits don't overfit;
                            accumulating solvent does.)
        extend_resolution - small improvement
        new_experiment    - no real progress (and off-plan)
        validate / done   - no metric change
"""

REFINE_FLOOR = 0.205        # refinement can't push R-free below this
CONVERGED = 0.26            # at or below this, further refinement overfits
                            # (ordered solvent rides in and fits the free set)


def apply_action(action, before):
    """Apply an action's effect to the metrics. Returns a NEW dict."""
    after = dict(before)

    # Transcript path: explicit absolute effect.
    effect = action.get("effect")
    if effect and "r_free" in effect:
        after["r_free"] = effect["r_free"]
        after["r_work"] = effect.get("r_work", round(effect["r_free"] - 0.03, 3))
        return after
    if effect == {}:
        return after  # transcript no-op (off-plan / validate / done)

    # Live path: rule-based effect from the action kind. R-work and R-free move
    # INDEPENDENTLY — that is the whole point. Overfitting means R-work falls
    # while R-free does not follow, so the gap widens.
    kind = action.get("kind") or action.get("action")
    rf = before["r_free"]
    rw = before.get("r_work", rf - 0.035)

    if kind == "refine":
        if rf <= CONVERGED:
            # Over-refinement on thin data: R-work chases working-set noise DOWN
            # while the held-out R-free drifts UP. (Measured on real gene-5 data:
            # R-work 0.1975 -> 0.1725, R-free 0.2417 -> 0.2581, gap 0.044 -> 0.086.)
            rw = rw - 0.030
            rf = rf + 0.015
        else:
            gain = max(0.004, (rf - REFINE_FLOOR) * 0.35)
            rf = rf - gain
            rw = rw - gain * 1.1     # honest refinement: both improve together
    elif kind == "coot_edit":
        rf = rf - 0.006              # a well-supported edit helps
        rw = rw - 0.005
    elif kind == "extend_resolution":
        rf = rf - 0.004
        rw = rw - 0.004
    # new_experiment / validate / done / unknown -> no change

    after["r_free"] = round(max(rf, 0.0), 3)
    after["r_work"] = round(max(rw, 0.0), 3)
    return after


def tool_log(action, before, after):
    """Build a short, readable log line for an applied action."""
    tool = action.get("tool") or {
        "refine": "phenix.refine", "coot_edit": "coot",
        "extend_resolution": "phenix.refine", "validate": "phenix.validation",
    }.get(action.get("kind"), "—")
    parts = ["    tool: %s" % tool]
    if after.get("r_free") != before.get("r_free"):
        gb = before["r_free"] - before.get("r_work", before["r_free"])
        ga = after["r_free"] - after.get("r_work", after["r_free"])
        parts.append("    R-work: %.3f -> %.3f     R-free: %.3f -> %.3f"
                     % (before.get("r_work", 0), after.get("r_work", 0),
                        before["r_free"], after["r_free"]))
        flag = "  <-- gap widening: R-work fell but R-free did not follow" if ga > gb + 0.01 else ""
        parts.append("    gap:    %.3f -> %.3f%s" % (gb, ga, flag))
    else:
        parts.append("    R-free: %.3f (unchanged)" % before["r_free"])
    return "\n".join(parts)
