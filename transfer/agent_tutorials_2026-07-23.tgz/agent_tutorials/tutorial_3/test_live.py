"""
test_live.py — Tests for the LIVE machinery (no API key needed).

These cover the parts unique to --live mode: parsing a real model's reply,
the mock tool "physics," and the live governance loop driven by a scripted
stand-in model. Your policy work is tested separately by test_policy.py.

    python3 test_live.py
"""

import os as _os
import sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
import safe_io  # noqa: F401  survive a non-UTF-8 terminal
import sys
from live_agent import parse_action, scripted_responder, propose_action
from mock_tools import apply_action
import run_agent

PASS = 0
FAIL = 0


def check(name, got, expected):
    global PASS, FAIL
    if got == expected:
        PASS += 1
        print("  \033[32mPASS\033[0m: %s" % name)
    else:
        FAIL += 1
        print("  \033[31mFAIL\033[0m: %s" % name)
        print("        expected: %s" % repr(expected))
        print("             got: %s" % repr(got))


def test_parse():
    print("\n--- parse_action: coping with a real model's output ---")
    a = parse_action('{"action": "refine", "summary": "x", "reasoning": "y"}')
    check("clean JSON → kind 'refine'", a and a["kind"], "refine")

    a = parse_action('```json\n{"action": "coot_edit"}\n```')
    check("markdown-fenced JSON parses", a and a["kind"], "coot_edit")

    a = parse_action('Sure! Here you go:\n{"action": "validate"}')
    check("chatty preamble + JSON parses", a and a["kind"], "validate")

    check("plain prose → None", parse_action("I think we should refine."), None)
    check("empty → None", parse_action(""), None)
    check("JSON without action key → None",
          parse_action('{"summary": "no action here"}'), None)


def test_physics():
    print("\n--- apply_action: the mock tool world ---")
    r = apply_action({"kind": "refine"}, {"r_free": 0.34})["r_free"]
    check("refine drops R-free", r < 0.34, True)

    r = apply_action({"kind": "coot_edit"}, {"r_free": 0.30})["r_free"]
    check("a well-supported coot_edit helps", r < 0.30, True)

    r = apply_action({"kind": "coot_edit"}, {"r_free": 0.24})["r_free"]
    check("a clean coot_edit does NOT overfit near convergence", r < 0.24, True)

    m = apply_action({"kind": "refine"}, {"r_free": 0.24, "r_work": 0.205})
    check("re-refining at convergence OVERFITS: R-free rises", m["r_free"] > 0.24, True)
    check("...while R-work FALLS (the gap widens)", m["r_work"] < 0.205, True)

    r = apply_action({"kind": "new_experiment"}, {"r_free": 0.25})["r_free"]
    check("new_experiment makes no progress", r, 0.25)

    r = apply_action({"kind": "validate"}, {"r_free": 0.25})["r_free"]
    check("validate leaves metrics unchanged", r, 0.25)


def test_loop():
    print("\n--- live loop (scripted model, no key) ---")
    # Ungoverned so this doesn't depend on a solved policy.py.
    res = run_agent.run(governed=False, quiet=True, source="demo")
    check("scripted run reaches 'done'", res["completed"], True)
    check("final R-free is a float", isinstance(res["final_r_free"], float), True)

    capped = run_agent.run(governed=False, quiet=True, source="demo", max_steps=2)
    check("--max caps the run (stops before 'done')", capped["completed"], False)


def test_responder():
    print("\n--- propose_action wiring ---")
    action, raw = propose_action({"r_free": 0.34, "r_work": 0.31}, [],
                                 "GUIDEME text", scripted_responder())
    check("propose_action returns a parsed action", action and action["kind"], "refine")
    check("propose_action returns the raw text too", isinstance(raw, str), True)


def main():
    for t in (test_parse, test_physics, test_loop, test_responder):
        t()
    print("\n" + "=" * 40)
    print("  %d passed, %d failed" % (PASS, FAIL))
    print("=" * 40)
    sys.exit(1 if FAIL else 0)


if __name__ == "__main__":
    main()
