"""
llm_client.py — A tiny, dependency-free Anthropic API client.

Used by the LIVE mode of this tutorial, where the agent's proposals come
from a real model instead of a frozen transcript. Standard library only
(urllib + json) — nothing to pip install.

The student/instructor supplies a key in the environment:

    export ANTHROPIC_API_KEY="sk-ant-..."
    # optional:
    export ANTHROPIC_MODEL="claude-sonnet-4-6"

If no key is set, the harness falls back to simulated mode automatically,
so the tutorial still runs.
"""

import os
import json
import urllib.request
import urllib.error

ANTHROPIC_URL = "https://api.anthropic.com/v1/messages"
DEFAULT_MODEL = os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-4-6")


class NoAPIKey(Exception):
    pass


def have_key():
    """True if an API key is available in the environment."""
    return bool(os.environ.get("ANTHROPIC_API_KEY"))


def call_anthropic(system, user, model=None, max_tokens=400, temperature=0.2):
    """Send one message to the Anthropic API and return the text reply.

    Raises NoAPIKey if no key is set, or RuntimeError on an API error.
    """
    key = os.environ.get("ANTHROPIC_API_KEY")
    if not key:
        raise NoAPIKey("ANTHROPIC_API_KEY is not set")

    payload = json.dumps({
        "model": model or DEFAULT_MODEL,
        "max_tokens": max_tokens,
        "temperature": temperature,
        "system": system,
        "messages": [{"role": "user", "content": user}],
    }).encode("utf-8")

    req = urllib.request.Request(ANTHROPIC_URL, data=payload, method="POST")
    req.add_header("content-type", "application/json")
    req.add_header("x-api-key", key)
    req.add_header("anthropic-version", "2023-06-01")

    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", "replace")
        raise RuntimeError("Anthropic API error %s: %s" % (e.code, body))
    except urllib.error.URLError as e:
        raise RuntimeError("Network error calling Anthropic API: %s" % e)

    # The reply content is a list of blocks; concatenate the text ones.
    text_blocks = [b.get("text", "") for b in data.get("content", [])
                   if b.get("type") == "text"]
    return "".join(text_blocks)
