"""
test_policy.py — Test your policy implementations.

Run after each exercise:
    python3 test_policy.py        # all tests
    python3 test_policy.py 1      # exercise 1 only
    ...
"""

import os as _os
import sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
import safe_io  # noqa: F401  survive a non-UTF-8 terminal
import sys
from policy import (
    load_policy,
    needs_approval,
    check_scope,
    should_rollback,
    pre_act,
)

POLICY = {
    "r_free_tolerance": 0.01,
    "max_gap": 0.06,
    "max_iterations": 12,
    "gated_actions": ["extend_resolution", "deposit"],
    "in_scope_actions": ["refine", "coot_edit", "validate", "extend_resolution"],
}

SAMPLE_GUIDEME = """\
# GUIDEME
Some prose about principles that load_policy should ignore.

## OPERATING PARAMETERS
r_free_tolerance: 0.01
max_gap: 0.06
max_iterations: 12
gated_actions: extend_resolution, deposit
in_scope_actions: refine, coot_edit, validate, extend_resolution
"""

PASS = 0
FAIL = 0


def check(name, got, expected):
    global PASS, FAIL
    if got == expected:
        PASS += 1
        print("  \033[32mPASS\033[0m: %s" % name)
    else:
        FAIL += 1
        print("  \033[31mFAIL\033[0m: %s" % name)
        print("        expected: %s" % repr(expected))
        print("             got: %s" % repr(got))


# ---------------------------------------------------------------
def test_exercise_1():
    print("\n--- Exercise 1: load_policy ---")
    p = load_policy(SAMPLE_GUIDEME)
    check("r_free_tolerance parsed as float", p.get("r_free_tolerance"), 0.01)
    check("max_iterations parsed as int", p.get("max_iterations"), 12)
    check("gated_actions parsed as list",
          p.get("gated_actions"), ["extend_resolution", "deposit"])
    check("in_scope_actions parsed as list",
          p.get("in_scope_actions"),
          ["refine", "coot_edit", "validate", "extend_resolution"])
    check("max_gap parsed as float", p.get("max_gap"), 0.06)
    check("ignores prose lines (no stray keys)",
          sorted(p.keys()),
          ["gated_actions", "in_scope_actions", "max_gap", "max_iterations",
           "r_free_tolerance"])


def test_exercise_2():
    print("\n--- Exercise 2: needs_approval ---")
    ok, _ = needs_approval({"kind": "extend_resolution", "expensive": True}, POLICY)
    check("extend_resolution is gated", ok, True)
    ok, _ = needs_approval({"kind": "deposit", "expensive": False}, POLICY)
    check("deposit is gated (by name)", ok, True)
    ok, _ = needs_approval({"kind": "coot_edit", "expensive": True}, POLICY)
    check("expensive flag forces a gate", ok, True)
    ok, _ = needs_approval({"kind": "refine", "expensive": False}, POLICY)
    check("plain refine is not gated", ok, False)


def test_exercise_3():
    print("\n--- Exercise 3: check_scope ---")
    ok, _ = check_scope({"kind": "refine"}, POLICY)
    check("refine is in scope", ok, True)
    ok, _ = check_scope({"kind": "coot_edit"}, POLICY)
    check("coot_edit is in scope", ok, True)
    ok, _ = check_scope({"kind": "new_experiment"}, POLICY)
    check("new_experiment is out of scope", ok, False)
    ok, _ = check_scope({"kind": "done"}, POLICY)
    check("done is always allowed", ok, True)


# ── The three REAL overfits, measured on gene-5 data (2.59 A, C2). ──
# These are not invented test cases. Each is a refinement step that a real
# agent proposed on real data, and each one is overfitting. Note what R-free
# does — and what R-work does underneath it.
#
#                      R-work            R-free            gap
#   overfit 1     0.1975 → 0.1725   0.2417 → 0.2537   0.044 → 0.081
#   overfit 2     0.1975 → 0.1466   0.2417 → 0.2454   0.044 → 0.099
#   overfit 3     0.1920 → 0.1370   0.2390 → 0.2390   0.047 → 0.102
#
# A rule that only watches R-free sees +0.012, +0.004, and NOTHING.
OVERFIT_1 = ({"r_work": 0.1975, "r_free": 0.2417},
             {"r_work": 0.1725, "r_free": 0.2537})
OVERFIT_2 = ({"r_work": 0.1975, "r_free": 0.2417},
             {"r_work": 0.1466, "r_free": 0.2454})
OVERFIT_3 = ({"r_work": 0.1920, "r_free": 0.2390},
             {"r_work": 0.1370, "r_free": 0.2390})

# Two healthy steps, which must NOT be rolled back.
HEALTHY_REFINE = ({"r_work": 0.2160, "r_free": 0.2520},
                  {"r_work": 0.2080, "r_free": 0.2440})
HEALTHY_WOBBLE = ({"r_work": 0.2030, "r_free": 0.2390},
                  {"r_work": 0.2060, "r_free": 0.2430})


def test_exercise_4():
    print("\n--- Exercise 4: should_rollback — the 3 real overfits ---")
    roll, _ = should_rollback(OVERFIT_1[0], OVERFIT_1[1], POLICY)
    check("overfit 1  R-free +0.012, gap 0.044→0.081  → ROLL BACK", roll, True)

    roll, _ = should_rollback(OVERFIT_2[0], OVERFIT_2[1], POLICY)
    check("overfit 2  R-free +0.004, gap 0.044→0.099  → ROLL BACK", roll, True)

    roll, _ = should_rollback(OVERFIT_3[0], OVERFIT_3[1], POLICY)
    check("overfit 3  R-free  0.000, gap 0.047→0.102  → ROLL BACK", roll, True)

    roll, _ = should_rollback(HEALTHY_REFINE[0], HEALTHY_REFINE[1], POLICY)
    check("healthy    both improve, gap 0.036 flat    → keep", roll, False)

    roll, _ = should_rollback(HEALTHY_WOBBLE[0], HEALTHY_WOBBLE[1], POLICY)
    check("healthy    small wobble, gap 0.036→0.037   → keep", roll, False)


def test_exercise_5():
    print("\n--- Exercise 5: pre_act ordering ---")
    v, _ = pre_act({"kind": "refine", "expensive": False}, {}, POLICY)
    check("in-scope, cheap → proceed", v, "proceed")
    v, _ = pre_act({"kind": "extend_resolution", "expensive": True}, {}, POLICY)
    check("in-scope, expensive → gate", v, "gate")
    # The ordering test: out of scope AND expensive must BLOCK, not gate.
    v, _ = pre_act({"kind": "new_experiment", "expensive": True}, {}, POLICY)
    check("out-of-scope + expensive → block (scope before gate!)", v, "block")
    v, _ = pre_act({"kind": "done"}, {}, POLICY)
    check("done → proceed", v, "proceed")


TESTS = {1: test_exercise_1, 2: test_exercise_2, 3: test_exercise_3,
         4: test_exercise_4, 5: test_exercise_5}


def main():
    if len(sys.argv) > 1 and sys.argv[1] in "12345":
        TESTS[int(sys.argv[1])]()
    else:
        for n in sorted(TESTS):
            TESTS[n]()
    print("\n" + "=" * 40)
    print("  %d passed, %d failed" % (PASS, FAIL))
    print("=" * 40)
    sys.exit(1 if FAIL else 0)


if __name__ == "__main__":
    main()
