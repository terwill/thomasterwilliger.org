"""
live_agent.py — Turn a real model into the self-directed crystallography
agent: build the prompt, call the model, parse its proposed action.

The student does NOT edit this file. It's the bridge between the model
and the governance loop you write in policy.py. The model proposes; your
policy disposes.

Two things matter pedagogically here:

  * The model's system prompt IS your GUIDEME.md. So when you edit GUIDEME
    (tighten the tolerance, change a principle), you are reprogramming the
    *live* model — the strongest version of "policy steers behaviour."

  * The model returns raw text. Sometimes it's clean JSON; sometimes it's
    fenced or chatty. parse_action() has to cope — the same lesson as
    Tutorial 1, now against a real model.

  * The over-eager move near the end is a *re-refinement*, not a hand edit.
    That is the measured behaviour on real gene-5 data: clean rotamer fits did
    not worsen R-free; letting ordered solvent ride through re-refinement did.
"""

import json

# The six actions the agent may propose.
ACTION_KINDS = ["refine", "coot_edit", "extend_resolution",
                "new_experiment", "validate", "done"]

RESPONSE_FORMAT = """
--- RESPONSE FORMAT ---
You are choosing ONE next action for this cycle. Reply with a SINGLE JSON
object and nothing else:

{"action": "<one of: refine, coot_edit, extend_resolution, new_experiment, validate, done>",
 "summary": "<short label of what you're doing>",
 "reasoning": "<one or two sentences>",
 "expensive": <true or false>}

Action meanings:
  refine            - run phenix.refine against the data
  coot_edit         - make a manual model edit (rotamer, deletion, etc.)
  extend_resolution - extend the resolution cutoff (expensive)
  new_experiment    - re-run phasing / change the space group
  validate          - run final validation
  done              - the structure is converged and validated; stop

Choose "done" once R-free has converged and the model is validated.
Output JSON only — no markdown fences, no text outside the JSON object.
"""


def build_user_prompt(metrics, history):
    """Describe the current state to the model and ask for one action."""
    lines = ["Current model state:",
             "  R-free = %.3f, R-work = %.3f" % (metrics["r_free"],
                                                 metrics.get("r_work", 0.0))]
    if history:
        lines.append("\nRecent actions (most recent last):")
        for h in history[-6:]:
            note = ""
            if h.get("status") and h["status"] != "applied":
                note = "  [%s]" % h["status"]
            lines.append("  step %d: %s -> R-free %.3f%s"
                         % (h["step"], h["summary"], h["rfree"], note))
    else:
        lines.append("\nNo actions taken yet. This is the first cycle.")
    lines.append("\nPropose your next action as JSON.")
    return "\n".join(lines)


def parse_action(raw_text):
    """Extract a single action dict from the model's raw reply.

    Handles clean JSON, markdown-fenced JSON, and chatty preambles.
    Returns a dict with a normalised "kind" key, or None if nothing
    usable is found.
    """
    if not raw_text or not raw_text.strip():
        return None
    text = raw_text.strip()

    if "```" in text:
        for part in text.split("```"):
            p = part.strip()
            if p.startswith("json"):
                p = p[4:].strip()
            if p.startswith("{"):
                text = p
                break

    start, end = text.find("{"), text.rfind("}")
    if start == -1 or end == -1 or end <= start:
        return None
    try:
        obj = json.loads(text[start:end + 1])
    except json.JSONDecodeError:
        return None
    if not isinstance(obj, dict):
        return None

    kind = obj.get("action") or obj.get("kind")
    if not isinstance(kind, str) or not kind:
        return None
    obj["kind"] = kind
    obj.setdefault("summary", kind)
    obj.setdefault("reasoning", "")
    obj.setdefault("expensive", kind in ("extend_resolution", "new_experiment"))
    return obj


def propose_action(metrics, history, guideme_text, responder):
    """Ask the model for its next action.

    `responder(system, user) -> str` is the thing that actually calls the
    model. In live mode it's llm_client.call_anthropic; in tests/--demo
    it's a scripted stand-in. The student's GUIDEME.md is the system
    prompt, so editing GUIDEME changes the live model's behaviour.

    Returns (action_dict_or_None, raw_text).
    """
    system = guideme_text + "\n" + RESPONSE_FORMAT
    user = build_user_prompt(metrics, history)
    raw = responder(system, user)
    return parse_action(raw), raw


# ---------------------------------------------------------------------
# A scripted "model" for offline use (--demo) and for tests. It ignores
# the prompt and plays a realistic sequence, including the off-plan move,
# the expensive step, and a late edit that overfits — plus one fenced and
# one chatty reply so parse_action earns its keep.
# ---------------------------------------------------------------------

_SCRIPT = [
    '{"action": "refine", "summary": "Refine the placed model", '
    '"reasoning": "R-free is high; standard refinement should help.", "expensive": false}',

    '```json\n{"action": "coot_edit", "summary": "Delete unsupported residues 1, 86, 87", '
    '"reasoning": "These termini have almost no density support.", "expensive": false}\n```',

    '{"action": "refine", "summary": "Refine after trimming", '
    '"reasoning": "Another round should drop R-free further.", "expensive": false}',

    'Sure! Here is my next step:\n'
    '{"action": "new_experiment", "summary": "Re-run AutoSol in a new space group", '
    '"reasoning": "Maybe the space group is wrong.", "expensive": true}',

    '{"action": "extend_resolution", "summary": "Extend to 1.9 A", '
    '"reasoning": "The data go beyond the current cutoff.", "expensive": true}',

    '{"action": "refine", "summary": "Re-refine with ordered solvent to pick up waters", '
    '"reasoning": "There are unmodelled blobs in the map; adding ordered solvent and '
    're-refining should drop R-work further.", "expensive": false}',

    '{"action": "refine", "summary": "One more refinement cycle to polish", '
    '"reasoning": "R-work is still falling, so another cycle should help.", '
    '"expensive": false}',

    '{"action": "validate", "summary": "Run final validation", '
    '"reasoning": "The model looks complete.", "expensive": false}',

    '{"action": "done", "summary": "Report the finished model", '
    '"reasoning": "Structure solved and validated.", "expensive": false}',
]


def scripted_responder():
    """Return a responder(system, user) that replays _SCRIPT in order."""
    state = {"i": 0}

    def respond(system, user):
        i = state["i"]
        state["i"] = min(i + 1, len(_SCRIPT) - 1)
        return _SCRIPT[i]

    return respond
