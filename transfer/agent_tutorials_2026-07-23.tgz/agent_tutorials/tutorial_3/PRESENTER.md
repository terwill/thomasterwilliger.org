# Presenter Notes — Tutorial 3: Steering an Autonomous Agent

This is Tutorial 3 with a real model proposing the actions. The exercises
are identical, so everything in the Tutorial 3 presenter notes applies. The
notes below cover only what's different about running it live.

---

## Before the session

- **Hand out the key.** `export ANTHROPIC_API_KEY=...` is the only setup.
  Put it in a copy-paste block on a slide. Optionally set `ANTHROPIC_MODEL`.
- **Have a fallback ready.** If keys, network, or budget fail, tell students
  to run `--demo` (live code path, scripted model, no key). Nothing about
  the exercises changes. Decide in advance whether you're teaching live or
  in `--demo`, and have both working on your own machine.
- **Do a dry run and note the cost.** A few cents per student per run. If
  budget is tight, use a smaller model and/or cap `--max`.

---

## Framing the difference (2 min)

"In Tutorial 3 the agent was on rails — the same run every time. Today it's
a real model. It will say things its own way, and it may surprise you. Your
job is the same: write the policy that governs it. The difference is that
now the thing you're governing actually has a mind of its own."

---

## Two live-only beats

1. **Reprogram the LLM by editing English.** After Exercise 4, when
   students tighten `r_free_tolerance`, point out they just changed a number
   the *model itself* reads (GUIDEME is its system prompt). Then have them
   change a *principle* — e.g., make "stay in scope" more emphatic — and
   run again. Watch the proposals shift. This is the strongest possible
   version of "policy steers behaviour."

2. **Run it twice.** Have the room run the live agent twice and compare. The
   trajectories differ; a good policy still produces a trustworthy result.
   Land it: "You're not scripting the agent. You're governing it. Those are
   different jobs, and governance is the one that scales."

---

## What to expect live (and how to handle it)

- **The LLM usually behaves reasonably**, so the off-plan/gate/overfit
  moments may not all fire on a given live run. That's fine — use `--demo`
  or `--simulated` to *guarantee* all three for the teaching moment, then go
  live to show it holding up under real variation.
- **Messy JSON** happens; `live_agent.parse_action` tolerates fences and
  preambles. If a reply is truly unparseable, the framework says so and stops
  cleanly — a teachable example of why parsing is its own line of defence
  (callback to Tutorial 1).
- **A model that won't stop** is capped by `max_iterations`; the run ends
  "did not complete," which is itself a useful illustration of the cap.

---

## If everything is offline

`--demo` reproduces the entire arc deterministically with no key. You can
teach the whole tutorial in `--demo` and only switch to live for the final
"run it for real" beat if/when keys are available.
