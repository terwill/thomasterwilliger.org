"""
decisions.py — YOUR CODE GOES HERE

You're building the decision-making brain of a scientific agent.
The agent runs a crystallography pipeline: analyze → find_model →
place_model → refine → validate. Your job is to make it choose
the right program at each step.

You'll build two deciders:
  - A rules-based engine (reliable but rigid)
  - An LLM-powered engine (flexible but unreliable)
  - A hybrid that uses both

Run the tests after each exercise:
    python3 test_decisions.py N

Run the agent to see your decisions in action:
    python3 run_agent.py
"""

import json
from fake_llm import query_llm


# =====================================================================
# EXERCISE 1: What can we do right now?
# =====================================================================

def get_valid_programs(current_phase, program_defs):
    """
    Return the list of programs valid in the current phase.

    Each program in program_defs has a "valid_phases" list.
    Return the names of all programs where current_phase appears
    in their valid_phases.

    Args:
        current_phase: str, e.g. "refine"
        program_defs:  dict of program_name -> definition

    Returns:
        list of str: program names valid for this phase

    Examples:
        ("analyze", ...) → ["analyze_data"]
        ("refine", ...)  → ["refine", "validate"]
    """
    # --- YOUR CODE HERE ---
    return []  # Stub: no programs valid


# =====================================================================
# EXERCISE 2: Parse the LLM's messy output
# =====================================================================

def parse_llm_response(raw_text):
    """
    Parse a raw LLM text response into a decision dict.

    LLMs return text in unpredictable formats:
      - Clean JSON:        {"program": "refine", ...}
      - Markdown-fenced:   ```json\n{...}\n```
      - Chatty preamble:   "I recommend...\n{...}"
      - Plain text:        "I think we should refine..."  (no JSON at all)
      - Empty string:      ""

    Your parser must handle ALL of these.  For responses that contain
    JSON somewhere in the text, extract and parse it.  For responses
    with no JSON at all, return None.

    Args:
        raw_text: str, the raw LLM response

    Returns:
        dict or None: parsed dict with at least "program" key,
                      or None if no valid JSON found

    Examples:
        '{"program": "refine"}'           → {"program": "refine"}
        '```json\n{"program": "x"}\n```'  → {"program": "x"}
        'I think we should refine...'     → None
        ''                                → None

    Hint: You might want to find the index of the first '{' and the
    last '}'.  Python's .find() and .rfind() are your friends here!
    Don't forget to handle json.JSONDecodeError!

    Skeleton:
        1. Return None if raw_text is empty
        2. If '```' appears, strip the fences (split on '```',
           look for the part that starts with '{')
        3. Find first '{' and last '}' — if either is missing, return None
        4. Slice the string between them and json.loads() it
        5. If it's a dict with a "program" key, return it; else None
    """
    # --- YOUR CODE HERE ---
    return None  # Stub: never parses anything


# =====================================================================
# EXERCISE 3: Build the context for the LLM
# =====================================================================

def build_context(state):
    """
    Structure the agent's state into a context dict for the LLM.

    The LLM makes better decisions when it has the right information.
    Build a dict that includes everything the LLM needs to know.

    Args:
        state: dict with keys:
            "current_phase"   : str
            "available_files" : set of str
            "program_defs"    : dict
            "history"         : list of {"program": ..., "cycle": ...}
            "metrics_history" : list of dicts with optional "r_free"
            "cycle"           : int

    Returns:
        dict with keys:
            "current_phase"    : str (pass through)
            "cycle"            : int (pass through)
            "available_files"  : list of str (sorted, for consistency)
            "valid_programs"   : list of str (call get_valid_programs!)
            "latest_metrics"   : dict (last entry in metrics_history,
                                       or {} if empty)
            "recent_history"   : list of str (program names from last
                                              3 history entries)

    Examples:
        state with phase="refine", 2 refines done, r_free=0.255:
        → {"current_phase": "refine", "cycle": 6,
           "available_files": ["data.mtz", "placed_model.pdb", ...],
           "valid_programs": ["refine", "validate"],
           "latest_metrics": {"r_free": 0.255},
           "recent_history": ["place_model", "refine", "refine"]}
    """
    # --- YOUR CODE HERE ---
    return {"current_phase": state["current_phase"],
            "cycle": state.get("cycle", 0)}  # Stub: minimal context


# =====================================================================
# EXERCISE 4: Rules-based fallback
# =====================================================================

def decide_by_rules(state):
    """
    Make a decision using hand-written rules (no LLM).

    The state dict includes a helper field:
        state["refine_count"] — number of times "refine" has run

    Rules:
        1. Get the list of valid programs for the current phase.
        2. If "validate" is valid AND refine_count >= 3,
           choose "validate" (we've refined enough).
        3. Otherwise, choose the first valid program.

    Args:
        state: the full agent state dict (includes "refine_count")

    Returns:
        dict: {"program": "...", "files": {}, "reasoning": "..."}
              or None if no valid programs exist

    Examples:
        phase="analyze" → {"program": "analyze_data", ...}
        phase="refine", refine_count=2 → {"program": "refine", ...}
        phase="refine", refine_count=3 → {"program": "validate", ...}
    """
    # --- YOUR CODE HERE ---
    return None  # Stub: no decision


# =====================================================================
# EXERCISE 5: Compose — LLM proposes, rules verify
# =====================================================================

def decide(state):
    """
    Make a decision using the LLM with a rules-based fallback.

    The three functions below are ALREADY WRITTEN — but they're
    called in the WRONG ORDER.  The current logic tries rules first
    and only uses the LLM as a backup.  That's backwards — it
    means the LLM's flexibility is never used.

    Fix the order so the LLM goes first:
      1. Build context and query the LLM
      2. Parse the response
      3. Check if the parsed program is valid for this phase
      4. If any step fails, fall back to rules

    Run: python3 test_decisions.py 5

    Returns:
        tuple: (decision_dict, source_str)
               source_str is "llm" or "rules"
    """
    valid = get_valid_programs(state["current_phase"], state["program_defs"])

    # ── Block A: Try rules ──
    rules_decision = decide_by_rules(state)
    if rules_decision:
        return rules_decision, "rules"

    # ── Block B: Try LLM ──
    context = build_context(state)
    raw = query_llm(context)
    parsed = parse_llm_response(raw)
    if parsed and parsed.get("program") in valid:
        return parsed, "llm"

    # ── Block C: Give up ──
    return {"program": valid[0] if valid else "unknown",
            "files": {}, "reasoning": "No decision available"}, "fallback"
