#!/usr/bin/env python3
"""
run_agent.py — Run the crystallography pipeline with your decision engine.

Usage:
    python3 run_agent.py              Hybrid mode (LLM + rules fallback)
    python3 run_agent.py --rules      Rules-only mode
    python3 run_agent.py --llm        LLM-only mode (no fallback)
    python3 run_agent.py --compare    Run all three and show comparison
    python3 run_agent.py --max=N      Limit to N cycles
"""

import os as _os
import sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
import safe_io  # noqa: F401  survive a non-UTF-8 terminal
import sys
import io
import json
import textwrap
import contextlib
from mock_runner import MockRunner
from decisions import decide, decide_by_rules, build_context, parse_llm_response, get_valid_programs
from fake_llm import query_llm


def load_config():
    with open("programs.json", "r") as f:
        return json.load(f)


def format_state_summary(state):
    parts = ["  Phase:     %s" % state["current_phase"]]
    parts.append("  Files:     %s" % ", ".join(sorted(state["available_files"])))
    if state.get("metrics_history"):
        last_m = state["metrics_history"][-1]
        if last_m:
            parts.append("  Metrics:   %s" % last_m)
    if state["history"]:
        prog_names = [h["program"] for h in state["history"][-5:]]
        prefix = "... → " if len(state["history"]) > 5 else ""
        parts.append("  History:   %s%s" % (prefix, " → ".join(prog_names)))
    return "\n".join(parts)


def advance_phase(current_phase, phases, program_defs, program_name):
    defn = program_defs.get(program_name, {})
    if defn.get("advances_phase", True):
        idx = phases.index(current_phase) if current_phase in phases else 0
        if idx + 1 < len(phases):
            return phases[idx + 1]
    return current_phase


def run_agent(mode="hybrid", max_cycles=12, verbose=True):
    """Run the agent in the given mode. Returns scorecard dict."""
    config = load_config()
    program_defs = config["programs"]
    phases = config["phases"]
    runner = MockRunner(program_defs)

    state = {
        "available_files": {"data.mtz", "sequence.fa"},
        "current_phase": "analyze",
        "program_defs": program_defs,
        "history": [],
        "metrics_history": [],
    }

    mode_labels = {"hybrid": "HYBRID (LLM + rules fallback)",
                   "rules": "RULES ONLY",
                   "llm": "LLM ONLY (no fallback)"}

    if verbose:
        print("\n" + "=" * 60)
        print("  AGENT — %s" % mode_labels.get(mode, mode))
        print("=" * 60)
        print("\nStarting files: data.mtz, sequence.fa")
        print("Goal: analyze → find_model → place → refine → validate\n")

    score = {"llm": 0, "rules": 0, "fallback": 0, "failed": 0,
             "completed": False, "cycles": 0, "final_rfree": None}

    for cycle in range(1, max_cycles + 1):
        if state["current_phase"] == "done":
            score["completed"] = True
            if verbose:
                print("\n\033[32m★ Pipeline complete! ★\033[0m\n")
            break

        state["cycle"] = cycle
        state["refine_count"] = sum(
            1 for h in state["history"] if h["program"] == "refine")
        score["cycles"] = cycle

        if verbose:
            print("─" * 60)
            print("CYCLE %d" % cycle)
            print("─" * 60)
            print("\nCurrent state:")
            print(format_state_summary(state))

        # ── DECIDE ──
        if mode == "rules":
            decision = decide_by_rules(state)
            source = "rules"
            if decision is None:
                decision = {"program": "unknown", "files": {},
                            "reasoning": "No rules matched"}
                source = "failed"
        elif mode == "llm":
            context = build_context(state)
            raw = query_llm(context)
            parsed = parse_llm_response(raw)
            valid = get_valid_programs(state["current_phase"],
                                       state["program_defs"])
            if parsed and parsed.get("program") in valid:
                decision = parsed
                source = "llm"
            else:
                decision = {"program": parsed.get("program", "???") if parsed else "???",
                            "files": {}, "reasoning": "Parse/validation failed"}
                source = "failed"
                if verbose:
                    if parsed:
                        print("\n  \033[33mLLM said '%s' — not valid for %s phase\033[0m"
                              % (parsed["program"], state["current_phase"]))
                    else:
                        print("\n  \033[33mLLM response could not be parsed\033[0m")
        else:  # hybrid
            decision, source = decide(state)

        if verbose:
            label = source.upper()
            if decision.get("program") == "unknown":
                label = "NO DECISION"          # the stub produced nothing
            print("\nDecision [%s]: run '%s'" % (label, decision["program"]))
            reasoning = decision.get("reasoning", "")
            if reasoning:
                wrapped = textwrap.fill(reasoning, width=56,
                                        initial_indent="  Reasoning: ",
                                        subsequent_indent="    ")
                print(wrapped)

        # ── EXECUTE ──
        if source == "failed":
            score["failed"] += 1
            if verbose:
                print("\n  \033[31m✗ No valid decision — skipping cycle\033[0m")
            state["history"].append({"program": decision["program"],
                                     "cycle": cycle, "status": "failed"})
            state["metrics_history"].append({})
            continue

        result = runner.execute(decision["program"], state["available_files"])
        if verbose:
            print("\n%s" % result["log"])

        if result["success"]:
            score[source] += 1
            for f in result["output_files"]:
                state["available_files"].add(f)
            state["history"].append({"program": decision["program"],
                                     "cycle": cycle})
            state["metrics_history"].append(result["metrics"])
            state["current_phase"] = advance_phase(
                state["current_phase"], phases, program_defs,
                decision["program"])
            if result["metrics"].get("r_free"):
                score["final_rfree"] = result["metrics"]["r_free"]
        else:
            score["failed"] += 1
            if verbose:
                print("  \033[31mExecution failed: %s\033[0m" % result["log"])
            state["history"].append({"program": decision["program"],
                                     "cycle": cycle, "status": "failed"})
            state["metrics_history"].append({})
    else:
        if verbose:
            print("\n\033[33m⚠ Reached max cycles (%d) without completing!\033[0m\n"
                  % max_cycles)

    if verbose:
        total = score["llm"] + score["rules"] + score["fallback"] + score["failed"]
        print("─" * 60)
        print("SCORECARD (%s)" % mode.upper())
        print("─" * 60)
        if score["completed"]:
            print("  Result:          \033[32mPipeline completed\033[0m")
        else:
            print("  Result:          \033[31mDid not complete\033[0m")
        print("  Cycles used:     %d" % score["cycles"])
        if mode == "hybrid":
            print("  LLM decisions:   %d / %d" % (score["llm"], total))
            print("  Rules fallback:  %d / %d" % (score["rules"], total))
        elif mode == "rules":
            print("  Rules decisions: %d / %d" % (score["rules"], total))
        elif mode == "llm":
            print("  LLM decisions:   %d / %d" % (score["llm"], total))
        if score["failed"]:
            print("  Failed:          %d / %d" % (score["failed"], total))

        if score["failed"] == total and total > 0:
            print()
            print("\033[33m" + "=" * 60 + "\033[0m")
            print("\033[33m\033[1m  THIS IS EXPECTED — nothing is broken.\033[0m")
            print("\033[33m" + "=" * 60 + "\033[0m")
            print("  `%s` is still stubbed, so the agent has no" % "decisions.py")
            print("  idea what to do. You have just watched an agent with no")
            print("  decision-making at all — that is the point of this run.")
            print()
            print("  \033[1mNow go build it.\033[0m  Open README.md and start with")
            print("  Exercise 1 (\033[36m%s\033[0m)." % "get_valid_programs")
            print("\033[33m" + "=" * 60 + "\033[0m")

        if score["final_rfree"]:
            print("  Final R-free:    %.3f" % score["final_rfree"])
        print()

    return score


def compare():
    """Run all three modes and show a comparison table."""
    print("\n" + "=" * 60)
    print("  COMPARING THREE STRATEGIES")
    print("=" * 60)

    results = {}
    # Run the three strategies silently — the per-function prints are
    # useful per-cycle but would bury the comparison table here.
    with contextlib.redirect_stdout(io.StringIO()):
        for mode in ["rules", "llm", "hybrid"]:
            results[mode] = run_agent(mode=mode, verbose=False)

    labels = {"rules": "Rules only", "llm": "LLM only", "hybrid": "Hybrid"}

    print("\n  %-14s  %-12s  %-8s  %-10s" % ("Strategy", "Completed?", "Cycles", "R-free"))
    print("  " + "-" * 50)
    for mode in ["rules", "llm", "hybrid"]:
        r = results[mode]
        status = "\033[32mYes\033[0m" if r["completed"] else "\033[31mNo\033[0m"
        rfree = "%.3f" % r["final_rfree"] if (r["completed"] and r["final_rfree"]) else "—"
        # Pad to account for ANSI codes
        print("  %-14s  %-21s  %-8d  %-10s" % (labels[mode], status, r["cycles"], rfree))

    print()
    for mode in ["rules", "llm", "hybrid"]:
        r = results[mode]
        total = r["llm"] + r["rules"] + r["fallback"] + r["failed"]
        detail = []
        if r["llm"]:
            detail.append("%d LLM" % r["llm"])
        if r["rules"]:
            detail.append("%d rules" % r["rules"])
        if r["failed"]:
            detail.append("%d failed" % r["failed"])
        print("  %s: %s" % (labels[mode], ", ".join(detail)))
    print()


if __name__ == "__main__":
    mode = "hybrid"
    max_c = 12
    do_compare = False

    for arg in sys.argv[1:]:
        if arg == "--rules":
            mode = "rules"
        elif arg == "--llm":
            mode = "llm"
        elif arg == "--compare":
            do_compare = True
        elif arg.startswith("--max="):
            max_c = int(arg.split("=")[1])

    if do_compare:
        compare()
    else:
        run_agent(mode=mode, max_cycles=max_c)
