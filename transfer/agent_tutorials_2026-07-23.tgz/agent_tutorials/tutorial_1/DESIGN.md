# Tutorial Design Document: "From Rules to Reasoning"

## Building a Scientific Decision Agent

---

## 1. Requirements and Constraints

Identical to Tutorial 2 ("Trust But Verify"). Same workshop, same
audience, same constraints. See that design document for details.

**Relationship to Tutorial 2:** These tutorials are complementary.
Tutorial 1 builds the decision-making brain (perceive, decide, act).
Tutorial 2 builds the safety net (validation layers). They share
the same domain (`programs.json`) and mock execution engine
(`mock_runner.py`) but teach different lessons. A workshop could
run either independently, or both sequentially.

---

## 2. Goal

### Learning Objectives

By the end of this tutorial, students will:

1. **Understand the agent loop** — perceive (read state), decide
   (choose action), act (execute), update (process results). This
   pattern is universal across all agent frameworks.

2. **Know how to parse unreliable LLM output.** Real LLMs return
   text in unpredictable formats — clean JSON, markdown-fenced JSON,
   chatty preambles, plain text. Students will build a robust parser
   that handles all of these.

3. **See why agents need both rules and LLMs.** Rules are reliable
   but rigid. LLMs are flexible but unreliable. The hybrid
   approach — LLM proposes, rules verify — gets the best of both.
   Students will run all three strategies and compare scorecards.

4. **Recognize that context is the prompt.** The information you
   give the LLM determines the quality of its decisions. Students
   build the context-assembly function and see how it maps to
   prompt engineering.

### Non-Goals

Same as Tutorial 2: not teaching crystallography, not teaching
prompt engineering as a discipline, not teaching a specific
framework.

---

## 3. Materials Required

Same infrastructure as Tutorial 2 plus two new files:

```
tutorial-1/
├── README.md
├── programs.json          (shared with Tutorial 2)
├── mock_runner.py         (shared with Tutorial 2)
├── fake_llm.py            Hand-written LLM responses (not transcripts)
├── decisions.py           Student's work file — 5 exercises
├── test_decisions.py      Test suite, per-exercise
├── run_agent.py           Agent loop with 3 modes + comparison
├── catchup.py             Escape hatch
└── solutions/
    └── decisions_complete.py
```

Zero external dependencies. Standard library Python only.

---

## 4. Overall Strategy

### Narrative Arc

The tutorial tells a story of increasing automation:

1. **Know your options** (Exercise 1) — Before deciding, know what's
   possible. Filter the program list by current phase.

2. **Parse the LLM** (Exercise 2) — The LLM returns raw text. It
   might be clean JSON, fenced JSON, or not JSON at all. Build a
   parser robust enough to handle the mess.

3. **Build the context** (Exercise 3) — Assemble the state into a
   structured dict that the LLM can use. This is prompt engineering
   in code form.

4. **Build a rules engine** (Exercise 4) — A fallback that always
   works: follow the phase sequence, stop refining after 3 cycles.
   Reliable, rigid, boring.

5. **Compose them** (Exercise 5) — LLM goes first; if it fails, rules
   take over. Pre-written but in wrong order; student fixes it. The
   `--compare` flag shows the quantitative difference.

### Key "Aha" Moments

1. **Exercise 2: "LLMs don't return clean data."** Students who've
   used ChatGPT via the web interface have never dealt with raw
   output parsing. Seeing markdown fences, chatty preambles, and
   format failures is eye-opening.

2. **After Exercise 4 (`--rules`):** "Rules work perfectly — for
   the simple case." The pipeline completes but always takes the
   same path. Students realize rules can't adapt.

3. **After Exercise 5 (`--compare`):** The comparison table shows
   rules-only completes but is rigid, LLM-only fails 2/12 cycles
   and doesn't complete, hybrid completes with 6 LLM + 2 rules
   decisions. The quantitative comparison makes the case for
   hybrid architecture.

4. **The cross-reference to Tutorial 2:** The hybrid agent works
   but the LLM still hallucinates names and loses format. Tutorial 1
   handles this by falling back to rules. Tutorial 2 handles it by
   adding validation layers. Real systems need both.

---

## 5. Detailed Implementation

### 5.1 The Fake LLM (fake_llm.py)

Hand-written responses keyed by `(phase, cycle)` that exhibit
realistic formatting variations:

| Cycle | Phase | Format | Notes |
|-------|-------|--------|-------|
| 1 | analyze | Clean JSON | Easy parse |
| 2 | find_model | Markdown-fenced JSON | Common LLM behavior |
| 3 | place_model | Clean JSON | Easy parse |
| 4 | refine | Clean JSON | First refine |
| 5 | refine | Chatty preamble + JSON | Text before the JSON |
| 6 | refine | Hallucinated program name | `refine_model` |
| 7 | refine | Plain text, no JSON | Parser must return None |
| 8+ | refine | Clean JSON | Keeps wanting to refine |

The LLM never suggests `validate` on its own — it always wants
more refinement. This is realistic: LLMs are optimistic about
iterative improvement.

### 5.2 The Three Agent Modes

**`--rules`:** Calls only `decide_by_rules`. Always works, always
takes the same path. Completes in 8 cycles.

**`--llm`:** Calls `query_llm` → `parse_llm_response`, validates
against valid programs. No fallback. Fails at cycles 6 (hallucinated
name) and 7 (unparseable text), does not complete within 12 cycles.

**`--compare`:** Runs all three silently, prints a comparison table:

```
  Strategy        Completed?    Cycles    R-free
  --------------------------------------------------
  Rules only      Yes           8         0.240
  LLM only        No            12        0.240
  Hybrid          Yes           8         0.240
```

### 5.3 Exercise Details

**Exercise 1: `get_valid_programs`** (5 lines)
Filter `program_defs` by `current_phase in valid_phases`. Foundation
for everything else — both rules and LLM validation use this.

**Exercise 2: `parse_llm_response`** (15 lines)
The meatiest exercise. Must handle: empty input, markdown fences
(```` ```json...``` ````), chatty preamble, first-`{`-to-last-`}`
extraction, `json.loads()` with error handling. The docstring
provides a 5-step skeleton (return None if empty → strip fences →
find braces → json.loads → check for "program" key) and calls out
`.find()`, `.rfind()`, and `json.JSONDecodeError` by name.

**Exercise 3: `build_context`** (10 lines)
Assemble a structured dict from the raw state. Key insight: calls
`get_valid_programs` to tell the LLM what's allowed. Students see
how their context function feeds directly into the LLM.

**Exercise 4: `decide_by_rules`** (5 lines)
Simple rules: get valid programs, check `state["refine_count"]`,
if refined 3+ times and validate is available then validate,
otherwise pick first valid program. The agent pre-computes
`refine_count` each cycle so the student doesn't need to iterate
through history — the rule is a simple `if` statement.

**Exercise 5: `decide`** (block reorder)
Pre-written with Block A (rules) before Block B (LLM). Student
swaps them. The test `cycle 1: LLM returns clean JSON → uses LLM`
fails in wrong order because rules always produces a valid answer,
preventing the LLM from ever being tried.

### 5.4 Session Flow

| Time | Activity | Student Action |
|------|----------|----------------|
| 0:00 | Instructor intro | Listen |
| 0:08 | Read domain, run broken agent | `cat programs.json`, `python3 run_agent.py --max=3` |
| 0:10 | Exercise 1: valid programs | Edit → test → pass |
| 0:15 | Exercise 2: parse LLM output | Edit → test → pass |
| 0:25 | Exercise 3: build context | Edit → test → pass |
| 0:35 | Exercise 4: rules engine | Edit → test → `python3 run_agent.py --rules` |
| 0:45 | Exercise 5: compose hybrid | Swap blocks → test → pass |
| 0:48 | Compare all three | `python3 run_agent.py --compare` |
| 0:50 | Discussion | Group discussion |
| 1:00 | End | |

---

## 6. Distribution Checklist

- [ ] `decisions.py` has all stubs (Exercises 1–4) and wrong-order
      blocks (Exercise 5)
- [ ] `solutions/decisions_complete.py` has correct implementations
- [ ] `programs.json` and `mock_runner.py` identical to Tutorial 2
- [ ] `catchup.py` tested for values 2, 3, 4, and 5
- [ ] `fake_llm.py` returns varied formats across cycles
- [ ] `--compare` shows rules=complete, llm=incomplete, hybrid=complete
- [ ] Test suite: 29/29 passing with solved decisions
- [ ] No external dependencies
- [ ] `__pycache__/` removed from tarball
