"""
mock_runner.py — Simulates PHENIX program execution.

Each "program" just creates output files and returns fake metrics.
The refine program decreases R-free by a diminishing amount each run.
"""

import copy


class MockRunner:
    """Execute mock programs and track available files + metrics."""

    def __init__(self, program_defs):
        self.program_defs = program_defs
        self.refine_count = 0

    def execute(self, program_name, available_files):
        """
        Run a mock program.

        Returns:
            dict with keys: success, output_files, metrics, log
        """
        defn = self.program_defs.get(program_name)
        if defn is None:
            return {
                "success": False,
                "output_files": [],
                "metrics": {},
                "log": "ERROR: Unknown program '%s'" % program_name,
            }

        # Check required files exist
        missing = [r for r in defn["requires"] if r not in available_files]
        if missing:
            return {
                "success": False,
                "output_files": [],
                "metrics": {},
                "log": "ERROR: Missing required files: %s" % ", ".join(missing),
            }

        # "Run" the program — produce output files
        output_files = list(defn["produces"])
        metrics = copy.deepcopy(defn.get("mock_metrics", {}))

        # Refine: R-free decreases with diminishing returns
        if program_name == "refine":
            self.refine_count += 1
            # Starts at 0.32, drops fast then plateaus
            # Run 1: 0.32, Run 2: 0.28, Run 3: 0.265, Run 4: 0.258, ...
            drop = 0.04 / (self.refine_count ** 0.7)
            base = 0.32 - sum(0.04 / (i ** 0.7) for i in range(1, self.refine_count + 1))
            metrics["r_free"] = round(max(base, 0.24), 4)

        log_lines = [
            "=" * 50,
            "  Running: %s" % program_name,
            "  Input files: %s" % ", ".join(defn["requires"]),
            "  Output files: %s" % ", ".join(output_files),
        ]
        if metrics:
            log_lines.append("  Metrics: %s" % metrics)
        log_lines.append("  Status: SUCCESS")
        log_lines.append("=" * 50)

        return {
            "success": True,
            "output_files": output_files,
            "metrics": metrics,
            "log": "\n".join(log_lines),
        }
