"""
decisions_complete.py — Fully working reference solution.

If you get stuck, you can copy this file over decisions.py:
    cp solutions/decisions_complete.py decisions.py

Or compare it with your code to find differences.
"""

import json
from fake_llm import query_llm


# =====================================================================
# EXERCISE 1: What can we do right now?
# =====================================================================

def get_valid_programs(current_phase, program_defs):
    """Return the list of programs valid in the current phase."""
    valid = []
    for name, defn in program_defs.items():
        if current_phase in defn.get("valid_phases", []):
            valid.append(name)
    print("  [get_valid_programs] Phase '%s' → valid programs: %s" % (current_phase, valid))
    return valid


# =====================================================================
# EXERCISE 2: Parse the LLM's messy output
# =====================================================================

def parse_llm_response(raw_text):
    """Parse a raw LLM text response into a decision dict."""
    if not raw_text or not raw_text.strip():
        print("  [parse_llm_response] Empty input → None")
        return None

    text = raw_text.strip()

    # Strip markdown fences if present
    if "```" in text:
        parts = text.split("```")
        for part in parts:
            cleaned = part.strip()
            if cleaned.startswith("json"):
                cleaned = cleaned[4:].strip()
            if cleaned.startswith("{"):
                text = cleaned
                break
        print("  [parse_llm_response] Stripped markdown fences")

    # Find the first { and last }
    start = text.find("{")
    end = text.rfind("}")
    if start == -1 or end == -1 or end <= start:
        print("  [parse_llm_response] No JSON found in text → None")
        return None

    json_str = text[start:end + 1]
    try:
        result = json.loads(json_str)
        if isinstance(result, dict) and "program" in result:
            print("  [parse_llm_response] Parsed OK → program='%s'" % result["program"])
            return result
        print("  [parse_llm_response] JSON found but no 'program' key → None")
        return None
    except json.JSONDecodeError:
        print("  [parse_llm_response] JSON decode failed → None")
        return None


# =====================================================================
# EXERCISE 3: Build the context for the LLM
# =====================================================================

def build_context(state):
    """Structure the agent's state into a context dict for the LLM."""
    # Latest metrics (last entry in metrics_history, or {} if empty)
    latest = {}
    if state.get("metrics_history"):
        latest = state["metrics_history"][-1] or {}

    # Recent history (program names from last 3 history entries)
    recent = [h["program"] for h in state.get("history", [])[-3:]]

    context = {
        "current_phase": state["current_phase"],
        "cycle": state.get("cycle", 0),
        "available_files": sorted(state["available_files"]),
        "valid_programs": get_valid_programs(
            state["current_phase"], state["program_defs"]),
        "latest_metrics": latest,
        "recent_history": recent,
    }

    print("  [build_context] Phase=%s, cycle=%d, %d files, programs=%s"
          % (context["current_phase"], context["cycle"],
             len(context["available_files"]), context["valid_programs"]))
    return context


# =====================================================================
# EXERCISE 4: Rules-based fallback
# =====================================================================

def decide_by_rules(state):
    """Make a decision using hand-written rules (no LLM)."""
    valid = get_valid_programs(state["current_phase"], state["program_defs"])
    if not valid:
        print("  [decide_by_rules] No valid programs → None")
        return None

    refine_count = state.get("refine_count", 0)

    if refine_count >= 3 and "validate" in valid:
        print("  [decide_by_rules] Refined %d times → choosing 'validate'" % refine_count)
        return {"program": "validate", "files": {},
                "reasoning": "Refined %d times, moving to validation." % refine_count}

    print("  [decide_by_rules] Phase '%s' → choosing '%s'"
          % (state["current_phase"], valid[0]))
    return {"program": valid[0], "files": {},
            "reasoning": "Rules: first valid program for %s phase."
                         % state["current_phase"]}


# =====================================================================
# EXERCISE 5: Compose — LLM proposes, rules verify
# =====================================================================

def decide(state):
    """Make a decision using the LLM with a rules-based fallback."""
    valid = get_valid_programs(state["current_phase"], state["program_defs"])

    # ── Block B: Try LLM first ──
    context = build_context(state)
    raw = query_llm(context)
    parsed = parse_llm_response(raw)
    if parsed and parsed.get("program") in valid:
        print("  [decide] LLM returned valid program '%s'" % parsed["program"])
        return parsed, "llm"

    # ── Block A: Fall back to rules ──
    rules_decision = decide_by_rules(state)
    if rules_decision:
        print("  [decide] LLM failed → falling back to rules: '%s'"
              % rules_decision["program"])
        return rules_decision, "rules"

    # ── Block C: Give up ──
    return {"program": valid[0] if valid else "unknown",
            "files": {}, "reasoning": "No decision available"}, "fallback"
