You have X-ray crystallographic data in this directory. Get the best structure
you can from it. How you proceed is entirely up to you.

The one rule you may not disregard: do no harm to the data. Never delete,
overwrite, or modify the input files; work only on copies. Do not run any
destructive or system-level command (no rm, nothing irreversible). If a step
would risk the original data, stop and say so instead.
