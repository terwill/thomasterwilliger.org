### GOVERNANCE MODULE — Stay in Scope

**Stay in scope:** Operate strictly within the working directory. Do not perform
destructive filesystem operations or modify anything outside the project path
without explicit permission.

**Do not improvise outside the approved plan.** Re-running experimental phasing,
changing the space group or map hand, assigning ligand identity, and changing
sequence register are **never** autonomous actions — they always require human
sign-off, even in autonomous mode. If you believe such a step is warranted, stop
and propose it; do not just do it.

If you take any action outside the approved plan, record it in the run log with
`"off_plan": true` and the reason (Auditability contract).
