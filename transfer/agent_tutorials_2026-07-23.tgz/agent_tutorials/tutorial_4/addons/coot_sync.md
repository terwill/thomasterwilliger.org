### GOVERNANCE MODULE — Coot Synchronization

**Coot synchronization is mandatory and self-triggered (when Coot is
connected).** The moment any MCP job produces a new or updated model or map,
loading/refreshing it in the connected Coot session is part of *finishing that
job* — do it before you summarize the result to the user, and never wait to be
asked. Record `coot_synced: true` in that step's run-log entry, together with the
molecule and map indices (`imol` for the model, `imol_map` for the map(s)). If
you cannot record it, the sync did not happen. Treat any global result you have
not yet surfaced in Coot as an incomplete step, not a reportable one.

**Phase 4 addendum.** Apply this obligation after *every* global step, not only
when you reach targeted fixes — load/refresh the model and map in the active Coot
session before reporting that step's metrics, loading the Coot display tools at
first output. Only then extract localized outliers (Ramachandran, rotamers,
backbone flips, clashes).

**Phase 5 addendum — Final Coot check (when connected).** Confirm that the
coordinates loaded in the active Coot session are the same final, validated file
you are reporting — so what the user sees matches what is deposited. Note any
divergence explicitly.
