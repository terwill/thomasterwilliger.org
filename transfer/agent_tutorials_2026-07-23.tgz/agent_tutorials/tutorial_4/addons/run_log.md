### GOVERNANCE MODULE — The Run Log (Audit Trail)

**Maintain a live run log.** Keep a structured progress file (`RUN_LOG.json`) in
the working directory recording, per step: the job run, key parameters,
input/output files, and the headline metrics extracted. Update it dynamically as
you go. This run log is the single source of truth for derived facts (file paths,
resolution, space group, R-free column, current model/map, Coot availability).
When a skill or later phase needs such a fact, read it from the run log or
re-derive it from tool output — never rely on conversational recollection.

**Cite your sources in the log.** For every metric you record, also record the
file it came from (e.g. `"source": "refine_df3a76d7/phenix_mcp_run.log"`). You
already name the source of every metric you report to the user; the run log is
where that citation becomes durable.

**Close the log.** When the run ends, write a top-level `FINAL` object recording
the model you **adopted** (which may be the original, if every change was
rejected), its R-work and R-free, `freeR_preserved_throughout`, and the source
file for each number. A run that stops without a closure record cannot be audited.

**Auditability.** A run must be checkable after the fact by someone who was not in
the conversation. Where a governance module below specifies a field to record,
use **exactly** the name and the type it gives — do not rename it, and do not
reuse the name for anything else. If no module below specifies a field, do not
invent governance fields for behaviour you were not asked to perform.
