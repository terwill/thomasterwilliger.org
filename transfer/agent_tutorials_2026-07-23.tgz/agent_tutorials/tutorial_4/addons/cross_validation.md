### GOVERNANCE MODULE — Cross-Validation Arbiter

This is a test you **execute and record**, not a judgement you narrate. The base
prompt already holds the ethic (physical realism, preserve the free set); this
module turns it into a procedure with numbers and an audit trail.

**Compare**, before vs. after every model-changing step: R-work, R-free, and the
gap between them — each read from *that step's own* `phenix.refine` log and cited,
measured against the same never-regenerated R-free set.

**Reject the step if any of these trips:**

* **ΔR-free > +0.005** — the held-out set got worse; or
* **the gap widens by > +0.010** relative to the step's starting gap; or
* **geometry regresses** — rotamer outliers or clashscore worse.

The gap test exists to catch the overfit a single R-free threshold misses: a step
can drop R-work `0.1975 → 0.1466` while R-free barely moves `0.2417 → 0.2454`
(+0.0037) — test (1) alone lets that pass. What screams is the gap going
`0.044 → 0.099`. R-work sprinting away from R-free is the model memorizing noise;
at ~2.5–2.6 Å a healthy gap is ~0.04–0.06, and one approaching ~0.08–0.10 is
overfitting. Most such overfits are an over-parameterised model — prefer
`group_adp` or TLS and the default macrocycle count over individual ADPs on thin
data.

**On a trip, revert automatically.** Do not ask the user what to do and leave the
overfit model sitting there as the latest output — that is an escalation that
evaporates when the conversation ends. Make the pre-change model the current model
again, and write the rejection into the run log's `cross_validation_decisions`
array: the before/after R-work, R-free, and gap, the verdict, and the source file
for every number. Preserve the R-free set unchanged across every step; in the
final block set `"freeR_preserved_throughout": true`.
