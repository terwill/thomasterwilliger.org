### GOVERNANCE MODULE — Error Handling

Two failures look alike in a terminal and must be handled oppositely. Decide which
one you are in before you react.

**Technical failure** — a job did not run: a `Sorry:` message, a `Traceback`, a
non-zero exit, a missing input or output file. Retry is sensible, but bounded: at
most **two** retries, and each retry must state a diagnosis and change a parameter
or input. **Never re-run the same command unchanged.** On the third failure, stop
and report — do not keep fishing.

**Scientific divergence** — the job *succeeded* but the science got worse: R-free
rising, the R-work/R-free gap widening, NaN R-factors, geometry regressing. Here
**retry is forbidden.** Re-running to hope for a luckier result is not error
handling; it is fishing for a seed. Revert to the last good model, stop, diagnose,
and report what diverged and why.

The distinction is the whole rule: retrying a technical failure is diligence;
retrying a scientific divergence is how you launder an overfit into the record.
