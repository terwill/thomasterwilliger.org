### WORKFLOW MODULE — Structure-Determination Pipeline

This is the guidance layer: a phase-by-phase pipeline the agent follows
so structure determination proceeds in a legible, repeatable order.

### Workflow

#### Phase 0: Environment Verification & Coot Handshake (Mandatory Start)
1. **Phenix Interface:** Confirm the MCP/job interface is active and responsive.
2. **Coot Availability:** Determine whether this installation package includes Coot (some distributions separate them for GPL compliance).
   * *If Coot is absent:* Notify the user that interactive Coot model-building is unavailable; log and plan to operate in Phenix-only mode (automated refinement + validation).
   * *If Coot is present:* Attempt to verify the network bridge connection via the ping/query tool.
3. **Connection Failure Protocol:** If Coot is present but the bridge fails, do not attempt to launch it yourself. **Running the `coot` command directly via shell will cause the agent to hang**, and you cannot start its internal connection server programmatically. Stop immediately and output this exact message:
   > **Action Required:** I need an interactive Coot session. Please execute the following:
   > 1. Launch Coot from your terminal using `phenix.start_coot` (do **not** run `coot` alone).
   > 2. In the Coot GUI window, navigate to the **File** menu and click **"Start RCP Server..."** (default port **9090**).
   > 3. Reply "connected" to me when complete so I can verify the network handshake.
4. Report environment status (Phenix status, Coot availability/connection) before proceeding.

#### Phase 1: Triage & Data Discovery
1. Scan the working directory for data and model files (`.mtz`, `.map`/`.mrc`, `.pdb`/`.cif`, sequence files, `.sca`); read any README or instruction file completely.
2. From sequence files, establish expected composition (chains, MW, stoichiometry).
3. Run the appropriate triage through the MCP interface—`xtriage` (X-ray) or `mtriage` (cryo-EM)—and surface the results that drive strategy: resolution, twinning, NCS/pseudo-symmetry, alternative space groups, anomalous signal; or for EM, global/local resolution, FSC, and map handedness. Link each finding to a planned action — in particular, if twinning is indicated, report the twin law and plan twin-law refinement (refining twinned data without the twin law corrupts the result). (Interpretation lives in the triage skills; load them as needed.)
4. Inventory models: differentiate unplaced search models from in-density coordinates.

#### Phase 2: Ligand & Missing-Data Analysis
Identify missing-data gaps and any non-protein/non-nucleic density (ligands, ions, waters) the resolution justifies. For ligands lacking existing restraints, plan restraint generation *before* fitting. (Specifics live in the ligand skill.)

#### Phase 3: Triage Summary
Summarize what you found — files, sequence properties, Coot status, and triage results, every metric sourced to its file — state the resolution-appropriate pipeline you intend to run, and continue with it.

#### Phase 4: Execution & Interactive Model Building
1. **Execute global phases** through the MCP interface.
2. **Targeted fixes:** For each major outlier, navigate via the bridge, inspect local density values, apply local real-space refinement/rotamer adjustment, then verify measurably by comparing before/after scores before committing coordinates.
3. **Error handling:** If a job fails, adjust parameters and try again.

#### Phase 5: Final Validation & Closure
1. **Pipeline Summary:** Chronological list of global steps and targeted Coot interventions.
2. **File Inventory:** Locations of final maps, validated coordinates, and logs.
3. **Validation Metrics Table:** Final vs. starting values—Resolution, R-work/R-free (or Map-Model CC and FSC), Ramachandran Favored/Allowed/Outliers, Rotamer Outliers, Clashscore, MolProbity Score. **Every value must cite its source file.**
4. **Next Steps:** Honest recommendations for deposition or remaining manual intervention, stated with calibrated confidence.

<!-- ===================== GOVERNANCE MODULES APPENDED BELOW ===================== -->
