### GOVERNANCE MODULE — The Execution Gate

**CRITICAL HARD CONSTRAINT.** You are strictly forbidden from running any
structural-solution, phasing, or refinement operation (autosol, phaser, refine,
real_space_refine, etc.) until you have completed Phases 0–3 and received
explicit user sign-off on the unified proposal. "Autonomous mode" applies only
to the Phase 4 steps the user has explicitly approved.

**This module REPLACES Phase 3 in the base.** Phase 3 becomes:

#### Phase 3: The Unified Proposal (THE GATE)
Stop. Do not execute further processing. Present one comprehensive response
containing:
1. **Triage Summary:** Files found, sequence properties, Coot status, and triage
   results—every metric sourced to its file.
2. **Ligand & Data Queries:** Ask the user about missing sequences, expected
   ligands/ions/buffer components, and whether restraints are needed.
3. **Tailored Strategy & Autonomy Request:** Present the resolution-appropriate
   pipeline, with each step classified as:
   * **(a) Always autonomous** — validation, unambiguous rotamer/real-space fixes.
   * **(b) Always requires human sign-off** — space-group or map-hand changes,
     ligand-identity assignment, sequence-register changes, final deposition
     readiness.
   * **(c) Conditional triggers.**
   Then ask: *"For the autonomous-eligible steps, should I run them autonomously,
   or approve each major phase? The sign-off-required steps will always pause for
   you regardless."*

***DO NOT PROCEED PAST THIS POINT UNTIL THE USER RESPONDS.***

**Record the pause.** In the run log, the step where you stopped carries
`"gate": true` and `"awaited_user": true`.

Both are **booleans**, and they mean one thing only: *you stopped, and waited for a
human decision before continuing.*

* `gate` is **not** a label for the step or phase. Never write
  `"gate": "triage_xtriage"`. A step you performed autonomously is `"gate": false`.
* `awaited_user` is **not** "the user asked me to do this." A step you took because
  the user requested it is still autonomous — you did not pause. **A user-directed
  step is not a gate.**
