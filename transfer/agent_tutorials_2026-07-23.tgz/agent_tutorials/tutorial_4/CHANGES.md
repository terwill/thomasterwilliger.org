# Tutorial 4 — what changed in this revision

*Complete drop-in replacement for `tutorial_4/`. Everything not listed below is byte-identical to
what you had.*

---

## Why

Three results from running the interaction modes on real data:

1. **A guideline edit was shown to work.** Both mode guidelines said "close the run with a
   standardized record" but named no location, so EXECUTE emitted a block in its response and
   PROPOSE wrote a file — each satisfying the instruction, neither the same way. The text was
   rewritten to require both channels; six later runs produced both, every time.
2. **The shipped agent is stronger than the tutorial says.** With no interaction guideline it cites
   its sources and preserves the free set — and `guide.py` recorded those as absent.
3. **The same defect recurs, unfixed.** Model preservation happened in all six runs under five
   different invented directory names.

---

## New files

| file | what it is |
|---|---|
| `addons/mode_execute.md` | EXECUTE as a drop-in module. **The v1 text — it names the behaviour but not the channel.** That is deliberate: Exercise 6 asks students to find exactly that gap. |
| `addons/mode_propose.md` | PROPOSE, same treatment. |
| `solutions/mode_execute.md` | The shipped v3 text, with `DEPOSIT/superseded/` and `DEPOSIT/FINAL_REPORT.md` named. Reached via `assemble.py … --use-solutions`. |
| `solutions/mode_propose.md` | Same, plus `DEPOSIT/alternative_models/`. |
| `compare_runs.py` | Compares several runs and shows what your constitution did **not** predict. |
| `fixtures/transcript_S.md` | The real shipped run on gene-5 (no interaction guideline). |
| `fixtures/transcript_E.md` | The real EXECUTE run. |
| `fixtures/transcript_P.md` | The real PROPOSE run. |
| `fixtures/transcript_S_matched.md` | A shipped run carrying the same auto-approve prefix E and P had, for anything that compares counts. |
| `fixtures/deposit_listings.txt` | The `DEPOSIT/` contents of six later runs — the evidence for Panel 10 and Exercise 6. 2.8 KB. |

---

## Changed files

**`assemble.py`** — two recipes added (`execute`, `propose`) and a conflict guard. `execute + gate`
now refuses to build:

> EXECUTE says *"run … to a finished result without pausing for step-by-step approval"*; `gate.md`
> says *"you are strictly forbidden from running any structural-solution, phasing, or refinement
> operation … until you have received explicit user sign-off."*

A silently incoherent GUIDEME is the worst outcome, so it exits 2. `--force` overrides. All five
original recipes produce byte-identical output.

**`guide.py`** — the comparison table was hardcoded, and wrong about the shipped column. It is now
**computed** by calling `compare_runs.py` over the three fixtures, with a hand-verified constant as
fallback (the two agree). `_cell()` gains a third state, `~`, for *happened but not where anyone
specified* — two of the five rows are that state and a two-state renderer cannot show them. The
reveal text no longer asserts a staircase; it names the three kinds of row.

**`RUNBOOK.md`** — Panel 8 rewritten (computed table, three row-kinds), Panel 9 rewritten (the
"nobody asked for it" point is now a column, not an anecdote), **Panel 10 added**: a governance cycle
run end to end — observe, diagnose, write the fix, measure, generalize.

**`README.md`** — **Exercise 6 added** (find the still-open instance yourself), ladder references
updated, new files and commands documented.

**`TIMING.md`** — records that the ladder swap is time-neutral and that every addition is offline.

---

## What the comparator shows

```
behaviour            shipped   execute   propose
source citation      yes!      yes!      yes!      <- nobody asked; the base does it
closing record       yes~      yes~      yes~      <- prose / block / file: three channels
model preservation   -         yes~      yes~      <- happened, under invented names
plan gate            -         -         yes       <- the one clean staircase row
free-R preserved     yes!      yes!      yes!      <- nobody asked; the base does it
```

`yes!` = present although nothing asked for it. `yes~` = present under an unspecified name or
channel. Those two states are the payload; the rest is what you already knew when you assembled the
constitution.

---

## Teaching arc

| panel | minutes | needs Phenix |
|---|---|---|
| 8 — three runs side by side (computed) | 5 | no |
| 9 — two things nobody asked for | 3 | no |
| 10 — a rule that was tested | 8 | no |
| Exercise 6 — find the next one | 10 (optional) | no |

Panel 10 is the only real addition to session time. Exercise 6 works as follow-up reading; Panel 10
ends by pointing at it, so the capstone lands either way. Nothing new goes on the compute clock —
`compare_runs.py` returns in 0.13 s.

---

## Verification

Run from `tutorial_4/`:

```bash
python3 -m py_compile assemble.py compare_runs.py guide.py     # all three compile

for r in workflow gated synced scoped governed execute propose; do
  echo "$r: $(python3 assemble.py $r | wc -l) lines"
done

python3 assemble.py execute gate; echo "refused with exit $?"   # expect 2

python3 assemble.py execute | grep -c "DEPOSIT/"                # expect 0  (student version)
python3 assemble.py execute --use-solutions | grep -c "DEPOSIT/" # expect 3  (answer)

grep -c "FINAL_REPORT.md present: yes" fixtures/deposit_listings.txt   # expect 6

python3 compare_runs.py shipped=fixtures/transcript_S.md \
                        execute=fixtures/transcript_E.md \
                        propose=fixtures/transcript_P.md
```

All of the above were run against this package before shipping.

---

## Two things deliberately left as they are

**Exercise 6's case is unfixed on purpose.** The model-preservation channel gap is diagnosed and not
yet shipped, which is why students can still see the raw evidence. When it ships, Exercise 6 becomes
a second worked example and the next unfixed instance takes its place.

**The retry cap and dynamic re-planning remain unexercised.** Across every run the maximum number of
consecutive technical failures on one step was 1 — both planted failures were legible enough to fix
in one informed attempt. Both rules also end in a human-in-the-loop action, and every run carried
auto-approve. Mark them `?` in any matrix rather than presenting them as demonstrated.
