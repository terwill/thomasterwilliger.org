refined_start/ — near-converged gene-5 model for fast demos.

  model.pdb     R-work 0.1975 / R-free 0.2401, C2, 263 free reflections
  data.mtz      the exact data this model was refined against
  sequence.dat  the 87-residue gene-V protein sequence

Point the agent here (instead of the raw SAD data) for any step past triage:
the Coot edit and the cross-validation arbiter are reached in ~2 minutes,
so you never wait on a full 13-minute autosol. See ../TIMING.md.
