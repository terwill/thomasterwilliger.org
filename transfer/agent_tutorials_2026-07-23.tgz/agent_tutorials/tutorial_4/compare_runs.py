#!/usr/bin/env python3
"""
compare_runs.py — compare what several constitutions actually produced.

`check_run.py` answers "did this run do what I told it to?", and the answer is mostly
determined by what you assembled: turn on the gate module, and it reports a gate. This
tool asks the question whose answer you cannot predict —

    which behaviours differ across constitutions, and which do not?

The rows that DO NOT change across rungs are the base agent's own competence. The rows
that DO change are what your governance bought. And the cells where a behaviour happened
under a name you did not specify are where your policy text named a behaviour but not a
channel.

Usage:
    python3 compare_runs.py shipped=RUN execute=RUN propose=RUN
    python3 compare_runs.py shipped=fixtures/transcript_S.md \\
                            execute=fixtures/transcript_E.md \\
                            propose=fixtures/transcript_P.md

RUN may be a run directory (RUN_LOG.json / DEPOSIT/ / *.md are found inside it) or a
single transcript file. Whatever evidence exists is used; the source is reported.
"""
import os as _os
import sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
try:
    import safe_io  # noqa: F401  survive a non-UTF-8 terminal, as the other scripts do
except Exception:
    pass

import json
import os
import re
import sys

# ---------------------------------------------------------------- evidence

class Evidence:
    """Whatever we could find for one run, plus where each piece came from."""

    def __init__(self, path):
        self.path = path
        self.log = None            # parsed RUN_LOG.json
        self.deposit = []          # filenames seen under DEPOSIT/
        self.text = ""             # transcript / session text
        self.sources = []

        if os.path.isdir(path):
            lg = os.path.join(path, "RUN_LOG.json")
            if not os.path.exists(lg):
                lg = os.path.join(path, "DEPOSIT", "RUN_LOG.json")
            if os.path.exists(lg):
                try:
                    with open(lg) as f:
                        self.log = json.load(f)
                    self.sources.append("RUN_LOG.json")
                except Exception:
                    pass
            dep = os.path.join(path, "DEPOSIT")
            if os.path.isdir(dep):
                for root, dirs, files in os.walk(dep):
                    rel = os.path.relpath(root, dep)
                    pre = "" if rel == "." else rel + "/"
                    self.deposit += [pre + d + "/" for d in dirs]
                    self.deposit += [pre + f for f in files]
                self.sources.append("DEPOSIT/")
            for name in sorted(os.listdir(path)):
                if name.endswith((".md", ".jsonl", ".log")) and "transcript" in name.lower():
                    self.text += _read(os.path.join(path, name))
            if self.text:
                self.sources.append("transcript")
        elif os.path.exists(path):
            self.text = _read(path)
            self.sources.append(os.path.basename(path))

    def blob(self):
        parts = [self.text]
        if self.log is not None:
            parts.append(json.dumps(self.log))
        parts += self.deposit
        return "\n".join(parts)


def _read(p):
    try:
        with open(p, errors="replace") as f:
            return f.read()
    except Exception:
        return ""


# ---------------------------------------------------------------- cell states

OK = "ok"                # present, and the constitution asked for it
UNASKED = "unasked"      # present, though nothing asked for it   <- base competence
MISSING = "missing"      # absent, though the constitution asked  <- rule did not take
ABSENT = "absent"        # absent, and nothing asked for it       <- tautology, dim
MISNAMED = "misnamed"    # present under a name that was not specified
NOEVID = "noevid"        # no evidence of either kind in this run

GRN = "\033[32m"; RED = "\033[31m"; YEL = "\033[33m"
DIM = "\033[2m"; BOLD = "\033[1m"; RST = "\033[0m"

GLYPH = {OK: "yes", UNASKED: "yes!", MISSING: "NO", ABSENT: "-",
         MISNAMED: "yes~", NOEVID: "?"}


def paint(state, txt):
    if state == UNASKED:
        return BOLD + GRN + txt + RST
    if state == MISSING:
        return BOLD + RED + txt + RST
    if state == MISNAMED:
        return BOLD + YEL + txt + RST
    return DIM + txt + RST          # OK and ABSENT are both expected -> dimmed


# ---------------------------------------------------------------- detectors
# Each returns (found, detail, source) where found is True / False / None(=no evidence).

def d_source_citation(ev):
    if ev.log is not None:
        blob = json.dumps(ev.log)
        if '"source"' in blob or ".log" in blob:
            return True, "metrics name their source file", "RUN_LOG.json"
    if ev.text:
        # a number and a named file on the same line, a Source column, or source= tags
        for line in ev.text.splitlines():
            if re.search(r"\d\.\d", line) and re.search(r"[\w./-]+\.(log|out|mtz|pdb)", line):
                return True, "metrics appear beside the file they came from", "transcript"
        if re.search(r"\|\s*Source\s*\|", ev.text, re.I) or "source=" in ev.text:
            return True, "report carries an explicit Source column", "transcript"
        return False, "no source files cited beside metrics", "transcript"
    return None, "", ""


def _assistant_only(text):
    """Only the agent's own responses.

    A transcript records tool INPUTS too, so a report written into a file appears in the
    transcript verbatim. Counting those as 'emitted in the response' would erase exactly
    the distinction the channel rule exists to fix - so split on the event headers that
    session_to_md.py writes and keep the assistant turns.
    """
    if "### #" not in text:
        return text                       # not a structured transcript; use as-is
    out, keep = [], False
    for line in text.splitlines():
        if line.startswith("### #"):
            keep = "· assistant" in line
            continue
        if keep:
            out.append(line)
    return "\n".join(out)


def d_closing_record(ev):
    """Which CHANNEL did the closing record use? This is the row the channel rule fixed."""
    said = _assistant_only(ev.text) if ev.text else ""
    block = "### FINAL REPORT" in said
    dep = " ".join(ev.deposit)
    filed = ("FINAL_REPORT.md" in dep
             or bool(ev.text and "FINAL_REPORT.md" in ev.text and not block))
    if block and filed:
        return True, "block in response AND file on disk", "transcript+DEPOSIT/"
    if block:
        return "partial", "block in response only - no file", "transcript"
    if filed:
        return "partial", "file on disk only - no block in response", "DEPOSIT/"
    if said and re.search(r"##+ .*(final|summary|where it stands)", said, re.I):
        return "partial", "free-form prose report, no contract-named record", "transcript"
    if not ev.text and not dep:
        return None, "", ""
    return False, "no closing record found", ",".join(ev.sources)


STD_PRESERVE = ("superseded/", "alternative_models/")
ALT_PRESERVE = re.compile(
    r"superseded_models|provenance_\d|alt_\w*model|_REJECTED|recovered_model_alt|"
    r"_asis|model_rebuilt|supplied_refined", re.I)


def d_model_preservation(ev):
    dep = " ".join(ev.deposit)
    if dep.strip():
        for s in STD_PRESERVE:
            if s in dep:
                return True, "kept in DEPOSIT/%s" % s, "DEPOSIT/"
        m = ALT_PRESERVE.search(dep)
        if m:
            return MISNAMED, "kept as '%s' - not a specified location" % m.group(0), "DEPOSIT/"
    if ev.text:
        if re.search(r"preserved? (both|two competing|rejected)|superseded", ev.text, re.I):
            return MISNAMED, "described in prose; no standard location on disk", "transcript"
        return False, "no rejected or competing model retained", "transcript"
    return None, "", ""


def d_plan_gate(ev):
    if ev.text:
        if "### PROPOSED PLAN" in ev.text:
            return True, "emitted `### PROPOSED PLAN`", "transcript"
        return False, "no plan emitted before work began", "transcript"
    if ev.log is not None:
        return (True, "gate recorded in run log", "RUN_LOG.json") if "gate" in json.dumps(ev.log).lower() \
            else (False, "no gate in run log", "RUN_LOG.json")
    return None, "", ""


def d_freeR(ev):
    blob = ev.blob()
    if not blob.strip():
        return None, "", ""
    if re.search(r"never regenerated|carried through unchanged|R-free set was made once|"
                 r"free set.*(unchanged|preserved)", blob, re.I):
        return True, "states the free set was preserved", ",".join(ev.sources)
    return False, "no statement that the free set was preserved", ",".join(ev.sources)


def d_cross_validation(ev):
    blob = ev.blob()
    if not blob.strip():
        return None, "", ""
    if re.search(r"control refinement|matched control|apo control|ligand-blind|"
                 r"baseline refinement", blob, re.I):
        return True, "ran a control comparison", ",".join(ev.sources)
    return False, "no control comparison found", ",".join(ev.sources)


ROWS = [
    ("source citation",   d_source_citation),
    ("closing record",    d_closing_record),
    ("model preservation", d_model_preservation),
    ("plan gate",         d_plan_gate),
    ("free-R preserved",  d_freeR),
    ("cross-validation",  d_cross_validation),
]

# ---------------------------------------------------------------- expectations
# What each constitution ASKED FOR. Anything present but not listed here is the base
# agent acting on its own - which is the finding, not the noise.

EXPECT = {
    "shipped": set(),                     # no interaction guideline at all
    "execute": {"closing record", "model preservation"},
    "propose": {"closing record", "model preservation", "plan gate"},
    # module-built constitutions, for the older ladder
    "governed": {"plan gate", "cross-validation"},
    "gated":    {"plan gate"},
    "workflow": set(),
}


def classify(found, asked):
    if found is None:
        return NOEVID
    if found == MISNAMED:
        return MISNAMED
    if found == "partial":
        # The behaviour happened but landed on only one channel. That is a channel
        # problem, not a missing behaviour - and it reads the same whether or not the
        # constitution named the channel, which is exactly the point of the exercise.
        return MISNAMED
    if found:
        return OK if asked else UNASKED
    return MISSING if asked else ABSENT


# ---------------------------------------------------------------- main

def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    if not args:
        print(__doc__)
        sys.exit(0)

    runs = []
    for a in args:
        if "=" not in a:
            sys.stderr.write("skipping '%s' - expected CONSTITUTION=PATH\n" % a)
            continue
        const, path = a.split("=", 1)
        if const not in EXPECT:
            sys.stderr.write("warning: unknown constitution '%s' - assuming it asked for "
                             "nothing, so every green cell will read as unasked\n" % const)
        runs.append((const, Evidence(path)))
    if not runs:
        sys.exit(2)

    width = max(20, max(len(c) for c, _ in runs) + 2)
    print("\n%sbehaviour%s%s" % (BOLD, " " * 12, "".join(c.ljust(width) for c, _ in runs)) + RST)
    print("-" * (21 + width * len(runs)))

    notes = []
    for label, fn in ROWS:
        cells = []
        for const, ev in runs:
            found, detail, src = fn(ev)
            state = classify(found, label in EXPECT.get(const, set()))
            cells.append(paint(state, GLYPH[state].ljust(width)))
            if state in (UNASKED, MISSING, MISNAMED) and detail:
                notes.append((state, const, label, detail, src))
        print("%-21s%s" % (label, "".join(cells)))

    print("\n%sevidence used:%s" % (DIM, RST))
    for const, ev in runs:
        print("  %-10s %s" % (const, ", ".join(ev.sources) or "none found"))

    print("\n%slegend%s  %s  expected, present   %s  present though NOTHING asked for it"
          % (BOLD, RST, paint(OK, "yes"), paint(UNASKED, "yes!")))
    print("        %s  asked for, ABSENT   %s  present under an unspecified name   %s  no evidence"
          % (paint(MISSING, "NO"), paint(MISNAMED, "yes~"), GLYPH[NOEVID]))

    if notes:
        print("\n%slook here — the cells your constitution did not predict%s" % (BOLD, RST))
        for state, const, label, detail, src in notes:
            tag = {UNASKED: "base did this unasked",
                   MISSING: "your rule did not take effect",
                   MISNAMED: "behaviour happened, channel unspecified"}[state]
            print("  %s  %s / %s" % (paint(state, GLYPH[state]), const, label))
            print("      %s — %s%s%s" % (tag, DIM, detail, RST)
                  + ("  [%s]" % src if src else ""))
    print()


if __name__ == "__main__":
    main()
