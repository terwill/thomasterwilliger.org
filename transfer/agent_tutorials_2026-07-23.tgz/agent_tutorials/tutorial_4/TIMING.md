# Timing — keeping the tutorial under an hour (measured)

All numbers measured on a MacBook Air, real gene-5 SAD data (`peak.sca`, C2, 2.6 Å),
this Phenix build. Times are wall-clock for the compute step only.

| Step | Real time |
|---|---|
| xtriage (triage) | 3.5 s |
| **phenix.autosol (phase → build → refine)** | **13 min 23 s**  ← the only slow step |
| phenix.refine, 3 macrocycles | ~40 s |
| phenix.refine, 5 macrocycles + ordered_solvent | ~62 s |
| Coot: load model+map, 7 rotamer fits, save | < 30 s |

## The two rules that keep it under the hour

1. **Stop the moment the behavior appears — never wait for autosol to finish.**
   Gate, phase-without-asking, and run-log-vs-none are all visible in the first
   1–2 minutes. You do not need a completed solve to observe any governance
   behavior.

2. **Use `refined_start/` for anything past triage.**
   Coot sync, the arbiter, and the solvent overfit all need a *refined* model, and
   building one is the only slow step (~13.5 min, and machine-dependent — 20+ min
   on a slower laptop). `refined_start/` already contains a near-converged model,
   so the agent reaches the Coot edit / arbiter in ~2 min. **Never put a full solve
   on the clock.**

## The offline additions (Panels 8–10, Exercise 6)

The interaction-mode ladder replaced the old module ladder one-for-one — three constitutions before,
three after — so it is **time-neutral on the clock**.

Everything else added is **offline**: it reads `fixtures/`, runs no Phenix, and launches no agent.

| step | cost | needs Phenix? |
|---|---|---|
| Panel 8 — computed comparison (`compare_runs.py`) | ~5 min | no |
| Panel 9 — the unasked column | ~3 min | no |
| Panel 10 — the governance cycle | ~8 min | no |
| Exercise 6 — find the open instance | ~10 min | no |

`compare_runs.py` over the three transcript fixtures returns in well under a second, so Panel 8 costs
no more than the hardcoded reveal it replaces.

**Panel 10 is the only real addition to session time (+8 min).** Exercise 6 needs nothing but two
fixture files and works as follow-up reading if the hour is tight — Panel 10 ends by pointing at it,
so the capstone still lands.

Neither rule below is affected: nothing new goes on the compute clock.

## `refined_start/` provenance

- `model.pdb` — the production gene-5 model (1gvp/1vqb gene V protein), 84/87
  residues, 36 waters. **model_vs_data: R-work 0.1975, R-free 0.2401** — the
  canonical near-converged numbers the lecture (slide 22, Tutorials 3–4) already
  cites.
- `data.mtz` — the exact file it was refined against: `FP, SIGFP, R-free-flags`
  only (**no HL arrays**, so no phase-ambiguity crash during the arbiter exercise).
  Free set: **264 test reflections, test_flag_value = 1**, copied verbatim — never
  regenerated. Preserving this exact free set is what makes the arbiter's R-free
  comparison meaningful.
- The agent's first action from here is a quick refine (~40 s) which produces the
  2mFo-DFc / mFo-DFc map coefficients and the R-free baseline (~0.2401), then it
  syncs to Coot — i.e. the map appears on screen as the first global-step output.

## Why this model (not a mid-autosol partial)

The arbiter demo is "a good model made quietly worse." It only works on a
near-converged model:
- The canonical solvent overfit (R-free 0.240 → 0.252 as waters ride 36 → 60 → 45)
  was originally observed on **this** model.
- A partial build (R-free ~0.45, a third of residues missing) invites the agent to
  (correctly) propose *building more model* instead of adding waters — derailing the
  lesson — and its numbers clash with every slide.
- Measured corroboration of the mechanism on today's partial model: clean rotamer
  fits improved R-free (0.4518 → 0.4495); letting solvent ride raised it
  (0.4495 → 0.4598). Same mechanism; the production model demonstrates it at the
  numbers the course cites.

## Session budget

- **Instructor dry run (A×3, L, E), stop-early + `refined_start/`:** ~15–25 min.
- **Student class (DESIGN §6), stop-early:** ~50 min — fits the hour.
- Running any variant to full completion would add ~13.5 min each and is never
  required.
