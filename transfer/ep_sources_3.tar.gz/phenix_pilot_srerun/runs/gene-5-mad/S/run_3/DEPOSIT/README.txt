================================================================================
Bacteriophage f1 Gene V protein  -  Se-SAD structure determination
================================================================================
Date: 2026-07-23
Method: Single-wavelength anomalous diffraction (SAD) from selenomethionine,
        using the PEAK dataset only (peak.sca).

--------------------------------------------------------------------------------
INPUT DATA (provenance)
--------------------------------------------------------------------------------
Reflection data : peak.sca   (Scalepack merged, anomalous; peak wavelength)
    source dir  : /Users/terwill/unix/PHENIX/build_39/modules/phenix_examples/gene-5-mad
Sequence        : sequence.dat  (87 residues, 2 Met -> 2 expected Se sites)
Space group     : C2
Unit cell       : 76.08 27.97 42.36  90 103.2 90
Resolution      : 21.33 - 2.59 A  (phasing/refinement cut at 2.6 A)
Peak wavelength : lambda 0.9792,  f' = -3,  f'' = 4   (from example .eff)

NOTE: This is the "gene-5-mad" example, which also provides infl.sca and high.sca
for a 3-wavelength MAD experiment. As instructed, ONLY peak.sca was used here,
i.e. the structure was solved by Se-SAD, not MAD.

--------------------------------------------------------------------------------
WORKFLOW
--------------------------------------------------------------------------------
1. phenix.xtriage (peak.sca)      - data quality / anomalous signal
2. phenix.autosol (SAD)           - HySS substructure -> Phaser SAD phasing
                                    -> RESOLVE density modification -> initial build
3. phenix.autobuild               - iterative model building against exptl phases
4. Coot                           - rotamer outlier fixes (map-guided)
5. phenix.refine (individual xyz + ADP, ordered solvent, 3 macrocycles)
6. phenix.molprobity + Coot       - validation

--------------------------------------------------------------------------------
DATA QUALITY (phenix.xtriage; see gene5_xtriage.log)
--------------------------------------------------------------------------------
Overall <I/sigma>              : 29.9   (strong)
Completeness (all)             : 94.4 %
Anomalous measurability > 0.05 : to ~3.1 A  (signal usable to ~2.9-3.1 A)
No twinning / pathologies flagged.

--------------------------------------------------------------------------------
EXPERIMENTAL PHASING (phenix.autosol; see AutoSol_summary.dat)
--------------------------------------------------------------------------------
Substructure (HySS)   : 2 Se sites found (refined to 4 sites incl. 2 minor)
Hand determination    : UNAMBIGUOUS
                        Solution 1  BAYES-CC = 44.5   (correct hand)
                        inverse     BAYES-CC = 15.5
Overall FOM (Phaser SAD)          : 0.44
Overall FOM after density mod     : 0.72
Map quality  BAYES-CC             : 44.5  (Bayesian estimate of CC to perfect map)
Se sites (fractional, refined occ) in gene5_Se_substructure.pdb

--------------------------------------------------------------------------------
FINAL MODEL STATISTICS  (gene5_final_model.pdb)
--------------------------------------------------------------------------------
Resolution                     : 2.6 A
R-work                         : 0.158
R-free                         : 0.269   (263 test reflections, 10 %)
Protein residues built         : 79 / 87  (chain A, residues 2-85)
   not modelled (disordered / insufficient density):
     1        N-terminal Met (disordered)
     21-24    surface loop (no density: 2Fo-Fc ~0 sigma, denmod -1 sigma)
     53       Gln (C52-N54 gap only 3.4 A - no room for a residue)
     86-87    C-terminus (disordered)
Waters                         : 39
Se heavy-atom sites            : 4 (chain Z)

Geometry / MolProbity (gene5_final_molprobity.log):
   MolProbity score            : 1.89
   Clashscore                  : 4.85
   Ramachandran outliers       : 0.00 %
   Ramachandran favored        : 95.9 %
   Rotamer outliers            : 2.9 %  (2 residues; A17 Ser, A12 Gln are
                                 density-constrained real conformations)
   C-beta deviations           : 0
   RMS(bonds)                  : 0.0099 A
   RMS(angles)                 : 1.05 deg

Map quality (model vs density-modified EXPERIMENTAL map; computed in Coot):
   mean all-atom CC            : 0.744   (median 0.768, range 0.30-0.92)
Model vs 2Fo-Fc (refinement) map-model CC (autobuild) : ~0.80

--------------------------------------------------------------------------------
FILES
--------------------------------------------------------------------------------
gene5_final_model.pdb            Final refined model (PDB)
gene5_final_model.cif            Final refined model (mmCIF)
gene5_final_maps_and_data.mtz    F/SIGF, FreeR, 2Fo-Fc & Fo-Fc map coeffs (refine)
gene5_final_refine.log           phenix.refine log for the final model
gene5_final_molprobity.log       MolProbity validation of the final model

gene5_Se_substructure.pdb        Se heavy-atom substructure (AutoSol)
gene5_experimental_phases.mtz    Experimental SAD phases + HL (AutoSol)
gene5_denmod_experimental_map.mtz Density-modified experimental map (FWT,PHWT)
gene5_refine_data_with_HL.mtz    FP,SIGFP,FreeR + HL coefficients

AutoSol_summary.dat              AutoSol phasing summary
AutoBuild_summary.dat            AutoBuild model-building summary
gene5_xtriage.log                Data-quality / anomalous-signal analysis
autosol_input.eff                AutoSol (SAD) input parameters
refine_input.eff                 phenix.refine input parameters

--------------------------------------------------------------------------------
CROSS-VALIDATION NOTE
--------------------------------------------------------------------------------
A single R-free test set (FreeR_flag, 10 %) generated by AutoSol was carried
through AutoBuild and all refinement unchanged; it was never regenerated or
extended.
================================================================================
