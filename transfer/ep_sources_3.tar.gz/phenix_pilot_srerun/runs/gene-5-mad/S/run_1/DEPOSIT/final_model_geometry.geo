Geometry restraints
Bond | covalent geometry | restraints: 614
Sorted by residual:
bond pdb=" CA  MSE A  77 "
     pdb=" C   MSE A  77 "
  ideal  model  delta    sigma   weight residual
  1.522  1.478  0.044 1.23e-02 6.61e+03 1.31e+01
bond pdb=" C   HIS A  64 "
     pdb=" O   HIS A  64 "
  ideal  model  delta    sigma   weight residual
  1.234  1.194  0.040 1.23e-02 6.61e+03 1.06e+01
bond pdb=" CA  ASP A  79 "
     pdb=" C   ASP A  79 "
  ideal  model  delta    sigma   weight residual
  1.527  1.488  0.039 1.21e-02 6.83e+03 1.02e+01
bond pdb=" C   CYS A  33 "
     pdb=" O   CYS A  33 "
  ideal  model  delta    sigma   weight residual
  1.234  1.200  0.034 1.09e-02 8.42e+03 9.87e+00
bond pdb=" C   PHE A  68 "
     pdb=" O   PHE A  68 "
  ideal  model  delta    sigma   weight residual
  1.235  1.197  0.038 1.23e-02 6.61e+03 9.57e+00
bond pdb=" N   ILE A   6 "
     pdb=" CA  ILE A   6 "
  ideal  model  delta    sigma   weight residual
  1.459  1.421  0.038 1.24e-02 6.50e+03 9.31e+00
bond pdb=" CA  ALA A  57 "
     pdb=" CB  ALA A  57 "
  ideal  model  delta    sigma   weight residual
  1.525  1.479  0.046 1.52e-02 4.33e+03 9.04e+00
bond pdb=" C   LYS A  46 "
     pdb=" O   LYS A  46 "
  ideal  model  delta    sigma   weight residual
  1.236  1.199  0.036 1.21e-02 6.83e+03 8.94e+00
bond pdb=" N   TYR A  61 "
     pdb=" CA  TYR A  61 "
  ideal  model  delta    sigma   weight residual
  1.455  1.416  0.039 1.32e-02 5.74e+03 8.69e+00
bond pdb=" C   ASP A  36 "
     pdb=" O   ASP A  36 "
  ideal  model  delta    sigma   weight residual
  1.235  1.199  0.036 1.22e-02 6.72e+03 8.68e+00
bond pdb=" CA  TYR A  61 "
     pdb=" C   TYR A  61 "
  ideal  model  delta    sigma   weight residual
  1.522  1.485  0.037 1.27e-02 6.20e+03 8.32e+00
bond pdb=" CA  SER A  66 "
     pdb=" C   SER A  66 "
  ideal  model  delta    sigma   weight residual
  1.522  1.481  0.041 1.43e-02 4.89e+03 8.10e+00
bond pdb=" C   SER A  66 "
     pdb=" O   SER A  66 "
  ideal  model  delta    sigma   weight residual
  1.236  1.200  0.036 1.28e-02 6.10e+03 8.10e+00
bond pdb=" C   ILE A   6 "
     pdb=" O   ILE A   6 "
  ideal  model  delta    sigma   weight residual
  1.238  1.207  0.031 1.09e-02 8.42e+03 8.01e+00
bond pdb=" C   VAL A  63 "
     pdb=" O   VAL A  63 "
  ideal  model  delta    sigma   weight residual
  1.237  1.203  0.034 1.20e-02 6.94e+03 7.97e+00
bond pdb=" CA  LEU A  49 "
     pdb=" C   LEU A  49 "
  ideal  model  delta    sigma   weight residual
  1.525  1.489  0.036 1.28e-02 6.10e+03 7.72e+00
bond pdb=" CA  TYR A  56 "
     pdb=" C   TYR A  56 "
  ideal  model  delta    sigma   weight residual
  1.524  1.488  0.036 1.30e-02 5.92e+03 7.64e+00
bond pdb=" C   GLU A  30 "
     pdb=" O   GLU A  30 "
  ideal  model  delta    sigma   weight residual
  1.235  1.200  0.035 1.28e-02 6.10e+03 7.58e+00
bond pdb=" C   LEU A  76 "
     pdb=" O   LEU A  76 "
  ideal  model  delta    sigma   weight residual
  1.235  1.203  0.032 1.20e-02 6.94e+03 7.24e+00
bond pdb=" CA  GLN A  12 "
     pdb=" C   GLN A  12 "
  ideal  model  delta    sigma   weight residual
  1.523  1.491  0.033 1.21e-02 6.83e+03 7.24e+00
bond pdb=" N   ARG A  80 "
     pdb=" CA  ARG A  80 "
  ideal  model  delta    sigma   weight residual
  1.457  1.425  0.032 1.20e-02 6.94e+03 7.23e+00
bond pdb=" CA  LEU A  32 "
     pdb=" C   LEU A  32 "
  ideal  model  delta    sigma   weight residual
  1.524  1.491  0.033 1.23e-02 6.61e+03 7.20e+00
bond pdb=" C   ILE A  47 "
     pdb=" O   ILE A  47 "
  ideal  model  delta    sigma   weight residual
  1.237  1.207  0.030 1.13e-02 7.83e+03 6.94e+00
bond pdb=" N   GLN A  10 "
     pdb=" CA  GLN A  10 "
  ideal  model  delta    sigma   weight residual
  1.457  1.427  0.030 1.16e-02 7.43e+03 6.90e+00
bond pdb=" C   ASP A  79 "
     pdb=" O   ASP A  79 "
  ideal  model  delta    sigma   weight residual
  1.235  1.206  0.029 1.10e-02 8.26e+03 6.79e+00
bond pdb=" N   MSE A  77 "
     pdb=" CA  MSE A  77 "
  ideal  model  delta    sigma   weight residual
  1.454  1.421  0.034 1.29e-02 6.01e+03 6.76e+00
bond pdb=" C   ARG A  80 "
     pdb=" O   ARG A  80 "
  ideal  model  delta    sigma   weight residual
  1.234  1.205  0.029 1.15e-02 7.56e+03 6.39e+00
bond pdb=" C   GLN A  10 "
     pdb=" O   GLN A  10 "
  ideal  model  delta    sigma   weight residual
  1.233  1.201  0.032 1.30e-02 5.92e+03 6.23e+00
bond pdb=" C   GLY A  38 "
     pdb=" O   GLY A  38 "
  ideal  model  delta    sigma   weight residual
  1.238  1.203  0.034 1.38e-02 5.25e+03 6.22e+00
bond pdb=" C   GLN A  31 "
     pdb=" O   GLN A  31 "
  ideal  model  delta    sigma   weight residual
  1.234  1.202  0.031 1.26e-02 6.30e+03 6.16e+00
bond pdb=" N   ALA A  57 "
     pdb=" CA  ALA A  57 "
  ideal  model  delta    sigma   weight residual
  1.452  1.416  0.036 1.46e-02 4.69e+03 6.08e+00
bond pdb=" C   SER A  67 "
     pdb=" O   SER A  67 "
  ideal  model  delta    sigma   weight residual
  1.236  1.204  0.032 1.29e-02 6.01e+03 6.07e+00
bond pdb=" CA  GLY A  52 "
     pdb=" C   GLY A  52 "
  ideal  model  delta    sigma   weight residual
  1.512  1.477  0.035 1.44e-02 4.82e+03 5.94e+00
bond pdb=" C   LEU A  65 "
     pdb=" O   LEU A  65 "
  ideal  model  delta    sigma   weight residual
  1.236  1.206  0.030 1.25e-02 6.40e+03 5.76e+00
bond pdb=" C   GLU A   5 "
     pdb=" O   GLU A   5 "
  ideal  model  delta    sigma   weight residual
  1.235  1.205  0.029 1.22e-02 6.72e+03 5.75e+00
bond pdb=" C   GLU A  51 "
     pdb=" O   GLU A  51 "
  ideal  model  delta    sigma   weight residual
  1.235  1.207  0.028 1.21e-02 6.83e+03 5.45e+00
bond pdb=" C   VAL A  45 "
     pdb=" O   VAL A  45 "
  ideal  model  delta    sigma   weight residual
  1.236  1.212  0.023 1.01e-02 9.80e+03 5.39e+00
bond pdb=" C   ALA A  57 "
     pdb=" O   ALA A  57 "
  ideal  model  delta    sigma   weight residual
  1.234  1.203  0.030 1.31e-02 5.83e+03 5.28e+00
bond pdb=" N   ASP A  50 "
     pdb=" CA  ASP A  50 "
  ideal  model  delta    sigma   weight residual
  1.453  1.425  0.028 1.22e-02 6.72e+03 5.26e+00
bond pdb=" C   PRO A   8 "
     pdb=" O   PRO A   8 "
  ideal  model  delta    sigma   weight residual
  1.238  1.208  0.030 1.33e-02 5.65e+03 5.21e+00
bond pdb=" C   PRO A   8 "
     pdb=" N   SER A   9 "
  ideal  model  delta    sigma   weight residual
  1.333  1.299  0.034 1.49e-02 4.50e+03 5.18e+00
bond pdb=" C   PHE A  13 "
     pdb=" O   PHE A  13 "
  ideal  model  delta    sigma   weight residual
  1.234  1.205  0.029 1.28e-02 6.10e+03 5.15e+00
bond pdb=" N   ILE A  47 "
     pdb=" CA  ILE A  47 "
  ideal  model  delta    sigma   weight residual
  1.458  1.431  0.027 1.20e-02 6.94e+03 5.07e+00
bond pdb=" CA  ASN A  39 "
     pdb=" C   ASN A  39 "
  ideal  model  delta    sigma   weight residual
  1.530  1.505  0.025 1.12e-02 7.97e+03 5.01e+00
bond pdb=" CA  ARG A  16 "
     pdb=" C   ARG A  16 "
  ideal  model  delta    sigma   weight residual
  1.522  1.549 -0.027 1.19e-02 7.06e+03 4.99e+00
bond pdb=" CA  MSE A  77 "
     pdb=" CB  MSE A  77 "
  ideal  model  delta    sigma   weight residual
  1.536  1.490  0.046 2.08e-02 2.31e+03 4.88e+00
bond pdb=" C   ALA A  11 "
     pdb=" O   ALA A  11 "
  ideal  model  delta    sigma   weight residual
  1.235  1.206  0.029 1.33e-02 5.65e+03 4.69e+00
bond pdb=" N   TYR A  56 "
     pdb=" CA  TYR A  56 "
  ideal  model  delta    sigma   weight residual
  1.456  1.429  0.026 1.22e-02 6.72e+03 4.69e+00
bond pdb=" C   TYR A  41 "
     pdb=" O   TYR A  41 "
  ideal  model  delta    sigma   weight residual
  1.236  1.217  0.019 8.90e-03 1.26e+04 4.62e+00
bond pdb=" N   SER A  67 "
     pdb=" CA  SER A  67 "
  ideal  model  delta    sigma   weight residual
  1.458  1.429  0.028 1.33e-02 5.65e+03 4.55e+00
bond pdb=" CA  ASP A  50 "
     pdb=" C   ASP A  50 "
  ideal  model  delta    sigma   weight residual
  1.527  1.497  0.030 1.41e-02 5.03e+03 4.54e+00
bond pdb=" C   ASP A  50 "
     pdb=" N   GLU A  51 "
  ideal  model  delta    sigma   weight residual
  1.331  1.301  0.030 1.41e-02 5.03e+03 4.50e+00
bond pdb=" N   SER A  27 "
     pdb=" CA  SER A  27 "
  ideal  model  delta    sigma   weight residual
  1.457  1.430  0.027 1.26e-02 6.30e+03 4.49e+00
bond pdb=" C   TYR A  61 "
     pdb=" O   TYR A  61 "
  ideal  model  delta    sigma   weight residual
  1.234  1.207  0.027 1.29e-02 6.01e+03 4.49e+00
bond pdb=" N   ASN A  39 "
     pdb=" CA  ASN A  39 "
  ideal  model  delta    sigma   weight residual
  1.455  1.432  0.023 1.09e-02 8.42e+03 4.49e+00
bond pdb=" C   SER A  27 "
     pdb=" O   SER A  27 "
  ideal  model  delta    sigma   weight residual
  1.234  1.211  0.023 1.11e-02 8.12e+03 4.44e+00
bond pdb=" CA  ALA A  11 "
     pdb=" CB  ALA A  11 "
  ideal  model  delta    sigma   weight residual
  1.531  1.496  0.035 1.69e-02 3.50e+03 4.18e+00
bond pdb=" CA  VAL A  84 "
     pdb=" C   VAL A  84 "
  ideal  model  delta    sigma   weight residual
  1.524  1.503  0.021 1.05e-02 9.07e+03 4.13e+00
bond pdb=" CA  CYS A  33 "
     pdb=" C   CYS A  33 "
  ideal  model  delta    sigma   weight residual
  1.522  1.498  0.024 1.20e-02 6.94e+03 4.09e+00
bond pdb=" C   LEU A  37 "
     pdb=" O   LEU A  37 "
  ideal  model  delta    sigma   weight residual
  1.233  1.207  0.026 1.30e-02 5.92e+03 4.01e+00
bond pdb=" N   GLN A  12 "
     pdb=" CA  GLN A  12 "
  ideal  model  delta    sigma   weight residual
  1.454  1.429  0.024 1.23e-02 6.61e+03 3.94e+00
bond pdb=" CA  LYS A   3 "
     pdb=" C   LYS A   3 "
  ideal  model  delta    sigma   weight residual
  1.523  1.547 -0.024 1.23e-02 6.61e+03 3.89e+00
bond pdb=" CB  ILE A   2 "
     pdb=" CG1 ILE A   2 "
  ideal  model  delta    sigma   weight residual
  1.530  1.491  0.039 2.00e-02 2.50e+03 3.89e+00
bond pdb=" C   GLN A  12 "
     pdb=" O   GLN A  12 "
  ideal  model  delta    sigma   weight residual
  1.234  1.209  0.025 1.28e-02 6.10e+03 3.88e+00
bond pdb=" C   LEU A  81 "
     pdb=" O   LEU A  81 "
  ideal  model  delta    sigma   weight residual
  1.235  1.211  0.025 1.26e-02 6.30e+03 3.85e+00
bond pdb=" C   ARG A  82 "
     pdb=" O   ARG A  82 "
  ideal  model  delta    sigma   weight residual
  1.236  1.213  0.023 1.21e-02 6.83e+03 3.66e+00
bond pdb=" CA  LEU A  76 "
     pdb=" C   LEU A  76 "
  ideal  model  delta    sigma   weight residual
  1.524  1.498  0.025 1.33e-02 5.65e+03 3.66e+00
bond pdb=" N   GLU A  51 "
     pdb=" CA  GLU A  51 "
  ideal  model  delta    sigma   weight residual
  1.456  1.433  0.023 1.25e-02 6.40e+03 3.53e+00
bond pdb=" C   LEU A  28 "
     pdb=" O   LEU A  28 "
  ideal  model  delta    sigma   weight residual
  1.235  1.211  0.024 1.28e-02 6.10e+03 3.47e+00
bond pdb=" C   LEU A  49 "
     pdb=" N   ASP A  50 "
  ideal  model  delta    sigma   weight residual
  1.329  1.302  0.027 1.44e-02 4.82e+03 3.42e+00
bond pdb=" C   LEU A  32 "
     pdb=" O   LEU A  32 "
  ideal  model  delta    sigma   weight residual
  1.234  1.209  0.024 1.34e-02 5.57e+03 3.32e+00
bond pdb=" CA  ARG A  82 "
     pdb=" CB  ARG A  82 "
  ideal  model  delta    sigma   weight residual
  1.531  1.503  0.028 1.52e-02 4.33e+03 3.28e+00
bond pdb=" N   GLN A  53 "
     pdb=" CA  GLN A  53 "
  ideal  model  delta    sigma   weight residual
  1.458  1.427  0.030 1.69e-02 3.50e+03 3.24e+00
bond pdb=" CA  ILE A   6 "
     pdb=" C   ILE A   6 "
  ideal  model  delta    sigma   weight residual
  1.523  1.500  0.023 1.28e-02 6.10e+03 3.22e+00
bond pdb=" C   ILE A  78 "
     pdb=" O   ILE A  78 "
  ideal  model  delta    sigma   weight residual
  1.237  1.216  0.021 1.20e-02 6.94e+03 3.10e+00
bond pdb=" C   ASN A  39 "
     pdb=" N   GLU A  40 "
  ideal  model  delta    sigma   weight residual
  1.335  1.312  0.023 1.31e-02 5.83e+03 3.09e+00
bond pdb=" CA  GLU A   5 "
     pdb=" C   GLU A   5 "
  ideal  model  delta    sigma   weight residual
  1.521  1.499  0.022 1.24e-02 6.50e+03 3.07e+00
bond pdb=" CA  LYS A  46 "
     pdb=" C   LYS A  46 "
  ideal  model  delta    sigma   weight residual
  1.523  1.502  0.021 1.23e-02 6.61e+03 2.94e+00
bond pdb=" CA  GLN A  53 "
     pdb=" CB  GLN A  53 "
  ideal  model  delta    sigma   weight residual
  1.526  1.552 -0.026 1.51e-02 4.39e+03 2.92e+00
bond pdb=" C   TYR A  61 "
     pdb=" N   THR A  62 "
  ideal  model  delta    sigma   weight residual
  1.331  1.307  0.023 1.39e-02 5.18e+03 2.81e+00
bond pdb=" CA  PHE A  13 "
     pdb=" C   PHE A  13 "
  ideal  model  delta    sigma   weight residual
  1.523  1.503  0.020 1.21e-02 6.83e+03 2.76e+00
bond pdb=" C   LEU A  60 "
     pdb=" O   LEU A  60 "
  ideal  model  delta    sigma   weight residual
  1.236  1.216  0.020 1.21e-02 6.83e+03 2.73e+00
bond pdb=" CA  PRO A   8 "
     pdb=" CB  PRO A   8 "
  ideal  model  delta    sigma   weight residual
  1.534  1.510  0.023 1.43e-02 4.89e+03 2.70e+00
bond pdb=" C   GLY A  38 "
     pdb=" N   ASN A  39 "
  ideal  model  delta    sigma   weight residual
  1.329  1.302  0.027 1.67e-02 3.59e+03 2.69e+00
bond pdb=" C   PHE A  13 "
     pdb=" N   THR A  14 "
  ideal  model  delta    sigma   weight residual
  1.329  1.306  0.022 1.37e-02 5.33e+03 2.69e+00
bond pdb=" CA  THR A  14 "
     pdb=" C   THR A  14 "
  ideal  model  delta    sigma   weight residual
  1.524  1.503  0.020 1.24e-02 6.50e+03 2.67e+00
bond pdb=" CA  ALA A  11 "
     pdb=" C   ALA A  11 "
  ideal  model  delta    sigma   weight residual
  1.523  1.498  0.025 1.56e-02 4.11e+03 2.63e+00
bond pdb=" C   ILE A  47 "
     pdb=" N   THR A  48 "
  ideal  model  delta    sigma   weight residual
  1.330  1.302  0.028 1.76e-02 3.23e+03 2.60e+00
bond pdb=" C   ASP A  79 "
     pdb=" N   ARG A  80 "
  ideal  model  delta    sigma   weight residual
  1.331  1.310  0.021 1.30e-02 5.92e+03 2.60e+00
bond pdb=" C   ALA A  11 "
     pdb=" N   GLN A  12 "
  ideal  model  delta    sigma   weight residual
  1.330  1.307  0.023 1.41e-02 5.03e+03 2.60e+00
bond pdb=" C   PRO A  58 "
     pdb=" O   PRO A  58 "
  ideal  model  delta    sigma   weight residual
  1.233  1.213  0.020 1.24e-02 6.50e+03 2.59e+00
bond pdb=" C   SER A  66 "
     pdb=" N   SER A  67 "
  ideal  model  delta    sigma   weight residual
  1.335  1.313  0.022 1.38e-02 5.25e+03 2.52e+00
bond pdb=" CA  LEU A  32 "
     pdb=" CB  LEU A  32 "
  ideal  model  delta    sigma   weight residual
  1.533  1.510  0.024 1.51e-02 4.39e+03 2.50e+00
bond pdb=" C   SER A   9 "
     pdb=" O   SER A   9 "
  ideal  model  delta    sigma   weight residual
  1.236  1.215  0.021 1.31e-02 5.83e+03 2.47e+00
bond pdb=" C   TYR A  56 "
     pdb=" O   TYR A  56 "
  ideal  model  delta    sigma   weight residual
  1.234  1.215  0.019 1.22e-02 6.72e+03 2.47e+00
bond pdb=" C   VAL A  35 "
     pdb=" N   ASP A  36 "
  ideal  model  delta    sigma   weight residual
  1.331  1.309  0.022 1.38e-02 5.25e+03 2.44e+00
bond pdb=" CA  VAL A  35 "
     pdb=" CB  VAL A  35 "
  ideal  model  delta    sigma   weight residual
  1.539  1.557 -0.018 1.18e-02 7.18e+03 2.31e+00
bond pdb=" CA  THR A  62 "
     pdb=" C   THR A  62 "
  ideal  model  delta    sigma   weight residual
  1.524  1.545 -0.020 1.35e-02 5.49e+03 2.30e+00
bond pdb=" N   SER A  75 "
     pdb=" CA  SER A  75 "
  ideal  model  delta    sigma   weight residual
  1.454  1.472 -0.018 1.21e-02 6.83e+03 2.27e+00
bond pdb=" C   ALA A  55 "
     pdb=" N   TYR A  56 "
  ideal  model  delta    sigma   weight residual
  1.330  1.310  0.020 1.32e-02 5.74e+03 2.27e+00
bond pdb=" C   TYR A  26 "
     pdb=" N   SER A  27 "
  ideal  model  delta    sigma   weight residual
  1.331  1.312  0.020 1.33e-02 5.65e+03 2.24e+00
bond pdb=" C   ASN A  39 "
     pdb=" O   ASN A  39 "
  ideal  model  delta    sigma   weight residual
  1.234  1.219  0.015 1.00e-02 1.00e+04 2.20e+00
bond pdb=" N   GLU A   5 "
     pdb=" CA  GLU A   5 "
  ideal  model  delta    sigma   weight residual
  1.455  1.437  0.018 1.25e-02 6.40e+03 2.18e+00
bond pdb=" N   LYS A   7 "
     pdb=" CA  LYS A   7 "
  ideal  model  delta    sigma   weight residual
  1.452  1.430  0.021 1.46e-02 4.69e+03 2.17e+00
bond pdb=" N   TYR A  26 "
     pdb=" CA  TYR A  26 "
  ideal  model  delta    sigma   weight residual
  1.458  1.486 -0.028 1.90e-02 2.77e+03 2.15e+00
bond pdb=" CA  LYS A  46 "
     pdb=" CB  LYS A  46 "
  ideal  model  delta    sigma   weight residual
  1.530  1.509  0.021 1.43e-02 4.89e+03 2.12e+00
bond pdb=" C   LEU A  60 "
     pdb=" N   TYR A  61 "
  ideal  model  delta    sigma   weight residual
  1.331  1.312  0.019 1.33e-02 5.65e+03 2.09e+00
bond pdb=" N   VAL A  45 "
     pdb=" CA  VAL A  45 "
  ideal  model  delta    sigma   weight residual
  1.459  1.441  0.017 1.19e-02 7.06e+03 2.07e+00
bond pdb=" CA  LEU A  37 "
     pdb=" C   LEU A  37 "
  ideal  model  delta    sigma   weight residual
  1.526  1.508  0.018 1.28e-02 6.10e+03 2.07e+00
bond pdb=" C   LEU A  65 "
     pdb=" N   SER A  66 "
  ideal  model  delta    sigma   weight residual
  1.335  1.315  0.019 1.33e-02 5.65e+03 2.05e+00
bond pdb=" C   SER A  67 "
     pdb=" N   PHE A  68 "
  ideal  model  delta    sigma   weight residual
  1.330  1.310  0.019 1.36e-02 5.41e+03 2.04e+00
bond pdb=" C   PRO A  54 "
     pdb=" O   PRO A  54 "
  ideal  model  delta    sigma   weight residual
  1.232  1.215  0.018 1.27e-02 6.20e+03 2.00e+00
bond pdb=" CA  VAL A  43 "
     pdb=" CB  VAL A  43 "
  ideal  model  delta    sigma   weight residual
  1.544  1.525  0.019 1.35e-02 5.49e+03 1.99e+00
bond pdb=" C   LYS A   7 "
     pdb=" O   LYS A   7 "
  ideal  model  delta    sigma   weight residual
  1.234  1.215  0.018 1.31e-02 5.83e+03 1.98e+00
bond pdb=" C   GLN A  10 "
     pdb=" N   ALA A  11 "
  ideal  model  delta    sigma   weight residual
  1.331  1.311  0.020 1.43e-02 4.89e+03 1.98e+00
bond pdb=" CA  SER A  17 "
     pdb=" CB  SER A  17 "
  ideal  model  delta    sigma   weight residual
  1.530  1.502  0.028 2.00e-02 2.50e+03 1.92e+00
bond pdb=" C   GLU A  51 "
     pdb=" N   GLY A  52 "
  ideal  model  delta    sigma   weight residual
  1.331  1.310  0.021 1.53e-02 4.27e+03 1.91e+00
bond pdb=" CA  VAL A  45 "
     pdb=" CB  VAL A  45 "
  ideal  model  delta    sigma   weight residual
  1.544  1.563 -0.020 1.46e-02 4.69e+03 1.85e+00
bond pdb=" C   ASP A  50 "
     pdb=" O   ASP A  50 "
  ideal  model  delta    sigma   weight residual
  1.233  1.215  0.018 1.32e-02 5.74e+03 1.83e+00
bond pdb=" C   LYS A  46 "
     pdb=" N   ILE A  47 "
  ideal  model  delta    sigma   weight residual
  1.330  1.311  0.019 1.42e-02 4.96e+03 1.82e+00
bond pdb=" C   MSE A  77 "
     pdb=" O   MSE A  77 "
  ideal  model  delta    sigma   weight residual
  1.234  1.217  0.017 1.26e-02 6.30e+03 1.80e+00
bond pdb=" CA  SER A  75 "
     pdb=" C   SER A  75 "
  ideal  model  delta    sigma   weight residual
  1.526  1.545 -0.019 1.42e-02 4.96e+03 1.77e+00
bond pdb=" N   LEU A  49 "
     pdb=" CA  LEU A  49 "
  ideal  model  delta    sigma   weight residual
  1.456  1.439  0.017 1.25e-02 6.40e+03 1.77e+00
bond pdb=" CA  GLU A  51 "
     pdb=" C   GLU A  51 "
  ideal  model  delta    sigma   weight residual
  1.524  1.506  0.017 1.31e-02 5.83e+03 1.75e+00
bond pdb=" CA  ASN A  29 "
     pdb=" C   ASN A  29 "
  ideal  model  delta    sigma   weight residual
  1.522  1.538 -0.016 1.20e-02 6.94e+03 1.73e+00
bond pdb=" CA  GLN A  10 "
     pdb=" C   GLN A  10 "
  ideal  model  delta    sigma   weight residual
  1.526  1.509  0.017 1.28e-02 6.10e+03 1.71e+00
bond pdb=" CA  GLU A  51 "
     pdb=" CB  GLU A  51 "
  ideal  model  delta    sigma   weight residual
  1.528  1.509  0.019 1.49e-02 4.50e+03 1.69e+00
bond pdb=" CA  GLU A   5 "
     pdb=" CB  GLU A   5 "
  ideal  model  delta    sigma   weight residual
  1.534  1.503  0.032 2.47e-02 1.64e+03 1.65e+00
bond pdb=" N   LEU A  28 "
     pdb=" CA  LEU A  28 "
  ideal  model  delta    sigma   weight residual
  1.455  1.440  0.015 1.23e-02 6.61e+03 1.56e+00
bond pdb=" CA  SER A  17 "
     pdb=" C   SER A  17 "
  ideal  model  delta    sigma   weight residual
  1.525  1.499  0.026 2.10e-02 2.27e+03 1.52e+00
bond pdb=" CB  LEU A  44 "
     pdb=" CG  LEU A  44 "
  ideal  model  delta    sigma   weight residual
  1.530  1.505  0.025 2.00e-02 2.50e+03 1.52e+00
bond pdb=" C   THR A  48 "
     pdb=" N   LEU A  49 "
  ideal  model  delta    sigma   weight residual
  1.331  1.314  0.016 1.31e-02 5.83e+03 1.51e+00
bond pdb=" CA  VAL A   4 "
     pdb=" CB  VAL A   4 "
  ideal  model  delta    sigma   weight residual
  1.544  1.561 -0.017 1.42e-02 4.96e+03 1.47e+00
bond pdb=" C   TYR A  26 "
     pdb=" O   TYR A  26 "
  ideal  model  delta    sigma   weight residual
  1.231  1.207  0.024 2.00e-02 2.50e+03 1.45e+00
bond pdb=" N   ASN A  29 "
     pdb=" CA  ASN A  29 "
  ideal  model  delta    sigma   weight residual
  1.456  1.442  0.015 1.21e-02 6.83e+03 1.45e+00
bond pdb=" N   THR A  15 "
     pdb=" CA  THR A  15 "
  ideal  model  delta    sigma   weight residual
  1.457  1.442  0.015 1.24e-02 6.50e+03 1.40e+00
bond pdb=" CG  GLU A  51 "
     pdb=" CD  GLU A  51 "
  ideal  model  delta    sigma   weight residual
  1.516  1.545 -0.029 2.50e-02 1.60e+03 1.39e+00
bond pdb=" CA  GLN A  10 "
     pdb=" CB  GLN A  10 "
  ideal  model  delta    sigma   weight residual
  1.528  1.512  0.016 1.35e-02 5.49e+03 1.37e+00
bond pdb=" CA  GLY A  38 "
     pdb=" C   GLY A  38 "
  ideal  model  delta    sigma   weight residual
  1.512  1.496  0.016 1.40e-02 5.10e+03 1.33e+00
bond pdb=" CA  LEU A  28 "
     pdb=" CB  LEU A  28 "
  ideal  model  delta    sigma   weight residual
  1.533  1.507  0.026 2.29e-02 1.91e+03 1.33e+00
bond pdb=" C   SER A   9 "
     pdb=" N   GLN A  10 "
  ideal  model  delta    sigma   weight residual
  1.333  1.317  0.016 1.42e-02 4.96e+03 1.32e+00
bond pdb=" N   LYS A  69 "
     pdb=" CA  LYS A  69 "
  ideal  model  delta    sigma   weight residual
  1.454  1.439  0.015 1.33e-02 5.65e+03 1.32e+00
bond pdb=" CA  TYR A  61 "
     pdb=" CB  TYR A  61 "
  ideal  model  delta    sigma   weight residual
  1.534  1.555 -0.020 1.77e-02 3.19e+03 1.31e+00
bond pdb=" C   GLU A  30 "
     pdb=" N   GLN A  31 "
  ideal  model  delta    sigma   weight residual
  1.331  1.315  0.016 1.41e-02 5.03e+03 1.31e+00
bond pdb=" CZ  ARG A  82 "
     pdb=" NH2 ARG A  82 "
  ideal  model  delta    sigma   weight residual
  1.330  1.315  0.015 1.30e-02 5.92e+03 1.31e+00
bond pdb=" N   LEU A  83 "
     pdb=" CA  LEU A  83 "
  ideal  model  delta    sigma   weight residual
  1.454  1.468 -0.014 1.19e-02 7.06e+03 1.30e+00
bond pdb=" CA  VAL A  70 "
     pdb=" CB  VAL A  70 "
  ideal  model  delta    sigma   weight residual
  1.533  1.521  0.013 1.13e-02 7.83e+03 1.28e+00
bond pdb=" C   LEU A  49 "
     pdb=" O   LEU A  49 "
  ideal  model  delta    sigma   weight residual
  1.234  1.220  0.014 1.24e-02 6.50e+03 1.27e+00
bond pdb=" N   VAL A  70 "
     pdb=" CA  VAL A  70 "
  ideal  model  delta    sigma   weight residual
  1.459  1.446  0.013 1.15e-02 7.56e+03 1.25e+00
bond pdb=" CA  THR A  15 "
     pdb=" C   THR A  15 "
  ideal  model  delta    sigma   weight residual
  1.520  1.507  0.014 1.21e-02 6.83e+03 1.25e+00
bond pdb=" C   GLY A  59 "
     pdb=" O   GLY A  59 "
  ideal  model  delta    sigma   weight residual
  1.227  1.211  0.016 1.43e-02 4.89e+03 1.22e+00
bond pdb=" CA  ALA A  57 "
     pdb=" C   ALA A  57 "
  ideal  model  delta    sigma   weight residual
  1.525  1.510  0.015 1.34e-02 5.57e+03 1.21e+00
bond pdb=" C   GLN A  12 "
     pdb=" N   PHE A  13 "
  ideal  model  delta    sigma   weight residual
  1.330  1.314  0.015 1.41e-02 5.03e+03 1.20e+00
bond pdb=" CA  VAL A  35 "
     pdb=" C   VAL A  35 "
  ideal  model  delta    sigma   weight residual
  1.522  1.535 -0.013 1.19e-02 7.06e+03 1.19e+00
bond pdb=" CA  GLN A  53 "
     pdb=" C   GLN A  53 "
  ideal  model  delta    sigma   weight residual
  1.519  1.504  0.015 1.38e-02 5.25e+03 1.17e+00
bond pdb=" C   SER A  17 "
     pdb=" O   SER A  17 "
  ideal  model  delta    sigma   weight residual
  1.231  1.209  0.022 2.00e-02 2.50e+03 1.16e+00
bond pdb=" C   GLU A   5 "
     pdb=" N   ILE A   6 "
  ideal  model  delta    sigma   weight residual
  1.330  1.317  0.013 1.25e-02 6.40e+03 1.15e+00
bond pdb=" CA  TYR A  41 "
     pdb=" C   TYR A  41 "
  ideal  model  delta    sigma   weight residual
  1.519  1.529 -0.010 9.50e-03 1.11e+04 1.14e+00
bond pdb=" CA  VAL A   4 "
     pdb=" C   VAL A   4 "
  ideal  model  delta    sigma   weight residual
  1.522  1.509  0.013 1.22e-02 6.72e+03 1.13e+00
bond pdb=" C   ALA A  57 "
     pdb=" N   PRO A  58 "
  ideal  model  delta    sigma   weight residual
  1.331  1.318  0.013 1.27e-02 6.20e+03 1.12e+00
bond pdb=" N   PRO A  58 "
     pdb=" CA  PRO A  58 "
  ideal  model  delta    sigma   weight residual
  1.466  1.454  0.012 1.17e-02 7.31e+03 1.12e+00
bond pdb=" CA  VAL A  63 "
     pdb=" C   VAL A  63 "
  ideal  model  delta    sigma   weight residual
  1.523  1.510  0.013 1.23e-02 6.61e+03 1.12e+00
bond pdb=" C   GLN A  53 "
     pdb=" O   GLN A  53 "
  ideal  model  delta    sigma   weight residual
  1.240  1.225  0.015 1.41e-02 5.03e+03 1.11e+00
bond pdb=" C   TYR A  56 "
     pdb=" N   ALA A  57 "
  ideal  model  delta    sigma   weight residual
  1.329  1.309  0.020 1.86e-02 2.89e+03 1.11e+00
bond pdb=" CA  GLY A  74 "
     pdb=" C   GLY A  74 "
  ideal  model  delta    sigma   weight residual
  1.512  1.527 -0.015 1.41e-02 5.03e+03 1.08e+00
bond pdb=" CA  GLU A  40 "
     pdb=" CB  GLU A  40 "
  ideal  model  delta    sigma   weight residual
  1.528  1.545 -0.016 1.56e-02 4.11e+03 1.05e+00
bond pdb=" N   LEU A  32 "
     pdb=" CA  LEU A  32 "
  ideal  model  delta    sigma   weight residual
  1.455  1.442  0.013 1.25e-02 6.40e+03 1.02e+00
bond pdb=" C   THR A  14 "
     pdb=" N   THR A  15 "
  ideal  model  delta    sigma   weight residual
  1.331  1.317  0.014 1.38e-02 5.25e+03 1.01e+00
bond pdb=" CA  GLN A  31 "
     pdb=" C   GLN A  31 "
  ideal  model  delta    sigma   weight residual
  1.522  1.534 -0.012 1.23e-02 6.61e+03 9.88e-01
bond pdb=" C   GLY A  74 "
     pdb=" O   GLY A  74 "
  ideal  model  delta    sigma   weight residual
  1.237  1.222  0.015 1.46e-02 4.69e+03 9.87e-01
bond pdb=" N   GLY A  59 "
     pdb=" CA  GLY A  59 "
  ideal  model  delta    sigma   weight residual
  1.447  1.432  0.015 1.49e-02 4.50e+03 9.84e-01
bond pdb=" CZ  ARG A  80 "
     pdb=" NH2 ARG A  80 "
  ideal  model  delta    sigma   weight residual
  1.330  1.317  0.013 1.30e-02 5.92e+03 9.78e-01
bond pdb=" CG  TYR A  34 "
     pdb=" CD1 TYR A  34 "
  ideal  model  delta    sigma   weight residual
  1.389  1.368  0.021 2.10e-02 2.27e+03 9.59e-01
bond pdb=" N   HIS A  64 "
     pdb=" CA  HIS A  64 "
  ideal  model  delta    sigma   weight residual
  1.454  1.442  0.012 1.27e-02 6.20e+03 9.26e-01
bond pdb=" C   LYS A  69 "
     pdb=" O   LYS A  69 "
  ideal  model  delta    sigma   weight residual
  1.234  1.222  0.012 1.28e-02 6.10e+03 9.08e-01
bond pdb=" CA  PRO A  42 "
     pdb=" C   PRO A  42 "
  ideal  model  delta    sigma   weight residual
  1.521  1.532 -0.012 1.24e-02 6.50e+03 9.02e-01
bond pdb=" CB  ASP A  50 "
     pdb=" CG  ASP A  50 "
  ideal  model  delta    sigma   weight residual
  1.516  1.492  0.024 2.50e-02 1.60e+03 8.95e-01
bond pdb=" CA  ILE A  47 "
     pdb=" C   ILE A  47 "
  ideal  model  delta    sigma   weight residual
  1.522  1.511  0.011 1.17e-02 7.31e+03 8.68e-01
bond pdb=" C   VAL A  63 "
     pdb=" N   HIS A  64 "
  ideal  model  delta    sigma   weight residual
  1.329  1.316  0.013 1.43e-02 4.89e+03 8.66e-01
bond pdb=" C   THR A  62 "
     pdb=" O   THR A  62 "
  ideal  model  delta    sigma   weight residual
  1.235  1.247 -0.013 1.36e-02 5.41e+03 8.62e-01
bond pdb=" CE2 TYR A  41 "
     pdb=" CZ  TYR A  41 "
  ideal  model  delta    sigma   weight residual
  1.378  1.356  0.022 2.40e-02 1.74e+03 8.37e-01
bond pdb=" CA  LEU A  44 "
     pdb=" C   LEU A  44 "
  ideal  model  delta    sigma   weight residual
  1.523  1.511  0.012 1.32e-02 5.74e+03 8.37e-01
bond pdb=" CD  LYS A  69 "
     pdb=" CE  LYS A  69 "
  ideal  model  delta    sigma   weight residual
  1.520  1.547 -0.027 3.00e-02 1.11e+03 8.28e-01
bond pdb=" CA  GLN A  12 "
     pdb=" CB  GLN A  12 "
  ideal  model  delta    sigma   weight residual
  1.535  1.518  0.017 1.93e-02 2.68e+03 8.12e-01
bond pdb=" CA  VAL A  70 "
     pdb=" C   VAL A  70 "
  ideal  model  delta    sigma   weight residual
  1.525  1.514  0.011 1.17e-02 7.31e+03 8.09e-01
bond pdb=" CA  LEU A  37 "
     pdb=" CB  LEU A  37 "
  ideal  model  delta    sigma   weight residual
  1.528  1.515  0.012 1.35e-02 5.49e+03 7.92e-01
bond pdb=" C   HIS A  64 "
     pdb=" N   LEU A  65 "
  ideal  model  delta    sigma   weight residual
  1.335  1.323  0.012 1.34e-02 5.57e+03 7.88e-01
bond pdb=" C   PHE A  73 "
     pdb=" O   PHE A  73 "
  ideal  model  delta    sigma   weight residual
  1.235  1.223  0.012 1.32e-02 5.74e+03 7.81e-01
bond pdb=" C   SER A  75 "
     pdb=" O   SER A  75 "
  ideal  model  delta    sigma   weight residual
  1.233  1.245 -0.011 1.28e-02 6.10e+03 7.74e-01
bond pdb=" CA  SER A  75 "
     pdb=" CB  SER A  75 "
  ideal  model  delta    sigma   weight residual
  1.529  1.515  0.014 1.64e-02 3.72e+03 7.61e-01
bond pdb=" N   THR A  14 "
     pdb=" CA  THR A  14 "
  ideal  model  delta    sigma   weight residual
  1.454  1.443  0.011 1.31e-02 5.83e+03 7.57e-01
bond pdb=" C   ARG A  16 "
     pdb=" N   SER A  17 "
  ideal  model  delta    sigma   weight residual
  1.329  1.317  0.012 1.40e-02 5.10e+03 7.50e-01
bond pdb=" CE  LYS A  69 "
     pdb=" NZ  LYS A  69 "
  ideal  model  delta    sigma   weight residual
  1.489  1.515 -0.026 3.00e-02 1.11e+03 7.41e-01
bond pdb=" CA  THR A  48 "
     pdb=" C   THR A  48 "
  ideal  model  delta    sigma   weight residual
  1.526  1.514  0.011 1.30e-02 5.92e+03 7.39e-01
bond pdb=" N   GLY A  52 "
     pdb=" CA  GLY A  52 "
  ideal  model  delta    sigma   weight residual
  1.446  1.433  0.013 1.50e-02 4.44e+03 7.36e-01
bond pdb=" C   ASP A  36 "
     pdb=" N   LEU A  37 "
  ideal  model  delta    sigma   weight residual
  1.333  1.321  0.012 1.42e-02 4.96e+03 7.30e-01
bond pdb=" CA  LEU A  44 "
     pdb=" CB  LEU A  44 "
  ideal  model  delta    sigma   weight residual
  1.529  1.515  0.014 1.64e-02 3.72e+03 7.30e-01
bond pdb=" N   TYR A  41 "
     pdb=" CA  TYR A  41 "
  ideal  model  delta    sigma   weight residual
  1.453  1.461 -0.008 9.20e-03 1.18e+04 7.18e-01
bond pdb=" CZ  TYR A  61 "
     pdb=" OH  TYR A  61 "
  ideal  model  delta    sigma   weight residual
  1.376  1.358  0.018 2.10e-02 2.27e+03 7.05e-01
bond pdb=" CA  ASN A  29 "
     pdb=" CB  ASN A  29 "
  ideal  model  delta    sigma   weight residual
  1.531  1.518  0.013 1.52e-02 4.33e+03 6.92e-01
bond pdb=" N   PRO A  54 "
     pdb=" CA  PRO A  54 "
  ideal  model  delta    sigma   weight residual
  1.466  1.456  0.010 1.21e-02 6.83e+03 6.88e-01
bond pdb=" N   CYS A  33 "
     pdb=" CA  CYS A  33 "
  ideal  model  delta    sigma   weight residual
  1.458  1.448  0.010 1.18e-02 7.18e+03 6.83e-01
bond pdb=" CA  VAL A  45 "
     pdb=" C   VAL A  45 "
  ideal  model  delta    sigma   weight residual
  1.522  1.533 -0.010 1.26e-02 6.30e+03 6.81e-01
bond pdb=" C   MSE A  77 "
     pdb=" N   ILE A  78 "
  ideal  model  delta    sigma   weight residual
  1.329  1.315  0.014 1.69e-02 3.50e+03 6.46e-01
bond pdb=" CA  HIS A  64 "
     pdb=" C   HIS A  64 "
  ideal  model  delta    sigma   weight residual
  1.524  1.513  0.011 1.33e-02 5.65e+03 6.42e-01
bond pdb=" CB  VAL A   4 "
     pdb=" CG1 VAL A   4 "
  ideal  model  delta    sigma   weight residual
  1.521  1.547 -0.026 3.30e-02 9.18e+02 6.26e-01
bond pdb=" CA  PRO A  58 "
     pdb=" C   PRO A  58 "
  ideal  model  delta    sigma   weight residual
  1.522  1.531 -0.009 1.19e-02 7.06e+03 6.14e-01
bond pdb=" CA  GLU A  40 "
     pdb=" C   GLU A  40 "
  ideal  model  delta    sigma   weight residual
  1.523  1.513  0.010 1.30e-02 5.92e+03 6.02e-01
bond pdb=" C   VAL A  70 "
     pdb=" O   VAL A  70 "
  ideal  model  delta    sigma   weight residual
  1.234  1.225  0.009 1.17e-02 7.31e+03 5.95e-01
bond pdb=" C   ASN A  29 "
     pdb=" O   ASN A  29 "
  ideal  model  delta    sigma   weight residual
  1.236  1.226  0.009 1.21e-02 6.83e+03 5.91e-01
bond pdb=" CB  VAL A  84 "
     pdb=" CG2 VAL A  84 "
  ideal  model  delta    sigma   weight residual
  1.521  1.496  0.025 3.30e-02 9.18e+02 5.77e-01
bond pdb=" C   GLY A  52 "
     pdb=" N   GLN A  53 "
  ideal  model  delta    sigma   weight residual
  1.335  1.308  0.027 3.59e-02 7.76e+02 5.72e-01
bond pdb=" C   ARG A  82 "
     pdb=" N   LEU A  83 "
  ideal  model  delta    sigma   weight residual
  1.329  1.319  0.010 1.38e-02 5.25e+03 5.65e-01
bond pdb=" CG  ASN A  29 "
     pdb=" ND2 ASN A  29 "
  ideal  model  delta    sigma   weight residual
  1.328  1.344 -0.016 2.10e-02 2.27e+03 5.63e-01
bond pdb=" N   THR A  62 "
     pdb=" CA  THR A  62 "
  ideal  model  delta    sigma   weight residual
  1.456  1.445  0.011 1.44e-02 4.82e+03 5.56e-01
bond pdb=" CA  PHE A  73 "
     pdb=" C   PHE A  73 "
  ideal  model  delta    sigma   weight residual
  1.525  1.515  0.010 1.35e-02 5.49e+03 5.55e-01
bond pdb=" CA  PHE A  68 "
     pdb=" CB  PHE A  68 "
  ideal  model  delta    sigma   weight residual
  1.532  1.544 -0.013 1.74e-02 3.30e+03 5.50e-01
bond pdb=" CB  LEU A  65 "
     pdb=" CG  LEU A  65 "
  ideal  model  delta    sigma   weight residual
  1.530  1.515  0.015 2.00e-02 2.50e+03 5.48e-01
bond pdb=" CG  ASN A  29 "
     pdb=" OD1 ASN A  29 "
  ideal  model  delta    sigma   weight residual
  1.231  1.245 -0.014 1.90e-02 2.77e+03 5.46e-01
bond pdb=" C   THR A  62 "
     pdb=" N   VAL A  63 "
  ideal  model  delta    sigma   weight residual
  1.329  1.316  0.012 1.69e-02 3.50e+03 5.39e-01
bond pdb=" CB  GLU A  51 "
     pdb=" CG  GLU A  51 "
  ideal  model  delta    sigma   weight residual
  1.520  1.542 -0.022 3.00e-02 1.11e+03 5.27e-01
bond pdb=" CA  LEU A  60 "
     pdb=" C   LEU A  60 "
  ideal  model  delta    sigma   weight residual
  1.522  1.513  0.009 1.20e-02 6.94e+03 5.26e-01
bond pdb=" N   ILE A   2 "
     pdb=" CA  ILE A   2 "
  ideal  model  delta    sigma   weight residual
  1.458  1.472 -0.014 1.90e-02 2.77e+03 5.23e-01
bond pdb=" C   LEU A  76 "
     pdb=" N   MSE A  77 "
  ideal  model  delta    sigma   weight residual
  1.331  1.321  0.010 1.41e-02 5.03e+03 5.15e-01
bond pdb=" C   GLY A  52 "
     pdb=" O   GLY A  52 "
  ideal  model  delta    sigma   weight residual
  1.238  1.228  0.010 1.42e-02 4.96e+03 5.10e-01
bond pdb=" N   ARG A  82 "
     pdb=" CA  ARG A  82 "
  ideal  model  delta    sigma   weight residual
  1.456  1.448  0.009 1.21e-02 6.83e+03 5.00e-01
bond pdb=" CB  TYR A  61 "
     pdb=" CG  TYR A  61 "
  ideal  model  delta    sigma   weight residual
  1.512  1.497  0.015 2.20e-02 2.07e+03 4.96e-01
bond pdb=" CB  VAL A  35 "
     pdb=" CG1 VAL A  35 "
  ideal  model  delta    sigma   weight residual
  1.521  1.498  0.023 3.30e-02 9.18e+02 4.96e-01
bond pdb=" CA  LYS A   7 "
     pdb=" C   LYS A   7 "
  ideal  model  delta    sigma   weight residual
  1.525  1.516  0.009 1.34e-02 5.57e+03 4.92e-01
bond pdb=" C   LEU A  44 "
     pdb=" O   LEU A  44 "
  ideal  model  delta    sigma   weight residual
  1.234  1.226  0.008 1.20e-02 6.94e+03 4.86e-01
bond pdb=" CA  ASP A  36 "
     pdb=" C   ASP A  36 "
  ideal  model  delta    sigma   weight residual
  1.524  1.533 -0.009 1.26e-02 6.30e+03 4.86e-01
bond pdb=" CB  VAL A   4 "
     pdb=" CG2 VAL A   4 "
  ideal  model  delta    sigma   weight residual
  1.521  1.544 -0.023 3.30e-02 9.18e+02 4.85e-01
bond pdb=" CA  SER A  27 "
     pdb=" C   SER A  27 "
  ideal  model  delta    sigma   weight residual
  1.520  1.528 -0.008 1.20e-02 6.94e+03 4.83e-01
bond pdb=" N   VAL A  63 "
     pdb=" CA  VAL A  63 "
  ideal  model  delta    sigma   weight residual
  1.459  1.450  0.009 1.24e-02 6.50e+03 4.77e-01
bond pdb=" C   LYS A   3 "
     pdb=" O   LYS A   3 "
  ideal  model  delta    sigma   weight residual
  1.236  1.244 -0.008 1.21e-02 6.83e+03 4.73e-01
bond pdb=" CA  TYR A  34 "
     pdb=" CB  TYR A  34 "
  ideal  model  delta    sigma   weight residual
  1.531  1.520  0.010 1.52e-02 4.33e+03 4.70e-01
bond pdb=" N   LEU A  60 "
     pdb=" CA  LEU A  60 "
  ideal  model  delta    sigma   weight residual
  1.456  1.448  0.008 1.21e-02 6.83e+03 4.70e-01
bond pdb=" CA  TYR A  26 "
     pdb=" CB  TYR A  26 "
  ideal  model  delta    sigma   weight residual
  1.530  1.544 -0.014 2.00e-02 2.50e+03 4.68e-01
bond pdb=" CB  GLU A  40 "
     pdb=" CG  GLU A  40 "
  ideal  model  delta    sigma   weight residual
  1.520  1.540 -0.020 3.00e-02 1.11e+03 4.67e-01
bond pdb=" CA  ILE A  47 "
     pdb=" CB  ILE A  47 "
  ideal  model  delta    sigma   weight residual
  1.542  1.550 -0.009 1.26e-02 6.30e+03 4.63e-01
bond pdb=" C   LEU A  37 "
     pdb=" N   GLY A  38 "
  ideal  model  delta    sigma   weight residual
  1.331  1.322  0.010 1.46e-02 4.69e+03 4.59e-01
bond pdb=" CG  TYR A  34 "
     pdb=" CD2 TYR A  34 "
  ideal  model  delta    sigma   weight residual
  1.389  1.403 -0.014 2.10e-02 2.27e+03 4.56e-01
bond pdb=" CA  PHE A  68 "
     pdb=" C   PHE A  68 "
  ideal  model  delta    sigma   weight residual
  1.522  1.530 -0.008 1.19e-02 7.06e+03 4.45e-01
bond pdb=" CA  PRO A  58 "
     pdb=" CB  PRO A  58 "
  ideal  model  delta    sigma   weight residual
  1.532  1.523  0.008 1.29e-02 6.01e+03 4.22e-01
bond pdb=" C   VAL A  45 "
     pdb=" N   LYS A  46 "
  ideal  model  delta    sigma   weight residual
  1.330  1.321  0.009 1.39e-02 5.18e+03 4.22e-01
bond pdb=" CB  LEU A  37 "
     pdb=" CG  LEU A  37 "
  ideal  model  delta    sigma   weight residual
  1.530  1.517  0.013 2.00e-02 2.50e+03 4.21e-01
bond pdb=" C   ILE A   6 "
     pdb=" N   LYS A   7 "
  ideal  model  delta    sigma   weight residual
  1.329  1.317  0.012 1.86e-02 2.89e+03 4.19e-01
bond pdb=" CA  LYS A   7 "
     pdb=" CB  LYS A   7 "
  ideal  model  delta    sigma   weight residual
  1.525  1.515  0.010 1.52e-02 4.33e+03 4.14e-01
bond pdb=" CA  SER A   9 "
     pdb=" C   SER A   9 "
  ideal  model  delta    sigma   weight residual
  1.522  1.531 -0.009 1.37e-02 5.33e+03 4.13e-01
bond pdb=" CG  PHE A  13 "
     pdb=" CD2 PHE A  13 "
  ideal  model  delta    sigma   weight residual
  1.384  1.371  0.013 2.10e-02 2.27e+03 4.06e-01
bond pdb=" C   LEU A  83 "
     pdb=" O   LEU A  83 "
  ideal  model  delta    sigma   weight residual
  1.234  1.227  0.008 1.22e-02 6.72e+03 4.01e-01
bond pdb=" CA  SER A   9 "
     pdb=" CB  SER A   9 "
  ideal  model  delta    sigma   weight residual
  1.530  1.519  0.011 1.75e-02 3.27e+03 4.01e-01
bond pdb=" C   GLY A  71 "
     pdb=" N   GLN A  72 "
  ideal  model  delta    sigma   weight residual
  1.331  1.321  0.009 1.48e-02 4.57e+03 3.98e-01
bond pdb=" CG1 ILE A   2 "
     pdb=" CD1 ILE A   2 "
  ideal  model  delta    sigma   weight residual
  1.513  1.488  0.025 3.90e-02 6.57e+02 3.98e-01
bond pdb=" CA  HIS A  64 "
     pdb=" CB  HIS A  64 "
  ideal  model  delta    sigma   weight residual
  1.530  1.520  0.010 1.55e-02 4.16e+03 3.96e-01
bond pdb=" CA  THR A  48 "
     pdb=" CB  THR A  48 "
  ideal  model  delta    sigma   weight residual
  1.526  1.517  0.010 1.53e-02 4.27e+03 3.96e-01
bond pdb=" CG  GLU A   5 "
     pdb=" CD  GLU A   5 "
  ideal  model  delta    sigma   weight residual
  1.516  1.500  0.016 2.50e-02 1.60e+03 3.90e-01
bond pdb=" N   ASP A  36 "
     pdb=" CA  ASP A  36 "
  ideal  model  delta    sigma   weight residual
  1.459  1.452  0.008 1.24e-02 6.50e+03 3.89e-01
bond pdb=" N   LEU A  76 "
     pdb=" CA  LEU A  76 "
  ideal  model  delta    sigma   weight residual
  1.456  1.464 -0.008 1.22e-02 6.72e+03 3.88e-01
bond pdb=" N   LEU A  44 "
     pdb=" CA  LEU A  44 "
  ideal  model  delta    sigma   weight residual
  1.456  1.464 -0.008 1.28e-02 6.10e+03 3.72e-01
bond pdb=" CG  TYR A  61 "
     pdb=" CD2 TYR A  61 "
  ideal  model  delta    sigma   weight residual
  1.389  1.376  0.013 2.10e-02 2.27e+03 3.72e-01
bond pdb=" CB  THR A  48 "
     pdb=" CG2 THR A  48 "
  ideal  model  delta    sigma   weight residual
  1.521  1.501  0.020 3.30e-02 9.18e+02 3.69e-01
bond pdb=" N   GLN A  31 "
     pdb=" CA  GLN A  31 "
  ideal  model  delta    sigma   weight residual
  1.454  1.446  0.008 1.29e-02 6.01e+03 3.68e-01
bond pdb=" C   VAL A  43 "
     pdb=" O   VAL A  43 "
  ideal  model  delta    sigma   weight residual
  1.237  1.229  0.008 1.38e-02 5.25e+03 3.60e-01
bond pdb=" CB  TYR A  56 "
     pdb=" CG  TYR A  56 "
  ideal  model  delta    sigma   weight residual
  1.512  1.499  0.013 2.20e-02 2.07e+03 3.52e-01
bond pdb=" CG  ASP A  50 "
     pdb=" OD1 ASP A  50 "
  ideal  model  delta    sigma   weight residual
  1.249  1.238  0.011 1.90e-02 2.77e+03 3.45e-01
bond pdb=" CG  PHE A  68 "
     pdb=" CD2 PHE A  68 "
  ideal  model  delta    sigma   weight residual
  1.384  1.372  0.012 2.10e-02 2.27e+03 3.45e-01
bond pdb=" N   LYS A   3 "
     pdb=" CA  LYS A   3 "
  ideal  model  delta    sigma   weight residual
  1.456  1.464 -0.007 1.23e-02 6.61e+03 3.42e-01
bond pdb=" CZ  TYR A  34 "
     pdb=" OH  TYR A  34 "
  ideal  model  delta    sigma   weight residual
  1.376  1.364  0.012 2.10e-02 2.27e+03 3.41e-01
bond pdb=" N   GLY A  74 "
     pdb=" CA  GLY A  74 "
  ideal  model  delta    sigma   weight residual
  1.446  1.455 -0.009 1.53e-02 4.27e+03 3.41e-01
bond pdb=" CA  LYS A   3 "
     pdb=" CB  LYS A   3 "
  ideal  model  delta    sigma   weight residual
  1.530  1.521  0.008 1.43e-02 4.89e+03 3.34e-01
bond pdb=" CZ  TYR A  56 "
     pdb=" OH  TYR A  56 "
  ideal  model  delta    sigma   weight residual
  1.376  1.364  0.012 2.10e-02 2.27e+03 3.32e-01
bond pdb=" CG  ASP A  50 "
     pdb=" OD2 ASP A  50 "
  ideal  model  delta    sigma   weight residual
  1.249  1.238  0.011 1.90e-02 2.77e+03 3.28e-01
bond pdb=" CB  PHE A  13 "
     pdb=" CG  PHE A  13 "
  ideal  model  delta    sigma   weight residual
  1.502  1.489  0.013 2.30e-02 1.89e+03 3.14e-01
bond pdb=" C   LYS A  69 "
     pdb=" N   VAL A  70 "
  ideal  model  delta    sigma   weight residual
  1.329  1.323  0.006 1.15e-02 7.56e+03 3.14e-01
bond pdb=" CA  GLU A  30 "
     pdb=" CB  GLU A  30 "
  ideal  model  delta    sigma   weight residual
  1.533  1.520  0.013 2.29e-02 1.91e+03 3.13e-01
bond pdb=" C   LEU A  44 "
     pdb=" N   VAL A  45 "
  ideal  model  delta    sigma   weight residual
  1.330  1.323  0.008 1.35e-02 5.49e+03 3.11e-01
bond pdb=" CB  VAL A  70 "
     pdb=" CG1 VAL A  70 "
  ideal  model  delta    sigma   weight residual
  1.521  1.503  0.018 3.30e-02 9.18e+02 3.09e-01
bond pdb=" CD  GLU A   5 "
     pdb=" OE2 GLU A   5 "
  ideal  model  delta    sigma   weight residual
  1.249  1.238  0.011 1.90e-02 2.77e+03 3.06e-01
bond pdb=" CD  GLN A  10 "
     pdb=" NE2 GLN A  10 "
  ideal  model  delta    sigma   weight residual
  1.328  1.317  0.011 2.10e-02 2.27e+03 3.00e-01
bond pdb=" N   ALA A  11 "
     pdb=" CA  ALA A  11 "
  ideal  model  delta    sigma   weight residual
  1.456  1.448  0.007 1.32e-02 5.74e+03 2.99e-01
bond pdb=" C   VAL A  43 "
     pdb=" N   LEU A  44 "
  ideal  model  delta    sigma   weight residual
  1.331  1.323  0.007 1.36e-02 5.41e+03 2.97e-01
bond pdb=" CB  ASP A  36 "
     pdb=" CG  ASP A  36 "
  ideal  model  delta    sigma   weight residual
  1.516  1.502  0.014 2.50e-02 1.60e+03 2.95e-01
bond pdb=" C   VAL A  84 "
     pdb=" N   PRO A  85 "
  ideal  model  delta    sigma   weight residual
  1.341  1.350 -0.009 1.60e-02 3.91e+03 2.95e-01
bond pdb=" CA  ALA A  55 "
     pdb=" C   ALA A  55 "
  ideal  model  delta    sigma   weight residual
  1.524  1.531 -0.007 1.30e-02 5.92e+03 2.88e-01
bond pdb=" CA  THR A  62 "
     pdb=" CB  THR A  62 "
  ideal  model  delta    sigma   weight residual
  1.534  1.542 -0.008 1.45e-02 4.76e+03 2.86e-01
bond pdb=" C   GLU A  40 "
     pdb=" N   TYR A  41 "
  ideal  model  delta    sigma   weight residual
  1.326  1.332 -0.006 1.12e-02 7.97e+03 2.84e-01
bond pdb=" CG  TYR A  41 "
     pdb=" CD1 TYR A  41 "
  ideal  model  delta    sigma   weight residual
  1.389  1.400 -0.011 2.10e-02 2.27e+03 2.82e-01
bond pdb=" CB  SER A  17 "
     pdb=" OG  SER A  17 "
  ideal  model  delta    sigma   weight residual
  1.417  1.406  0.011 2.00e-02 2.50e+03 2.81e-01
bond pdb=" CD  GLU A  30 "
     pdb=" OE2 GLU A  30 "
  ideal  model  delta    sigma   weight residual
  1.249  1.239  0.010 1.90e-02 2.77e+03 2.80e-01
bond pdb=" CE1 TYR A  61 "
     pdb=" CZ  TYR A  61 "
  ideal  model  delta    sigma   weight residual
  1.378  1.365  0.013 2.40e-02 1.74e+03 2.76e-01
bond pdb=" C   ASN A  29 "
     pdb=" N   GLU A  30 "
  ideal  model  delta    sigma   weight residual
  1.330  1.323  0.008 1.44e-02 4.82e+03 2.75e-01
bond pdb=" C   SER A  27 "
     pdb=" N   LEU A  28 "
  ideal  model  delta    sigma   weight residual
  1.330  1.323  0.008 1.44e-02 4.82e+03 2.73e-01
bond pdb=" CD  GLN A  31 "
     pdb=" NE2 GLN A  31 "
  ideal  model  delta    sigma   weight residual
  1.328  1.317  0.011 2.10e-02 2.27e+03 2.73e-01
bond pdb=" CE1 TYR A  56 "
     pdb=" CZ  TYR A  56 "
  ideal  model  delta    sigma   weight residual
  1.378  1.366  0.012 2.40e-02 1.74e+03 2.70e-01
bond pdb=" CD1 PHE A  13 "
     pdb=" CE1 PHE A  13 "
  ideal  model  delta    sigma   weight residual
  1.382  1.367  0.015 3.00e-02 1.11e+03 2.64e-01
bond pdb=" C   VAL A  70 "
     pdb=" N   GLY A  71 "
  ideal  model  delta    sigma   weight residual
  1.331  1.338 -0.007 1.46e-02 4.69e+03 2.62e-01
bond pdb=" C   CYS A  33 "
     pdb=" N   TYR A  34 "
  ideal  model  delta    sigma   weight residual
  1.330  1.323  0.007 1.32e-02 5.74e+03 2.61e-01
bond pdb=" CB  GLN A  10 "
     pdb=" CG  GLN A  10 "
  ideal  model  delta    sigma   weight residual
  1.520  1.505  0.015 3.00e-02 1.11e+03 2.60e-01
bond pdb=" CB  ASN A  29 "
     pdb=" CG  ASN A  29 "
  ideal  model  delta    sigma   weight residual
  1.516  1.529 -0.013 2.50e-02 1.60e+03 2.59e-01
bond pdb=" CB  PHE A  68 "
     pdb=" CG  PHE A  68 "
  ideal  model  delta    sigma   weight residual
  1.502  1.490  0.012 2.30e-02 1.89e+03 2.56e-01
bond pdb=" CA  GLY A  59 "
     pdb=" C   GLY A  59 "
  ideal  model  delta    sigma   weight residual
  1.516  1.509  0.007 1.31e-02 5.83e+03 2.55e-01
bond pdb=" CE  LYS A   3 "
     pdb=" NZ  LYS A   3 "
  ideal  model  delta    sigma   weight residual
  1.489  1.504 -0.015 3.00e-02 1.11e+03 2.52e-01
bond pdb=" C   TYR A  34 "
     pdb=" O   TYR A  34 "
  ideal  model  delta    sigma   weight residual
  1.236  1.230  0.006 1.21e-02 6.83e+03 2.47e-01
bond pdb=" C   LEU A  81 "
     pdb=" N   ARG A  82 "
  ideal  model  delta    sigma   weight residual
  1.330  1.323  0.006 1.32e-02 5.74e+03 2.40e-01
bond pdb=" CD  GLU A  30 "
     pdb=" OE1 GLU A  30 "
  ideal  model  delta    sigma   weight residual
  1.249  1.240  0.009 1.90e-02 2.77e+03 2.39e-01
bond pdb=" CG  TYR A  41 "
     pdb=" CD2 TYR A  41 "
  ideal  model  delta    sigma   weight residual
  1.389  1.379  0.010 2.10e-02 2.27e+03 2.37e-01
bond pdb=" CG  LEU A  83 "
     pdb=" CD1 LEU A  83 "
  ideal  model  delta    sigma   weight residual
  1.521  1.537 -0.016 3.30e-02 9.18e+02 2.34e-01
bond pdb=" CB  ILE A  47 "
     pdb=" CG1 ILE A  47 "
  ideal  model  delta    sigma   weight residual
  1.530  1.520  0.010 2.00e-02 2.50e+03 2.33e-01
bond pdb=" CA  ASP A  36 "
     pdb=" CB  ASP A  36 "
  ideal  model  delta    sigma   weight residual
  1.526  1.532 -0.006 1.26e-02 6.30e+03 2.32e-01
bond pdb=" CB  LEU A  81 "
     pdb=" CG  LEU A  81 "
  ideal  model  delta    sigma   weight residual
  1.530  1.520  0.010 2.00e-02 2.50e+03 2.29e-01
bond pdb=" CA  PRO A  54 "
     pdb=" CB  PRO A  54 "
  ideal  model  delta    sigma   weight residual
  1.531  1.523  0.007 1.49e-02 4.50e+03 2.27e-01
bond pdb=" C   VAL A  84 "
     pdb=" O   VAL A  84 "
  ideal  model  delta    sigma   weight residual
  1.240  1.234  0.006 1.26e-02 6.30e+03 2.25e-01
bond pdb=" CG  TYR A  56 "
     pdb=" CD1 TYR A  56 "
  ideal  model  delta    sigma   weight residual
  1.389  1.379  0.010 2.10e-02 2.27e+03 2.22e-01
bond pdb=" CA  ARG A  80 "
     pdb=" CB  ARG A  80 "
  ideal  model  delta    sigma   weight residual
  1.533  1.525  0.008 1.69e-02 3.50e+03 2.21e-01
bond pdb=" CE1 TYR A  41 "
     pdb=" CZ  TYR A  41 "
  ideal  model  delta    sigma   weight residual
  1.378  1.389 -0.011 2.40e-02 1.74e+03 2.21e-01
bond pdb=" CG  ASP A  79 "
     pdb=" OD2 ASP A  79 "
  ideal  model  delta    sigma   weight residual
  1.249  1.240  0.009 1.90e-02 2.77e+03 2.19e-01
bond pdb=" CA  PRO A  54 "
     pdb=" C   PRO A  54 "
  ideal  model  delta    sigma   weight residual
  1.521  1.527 -0.006 1.20e-02 6.94e+03 2.15e-01
bond pdb=" C   PRO A  85 "
     pdb=" O   PRO A  85 "
  ideal  model  delta    sigma   weight residual
  1.231  1.240 -0.009 2.00e-02 2.50e+03 2.13e-01
bond pdb=" CG  MSE A  77 "
     pdb="SE   MSE A  77 "
  ideal  model  delta    sigma   weight residual
  1.950  1.964 -0.014 3.00e-02 1.11e+03 2.12e-01
bond pdb=" CB  ASP A  79 "
     pdb=" CG  ASP A  79 "
  ideal  model  delta    sigma   weight residual
  1.516  1.505  0.011 2.50e-02 1.60e+03 2.11e-01
bond pdb=" C   LEU A  32 "
     pdb=" N   CYS A  33 "
  ideal  model  delta    sigma   weight residual
  1.329  1.324  0.006 1.25e-02 6.40e+03 2.09e-01
bond pdb=" CB  SER A   9 "
     pdb=" OG  SER A   9 "
  ideal  model  delta    sigma   weight residual
  1.417  1.408  0.009 2.00e-02 2.50e+03 2.09e-01
bond pdb=" C   THR A  48 "
     pdb=" O   THR A  48 "
  ideal  model  delta    sigma   weight residual
  1.234  1.229  0.005 1.16e-02 7.43e+03 2.01e-01
bond pdb=" C   THR A  15 "
     pdb=" N   ARG A  16 "
  ideal  model  delta    sigma   weight residual
  1.330  1.324  0.006 1.36e-02 5.41e+03 2.00e-01
bond pdb=" C   LYS A   7 "
     pdb=" N   PRO A   8 "
  ideal  model  delta    sigma   weight residual
  1.333  1.340 -0.006 1.44e-02 4.82e+03 2.00e-01
bond pdb=" N   VAL A  43 "
     pdb=" CA  VAL A  43 "
  ideal  model  delta    sigma   weight residual
  1.458  1.452  0.006 1.24e-02 6.50e+03 2.00e-01
bond pdb=" ND1 HIS A  64 "
     pdb=" CE1 HIS A  64 "
  ideal  model  delta    sigma   weight residual
  1.321  1.317  0.004 1.00e-02 1.00e+04 1.99e-01
bond pdb=" CG  ASP A  36 "
     pdb=" OD1 ASP A  36 "
  ideal  model  delta    sigma   weight residual
  1.249  1.241  0.008 1.90e-02 2.77e+03 1.97e-01
bond pdb=" C   PRO A  54 "
     pdb=" N   ALA A  55 "
  ideal  model  delta    sigma   weight residual
  1.330  1.324  0.006 1.32e-02 5.74e+03 1.94e-01
bond pdb=" CB  PRO A  58 "
     pdb=" CG  PRO A  58 "
  ideal  model  delta    sigma   weight residual
  1.492  1.470  0.022 5.00e-02 4.00e+02 1.92e-01
bond pdb=" CA  LEU A  60 "
     pdb=" CB  LEU A  60 "
  ideal  model  delta    sigma   weight residual
  1.531  1.524  0.007 1.52e-02 4.33e+03 1.90e-01
bond pdb=" CG  PHE A  13 "
     pdb=" CD1 PHE A  13 "
  ideal  model  delta    sigma   weight residual
  1.384  1.375  0.009 2.10e-02 2.27e+03 1.87e-01
bond pdb=" CD1 TYR A  61 "
     pdb=" CE1 TYR A  61 "
  ideal  model  delta    sigma   weight residual
  1.382  1.369  0.013 3.00e-02 1.11e+03 1.84e-01
bond pdb=" CE1 PHE A  68 "
     pdb=" CZ  PHE A  68 "
  ideal  model  delta    sigma   weight residual
  1.382  1.369  0.013 3.00e-02 1.11e+03 1.83e-01
bond pdb=" CE1 PHE A  13 "
     pdb=" CZ  PHE A  13 "
  ideal  model  delta    sigma   weight residual
  1.382  1.369  0.013 3.00e-02 1.11e+03 1.82e-01
bond pdb=" N   SER A  17 "
     pdb=" CA  SER A  17 "
  ideal  model  delta    sigma   weight residual
  1.458  1.450  0.008 1.90e-02 2.77e+03 1.82e-01
bond pdb=" CD1 PHE A  68 "
     pdb=" CE1 PHE A  68 "
  ideal  model  delta    sigma   weight residual
  1.382  1.369  0.013 3.00e-02 1.11e+03 1.75e-01
bond pdb=" C   GLN A  53 "
     pdb=" N   PRO A  54 "
  ideal  model  delta    sigma   weight residual
  1.330  1.335 -0.005 1.25e-02 6.40e+03 1.74e-01
bond pdb=" CA  GLU A  30 "
     pdb=" C   GLU A  30 "
  ideal  model  delta    sigma   weight residual
  1.522  1.517  0.005 1.22e-02 6.72e+03 1.72e-01
bond pdb=" CG  ASP A  79 "
     pdb=" OD1 ASP A  79 "
  ideal  model  delta    sigma   weight residual
  1.249  1.241  0.008 1.90e-02 2.77e+03 1.70e-01
bond pdb=" N   VAL A   4 "
     pdb=" CA  VAL A   4 "
  ideal  model  delta    sigma   weight residual
  1.458  1.453  0.005 1.18e-02 7.18e+03 1.70e-01
bond pdb=" CB  THR A  48 "
     pdb=" OG1 THR A  48 "
  ideal  model  delta    sigma   weight residual
  1.433  1.426  0.007 1.60e-02 3.91e+03 1.68e-01
bond pdb=" CA  LYS A  69 "
     pdb=" C   LYS A  69 "
  ideal  model  delta    sigma   weight residual
  1.523  1.528 -0.005 1.25e-02 6.40e+03 1.68e-01
bond pdb=" N   ILE A  78 "
     pdb=" CA  ILE A  78 "
  ideal  model  delta    sigma   weight residual
  1.459  1.454  0.005 1.24e-02 6.50e+03 1.66e-01
bond pdb=" CD  ARG A  82 "
     pdb=" NE  ARG A  82 "
  ideal  model  delta    sigma   weight residual
  1.458  1.452  0.006 1.40e-02 5.10e+03 1.63e-01
bond pdb=" C   LEU A  28 "
     pdb=" N   ASN A  29 "
  ideal  model  delta    sigma   weight residual
  1.330  1.324  0.005 1.32e-02 5.74e+03 1.62e-01
bond pdb=" CB  MSE A  77 "
     pdb=" CG  MSE A  77 "
  ideal  model  delta    sigma   weight residual
  1.520  1.508  0.012 3.00e-02 1.11e+03 1.61e-01
bond pdb=" CB  SER A  66 "
     pdb=" OG  SER A  66 "
  ideal  model  delta    sigma   weight residual
  1.417  1.409  0.008 2.00e-02 2.50e+03 1.60e-01
bond pdb=" CG  TYR A  56 "
     pdb=" CD2 TYR A  56 "
  ideal  model  delta    sigma   weight residual
  1.389  1.381  0.008 2.10e-02 2.27e+03 1.58e-01
bond pdb=" CG  PRO A  85 "
     pdb=" CD  PRO A  85 "
  ideal  model  delta    sigma   weight residual
  1.503  1.489  0.014 3.40e-02 8.65e+02 1.58e-01
bond pdb=" CA  THR A  14 "
     pdb=" CB  THR A  14 "
  ideal  model  delta    sigma   weight residual
  1.534  1.541 -0.006 1.60e-02 3.91e+03 1.57e-01
bond pdb=" CA  LEU A  83 "
     pdb=" C   LEU A  83 "
  ideal  model  delta    sigma   weight residual
  1.523  1.528 -0.005 1.18e-02 7.18e+03 1.56e-01
bond pdb=" CD2 PHE A  13 "
     pdb=" CE2 PHE A  13 "
  ideal  model  delta    sigma   weight residual
  1.382  1.370  0.012 3.00e-02 1.11e+03 1.55e-01
bond pdb=" CG  ASP A  36 "
     pdb=" OD2 ASP A  36 "
  ideal  model  delta    sigma   weight residual
  1.249  1.242  0.007 1.90e-02 2.77e+03 1.54e-01
bond pdb=" C   GLY A  71 "
     pdb=" O   GLY A  71 "
  ideal  model  delta    sigma   weight residual
  1.235  1.229  0.005 1.35e-02 5.49e+03 1.53e-01
bond pdb=" CB  ILE A  78 "
     pdb=" CG1 ILE A  78 "
  ideal  model  delta    sigma   weight residual
  1.530  1.522  0.008 2.00e-02 2.50e+03 1.53e-01
bond pdb=" N   LEU A  81 "
     pdb=" CA  LEU A  81 "
  ideal  model  delta    sigma   weight residual
  1.457  1.462 -0.005 1.29e-02 6.01e+03 1.50e-01
bond pdb=" CA  ASP A  79 "
     pdb=" CB  ASP A  79 "
  ideal  model  delta    sigma   weight residual
  1.533  1.527  0.006 1.46e-02 4.69e+03 1.48e-01
bond pdb=" N   PRO A  42 "
     pdb=" CD  PRO A  42 "
  ideal  model  delta    sigma   weight residual
  1.473  1.478 -0.005 1.40e-02 5.10e+03 1.43e-01
bond pdb=" CB  LEU A  60 "
     pdb=" CG  LEU A  60 "
  ideal  model  delta    sigma   weight residual
  1.530  1.522  0.008 2.00e-02 2.50e+03 1.43e-01
bond pdb=" CG  PRO A  54 "
     pdb=" CD  PRO A  54 "
  ideal  model  delta    sigma   weight residual
  1.503  1.490  0.013 3.40e-02 8.65e+02 1.43e-01
bond pdb=" CD2 TYR A  34 "
     pdb=" CE2 TYR A  34 "
  ideal  model  delta    sigma   weight residual
  1.382  1.393 -0.011 3.00e-02 1.11e+03 1.42e-01
bond pdb=" CG  GLN A  10 "
     pdb=" CD  GLN A  10 "
  ideal  model  delta    sigma   weight residual
  1.516  1.507  0.009 2.50e-02 1.60e+03 1.40e-01
bond pdb=" CB  LEU A  28 "
     pdb=" CG  LEU A  28 "
  ideal  model  delta    sigma   weight residual
  1.530  1.523  0.007 2.00e-02 2.50e+03 1.40e-01
bond pdb=" CA  ASP A  50 "
     pdb=" CB  ASP A  50 "
  ideal  model  delta    sigma   weight residual
  1.529  1.535 -0.006 1.65e-02 3.67e+03 1.40e-01
bond pdb=" CZ  TYR A  41 "
     pdb=" OH  TYR A  41 "
  ideal  model  delta    sigma   weight residual
  1.376  1.368  0.008 2.10e-02 2.27e+03 1.39e-01
bond pdb=" CD  GLN A  10 "
     pdb=" OE1 GLN A  10 "
  ideal  model  delta    sigma   weight residual
  1.231  1.224  0.007 1.90e-02 2.77e+03 1.39e-01
bond pdb=" CA  ILE A   6 "
     pdb=" CB  ILE A   6 "
  ideal  model  delta    sigma   weight residual
  1.537  1.541 -0.004 1.21e-02 6.83e+03 1.38e-01
bond pdb=" CA  ARG A  80 "
     pdb=" C   ARG A  80 "
  ideal  model  delta    sigma   weight residual
  1.520  1.516  0.004 1.20e-02 6.94e+03 1.37e-01
bond pdb=" CB  ARG A  16 "
     pdb=" CG  ARG A  16 "
  ideal  model  delta    sigma   weight residual
  1.520  1.509  0.011 3.00e-02 1.11e+03 1.36e-01
bond pdb=" N   GLU A  40 "
     pdb=" CA  GLU A  40 "
  ideal  model  delta    sigma   weight residual
  1.459  1.455  0.004 1.21e-02 6.83e+03 1.33e-01
bond pdb=" CB  SER A  27 "
     pdb=" OG  SER A  27 "
  ideal  model  delta    sigma   weight residual
  1.417  1.410  0.007 2.00e-02 2.50e+03 1.30e-01
bond pdb=" CG  LYS A  69 "
     pdb=" CD  LYS A  69 "
  ideal  model  delta    sigma   weight residual
  1.520  1.531 -0.011 3.00e-02 1.11e+03 1.29e-01
bond pdb=" N   PRO A  58 "
     pdb=" CD  PRO A  58 "
  ideal  model  delta    sigma   weight residual
  1.473  1.468  0.005 1.40e-02 5.10e+03 1.28e-01
bond pdb=" CD  GLU A   5 "
     pdb=" OE1 GLU A   5 "
  ideal  model  delta    sigma   weight residual
  1.249  1.242  0.007 1.90e-02 2.77e+03 1.27e-01
bond pdb=" CA  GLN A  31 "
     pdb=" CB  GLN A  31 "
  ideal  model  delta    sigma   weight residual
  1.536  1.528  0.007 2.08e-02 2.31e+03 1.26e-01
bond pdb=" C   ALA A  55 "
     pdb=" O   ALA A  55 "
  ideal  model  delta    sigma   weight residual
  1.234  1.230  0.004 1.22e-02 6.72e+03 1.25e-01
bond pdb=" N   PRO A  54 "
     pdb=" CD  PRO A  54 "
  ideal  model  delta    sigma   weight residual
  1.473  1.468  0.005 1.40e-02 5.10e+03 1.25e-01
bond pdb=" C   THR A  14 "
     pdb=" O   THR A  14 "
  ideal  model  delta    sigma   weight residual
  1.234  1.229  0.005 1.31e-02 5.83e+03 1.25e-01
bond pdb=" N   TYR A  34 "
     pdb=" CA  TYR A  34 "
  ideal  model  delta    sigma   weight residual
  1.456  1.461 -0.004 1.21e-02 6.83e+03 1.22e-01
bond pdb=" CB  HIS A  64 "
     pdb=" CG  HIS A  64 "
  ideal  model  delta    sigma   weight residual
  1.497  1.492  0.005 1.40e-02 5.10e+03 1.22e-01
bond pdb=" CG  PRO A  58 "
     pdb=" CD  PRO A  58 "
  ideal  model  delta    sigma   weight residual
  1.503  1.491  0.012 3.40e-02 8.65e+02 1.21e-01
bond pdb=" CA  SER A  67 "
     pdb=" CB  SER A  67 "
  ideal  model  delta    sigma   weight residual
  1.529  1.535 -0.006 1.74e-02 3.30e+03 1.21e-01
bond pdb=" CG  ASN A  39 "
     pdb=" OD1 ASN A  39 "
  ideal  model  delta    sigma   weight residual
  1.231  1.224  0.007 1.90e-02 2.77e+03 1.21e-01
bond pdb=" CB  GLN A  72 "
     pdb=" CG  GLN A  72 "
  ideal  model  delta    sigma   weight residual
  1.520  1.510  0.010 3.00e-02 1.11e+03 1.19e-01
bond pdb=" CB  ARG A  80 "
     pdb=" CG  ARG A  80 "
  ideal  model  delta    sigma   weight residual
  1.520  1.510  0.010 3.00e-02 1.11e+03 1.19e-01
bond pdb=" CA  LEU A  65 "
     pdb=" C   LEU A  65 "
  ideal  model  delta    sigma   weight residual
  1.522  1.518  0.005 1.36e-02 5.41e+03 1.17e-01
bond pdb=" CZ  ARG A  16 "
     pdb=" NH2 ARG A  16 "
  ideal  model  delta    sigma   weight residual
  1.330  1.334 -0.004 1.30e-02 5.92e+03 1.15e-01
bond pdb=" CD  GLN A  31 "
     pdb=" OE1 GLN A  31 "
  ideal  model  delta    sigma   weight residual
  1.231  1.225  0.006 1.90e-02 2.77e+03 1.14e-01
bond pdb=" N   PRO A  42 "
     pdb=" CA  PRO A  42 "
  ideal  model  delta    sigma   weight residual
  1.466  1.470 -0.004 1.24e-02 6.50e+03 1.14e-01
bond pdb=" CB  SER A  67 "
     pdb=" OG  SER A  67 "
  ideal  model  delta    sigma   weight residual
  1.417  1.410  0.007 2.00e-02 2.50e+03 1.14e-01
bond pdb=" CG  LEU A  28 "
     pdb=" CD2 LEU A  28 "
  ideal  model  delta    sigma   weight residual
  1.521  1.510  0.011 3.30e-02 9.18e+02 1.12e-01
bond pdb=" CD2 HIS A  64 "
     pdb=" NE2 HIS A  64 "
  ideal  model  delta    sigma   weight residual
  1.374  1.370  0.004 1.10e-02 8.26e+03 1.12e-01
bond pdb=" CA  LEU A  76 "
     pdb=" CB  LEU A  76 "
  ideal  model  delta    sigma   weight residual
  1.528  1.523  0.005 1.58e-02 4.01e+03 1.11e-01
bond pdb=" CD2 TYR A  61 "
     pdb=" CE2 TYR A  61 "
  ideal  model  delta    sigma   weight residual
  1.382  1.372  0.010 3.00e-02 1.11e+03 1.11e-01
bond pdb=" CD  LYS A   3 "
     pdb=" CE  LYS A   3 "
  ideal  model  delta    sigma   weight residual
  1.520  1.510  0.010 3.00e-02 1.11e+03 1.08e-01
bond pdb="SE   MSE A  77 "
     pdb=" CE  MSE A  77 "
  ideal  model  delta    sigma   weight residual
  1.950  1.960 -0.010 3.00e-02 1.11e+03 1.07e-01
bond pdb=" CD  GLN A  72 "
     pdb=" OE1 GLN A  72 "
  ideal  model  delta    sigma   weight residual
  1.231  1.237 -0.006 1.90e-02 2.77e+03 1.07e-01
bond pdb=" C   ILE A   2 "
     pdb=" O   ILE A   2 "
  ideal  model  delta    sigma   weight residual
  1.231  1.224  0.007 2.00e-02 2.50e+03 1.06e-01
bond pdb=" CG  PRO A   8 "
     pdb=" CD  PRO A   8 "
  ideal  model  delta    sigma   weight residual
  1.503  1.492  0.011 3.40e-02 8.65e+02 1.05e-01
bond pdb=" CG  GLN A  12 "
     pdb=" CD  GLN A  12 "
  ideal  model  delta    sigma   weight residual
  1.516  1.524 -0.008 2.50e-02 1.60e+03 1.04e-01
bond pdb=" N   ASP A  79 "
     pdb=" CA  ASP A  79 "
  ideal  model  delta    sigma   weight residual
  1.460  1.456  0.004 1.22e-02 6.72e+03 1.02e-01
bond pdb=" N   ARG A  16 "
     pdb=" CA  ARG A  16 "
  ideal  model  delta    sigma   weight residual
  1.455  1.451  0.004 1.21e-02 6.83e+03 1.01e-01
bond pdb=" N   PRO A  85 "
     pdb=" CA  PRO A  85 "
  ideal  model  delta    sigma   weight residual
  1.466  1.471 -0.005 1.50e-02 4.44e+03 1.01e-01
bond pdb=" CE2 PHE A  68 "
     pdb=" CZ  PHE A  68 "
  ideal  model  delta    sigma   weight residual
  1.382  1.372  0.010 3.00e-02 1.11e+03 1.01e-01
bond pdb=" CE2 TYR A  56 "
     pdb=" CZ  TYR A  56 "
  ideal  model  delta    sigma   weight residual
  1.378  1.370  0.008 2.40e-02 1.74e+03 1.00e-01
bond pdb=" CB  LEU A  76 "
     pdb=" CG  LEU A  76 "
  ideal  model  delta    sigma   weight residual
  1.530  1.524  0.006 2.00e-02 2.50e+03 9.84e-02
bond pdb=" CD1 TYR A  26 "
     pdb=" CE1 TYR A  26 "
  ideal  model  delta    sigma   weight residual
  1.382  1.373  0.009 3.00e-02 1.11e+03 9.79e-02
bond pdb=" CA  PRO A  85 "
     pdb=" CB  PRO A  85 "
  ideal  model  delta    sigma   weight residual
  1.530  1.536 -0.006 2.00e-02 2.50e+03 9.66e-02
bond pdb=" CZ  ARG A  82 "
     pdb=" NH1 ARG A  82 "
  ideal  model  delta    sigma   weight residual
  1.323  1.319  0.004 1.40e-02 5.10e+03 9.66e-02
bond pdb=" CG  HIS A  64 "
     pdb=" CD2 HIS A  64 "
  ideal  model  delta    sigma   weight residual
  1.354  1.351  0.003 1.10e-02 8.26e+03 9.52e-02
bond pdb=" CB  GLN A  53 "
     pdb=" CG  GLN A  53 "
  ideal  model  delta    sigma   weight residual
  1.520  1.511  0.009 3.00e-02 1.11e+03 9.45e-02
bond pdb=" CB  THR A  15 "
     pdb=" CG2 THR A  15 "
  ideal  model  delta    sigma   weight residual
  1.521  1.511  0.010 3.30e-02 9.18e+02 9.31e-02
bond pdb=" CZ  ARG A  80 "
     pdb=" NH1 ARG A  80 "
  ideal  model  delta    sigma   weight residual
  1.323  1.319  0.004 1.40e-02 5.10e+03 8.91e-02
bond pdb=" CB  LYS A   3 "
     pdb=" CG  LYS A   3 "
  ideal  model  delta    sigma   weight residual
  1.520  1.511  0.009 3.00e-02 1.11e+03 8.83e-02
bond pdb=" CG  TYR A  26 "
     pdb=" CD1 TYR A  26 "
  ideal  model  delta    sigma   weight residual
  1.389  1.395 -0.006 2.10e-02 2.27e+03 8.79e-02
bond pdb=" N   GLU A  30 "
     pdb=" CA  GLU A  30 "
  ideal  model  delta    sigma   weight residual
  1.455  1.452  0.004 1.23e-02 6.61e+03 8.76e-02
bond pdb=" CB  VAL A  63 "
     pdb=" CG2 VAL A  63 "
  ideal  model  delta    sigma   weight residual
  1.521  1.511  0.010 3.30e-02 9.18e+02 8.54e-02
bond pdb=" CG  LEU A  32 "
     pdb=" CD1 LEU A  32 "
  ideal  model  delta    sigma   weight residual
  1.521  1.511  0.010 3.30e-02 9.18e+02 8.52e-02
bond pdb=" CG  LEU A  60 "
     pdb=" CD2 LEU A  60 "
  ideal  model  delta    sigma   weight residual
  1.521  1.511  0.010 3.30e-02 9.18e+02 8.48e-02
bond pdb=" CD2 PHE A  68 "
     pdb=" CE2 PHE A  68 "
  ideal  model  delta    sigma   weight residual
  1.382  1.373  0.009 3.00e-02 1.11e+03 8.36e-02
bond pdb=" C   GLY A  74 "
     pdb=" N   SER A  75 "
  ideal  model  delta    sigma   weight residual
  1.328  1.332 -0.004 1.44e-02 4.82e+03 8.29e-02
bond pdb=" CA  TYR A  56 "
     pdb=" CB  TYR A  56 "
  ideal  model  delta    sigma   weight residual
  1.528  1.533 -0.005 1.66e-02 3.63e+03 8.21e-02
bond pdb=" CA  TYR A  26 "
     pdb=" C   TYR A  26 "
  ideal  model  delta    sigma   weight residual
  1.525  1.519  0.006 2.10e-02 2.27e+03 8.04e-02
bond pdb=" CG  LYS A  46 "
     pdb=" CD  LYS A  46 "
  ideal  model  delta    sigma   weight residual
  1.520  1.512  0.008 3.00e-02 1.11e+03 7.98e-02
bond pdb=" CA  LEU A  81 "
     pdb=" C   LEU A  81 "
  ideal  model  delta    sigma   weight residual
  1.523  1.527 -0.004 1.34e-02 5.57e+03 7.90e-02
bond pdb=" CG  LYS A   7 "
     pdb=" CD  LYS A   7 "
  ideal  model  delta    sigma   weight residual
  1.520  1.512  0.008 3.00e-02 1.11e+03 7.81e-02
bond pdb=" CB  LEU A  49 "
     pdb=" CG  LEU A  49 "
  ideal  model  delta    sigma   weight residual
  1.530  1.524  0.006 2.00e-02 2.50e+03 7.58e-02
bond pdb=" C   PHE A  73 "
     pdb=" N   GLY A  74 "
  ideal  model  delta    sigma   weight residual
  1.333  1.330  0.004 1.41e-02 5.03e+03 7.57e-02
bond pdb=" CB  PRO A   8 "
     pdb=" CG  PRO A   8 "
  ideal  model  delta    sigma   weight residual
  1.492  1.478  0.014 5.00e-02 4.00e+02 7.54e-02
bond pdb=" CB  LYS A   7 "
     pdb=" CG  LYS A   7 "
  ideal  model  delta    sigma   weight residual
  1.520  1.512  0.008 3.00e-02 1.11e+03 7.48e-02
bond pdb=" CE2 TYR A  34 "
     pdb=" CZ  TYR A  34 "
  ideal  model  delta    sigma   weight residual
  1.378  1.371  0.007 2.40e-02 1.74e+03 7.41e-02
bond pdb=" NE  ARG A  16 "
     pdb=" CZ  ARG A  16 "
  ideal  model  delta    sigma   weight residual
  1.326  1.323  0.003 1.10e-02 8.26e+03 7.36e-02
bond pdb=" CA  SER A  66 "
     pdb=" CB  SER A  66 "
  ideal  model  delta    sigma   weight residual
  1.530  1.535 -0.005 1.87e-02 2.86e+03 7.22e-02
bond pdb=" CG  TYR A  61 "
     pdb=" CD1 TYR A  61 "
  ideal  model  delta    sigma   weight residual
  1.389  1.383  0.006 2.10e-02 2.27e+03 7.09e-02
bond pdb=" CA  ARG A  82 "
     pdb=" C   ARG A  82 "
  ideal  model  delta    sigma   weight residual
  1.522  1.519  0.003 1.20e-02 6.94e+03 7.06e-02
bond pdb=" C   TYR A  34 "
     pdb=" N   VAL A  35 "
  ideal  model  delta    sigma   weight residual
  1.330  1.327  0.003 1.26e-02 6.30e+03 7.00e-02
bond pdb=" CB  PRO A  54 "
     pdb=" CG  PRO A  54 "
  ideal  model  delta    sigma   weight residual
  1.492  1.479  0.013 5.00e-02 4.00e+02 6.95e-02
bond pdb=" CB  ARG A  82 "
     pdb=" CG  ARG A  82 "
  ideal  model  delta    sigma   weight residual
  1.520  1.512  0.008 3.00e-02 1.11e+03 6.92e-02
bond pdb=" CE2 TYR A  61 "
     pdb=" CZ  TYR A  61 "
  ideal  model  delta    sigma   weight residual
  1.378  1.372  0.006 2.40e-02 1.74e+03 6.47e-02
bond pdb=" C   SER A  75 "
     pdb=" N   LEU A  76 "
  ideal  model  delta    sigma   weight residual
  1.331  1.327  0.003 1.37e-02 5.33e+03 6.47e-02
bond pdb=" CD2 TYR A  26 "
     pdb=" CE2 TYR A  26 "
  ideal  model  delta    sigma   weight residual
  1.382  1.374  0.008 3.00e-02 1.11e+03 6.47e-02
bond pdb=" N   GLY A  38 "
     pdb=" CA  GLY A  38 "
  ideal  model  delta    sigma   weight residual
  1.446  1.443  0.004 1.54e-02 4.22e+03 6.42e-02
bond pdb=" CG  ARG A  82 "
     pdb=" CD  ARG A  82 "
  ideal  model  delta    sigma   weight residual
  1.520  1.512  0.008 3.00e-02 1.11e+03 6.40e-02
bond pdb=" CA  ILE A  78 "
     pdb=" C   ILE A  78 "
  ideal  model  delta    sigma   weight residual
  1.523  1.520  0.003 1.23e-02 6.61e+03 6.25e-02
bond pdb=" CE1 HIS A  64 "
     pdb=" NE2 HIS A  64 "
  ideal  model  delta    sigma   weight residual
  1.321  1.319  0.002 1.00e-02 1.00e+04 6.15e-02
bond pdb=" CG  GLN A  53 "
     pdb=" CD  GLN A  53 "
  ideal  model  delta    sigma   weight residual
  1.516  1.510  0.006 2.50e-02 1.60e+03 6.13e-02
bond pdb=" CA  ILE A   2 "
     pdb=" C   ILE A   2 "
  ideal  model  delta    sigma   weight residual
  1.525  1.520  0.005 2.10e-02 2.27e+03 6.06e-02
bond pdb=" N   GLY A  71 "
     pdb=" CA  GLY A  71 "
  ideal  model  delta    sigma   weight residual
  1.449  1.453 -0.004 1.45e-02 4.76e+03 6.04e-02
bond pdb=" CD1 TYR A  41 "
     pdb=" CE1 TYR A  41 "
  ideal  model  delta    sigma   weight residual
  1.382  1.389 -0.007 3.00e-02 1.11e+03 6.04e-02
bond pdb=" N   PHE A  13 "
     pdb=" CA  PHE A  13 "
  ideal  model  delta    sigma   weight residual
  1.454  1.451  0.003 1.23e-02 6.61e+03 5.84e-02
bond pdb=" CA  CYS A  33 "
     pdb=" CB  CYS A  33 "
  ideal  model  delta    sigma   weight residual
  1.531  1.535 -0.004 1.67e-02 3.59e+03 5.81e-02
bond pdb=" CB  TYR A  41 "
     pdb=" CG  TYR A  41 "
  ideal  model  delta    sigma   weight residual
  1.512  1.517 -0.005 2.20e-02 2.07e+03 5.75e-02
bond pdb=" CD  GLN A  12 "
     pdb=" OE1 GLN A  12 "
  ideal  model  delta    sigma   weight residual
  1.231  1.226  0.005 1.90e-02 2.77e+03 5.75e-02
bond pdb=" CA  VAL A  43 "
     pdb=" C   VAL A  43 "
  ideal  model  delta    sigma   weight residual
  1.521  1.524 -0.003 1.27e-02 6.20e+03 5.59e-02
bond pdb=" CA  PHE A  73 "
     pdb=" CB  PHE A  73 "
  ideal  model  delta    sigma   weight residual
  1.529  1.532 -0.003 1.40e-02 5.10e+03 5.57e-02
bond pdb=" CB  GLN A  12 "
     pdb=" CG  GLN A  12 "
  ideal  model  delta    sigma   weight residual
  1.520  1.527 -0.007 3.00e-02 1.11e+03 5.55e-02
bond pdb=" CG  TYR A  26 "
     pdb=" CD2 TYR A  26 "
  ideal  model  delta    sigma   weight residual
  1.389  1.384  0.005 2.10e-02 2.27e+03 5.52e-02
bond pdb=" N   PRO A   8 "
     pdb=" CD  PRO A   8 "
  ideal  model  delta    sigma   weight residual
  1.473  1.470  0.003 1.40e-02 5.10e+03 5.52e-02
bond pdb=" CG  HIS A  64 "
     pdb=" ND1 HIS A  64 "
  ideal  model  delta    sigma   weight residual
  1.378  1.375  0.003 1.10e-02 8.26e+03 5.43e-02
bond pdb=" CG  PRO A  42 "
     pdb=" CD  PRO A  42 "
  ideal  model  delta    sigma   weight residual
  1.503  1.495  0.008 3.40e-02 8.65e+02 5.40e-02
bond pdb=" CG  LEU A  81 "
     pdb=" CD1 LEU A  81 "
  ideal  model  delta    sigma   weight residual
  1.521  1.514  0.007 3.30e-02 9.18e+02 5.14e-02
bond pdb=" CG  PHE A  73 "
     pdb=" CD2 PHE A  73 "
  ideal  model  delta    sigma   weight residual
  1.384  1.389 -0.005 2.10e-02 2.27e+03 5.09e-02
bond pdb=" CA  GLN A  72 "
     pdb=" C   GLN A  72 "
  ideal  model  delta    sigma   weight residual
  1.523  1.526 -0.003 1.41e-02 5.03e+03 5.05e-02
bond pdb=" CG  LEU A  65 "
     pdb=" CD2 LEU A  65 "
  ideal  model  delta    sigma   weight residual
  1.521  1.514  0.007 3.30e-02 9.18e+02 4.96e-02
bond pdb=" CB  GLU A   5 "
     pdb=" CG  GLU A   5 "
  ideal  model  delta    sigma   weight residual
  1.520  1.513  0.007 3.00e-02 1.11e+03 4.81e-02
bond pdb=" CA  LYS A  69 "
     pdb=" CB  LYS A  69 "
  ideal  model  delta    sigma   weight residual
  1.535  1.539 -0.004 1.71e-02 3.42e+03 4.79e-02
bond pdb=" CB  GLN A  31 "
     pdb=" CG  GLN A  31 "
  ideal  model  delta    sigma   weight residual
  1.520  1.513  0.007 3.00e-02 1.11e+03 4.76e-02
bond pdb=" C   ILE A  78 "
     pdb=" N   ASP A  79 "
  ideal  model  delta    sigma   weight residual
  1.333  1.330  0.003 1.26e-02 6.30e+03 4.72e-02
bond pdb=" C   VAL A   4 "
     pdb=" O   VAL A   4 "
  ideal  model  delta    sigma   weight residual
  1.236  1.238 -0.002 9.90e-03 1.02e+04 4.71e-02
bond pdb=" CD  GLN A  72 "
     pdb=" NE2 GLN A  72 "
  ideal  model  delta    sigma   weight residual
  1.328  1.333 -0.005 2.10e-02 2.27e+03 4.66e-02
bond pdb=" CD  GLU A  51 "
     pdb=" OE1 GLU A  51 "
  ideal  model  delta    sigma   weight residual
  1.249  1.253 -0.004 1.90e-02 2.77e+03 4.65e-02
bond pdb=" CE2 PHE A  13 "
     pdb=" CZ  PHE A  13 "
  ideal  model  delta    sigma   weight residual
  1.382  1.376  0.006 3.00e-02 1.11e+03 4.51e-02
bond pdb=" CB  VAL A  45 "
     pdb=" CG1 VAL A  45 "
  ideal  model  delta    sigma   weight residual
  1.521  1.514  0.007 3.30e-02 9.18e+02 4.44e-02
bond pdb=" CE2 TYR A  26 "
     pdb=" CZ  TYR A  26 "
  ideal  model  delta    sigma   weight residual
  1.378  1.373  0.005 2.40e-02 1.74e+03 4.37e-02
bond pdb=" CB  VAL A  43 "
     pdb=" CG1 VAL A  43 "
  ideal  model  delta    sigma   weight residual
  1.521  1.514  0.007 3.30e-02 9.18e+02 4.34e-02
bond pdb=" CG  PHE A  68 "
     pdb=" CD1 PHE A  68 "
  ideal  model  delta    sigma   weight residual
  1.384  1.380  0.004 2.10e-02 2.27e+03 4.27e-02
bond pdb=" CD  LYS A   7 "
     pdb=" CE  LYS A   7 "
  ideal  model  delta    sigma   weight residual
  1.520  1.514  0.006 3.00e-02 1.11e+03 4.27e-02
bond pdb=" CB  GLU A  30 "
     pdb=" CG  GLU A  30 "
  ideal  model  delta    sigma   weight residual
  1.520  1.514  0.006 3.00e-02 1.11e+03 4.23e-02
bond pdb=" CG  LEU A  44 "
     pdb=" CD2 LEU A  44 "
  ideal  model  delta    sigma   weight residual
  1.521  1.514  0.007 3.30e-02 9.18e+02 4.23e-02
bond pdb=" C   THR A  15 "
     pdb=" O   THR A  15 "
  ideal  model  delta    sigma   weight residual
  1.235  1.238 -0.002 1.14e-02 7.69e+03 4.23e-02
bond pdb=" CG  ASN A  39 "
     pdb=" ND2 ASN A  39 "
  ideal  model  delta    sigma   weight residual
  1.328  1.324  0.004 2.10e-02 2.27e+03 4.21e-02
bond pdb=" CE  LYS A   7 "
     pdb=" NZ  LYS A   7 "
  ideal  model  delta    sigma   weight residual
  1.489  1.483  0.006 3.00e-02 1.11e+03 4.17e-02
bond pdb=" CG  ARG A  80 "
     pdb=" CD  ARG A  80 "
  ideal  model  delta    sigma   weight residual
  1.520  1.514  0.006 3.00e-02 1.11e+03 4.10e-02
bond pdb=" CB  VAL A  45 "
     pdb=" CG2 VAL A  45 "
  ideal  model  delta    sigma   weight residual
  1.521  1.514  0.007 3.30e-02 9.18e+02 4.08e-02
bond pdb=" CD2 PHE A  73 "
     pdb=" CE2 PHE A  73 "
  ideal  model  delta    sigma   weight residual
  1.382  1.388 -0.006 3.00e-02 1.11e+03 4.06e-02
bond pdb=" N   LYS A  46 "
     pdb=" CA  LYS A  46 "
  ideal  model  delta    sigma   weight residual
  1.456  1.454  0.002 1.23e-02 6.61e+03 3.92e-02
bond pdb=" CD2 TYR A  56 "
     pdb=" CE2 TYR A  56 "
  ideal  model  delta    sigma   weight residual
  1.382  1.376  0.006 3.00e-02 1.11e+03 3.84e-02
bond pdb=" CA  PRO A   8 "
     pdb=" C   PRO A   8 "
  ideal  model  delta    sigma   weight residual
  1.516  1.513  0.003 1.72e-02 3.38e+03 3.79e-02
bond pdb=" CA  LEU A  83 "
     pdb=" CB  LEU A  83 "
  ideal  model  delta    sigma   weight residual
  1.532  1.529  0.003 1.74e-02 3.30e+03 3.74e-02
bond pdb=" NE  ARG A  82 "
     pdb=" CZ  ARG A  82 "
  ideal  model  delta    sigma   weight residual
  1.326  1.324  0.002 1.10e-02 8.26e+03 3.69e-02
bond pdb=" CA  ASN A  39 "
     pdb=" CB  ASN A  39 "
  ideal  model  delta    sigma   weight residual
  1.532  1.529  0.003 1.54e-02 4.22e+03 3.67e-02
bond pdb=" CD  GLN A  12 "
     pdb=" NE2 GLN A  12 "
  ideal  model  delta    sigma   weight residual
  1.328  1.324  0.004 2.10e-02 2.27e+03 3.67e-02
bond pdb=" N   LEU A  65 "
     pdb=" CA  LEU A  65 "
  ideal  model  delta    sigma   weight residual
  1.459  1.456  0.002 1.25e-02 6.40e+03 3.67e-02
bond pdb=" CB  THR A  15 "
     pdb=" OG1 THR A  15 "
  ideal  model  delta    sigma   weight residual
  1.433  1.436 -0.003 1.60e-02 3.91e+03 3.63e-02
bond pdb=" CD  GLU A  40 "
     pdb=" OE2 GLU A  40 "
  ideal  model  delta    sigma   weight residual
  1.249  1.253 -0.004 1.90e-02 2.77e+03 3.61e-02
bond pdb=" CD1 TYR A  56 "
     pdb=" CE1 TYR A  56 "
  ideal  model  delta    sigma   weight residual
  1.382  1.376  0.006 3.00e-02 1.11e+03 3.61e-02
bond pdb=" N   THR A  48 "
     pdb=" CA  THR A  48 "
  ideal  model  delta    sigma   weight residual
  1.461  1.459  0.003 1.38e-02 5.25e+03 3.60e-02
bond pdb=" CB  LYS A  69 "
     pdb=" CG  LYS A  69 "
  ideal  model  delta    sigma   weight residual
  1.520  1.526 -0.006 3.00e-02 1.11e+03 3.57e-02
bond pdb=" CB  VAL A  63 "
     pdb=" CG1 VAL A  63 "
  ideal  model  delta    sigma   weight residual
  1.521  1.515  0.006 3.30e-02 9.18e+02 3.57e-02
bond pdb=" CZ  TYR A  26 "
     pdb=" OH  TYR A  26 "
  ideal  model  delta    sigma   weight residual
  1.376  1.372  0.004 2.10e-02 2.27e+03 3.52e-02
bond pdb=" CG  LEU A  37 "
     pdb=" CD2 LEU A  37 "
  ideal  model  delta    sigma   weight residual
  1.521  1.515  0.006 3.30e-02 9.18e+02 3.48e-02
bond pdb=" CG  LEU A  49 "
     pdb=" CD2 LEU A  49 "
  ideal  model  delta    sigma   weight residual
  1.521  1.515  0.006 3.30e-02 9.18e+02 3.46e-02
bond pdb=" C   GLU A  40 "
     pdb=" O   GLU A  40 "
  ideal  model  delta    sigma   weight residual
  1.237  1.235  0.002 1.17e-02 7.31e+03 3.45e-02
bond pdb=" CB  TYR A  34 "
     pdb=" CG  TYR A  34 "
  ideal  model  delta    sigma   weight residual
  1.512  1.508  0.004 2.20e-02 2.07e+03 3.18e-02
bond pdb=" CZ  ARG A  16 "
     pdb=" NH1 ARG A  16 "
  ideal  model  delta    sigma   weight residual
  1.323  1.325 -0.002 1.40e-02 5.10e+03 3.18e-02
bond pdb=" CA  LEU A  65 "
     pdb=" CB  LEU A  65 "
  ideal  model  delta    sigma   weight residual
  1.529  1.526  0.003 1.64e-02 3.72e+03 3.18e-02
bond pdb=" CB  ASN A  39 "
     pdb=" CG  ASN A  39 "
  ideal  model  delta    sigma   weight residual
  1.516  1.512  0.004 2.50e-02 1.60e+03 3.17e-02
bond pdb=" CG  GLN A  72 "
     pdb=" CD  GLN A  72 "
  ideal  model  delta    sigma   weight residual
  1.516  1.520 -0.004 2.50e-02 1.60e+03 3.16e-02
bond pdb=" CG  LEU A  60 "
     pdb=" CD1 LEU A  60 "
  ideal  model  delta    sigma   weight residual
  1.521  1.515  0.006 3.30e-02 9.18e+02 3.13e-02
bond pdb=" CA  PHE A  13 "
     pdb=" CB  PHE A  13 "
  ideal  model  delta    sigma   weight residual
  1.535  1.538 -0.003 1.93e-02 2.68e+03 2.93e-02
bond pdb=" CG  LEU A  81 "
     pdb=" CD2 LEU A  81 "
  ideal  model  delta    sigma   weight residual
  1.521  1.515  0.006 3.30e-02 9.18e+02 2.89e-02
bond pdb=" CG1 ILE A   6 "
     pdb=" CD1 ILE A   6 "
  ideal  model  delta    sigma   weight residual
  1.513  1.506  0.007 3.90e-02 6.57e+02 2.80e-02
bond pdb=" CG  LEU A  32 "
     pdb=" CD2 LEU A  32 "
  ideal  model  delta    sigma   weight residual
  1.521  1.516  0.005 3.30e-02 9.18e+02 2.71e-02
bond pdb=" C   VAL A  35 "
     pdb=" O   VAL A  35 "
  ideal  model  delta    sigma   weight residual
  1.237  1.235  0.002 1.11e-02 8.12e+03 2.61e-02
bond pdb=" CB  THR A  62 "
     pdb=" CG2 THR A  62 "
  ideal  model  delta    sigma   weight residual
  1.521  1.526 -0.005 3.30e-02 9.18e+02 2.59e-02
bond pdb=" CD1 TYR A  34 "
     pdb=" CE1 TYR A  34 "
  ideal  model  delta    sigma   weight residual
  1.382  1.377  0.005 3.00e-02 1.11e+03 2.55e-02
bond pdb=" CB  CYS A  33 "
     pdb=" SG  CYS A  33 "
  ideal  model  delta    sigma   weight residual
  1.808  1.803  0.005 3.30e-02 9.18e+02 2.44e-02
bond pdb=" CA  GLN A  72 "
     pdb=" CB  GLN A  72 "
  ideal  model  delta    sigma   weight residual
  1.532  1.529  0.003 1.78e-02 3.16e+03 2.36e-02
bond pdb=" CB  PRO A  85 "
     pdb=" CG  PRO A  85 "
  ideal  model  delta    sigma   weight residual
  1.492  1.484  0.008 5.00e-02 4.00e+02 2.31e-02
bond pdb=" CB  THR A  14 "
     pdb=" OG1 THR A  14 "
  ideal  model  delta    sigma   weight residual
  1.433  1.431  0.002 1.60e-02 3.91e+03 2.23e-02
bond pdb=" CG  LEU A  37 "
     pdb=" CD1 LEU A  37 "
  ideal  model  delta    sigma   weight residual
  1.521  1.516  0.005 3.30e-02 9.18e+02 2.20e-02
bond pdb=" CA  TYR A  41 "
     pdb=" CB  TYR A  41 "
  ideal  model  delta    sigma   weight residual
  1.535  1.533  0.002 1.21e-02 6.83e+03 2.15e-02
bond pdb=" CB  THR A  62 "
     pdb=" OG1 THR A  62 "
  ideal  model  delta    sigma   weight residual
  1.433  1.431  0.002 1.60e-02 3.91e+03 2.14e-02
bond pdb=" CG  LEU A  49 "
     pdb=" CD1 LEU A  49 "
  ideal  model  delta    sigma   weight residual
  1.521  1.516  0.005 3.30e-02 9.18e+02 2.13e-02
bond pdb=" CB  TYR A  26 "
     pdb=" CG  TYR A  26 "
  ideal  model  delta    sigma   weight residual
  1.512  1.515 -0.003 2.20e-02 2.07e+03 2.10e-02
bond pdb=" CG1 ILE A  78 "
     pdb=" CD1 ILE A  78 "
  ideal  model  delta    sigma   weight residual
  1.513  1.507  0.006 3.90e-02 6.57e+02 2.05e-02
bond pdb=" N   GLN A  72 "
     pdb=" CA  GLN A  72 "
  ideal  model  delta    sigma   weight residual
  1.456  1.458 -0.002 1.32e-02 5.74e+03 2.01e-02
bond pdb=" CB  LEU A  83 "
     pdb=" CG  LEU A  83 "
  ideal  model  delta    sigma   weight residual
  1.530  1.533 -0.003 2.00e-02 2.50e+03 1.86e-02
bond pdb=" C   TYR A  41 "
     pdb=" N   PRO A  42 "
  ideal  model  delta    sigma   weight residual
  1.332  1.334 -0.002 1.34e-02 5.57e+03 1.83e-02
bond pdb=" CG  GLU A  30 "
     pdb=" CD  GLU A  30 "
  ideal  model  delta    sigma   weight residual
  1.516  1.513  0.003 2.50e-02 1.60e+03 1.82e-02
bond pdb=" CG  LEU A  28 "
     pdb=" CD1 LEU A  28 "
  ideal  model  delta    sigma   weight residual
  1.521  1.517  0.004 3.30e-02 9.18e+02 1.79e-02
bond pdb=" CA  LEU A  81 "
     pdb=" CB  LEU A  81 "
  ideal  model  delta    sigma   weight residual
  1.530  1.528  0.002 1.69e-02 3.50e+03 1.77e-02
bond pdb=" CD  GLU A  51 "
     pdb=" OE2 GLU A  51 "
  ideal  model  delta    sigma   weight residual
  1.249  1.252 -0.003 1.90e-02 2.77e+03 1.76e-02
bond pdb=" N   SER A   9 "
     pdb=" CA  SER A   9 "
  ideal  model  delta    sigma   weight residual
  1.456  1.455  0.002 1.31e-02 5.83e+03 1.72e-02
bond pdb=" CG  LYS A   3 "
     pdb=" CD  LYS A   3 "
  ideal  model  delta    sigma   weight residual
  1.520  1.524 -0.004 3.00e-02 1.11e+03 1.60e-02
bond pdb=" CA  LEU A  49 "
     pdb=" CB  LEU A  49 "
  ideal  model  delta    sigma   weight residual
  1.529  1.527  0.002 1.70e-02 3.46e+03 1.58e-02
bond pdb=" CA  ALA A  55 "
     pdb=" CB  ALA A  55 "
  ideal  model  delta    sigma   weight residual
  1.528  1.530 -0.002 1.66e-02 3.63e+03 1.57e-02
bond pdb=" CD  GLN A  53 "
     pdb=" NE2 GLN A  53 "
  ideal  model  delta    sigma   weight residual
  1.328  1.325  0.003 2.10e-02 2.27e+03 1.44e-02
bond pdb=" C   GLN A  72 "
     pdb=" N   PHE A  73 "
  ideal  model  delta    sigma   weight residual
  1.334  1.335 -0.002 1.30e-02 5.92e+03 1.38e-02
bond pdb=" CA  ILE A  78 "
     pdb=" CB  ILE A  78 "
  ideal  model  delta    sigma   weight residual
  1.538  1.540 -0.001 1.24e-02 6.50e+03 1.34e-02
bond pdb=" CB  PHE A  73 "
     pdb=" CG  PHE A  73 "
  ideal  model  delta    sigma   weight residual
  1.502  1.505 -0.003 2.30e-02 1.89e+03 1.32e-02
bond pdb=" C   PRO A  58 "
     pdb=" N   GLY A  59 "
  ideal  model  delta    sigma   weight residual
  1.323  1.322  0.002 1.53e-02 4.27e+03 1.24e-02
bond pdb=" CB  LYS A  46 "
     pdb=" CG  LYS A  46 "
  ideal  model  delta    sigma   weight residual
  1.520  1.517  0.003 3.00e-02 1.11e+03 1.21e-02
bond pdb=" CA  ILE A   2 "
     pdb=" CB  ILE A   2 "
  ideal  model  delta    sigma   weight residual
  1.540  1.537  0.003 2.70e-02 1.37e+03 1.18e-02
bond pdb=" C   VAL A   4 "
     pdb=" N   GLU A   5 "
  ideal  model  delta    sigma   weight residual
  1.331  1.329  0.002 1.55e-02 4.16e+03 1.15e-02
bond pdb=" CA  SER A  27 "
     pdb=" CB  SER A  27 "
  ideal  model  delta    sigma   weight residual
  1.534  1.536 -0.002 1.72e-02 3.38e+03 1.14e-02
bond pdb=" CA  VAL A  84 "
     pdb=" CB  VAL A  84 "
  ideal  model  delta    sigma   weight residual
  1.537  1.539 -0.001 1.29e-02 6.01e+03 1.11e-02
bond pdb=" CG  LEU A  76 "
     pdb=" CD2 LEU A  76 "
  ideal  model  delta    sigma   weight residual
  1.521  1.518  0.003 3.30e-02 9.18e+02 1.10e-02
bond pdb=" CB  LEU A  32 "
     pdb=" CG  LEU A  32 "
  ideal  model  delta    sigma   weight residual
  1.530  1.528  0.002 2.00e-02 2.50e+03 1.09e-02
bond pdb=" C   GLY A  59 "
     pdb=" N   LEU A  60 "
  ideal  model  delta    sigma   weight residual
  1.330  1.328  0.001 1.32e-02 5.74e+03 1.07e-02
bond pdb=" N   PRO A  85 "
     pdb=" CD  PRO A  85 "
  ideal  model  delta    sigma   weight residual
  1.473  1.474 -0.001 1.40e-02 5.10e+03 1.03e-02
bond pdb=" CD  ARG A  80 "
     pdb=" NE  ARG A  80 "
  ideal  model  delta    sigma   weight residual
  1.458  1.457  0.001 1.40e-02 5.10e+03 1.01e-02
bond pdb=" CD  LYS A  46 "
     pdb=" CE  LYS A  46 "
  ideal  model  delta    sigma   weight residual
  1.520  1.517  0.003 3.00e-02 1.11e+03 9.83e-03
bond pdb=" CB  VAL A  70 "
     pdb=" CG2 VAL A  70 "
  ideal  model  delta    sigma   weight residual
  1.521  1.518  0.003 3.30e-02 9.18e+02 9.03e-03
bond pdb=" CG  LEU A  65 "
     pdb=" CD1 LEU A  65 "
  ideal  model  delta    sigma   weight residual
  1.521  1.518  0.003 3.30e-02 9.18e+02 8.90e-03
bond pdb=" CB  THR A  14 "
     pdb=" CG2 THR A  14 "
  ideal  model  delta    sigma   weight residual
  1.521  1.524 -0.003 3.30e-02 9.18e+02 8.90e-03
bond pdb=" CB  VAL A  35 "
     pdb=" CG2 VAL A  35 "
  ideal  model  delta    sigma   weight residual
  1.521  1.518  0.003 3.30e-02 9.18e+02 8.67e-03
bond pdb=" CG  GLN A  31 "
     pdb=" CD  GLN A  31 "
  ideal  model  delta    sigma   weight residual
  1.516  1.518 -0.002 2.50e-02 1.60e+03 8.37e-03
bond pdb=" C   GLN A  31 "
     pdb=" N   LEU A  32 "
  ideal  model  delta    sigma   weight residual
  1.328  1.329 -0.001 1.37e-02 5.33e+03 7.56e-03
bond pdb=" N   PRO A   8 "
     pdb=" CA  PRO A   8 "
  ideal  model  delta    sigma   weight residual
  1.471  1.470  0.001 1.32e-02 5.74e+03 7.30e-03
bond pdb=" CG  LEU A  76 "
     pdb=" CD1 LEU A  76 "
  ideal  model  delta    sigma   weight residual
  1.521  1.518  0.003 3.30e-02 9.18e+02 6.62e-03
bond pdb=" CG  ARG A  16 "
     pdb=" CD  ARG A  16 "
  ideal  model  delta    sigma   weight residual
  1.520  1.518  0.002 3.00e-02 1.11e+03 6.52e-03
bond pdb=" CG1 ILE A  47 "
     pdb=" CD1 ILE A  47 "
  ideal  model  delta    sigma   weight residual
  1.513  1.510  0.003 3.90e-02 6.57e+02 6.44e-03
bond pdb=" C   ILE A   2 "
     pdb=" N   LYS A   3 "
  ideal  model  delta    sigma   weight residual
  1.330  1.329  0.001 1.39e-02 5.18e+03 6.22e-03
bond pdb=" CD  GLN A  53 "
     pdb=" OE1 GLN A  53 "
  ideal  model  delta    sigma   weight residual
  1.231  1.230  0.001 1.90e-02 2.77e+03 5.89e-03
bond pdb=" N   PHE A  68 "
     pdb=" CA  PHE A  68 "
  ideal  model  delta    sigma   weight residual
  1.455  1.454  0.001 1.21e-02 6.83e+03 5.73e-03
bond pdb=" CD2 TYR A  41 "
     pdb=" CE2 TYR A  41 "
  ideal  model  delta    sigma   weight residual
  1.382  1.380  0.002 3.00e-02 1.11e+03 5.33e-03
bond pdb=" CB  SER A  75 "
     pdb=" OG  SER A  75 "
  ideal  model  delta    sigma   weight residual
  1.417  1.416  0.001 2.00e-02 2.50e+03 4.92e-03
bond pdb=" C   LYS A   3 "
     pdb=" N   VAL A   4 "
  ideal  model  delta    sigma   weight residual
  1.331  1.330  0.001 1.43e-02 4.89e+03 4.81e-03
bond pdb=" CE2 PHE A  73 "
     pdb=" CZ  PHE A  73 "
  ideal  model  delta    sigma   weight residual
  1.382  1.380  0.002 3.00e-02 1.11e+03 4.65e-03
bond pdb=" CG  GLU A  40 "
     pdb=" CD  GLU A  40 "
  ideal  model  delta    sigma   weight residual
  1.516  1.518 -0.002 2.50e-02 1.60e+03 4.54e-03
bond pdb=" CB  VAL A  84 "
     pdb=" CG1 VAL A  84 "
  ideal  model  delta    sigma   weight residual
  1.521  1.519  0.002 3.30e-02 9.18e+02 3.95e-03
bond pdb=" C   LEU A  83 "
     pdb=" N   VAL A  84 "
  ideal  model  delta    sigma   weight residual
  1.329  1.330 -0.001 1.13e-02 7.83e+03 3.67e-03
bond pdb=" CB  ILE A   6 "
     pdb=" CG1 ILE A   6 "
  ideal  model  delta    sigma   weight residual
  1.530  1.529  0.001 2.00e-02 2.50e+03 3.62e-03
bond pdb=" N   ALA A  55 "
     pdb=" CA  ALA A  55 "
  ideal  model  delta    sigma   weight residual
  1.456  1.456 -0.001 1.22e-02 6.72e+03 3.42e-03
bond pdb=" N   PHE A  73 "
     pdb=" CA  PHE A  73 "
  ideal  model  delta    sigma   weight residual
  1.457  1.458 -0.001 1.16e-02 7.43e+03 3.12e-03
bond pdb=" CA  VAL A  63 "
     pdb=" CB  VAL A  63 "
  ideal  model  delta    sigma   weight residual
  1.538  1.537  0.001 1.24e-02 6.50e+03 3.07e-03
bond pdb=" CA  THR A  15 "
     pdb=" CB  THR A  15 "
  ideal  model  delta    sigma   weight residual
  1.533  1.532  0.001 1.90e-02 2.77e+03 2.70e-03
bond pdb=" CA  PRO A  85 "
     pdb=" C   PRO A  85 "
  ideal  model  delta    sigma   weight residual
  1.525  1.524  0.001 2.10e-02 2.27e+03 2.62e-03
bond pdb=" C   PRO A  42 "
     pdb=" O   PRO A  42 "
  ideal  model  delta    sigma   weight residual
  1.233  1.234 -0.001 1.19e-02 7.06e+03 2.57e-03
bond pdb=" C   ARG A  80 "
     pdb=" N   LEU A  81 "
  ideal  model  delta    sigma   weight residual
  1.332  1.332  0.001 1.40e-02 5.10e+03 2.31e-03
bond pdb=" CA  ARG A  16 "
     pdb=" CB  ARG A  16 "
  ideal  model  delta    sigma   weight residual
  1.532  1.531  0.001 1.74e-02 3.30e+03 2.21e-03
bond pdb=" N   VAL A  35 "
     pdb=" CA  VAL A  35 "
  ideal  model  delta    sigma   weight residual
  1.459  1.459 -0.001 1.20e-02 6.94e+03 2.12e-03
bond pdb=" N   LEU A  37 "
     pdb=" CA  LEU A  37 "
  ideal  model  delta    sigma   weight residual
  1.457  1.458 -0.001 1.16e-02 7.43e+03 1.89e-03
bond pdb=" N   VAL A  84 "
     pdb=" CA  VAL A  84 "
  ideal  model  delta    sigma   weight residual
  1.461  1.462 -0.001 1.23e-02 6.61e+03 1.80e-03
bond pdb=" NE  ARG A  80 "
     pdb=" CZ  ARG A  80 "
  ideal  model  delta    sigma   weight residual
  1.326  1.326  0.000 1.10e-02 8.26e+03 1.61e-03
bond pdb=" C   GLN A  72 "
     pdb=" O   GLN A  72 "
  ideal  model  delta    sigma   weight residual
  1.235  1.236 -0.001 1.33e-02 5.65e+03 1.50e-03
bond pdb=" CB  VAL A  43 "
     pdb=" CG2 VAL A  43 "
  ideal  model  delta    sigma   weight residual
  1.521  1.522 -0.001 3.30e-02 9.18e+02 1.38e-03
bond pdb=" CA  SER A  67 "
     pdb=" C   SER A  67 "
  ideal  model  delta    sigma   weight residual
  1.522  1.522  0.001 1.40e-02 5.10e+03 1.32e-03
bond pdb=" CG  PHE A  73 "
     pdb=" CD1 PHE A  73 "
  ideal  model  delta    sigma   weight residual
  1.384  1.383  0.001 2.10e-02 2.27e+03 1.30e-03
bond pdb=" CA  LEU A  28 "
     pdb=" C   LEU A  28 "
  ideal  model  delta    sigma   weight residual
  1.522  1.521  0.000 1.22e-02 6.72e+03 1.22e-03
bond pdb=" CE1 TYR A  34 "
     pdb=" CZ  TYR A  34 "
  ideal  model  delta    sigma   weight residual
  1.378  1.377  0.001 2.40e-02 1.74e+03 1.21e-03
bond pdb=" CD  ARG A  16 "
     pdb=" NE  ARG A  16 "
  ideal  model  delta    sigma   weight residual
  1.458  1.458  0.000 1.40e-02 5.10e+03 1.11e-03
bond pdb=" C   PHE A  68 "
     pdb=" N   LYS A  69 "
  ideal  model  delta    sigma   weight residual
  1.331  1.330  0.000 1.38e-02 5.25e+03 1.05e-03
bond pdb=" CB  ILE A   2 "
     pdb=" CG2 ILE A   2 "
  ideal  model  delta    sigma   weight residual
  1.521  1.522 -0.001 3.30e-02 9.18e+02 1.05e-03
bond pdb=" CE1 TYR A  26 "
     pdb=" CZ  TYR A  26 "
  ideal  model  delta    sigma   weight residual
  1.378  1.377  0.001 2.40e-02 1.74e+03 8.96e-04
bond pdb=" CB  ILE A  78 "
     pdb=" CG2 ILE A  78 "
  ideal  model  delta    sigma   weight residual
  1.521  1.520  0.001 3.30e-02 9.18e+02 8.58e-04
bond pdb=" CD1 PHE A  73 "
     pdb=" CE1 PHE A  73 "
  ideal  model  delta    sigma   weight residual
  1.382  1.383 -0.001 3.00e-02 1.11e+03 6.69e-04
bond pdb=" N   SER A  66 "
     pdb=" CA  SER A  66 "
  ideal  model  delta    sigma   weight residual
  1.457  1.457  0.000 1.35e-02 5.49e+03 5.54e-04
bond pdb=" C   PRO A  42 "
     pdb=" N   VAL A  43 "
  ideal  model  delta    sigma   weight residual
  1.329  1.330 -0.000 2.31e-02 1.87e+03 4.25e-04
bond pdb=" CG  LEU A  83 "
     pdb=" CD2 LEU A  83 "
  ideal  model  delta    sigma   weight residual
  1.521  1.522 -0.001 3.30e-02 9.18e+02 3.84e-04
bond pdb=" CD  GLU A  40 "
     pdb=" OE1 GLU A  40 "
  ideal  model  delta    sigma   weight residual
  1.249  1.249  0.000 1.90e-02 2.77e+03 3.30e-04
bond pdb=" CB  PRO A  42 "
     pdb=" CG  PRO A  42 "
  ideal  model  delta    sigma   weight residual
  1.492  1.491  0.001 5.00e-02 4.00e+02 1.83e-04
bond pdb=" CE1 PHE A  73 "
     pdb=" CZ  PHE A  73 "
  ideal  model  delta    sigma   weight residual
  1.382  1.382 -0.000 3.00e-02 1.11e+03 1.73e-04
bond pdb=" CG  LEU A  44 "
     pdb=" CD1 LEU A  44 "
  ideal  model  delta    sigma   weight residual
  1.521  1.521 -0.000 3.30e-02 9.18e+02 1.33e-04
bond pdb=" CB  ILE A  47 "
     pdb=" CG2 ILE A  47 "
  ideal  model  delta    sigma   weight residual
  1.521  1.521 -0.000 3.30e-02 9.18e+02 1.10e-04
bond pdb=" CA  PRO A  42 "
     pdb=" CB  PRO A  42 "
  ideal  model  delta    sigma   weight residual
  1.532  1.533 -0.000 1.39e-02 5.18e+03 8.26e-05
bond pdb=" CA  TYR A  34 "
     pdb=" C   TYR A  34 "
  ideal  model  delta    sigma   weight residual
  1.522  1.522 -0.000 1.20e-02 6.94e+03 6.46e-05
bond pdb=" CA  GLY A  71 "
     pdb=" C   GLY A  71 "
  ideal  model  delta    sigma   weight residual
  1.514  1.514  0.000 1.41e-02 5.03e+03 6.40e-05
bond pdb=" CE  LYS A  46 "
     pdb=" NZ  LYS A  46 "
  ideal  model  delta    sigma   weight residual
  1.489  1.489  0.000 3.00e-02 1.11e+03 3.82e-05
bond pdb=" C   ARG A  16 "
     pdb=" O   ARG A  16 "
  ideal  model  delta    sigma   weight residual
  1.235  1.235  0.000 1.23e-02 6.61e+03 2.12e-05
bond pdb=" CB  ILE A   6 "
     pdb=" CG2 ILE A   6 "
  ideal  model  delta    sigma   weight residual
  1.521  1.521 -0.000 3.30e-02 9.18e+02 8.34e-06

Bond angle | covalent geometry | restraints: 832
Sorted by residual:
angle pdb=" C   MSE A  77 "
      pdb=" CA  MSE A  77 "
      pdb=" CB  MSE A  77 "
    ideal   model   delta    sigma   weight residual
   109.79   97.93   11.86 2.05e+00 2.38e-01 3.35e+01
angle pdb=" N   GLY A  59 "
      pdb=" CA  GLY A  59 "
      pdb=" C   GLY A  59 "
    ideal   model   delta    sigma   weight residual
   110.38  117.22   -6.84 1.28e+00 6.10e-01 2.86e+01
angle pdb=" N   GLY A  38 "
      pdb=" CA  GLY A  38 "
      pdb=" C   GLY A  38 "
    ideal   model   delta    sigma   weight residual
   115.36  121.78   -6.42 1.33e+00 5.65e-01 2.33e+01
angle pdb=" N   PHE A  68 "
      pdb=" CA  PHE A  68 "
      pdb=" C   PHE A  68 "
    ideal   model   delta    sigma   weight residual
   109.59  117.04   -7.45 1.61e+00 3.86e-01 2.14e+01
angle pdb=" C   CYS A  33 "
      pdb=" N   TYR A  34 "
      pdb=" CA  TYR A  34 "
    ideal   model   delta    sigma   weight residual
   123.00  116.89    6.11 1.38e+00 5.25e-01 1.96e+01
angle pdb=" N   GLU A  30 "
      pdb=" CA  GLU A  30 "
      pdb=" C   GLU A  30 "
    ideal   model   delta    sigma   weight residual
   109.40  115.76   -6.36 1.63e+00 3.76e-01 1.52e+01
angle pdb=" N   VAL A  63 "
      pdb=" CA  VAL A  63 "
      pdb=" C   VAL A  63 "
    ideal   model   delta    sigma   weight residual
   108.58  114.19   -5.61 1.44e+00 4.82e-01 1.52e+01
angle pdb=" C   GLN A  53 "
      pdb=" CA  GLN A  53 "
      pdb=" CB  GLN A  53 "
    ideal   model   delta    sigma   weight residual
   109.31  114.09   -4.78 1.23e+00 6.61e-01 1.51e+01
angle pdb=" N   LEU A  65 "
      pdb=" CA  LEU A  65 "
      pdb=" C   LEU A  65 "
    ideal   model   delta    sigma   weight residual
   111.71  116.13   -4.42 1.15e+00 7.56e-01 1.48e+01
angle pdb=" N   ASN A  39 "
      pdb=" CA  ASN A  39 "
      pdb=" C   ASN A  39 "
    ideal   model   delta    sigma   weight residual
   109.31  114.65   -5.34 1.42e+00 4.96e-01 1.41e+01
angle pdb=" N   LEU A  83 "
      pdb=" CA  LEU A  83 "
      pdb=" C   LEU A  83 "
    ideal   model   delta    sigma   weight residual
   109.95  115.41   -5.46 1.59e+00 3.96e-01 1.18e+01
angle pdb=" N   LYS A  46 "
      pdb=" CA  LYS A  46 "
      pdb=" C   LYS A  46 "
    ideal   model   delta    sigma   weight residual
   109.24  114.77   -5.53 1.63e+00 3.76e-01 1.15e+01
angle pdb=" CB  MSE A  77 "
      pdb=" CG  MSE A  77 "
      pdb="SE   MSE A  77 "
    ideal   model   delta    sigma   weight residual
   112.70  102.71    9.99 3.00e+00 1.11e-01 1.11e+01
angle pdb=" N   LEU A  60 "
      pdb=" CA  LEU A  60 "
      pdb=" C   LEU A  60 "
    ideal   model   delta    sigma   weight residual
   109.07  114.17   -5.10 1.61e+00 3.86e-01 1.00e+01
angle pdb=" CG1 ILE A   2 "
      pdb=" CB  ILE A   2 "
      pdb=" CG2 ILE A   2 "
    ideal   model   delta    sigma   weight residual
   110.70  101.31    9.39 3.00e+00 1.11e-01 9.79e+00
angle pdb=" C   TYR A  34 "
      pdb=" N   VAL A  35 "
      pdb=" CA  VAL A  35 "
    ideal   model   delta    sigma   weight residual
   123.19  119.52    3.67 1.24e+00 6.50e-01 8.78e+00
angle pdb=" C   ARG A  82 "
      pdb=" CA  ARG A  82 "
      pdb=" CB  ARG A  82 "
    ideal   model   delta    sigma   weight residual
   109.72  114.84   -5.12 1.73e+00 3.34e-01 8.75e+00
angle pdb=" CA  GLY A  52 "
      pdb=" C   GLY A  52 "
      pdb=" N   GLN A  53 "
    ideal   model   delta    sigma   weight residual
   118.48  115.04    3.44 1.17e+00 7.31e-01 8.65e+00
angle pdb=" N   GLU A  51 "
      pdb=" CA  GLU A  51 "
      pdb=" C   GLU A  51 "
    ideal   model   delta    sigma   weight residual
   109.76  114.36   -4.60 1.59e+00 3.96e-01 8.35e+00
angle pdb=" N   ASP A  36 "
      pdb=" CA  ASP A  36 "
      pdb=" C   ASP A  36 "
    ideal   model   delta    sigma   weight residual
   108.67  113.15   -4.48 1.55e+00 4.16e-01 8.34e+00
angle pdb=" O   VAL A  35 "
      pdb=" C   VAL A  35 "
      pdb=" N   ASP A  36 "
    ideal   model   delta    sigma   weight residual
   123.18  120.18    3.00 1.05e+00 9.07e-01 8.16e+00
angle pdb=" C   PRO A  54 "
      pdb=" N   ALA A  55 "
      pdb=" CA  ALA A  55 "
    ideal   model   delta    sigma   weight residual
   120.87  116.89    3.98 1.42e+00 4.96e-01 7.87e+00
angle pdb=" N   TYR A  61 "
      pdb=" CA  TYR A  61 "
      pdb=" C   TYR A  61 "
    ideal   model   delta    sigma   weight residual
   109.14  113.23   -4.09 1.49e+00 4.50e-01 7.53e+00
angle pdb=" N   MSE A  77 "
      pdb=" CA  MSE A  77 "
      pdb=" CB  MSE A  77 "
    ideal   model   delta    sigma   weight residual
   111.55  106.89    4.66 1.74e+00 3.30e-01 7.18e+00
angle pdb=" N   TYR A  26 "
      pdb=" CA  TYR A  26 "
      pdb=" C   TYR A  26 "
    ideal   model   delta    sigma   weight residual
   111.00  118.42   -7.42 2.80e+00 1.28e-01 7.02e+00
angle pdb=" C   ASN A  39 "
      pdb=" CA  ASN A  39 "
      pdb=" CB  ASN A  39 "
    ideal   model   delta    sigma   weight residual
   114.16  108.14    6.02 2.31e+00 1.87e-01 6.80e+00
angle pdb=" N   TYR A  34 "
      pdb=" CA  TYR A  34 "
      pdb=" C   TYR A  34 "
    ideal   model   delta    sigma   weight residual
   109.07  113.25   -4.18 1.61e+00 3.86e-01 6.74e+00
angle pdb=" N   VAL A  43 "
      pdb=" CA  VAL A  43 "
      pdb=" C   VAL A  43 "
    ideal   model   delta    sigma   weight residual
   108.97  112.96   -3.99 1.55e+00 4.16e-01 6.61e+00
angle pdb=" N   PRO A  58 "
      pdb=" CA  PRO A  58 "
      pdb=" C   PRO A  58 "
    ideal   model   delta    sigma   weight residual
   111.15  115.18   -4.03 1.58e+00 4.01e-01 6.50e+00
angle pdb=" CA  MSE A  77 "
      pdb=" C   MSE A  77 "
      pdb=" N   ILE A  78 "
    ideal   model   delta    sigma   weight residual
   115.34  119.31   -3.97 1.56e+00 4.11e-01 6.49e+00
angle pdb=" N   CYS A  33 "
      pdb=" CA  CYS A  33 "
      pdb=" C   CYS A  33 "
    ideal   model   delta    sigma   weight residual
   108.14  111.95   -3.81 1.52e+00 4.33e-01 6.30e+00
angle pdb=" N   LEU A  76 "
      pdb=" CA  LEU A  76 "
      pdb=" C   LEU A  76 "
    ideal   model   delta    sigma   weight residual
   109.96  113.69   -3.73 1.50e+00 4.44e-01 6.17e+00
angle pdb=" C   CYS A  33 "
      pdb=" CA  CYS A  33 "
      pdb=" CB  CYS A  33 "
    ideal   model   delta    sigma   weight residual
   110.95  106.50    4.45 1.80e+00 3.09e-01 6.11e+00
angle pdb=" N   ALA A  11 "
      pdb=" CA  ALA A  11 "
      pdb=" C   ALA A  11 "
    ideal   model   delta    sigma   weight residual
   113.02  115.97   -2.95 1.20e+00 6.94e-01 6.04e+00
angle pdb=" C   GLY A  71 "
      pdb=" N   GLN A  72 "
      pdb=" CA  GLN A  72 "
    ideal   model   delta    sigma   weight residual
   122.38  117.93    4.45 1.81e+00 3.05e-01 6.04e+00
angle pdb=" CA  MSE A  77 "
      pdb=" C   MSE A  77 "
      pdb=" O   MSE A  77 "
    ideal   model   delta    sigma   weight residual
   121.44  118.58    2.86 1.17e+00 7.31e-01 5.98e+00
angle pdb=" N   SER A   9 "
      pdb=" CA  SER A   9 "
      pdb=" CB  SER A   9 "
    ideal   model   delta    sigma   weight residual
   110.41  106.31    4.10 1.68e+00 3.54e-01 5.97e+00
angle pdb=" N   SER A   9 "
      pdb=" CA  SER A   9 "
      pdb=" C   SER A   9 "
    ideal   model   delta    sigma   weight residual
   113.18  116.12   -2.94 1.21e+00 6.83e-01 5.92e+00
angle pdb=" CA  TYR A  61 "
      pdb=" CB  TYR A  61 "
      pdb=" CG  TYR A  61 "
    ideal   model   delta    sigma   weight residual
   113.90  118.28   -4.38 1.80e+00 3.09e-01 5.91e+00
angle pdb=" C   SER A  27 "
      pdb=" CA  SER A  27 "
      pdb=" CB  SER A  27 "
    ideal   model   delta    sigma   weight residual
   109.65  113.90   -4.25 1.75e+00 3.27e-01 5.89e+00
angle pdb=" N   GLN A  10 "
      pdb=" CA  GLN A  10 "
      pdb=" CB  GLN A  10 "
    ideal   model   delta    sigma   weight residual
   111.17  107.21    3.96 1.64e+00 3.72e-01 5.83e+00
angle pdb=" CB  ILE A   2 "
      pdb=" CG1 ILE A   2 "
      pdb=" CD1 ILE A   2 "
    ideal   model   delta    sigma   weight residual
   113.80  108.75    5.05 2.10e+00 2.27e-01 5.78e+00
angle pdb=" CA  TYR A  56 "
      pdb=" CB  TYR A  56 "
      pdb=" CG  TYR A  56 "
    ideal   model   delta    sigma   weight residual
   113.90  118.20   -4.30 1.80e+00 3.09e-01 5.70e+00
angle pdb=" C   PHE A  13 "
      pdb=" N   THR A  14 "
      pdb=" CA  THR A  14 "
    ideal   model   delta    sigma   weight residual
   123.03  118.79    4.24 1.79e+00 3.12e-01 5.60e+00
angle pdb=" C   TYR A  61 "
      pdb=" N   THR A  62 "
      pdb=" CA  THR A  62 "
    ideal   model   delta    sigma   weight residual
   123.01  118.81    4.20 1.78e+00 3.16e-01 5.55e+00
angle pdb=" N   SER A  67 "
      pdb=" CA  SER A  67 "
      pdb=" CB  SER A  67 "
    ideal   model   delta    sigma   weight residual
   110.39  106.50    3.89 1.66e+00 3.63e-01 5.50e+00
angle pdb=" N   GLY A  52 "
      pdb=" CA  GLY A  52 "
      pdb=" C   GLY A  52 "
    ideal   model   delta    sigma   weight residual
   115.32  112.14    3.18 1.38e+00 5.25e-01 5.30e+00
angle pdb=" CB  GLU A  51 "
      pdb=" CG  GLU A  51 "
      pdb=" CD  GLU A  51 "
    ideal   model   delta    sigma   weight residual
   112.60  116.51   -3.91 1.70e+00 3.46e-01 5.29e+00
angle pdb=" C   LYS A   7 "
      pdb=" N   PRO A   8 "
      pdb=" CA  PRO A   8 "
    ideal   model   delta    sigma   weight residual
   119.47  122.13   -2.66 1.16e+00 7.43e-01 5.27e+00
angle pdb=" N   LYS A   3 "
      pdb=" CA  LYS A   3 "
      pdb=" C   LYS A   3 "
    ideal   model   delta    sigma   weight residual
   109.24  112.91   -3.67 1.63e+00 3.76e-01 5.07e+00
angle pdb=" N   SER A  75 "
      pdb=" CA  SER A  75 "
      pdb=" C   SER A  75 "
    ideal   model   delta    sigma   weight residual
   110.52  113.85   -3.33 1.48e+00 4.57e-01 5.06e+00
angle pdb=" C   LEU A  28 "
      pdb=" N   ASN A  29 "
      pdb=" CA  ASN A  29 "
    ideal   model   delta    sigma   weight residual
   123.00  119.91    3.09 1.38e+00 5.25e-01 5.00e+00
angle pdb=" N   THR A  14 "
      pdb=" CA  THR A  14 "
      pdb=" C   THR A  14 "
    ideal   model   delta    sigma   weight residual
   109.81  106.45    3.36 1.53e+00 4.27e-01 4.83e+00
angle pdb=" C   THR A  14 "
      pdb=" N   THR A  15 "
      pdb=" CA  THR A  15 "
    ideal   model   delta    sigma   weight residual
   122.74  119.37    3.37 1.54e+00 4.22e-01 4.78e+00
angle pdb=" N   LEU A  32 "
      pdb=" CA  LEU A  32 "
      pdb=" C   LEU A  32 "
    ideal   model   delta    sigma   weight residual
   110.14  113.31   -3.17 1.47e+00 4.63e-01 4.65e+00
angle pdb=" N   HIS A  64 "
      pdb=" CA  HIS A  64 "
      pdb=" C   HIS A  64 "
    ideal   model   delta    sigma   weight residual
   110.32  113.75   -3.43 1.59e+00 3.96e-01 4.65e+00
angle pdb=" CA  PRO A  54 "
      pdb=" C   PRO A  54 "
      pdb=" N   ALA A  55 "
    ideal   model   delta    sigma   weight residual
   114.75  117.87   -3.12 1.45e+00 4.76e-01 4.62e+00
angle pdb=" CA  GLU A  40 "
      pdb=" C   GLU A  40 "
      pdb=" N   TYR A  41 "
    ideal   model   delta    sigma   weight residual
   117.30  114.85    2.45 1.16e+00 7.43e-01 4.45e+00
angle pdb=" N   ILE A  47 "
      pdb=" CA  ILE A  47 "
      pdb=" C   ILE A  47 "
    ideal   model   delta    sigma   weight residual
   108.53  111.57   -3.04 1.45e+00 4.76e-01 4.39e+00
angle pdb=" CA  GLY A  52 "
      pdb=" C   GLY A  52 "
      pdb=" O   GLY A  52 "
    ideal   model   delta    sigma   weight residual
   119.06  121.40   -2.34 1.12e+00 7.97e-01 4.38e+00
angle pdb=" N   SER A  27 "
      pdb=" CA  SER A  27 "
      pdb=" C   SER A  27 "
    ideal   model   delta    sigma   weight residual
   108.69  105.00    3.69 1.77e+00 3.19e-01 4.35e+00
angle pdb=" CA  GLN A  31 "
      pdb=" CB  GLN A  31 "
      pdb=" CG  GLN A  31 "
    ideal   model   delta    sigma   weight residual
   114.10  118.20   -4.10 2.00e+00 2.50e-01 4.20e+00
angle pdb=" C   TYR A  61 "
      pdb=" CA  TYR A  61 "
      pdb=" CB  TYR A  61 "
    ideal   model   delta    sigma   weight residual
   110.67  106.15    4.52 2.23e+00 2.01e-01 4.10e+00
angle pdb=" N   GLU A  51 "
      pdb=" CA  GLU A  51 "
      pdb=" CB  GLU A  51 "
    ideal   model   delta    sigma   weight residual
   109.95  106.85    3.10 1.55e+00 4.16e-01 3.99e+00
angle pdb=" C   ILE A  78 "
      pdb=" CA  ILE A  78 "
      pdb=" CB  ILE A  78 "
    ideal   model   delta    sigma   weight residual
   110.91  108.45    2.46 1.24e+00 6.50e-01 3.95e+00
angle pdb=" O   GLU A  40 "
      pdb=" C   GLU A  40 "
      pdb=" N   TYR A  41 "
    ideal   model   delta    sigma   weight residual
   122.12  124.21   -2.09 1.06e+00 8.90e-01 3.90e+00
angle pdb=" O   VAL A  84 "
      pdb=" C   VAL A  84 "
      pdb=" N   PRO A  85 "
    ideal   model   delta    sigma   weight residual
   121.10  123.33   -2.23 1.14e+00 7.69e-01 3.82e+00
angle pdb=" CA  CYS A  33 "
      pdb=" CB  CYS A  33 "
      pdb=" SG  CYS A  33 "
    ideal   model   delta    sigma   weight residual
   114.40  118.87   -4.47 2.30e+00 1.89e-01 3.78e+00
angle pdb=" CA  PRO A  54 "
      pdb=" C   PRO A  54 "
      pdb=" O   PRO A  54 "
    ideal   model   delta    sigma   weight residual
   122.31  119.59    2.72 1.41e+00 5.03e-01 3.73e+00
angle pdb=" C   ARG A  16 "
      pdb=" CA  ARG A  16 "
      pdb=" CB  ARG A  16 "
    ideal   model   delta    sigma   weight residual
   109.38  112.84   -3.46 1.80e+00 3.09e-01 3.69e+00
angle pdb=" N   VAL A  45 "
      pdb=" CA  VAL A  45 "
      pdb=" C   VAL A  45 "
    ideal   model   delta    sigma   weight residual
   108.45  111.28   -2.83 1.48e+00 4.57e-01 3.65e+00
angle pdb=" N   VAL A   4 "
      pdb=" CA  VAL A   4 "
      pdb=" C   VAL A   4 "
    ideal   model   delta    sigma   weight residual
   108.46  105.63    2.83 1.49e+00 4.50e-01 3.62e+00
angle pdb=" CA  VAL A   4 "
      pdb=" C   VAL A   4 "
      pdb=" N   GLU A   5 "
    ideal   model   delta    sigma   weight residual
   116.18  113.83    2.35 1.24e+00 6.50e-01 3.58e+00
angle pdb=" CA  VAL A  35 "
      pdb=" C   VAL A  35 "
      pdb=" N   ASP A  36 "
    ideal   model   delta    sigma   weight residual
   116.31  118.53   -2.22 1.18e+00 7.18e-01 3.53e+00
angle pdb=" O   VAL A   4 "
      pdb=" C   VAL A   4 "
      pdb=" N   GLU A   5 "
    ideal   model   delta    sigma   weight residual
   123.10  125.11   -2.01 1.07e+00 8.73e-01 3.53e+00
angle pdb=" N   GLN A  53 "
      pdb=" CA  GLN A  53 "
      pdb=" C   GLN A  53 "
    ideal   model   delta    sigma   weight residual
   109.62  112.33   -2.71 1.45e+00 4.76e-01 3.50e+00
angle pdb=" CA  LEU A  32 "
      pdb=" CB  LEU A  32 "
      pdb=" CG  LEU A  32 "
    ideal   model   delta    sigma   weight residual
   116.30  109.75    6.55 3.50e+00 8.16e-02 3.50e+00
angle pdb=" N   GLU A   5 "
      pdb=" CA  GLU A   5 "
      pdb=" C   GLU A   5 "
    ideal   model   delta    sigma   weight residual
   109.24  112.36   -3.12 1.67e+00 3.59e-01 3.48e+00
angle pdb=" CA  TYR A  26 "
      pdb=" CB  TYR A  26 "
      pdb=" CG  TYR A  26 "
    ideal   model   delta    sigma   weight residual
   113.90  117.22   -3.32 1.80e+00 3.09e-01 3.41e+00
angle pdb=" CA  PRO A  42 "
      pdb=" C   PRO A  42 "
      pdb=" N   VAL A  43 "
    ideal   model   delta    sigma   weight residual
   115.33  117.67   -2.34 1.28e+00 6.10e-01 3.35e+00
angle pdb=" O   THR A  48 "
      pdb=" C   THR A  48 "
      pdb=" N   LEU A  49 "
    ideal   model   delta    sigma   weight residual
   123.01  125.38   -2.37 1.30e+00 5.92e-01 3.33e+00
angle pdb=" C   ILE A   2 "
      pdb=" CA  ILE A   2 "
      pdb=" CB  ILE A   2 "
    ideal   model   delta    sigma   weight residual
   111.60  107.96    3.64 2.00e+00 2.50e-01 3.32e+00
angle pdb=" C   HIS A  64 "
      pdb=" N   LEU A  65 "
      pdb=" CA  LEU A  65 "
    ideal   model   delta    sigma   weight residual
   120.28  122.89   -2.61 1.44e+00 4.82e-01 3.28e+00
angle pdb=" CA  GLN A  53 "
      pdb=" C   GLN A  53 "
      pdb=" N   PRO A  54 "
    ideal   model   delta    sigma   weight residual
   118.75  115.16    3.59 1.99e+00 2.53e-01 3.26e+00
angle pdb=" C   LEU A  49 "
      pdb=" N   ASP A  50 "
      pdb=" CA  ASP A  50 "
    ideal   model   delta    sigma   weight residual
   122.03  118.40    3.63 2.01e+00 2.48e-01 3.26e+00
angle pdb=" CA  MSE A  77 "
      pdb=" CB  MSE A  77 "
      pdb=" CG  MSE A  77 "
    ideal   model   delta    sigma   weight residual
   114.10  117.67   -3.57 2.00e+00 2.50e-01 3.19e+00
angle pdb=" C   PRO A  42 "
      pdb=" N   VAL A  43 "
      pdb=" CA  VAL A  43 "
    ideal   model   delta    sigma   weight residual
   122.64  119.81    2.83 1.61e+00 3.86e-01 3.09e+00
angle pdb=" CA  PRO A  42 "
      pdb=" C   PRO A  42 "
      pdb=" O   PRO A  42 "
    ideal   model   delta    sigma   weight residual
   121.56  119.53    2.03 1.16e+00 7.43e-01 3.07e+00
angle pdb=" C   ARG A  82 "
      pdb=" N   LEU A  83 "
      pdb=" CA  LEU A  83 "
    ideal   model   delta    sigma   weight residual
   122.87  120.11    2.76 1.61e+00 3.86e-01 2.94e+00
angle pdb=" CA  PRO A  85 "
      pdb=" C   PRO A  85 "
      pdb=" O   PRO A  85 "
    ideal   model   delta    sigma   weight residual
   119.00  113.88    5.12 3.00e+00 1.11e-01 2.91e+00
angle pdb=" C   VAL A  35 "
      pdb=" N   ASP A  36 "
      pdb=" CA  ASP A  36 "
    ideal   model   delta    sigma   weight residual
   121.99  119.45    2.54 1.49e+00 4.50e-01 2.91e+00
angle pdb=" N   ILE A  78 "
      pdb=" CA  ILE A  78 "
      pdb=" C   ILE A  78 "
    ideal   model   delta    sigma   weight residual
   108.58  111.03   -2.45 1.44e+00 4.82e-01 2.90e+00
angle pdb=" N   GLU A  40 "
      pdb=" CA  GLU A  40 "
      pdb=" C   GLU A  40 "
    ideal   model   delta    sigma   weight residual
   111.28  109.45    1.83 1.09e+00 8.42e-01 2.81e+00
angle pdb=" N   GLN A  12 "
      pdb=" CA  GLN A  12 "
      pdb=" CB  GLN A  12 "
    ideal   model   delta    sigma   weight residual
   111.20  108.49    2.71 1.62e+00 3.81e-01 2.80e+00
angle pdb=" N   HIS A  64 "
      pdb=" CA  HIS A  64 "
      pdb=" CB  HIS A  64 "
    ideal   model   delta    sigma   weight residual
   110.41  107.74    2.67 1.63e+00 3.76e-01 2.68e+00
angle pdb=" C   PRO A   8 "
      pdb=" N   SER A   9 "
      pdb=" CA  SER A   9 "
    ideal   model   delta    sigma   weight residual
   121.58  124.75   -3.17 1.95e+00 2.63e-01 2.65e+00
angle pdb=" C   ASN A  39 "
      pdb=" N   GLU A  40 "
      pdb=" CA  GLU A  40 "
    ideal   model   delta    sigma   weight residual
   120.28  122.46   -2.18 1.34e+00 5.57e-01 2.64e+00
angle pdb=" CA  LEU A  32 "
      pdb=" C   LEU A  32 "
      pdb=" O   LEU A  32 "
    ideal   model   delta    sigma   weight residual
   121.78  119.70    2.08 1.28e+00 6.10e-01 2.63e+00
angle pdb=" CA  GLN A  53 "
      pdb=" CB  GLN A  53 "
      pdb=" CG  GLN A  53 "
    ideal   model   delta    sigma   weight residual
   114.10  117.34   -3.24 2.00e+00 2.50e-01 2.63e+00
angle pdb=" CA  LEU A  60 "
      pdb=" C   LEU A  60 "
      pdb=" O   LEU A  60 "
    ideal   model   delta    sigma   weight residual
   120.38  122.14   -1.76 1.09e+00 8.42e-01 2.62e+00
angle pdb=" C   LEU A  60 "
      pdb=" N   TYR A  61 "
      pdb=" CA  TYR A  61 "
    ideal   model   delta    sigma   weight residual
   122.36  119.78    2.58 1.60e+00 3.91e-01 2.61e+00
angle pdb=" CA  GLY A  38 "
      pdb=" C   GLY A  38 "
      pdb=" N   ASN A  39 "
    ideal   model   delta    sigma   weight residual
   118.55  116.59    1.96 1.22e+00 6.72e-01 2.58e+00
angle pdb=" N   GLN A  12 "
      pdb=" CA  GLN A  12 "
      pdb=" C   GLN A  12 "
    ideal   model   delta    sigma   weight residual
   109.85  112.38   -2.53 1.58e+00 4.01e-01 2.56e+00
angle pdb=" CA  ALA A  57 "
      pdb=" C   ALA A  57 "
      pdb=" N   PRO A  58 "
    ideal   model   delta    sigma   weight residual
   117.48  115.64    1.84 1.15e+00 7.56e-01 2.55e+00
angle pdb=" O   ARG A  16 "
      pdb=" C   ARG A  16 "
      pdb=" N   SER A  17 "
    ideal   model   delta    sigma   weight residual
   123.21  121.19    2.02 1.27e+00 6.20e-01 2.53e+00
angle pdb=" C   THR A  62 "
      pdb=" N   VAL A  63 "
      pdb=" CA  VAL A  63 "
    ideal   model   delta    sigma   weight residual
   122.37  120.33    2.04 1.29e+00 6.01e-01 2.51e+00
angle pdb=" N   ILE A   6 "
      pdb=" CA  ILE A   6 "
      pdb=" C   ILE A   6 "
    ideal   model   delta    sigma   weight residual
   107.80  105.51    2.29 1.45e+00 4.76e-01 2.50e+00
angle pdb=" N   ALA A  11 "
      pdb=" CA  ALA A  11 "
      pdb=" CB  ALA A  11 "
    ideal   model   delta    sigma   weight residual
   110.47  108.18    2.29 1.45e+00 4.76e-01 2.49e+00
angle pdb=" C   GLN A  12 "
      pdb=" N   PHE A  13 "
      pdb=" CA  PHE A  13 "
    ideal   model   delta    sigma   weight residual
   122.81  120.18    2.63 1.68e+00 3.54e-01 2.45e+00
angle pdb=" CA  ARG A  80 "
      pdb=" C   ARG A  80 "
      pdb=" N   LEU A  81 "
    ideal   model   delta    sigma   weight residual
   116.29  118.55   -2.26 1.45e+00 4.76e-01 2.42e+00
angle pdb=" N   LEU A  49 "
      pdb=" CA  LEU A  49 "
      pdb=" C   LEU A  49 "
    ideal   model   delta    sigma   weight residual
   110.35  112.45   -2.10 1.36e+00 5.41e-01 2.37e+00
angle pdb=" C   PHE A  73 "
      pdb=" CA  PHE A  73 "
      pdb=" CB  PHE A  73 "
    ideal   model   delta    sigma   weight residual
   111.02  108.55    2.47 1.61e+00 3.86e-01 2.35e+00
angle pdb=" N   GLN A  10 "
      pdb=" CA  GLN A  10 "
      pdb=" C   GLN A  10 "
    ideal   model   delta    sigma   weight residual
   112.26  110.25    2.01 1.32e+00 5.74e-01 2.32e+00
angle pdb=" CA  HIS A  64 "
      pdb=" C   HIS A  64 "
      pdb=" N   LEU A  65 "
    ideal   model   delta    sigma   weight residual
   115.51  117.40   -1.89 1.24e+00 6.50e-01 2.32e+00
angle pdb=" N   ARG A  16 "
      pdb=" CA  ARG A  16 "
      pdb=" C   ARG A  16 "
    ideal   model   delta    sigma   weight residual
   109.59  107.14    2.45 1.61e+00 3.86e-01 2.31e+00
angle pdb=" CB  LEU A  44 "
      pdb=" CG  LEU A  44 "
      pdb=" CD2 LEU A  44 "
    ideal   model   delta    sigma   weight residual
   110.70  106.27    4.43 3.00e+00 1.11e-01 2.18e+00
angle pdb=" C   ASP A  36 "
      pdb=" CA  ASP A  36 "
      pdb=" CB  ASP A  36 "
    ideal   model   delta    sigma   weight residual
   110.77  113.22   -2.45 1.67e+00 3.59e-01 2.15e+00
angle pdb=" CA  PHE A  68 "
      pdb=" CB  PHE A  68 "
      pdb=" CG  PHE A  68 "
    ideal   model   delta    sigma   weight residual
   113.80  115.25   -1.45 1.00e+00 1.00e+00 2.12e+00
angle pdb=" C   SER A  66 "
      pdb=" N   SER A  67 "
      pdb=" CA  SER A  67 "
    ideal   model   delta    sigma   weight residual
   120.72  123.14   -2.42 1.67e+00 3.59e-01 2.10e+00
angle pdb=" C   ASN A  29 "
      pdb=" CA  ASN A  29 "
      pdb=" CB  ASN A  29 "
    ideal   model   delta    sigma   weight residual
   109.72  112.23   -2.51 1.73e+00 3.34e-01 2.10e+00
angle pdb=" CA  ILE A  78 "
      pdb=" C   ILE A  78 "
      pdb=" N   ASP A  79 "
    ideal   model   delta    sigma   weight residual
   116.31  118.04   -1.73 1.20e+00 6.94e-01 2.07e+00
angle pdb=" C   TYR A  41 "
      pdb=" N   PRO A  42 "
      pdb=" CA  PRO A  42 "
    ideal   model   delta    sigma   weight residual
   119.78  121.26   -1.48 1.03e+00 9.43e-01 2.06e+00
angle pdb=" CA  ILE A  47 "
      pdb=" CB  ILE A  47 "
      pdb=" CG2 ILE A  47 "
    ideal   model   delta    sigma   weight residual
   110.50  112.93   -2.43 1.70e+00 3.46e-01 2.05e+00
angle pdb=" CA  GLY A  38 "
      pdb=" C   GLY A  38 "
      pdb=" O   GLY A  38 "
    ideal   model   delta    sigma   weight residual
   119.02  120.59   -1.57 1.11e+00 8.12e-01 2.00e+00
angle pdb=" N   LEU A  28 "
      pdb=" CA  LEU A  28 "
      pdb=" C   LEU A  28 "
    ideal   model   delta    sigma   weight residual
   109.40  111.70   -2.30 1.63e+00 3.76e-01 1.99e+00
angle pdb=" N   PRO A  54 "
      pdb=" CA  PRO A  54 "
      pdb=" CB  PRO A  54 "
    ideal   model   delta    sigma   weight residual
   103.42  101.57    1.85 1.32e+00 5.74e-01 1.96e+00
angle pdb=" N   LEU A  65 "
      pdb=" CA  LEU A  65 "
      pdb=" CB  LEU A  65 "
    ideal   model   delta    sigma   weight residual
   110.22  108.08    2.14 1.54e+00 4.22e-01 1.93e+00
angle pdb=" N   PRO A   8 "
      pdb=" CA  PRO A   8 "
      pdb=" CB  PRO A   8 "
    ideal   model   delta    sigma   weight residual
   103.30  101.75    1.55 1.12e+00 7.97e-01 1.92e+00
angle pdb=" N   TYR A  61 "
      pdb=" CA  TYR A  61 "
      pdb=" CB  TYR A  61 "
    ideal   model   delta    sigma   weight residual
   111.62  109.39    2.23 1.62e+00 3.81e-01 1.90e+00
angle pdb=" C   THR A  48 "
      pdb=" CA  THR A  48 "
      pdb=" CB  THR A  48 "
    ideal   model   delta    sigma   weight residual
   111.22  108.86    2.36 1.72e+00 3.38e-01 1.89e+00
angle pdb=" CA  GLN A  53 "
      pdb=" C   GLN A  53 "
      pdb=" O   GLN A  53 "
    ideal   model   delta    sigma   weight residual
   119.61  121.14   -1.53 1.12e+00 7.97e-01 1.87e+00
angle pdb=" N   MSE A  77 "
      pdb=" CA  MSE A  77 "
      pdb=" C   MSE A  77 "
    ideal   model   delta    sigma   weight residual
   109.52  111.62   -2.10 1.55e+00 4.16e-01 1.84e+00
angle pdb=" C   LEU A  65 "
      pdb=" N   SER A  66 "
      pdb=" CA  SER A  66 "
    ideal   model   delta    sigma   weight residual
   120.99  123.48   -2.49 1.86e+00 2.89e-01 1.79e+00
angle pdb=" C   PHE A  73 "
      pdb=" N   GLY A  74 "
      pdb=" CA  GLY A  74 "
    ideal   model   delta    sigma   weight residual
   122.28  120.30    1.98 1.49e+00 4.50e-01 1.77e+00
angle pdb=" N   LEU A  44 "
      pdb=" CA  LEU A  44 "
      pdb=" C   LEU A  44 "
    ideal   model   delta    sigma   weight residual
   110.10  112.08   -1.98 1.49e+00 4.50e-01 1.77e+00
angle pdb=" C   VAL A  35 "
      pdb=" CA  VAL A  35 "
      pdb=" CB  VAL A  35 "
    ideal   model   delta    sigma   weight residual
   110.83  112.79   -1.96 1.49e+00 4.50e-01 1.73e+00
angle pdb=" C   VAL A  43 "
      pdb=" CA  VAL A  43 "
      pdb=" CB  VAL A  43 "
    ideal   model   delta    sigma   weight residual
   111.31  109.34    1.97 1.51e+00 4.39e-01 1.71e+00
angle pdb=" CA  SER A  66 "
      pdb=" C   SER A  66 "
      pdb=" N   SER A  67 "
    ideal   model   delta    sigma   weight residual
   118.42  116.71    1.71 1.31e+00 5.83e-01 1.70e+00
angle pdb=" CA  GLU A  40 "
      pdb=" CB  GLU A  40 "
      pdb=" CG  GLU A  40 "
    ideal   model   delta    sigma   weight residual
   114.10  116.68   -2.58 2.00e+00 2.50e-01 1.66e+00
angle pdb=" CA  SER A   9 "
      pdb=" C   SER A   9 "
      pdb=" O   SER A   9 "
    ideal   model   delta    sigma   weight residual
   119.11  120.74   -1.63 1.28e+00 6.10e-01 1.63e+00
angle pdb=" N   TYR A  41 "
      pdb=" CA  TYR A  41 "
      pdb=" C   TYR A  41 "
    ideal   model   delta    sigma   weight residual
   108.55  110.54   -1.99 1.56e+00 4.11e-01 1.62e+00
angle pdb=" N   LYS A   7 "
      pdb=" CA  LYS A   7 "
      pdb=" C   LYS A   7 "
    ideal   model   delta    sigma   weight residual
   110.39  112.29   -1.90 1.50e+00 4.44e-01 1.60e+00
angle pdb=" N   GLY A  74 "
      pdb=" CA  GLY A  74 "
      pdb=" C   GLY A  74 "
    ideal   model   delta    sigma   weight residual
   115.42  117.03   -1.61 1.27e+00 6.20e-01 1.60e+00
angle pdb=" N   TYR A  56 "
      pdb=" CA  TYR A  56 "
      pdb=" C   TYR A  56 "
    ideal   model   delta    sigma   weight residual
   110.28  108.42    1.86 1.48e+00 4.57e-01 1.58e+00
angle pdb=" CA  ILE A  47 "
      pdb=" C   ILE A  47 "
      pdb=" O   ILE A  47 "
    ideal   model   delta    sigma   weight residual
   120.72  122.14   -1.42 1.14e+00 7.69e-01 1.56e+00
angle pdb=" O   ARG A  82 "
      pdb=" C   ARG A  82 "
      pdb=" N   LEU A  83 "
    ideal   model   delta    sigma   weight residual
   123.29  121.82    1.47 1.18e+00 7.18e-01 1.56e+00
angle pdb=" O   GLN A  53 "
      pdb=" C   GLN A  53 "
      pdb=" N   PRO A  54 "
    ideal   model   delta    sigma   weight residual
   121.59  123.62   -2.03 1.64e+00 3.72e-01 1.53e+00
angle pdb=" C   GLN A  72 "
      pdb=" N   PHE A  73 "
      pdb=" CA  PHE A  73 "
    ideal   model   delta    sigma   weight residual
   122.67  120.70    1.97 1.59e+00 3.96e-01 1.53e+00
angle pdb=" O   LYS A   7 "
      pdb=" C   LYS A   7 "
      pdb=" N   PRO A   8 "
    ideal   model   delta    sigma   weight residual
   121.53  122.91   -1.38 1.12e+00 7.97e-01 1.51e+00
angle pdb=" N   LYS A   7 "
      pdb=" CA  LYS A   7 "
      pdb=" CB  LYS A   7 "
    ideal   model   delta    sigma   weight residual
   109.78  108.09    1.69 1.38e+00 5.25e-01 1.50e+00
angle pdb=" C   SER A   9 "
      pdb=" CA  SER A   9 "
      pdb=" CB  SER A   9 "
    ideal   model   delta    sigma   weight residual
   109.95  107.52    2.43 1.99e+00 2.53e-01 1.49e+00
angle pdb=" CA  THR A  15 "
      pdb=" C   THR A  15 "
      pdb=" N   ARG A  16 "
    ideal   model   delta    sigma   weight residual
   116.32  114.65    1.67 1.38e+00 5.25e-01 1.47e+00
angle pdb=" C   VAL A  43 "
      pdb=" N   LEU A  44 "
      pdb=" CA  LEU A  44 "
    ideal   model   delta    sigma   weight residual
   120.82  122.53   -1.71 1.41e+00 5.03e-01 1.47e+00
angle pdb=" N   PRO A   8 "
      pdb=" CA  PRO A   8 "
      pdb=" C   PRO A   8 "
    ideal   model   delta    sigma   weight residual
   113.81  112.05    1.76 1.45e+00 4.76e-01 1.47e+00
angle pdb=" C   GLN A  53 "
      pdb=" N   PRO A  54 "
      pdb=" CA  PRO A  54 "
    ideal   model   delta    sigma   weight residual
   120.21  121.37   -1.16 9.60e-01 1.09e+00 1.47e+00
angle pdb=" O   ALA A  55 "
      pdb=" C   ALA A  55 "
      pdb=" N   TYR A  56 "
    ideal   model   delta    sigma   weight residual
   122.89  124.37   -1.48 1.22e+00 6.72e-01 1.47e+00
angle pdb=" CA  VAL A  45 "
      pdb=" CB  VAL A  45 "
      pdb=" CG1 VAL A  45 "
    ideal   model   delta    sigma   weight residual
   110.40  112.44   -2.04 1.70e+00 3.46e-01 1.44e+00
angle pdb=" C   LYS A   7 "
      pdb=" CA  LYS A   7 "
      pdb=" CB  LYS A   7 "
    ideal   model   delta    sigma   weight residual
   109.45  111.62   -2.17 1.81e+00 3.05e-01 1.43e+00
angle pdb=" C   GLU A  51 "
      pdb=" CA  GLU A  51 "
      pdb=" CB  GLU A  51 "
    ideal   model   delta    sigma   weight residual
   109.84  111.77   -1.93 1.63e+00 3.76e-01 1.41e+00
angle pdb=" C   ALA A  11 "
      pdb=" CA  ALA A  11 "
      pdb=" CB  ALA A  11 "
    ideal   model   delta    sigma   weight residual
   110.37  108.26    2.11 1.78e+00 3.16e-01 1.41e+00
angle pdb=" N   THR A  14 "
      pdb=" CA  THR A  14 "
      pdb=" CB  THR A  14 "
    ideal   model   delta    sigma   weight residual
   111.05  112.82   -1.77 1.50e+00 4.44e-01 1.39e+00
angle pdb=" CA  ARG A  16 "
      pdb=" C   ARG A  16 "
      pdb=" N   SER A  17 "
    ideal   model   delta    sigma   weight residual
   116.02  117.69   -1.67 1.42e+00 4.96e-01 1.39e+00
angle pdb=" C   GLU A   5 "
      pdb=" CA  GLU A   5 "
      pdb=" CB  GLU A   5 "
    ideal   model   delta    sigma   weight residual
   109.35  107.04    2.31 1.98e+00 2.55e-01 1.36e+00
angle pdb=" CA  THR A  62 "
      pdb=" C   THR A  62 "
      pdb=" N   VAL A  63 "
    ideal   model   delta    sigma   weight residual
   115.71  117.56   -1.85 1.60e+00 3.91e-01 1.33e+00
angle pdb=" N   ALA A  57 "
      pdb=" CA  ALA A  57 "
      pdb=" CB  ALA A  57 "
    ideal   model   delta    sigma   weight residual
   109.78  108.19    1.59 1.38e+00 5.25e-01 1.33e+00
angle pdb=" N   ARG A  82 "
      pdb=" CA  ARG A  82 "
      pdb=" C   ARG A  82 "
    ideal   model   delta    sigma   weight residual
   109.07  107.23    1.84 1.61e+00 3.86e-01 1.31e+00
angle pdb=" CE2 TYR A  41 "
      pdb=" CZ  TYR A  41 "
      pdb=" OH  TYR A  41 "
    ideal   model   delta    sigma   weight residual
   119.90  116.47    3.43 3.00e+00 1.11e-01 1.31e+00
angle pdb=" C   GLN A  31 "
      pdb=" CA  GLN A  31 "
      pdb=" CB  GLN A  31 "
    ideal   model   delta    sigma   weight residual
   109.79  112.13   -2.34 2.05e+00 2.38e-01 1.30e+00
angle pdb=" CA  THR A  15 "
      pdb=" C   THR A  15 "
      pdb=" O   THR A  15 "
    ideal   model   delta    sigma   weight residual
   120.32  121.57   -1.25 1.11e+00 8.12e-01 1.27e+00
angle pdb=" NE  ARG A  82 "
      pdb=" CZ  ARG A  82 "
      pdb=" NH1 ARG A  82 "
    ideal   model   delta    sigma   weight residual
   121.50  120.38    1.12 1.00e+00 1.00e+00 1.26e+00
angle pdb=" N   GLN A  31 "
      pdb=" CA  GLN A  31 "
      pdb=" C   GLN A  31 "
    ideal   model   delta    sigma   weight residual
   109.52  111.26   -1.74 1.55e+00 4.16e-01 1.26e+00
angle pdb=" N   ARG A  82 "
      pdb=" CA  ARG A  82 "
      pdb=" CB  ARG A  82 "
    ideal   model   delta    sigma   weight residual
   110.57  108.83    1.74 1.57e+00 4.06e-01 1.23e+00
angle pdb=" CA  LEU A  49 "
      pdb=" CB  LEU A  49 "
      pdb=" CG  LEU A  49 "
    ideal   model   delta    sigma   weight residual
   116.30  120.16   -3.86 3.50e+00 8.16e-02 1.22e+00
angle pdb=" CA  VAL A  84 "
      pdb=" C   VAL A  84 "
      pdb=" N   PRO A  85 "
    ideal   model   delta    sigma   weight residual
   118.88  117.18    1.70 1.54e+00 4.22e-01 1.21e+00
angle pdb=" N   GLN A  72 "
      pdb=" CA  GLN A  72 "
      pdb=" C   GLN A  72 "
    ideal   model   delta    sigma   weight residual
   113.16  111.80    1.36 1.24e+00 6.50e-01 1.21e+00
angle pdb=" N   ALA A  57 "
      pdb=" CA  ALA A  57 "
      pdb=" C   ALA A  57 "
    ideal   model   delta    sigma   weight residual
   110.39  112.03   -1.64 1.50e+00 4.44e-01 1.20e+00
angle pdb=" CA  GLN A  31 "
      pdb=" C   GLN A  31 "
      pdb=" N   LEU A  32 "
    ideal   model   delta    sigma   weight residual
   115.34  117.05   -1.71 1.56e+00 4.11e-01 1.19e+00
angle pdb=" C   PRO A  42 "
      pdb=" CA  PRO A  42 "
      pdb=" CB  PRO A  42 "
    ideal   model   delta    sigma   weight residual
   111.23  109.83    1.40 1.28e+00 6.10e-01 1.19e+00
angle pdb=" CA  CYS A  33 "
      pdb=" C   CYS A  33 "
      pdb=" N   TYR A  34 "
    ideal   model   delta    sigma   weight residual
   115.38  116.82   -1.44 1.33e+00 5.65e-01 1.18e+00
angle pdb=" N   VAL A  84 "
      pdb=" CA  VAL A  84 "
      pdb=" CB  VAL A  84 "
    ideal   model   delta    sigma   weight residual
   111.21  112.73   -1.52 1.40e+00 5.10e-01 1.17e+00
angle pdb=" C   GLY A  59 "
      pdb=" N   LEU A  60 "
      pdb=" CA  LEU A  60 "
    ideal   model   delta    sigma   weight residual
   123.00  121.51    1.49 1.38e+00 5.25e-01 1.17e+00
angle pdb=" O   ASN A  29 "
      pdb=" C   ASN A  29 "
      pdb=" N   GLU A  30 "
    ideal   model   delta    sigma   weight residual
   123.29  122.02    1.27 1.18e+00 7.18e-01 1.16e+00
angle pdb=" C   LYS A  69 "
      pdb=" N   VAL A  70 "
      pdb=" CA  VAL A  70 "
    ideal   model   delta    sigma   weight residual
   122.43  121.07    1.36 1.26e+00 6.30e-01 1.16e+00
angle pdb=" CA  VAL A  70 "
      pdb=" C   VAL A  70 "
      pdb=" O   VAL A  70 "
    ideal   model   delta    sigma   weight residual
   120.75  119.44    1.31 1.22e+00 6.72e-01 1.15e+00
angle pdb=" C   SER A  27 "
      pdb=" N   LEU A  28 "
      pdb=" CA  LEU A  28 "
    ideal   model   delta    sigma   weight residual
   122.94  121.33    1.61 1.50e+00 4.44e-01 1.15e+00
angle pdb=" N   LEU A  28 "
      pdb=" CA  LEU A  28 "
      pdb=" CB  LEU A  28 "
    ideal   model   delta    sigma   weight residual
   110.83  108.97    1.86 1.74e+00 3.30e-01 1.14e+00
angle pdb=" NE  ARG A  80 "
      pdb=" CZ  ARG A  80 "
      pdb=" NH1 ARG A  80 "
    ideal   model   delta    sigma   weight residual
   121.50  120.44    1.06 1.00e+00 1.00e+00 1.13e+00
angle pdb=" N   PRO A  42 "
      pdb=" CA  PRO A  42 "
      pdb=" C   PRO A  42 "
    ideal   model   delta    sigma   weight residual
   111.21  112.89   -1.68 1.59e+00 3.96e-01 1.11e+00
angle pdb=" C   VAL A  70 "
      pdb=" N   GLY A  71 "
      pdb=" CA  GLY A  71 "
    ideal   model   delta    sigma   weight residual
   121.41  123.48   -2.07 1.96e+00 2.60e-01 1.11e+00
angle pdb=" O   GLY A  71 "
      pdb=" C   GLY A  71 "
      pdb=" N   GLN A  72 "
    ideal   model   delta    sigma   weight residual
   122.70  121.33    1.37 1.30e+00 5.92e-01 1.11e+00
angle pdb=" N   ASP A  50 "
      pdb=" CA  ASP A  50 "
      pdb=" C   ASP A  50 "
    ideal   model   delta    sigma   weight residual
   110.59  109.07    1.52 1.45e+00 4.76e-01 1.10e+00
angle pdb=" CA  VAL A   4 "
      pdb=" CB  VAL A   4 "
      pdb=" CG1 VAL A   4 "
    ideal   model   delta    sigma   weight residual
   110.40  112.18   -1.78 1.70e+00 3.46e-01 1.10e+00
angle pdb=" N   GLN A  31 "
      pdb=" CA  GLN A  31 "
      pdb=" CB  GLN A  31 "
    ideal   model   delta    sigma   weight residual
   111.55  109.73    1.82 1.74e+00 3.30e-01 1.10e+00
angle pdb=" O   TYR A  34 "
      pdb=" C   TYR A  34 "
      pdb=" N   VAL A  35 "
    ideal   model   delta    sigma   weight residual
   123.29  122.06    1.23 1.18e+00 7.18e-01 1.08e+00
angle pdb=" C   ASN A  29 "
      pdb=" N   GLU A  30 "
      pdb=" CA  GLU A  30 "
    ideal   model   delta    sigma   weight residual
   122.94  121.38    1.56 1.50e+00 4.44e-01 1.08e+00
angle pdb=" CA  SER A  75 "
      pdb=" C   SER A  75 "
      pdb=" O   SER A  75 "
    ideal   model   delta    sigma   weight residual
   121.72  120.50    1.22 1.18e+00 7.18e-01 1.07e+00
angle pdb=" CA  HIS A  64 "
      pdb=" C   HIS A  64 "
      pdb=" O   HIS A  64 "
    ideal   model   delta    sigma   weight residual
   121.36  120.12    1.24 1.20e+00 6.94e-01 1.07e+00
angle pdb=" N   PHE A  73 "
      pdb=" CA  PHE A  73 "
      pdb=" C   PHE A  73 "
    ideal   model   delta    sigma   weight residual
   112.59  111.33    1.26 1.22e+00 6.72e-01 1.06e+00
angle pdb=" CA  SER A  75 "
      pdb=" CB  SER A  75 "
      pdb=" OG  SER A  75 "
    ideal   model   delta    sigma   weight residual
   111.10  109.04    2.06 2.00e+00 2.50e-01 1.06e+00
angle pdb=" C   LYS A  46 "
      pdb=" CA  LYS A  46 "
      pdb=" CB  LYS A  46 "
    ideal   model   delta    sigma   weight residual
   109.75  108.06    1.69 1.65e+00 3.67e-01 1.05e+00
angle pdb=" N   PRO A  54 "
      pdb=" CA  PRO A  54 "
      pdb=" C   PRO A  54 "
    ideal   model   delta    sigma   weight residual
   111.22  112.65   -1.43 1.40e+00 5.10e-01 1.04e+00
angle pdb=" C   GLU A  51 "
      pdb=" N   GLY A  52 "
      pdb=" CA  GLY A  52 "
    ideal   model   delta    sigma   weight residual
   122.05  120.20    1.85 1.81e+00 3.05e-01 1.04e+00
angle pdb=" CG1 VAL A  35 "
      pdb=" CB  VAL A  35 "
      pdb=" CG2 VAL A  35 "
    ideal   model   delta    sigma   weight residual
   110.80  108.57    2.23 2.20e+00 2.07e-01 1.03e+00
angle pdb=" O   VAL A  70 "
      pdb=" C   VAL A  70 "
      pdb=" N   GLY A  71 "
    ideal   model   delta    sigma   weight residual
   122.77  124.03   -1.26 1.24e+00 6.50e-01 1.03e+00
angle pdb=" CA  THR A  48 "
      pdb=" C   THR A  48 "
      pdb=" O   THR A  48 "
    ideal   model   delta    sigma   weight residual
   120.70  119.56    1.14 1.14e+00 7.69e-01 9.98e-01
angle pdb=" CA  LEU A  32 "
      pdb=" C   LEU A  32 "
      pdb=" N   CYS A  33 "
    ideal   model   delta    sigma   weight residual
   115.19  116.67   -1.48 1.48e+00 4.57e-01 9.93e-01
angle pdb=" N   LEU A  81 "
      pdb=" CA  LEU A  81 "
      pdb=" C   LEU A  81 "
    ideal   model   delta    sigma   weight residual
   110.80  112.89   -2.09 2.13e+00 2.20e-01 9.60e-01
angle pdb=" CG  MSE A  77 "
      pdb="SE   MSE A  77 "
      pdb=" CE  MSE A  77 "
    ideal   model   delta    sigma   weight residual
    98.92  101.07   -2.15 2.20e+00 2.07e-01 9.51e-01
angle pdb=" C   SER A  67 "
      pdb=" CA  SER A  67 "
      pdb=" CB  SER A  67 "
    ideal   model   delta    sigma   weight residual
   110.31  112.35   -2.04 2.09e+00 2.29e-01 9.51e-01
angle pdb=" C   ALA A  57 "
      pdb=" N   PRO A  58 "
      pdb=" CA  PRO A  58 "
    ideal   model   delta    sigma   weight residual
   119.90  118.91    0.99 1.02e+00 9.61e-01 9.42e-01
angle pdb=" CA  THR A  14 "
      pdb=" C   THR A  14 "
      pdb=" O   THR A  14 "
    ideal   model   delta    sigma   weight residual
   121.68  120.54    1.14 1.18e+00 7.18e-01 9.39e-01
angle pdb=" CB  TYR A  34 "
      pdb=" CG  TYR A  34 "
      pdb=" CD2 TYR A  34 "
    ideal   model   delta    sigma   weight residual
   120.80  122.25   -1.45 1.50e+00 4.44e-01 9.29e-01
angle pdb=" C   LEU A  44 "
      pdb=" CA  LEU A  44 "
      pdb=" CB  LEU A  44 "
    ideal   model   delta    sigma   weight residual
   109.90  108.40    1.50 1.56e+00 4.11e-01 9.28e-01
angle pdb=" CA  LYS A   3 "
      pdb=" C   LYS A   3 "
      pdb=" N   VAL A   4 "
    ideal   model   delta    sigma   weight residual
   116.25  115.07    1.18 1.23e+00 6.61e-01 9.28e-01
angle pdb=" C   TYR A  26 "
      pdb=" N   SER A  27 "
      pdb=" CA  SER A  27 "
    ideal   model   delta    sigma   weight residual
   122.33  120.71    1.62 1.68e+00 3.54e-01 9.26e-01
angle pdb=" C   ALA A  57 "
      pdb=" N   PRO A  58 "
      pdb=" CD  PRO A  58 "
    ideal   model   delta    sigma   weight residual
   125.00  128.94   -3.94 4.10e+00 5.95e-02 9.21e-01
angle pdb=" CA  THR A  15 "
      pdb=" CB  THR A  15 "
      pdb=" OG1 THR A  15 "
    ideal   model   delta    sigma   weight residual
   109.60  108.16    1.44 1.50e+00 4.44e-01 9.17e-01
angle pdb=" N   ILE A  47 "
      pdb=" CA  ILE A  47 "
      pdb=" CB  ILE A  47 "
    ideal   model   delta    sigma   weight residual
   111.21  109.44    1.77 1.85e+00 2.92e-01 9.15e-01
angle pdb=" CB  LEU A  65 "
      pdb=" CG  LEU A  65 "
      pdb=" CD2 LEU A  65 "
    ideal   model   delta    sigma   weight residual
   110.70  107.83    2.87 3.00e+00 1.11e-01 9.14e-01
angle pdb=" C   GLU A  30 "
      pdb=" N   GLN A  31 "
      pdb=" CA  GLN A  31 "
    ideal   model   delta    sigma   weight residual
   122.59  121.10    1.49 1.57e+00 4.06e-01 8.96e-01
angle pdb=" CA  LYS A   3 "
      pdb=" C   LYS A   3 "
      pdb=" O   LYS A   3 "
    ideal   model   delta    sigma   weight residual
   120.43  121.46   -1.03 1.09e+00 8.42e-01 8.95e-01
angle pdb=" CA  SER A  75 "
      pdb=" C   SER A  75 "
      pdb=" N   LEU A  76 "
    ideal   model   delta    sigma   weight residual
   115.27  116.44   -1.17 1.24e+00 6.50e-01 8.88e-01
angle pdb=" CA  GLN A  72 "
      pdb=" C   GLN A  72 "
      pdb=" N   PHE A  73 "
    ideal   model   delta    sigma   weight residual
   118.32  117.05    1.27 1.35e+00 5.49e-01 8.85e-01
angle pdb=" CA  ILE A  78 "
      pdb=" C   ILE A  78 "
      pdb=" O   ILE A  78 "
    ideal   model   delta    sigma   weight residual
   120.71  119.65    1.06 1.13e+00 7.83e-01 8.84e-01
angle pdb=" N   ASP A  50 "
      pdb=" CA  ASP A  50 "
      pdb=" CB  ASP A  50 "
    ideal   model   delta    sigma   weight residual
   110.42  111.85   -1.43 1.52e+00 4.33e-01 8.84e-01
angle pdb=" O   ASN A  39 "
      pdb=" C   ASN A  39 "
      pdb=" N   GLU A  40 "
    ideal   model   delta    sigma   weight residual
   121.78  123.00   -1.22 1.31e+00 5.83e-01 8.72e-01
angle pdb=" N   PRO A  58 "
      pdb=" CA  PRO A  58 "
      pdb=" CB  PRO A  58 "
    ideal   model   delta    sigma   weight residual
   103.25  102.43    0.82 8.80e-01 1.29e+00 8.70e-01
angle pdb=" CA  LEU A  65 "
      pdb=" CB  LEU A  65 "
      pdb=" CG  LEU A  65 "
    ideal   model   delta    sigma   weight residual
   116.30  119.56   -3.26 3.50e+00 8.16e-02 8.69e-01
angle pdb=" CA  LEU A  65 "
      pdb=" C   LEU A  65 "
      pdb=" O   LEU A  65 "
    ideal   model   delta    sigma   weight residual
   120.10  119.05    1.05 1.13e+00 7.83e-01 8.69e-01
angle pdb=" N   THR A  15 "
      pdb=" CA  THR A  15 "
      pdb=" C   THR A  15 "
    ideal   model   delta    sigma   weight residual
   108.76  110.33   -1.57 1.69e+00 3.50e-01 8.68e-01
angle pdb=" C   GLY A  74 "
      pdb=" N   SER A  75 "
      pdb=" CA  SER A  75 "
    ideal   model   delta    sigma   weight residual
   122.07  120.20    1.87 2.01e+00 2.48e-01 8.67e-01
angle pdb=" N   CYS A  33 "
      pdb=" CA  CYS A  33 "
      pdb=" CB  CYS A  33 "
    ideal   model   delta    sigma   weight residual
   111.57  110.01    1.56 1.68e+00 3.54e-01 8.57e-01
angle pdb=" CA  ASP A  79 "
      pdb=" CB  ASP A  79 "
      pdb=" CG  ASP A  79 "
    ideal   model   delta    sigma   weight residual
   112.60  113.52   -0.92 1.00e+00 1.00e+00 8.54e-01
angle pdb=" CE1 TYR A  41 "
      pdb=" CZ  TYR A  41 "
      pdb=" OH  TYR A  41 "
    ideal   model   delta    sigma   weight residual
   119.90  122.67   -2.77 3.00e+00 1.11e-01 8.52e-01
angle pdb=" CB  TYR A  34 "
      pdb=" CG  TYR A  34 "
      pdb=" CD1 TYR A  34 "
    ideal   model   delta    sigma   weight residual
   120.80  119.43    1.37 1.50e+00 4.44e-01 8.32e-01
angle pdb=" N   THR A  48 "
      pdb=" CA  THR A  48 "
      pdb=" C   THR A  48 "
    ideal   model   delta    sigma   weight residual
   107.62  109.42   -1.80 1.97e+00 2.58e-01 8.31e-01
angle pdb=" C   VAL A   4 "
      pdb=" CA  VAL A   4 "
      pdb=" CB  VAL A   4 "
    ideal   model   delta    sigma   weight residual
   110.50  111.90   -1.40 1.54e+00 4.22e-01 8.25e-01
angle pdb=" N   PHE A  13 "
      pdb=" CA  PHE A  13 "
      pdb=" CB  PHE A  13 "
    ideal   model   delta    sigma   weight residual
   111.20  112.67   -1.47 1.62e+00 3.81e-01 8.24e-01
angle pdb=" CA  HIS A  64 "
      pdb=" CB  HIS A  64 "
      pdb=" CG  HIS A  64 "
    ideal   model   delta    sigma   weight residual
   113.80  114.70   -0.90 1.00e+00 1.00e+00 8.17e-01
angle pdb=" C   THR A  15 "
      pdb=" N   ARG A  16 "
      pdb=" CA  ARG A  16 "
    ideal   model   delta    sigma   weight residual
   122.93  121.62    1.31 1.45e+00 4.76e-01 8.16e-01
angle pdb=" O   ALA A  57 "
      pdb=" C   ALA A  57 "
      pdb=" N   PRO A  58 "
    ideal   model   delta    sigma   weight residual
   121.53  122.53   -1.00 1.12e+00 7.97e-01 8.02e-01
angle pdb=" O   ASP A  79 "
      pdb=" C   ASP A  79 "
      pdb=" N   ARG A  80 "
    ideal   model   delta    sigma   weight residual
   122.32  123.34   -1.02 1.15e+00 7.56e-01 7.93e-01
angle pdb=" O   GLY A  52 "
      pdb=" C   GLY A  52 "
      pdb=" N   GLN A  53 "
    ideal   model   delta    sigma   weight residual
   122.43  123.54   -1.11 1.27e+00 6.20e-01 7.64e-01
angle pdb=" CA  GLN A  12 "
      pdb=" C   GLN A  12 "
      pdb=" O   GLN A  12 "
    ideal   model   delta    sigma   weight residual
   121.46  120.44    1.02 1.17e+00 7.31e-01 7.63e-01
angle pdb=" O   ARG A  80 "
      pdb=" C   ARG A  80 "
      pdb=" N   LEU A  81 "
    ideal   model   delta    sigma   weight residual
   123.44  122.37    1.07 1.23e+00 6.61e-01 7.60e-01
angle pdb=" CA  GLU A  51 "
      pdb=" C   GLU A  51 "
      pdb=" O   GLU A  51 "
    ideal   model   delta    sigma   weight residual
   120.69  121.68   -0.99 1.14e+00 7.69e-01 7.49e-01
angle pdb=" O   PRO A   8 "
      pdb=" C   PRO A   8 "
      pdb=" N   SER A   9 "
    ideal   model   delta    sigma   weight residual
   122.17  123.22   -1.05 1.21e+00 6.83e-01 7.49e-01
angle pdb=" NE  ARG A  80 "
      pdb=" CZ  ARG A  80 "
      pdb=" NH2 ARG A  80 "
    ideal   model   delta    sigma   weight residual
   119.20  119.98   -0.78 9.00e-01 1.23e+00 7.42e-01
angle pdb=" C   GLY A  52 "
      pdb=" N   GLN A  53 "
      pdb=" CA  GLN A  53 "
    ideal   model   delta    sigma   weight residual
   121.59  118.56    3.03 3.54e+00 7.98e-02 7.35e-01
angle pdb=" CA  THR A  48 "
      pdb=" C   THR A  48 "
      pdb=" N   LEU A  49 "
    ideal   model   delta    sigma   weight residual
   116.23  115.06    1.17 1.37e+00 5.33e-01 7.32e-01
angle pdb=" CB  ILE A  47 "
      pdb=" CG1 ILE A  47 "
      pdb=" CD1 ILE A  47 "
    ideal   model   delta    sigma   weight residual
   113.80  112.02    1.78 2.10e+00 2.27e-01 7.22e-01
angle pdb=" CB  PRO A  54 "
      pdb=" CG  PRO A  54 "
      pdb=" CD  PRO A  54 "
    ideal   model   delta    sigma   weight residual
   106.10  103.39    2.71 3.20e+00 9.77e-02 7.18e-01
angle pdb=" CA  ARG A  80 "
      pdb=" C   ARG A  80 "
      pdb=" O   ARG A  80 "
    ideal   model   delta    sigma   weight residual
   120.21  119.07    1.14 1.35e+00 5.49e-01 7.17e-01
angle pdb=" CA  GLY A  59 "
      pdb=" C   GLY A  59 "
      pdb=" N   LEU A  60 "
    ideal   model   delta    sigma   weight residual
   115.00  116.31   -1.31 1.55e+00 4.16e-01 7.16e-01
angle pdb=" C   GLU A   5 "
      pdb=" N   ILE A   6 "
      pdb=" CA  ILE A   6 "
    ideal   model   delta    sigma   weight residual
   123.12  122.02    1.10 1.30e+00 5.92e-01 7.12e-01
angle pdb=" N   LYS A  69 "
      pdb=" CA  LYS A  69 "
      pdb=" CB  LYS A  69 "
    ideal   model   delta    sigma   weight residual
   111.43  110.09    1.34 1.59e+00 3.96e-01 7.11e-01
angle pdb=" CA  SER A  67 "
      pdb=" CB  SER A  67 "
      pdb=" OG  SER A  67 "
    ideal   model   delta    sigma   weight residual
   111.10  112.78   -1.68 2.00e+00 2.50e-01 7.03e-01
angle pdb=" N   TYR A  56 "
      pdb=" CA  TYR A  56 "
      pdb=" CB  TYR A  56 "
    ideal   model   delta    sigma   weight residual
   109.97  111.20   -1.23 1.47e+00 4.63e-01 7.00e-01
angle pdb=" CA  ALA A  57 "
      pdb=" C   ALA A  57 "
      pdb=" O   ALA A  57 "
    ideal   model   delta    sigma   weight residual
   120.88  121.81   -0.93 1.12e+00 7.97e-01 6.93e-01
angle pdb=" CA  GLN A  31 "
      pdb=" C   GLN A  31 "
      pdb=" O   GLN A  31 "
    ideal   model   delta    sigma   weight residual
   121.44  120.47    0.97 1.17e+00 7.31e-01 6.92e-01
angle pdb=" O   MSE A  77 "
      pdb=" C   MSE A  77 "
      pdb=" N   ILE A  78 "
    ideal   model   delta    sigma   weight residual
   123.15  122.07    1.08 1.30e+00 5.92e-01 6.91e-01
angle pdb=" CA  ASN A  39 "
      pdb=" C   ASN A  39 "
      pdb=" N   GLU A  40 "
    ideal   model   delta    sigma   weight residual
   117.21  116.03    1.18 1.42e+00 4.96e-01 6.86e-01
angle pdb=" CA  LYS A   7 "
      pdb=" C   LYS A   7 "
      pdb=" O   LYS A   7 "
    ideal   model   delta    sigma   weight residual
   120.88  119.95    0.93 1.12e+00 7.97e-01 6.85e-01
angle pdb=" N   LEU A  83 "
      pdb=" CA  LEU A  83 "
      pdb=" CB  LEU A  83 "
    ideal   model   delta    sigma   weight residual
   110.85  109.53    1.32 1.60e+00 3.91e-01 6.84e-01
angle pdb=" CA  ALA A  55 "
      pdb=" C   ALA A  55 "
      pdb=" N   TYR A  56 "
    ideal   model   delta    sigma   weight residual
   115.88  114.82    1.06 1.28e+00 6.10e-01 6.82e-01
angle pdb=" CA  LEU A  60 "
      pdb=" C   LEU A  60 "
      pdb=" N   TYR A  61 "
    ideal   model   delta    sigma   weight residual
   116.28  115.24    1.04 1.26e+00 6.30e-01 6.81e-01
angle pdb=" CA  LEU A  28 "
      pdb=" C   LEU A  28 "
      pdb=" N   ASN A  29 "
    ideal   model   delta    sigma   weight residual
   116.01  117.23   -1.22 1.49e+00 4.50e-01 6.75e-01
angle pdb=" N   ILE A   2 "
      pdb=" CA  ILE A   2 "
      pdb=" C   ILE A   2 "
    ideal   model   delta    sigma   weight residual
   111.00  113.28   -2.28 2.80e+00 1.28e-01 6.65e-01
angle pdb=" CA  VAL A  70 "
      pdb=" CB  VAL A  70 "
      pdb=" CG2 VAL A  70 "
    ideal   model   delta    sigma   weight residual
   110.40  109.02    1.38 1.70e+00 3.46e-01 6.55e-01
angle pdb=" C   ALA A  11 "
      pdb=" N   GLN A  12 "
      pdb=" CA  GLN A  12 "
    ideal   model   delta    sigma   weight residual
   122.81  121.46    1.35 1.68e+00 3.54e-01 6.48e-01
angle pdb=" N   ASP A  79 "
      pdb=" CA  ASP A  79 "
      pdb=" CB  ASP A  79 "
    ideal   model   delta    sigma   weight residual
   110.14  108.89    1.25 1.56e+00 4.11e-01 6.46e-01
angle pdb=" NE  ARG A  82 "
      pdb=" CZ  ARG A  82 "
      pdb=" NH2 ARG A  82 "
    ideal   model   delta    sigma   weight residual
   119.20  119.92   -0.72 9.00e-01 1.23e+00 6.37e-01
angle pdb=" CA  LYS A  69 "
      pdb=" C   LYS A  69 "
      pdb=" N   VAL A  70 "
    ideal   model   delta    sigma   weight residual
   115.42  116.73   -1.31 1.64e+00 3.72e-01 6.35e-01
angle pdb=" C   ASP A  79 "
      pdb=" CA  ASP A  79 "
      pdb=" CB  ASP A  79 "
    ideal   model   delta    sigma   weight residual
   111.03  109.54    1.49 1.87e+00 2.86e-01 6.31e-01
angle pdb=" N   LEU A  76 "
      pdb=" CA  LEU A  76 "
      pdb=" CB  LEU A  76 "
    ideal   model   delta    sigma   weight residual
   109.85  111.03   -1.18 1.49e+00 4.50e-01 6.31e-01
angle pdb=" N   SER A  67 "
      pdb=" CA  SER A  67 "
      pdb=" C   SER A  67 "
    ideal   model   delta    sigma   weight residual
   112.54  113.51   -0.97 1.22e+00 6.72e-01 6.29e-01
angle pdb=" C   GLY A  38 "
      pdb=" N   ASN A  39 "
      pdb=" CA  ASN A  39 "
    ideal   model   delta    sigma   weight residual
   122.15  120.78    1.37 1.74e+00 3.30e-01 6.23e-01
angle pdb=" CA  THR A  62 "
      pdb=" CB  THR A  62 "
      pdb=" CG2 THR A  62 "
    ideal   model   delta    sigma   weight residual
   110.50  111.84   -1.34 1.70e+00 3.46e-01 6.20e-01
angle pdb=" CB  LEU A  44 "
      pdb=" CG  LEU A  44 "
      pdb=" CD1 LEU A  44 "
    ideal   model   delta    sigma   weight residual
   110.70  108.35    2.35 3.00e+00 1.11e-01 6.15e-01
angle pdb=" O   THR A  62 "
      pdb=" C   THR A  62 "
      pdb=" N   VAL A  63 "
    ideal   model   delta    sigma   weight residual
   122.74  121.66    1.08 1.38e+00 5.25e-01 6.11e-01
angle pdb=" CA  GLN A  12 "
      pdb=" C   GLN A  12 "
      pdb=" N   PHE A  13 "
    ideal   model   delta    sigma   weight residual
   115.36  116.58   -1.22 1.56e+00 4.11e-01 6.09e-01
angle pdb=" CA  ARG A  82 "
      pdb=" CB  ARG A  82 "
      pdb=" CG  ARG A  82 "
    ideal   model   delta    sigma   weight residual
   114.10  112.54    1.56 2.00e+00 2.50e-01 6.08e-01
angle pdb=" C   HIS A  64 "
      pdb=" CA  HIS A  64 "
      pdb=" CB  HIS A  64 "
    ideal   model   delta    sigma   weight residual
   109.51  110.84   -1.33 1.71e+00 3.42e-01 6.07e-01
angle pdb=" O   SER A  66 "
      pdb=" C   SER A  66 "
      pdb=" N   SER A  67 "
    ideal   model   delta    sigma   weight residual
   122.43  123.45   -1.02 1.33e+00 5.65e-01 5.88e-01
angle pdb=" CG  GLU A  51 "
      pdb=" CD  GLU A  51 "
      pdb=" OE1 GLU A  51 "
    ideal   model   delta    sigma   weight residual
   118.40  120.15   -1.75 2.30e+00 1.89e-01 5.78e-01
angle pdb=" C   SER A  67 "
      pdb=" N   PHE A  68 "
      pdb=" CA  PHE A  68 "
    ideal   model   delta    sigma   weight residual
   122.93  121.83    1.10 1.45e+00 4.76e-01 5.74e-01
angle pdb=" CA  LEU A  83 "
      pdb=" CB  LEU A  83 "
      pdb=" CG  LEU A  83 "
    ideal   model   delta    sigma   weight residual
   116.30  118.94   -2.64 3.50e+00 8.16e-02 5.70e-01
angle pdb=" N   TYR A  26 "
      pdb=" CA  TYR A  26 "
      pdb=" CB  TYR A  26 "
    ideal   model   delta    sigma   weight residual
   110.50  111.78   -1.28 1.70e+00 3.46e-01 5.69e-01
angle pdb=" CA  ILE A  78 "
      pdb=" CB  ILE A  78 "
      pdb=" CG2 ILE A  78 "
    ideal   model   delta    sigma   weight residual
   110.50  111.78   -1.28 1.70e+00 3.46e-01 5.66e-01
angle pdb=" CA  SER A   9 "
      pdb=" C   SER A   9 "
      pdb=" N   GLN A  10 "
    ideal   model   delta    sigma   weight residual
   118.41  117.40    1.01 1.34e+00 5.57e-01 5.66e-01
angle pdb=" CA  TYR A  34 "
      pdb=" C   TYR A  34 "
      pdb=" N   VAL A  35 "
    ideal   model   delta    sigma   weight residual
   116.28  117.22   -0.94 1.26e+00 6.30e-01 5.56e-01
angle pdb=" CA  TYR A  26 "
      pdb=" C   TYR A  26 "
      pdb=" O   TYR A  26 "
    ideal   model   delta    sigma   weight residual
   120.80  122.07   -1.27 1.70e+00 3.46e-01 5.54e-01
angle pdb=" CG1 VAL A  63 "
      pdb=" CB  VAL A  63 "
      pdb=" CG2 VAL A  63 "
    ideal   model   delta    sigma   weight residual
   110.80  109.17    1.63 2.20e+00 2.07e-01 5.49e-01
angle pdb=" C   SER A  66 "
      pdb=" CA  SER A  66 "
      pdb=" CB  SER A  66 "
    ideal   model   delta    sigma   weight residual
   110.21  108.62    1.59 2.19e+00 2.09e-01 5.30e-01
angle pdb=" CA  TYR A  41 "
      pdb=" CB  TYR A  41 "
      pdb=" CG  TYR A  41 "
    ideal   model   delta    sigma   weight residual
   113.90  115.20   -1.30 1.80e+00 3.09e-01 5.25e-01
angle pdb=" CA  TYR A  34 "
      pdb=" CB  TYR A  34 "
      pdb=" CG  TYR A  34 "
    ideal   model   delta    sigma   weight residual
   113.90  115.20   -1.30 1.80e+00 3.09e-01 5.19e-01
angle pdb=" CA  ARG A  82 "
      pdb=" C   ARG A  82 "
      pdb=" N   LEU A  83 "
    ideal   model   delta    sigma   weight residual
   116.28  117.18   -0.90 1.26e+00 6.30e-01 5.16e-01
angle pdb=" N   GLY A  71 "
      pdb=" CA  GLY A  71 "
      pdb=" C   GLY A  71 "
    ideal   model   delta    sigma   weight residual
   113.18  114.87   -1.69 2.37e+00 1.78e-01 5.11e-01
angle pdb=" CA  PHE A  68 "
      pdb=" C   PHE A  68 "
      pdb=" N   LYS A  69 "
    ideal   model   delta    sigma   weight residual
   116.02  117.03   -1.01 1.42e+00 4.96e-01 5.06e-01
angle pdb=" C   ILE A   6 "
      pdb=" CA  ILE A   6 "
      pdb=" CB  ILE A   6 "
    ideal   model   delta    sigma   weight residual
   110.96  109.92    1.04 1.46e+00 4.69e-01 5.06e-01
angle pdb=" CA  ASP A  36 "
      pdb=" CB  ASP A  36 "
      pdb=" CG  ASP A  36 "
    ideal   model   delta    sigma   weight residual
   112.60  113.31   -0.71 1.00e+00 1.00e+00 5.05e-01
angle pdb=" CA  PRO A   8 "
      pdb=" C   PRO A   8 "
      pdb=" N   SER A   9 "
    ideal   model   delta    sigma   weight residual
   118.15  117.03    1.12 1.58e+00 4.01e-01 5.01e-01
angle pdb=" CA  SER A  67 "
      pdb=" C   SER A  67 "
      pdb=" O   SER A  67 "
    ideal   model   delta    sigma   weight residual
   119.38  120.25   -0.87 1.23e+00 6.61e-01 5.00e-01
angle pdb=" CA  VAL A  35 "
      pdb=" CB  VAL A  35 "
      pdb=" CG1 VAL A  35 "
    ideal   model   delta    sigma   weight residual
   110.40  111.60   -1.20 1.70e+00 3.46e-01 4.97e-01
angle pdb=" CA  THR A  14 "
      pdb=" C   THR A  14 "
      pdb=" N   THR A  15 "
    ideal   model   delta    sigma   weight residual
   115.32  116.45   -1.13 1.61e+00 3.86e-01 4.95e-01
angle pdb=" C   ARG A  80 "
      pdb=" CA  ARG A  80 "
      pdb=" CB  ARG A  80 "
    ideal   model   delta    sigma   weight residual
   109.80  110.99   -1.19 1.70e+00 3.46e-01 4.93e-01
angle pdb=" CA  GLU A  51 "
      pdb=" C   GLU A  51 "
      pdb=" N   GLY A  52 "
    ideal   model   delta    sigma   weight residual
   116.23  115.32    0.91 1.30e+00 5.92e-01 4.88e-01
angle pdb=" CB  GLN A  53 "
      pdb=" CG  GLN A  53 "
      pdb=" CD  GLN A  53 "
    ideal   model   delta    sigma   weight residual
   112.60  111.41    1.19 1.70e+00 3.46e-01 4.86e-01
angle pdb=" CA  ASP A  50 "
      pdb=" CB  ASP A  50 "
      pdb=" CG  ASP A  50 "
    ideal   model   delta    sigma   weight residual
   112.60  113.30   -0.70 1.00e+00 1.00e+00 4.85e-01
angle pdb=" CA  CYS A  33 "
      pdb=" C   CYS A  33 "
      pdb=" O   CYS A  33 "
    ideal   model   delta    sigma   weight residual
   121.28  120.53    0.75 1.07e+00 8.73e-01 4.85e-01
angle pdb=" C   VAL A  63 "
      pdb=" CA  VAL A  63 "
      pdb=" CB  VAL A  63 "
    ideal   model   delta    sigma   weight residual
   110.91  111.77   -0.86 1.24e+00 6.50e-01 4.83e-01
angle pdb=" CA  VAL A  63 "
      pdb=" CB  VAL A  63 "
      pdb=" CG2 VAL A  63 "
    ideal   model   delta    sigma   weight residual
   110.40  109.23    1.17 1.70e+00 3.46e-01 4.75e-01
angle pdb=" OE1 GLU A  51 "
      pdb=" CD  GLU A  51 "
      pdb=" OE2 GLU A  51 "
    ideal   model   delta    sigma   weight residual
   122.90  121.25    1.65 2.40e+00 1.74e-01 4.72e-01
angle pdb=" C   LEU A  60 "
      pdb=" CA  LEU A  60 "
      pdb=" CB  LEU A  60 "
    ideal   model   delta    sigma   weight residual
   109.72  110.91   -1.19 1.73e+00 3.34e-01 4.70e-01
angle pdb=" CA  PHE A  73 "
      pdb=" CB  PHE A  73 "
      pdb=" CG  PHE A  73 "
    ideal   model   delta    sigma   weight residual
   113.80  114.49   -0.69 1.00e+00 1.00e+00 4.69e-01
angle pdb=" O   CYS A  33 "
      pdb=" C   CYS A  33 "
      pdb=" N   TYR A  34 "
    ideal   model   delta    sigma   weight residual
   123.29  122.62    0.67 1.00e+00 1.00e+00 4.54e-01
angle pdb=" CB  GLN A  12 "
      pdb=" CG  GLN A  12 "
      pdb=" CD  GLN A  12 "
    ideal   model   delta    sigma   weight residual
   112.60  113.74   -1.14 1.70e+00 3.46e-01 4.52e-01
angle pdb=" N   VAL A  63 "
      pdb=" CA  VAL A  63 "
      pdb=" CB  VAL A  63 "
    ideal   model   delta    sigma   weight residual
   110.72  109.99    0.73 1.09e+00 8.42e-01 4.51e-01
angle pdb=" O   SER A  27 "
      pdb=" C   SER A  27 "
      pdb=" N   LEU A  28 "
    ideal   model   delta    sigma   weight residual
   123.36  122.55    0.81 1.22e+00 6.72e-01 4.44e-01
angle pdb=" CB  TYR A  41 "
      pdb=" CG  TYR A  41 "
      pdb=" CD1 TYR A  41 "
    ideal   model   delta    sigma   weight residual
   120.80  121.80   -1.00 1.50e+00 4.44e-01 4.44e-01
angle pdb=" C   VAL A  45 "
      pdb=" N   LYS A  46 "
      pdb=" CA  LYS A  46 "
    ideal   model   delta    sigma   weight residual
   122.72  121.81    0.91 1.38e+00 5.25e-01 4.38e-01
angle pdb=" C   PHE A  13 "
      pdb=" CA  PHE A  13 "
      pdb=" CB  PHE A  13 "
    ideal   model   delta    sigma   weight residual
   109.66  110.93   -1.27 1.94e+00 2.66e-01 4.27e-01
angle pdb=" O   GLY A  59 "
      pdb=" C   GLY A  59 "
      pdb=" N   LEU A  60 "
    ideal   model   delta    sigma   weight residual
   123.93  122.89    1.04 1.59e+00 3.96e-01 4.26e-01
angle pdb=" CA  ASN A  29 "
      pdb=" C   ASN A  29 "
      pdb=" N   GLU A  30 "
    ideal   model   delta    sigma   weight residual
   116.28  117.10   -0.82 1.26e+00 6.30e-01 4.25e-01
angle pdb=" CA  VAL A  43 "
      pdb=" CB  VAL A  43 "
      pdb=" CG2 VAL A  43 "
    ideal   model   delta    sigma   weight residual
   110.40  109.30    1.10 1.70e+00 3.46e-01 4.22e-01
angle pdb=" C   PRO A  54 "
      pdb=" CA  PRO A  54 "
      pdb=" CB  PRO A  54 "
    ideal   model   delta    sigma   weight residual
   111.22  110.24    0.98 1.51e+00 4.39e-01 4.22e-01
angle pdb=" N   ASN A  39 "
      pdb=" CA  ASN A  39 "
      pdb=" CB  ASN A  39 "
    ideal   model   delta    sigma   weight residual
   109.94  109.00    0.94 1.44e+00 4.82e-01 4.22e-01
angle pdb=" CD  LYS A  69 "
      pdb=" CE  LYS A  69 "
      pdb=" NZ  LYS A  69 "
    ideal   model   delta    sigma   weight residual
   111.90  113.98   -2.08 3.20e+00 9.77e-02 4.21e-01
angle pdb=" C   THR A  15 "
      pdb=" CA  THR A  15 "
      pdb=" CB  THR A  15 "
    ideal   model   delta    sigma   weight residual
   109.70  110.87   -1.17 1.81e+00 3.05e-01 4.18e-01
angle pdb=" CD1 LEU A  44 "
      pdb=" CG  LEU A  44 "
      pdb=" CD2 LEU A  44 "
    ideal   model   delta    sigma   weight residual
   110.80  112.22   -1.42 2.20e+00 2.07e-01 4.18e-01
angle pdb=" C   PHE A  68 "
      pdb=" N   LYS A  69 "
      pdb=" CA  LYS A  69 "
    ideal   model   delta    sigma   weight residual
   122.82  121.73    1.09 1.68e+00 3.54e-01 4.18e-01
angle pdb=" O   VAL A  45 "
      pdb=" C   VAL A  45 "
      pdb=" N   LYS A  46 "
    ideal   model   delta    sigma   weight residual
   123.05  122.33    0.72 1.11e+00 8.12e-01 4.17e-01
angle pdb=" CA  SER A  27 "
      pdb=" C   SER A  27 "
      pdb=" N   LEU A  28 "
    ideal   model   delta    sigma   weight residual
   116.31  117.27   -0.96 1.48e+00 4.57e-01 4.16e-01
angle pdb=" N   LEU A  37 "
      pdb=" CA  LEU A  37 "
      pdb=" C   LEU A  37 "
    ideal   model   delta    sigma   weight residual
   112.26  113.11   -0.85 1.32e+00 5.74e-01 4.15e-01
angle pdb=" N   ASP A  79 "
      pdb=" CA  ASP A  79 "
      pdb=" C   ASP A  79 "
    ideal   model   delta    sigma   weight residual
   111.56  110.59    0.97 1.53e+00 4.27e-01 4.05e-01
angle pdb=" CA  VAL A  35 "
      pdb=" C   VAL A  35 "
      pdb=" O   VAL A  35 "
    ideal   model   delta    sigma   weight residual
   120.48  121.15   -0.67 1.06e+00 8.90e-01 4.03e-01
angle pdb=" O   ILE A  47 "
      pdb=" C   ILE A  47 "
      pdb=" N   THR A  48 "
    ideal   model   delta    sigma   weight residual
   123.14  122.50    0.64 1.02e+00 9.61e-01 4.00e-01
angle pdb=" CA  PRO A  58 "
      pdb=" C   PRO A  58 "
      pdb=" O   PRO A  58 "
    ideal   model   delta    sigma   weight residual
   121.36  120.65    0.71 1.13e+00 7.83e-01 3.91e-01
angle pdb=" N   LEU A  81 "
      pdb=" CA  LEU A  81 "
      pdb=" CB  LEU A  81 "
    ideal   model   delta    sigma   weight residual
   110.49  111.54   -1.05 1.69e+00 3.50e-01 3.89e-01
angle pdb=" C   TYR A  56 "
      pdb=" CA  TYR A  56 "
      pdb=" CB  TYR A  56 "
    ideal   model   delta    sigma   weight residual
   109.65  108.59    1.06 1.71e+00 3.42e-01 3.86e-01
angle pdb=" CA  ALA A  11 "
      pdb=" C   ALA A  11 "
      pdb=" N   GLN A  12 "
    ideal   model   delta    sigma   weight residual
   118.13  117.34    0.79 1.28e+00 6.10e-01 3.79e-01
angle pdb=" CA  THR A  62 "
      pdb=" C   THR A  62 "
      pdb=" O   THR A  62 "
    ideal   model   delta    sigma   weight residual
   121.49  120.78    0.71 1.16e+00 7.43e-01 3.75e-01
angle pdb=" N   THR A  48 "
      pdb=" CA  THR A  48 "
      pdb=" CB  THR A  48 "
    ideal   model   delta    sigma   weight residual
   110.46  111.50   -1.04 1.69e+00 3.50e-01 3.75e-01
angle pdb=" CA  LYS A  69 "
      pdb=" C   LYS A  69 "
      pdb=" O   LYS A  69 "
    ideal   model   delta    sigma   weight residual
   121.58  120.87    0.71 1.16e+00 7.43e-01 3.74e-01
angle pdb=" CA  ILE A  47 "
      pdb=" C   ILE A  47 "
      pdb=" N   THR A  48 "
    ideal   model   delta    sigma   weight residual
   116.10  115.34    0.76 1.25e+00 6.40e-01 3.70e-01
angle pdb=" O   GLY A  74 "
      pdb=" C   GLY A  74 "
      pdb=" N   SER A  75 "
    ideal   model   delta    sigma   weight residual
   122.25  121.49    0.76 1.25e+00 6.40e-01 3.69e-01
angle pdb=" CB  GLN A  72 "
      pdb=" CG  GLN A  72 "
      pdb=" CD  GLN A  72 "
    ideal   model   delta    sigma   weight residual
   112.60  111.58    1.02 1.70e+00 3.46e-01 3.63e-01
angle pdb=" CA  PHE A  13 "
      pdb=" CB  PHE A  13 "
      pdb=" CG  PHE A  13 "
    ideal   model   delta    sigma   weight residual
   113.80  114.40   -0.60 1.00e+00 1.00e+00 3.61e-01
angle pdb=" CB  ASP A  36 "
      pdb=" CG  ASP A  36 "
      pdb=" OD1 ASP A  36 "
    ideal   model   delta    sigma   weight residual
   118.40  119.76   -1.36 2.30e+00 1.89e-01 3.49e-01
angle pdb=" C   GLN A  10 "
      pdb=" N   ALA A  11 "
      pdb=" CA  ALA A  11 "
    ideal   model   delta    sigma   weight residual
   122.56  121.55    1.01 1.72e+00 3.38e-01 3.48e-01
angle pdb=" C   LYS A   3 "
      pdb=" N   VAL A   4 "
      pdb=" CA  VAL A   4 "
    ideal   model   delta    sigma   weight residual
   122.94  123.75   -0.81 1.39e+00 5.18e-01 3.43e-01
angle pdb=" CA  SER A  66 "
      pdb=" C   SER A  66 "
      pdb=" O   SER A  66 "
    ideal   model   delta    sigma   weight residual
   119.10  119.84   -0.74 1.26e+00 6.30e-01 3.43e-01
angle pdb=" CA  GLY A  74 "
      pdb=" C   GLY A  74 "
      pdb=" O   GLY A  74 "
    ideal   model   delta    sigma   weight residual
   119.20  119.78   -0.58 9.90e-01 1.02e+00 3.40e-01
angle pdb=" O   LEU A  60 "
      pdb=" C   LEU A  60 "
      pdb=" N   TYR A  61 "
    ideal   model   delta    sigma   weight residual
   123.29  122.61    0.68 1.18e+00 7.18e-01 3.35e-01
angle pdb=" N   ILE A  78 "
      pdb=" CA  ILE A  78 "
      pdb=" CB  ILE A  78 "
    ideal   model   delta    sigma   weight residual
   110.72  111.35   -0.63 1.09e+00 8.42e-01 3.34e-01
angle pdb=" CB  LEU A  32 "
      pdb=" CG  LEU A  32 "
      pdb=" CD1 LEU A  32 "
    ideal   model   delta    sigma   weight residual
   110.70  112.43   -1.73 3.00e+00 1.11e-01 3.33e-01
angle pdb=" C   TYR A  56 "
      pdb=" N   ALA A  57 "
      pdb=" CA  ALA A  57 "
    ideal   model   delta    sigma   weight residual
   121.48  120.31    1.17 2.04e+00 2.40e-01 3.30e-01
angle pdb=" CB  LEU A  37 "
      pdb=" CG  LEU A  37 "
      pdb=" CD1 LEU A  37 "
    ideal   model   delta    sigma   weight residual
   110.70  108.98    1.72 3.00e+00 1.11e-01 3.28e-01
angle pdb=" O   ILE A  78 "
      pdb=" C   ILE A  78 "
      pdb=" N   ASP A  79 "
    ideal   model   delta    sigma   weight residual
   122.95  122.30    0.65 1.14e+00 7.69e-01 3.26e-01
angle pdb=" N   LEU A  37 "
      pdb=" CA  LEU A  37 "
      pdb=" CB  LEU A  37 "
    ideal   model   delta    sigma   weight residual
   111.17  110.24    0.93 1.64e+00 3.72e-01 3.22e-01
angle pdb=" CA  GLN A  10 "
      pdb=" CB  GLN A  10 "
      pdb=" CG  GLN A  10 "
    ideal   model   delta    sigma   weight residual
   114.10  115.23   -1.13 2.00e+00 2.50e-01 3.21e-01
angle pdb=" C   LEU A  28 "
      pdb=" CA  LEU A  28 "
      pdb=" CB  LEU A  28 "
    ideal   model   delta    sigma   weight residual
   109.37  110.45   -1.08 1.91e+00 2.74e-01 3.21e-01
angle pdb=" CA  ARG A  82 "
      pdb=" C   ARG A  82 "
      pdb=" O   ARG A  82 "
    ideal   model   delta    sigma   weight residual
   120.38  121.00   -0.62 1.09e+00 8.42e-01 3.20e-01
angle pdb=" C   ILE A  47 "
      pdb=" N   THR A  48 "
      pdb=" CA  THR A  48 "
    ideal   model   delta    sigma   weight residual
   123.14  122.31    0.83 1.48e+00 4.57e-01 3.17e-01
angle pdb=" N   ILE A   2 "
      pdb=" CA  ILE A   2 "
      pdb=" CB  ILE A   2 "
    ideal   model   delta    sigma   weight residual
   111.50  112.46   -0.96 1.70e+00 3.46e-01 3.16e-01
angle pdb=" CA  SER A  27 "
      pdb=" CB  SER A  27 "
      pdb=" OG  SER A  27 "
    ideal   model   delta    sigma   weight residual
   111.10  112.22   -1.12 2.00e+00 2.50e-01 3.14e-01
angle pdb=" C   GLN A  31 "
      pdb=" N   LEU A  32 "
      pdb=" CA  LEU A  32 "
    ideal   model   delta    sigma   weight residual
   123.05  122.05    1.00 1.79e+00 3.12e-01 3.10e-01
angle pdb=" CA  SER A  66 "
      pdb=" CB  SER A  66 "
      pdb=" OG  SER A  66 "
    ideal   model   delta    sigma   weight residual
   111.10  112.21   -1.11 2.00e+00 2.50e-01 3.09e-01
angle pdb=" N   PHE A  13 "
      pdb=" CA  PHE A  13 "
      pdb=" C   PHE A  13 "
    ideal   model   delta    sigma   weight residual
   109.85  110.73   -0.88 1.58e+00 4.01e-01 3.08e-01
angle pdb=" N   SER A  75 "
      pdb=" CA  SER A  75 "
      pdb=" CB  SER A  75 "
    ideal   model   delta    sigma   weight residual
   110.46  109.59    0.87 1.60e+00 3.91e-01 2.98e-01
angle pdb=" CA  TYR A  26 "
      pdb=" C   TYR A  26 "
      pdb=" N   SER A  27 "
    ideal   model   delta    sigma   weight residual
   116.20  115.11    1.09 2.00e+00 2.50e-01 2.96e-01
angle pdb=" N   SER A  17 "
      pdb=" CA  SER A  17 "
      pdb=" CB  SER A  17 "
    ideal   model   delta    sigma   weight residual
   110.50  109.58    0.92 1.70e+00 3.46e-01 2.96e-01
angle pdb=" C   ASP A  36 "
      pdb=" N   LEU A  37 "
      pdb=" CA  LEU A  37 "
    ideal   model   delta    sigma   weight residual
   122.86  122.03    0.83 1.53e+00 4.27e-01 2.94e-01
angle pdb=" C   SER A   9 "
      pdb=" N   GLN A  10 "
      pdb=" CA  GLN A  10 "
    ideal   model   delta    sigma   weight residual
   122.86  122.03    0.83 1.53e+00 4.27e-01 2.94e-01
angle pdb=" O   GLN A  72 "
      pdb=" C   GLN A  72 "
      pdb=" N   PHE A  73 "
    ideal   model   delta    sigma   weight residual
   122.37  123.12   -0.75 1.38e+00 5.25e-01 2.94e-01
angle pdb=" N   ILE A   6 "
      pdb=" CA  ILE A   6 "
      pdb=" CB  ILE A   6 "
    ideal   model   delta    sigma   weight residual
   111.46  112.14   -0.68 1.26e+00 6.30e-01 2.92e-01
angle pdb=" C   PHE A  68 "
      pdb=" CA  PHE A  68 "
      pdb=" CB  PHE A  68 "
    ideal   model   delta    sigma   weight residual
   109.38  108.42    0.96 1.80e+00 3.09e-01 2.86e-01
angle pdb=" CA  LEU A  44 "
      pdb=" CB  LEU A  44 "
      pdb=" CG  LEU A  44 "
    ideal   model   delta    sigma   weight residual
   116.30  114.43    1.87 3.50e+00 8.16e-02 2.86e-01
angle pdb=" C   TYR A  34 "
      pdb=" CA  TYR A  34 "
      pdb=" CB  TYR A  34 "
    ideal   model   delta    sigma   weight residual
   109.72  108.80    0.92 1.73e+00 3.34e-01 2.86e-01
angle pdb=" N   VAL A  45 "
      pdb=" CA  VAL A  45 "
      pdb=" CB  VAL A  45 "
    ideal   model   delta    sigma   weight residual
   111.45  112.32   -0.87 1.64e+00 3.72e-01 2.84e-01
angle pdb=" O   LEU A  28 "
      pdb=" C   LEU A  28 "
      pdb=" N   ASN A  29 "
    ideal   model   delta    sigma   weight residual
   123.23  122.55    0.68 1.30e+00 5.92e-01 2.70e-01
angle pdb=" CA  LEU A  37 "
      pdb=" C   LEU A  37 "
      pdb=" O   LEU A  37 "
    ideal   model   delta    sigma   weight residual
   120.55  119.92    0.63 1.21e+00 6.83e-01 2.68e-01
angle pdb=" O   HIS A  64 "
      pdb=" C   HIS A  64 "
      pdb=" N   LEU A  65 "
    ideal   model   delta    sigma   weight residual
   123.06  122.48    0.58 1.12e+00 7.97e-01 2.67e-01
angle pdb=" N   GLU A  40 "
      pdb=" CA  GLU A  40 "
      pdb=" CB  GLU A  40 "
    ideal   model   delta    sigma   weight residual
   110.12  110.88   -0.76 1.47e+00 4.63e-01 2.66e-01
angle pdb=" CB  ASP A  79 "
      pdb=" CG  ASP A  79 "
      pdb=" OD1 ASP A  79 "
    ideal   model   delta    sigma   weight residual
   118.40  119.58   -1.18 2.30e+00 1.89e-01 2.64e-01
angle pdb=" CA  LEU A  44 "
      pdb=" C   LEU A  44 "
      pdb=" O   LEU A  44 "
    ideal   model   delta    sigma   weight residual
   120.92  120.33    0.59 1.14e+00 7.69e-01 2.64e-01
angle pdb=" O   GLN A  31 "
      pdb=" C   GLN A  31 "
      pdb=" N   LEU A  32 "
    ideal   model   delta    sigma   weight residual
   123.15  122.49    0.66 1.30e+00 5.92e-01 2.60e-01
angle pdb=" O   PHE A  13 "
      pdb=" C   PHE A  13 "
      pdb=" N   THR A  14 "
    ideal   model   delta    sigma   weight residual
   123.11  122.43    0.68 1.34e+00 5.57e-01 2.58e-01
angle pdb=" CA  VAL A  45 "
      pdb=" C   VAL A  45 "
      pdb=" O   VAL A  45 "
    ideal   model   delta    sigma   weight residual
   120.76  121.32   -0.56 1.10e+00 8.26e-01 2.56e-01
angle pdb=" C   SER A  75 "
      pdb=" N   LEU A  76 "
      pdb=" CA  LEU A  76 "
    ideal   model   delta    sigma   weight residual
   120.95  121.66   -0.71 1.40e+00 5.10e-01 2.55e-01
angle pdb=" CB  ARG A  82 "
      pdb=" CG  ARG A  82 "
      pdb=" CD  ARG A  82 "
    ideal   model   delta    sigma   weight residual
   111.30  112.46   -1.16 2.30e+00 1.89e-01 2.55e-01
angle pdb=" CA  PRO A  58 "
      pdb=" C   PRO A  58 "
      pdb=" N   GLY A  59 "
    ideal   model   delta    sigma   weight residual
   115.67  116.33   -0.66 1.30e+00 5.92e-01 2.54e-01
angle pdb=" O   LEU A  44 "
      pdb=" C   LEU A  44 "
      pdb=" N   VAL A  45 "
    ideal   model   delta    sigma   weight residual
   122.95  123.57   -0.62 1.24e+00 6.50e-01 2.54e-01
angle pdb=" C   TYR A  41 "
      pdb=" CA  TYR A  41 "
      pdb=" CB  TYR A  41 "
    ideal   model   delta    sigma   weight residual
   109.32  110.17   -0.85 1.71e+00 3.42e-01 2.50e-01
angle pdb=" N   LEU A  60 "
      pdb=" CA  LEU A  60 "
      pdb=" CB  LEU A  60 "
    ideal   model   delta    sigma   weight residual
   110.57  109.79    0.78 1.57e+00 4.06e-01 2.49e-01
angle pdb=" CA  LEU A  76 "
      pdb=" CB  LEU A  76 "
      pdb=" CG  LEU A  76 "
    ideal   model   delta    sigma   weight residual
   116.30  118.03   -1.73 3.50e+00 8.16e-02 2.44e-01
angle pdb=" N   LYS A   3 "
      pdb=" CA  LYS A   3 "
      pdb=" CB  LYS A   3 "
    ideal   model   delta    sigma   weight residual
   110.43  109.63    0.80 1.63e+00 3.76e-01 2.41e-01
angle pdb=" O   LEU A  83 "
      pdb=" C   LEU A  83 "
      pdb=" N   VAL A  84 "
    ideal   model   delta    sigma   weight residual
   123.16  122.55    0.61 1.26e+00 6.30e-01 2.38e-01
angle pdb=" N   PRO A  85 "
      pdb=" CA  PRO A  85 "
      pdb=" CB  PRO A  85 "
    ideal   model   delta    sigma   weight residual
   103.00  103.53   -0.53 1.10e+00 8.26e-01 2.34e-01
angle pdb=" CA  PHE A  13 "
      pdb=" C   PHE A  13 "
      pdb=" N   THR A  14 "
    ideal   model   delta    sigma   weight residual
   115.36  116.11   -0.75 1.56e+00 4.11e-01 2.33e-01
angle pdb=" CA  ILE A   2 "
      pdb=" CB  ILE A   2 "
      pdb=" CG1 ILE A   2 "
    ideal   model   delta    sigma   weight residual
   110.40  109.58    0.82 1.70e+00 3.46e-01 2.32e-01
angle pdb=" C   ALA A  55 "
      pdb=" CA  ALA A  55 "
      pdb=" CB  ALA A  55 "
    ideal   model   delta    sigma   weight residual
   109.65  110.47   -0.82 1.71e+00 3.42e-01 2.32e-01
angle pdb=" N   ASN A  29 "
      pdb=" CA  ASN A  29 "
      pdb=" CB  ASN A  29 "
    ideal   model   delta    sigma   weight residual
   110.57  109.82    0.75 1.57e+00 4.06e-01 2.30e-01
angle pdb=" CB  LYS A  69 "
      pdb=" CG  LYS A  69 "
      pdb=" CD  LYS A  69 "
    ideal   model   delta    sigma   weight residual
   111.30  112.40   -1.10 2.30e+00 1.89e-01 2.29e-01
angle pdb=" O   LEU A  32 "
      pdb=" C   LEU A  32 "
      pdb=" N   CYS A  33 "
    ideal   model   delta    sigma   weight residual
   122.97  123.63   -0.66 1.39e+00 5.18e-01 2.27e-01
angle pdb=" C   THR A  62 "
      pdb=" CA  THR A  62 "
      pdb=" CB  THR A  62 "
    ideal   model   delta    sigma   weight residual
   111.11  112.11   -1.00 2.10e+00 2.27e-01 2.25e-01
angle pdb=" CE2 TYR A  34 "
      pdb=" CZ  TYR A  34 "
      pdb=" OH  TYR A  34 "
    ideal   model   delta    sigma   weight residual
   119.90  118.48    1.42 3.00e+00 1.11e-01 2.24e-01
angle pdb=" O   TYR A  41 "
      pdb=" C   TYR A  41 "
      pdb=" N   PRO A  42 "
    ideal   model   delta    sigma   weight residual
   121.71  122.01   -0.30 6.40e-01 2.44e+00 2.23e-01
angle pdb=" CA  THR A  48 "
      pdb=" CB  THR A  48 "
      pdb=" OG1 THR A  48 "
    ideal   model   delta    sigma   weight residual
   109.60  108.89    0.71 1.50e+00 4.44e-01 2.23e-01
angle pdb=" C   ALA A  57 "
      pdb=" CA  ALA A  57 "
      pdb=" CB  ALA A  57 "
    ideal   model   delta    sigma   weight residual
   109.45  110.30   -0.85 1.81e+00 3.05e-01 2.23e-01
angle pdb=" N   PRO A  54 "
      pdb=" CD  PRO A  54 "
      pdb=" CG  PRO A  54 "
    ideal   model   delta    sigma   weight residual
   103.20  102.49    0.71 1.50e+00 4.44e-01 2.22e-01
angle pdb=" CB  ASP A  36 "
      pdb=" CG  ASP A  36 "
      pdb=" OD2 ASP A  36 "
    ideal   model   delta    sigma   weight residual
   118.40  117.32    1.08 2.30e+00 1.89e-01 2.22e-01
angle pdb=" CB  TYR A  26 "
      pdb=" CG  TYR A  26 "
      pdb=" CD1 TYR A  26 "
    ideal   model   delta    sigma   weight residual
   120.80  121.51   -0.71 1.50e+00 4.44e-01 2.21e-01
angle pdb=" CA  VAL A  35 "
      pdb=" CB  VAL A  35 "
      pdb=" CG2 VAL A  35 "
    ideal   model   delta    sigma   weight residual
   110.40  109.60    0.80 1.70e+00 3.46e-01 2.21e-01
angle pdb=" CA  PRO A  85 "
      pdb=" CB  PRO A  85 "
      pdb=" CG  PRO A  85 "
    ideal   model   delta    sigma   weight residual
   104.50  105.38   -0.88 1.90e+00 2.77e-01 2.15e-01
angle pdb=" CA  VAL A  63 "
      pdb=" CB  VAL A  63 "
      pdb=" CG1 VAL A  63 "
    ideal   model   delta    sigma   weight residual
   110.40  111.19   -0.79 1.70e+00 3.46e-01 2.14e-01
angle pdb=" CA  LEU A  65 "
      pdb=" C   LEU A  65 "
      pdb=" N   SER A  66 "
    ideal   model   delta    sigma   weight residual
   117.63  118.21   -0.58 1.25e+00 6.40e-01 2.13e-01
angle pdb=" N   GLN A  72 "
      pdb=" CA  GLN A  72 "
      pdb=" CB  GLN A  72 "
    ideal   model   delta    sigma   weight residual
   110.44  111.14   -0.70 1.53e+00 4.27e-01 2.12e-01
angle pdb=" C   GLN A  12 "
      pdb=" CA  GLN A  12 "
      pdb=" CB  GLN A  12 "
    ideal   model   delta    sigma   weight residual
   109.66  108.77    0.89 1.94e+00 2.66e-01 2.11e-01
angle pdb=" N   PHE A  73 "
      pdb=" CA  PHE A  73 "
      pdb=" CB  PHE A  73 "
    ideal   model   delta    sigma   weight residual
   110.92  111.65   -0.73 1.60e+00 3.91e-01 2.10e-01
angle pdb=" O   VAL A  43 "
      pdb=" C   VAL A  43 "
      pdb=" N   LEU A  44 "
    ideal   model   delta    sigma   weight residual
   122.69  123.21   -0.52 1.14e+00 7.69e-01 2.09e-01
angle pdb=" CA  GLN A  72 "
      pdb=" C   GLN A  72 "
      pdb=" O   GLN A  72 "
    ideal   model   delta    sigma   weight residual
   119.28  119.83   -0.55 1.21e+00 6.83e-01 2.08e-01
angle pdb=" CA  GLY A  71 "
      pdb=" C   GLY A  71 "
      pdb=" O   GLY A  71 "
    ideal   model   delta    sigma   weight residual
   120.57  121.36   -0.79 1.74e+00 3.30e-01 2.07e-01
angle pdb=" CA  LEU A  28 "
      pdb=" C   LEU A  28 "
      pdb=" O   LEU A  28 "
    ideal   model   delta    sigma   weight residual
   120.70  120.21    0.49 1.08e+00 8.57e-01 2.05e-01
angle pdb=" C   VAL A  70 "
      pdb=" CA  VAL A  70 "
      pdb=" CB  VAL A  70 "
    ideal   model   delta    sigma   weight residual
   111.25  111.82   -0.57 1.27e+00 6.20e-01 2.02e-01
angle pdb=" O   LEU A  65 "
      pdb=" C   LEU A  65 "
      pdb=" N   SER A  66 "
    ideal   model   delta    sigma   weight residual
   122.22  122.75   -0.53 1.17e+00 7.31e-01 2.02e-01
angle pdb=" N   TYR A  34 "
      pdb=" CA  TYR A  34 "
      pdb=" CB  TYR A  34 "
    ideal   model   delta    sigma   weight residual
   110.57  111.28   -0.71 1.57e+00 4.06e-01 2.02e-01
angle pdb=" CA  ASN A  29 "
      pdb=" C   ASN A  29 "
      pdb=" O   ASN A  29 "
    ideal   model   delta    sigma   weight residual
   120.38  120.87   -0.49 1.09e+00 8.42e-01 1.99e-01
angle pdb=" CA  ASP A  79 "
      pdb=" C   ASP A  79 "
      pdb=" N   ARG A  80 "
    ideal   model   delta    sigma   weight residual
   117.07  116.53    0.54 1.21e+00 6.83e-01 1.98e-01
angle pdb=" C   GLU A  40 "
      pdb=" CA  GLU A  40 "
      pdb=" CB  GLU A  40 "
    ideal   model   delta    sigma   weight residual
   110.79  110.05    0.74 1.66e+00 3.63e-01 1.98e-01
angle pdb=" O   GLU A  30 "
      pdb=" C   GLU A  30 "
      pdb=" N   GLN A  31 "
    ideal   model   delta    sigma   weight residual
   123.23  122.65    0.58 1.30e+00 5.92e-01 1.98e-01
angle pdb=" CA  GLU A  30 "
      pdb=" C   GLU A  30 "
      pdb=" O   GLU A  30 "
    ideal   model   delta    sigma   weight residual
   120.70  121.17   -0.47 1.08e+00 8.57e-01 1.88e-01
angle pdb=" CG  TYR A  34 "
      pdb=" CD2 TYR A  34 "
      pdb=" CE2 TYR A  34 "
    ideal   model   delta    sigma   weight residual
   121.20  120.55    0.65 1.50e+00 4.44e-01 1.88e-01
angle pdb=" CA  LYS A  46 "
      pdb=" CB  LYS A  46 "
      pdb=" CG  LYS A  46 "
    ideal   model   delta    sigma   weight residual
   114.10  113.24    0.86 2.00e+00 2.50e-01 1.86e-01
angle pdb=" CB  ARG A  80 "
      pdb=" CG  ARG A  80 "
      pdb=" CD  ARG A  80 "
    ideal   model   delta    sigma   weight residual
   111.30  110.31    0.99 2.30e+00 1.89e-01 1.85e-01
angle pdb=" N   VAL A  70 "
      pdb=" CA  VAL A  70 "
      pdb=" CB  VAL A  70 "
    ideal   model   delta    sigma   weight residual
   111.31  110.79    0.52 1.23e+00 6.61e-01 1.80e-01
angle pdb=" N   THR A  62 "
      pdb=" CA  THR A  62 "
      pdb=" CB  THR A  62 "
    ideal   model   delta    sigma   weight residual
   111.22  110.55    0.67 1.58e+00 4.01e-01 1.79e-01
angle pdb=" CA  PHE A  68 "
      pdb=" C   PHE A  68 "
      pdb=" O   PHE A  68 "
    ideal   model   delta    sigma   weight residual
   120.71  120.26    0.45 1.06e+00 8.90e-01 1.78e-01
angle pdb=" CE1 TYR A  34 "
      pdb=" CZ  TYR A  34 "
      pdb=" OH  TYR A  34 "
    ideal   model   delta    sigma   weight residual
   119.90  121.16   -1.26 3.00e+00 1.11e-01 1.77e-01
angle pdb=" CA  LYS A  46 "
      pdb=" C   LYS A  46 "
      pdb=" O   LYS A  46 "
    ideal   model   delta    sigma   weight residual
   120.43  120.89   -0.46 1.09e+00 8.42e-01 1.76e-01
angle pdb=" CA  PRO A  42 "
      pdb=" N   PRO A  42 "
      pdb=" CD  PRO A  42 "
    ideal   model   delta    sigma   weight residual
   112.00  112.59   -0.59 1.40e+00 5.10e-01 1.76e-01
angle pdb=" CG1 VAL A  43 "
      pdb=" CB  VAL A  43 "
      pdb=" CG2 VAL A  43 "
    ideal   model   delta    sigma   weight residual
   110.80  111.72   -0.92 2.20e+00 2.07e-01 1.74e-01
angle pdb=" N   VAL A   4 "
      pdb=" CA  VAL A   4 "
      pdb=" CB  VAL A   4 "
    ideal   model   delta    sigma   weight residual
   111.44  112.12   -0.68 1.64e+00 3.72e-01 1.72e-01
angle pdb=" CA  SER A  67 "
      pdb=" C   SER A  67 "
      pdb=" N   PHE A  68 "
    ideal   model   delta    sigma   weight residual
   118.14  117.60    0.54 1.31e+00 5.83e-01 1.71e-01
angle pdb=" CA  VAL A  84 "
      pdb=" CB  VAL A  84 "
      pdb=" CG2 VAL A  84 "
    ideal   model   delta    sigma   weight residual
   110.40  111.10   -0.70 1.70e+00 3.46e-01 1.71e-01
angle pdb=" N   VAL A  84 "
      pdb=" CA  VAL A  84 "
      pdb=" C   VAL A  84 "
    ideal   model   delta    sigma   weight residual
   108.88  107.99    0.89 2.16e+00 2.14e-01 1.68e-01
angle pdb=" C   VAL A  84 "
      pdb=" CA  VAL A  84 "
      pdb=" CB  VAL A  84 "
    ideal   model   delta    sigma   weight residual
   111.36  110.61    0.75 1.82e+00 3.02e-01 1.68e-01
angle pdb=" CA  LYS A   7 "
      pdb=" C   LYS A   7 "
      pdb=" N   PRO A   8 "
    ideal   model   delta    sigma   weight residual
   117.48  117.01    0.47 1.15e+00 7.56e-01 1.68e-01
angle pdb=" CA  GLU A  30 "
      pdb=" CB  GLU A  30 "
      pdb=" CG  GLU A  30 "
    ideal   model   delta    sigma   weight residual
   114.10  114.92   -0.82 2.00e+00 2.50e-01 1.67e-01
angle pdb=" N   LEU A  32 "
      pdb=" CA  LEU A  32 "
      pdb=" CB  LEU A  32 "
    ideal   model   delta    sigma   weight residual
   110.70  110.09    0.61 1.49e+00 4.50e-01 1.66e-01
angle pdb=" CB  ILE A   6 "
      pdb=" CG1 ILE A   6 "
      pdb=" CD1 ILE A   6 "
    ideal   model   delta    sigma   weight residual
   113.80  114.65   -0.85 2.10e+00 2.27e-01 1.66e-01
angle pdb=" C   SER A  75 "
      pdb=" CA  SER A  75 "
      pdb=" CB  SER A  75 "
    ideal   model   delta    sigma   weight residual
   109.83  109.12    0.71 1.75e+00 3.27e-01 1.65e-01
angle pdb=" CA  VAL A  43 "
      pdb=" CB  VAL A  43 "
      pdb=" CG1 VAL A  43 "
    ideal   model   delta    sigma   weight residual
   110.40  109.71    0.69 1.70e+00 3.46e-01 1.64e-01
angle pdb=" O   SER A   9 "
      pdb=" C   SER A   9 "
      pdb=" N   GLN A  10 "
    ideal   model   delta    sigma   weight residual
   122.43  121.84    0.59 1.46e+00 4.69e-01 1.64e-01
angle pdb=" CA  GLN A  12 "
      pdb=" CB  GLN A  12 "
      pdb=" CG  GLN A  12 "
    ideal   model   delta    sigma   weight residual
   114.10  114.91   -0.81 2.00e+00 2.50e-01 1.63e-01
angle pdb=" N   SER A  27 "
      pdb=" CA  SER A  27 "
      pdb=" CB  SER A  27 "
    ideal   model   delta    sigma   weight residual
   110.81  111.49   -0.68 1.68e+00 3.54e-01 1.62e-01
angle pdb=" O   ALA A  11 "
      pdb=" C   ALA A  11 "
      pdb=" N   GLN A  12 "
    ideal   model   delta    sigma   weight residual
   122.39  122.91   -0.52 1.29e+00 6.01e-01 1.62e-01
angle pdb=" CA  TYR A  41 "
      pdb=" C   TYR A  41 "
      pdb=" N   PRO A  42 "
    ideal   model   delta    sigma   weight residual
   117.71  117.34    0.37 9.20e-01 1.18e+00 1.61e-01
angle pdb=" C   ASP A  79 "
      pdb=" N   ARG A  80 "
      pdb=" CA  ARG A  80 "
    ideal   model   delta    sigma   weight residual
   121.89  122.58   -0.69 1.74e+00 3.30e-01 1.59e-01
angle pdb=" N   ALA A  55 "
      pdb=" CA  ALA A  55 "
      pdb=" CB  ALA A  55 "
    ideal   model   delta    sigma   weight residual
   109.97  110.55   -0.58 1.47e+00 4.63e-01 1.58e-01
angle pdb=" O   PHE A  68 "
      pdb=" C   PHE A  68 "
      pdb=" N   LYS A  69 "
    ideal   model   delta    sigma   weight residual
   123.21  122.71    0.50 1.27e+00 6.20e-01 1.57e-01
angle pdb=" O   LYS A  69 "
      pdb=" C   LYS A  69 "
      pdb=" N   VAL A  70 "
    ideal   model   delta    sigma   weight residual
   122.94  122.40    0.54 1.37e+00 5.33e-01 1.56e-01
angle pdb=" CA  ARG A  80 "
      pdb=" CB  ARG A  80 "
      pdb=" CG  ARG A  80 "
    ideal   model   delta    sigma   weight residual
   114.10  114.89   -0.79 2.00e+00 2.50e-01 1.55e-01
angle pdb=" CA  LEU A  83 "
      pdb=" C   LEU A  83 "
      pdb=" N   VAL A  84 "
    ideal   model   delta    sigma   weight residual
   115.60  116.18   -0.58 1.48e+00 4.57e-01 1.54e-01
angle pdb=" CD1 TYR A  41 "
      pdb=" CE1 TYR A  41 "
      pdb=" CZ  TYR A  41 "
    ideal   model   delta    sigma   weight residual
   119.60  118.90    0.70 1.80e+00 3.09e-01 1.53e-01
angle pdb=" CB  ASP A  79 "
      pdb=" CG  ASP A  79 "
      pdb=" OD2 ASP A  79 "
    ideal   model   delta    sigma   weight residual
   118.40  117.50    0.90 2.30e+00 1.89e-01 1.53e-01
angle pdb=" CA  ASP A  36 "
      pdb=" C   ASP A  36 "
      pdb=" O   ASP A  36 "
    ideal   model   delta    sigma   weight residual
   120.60  121.04   -0.44 1.13e+00 7.83e-01 1.51e-01
angle pdb=" CG  GLU A  40 "
      pdb=" CD  GLU A  40 "
      pdb=" OE2 GLU A  40 "
    ideal   model   delta    sigma   weight residual
   118.40  119.28   -0.88 2.30e+00 1.89e-01 1.47e-01
angle pdb=" CA  LEU A  81 "
      pdb=" CB  LEU A  81 "
      pdb=" CG  LEU A  81 "
    ideal   model   delta    sigma   weight residual
   116.30  117.64   -1.34 3.50e+00 8.16e-02 1.47e-01
angle pdb=" CG1 ILE A  47 "
      pdb=" CB  ILE A  47 "
      pdb=" CG2 ILE A  47 "
    ideal   model   delta    sigma   weight residual
   110.70  109.55    1.15 3.00e+00 1.11e-01 1.46e-01
angle pdb=" CB  TYR A  41 "
      pdb=" CG  TYR A  41 "
      pdb=" CD2 TYR A  41 "
    ideal   model   delta    sigma   weight residual
   120.80  120.23    0.57 1.50e+00 4.44e-01 1.45e-01
angle pdb=" C   LEU A  81 "
      pdb=" CA  LEU A  81 "
      pdb=" CB  LEU A  81 "
    ideal   model   delta    sigma   weight residual
   110.42  109.66    0.76 1.99e+00 2.53e-01 1.45e-01
angle pdb=" CA  ASP A  79 "
      pdb=" C   ASP A  79 "
      pdb=" O   ASP A  79 "
    ideal   model   delta    sigma   weight residual
   120.56  120.10    0.46 1.21e+00 6.83e-01 1.44e-01
angle pdb=" CG1 VAL A  45 "
      pdb=" CB  VAL A  45 "
      pdb=" CG2 VAL A  45 "
    ideal   model   delta    sigma   weight residual
   110.80  109.97    0.83 2.20e+00 2.07e-01 1.44e-01
angle pdb=" CB  LEU A  65 "
      pdb=" CG  LEU A  65 "
      pdb=" CD1 LEU A  65 "
    ideal   model   delta    sigma   weight residual
   110.70  109.59    1.11 3.00e+00 1.11e-01 1.37e-01
angle pdb=" CA  TYR A  56 "
      pdb=" C   TYR A  56 "
      pdb=" O   TYR A  56 "
    ideal   model   delta    sigma   weight residual
   121.16  121.57   -0.41 1.12e+00 7.97e-01 1.36e-01
angle pdb=" N   THR A  62 "
      pdb=" CA  THR A  62 "
      pdb=" C   THR A  62 "
    ideal   model   delta    sigma   weight residual
   109.18  109.69   -0.51 1.42e+00 4.96e-01 1.31e-01
angle pdb=" CA  GLU A  40 "
      pdb=" C   GLU A  40 "
      pdb=" O   GLU A  40 "
    ideal   model   delta    sigma   weight residual
   120.55  120.93   -0.38 1.06e+00 8.90e-01 1.31e-01
angle pdb=" C   LYS A  69 "
      pdb=" CA  LYS A  69 "
      pdb=" CB  LYS A  69 "
    ideal   model   delta    sigma   weight residual
   110.30  111.01   -0.71 1.98e+00 2.55e-01 1.29e-01
angle pdb=" CG  LYS A  69 "
      pdb=" CD  LYS A  69 "
      pdb=" CE  LYS A  69 "
    ideal   model   delta    sigma   weight residual
   111.30  112.12   -0.82 2.30e+00 1.89e-01 1.28e-01
angle pdb=" CA  ILE A  47 "
      pdb=" CB  ILE A  47 "
      pdb=" CG1 ILE A  47 "
    ideal   model   delta    sigma   weight residual
   110.40  111.01   -0.61 1.70e+00 3.46e-01 1.28e-01
angle pdb=" CA  VAL A  84 "
      pdb=" C   VAL A  84 "
      pdb=" O   VAL A  84 "
    ideal   model   delta    sigma   weight residual
   119.95  119.48    0.47 1.34e+00 5.57e-01 1.25e-01
angle pdb=" OG1 THR A  48 "
      pdb=" CB  THR A  48 "
      pdb=" CG2 THR A  48 "
    ideal   model   delta    sigma   weight residual
   109.30  108.60    0.70 2.00e+00 2.50e-01 1.21e-01
angle pdb=" CD  LYS A   3 "
      pdb=" CE  LYS A   3 "
      pdb=" NZ  LYS A   3 "
    ideal   model   delta    sigma   weight residual
   111.90  113.01   -1.11 3.20e+00 9.77e-02 1.20e-01
angle pdb=" CB  LEU A  32 "
      pdb=" CG  LEU A  32 "
      pdb=" CD2 LEU A  32 "
    ideal   model   delta    sigma   weight residual
   110.70  111.73   -1.03 3.00e+00 1.11e-01 1.19e-01
angle pdb=" C   GLU A  30 "
      pdb=" CA  GLU A  30 "
      pdb=" CB  GLU A  30 "
    ideal   model   delta    sigma   weight residual
   109.37  108.71    0.66 1.91e+00 2.74e-01 1.19e-01
angle pdb=" O   THR A  15 "
      pdb=" C   THR A  15 "
      pdb=" N   ARG A  16 "
    ideal   model   delta    sigma   weight residual
   123.31  123.71   -0.40 1.17e+00 7.31e-01 1.19e-01
angle pdb=" CD1 LEU A  32 "
      pdb=" CG  LEU A  32 "
      pdb=" CD2 LEU A  32 "
    ideal   model   delta    sigma   weight residual
   110.80  111.56   -0.76 2.20e+00 2.07e-01 1.18e-01
angle pdb=" C   LEU A  83 "
      pdb=" N   VAL A  84 "
      pdb=" CA  VAL A  84 "
    ideal   model   delta    sigma   weight residual
   122.13  121.50    0.63 1.85e+00 2.92e-01 1.18e-01
angle pdb=" CA  ARG A  16 "
      pdb=" CB  ARG A  16 "
      pdb=" CG  ARG A  16 "
    ideal   model   delta    sigma   weight residual
   114.10  114.78   -0.68 2.00e+00 2.50e-01 1.17e-01
angle pdb=" CA  VAL A  43 "
      pdb=" C   VAL A  43 "
      pdb=" N   LEU A  44 "
    ideal   model   delta    sigma   weight residual
   115.78  115.29    0.49 1.45e+00 4.76e-01 1.16e-01
angle pdb=" C   LEU A  83 "
      pdb=" CA  LEU A  83 "
      pdb=" CB  LEU A  83 "
    ideal   model   delta    sigma   weight residual
   109.37  108.75    0.62 1.83e+00 2.99e-01 1.16e-01
angle pdb=" CG1 ILE A  78 "
      pdb=" CB  ILE A  78 "
      pdb=" CG2 ILE A  78 "
    ideal   model   delta    sigma   weight residual
   110.70  109.69    1.01 3.00e+00 1.11e-01 1.13e-01
angle pdb=" CG  GLU A  30 "
      pdb=" CD  GLU A  30 "
      pdb=" OE1 GLU A  30 "
    ideal   model   delta    sigma   weight residual
   118.40  119.17   -0.77 2.30e+00 1.89e-01 1.13e-01
angle pdb=" O   GLY A  38 "
      pdb=" C   GLY A  38 "
      pdb=" N   ASN A  39 "
    ideal   model   delta    sigma   weight residual
   122.39  122.81   -0.42 1.27e+00 6.20e-01 1.12e-01
angle pdb=" CA  LEU A  28 "
      pdb=" CB  LEU A  28 "
      pdb=" CG  LEU A  28 "
    ideal   model   delta    sigma   weight residual
   116.30  117.47   -1.17 3.50e+00 8.16e-02 1.12e-01
angle pdb=" C   TYR A  26 "
      pdb=" CA  TYR A  26 "
      pdb=" CB  TYR A  26 "
    ideal   model   delta    sigma   weight residual
   110.10  109.47    0.63 1.90e+00 2.77e-01 1.11e-01
angle pdb=" N   ARG A  80 "
      pdb=" CA  ARG A  80 "
      pdb=" C   ARG A  80 "
    ideal   model   delta    sigma   weight residual
   108.48  107.88    0.60 1.80e+00 3.09e-01 1.11e-01
angle pdb=" N   GLU A  30 "
      pdb=" CA  GLU A  30 "
      pdb=" CB  GLU A  30 "
    ideal   model   delta    sigma   weight residual
   110.83  110.25    0.58 1.74e+00 3.30e-01 1.11e-01
angle pdb=" CG  ARG A  82 "
      pdb=" CD  ARG A  82 "
      pdb=" NE  ARG A  82 "
    ideal   model   delta    sigma   weight residual
   112.00  111.27    0.73 2.20e+00 2.07e-01 1.10e-01
angle pdb=" CB  LEU A  81 "
      pdb=" CG  LEU A  81 "
      pdb=" CD2 LEU A  81 "
    ideal   model   delta    sigma   weight residual
   110.70  109.73    0.97 3.00e+00 1.11e-01 1.06e-01
angle pdb=" CA  ALA A  55 "
      pdb=" C   ALA A  55 "
      pdb=" O   ALA A  55 "
    ideal   model   delta    sigma   weight residual
   121.16  120.80    0.36 1.12e+00 7.97e-01 1.03e-01
angle pdb=" CD1 LEU A  83 "
      pdb=" CG  LEU A  83 "
      pdb=" CD2 LEU A  83 "
    ideal   model   delta    sigma   weight residual
   110.80  111.50   -0.70 2.20e+00 2.07e-01 1.03e-01
angle pdb=" CB  PRO A  42 "
      pdb=" CG  PRO A  42 "
      pdb=" CD  PRO A  42 "
    ideal   model   delta    sigma   weight residual
   106.10  107.12   -1.02 3.20e+00 9.77e-02 1.02e-01
angle pdb=" N   GLN A  53 "
      pdb=" CA  GLN A  53 "
      pdb=" CB  GLN A  53 "
    ideal   model   delta    sigma   weight residual
   109.90  109.41    0.49 1.54e+00 4.22e-01 1.02e-01
angle pdb=" CA  LEU A  37 "
      pdb=" C   LEU A  37 "
      pdb=" N   GLY A  38 "
    ideal   model   delta    sigma   weight residual
   117.15  117.61   -0.46 1.44e+00 4.82e-01 1.02e-01
angle pdb=" CB  ASP A  50 "
      pdb=" CG  ASP A  50 "
      pdb=" OD2 ASP A  50 "
    ideal   model   delta    sigma   weight residual
   118.40  117.67    0.73 2.30e+00 1.89e-01 1.02e-01
angle pdb=" CD1 LEU A  65 "
      pdb=" CG  LEU A  65 "
      pdb=" CD2 LEU A  65 "
    ideal   model   delta    sigma   weight residual
   110.80  111.50   -0.70 2.20e+00 2.07e-01 1.01e-01
angle pdb=" C   GLN A  10 "
      pdb=" CA  GLN A  10 "
      pdb=" CB  GLN A  10 "
    ideal   model   delta    sigma   weight residual
   111.13  111.64   -0.51 1.61e+00 3.86e-01 9.97e-02
angle pdb=" NH1 ARG A  82 "
      pdb=" CZ  ARG A  82 "
      pdb=" NH2 ARG A  82 "
    ideal   model   delta    sigma   weight residual
   119.30  119.70   -0.40 1.30e+00 5.92e-01 9.70e-02
angle pdb=" CA  TYR A  34 "
      pdb=" C   TYR A  34 "
      pdb=" O   TYR A  34 "
    ideal   model   delta    sigma   weight residual
   120.38  120.72   -0.34 1.09e+00 8.42e-01 9.65e-02
angle pdb=" N   SER A  66 "
      pdb=" CA  SER A  66 "
      pdb=" CB  SER A  66 "
    ideal   model   delta    sigma   weight residual
   110.32  109.76    0.56 1.82e+00 3.02e-01 9.51e-02
angle pdb=" CB  PHE A  68 "
      pdb=" CG  PHE A  68 "
      pdb=" CD2 PHE A  68 "
    ideal   model   delta    sigma   weight residual
   120.70  120.18    0.52 1.70e+00 3.46e-01 9.36e-02
angle pdb=" C   LEU A  49 "
      pdb=" CA  LEU A  49 "
      pdb=" CB  LEU A  49 "
    ideal   model   delta    sigma   weight residual
   109.62  110.17   -0.55 1.79e+00 3.12e-01 9.34e-02
angle pdb=" CA  GLU A  51 "
      pdb=" CB  GLU A  51 "
      pdb=" CG  GLU A  51 "
    ideal   model   delta    sigma   weight residual
   114.10  114.71   -0.61 2.00e+00 2.50e-01 9.32e-02
angle pdb=" C   SER A  17 "
      pdb=" CA  SER A  17 "
      pdb=" CB  SER A  17 "
    ideal   model   delta    sigma   weight residual
   110.10  109.52    0.58 1.90e+00 2.77e-01 9.27e-02
angle pdb=" CG  LYS A  46 "
      pdb=" CD  LYS A  46 "
      pdb=" CE  LYS A  46 "
    ideal   model   delta    sigma   weight residual
   111.30  110.60    0.70 2.30e+00 1.89e-01 9.21e-02
angle pdb=" OD1 ASP A  50 "
      pdb=" CG  ASP A  50 "
      pdb=" OD2 ASP A  50 "
    ideal   model   delta    sigma   weight residual
   122.90  123.62   -0.72 2.40e+00 1.74e-01 9.06e-02
angle pdb=" CB  LEU A  28 "
      pdb=" CG  LEU A  28 "
      pdb=" CD2 LEU A  28 "
    ideal   model   delta    sigma   weight residual
   110.70  109.80    0.90 3.00e+00 1.11e-01 9.04e-02
angle pdb=" CA  GLY A  71 "
      pdb=" C   GLY A  71 "
      pdb=" N   GLN A  72 "
    ideal   model   delta    sigma   weight residual
   116.69  117.30   -0.61 2.04e+00 2.40e-01 9.03e-02
angle pdb=" C   PRO A  85 "
      pdb=" CA  PRO A  85 "
      pdb=" CB  PRO A  85 "
    ideal   model   delta    sigma   weight residual
   110.10  110.67   -0.57 1.90e+00 2.77e-01 8.90e-02
angle pdb=" CG  GLU A   5 "
      pdb=" CD  GLU A   5 "
      pdb=" OE1 GLU A   5 "
    ideal   model   delta    sigma   weight residual
   118.40  119.08   -0.68 2.30e+00 1.89e-01 8.85e-02
angle pdb=" C   GLN A  53 "
      pdb=" N   PRO A  54 "
      pdb=" CD  PRO A  54 "
    ideal   model   delta    sigma   weight residual
   125.00  126.21   -1.21 4.10e+00 5.95e-02 8.73e-02
angle pdb=" CA  LYS A  46 "
      pdb=" C   LYS A  46 "
      pdb=" N   ILE A  47 "
    ideal   model   delta    sigma   weight residual
   116.25  115.89    0.36 1.23e+00 6.61e-01 8.65e-02
angle pdb=" CA  SER A   9 "
      pdb=" CB  SER A   9 "
      pdb=" OG  SER A   9 "
    ideal   model   delta    sigma   weight residual
   111.10  111.68   -0.58 2.00e+00 2.50e-01 8.55e-02
angle pdb=" CG  GLU A   5 "
      pdb=" CD  GLU A   5 "
      pdb=" OE2 GLU A   5 "
    ideal   model   delta    sigma   weight residual
   118.40  117.74    0.66 2.30e+00 1.89e-01 8.34e-02
angle pdb=" C   LEU A  32 "
      pdb=" N   CYS A  33 "
      pdb=" CA  CYS A  33 "
    ideal   model   delta    sigma   weight residual
   122.09  122.62   -0.53 1.86e+00 2.89e-01 8.20e-02
angle pdb=" CA  THR A  62 "
      pdb=" CB  THR A  62 "
      pdb=" OG1 THR A  62 "
    ideal   model   delta    sigma   weight residual
   109.60  109.17    0.43 1.50e+00 4.44e-01 8.12e-02
angle pdb=" CA  ASP A  36 "
      pdb=" C   ASP A  36 "
      pdb=" N   LEU A  37 "
    ideal   model   delta    sigma   weight residual
   116.54  116.15    0.39 1.36e+00 5.41e-01 8.10e-02
angle pdb=" N   LEU A  44 "
      pdb=" CA  LEU A  44 "
      pdb=" CB  LEU A  44 "
    ideal   model   delta    sigma   weight residual
   109.69  110.12   -0.43 1.53e+00 4.27e-01 8.02e-02
angle pdb=" C   VAL A  45 "
      pdb=" CA  VAL A  45 "
      pdb=" CB  VAL A  45 "
    ideal   model   delta    sigma   weight residual
   110.71  111.20   -0.49 1.73e+00 3.34e-01 7.99e-02
angle pdb=" CA  PRO A  42 "
      pdb=" CB  PRO A  42 "
      pdb=" CG  PRO A  42 "
    ideal   model   delta    sigma   weight residual
   104.50  105.04   -0.54 1.90e+00 2.77e-01 7.96e-02
angle pdb=" CE1 TYR A  41 "
      pdb=" CZ  TYR A  41 "
      pdb=" CE2 TYR A  41 "
    ideal   model   delta    sigma   weight residual
   120.30  120.86   -0.56 2.00e+00 2.50e-01 7.92e-02
angle pdb=" CB  PRO A  58 "
      pdb=" CG  PRO A  58 "
      pdb=" CD  PRO A  58 "
    ideal   model   delta    sigma   weight residual
   106.10  105.20    0.90 3.20e+00 9.77e-02 7.92e-02
angle pdb=" C   LEU A  65 "
      pdb=" CA  LEU A  65 "
      pdb=" CB  LEU A  65 "
    ideal   model   delta    sigma   weight residual
   110.63  110.11    0.52 1.85e+00 2.92e-01 7.81e-02
angle pdb=" CA  GLU A   5 "
      pdb=" C   GLU A   5 "
      pdb=" N   ILE A   6 "
    ideal   model   delta    sigma   weight residual
   116.00  115.59    0.41 1.50e+00 4.44e-01 7.61e-02
angle pdb=" C   ASP A  50 "
      pdb=" N   GLU A  51 "
      pdb=" CA  GLU A  51 "
    ideal   model   delta    sigma   weight residual
   121.50  121.11    0.39 1.43e+00 4.89e-01 7.53e-02
angle pdb=" CB  LYS A   3 "
      pdb=" CG  LYS A   3 "
      pdb=" CD  LYS A   3 "
    ideal   model   delta    sigma   weight residual
   111.30  110.67    0.63 2.30e+00 1.89e-01 7.40e-02
angle pdb=" CA  VAL A   4 "
      pdb=" C   VAL A   4 "
      pdb=" O   VAL A   4 "
    ideal   model   delta    sigma   weight residual
   120.67  120.97   -0.30 1.12e+00 7.97e-01 7.36e-02
angle pdb=" CB  LEU A  83 "
      pdb=" CG  LEU A  83 "
      pdb=" CD2 LEU A  83 "
    ideal   model   delta    sigma   weight residual
   110.70  111.51   -0.81 3.00e+00 1.11e-01 7.22e-02
angle pdb=" CG  TYR A  41 "
      pdb=" CD1 TYR A  41 "
      pdb=" CE1 TYR A  41 "
    ideal   model   delta    sigma   weight residual
   121.20  120.80    0.40 1.50e+00 4.44e-01 7.14e-02
angle pdb=" CA  ILE A  78 "
      pdb=" CB  ILE A  78 "
      pdb=" CG1 ILE A  78 "
    ideal   model   delta    sigma   weight residual
   110.40  109.95    0.45 1.70e+00 3.46e-01 6.96e-02
angle pdb=" CA  ALA A  11 "
      pdb=" C   ALA A  11 "
      pdb=" O   ALA A  11 "
    ideal   model   delta    sigma   weight residual
   119.43  119.75   -0.32 1.21e+00 6.83e-01 6.90e-02
angle pdb=" CA  PHE A  73 "
      pdb=" C   PHE A  73 "
      pdb=" O   PHE A  73 "
    ideal   model   delta    sigma   weight residual
   119.95  119.64    0.31 1.18e+00 7.18e-01 6.90e-02
angle pdb=" CD1 TYR A  34 "
      pdb=" CE1 TYR A  34 "
      pdb=" CZ  TYR A  34 "
    ideal   model   delta    sigma   weight residual
   119.60  120.07   -0.47 1.80e+00 3.09e-01 6.83e-02
angle pdb=" O   SER A  67 "
      pdb=" C   SER A  67 "
      pdb=" N   PHE A  68 "
    ideal   model   delta    sigma   weight residual
   122.43  122.09    0.34 1.34e+00 5.57e-01 6.57e-02
angle pdb=" O   PRO A  54 "
      pdb=" C   PRO A  54 "
      pdb=" N   ALA A  55 "
    ideal   model   delta    sigma   weight residual
   122.86  122.54    0.32 1.24e+00 6.50e-01 6.46e-02
angle pdb=" CG  LYS A   7 "
      pdb=" CD  LYS A   7 "
      pdb=" CE  LYS A   7 "
    ideal   model   delta    sigma   weight residual
   111.30  110.72    0.58 2.30e+00 1.89e-01 6.37e-02
angle pdb=" N   TYR A  41 "
      pdb=" CA  TYR A  41 "
      pdb=" CB  TYR A  41 "
    ideal   model   delta    sigma   weight residual
   111.18  110.73    0.45 1.80e+00 3.09e-01 6.33e-02
angle pdb=" O   GLU A   5 "
      pdb=" C   GLU A   5 "
      pdb=" N   ILE A   6 "
    ideal   model   delta    sigma   weight residual
   123.27  123.57   -0.30 1.22e+00 6.72e-01 6.08e-02
angle pdb=" N   VAL A  43 "
      pdb=" CA  VAL A  43 "
      pdb=" CB  VAL A  43 "
    ideal   model   delta    sigma   weight residual
   111.37  110.85    0.52 2.12e+00 2.22e-01 6.03e-02
angle pdb=" CB  PRO A  85 "
      pdb=" CG  PRO A  85 "
      pdb=" CD  PRO A  85 "
    ideal   model   delta    sigma   weight residual
   106.10  106.88   -0.78 3.20e+00 9.77e-02 6.01e-02
angle pdb=" CA  VAL A  45 "
      pdb=" CB  VAL A  45 "
      pdb=" CG2 VAL A  45 "
    ideal   model   delta    sigma   weight residual
   110.40  110.81   -0.41 1.70e+00 3.46e-01 5.89e-02
angle pdb=" N   ARG A  80 "
      pdb=" CA  ARG A  80 "
      pdb=" CB  ARG A  80 "
    ideal   model   delta    sigma   weight residual
   110.71  110.31    0.40 1.66e+00 3.63e-01 5.79e-02
angle pdb=" CA  SER A  17 "
      pdb=" CB  SER A  17 "
      pdb=" OG  SER A  17 "
    ideal   model   delta    sigma   weight residual
   111.10  110.62    0.48 2.00e+00 2.50e-01 5.78e-02
angle pdb=" C   ILE A  47 "
      pdb=" CA  ILE A  47 "
      pdb=" CB  ILE A  47 "
    ideal   model   delta    sigma   weight residual
   110.81  110.45    0.36 1.52e+00 4.33e-01 5.70e-02
angle pdb=" CA  LEU A  81 "
      pdb=" C   LEU A  81 "
      pdb=" N   ARG A  82 "
    ideal   model   delta    sigma   weight residual
   116.84  117.24   -0.40 1.71e+00 3.42e-01 5.49e-02
angle pdb=" CG1 ILE A   6 "
      pdb=" CB  ILE A   6 "
      pdb=" CG2 ILE A   6 "
    ideal   model   delta    sigma   weight residual
   110.70  111.40   -0.70 3.00e+00 1.11e-01 5.40e-02
angle pdb=" O   ILE A   2 "
      pdb=" C   ILE A   2 "
      pdb=" N   LYS A   3 "
    ideal   model   delta    sigma   weight residual
   123.00  123.37   -0.37 1.60e+00 3.91e-01 5.31e-02
angle pdb=" CA  LYS A   3 "
      pdb=" CB  LYS A   3 "
      pdb=" CG  LYS A   3 "
    ideal   model   delta    sigma   weight residual
   114.10  113.64    0.46 2.00e+00 2.50e-01 5.25e-02
angle pdb=" CA  GLN A  10 "
      pdb=" C   GLN A  10 "
      pdb=" N   ALA A  11 "
    ideal   model   delta    sigma   weight residual
   117.15  117.48   -0.33 1.44e+00 4.82e-01 5.21e-02
angle pdb=" CA  ASN A  39 "
      pdb=" CB  ASN A  39 "
      pdb=" CG  ASN A  39 "
    ideal   model   delta    sigma   weight residual
   112.60  112.83   -0.23 1.00e+00 1.00e+00 5.21e-02
angle pdb=" CA  ASP A  50 "
      pdb=" C   ASP A  50 "
      pdb=" O   ASP A  50 "
    ideal   model   delta    sigma   weight residual
   121.89  122.15   -0.26 1.17e+00 7.31e-01 5.12e-02
angle pdb=" CB  LYS A  46 "
      pdb=" CG  LYS A  46 "
      pdb=" CD  LYS A  46 "
    ideal   model   delta    sigma   weight residual
   111.30  110.79    0.51 2.30e+00 1.89e-01 4.92e-02
angle pdb=" NH1 ARG A  80 "
      pdb=" CZ  ARG A  80 "
      pdb=" NH2 ARG A  80 "
    ideal   model   delta    sigma   weight residual
   119.30  119.59   -0.29 1.30e+00 5.92e-01 4.92e-02
angle pdb=" C   THR A  48 "
      pdb=" N   LEU A  49 "
      pdb=" CA  LEU A  49 "
    ideal   model   delta    sigma   weight residual
   120.75  121.08   -0.33 1.51e+00 4.39e-01 4.84e-02
angle pdb=" C   ILE A  78 "
      pdb=" N   ASP A  79 "
      pdb=" CA  ASP A  79 "
    ideal   model   delta    sigma   weight residual
   121.81  122.21   -0.40 1.83e+00 2.99e-01 4.83e-02
angle pdb=" CB  PHE A  13 "
      pdb=" CG  PHE A  13 "
      pdb=" CD2 PHE A  13 "
    ideal   model   delta    sigma   weight residual
   120.70  120.33    0.37 1.70e+00 3.46e-01 4.79e-02
angle pdb=" CA  TYR A  56 "
      pdb=" C   TYR A  56 "
      pdb=" N   ALA A  57 "
    ideal   model   delta    sigma   weight residual
   115.88  115.60    0.28 1.28e+00 6.10e-01 4.75e-02
angle pdb=" C   VAL A  63 "
      pdb=" N   HIS A  64 "
      pdb=" CA  HIS A  64 "
    ideal   model   delta    sigma   weight residual
   122.07  121.70    0.37 1.71e+00 3.42e-01 4.74e-02
angle pdb=" C   GLU A  40 "
      pdb=" N   TYR A  41 "
      pdb=" CA  TYR A  41 "
    ideal   model   delta    sigma   weight residual
   123.11  123.50   -0.39 1.79e+00 3.12e-01 4.73e-02
angle pdb=" N   PRO A  85 "
      pdb=" CA  PRO A  85 "
      pdb=" C   PRO A  85 "
    ideal   model   delta    sigma   weight residual
   112.10  111.56    0.54 2.50e+00 1.60e-01 4.60e-02
angle pdb=" C   PRO A  58 "
      pdb=" N   GLY A  59 "
      pdb=" CA  GLY A  59 "
    ideal   model   delta    sigma   weight residual
   121.97  121.62    0.35 1.65e+00 3.67e-01 4.58e-02
angle pdb=" CD  ARG A  16 "
      pdb=" NE  ARG A  16 "
      pdb=" CZ  ARG A  16 "
    ideal   model   delta    sigma   weight residual
   124.40  124.70   -0.30 1.40e+00 5.10e-01 4.57e-02
angle pdb=" CB  TYR A  26 "
      pdb=" CG  TYR A  26 "
      pdb=" CD2 TYR A  26 "
    ideal   model   delta    sigma   weight residual
   120.80  120.48    0.32 1.50e+00 4.44e-01 4.55e-02
angle pdb=" OG1 THR A  14 "
      pdb=" CB  THR A  14 "
      pdb=" CG2 THR A  14 "
    ideal   model   delta    sigma   weight residual
   109.30  109.73   -0.43 2.00e+00 2.50e-01 4.54e-02
angle pdb=" CD2 TYR A  41 "
      pdb=" CE2 TYR A  41 "
      pdb=" CZ  TYR A  41 "
    ideal   model   delta    sigma   weight residual
   119.60  119.98   -0.38 1.80e+00 3.09e-01 4.53e-02
angle pdb=" CB  LEU A  60 "
      pdb=" CG  LEU A  60 "
      pdb=" CD2 LEU A  60 "
    ideal   model   delta    sigma   weight residual
   110.70  110.07    0.63 3.00e+00 1.11e-01 4.45e-02
angle pdb=" N   VAL A  70 "
      pdb=" CA  VAL A  70 "
      pdb=" C   VAL A  70 "
    ideal   model   delta    sigma   weight residual
   107.73  108.05   -0.32 1.56e+00 4.11e-01 4.32e-02
angle pdb=" O   LEU A  37 "
      pdb=" C   LEU A  37 "
      pdb=" N   GLY A  38 "
    ideal   model   delta    sigma   weight residual
   122.20  122.47   -0.27 1.28e+00 6.10e-01 4.32e-02
angle pdb=" N   ASN A  29 "
      pdb=" CA  ASN A  29 "
      pdb=" C   ASN A  29 "
    ideal   model   delta    sigma   weight residual
   109.07  109.40   -0.33 1.61e+00 3.86e-01 4.30e-02
angle pdb=" C   LYS A  46 "
      pdb=" N   ILE A  47 "
      pdb=" CA  ILE A  47 "
    ideal   model   delta    sigma   weight residual
   123.10  122.83    0.27 1.29e+00 6.01e-01 4.28e-02
angle pdb=" CA  PRO A  54 "
      pdb=" N   PRO A  54 "
      pdb=" CD  PRO A  54 "
    ideal   model   delta    sigma   weight residual
   112.00  112.29   -0.29 1.40e+00 5.10e-01 4.26e-02
angle pdb=" CA  SER A  17 "
      pdb=" C   SER A  17 "
      pdb=" O   SER A  17 "
    ideal   model   delta    sigma   weight residual
   120.80  120.45    0.35 1.70e+00 3.46e-01 4.21e-02
angle pdb=" CB  TYR A  61 "
      pdb=" CG  TYR A  61 "
      pdb=" CD1 TYR A  61 "
    ideal   model   delta    sigma   weight residual
   120.80  121.11   -0.31 1.50e+00 4.44e-01 4.18e-02
angle pdb=" CE1 TYR A  61 "
      pdb=" CZ  TYR A  61 "
      pdb=" CE2 TYR A  61 "
    ideal   model   delta    sigma   weight residual
   120.30  120.71   -0.41 2.00e+00 2.50e-01 4.18e-02
angle pdb=" N   VAL A  35 "
      pdb=" CA  VAL A  35 "
      pdb=" C   VAL A  35 "
    ideal   model   delta    sigma   weight residual
   108.17  108.45   -0.28 1.40e+00 5.10e-01 4.13e-02
angle pdb=" CG  GLN A  31 "
      pdb=" CD  GLN A  31 "
      pdb=" OE1 GLN A  31 "
    ideal   model   delta    sigma   weight residual
   120.80  121.21   -0.41 2.00e+00 2.50e-01 4.13e-02
angle pdb=" CE2 TYR A  61 "
      pdb=" CZ  TYR A  61 "
      pdb=" OH  TYR A  61 "
    ideal   model   delta    sigma   weight residual
   119.90  119.29    0.61 3.00e+00 1.11e-01 4.10e-02
angle pdb=" CB  GLU A  40 "
      pdb=" CG  GLU A  40 "
      pdb=" CD  GLU A  40 "
    ideal   model   delta    sigma   weight residual
   112.60  112.94   -0.34 1.70e+00 3.46e-01 4.01e-02
angle pdb=" CB  LEU A  28 "
      pdb=" CG  LEU A  28 "
      pdb=" CD1 LEU A  28 "
    ideal   model   delta    sigma   weight residual
   110.70  111.30   -0.60 3.00e+00 1.11e-01 3.99e-02
angle pdb=" CD  ARG A  80 "
      pdb=" NE  ARG A  80 "
      pdb=" CZ  ARG A  80 "
    ideal   model   delta    sigma   weight residual
   124.40  124.12    0.28 1.40e+00 5.10e-01 3.98e-02
angle pdb=" CB  GLU A   5 "
      pdb=" CG  GLU A   5 "
      pdb=" CD  GLU A   5 "
    ideal   model   delta    sigma   weight residual
   112.60  112.94   -0.34 1.70e+00 3.46e-01 3.96e-02
angle pdb=" OE1 GLU A  30 "
      pdb=" CD  GLU A  30 "
      pdb=" OE2 GLU A  30 "
    ideal   model   delta    sigma   weight residual
   122.90  122.42    0.48 2.40e+00 1.74e-01 3.95e-02
angle pdb=" OE1 GLN A  31 "
      pdb=" CD  GLN A  31 "
      pdb=" NE2 GLN A  31 "
    ideal   model   delta    sigma   weight residual
   122.60  122.40    0.20 1.00e+00 1.00e+00 3.91e-02
angle pdb=" C   ARG A  16 "
      pdb=" N   SER A  17 "
      pdb=" CA  SER A  17 "
    ideal   model   delta    sigma   weight residual
   121.70  121.35    0.35 1.80e+00 3.09e-01 3.86e-02
angle pdb=" CB  GLN A  10 "
      pdb=" CG  GLN A  10 "
      pdb=" CD  GLN A  10 "
    ideal   model   delta    sigma   weight residual
   112.60  112.27    0.33 1.70e+00 3.46e-01 3.79e-02
angle pdb=" CD1 PHE A  68 "
      pdb=" CE1 PHE A  68 "
      pdb=" CZ  PHE A  68 "
    ideal   model   delta    sigma   weight residual
   120.00  119.65    0.35 1.80e+00 3.09e-01 3.75e-02
angle pdb=" CG  TYR A  41 "
      pdb=" CD2 TYR A  41 "
      pdb=" CE2 TYR A  41 "
    ideal   model   delta    sigma   weight residual
   121.20  121.49   -0.29 1.50e+00 4.44e-01 3.69e-02
angle pdb=" OE1 GLU A  40 "
      pdb=" CD  GLU A  40 "
      pdb=" OE2 GLU A  40 "
    ideal   model   delta    sigma   weight residual
   122.90  122.44    0.46 2.40e+00 1.74e-01 3.66e-02
angle pdb=" CA  GLY A  59 "
      pdb=" C   GLY A  59 "
      pdb=" O   GLY A  59 "
    ideal   model   delta    sigma   weight residual
   121.02  120.80    0.22 1.17e+00 7.31e-01 3.66e-02
angle pdb=" CB  LEU A  76 "
      pdb=" CG  LEU A  76 "
      pdb=" CD2 LEU A  76 "
    ideal   model   delta    sigma   weight residual
   110.70  110.13    0.57 3.00e+00 1.11e-01 3.61e-02
angle pdb=" CG  GLN A  72 "
      pdb=" CD  GLN A  72 "
      pdb=" NE2 GLN A  72 "
    ideal   model   delta    sigma   weight residual
   116.40  116.12    0.28 1.50e+00 4.44e-01 3.43e-02
angle pdb=" CG  GLN A  72 "
      pdb=" CD  GLN A  72 "
      pdb=" OE1 GLN A  72 "
    ideal   model   delta    sigma   weight residual
   120.80  121.17   -0.37 2.00e+00 2.50e-01 3.39e-02
angle pdb=" CA  PRO A  54 "
      pdb=" CB  PRO A  54 "
      pdb=" CG  PRO A  54 "
    ideal   model   delta    sigma   weight residual
   104.50  104.85   -0.35 1.90e+00 2.77e-01 3.37e-02
angle pdb=" CA  ARG A  16 "
      pdb=" C   ARG A  16 "
      pdb=" O   ARG A  16 "
    ideal   model   delta    sigma   weight residual
   120.71  120.90   -0.19 1.06e+00 8.90e-01 3.36e-02
angle pdb=" N   LYS A  69 "
      pdb=" CA  LYS A  69 "
      pdb=" C   LYS A  69 "
    ideal   model   delta    sigma   weight residual
   109.41  109.13    0.28 1.52e+00 4.33e-01 3.35e-02
angle pdb=" O   GLN A  10 "
      pdb=" C   GLN A  10 "
      pdb=" N   ALA A  11 "
    ideal   model   delta    sigma   weight residual
   122.20  121.97    0.23 1.28e+00 6.10e-01 3.30e-02
angle pdb=" O   VAL A  63 "
      pdb=" C   VAL A  63 "
      pdb=" N   HIS A  64 "
    ideal   model   delta    sigma   weight residual
   122.95  122.74    0.21 1.14e+00 7.69e-01 3.28e-02
angle pdb=" CE2 TYR A  26 "
      pdb=" CZ  TYR A  26 "
      pdb=" OH  TYR A  26 "
    ideal   model   delta    sigma   weight residual
   119.90  119.36    0.54 3.00e+00 1.11e-01 3.27e-02
angle pdb=" O   LYS A   3 "
      pdb=" C   LYS A   3 "
      pdb=" N   VAL A   4 "
    ideal   model   delta    sigma   weight residual
   123.27  123.47   -0.20 1.13e+00 7.83e-01 3.22e-02
angle pdb=" CA  ILE A   2 "
      pdb=" C   ILE A   2 "
      pdb=" O   ILE A   2 "
    ideal   model   delta    sigma   weight residual
   120.80  120.50    0.30 1.70e+00 3.46e-01 3.21e-02
angle pdb=" O   PRO A  42 "
      pdb=" C   PRO A  42 "
      pdb=" N   VAL A  43 "
    ideal   model   delta    sigma   weight residual
   123.01  122.79    0.22 1.24e+00 6.50e-01 3.19e-02
angle pdb=" CD1 PHE A  13 "
      pdb=" CG  PHE A  13 "
      pdb=" CD2 PHE A  13 "
    ideal   model   delta    sigma   weight residual
   118.60  118.87   -0.27 1.50e+00 4.44e-01 3.16e-02
angle pdb=" CA  PHE A  73 "
      pdb=" C   PHE A  73 "
      pdb=" N   GLY A  74 "
    ideal   model   delta    sigma   weight residual
   117.71  117.94   -0.23 1.28e+00 6.10e-01 3.16e-02
angle pdb=" CG  TYR A  56 "
      pdb=" CD2 TYR A  56 "
      pdb=" CE2 TYR A  56 "
    ideal   model   delta    sigma   weight residual
   121.20  120.94    0.26 1.50e+00 4.44e-01 3.10e-02
angle pdb=" C   PRO A  58 "
      pdb=" CA  PRO A  58 "
      pdb=" CB  PRO A  58 "
    ideal   model   delta    sigma   weight residual
   111.56  111.78   -0.22 1.27e+00 6.20e-01 3.09e-02
angle pdb=" CA  LEU A  76 "
      pdb=" C   LEU A  76 "
      pdb=" N   MSE A  77 "
    ideal   model   delta    sigma   weight residual
   116.21  115.98    0.23 1.33e+00 5.65e-01 3.05e-02
angle pdb=" CG1 VAL A  84 "
      pdb=" CB  VAL A  84 "
      pdb=" CG2 VAL A  84 "
    ideal   model   delta    sigma   weight residual
   110.80  111.18   -0.38 2.20e+00 2.07e-01 3.04e-02
angle pdb=" CA  ILE A   2 "
      pdb=" CB  ILE A   2 "
      pdb=" CG2 ILE A   2 "
    ideal   model   delta    sigma   weight residual
   110.50  110.21    0.29 1.70e+00 3.46e-01 2.95e-02
angle pdb=" CA  ASN A  29 "
      pdb=" CB  ASN A  29 "
      pdb=" CG  ASN A  29 "
    ideal   model   delta    sigma   weight residual
   112.60  112.43    0.17 1.00e+00 1.00e+00 2.95e-02
angle pdb=" N   PRO A  85 "
      pdb=" CD  PRO A  85 "
      pdb=" CG  PRO A  85 "
    ideal   model   delta    sigma   weight residual
   103.20  103.46   -0.26 1.50e+00 4.44e-01 2.94e-02
angle pdb=" CA  GLY A  74 "
      pdb=" C   GLY A  74 "
      pdb=" N   SER A  75 "
    ideal   model   delta    sigma   weight residual
   118.52  118.72   -0.20 1.22e+00 6.72e-01 2.76e-02
angle pdb=" CD  LYS A  46 "
      pdb=" CE  LYS A  46 "
      pdb=" NZ  LYS A  46 "
    ideal   model   delta    sigma   weight residual
   111.90  111.37    0.53 3.20e+00 9.77e-02 2.74e-02
angle pdb=" NH1 ARG A  16 "
      pdb=" CZ  ARG A  16 "
      pdb=" NH2 ARG A  16 "
    ideal   model   delta    sigma   weight residual
   119.30  119.09    0.21 1.30e+00 5.92e-01 2.71e-02
angle pdb=" CA  VAL A  45 "
      pdb=" C   VAL A  45 "
      pdb=" N   LYS A  46 "
    ideal   model   delta    sigma   weight residual
   116.14  116.35   -0.21 1.28e+00 6.10e-01 2.60e-02
angle pdb=" C   LEU A  32 "
      pdb=" CA  LEU A  32 "
      pdb=" CB  LEU A  32 "
    ideal   model   delta    sigma   weight residual
   110.36  110.65   -0.29 1.78e+00 3.16e-01 2.59e-02
angle pdb=" CB  LEU A  60 "
      pdb=" CG  LEU A  60 "
      pdb=" CD1 LEU A  60 "
    ideal   model   delta    sigma   weight residual
   110.70  110.22    0.48 3.00e+00 1.11e-01 2.59e-02
angle pdb=" OE1 GLN A  53 "
      pdb=" CD  GLN A  53 "
      pdb=" NE2 GLN A  53 "
    ideal   model   delta    sigma   weight residual
   122.60  122.76   -0.16 1.00e+00 1.00e+00 2.56e-02
angle pdb=" C   VAL A  84 "
      pdb=" N   PRO A  85 "
      pdb=" CD  PRO A  85 "
    ideal   model   delta    sigma   weight residual
   125.00  125.64   -0.64 4.10e+00 5.95e-02 2.46e-02
angle pdb=" C   TYR A  41 "
      pdb=" N   PRO A  42 "
      pdb=" CD  PRO A  42 "
    ideal   model   delta    sigma   weight residual
   125.00  125.64   -0.64 4.10e+00 5.95e-02 2.45e-02
angle pdb=" CD1 LEU A  37 "
      pdb=" CG  LEU A  37 "
      pdb=" CD2 LEU A  37 "
    ideal   model   delta    sigma   weight residual
   110.80  110.46    0.34 2.20e+00 2.07e-01 2.39e-02
angle pdb=" CA  PRO A  58 "
      pdb=" CB  PRO A  58 "
      pdb=" CG  PRO A  58 "
    ideal   model   delta    sigma   weight residual
   104.50  104.21    0.29 1.90e+00 2.77e-01 2.37e-02
angle pdb=" CE1 PHE A  13 "
      pdb=" CZ  PHE A  13 "
      pdb=" CE2 PHE A  13 "
    ideal   model   delta    sigma   weight residual
   120.00  119.73    0.27 1.80e+00 3.09e-01 2.33e-02
angle pdb=" CA  ASP A  50 "
      pdb=" C   ASP A  50 "
      pdb=" N   GLU A  51 "
    ideal   model   delta    sigma   weight residual
   115.36  115.15    0.21 1.37e+00 5.33e-01 2.32e-02
angle pdb=" CG  ARG A  80 "
      pdb=" CD  ARG A  80 "
      pdb=" NE  ARG A  80 "
    ideal   model   delta    sigma   weight residual
   112.00  112.33   -0.33 2.20e+00 2.07e-01 2.28e-02
angle pdb=" CB  TYR A  61 "
      pdb=" CG  TYR A  61 "
      pdb=" CD2 TYR A  61 "
    ideal   model   delta    sigma   weight residual
   120.80  120.57    0.23 1.50e+00 4.44e-01 2.28e-02
angle pdb=" C   THR A  14 "
      pdb=" CA  THR A  14 "
      pdb=" CB  THR A  14 "
    ideal   model   delta    sigma   weight residual
   110.24  110.52   -0.28 1.88e+00 2.83e-01 2.24e-02
angle pdb=" O   ILE A   6 "
      pdb=" C   ILE A   6 "
      pdb=" N   LYS A   7 "
    ideal   model   delta    sigma   weight residual
   123.10  122.93    0.17 1.17e+00 7.31e-01 2.23e-02
angle pdb=" CA  LEU A  49 "
      pdb=" C   LEU A  49 "
      pdb=" O   LEU A  49 "
    ideal   model   delta    sigma   weight residual
   121.55  121.71   -0.16 1.06e+00 8.90e-01 2.23e-02
angle pdb=" OD1 ASN A  29 "
      pdb=" CG  ASN A  29 "
      pdb=" ND2 ASN A  29 "
    ideal   model   delta    sigma   weight residual
   122.60  122.75   -0.15 1.00e+00 1.00e+00 2.16e-02
angle pdb=" CA  THR A  15 "
      pdb=" CB  THR A  15 "
      pdb=" CG2 THR A  15 "
    ideal   model   delta    sigma   weight residual
   110.50  110.75   -0.25 1.70e+00 3.46e-01 2.13e-02
angle pdb=" CA  LEU A  81 "
      pdb=" C   LEU A  81 "
      pdb=" O   LEU A  81 "
    ideal   model   delta    sigma   weight residual
   120.51  120.30    0.21 1.43e+00 4.89e-01 2.07e-02
angle pdb=" CD1 LEU A  49 "
      pdb=" CG  LEU A  49 "
      pdb=" CD2 LEU A  49 "
    ideal   model   delta    sigma   weight residual
   110.80  110.49    0.31 2.20e+00 2.07e-01 2.04e-02
angle pdb=" CA  VAL A  70 "
      pdb=" CB  VAL A  70 "
      pdb=" CG1 VAL A  70 "
    ideal   model   delta    sigma   weight residual
   110.40  110.64   -0.24 1.70e+00 3.46e-01 2.01e-02
angle pdb=" N   ALA A  55 "
      pdb=" CA  ALA A  55 "
      pdb=" C   ALA A  55 "
    ideal   model   delta    sigma   weight residual
   110.28  110.07    0.21 1.48e+00 4.57e-01 1.99e-02
angle pdb=" CG  ARG A  16 "
      pdb=" CD  ARG A  16 "
      pdb=" NE  ARG A  16 "
    ideal   model   delta    sigma   weight residual
   112.00  111.69    0.31 2.20e+00 2.07e-01 1.93e-02
angle pdb=" CG  TYR A  61 "
      pdb=" CD2 TYR A  61 "
      pdb=" CE2 TYR A  61 "
    ideal   model   delta    sigma   weight residual
   121.20  120.99    0.21 1.50e+00 4.44e-01 1.92e-02
angle pdb=" N   LYS A  46 "
      pdb=" CA  LYS A  46 "
      pdb=" CB  LYS A  46 "
    ideal   model   delta    sigma   weight residual
   110.43  110.20    0.23 1.63e+00 3.76e-01 1.92e-02
angle pdb=" O   LEU A  76 "
      pdb=" C   LEU A  76 "
      pdb=" N   MSE A  77 "
    ideal   model   delta    sigma   weight residual
   122.93  123.10   -0.17 1.23e+00 6.61e-01 1.90e-02
angle pdb=" CD1 TYR A  34 "
      pdb=" CG  TYR A  34 "
      pdb=" CD2 TYR A  34 "
    ideal   model   delta    sigma   weight residual
   118.10  118.31   -0.21 1.50e+00 4.44e-01 1.88e-02
angle pdb=" CB  GLU A  30 "
      pdb=" CG  GLU A  30 "
      pdb=" CD  GLU A  30 "
    ideal   model   delta    sigma   weight residual
   112.60  112.83   -0.23 1.70e+00 3.46e-01 1.84e-02
angle pdb=" CG  PHE A  68 "
      pdb=" CD1 PHE A  68 "
      pdb=" CE1 PHE A  68 "
    ideal   model   delta    sigma   weight residual
   120.70  120.93   -0.23 1.70e+00 3.46e-01 1.83e-02
angle pdb=" CD2 PHE A  73 "
      pdb=" CE2 PHE A  73 "
      pdb=" CZ  PHE A  73 "
    ideal   model   delta    sigma   weight residual
   120.00  119.76    0.24 1.80e+00 3.09e-01 1.81e-02
angle pdb=" CB  PHE A  68 "
      pdb=" CG  PHE A  68 "
      pdb=" CD1 PHE A  68 "
    ideal   model   delta    sigma   weight residual
   120.70  120.93   -0.23 1.70e+00 3.46e-01 1.79e-02
angle pdb=" CG  GLN A  10 "
      pdb=" CD  GLN A  10 "
      pdb=" OE1 GLN A  10 "
    ideal   model   delta    sigma   weight residual
   120.80  121.07   -0.27 2.00e+00 2.50e-01 1.78e-02
angle pdb=" CA  LYS A  69 "
      pdb=" CB  LYS A  69 "
      pdb=" CG  LYS A  69 "
    ideal   model   delta    sigma   weight residual
   114.10  114.36   -0.26 2.00e+00 2.50e-01 1.73e-02
angle pdb=" CE1 TYR A  26 "
      pdb=" CZ  TYR A  26 "
      pdb=" CE2 TYR A  26 "
    ideal   model   delta    sigma   weight residual
   120.30  120.56   -0.26 2.00e+00 2.50e-01 1.71e-02
angle pdb=" CD2 TYR A  34 "
      pdb=" CE2 TYR A  34 "
      pdb=" CZ  TYR A  34 "
    ideal   model   delta    sigma   weight residual
   119.60  119.36    0.24 1.80e+00 3.09e-01 1.71e-02
angle pdb=" CA  GLU A   5 "
      pdb=" C   GLU A   5 "
      pdb=" O   GLU A   5 "
    ideal   model   delta    sigma   weight residual
   120.66  120.81   -0.15 1.15e+00 7.56e-01 1.71e-02
angle pdb=" OG1 THR A  62 "
      pdb=" CB  THR A  62 "
      pdb=" CG2 THR A  62 "
    ideal   model   delta    sigma   weight residual
   109.30  109.56   -0.26 2.00e+00 2.50e-01 1.70e-02
angle pdb=" CB  TYR A  56 "
      pdb=" CG  TYR A  56 "
      pdb=" CD1 TYR A  56 "
    ideal   model   delta    sigma   weight residual
   120.80  120.99   -0.19 1.50e+00 4.44e-01 1.69e-02
angle pdb=" NE  ARG A  16 "
      pdb=" CZ  ARG A  16 "
      pdb=" NH2 ARG A  16 "
    ideal   model   delta    sigma   weight residual
   119.20  119.32   -0.12 9.00e-01 1.23e+00 1.67e-02
angle pdb=" C   LEU A  76 "
      pdb=" CA  LEU A  76 "
      pdb=" CB  LEU A  76 "
    ideal   model   delta    sigma   weight residual
   109.89  109.68    0.21 1.60e+00 3.91e-01 1.65e-02
angle pdb=" CA  ILE A   6 "
      pdb=" C   ILE A   6 "
      pdb=" N   LYS A   7 "
    ideal   model   delta    sigma   weight residual
   116.34  116.50   -0.16 1.28e+00 6.10e-01 1.61e-02
angle pdb=" CB  ASP A  50 "
      pdb=" CG  ASP A  50 "
      pdb=" OD1 ASP A  50 "
    ideal   model   delta    sigma   weight residual
   118.40  118.69   -0.29 2.30e+00 1.89e-01 1.59e-02
angle pdb=" CD1 PHE A  68 "
      pdb=" CG  PHE A  68 "
      pdb=" CD2 PHE A  68 "
    ideal   model   delta    sigma   weight residual
   118.60  118.79   -0.19 1.50e+00 4.44e-01 1.55e-02
angle pdb=" CG1 VAL A   4 "
      pdb=" CB  VAL A   4 "
      pdb=" CG2 VAL A   4 "
    ideal   model   delta    sigma   weight residual
   110.80  111.07   -0.27 2.20e+00 2.07e-01 1.55e-02
angle pdb=" CD1 TYR A  26 "
      pdb=" CE1 TYR A  26 "
      pdb=" CZ  TYR A  26 "
    ideal   model   delta    sigma   weight residual
   119.60  119.38    0.22 1.80e+00 3.09e-01 1.55e-02
angle pdb=" O   PHE A  73 "
      pdb=" C   PHE A  73 "
      pdb=" N   GLY A  74 "
    ideal   model   delta    sigma   weight residual
   122.26  122.41   -0.15 1.23e+00 6.61e-01 1.49e-02
angle pdb=" C   LEU A  37 "
      pdb=" CA  LEU A  37 "
      pdb=" CB  LEU A  37 "
    ideal   model   delta    sigma   weight residual
   111.13  110.94    0.19 1.61e+00 3.86e-01 1.46e-02
angle pdb=" CA  GLN A  72 "
      pdb=" CB  GLN A  72 "
      pdb=" CG  GLN A  72 "
    ideal   model   delta    sigma   weight residual
   114.10  114.34   -0.24 2.00e+00 2.50e-01 1.45e-02
angle pdb=" CG  PHE A  13 "
      pdb=" CD1 PHE A  13 "
      pdb=" CE1 PHE A  13 "
    ideal   model   delta    sigma   weight residual
   120.70  120.90   -0.20 1.70e+00 3.46e-01 1.41e-02
angle pdb=" C   LEU A  76 "
      pdb=" N   MSE A  77 "
      pdb=" CA  MSE A  77 "
    ideal   model   delta    sigma   weight residual
   122.59  122.40    0.19 1.57e+00 4.06e-01 1.40e-02
angle pdb=" CG  GLN A  53 "
      pdb=" CD  GLN A  53 "
      pdb=" NE2 GLN A  53 "
    ideal   model   delta    sigma   weight residual
   116.40  116.22    0.18 1.50e+00 4.44e-01 1.38e-02
angle pdb=" CA  VAL A  63 "
      pdb=" C   VAL A  63 "
      pdb=" O   VAL A  63 "
    ideal   model   delta    sigma   weight residual
   120.71  120.84   -0.13 1.13e+00 7.83e-01 1.36e-02
angle pdb=" OE1 GLU A   5 "
      pdb=" CD  GLU A   5 "
      pdb=" OE2 GLU A   5 "
    ideal   model   delta    sigma   weight residual
   122.90  123.18   -0.28 2.40e+00 1.74e-01 1.36e-02
angle pdb=" O   TYR A  26 "
      pdb=" C   TYR A  26 "
      pdb=" N   SER A  27 "
    ideal   model   delta    sigma   weight residual
   123.00  122.81    0.19 1.60e+00 3.91e-01 1.34e-02
angle pdb=" CB  ASN A  39 "
      pdb=" CG  ASN A  39 "
      pdb=" ND2 ASN A  39 "
    ideal   model   delta    sigma   weight residual
   116.40  116.57   -0.17 1.50e+00 4.44e-01 1.32e-02
angle pdb=" C   VAL A   4 "
      pdb=" N   GLU A   5 "
      pdb=" CA  GLU A   5 "
    ideal   model   delta    sigma   weight residual
   122.73  122.54    0.19 1.62e+00 3.81e-01 1.31e-02
angle pdb=" CG  GLN A  10 "
      pdb=" CD  GLN A  10 "
      pdb=" NE2 GLN A  10 "
    ideal   model   delta    sigma   weight residual
   116.40  116.23    0.17 1.50e+00 4.44e-01 1.31e-02
angle pdb=" ND1 HIS A  64 "
      pdb=" CE1 HIS A  64 "
      pdb=" NE2 HIS A  64 "
    ideal   model   delta    sigma   weight residual
   108.40  108.29    0.11 1.00e+00 1.00e+00 1.28e-02
angle pdb=" CG  HIS A  64 "
      pdb=" CD2 HIS A  64 "
      pdb=" NE2 HIS A  64 "
    ideal   model   delta    sigma   weight residual
   107.20  107.09    0.11 1.00e+00 1.00e+00 1.26e-02
angle pdb=" CA  ILE A   6 "
      pdb=" CB  ILE A   6 "
      pdb=" CG2 ILE A   6 "
    ideal   model   delta    sigma   weight residual
   110.50  110.69   -0.19 1.70e+00 3.46e-01 1.26e-02
angle pdb=" CB  HIS A  64 "
      pdb=" CG  HIS A  64 "
      pdb=" ND1 HIS A  64 "
    ideal   model   delta    sigma   weight residual
   122.70  122.53    0.17 1.50e+00 4.44e-01 1.25e-02
angle pdb=" CA  GLU A   5 "
      pdb=" CB  GLU A   5 "
      pdb=" CG  GLU A   5 "
    ideal   model   delta    sigma   weight residual
   114.10  113.88    0.22 2.00e+00 2.50e-01 1.24e-02
angle pdb=" CD1 TYR A  61 "
      pdb=" CE1 TYR A  61 "
      pdb=" CZ  TYR A  61 "
    ideal   model   delta    sigma   weight residual
   119.60  119.40    0.20 1.80e+00 3.09e-01 1.24e-02
angle pdb=" O   SER A  75 "
      pdb=" C   SER A  75 "
      pdb=" N   LEU A  76 "
    ideal   model   delta    sigma   weight residual
   122.94  123.06   -0.12 1.12e+00 7.97e-01 1.20e-02
angle pdb=" O   GLN A  12 "
      pdb=" C   GLN A  12 "
      pdb=" N   PHE A  13 "
    ideal   model   delta    sigma   weight residual
   123.11  122.96    0.15 1.34e+00 5.57e-01 1.20e-02
angle pdb=" CG  GLN A  12 "
      pdb=" CD  GLN A  12 "
      pdb=" OE1 GLN A  12 "
    ideal   model   delta    sigma   weight residual
   120.80  121.02   -0.22 2.00e+00 2.50e-01 1.19e-02
angle pdb=" OE1 GLN A  72 "
      pdb=" CD  GLN A  72 "
      pdb=" NE2 GLN A  72 "
    ideal   model   delta    sigma   weight residual
   122.60  122.71   -0.11 1.00e+00 1.00e+00 1.19e-02
angle pdb=" CG  PHE A  73 "
      pdb=" CD2 PHE A  73 "
      pdb=" CE2 PHE A  73 "
    ideal   model   delta    sigma   weight residual
   120.70  120.88   -0.18 1.70e+00 3.46e-01 1.18e-02
angle pdb=" OG1 THR A  15 "
      pdb=" CB  THR A  15 "
      pdb=" CG2 THR A  15 "
    ideal   model   delta    sigma   weight residual
   109.30  109.09    0.21 2.00e+00 2.50e-01 1.15e-02
angle pdb=" C   ALA A  55 "
      pdb=" N   TYR A  56 "
      pdb=" CA  TYR A  56 "
    ideal   model   delta    sigma   weight residual
   120.87  120.72    0.15 1.42e+00 4.96e-01 1.13e-02
angle pdb=" CA  GLU A  30 "
      pdb=" C   GLU A  30 "
      pdb=" N   GLN A  31 "
    ideal   model   delta    sigma   weight residual
   116.01  116.17   -0.16 1.49e+00 4.50e-01 1.13e-02
angle pdb=" OE1 GLN A  12 "
      pdb=" CD  GLN A  12 "
      pdb=" NE2 GLN A  12 "
    ideal   model   delta    sigma   weight residual
   122.60  122.49    0.11 1.00e+00 1.00e+00 1.12e-02
angle pdb=" CG  GLN A  53 "
      pdb=" CD  GLN A  53 "
      pdb=" OE1 GLN A  53 "
    ideal   model   delta    sigma   weight residual
   120.80  121.01   -0.21 2.00e+00 2.50e-01 1.11e-02
angle pdb=" CB  ARG A  16 "
      pdb=" CG  ARG A  16 "
      pdb=" CD  ARG A  16 "
    ideal   model   delta    sigma   weight residual
   111.30  111.06    0.24 2.30e+00 1.89e-01 1.09e-02
angle pdb=" CG  PHE A  68 "
      pdb=" CD2 PHE A  68 "
      pdb=" CE2 PHE A  68 "
    ideal   model   delta    sigma   weight residual
   120.70  120.52    0.18 1.70e+00 3.46e-01 1.09e-02
angle pdb=" OE1 GLN A  10 "
      pdb=" CD  GLN A  10 "
      pdb=" NE2 GLN A  10 "
    ideal   model   delta    sigma   weight residual
   122.60  122.70   -0.10 1.00e+00 1.00e+00 1.09e-02
angle pdb=" O   LEU A  81 "
      pdb=" C   LEU A  81 "
      pdb=" N   ARG A  82 "
    ideal   model   delta    sigma   weight residual
   122.59  122.45    0.14 1.33e+00 5.65e-01 1.08e-02
angle pdb=" CE1 PHE A  73 "
      pdb=" CZ  PHE A  73 "
      pdb=" CE2 PHE A  73 "
    ideal   model   delta    sigma   weight residual
   120.00  119.81    0.19 1.80e+00 3.09e-01 1.07e-02
angle pdb=" O   PRO A  58 "
      pdb=" C   PRO A  58 "
      pdb=" N   GLY A  59 "
    ideal   model   delta    sigma   weight residual
   122.89  123.02   -0.13 1.27e+00 6.20e-01 1.06e-02
angle pdb=" CD1 TYR A  61 "
      pdb=" CG  TYR A  61 "
      pdb=" CD2 TYR A  61 "
    ideal   model   delta    sigma   weight residual
   118.10  118.25   -0.15 1.50e+00 4.44e-01 1.05e-02
angle pdb=" CA  TYR A  41 "
      pdb=" C   TYR A  41 "
      pdb=" O   TYR A  41 "
    ideal   model   delta    sigma   weight residual
   120.50  120.59   -0.09 9.20e-01 1.18e+00 1.04e-02
angle pdb=" CA  SER A  27 "
      pdb=" C   SER A  27 "
      pdb=" O   SER A  27 "
    ideal   model   delta    sigma   weight residual
   120.28  120.15    0.13 1.23e+00 6.61e-01 1.03e-02
angle pdb=" O   GLU A  51 "
      pdb=" C   GLU A  51 "
      pdb=" N   GLY A  52 "
    ideal   model   delta    sigma   weight residual
   123.04  122.92    0.12 1.17e+00 7.31e-01 9.81e-03
angle pdb=" CA  LEU A  83 "
      pdb=" C   LEU A  83 "
      pdb=" O   LEU A  83 "
    ideal   model   delta    sigma   weight residual
   121.16  121.27   -0.11 1.13e+00 7.83e-01 9.73e-03
angle pdb=" C   ASP A  50 "
      pdb=" CA  ASP A  50 "
      pdb=" CB  ASP A  50 "
    ideal   model   delta    sigma   weight residual
   110.51  110.32    0.19 1.89e+00 2.80e-01 9.66e-03
angle pdb=" CD1 TYR A  26 "
      pdb=" CG  TYR A  26 "
      pdb=" CD2 TYR A  26 "
    ideal   model   delta    sigma   weight residual
   118.10  117.95    0.15 1.50e+00 4.44e-01 9.45e-03
angle pdb=" CD2 TYR A  26 "
      pdb=" CE2 TYR A  26 "
      pdb=" CZ  TYR A  26 "
    ideal   model   delta    sigma   weight residual
   119.60  119.77   -0.17 1.80e+00 3.09e-01 9.36e-03
angle pdb=" CA  LEU A  49 "
      pdb=" C   LEU A  49 "
      pdb=" N   ASP A  50 "
    ideal   model   delta    sigma   weight residual
   115.56  115.43    0.13 1.30e+00 5.92e-01 9.29e-03
angle pdb=" NE  ARG A  16 "
      pdb=" CZ  ARG A  16 "
      pdb=" NH1 ARG A  16 "
    ideal   model   delta    sigma   weight residual
   121.50  121.60   -0.10 1.00e+00 1.00e+00 9.06e-03
angle pdb=" CG1 VAL A  70 "
      pdb=" CB  VAL A  70 "
      pdb=" CG2 VAL A  70 "
    ideal   model   delta    sigma   weight residual
   110.80  111.01   -0.21 2.20e+00 2.07e-01 9.02e-03
angle pdb=" CG  TYR A  34 "
      pdb=" CD1 TYR A  34 "
      pdb=" CE1 TYR A  34 "
    ideal   model   delta    sigma   weight residual
   121.20  121.34   -0.14 1.50e+00 4.44e-01 8.95e-03
angle pdb=" C   LYS A   3 "
      pdb=" CA  LYS A   3 "
      pdb=" CB  LYS A   3 "
    ideal   model   delta    sigma   weight residual
   109.75  109.90   -0.15 1.65e+00 3.67e-01 8.31e-03
angle pdb=" CA  LEU A  76 "
      pdb=" C   LEU A  76 "
      pdb=" O   LEU A  76 "
    ideal   model   delta    sigma   weight residual
   120.81  120.91   -0.10 1.15e+00 7.56e-01 8.31e-03
angle pdb=" CA  TYR A  61 "
      pdb=" C   TYR A  61 "
      pdb=" O   TYR A  61 "
    ideal   model   delta    sigma   weight residual
   121.51  121.61   -0.10 1.12e+00 7.97e-01 8.21e-03
angle pdb=" N   SER A  17 "
      pdb=" CA  SER A  17 "
      pdb=" C   SER A  17 "
    ideal   model   delta    sigma   weight residual
   111.00  110.75    0.25 2.80e+00 1.28e-01 8.15e-03
angle pdb=" CD1 LEU A  76 "
      pdb=" CG  LEU A  76 "
      pdb=" CD2 LEU A  76 "
    ideal   model   delta    sigma   weight residual
   110.80  110.60    0.20 2.20e+00 2.07e-01 8.14e-03
angle pdb=" CA  GLN A  10 "
      pdb=" C   GLN A  10 "
      pdb=" O   GLN A  10 "
    ideal   model   delta    sigma   weight residual
   120.55  120.44    0.11 1.21e+00 6.83e-01 7.79e-03
angle pdb=" CA  PRO A  58 "
      pdb=" N   PRO A  58 "
      pdb=" CD  PRO A  58 "
    ideal   model   delta    sigma   weight residual
   112.00  111.88    0.12 1.40e+00 5.10e-01 7.70e-03
angle pdb=" CD1 TYR A  41 "
      pdb=" CG  TYR A  41 "
      pdb=" CD2 TYR A  41 "
    ideal   model   delta    sigma   weight residual
   118.10  117.97    0.13 1.50e+00 4.44e-01 7.67e-03
angle pdb=" CG  GLU A  51 "
      pdb=" CD  GLU A  51 "
      pdb=" OE2 GLU A  51 "
    ideal   model   delta    sigma   weight residual
   118.40  118.60   -0.20 2.30e+00 1.89e-01 7.36e-03
angle pdb=" C   LEU A  44 "
      pdb=" N   VAL A  45 "
      pdb=" CA  VAL A  45 "
    ideal   model   delta    sigma   weight residual
   122.71  122.83   -0.12 1.44e+00 4.82e-01 7.12e-03
angle pdb=" CA  VAL A  63 "
      pdb=" C   VAL A  63 "
      pdb=" N   HIS A  64 "
    ideal   model   delta    sigma   weight residual
   116.31  116.41   -0.10 1.20e+00 6.94e-01 6.90e-03
angle pdb=" CA  VAL A  70 "
      pdb=" C   VAL A  70 "
      pdb=" N   GLY A  71 "
    ideal   model   delta    sigma   weight residual
   116.43  116.53   -0.10 1.24e+00 6.50e-01 6.84e-03
angle pdb=" CG  HIS A  64 "
      pdb=" ND1 HIS A  64 "
      pdb=" CE1 HIS A  64 "
    ideal   model   delta    sigma   weight residual
   109.30  109.44   -0.14 1.70e+00 3.46e-01 6.69e-03
angle pdb=" CB  HIS A  64 "
      pdb=" CG  HIS A  64 "
      pdb=" CD2 HIS A  64 "
    ideal   model   delta    sigma   weight residual
   131.20  131.31   -0.11 1.30e+00 5.92e-01 6.66e-03
angle pdb=" CA  PRO A   8 "
      pdb=" N   PRO A   8 "
      pdb=" CD  PRO A   8 "
    ideal   model   delta    sigma   weight residual
   112.00  111.89    0.11 1.40e+00 5.10e-01 6.57e-03
angle pdb=" CD2 TYR A  61 "
      pdb=" CE2 TYR A  61 "
      pdb=" CZ  TYR A  61 "
    ideal   model   delta    sigma   weight residual
   119.60  119.45    0.15 1.80e+00 3.09e-01 6.56e-03
angle pdb=" CA  ASN A  39 "
      pdb=" C   ASN A  39 "
      pdb=" O   ASN A  39 "
    ideal   model   delta    sigma   weight residual
   120.84  120.95   -0.11 1.33e+00 5.65e-01 6.30e-03
angle pdb=" CD1 PHE A  73 "
      pdb=" CE1 PHE A  73 "
      pdb=" CZ  PHE A  73 "
    ideal   model   delta    sigma   weight residual
   120.00  120.14   -0.14 1.80e+00 3.09e-01 6.07e-03
angle pdb=" CG  PHE A  73 "
      pdb=" CD1 PHE A  73 "
      pdb=" CE1 PHE A  73 "
    ideal   model   delta    sigma   weight residual
   120.70  120.83   -0.13 1.70e+00 3.46e-01 6.01e-03
angle pdb=" CE2 TYR A  56 "
      pdb=" CZ  TYR A  56 "
      pdb=" OH  TYR A  56 "
    ideal   model   delta    sigma   weight residual
   119.90  119.67    0.23 3.00e+00 1.11e-01 5.90e-03
angle pdb=" CG  TYR A  56 "
      pdb=" CD1 TYR A  56 "
      pdb=" CE1 TYR A  56 "
    ideal   model   delta    sigma   weight residual
   121.20  121.09    0.11 1.50e+00 4.44e-01 5.86e-03
angle pdb=" N   VAL A  35 "
      pdb=" CA  VAL A  35 "
      pdb=" CB  VAL A  35 "
    ideal   model   delta    sigma   weight residual
   111.25  111.15    0.10 1.36e+00 5.41e-01 5.70e-03
angle pdb=" CA  LEU A  44 "
      pdb=" C   LEU A  44 "
      pdb=" N   VAL A  45 "
    ideal   model   delta    sigma   weight residual
   116.06  115.96    0.10 1.29e+00 6.01e-01 5.68e-03
angle pdb=" C   VAL A  84 "
      pdb=" N   PRO A  85 "
      pdb=" CA  PRO A  85 "
    ideal   model   delta    sigma   weight residual
   122.60  122.23    0.37 5.00e+00 4.00e-02 5.35e-03
angle pdb=" C   LYS A   7 "
      pdb=" N   PRO A   8 "
      pdb=" CD  PRO A   8 "
    ideal   model   delta    sigma   weight residual
   125.00  125.29   -0.29 4.10e+00 5.95e-02 5.03e-03
angle pdb=" C   ILE A   2 "
      pdb=" N   LYS A   3 "
      pdb=" CA  LYS A   3 "
    ideal   model   delta    sigma   weight residual
   122.72  122.82   -0.10 1.38e+00 5.25e-01 4.99e-03
angle pdb=" CD1 LEU A  60 "
      pdb=" CG  LEU A  60 "
      pdb=" CD2 LEU A  60 "
    ideal   model   delta    sigma   weight residual
   110.80  110.65    0.15 2.20e+00 2.07e-01 4.79e-03
angle pdb=" CA  THR A  48 "
      pdb=" CB  THR A  48 "
      pdb=" CG2 THR A  48 "
    ideal   model   delta    sigma   weight residual
   110.50  110.61   -0.11 1.70e+00 3.46e-01 4.55e-03
angle pdb=" C   LEU A  37 "
      pdb=" N   GLY A  38 "
      pdb=" CA  GLY A  38 "
    ideal   model   delta    sigma   weight residual
   121.93  122.06   -0.13 1.94e+00 2.66e-01 4.35e-03
angle pdb=" CG  TYR A  26 "
      pdb=" CD2 TYR A  26 "
      pdb=" CE2 TYR A  26 "
    ideal   model   delta    sigma   weight residual
   121.20  121.10    0.10 1.50e+00 4.44e-01 4.31e-03
angle pdb=" OD1 ASN A  39 "
      pdb=" CG  ASN A  39 "
      pdb=" ND2 ASN A  39 "
    ideal   model   delta    sigma   weight residual
   122.60  122.67   -0.07 1.00e+00 1.00e+00 4.30e-03
angle pdb=" CA  LEU A  37 "
      pdb=" CB  LEU A  37 "
      pdb=" CG  LEU A  37 "
    ideal   model   delta    sigma   weight residual
   116.30  116.52   -0.22 3.50e+00 8.16e-02 4.02e-03
angle pdb=" N   SER A  66 "
      pdb=" CA  SER A  66 "
      pdb=" C   SER A  66 "
    ideal   model   delta    sigma   weight residual
   112.87  112.79    0.08 1.20e+00 6.94e-01 4.01e-03
angle pdb=" C   PRO A   8 "
      pdb=" CA  PRO A   8 "
      pdb=" CB  PRO A   8 "
    ideal   model   delta    sigma   weight residual
   112.26  112.36   -0.10 1.67e+00 3.59e-01 3.94e-03
angle pdb=" CD1 TYR A  56 "
      pdb=" CG  TYR A  56 "
      pdb=" CD2 TYR A  56 "
    ideal   model   delta    sigma   weight residual
   118.10  118.19   -0.09 1.50e+00 4.44e-01 3.89e-03
angle pdb=" C   GLN A  72 "
      pdb=" CA  GLN A  72 "
      pdb=" CB  GLN A  72 "
    ideal   model   delta    sigma   weight residual
   110.01  110.12   -0.11 1.80e+00 3.09e-01 3.69e-03
angle pdb=" N   PHE A  68 "
      pdb=" CA  PHE A  68 "
      pdb=" CB  PHE A  68 "
    ideal   model   delta    sigma   weight residual
   110.69  110.79   -0.10 1.61e+00 3.86e-01 3.62e-03
angle pdb=" CE1 TYR A  26 "
      pdb=" CZ  TYR A  26 "
      pdb=" OH  TYR A  26 "
    ideal   model   delta    sigma   weight residual
   119.90  120.08   -0.18 3.00e+00 1.11e-01 3.62e-03
angle pdb=" CB  PHE A  13 "
      pdb=" CG  PHE A  13 "
      pdb=" CD1 PHE A  13 "
    ideal   model   delta    sigma   weight residual
   120.70  120.80   -0.10 1.70e+00 3.46e-01 3.56e-03
angle pdb=" CA  LYS A   7 "
      pdb=" CB  LYS A   7 "
      pdb=" CG  LYS A   7 "
    ideal   model   delta    sigma   weight residual
   114.10  114.22   -0.12 2.00e+00 2.50e-01 3.40e-03
angle pdb=" CA  THR A  14 "
      pdb=" CB  THR A  14 "
      pdb=" CG2 THR A  14 "
    ideal   model   delta    sigma   weight residual
   110.50  110.40    0.10 1.70e+00 3.46e-01 3.40e-03
angle pdb=" CG  GLN A  12 "
      pdb=" CD  GLN A  12 "
      pdb=" NE2 GLN A  12 "
    ideal   model   delta    sigma   weight residual
   116.40  116.49   -0.09 1.50e+00 4.44e-01 3.22e-03
angle pdb=" CA  PRO A   8 "
      pdb=" C   PRO A   8 "
      pdb=" O   PRO A   8 "
    ideal   model   delta    sigma   weight residual
   119.64  119.73   -0.09 1.58e+00 4.01e-01 3.15e-03
angle pdb=" CG  GLU A  40 "
      pdb=" CD  GLU A  40 "
      pdb=" OE1 GLU A  40 "
    ideal   model   delta    sigma   weight residual
   118.40  118.27    0.13 2.30e+00 1.89e-01 3.00e-03
angle pdb=" CD1 PHE A  13 "
      pdb=" CE1 PHE A  13 "
      pdb=" CZ  PHE A  13 "
    ideal   model   delta    sigma   weight residual
   120.00  119.90    0.10 1.80e+00 3.09e-01 2.95e-03
angle pdb=" O   TYR A  56 "
      pdb=" C   TYR A  56 "
      pdb=" N   ALA A  57 "
    ideal   model   delta    sigma   weight residual
   122.89  122.83    0.06 1.22e+00 6.72e-01 2.77e-03
angle pdb=" CD1 LEU A  28 "
      pdb=" CG  LEU A  28 "
      pdb=" CD2 LEU A  28 "
    ideal   model   delta    sigma   weight residual
   110.80  110.68    0.12 2.20e+00 2.07e-01 2.75e-03
angle pdb=" CA  THR A  14 "
      pdb=" CB  THR A  14 "
      pdb=" OG1 THR A  14 "
    ideal   model   delta    sigma   weight residual
   109.60  109.68   -0.08 1.50e+00 4.44e-01 2.67e-03
angle pdb=" CB  PHE A  73 "
      pdb=" CG  PHE A  73 "
      pdb=" CD2 PHE A  73 "
    ideal   model   delta    sigma   weight residual
   120.70  120.79   -0.09 1.70e+00 3.46e-01 2.67e-03
angle pdb=" N   PRO A  58 "
      pdb=" CD  PRO A  58 "
      pdb=" CG  PRO A  58 "
    ideal   model   delta    sigma   weight residual
   103.20  103.12    0.08 1.50e+00 4.44e-01 2.64e-03
angle pdb=" CA  LEU A  60 "
      pdb=" CB  LEU A  60 "
      pdb=" CG  LEU A  60 "
    ideal   model   delta    sigma   weight residual
   116.30  116.12    0.18 3.50e+00 8.16e-02 2.53e-03
angle pdb=" CA  PRO A  85 "
      pdb=" N   PRO A  85 "
      pdb=" CD  PRO A  85 "
    ideal   model   delta    sigma   weight residual
   112.00  112.07   -0.07 1.40e+00 5.10e-01 2.52e-03
angle pdb=" CB  LEU A  49 "
      pdb=" CG  LEU A  49 "
      pdb=" CD1 LEU A  49 "
    ideal   model   delta    sigma   weight residual
   110.70  110.55    0.15 3.00e+00 1.11e-01 2.38e-03
angle pdb=" CD2 TYR A  56 "
      pdb=" CE2 TYR A  56 "
      pdb=" CZ  TYR A  56 "
    ideal   model   delta    sigma   weight residual
   119.60  119.68   -0.08 1.80e+00 3.09e-01 2.22e-03
angle pdb=" C   ARG A  80 "
      pdb=" N   LEU A  81 "
      pdb=" CA  LEU A  81 "
    ideal   model   delta    sigma   weight residual
   121.54  121.45    0.09 1.91e+00 2.74e-01 2.02e-03
angle pdb=" CD1 TYR A  56 "
      pdb=" CE1 TYR A  56 "
      pdb=" CZ  TYR A  56 "
    ideal   model   delta    sigma   weight residual
   119.60  119.68   -0.08 1.80e+00 3.09e-01 2.00e-03
angle pdb=" N   ARG A  16 "
      pdb=" CA  ARG A  16 "
      pdb=" CB  ARG A  16 "
    ideal   model   delta    sigma   weight residual
   110.69  110.62    0.07 1.61e+00 3.86e-01 1.90e-03
angle pdb=" O   THR A  14 "
      pdb=" C   THR A  14 "
      pdb=" N   THR A  15 "
    ideal   model   delta    sigma   weight residual
   122.94  123.00   -0.06 1.43e+00 4.89e-01 1.86e-03
angle pdb=" CA  ILE A   2 "
      pdb=" C   ILE A   2 "
      pdb=" N   LYS A   3 "
    ideal   model   delta    sigma   weight residual
   116.20  116.12    0.08 2.00e+00 2.50e-01 1.81e-03
angle pdb=" CE1 TYR A  56 "
      pdb=" CZ  TYR A  56 "
      pdb=" CE2 TYR A  56 "
    ideal   model   delta    sigma   weight residual
   120.30  120.38   -0.08 2.00e+00 2.50e-01 1.80e-03
angle pdb=" CG  PHE A  13 "
      pdb=" CD2 PHE A  13 "
      pdb=" CE2 PHE A  13 "
    ideal   model   delta    sigma   weight residual
   120.70  120.63    0.07 1.70e+00 3.46e-01 1.77e-03
angle pdb=" CB  ILE A  78 "
      pdb=" CG1 ILE A  78 "
      pdb=" CD1 ILE A  78 "
    ideal   model   delta    sigma   weight residual
   113.80  113.71    0.09 2.10e+00 2.27e-01 1.76e-03
angle pdb=" CA  PHE A  13 "
      pdb=" C   PHE A  13 "
      pdb=" O   PHE A  13 "
    ideal   model   delta    sigma   weight residual
   121.46  121.41    0.05 1.17e+00 7.31e-01 1.76e-03
angle pdb=" CB  PHE A  73 "
      pdb=" CG  PHE A  73 "
      pdb=" CD1 PHE A  73 "
    ideal   model   delta    sigma   weight residual
   120.70  120.63    0.07 1.70e+00 3.46e-01 1.73e-03
angle pdb=" CD2 HIS A  64 "
      pdb=" NE2 HIS A  64 "
      pdb=" CE1 HIS A  64 "
    ideal   model   delta    sigma   weight residual
   109.00  109.04   -0.04 1.00e+00 1.00e+00 1.70e-03
angle pdb=" O   LYS A  46 "
      pdb=" C   LYS A  46 "
      pdb=" N   ILE A  47 "
    ideal   model   delta    sigma   weight residual
   123.27  123.22    0.05 1.13e+00 7.83e-01 1.63e-03
angle pdb=" CA  TYR A  61 "
      pdb=" C   TYR A  61 "
      pdb=" N   THR A  62 "
    ideal   model   delta    sigma   weight residual
   115.46  115.40    0.06 1.57e+00 4.06e-01 1.59e-03
angle pdb=" N   PRO A   8 "
      pdb=" CD  PRO A   8 "
      pdb=" CG  PRO A   8 "
    ideal   model   delta    sigma   weight residual
   103.20  103.26   -0.06 1.50e+00 4.44e-01 1.59e-03
angle pdb=" CD  ARG A  82 "
      pdb=" NE  ARG A  82 "
      pdb=" CZ  ARG A  82 "
    ideal   model   delta    sigma   weight residual
   124.40  124.46   -0.06 1.40e+00 5.10e-01 1.59e-03
angle pdb=" CA  ILE A   6 "
      pdb=" C   ILE A   6 "
      pdb=" O   ILE A   6 "
    ideal   model   delta    sigma   weight residual
   120.53  120.57   -0.04 1.07e+00 8.73e-01 1.57e-03
angle pdb=" ND1 HIS A  64 "
      pdb=" CG  HIS A  64 "
      pdb=" CD2 HIS A  64 "
    ideal   model   delta    sigma   weight residual
   106.10  106.14   -0.04 1.00e+00 1.00e+00 1.53e-03
angle pdb=" CA  ILE A   6 "
      pdb=" CB  ILE A   6 "
      pdb=" CG1 ILE A   6 "
    ideal   model   delta    sigma   weight residual
   110.40  110.47   -0.07 1.70e+00 3.46e-01 1.48e-03
angle pdb=" O   LEU A  49 "
      pdb=" C   LEU A  49 "
      pdb=" N   ASP A  50 "
    ideal   model   delta    sigma   weight residual
   122.81  122.86   -0.05 1.23e+00 6.61e-01 1.47e-03
angle pdb=" CB  TYR A  56 "
      pdb=" CG  TYR A  56 "
      pdb=" CD2 TYR A  56 "
    ideal   model   delta    sigma   weight residual
   120.80  120.74    0.06 1.50e+00 4.44e-01 1.43e-03
angle pdb=" CA  PRO A   8 "
      pdb=" CB  PRO A   8 "
      pdb=" CG  PRO A   8 "
    ideal   model   delta    sigma   weight residual
   104.50  104.43    0.07 1.90e+00 2.77e-01 1.30e-03
angle pdb=" N   PRO A  42 "
      pdb=" CD  PRO A  42 "
      pdb=" CG  PRO A  42 "
    ideal   model   delta    sigma   weight residual
   103.20  103.15    0.05 1.50e+00 4.44e-01 1.27e-03
angle pdb=" CB  LEU A  37 "
      pdb=" CG  LEU A  37 "
      pdb=" CD2 LEU A  37 "
    ideal   model   delta    sigma   weight residual
   110.70  110.59    0.11 3.00e+00 1.11e-01 1.25e-03
angle pdb=" N   LEU A  49 "
      pdb=" CA  LEU A  49 "
      pdb=" CB  LEU A  49 "
    ideal   model   delta    sigma   weight residual
   110.04  109.99    0.05 1.47e+00 4.63e-01 1.18e-03
angle pdb=" N   THR A  15 "
      pdb=" CA  THR A  15 "
      pdb=" CB  THR A  15 "
    ideal   model   delta    sigma   weight residual
   110.80  110.86   -0.06 1.73e+00 3.34e-01 1.14e-03
angle pdb=" CE1 TYR A  61 "
      pdb=" CZ  TYR A  61 "
      pdb=" OH  TYR A  61 "
    ideal   model   delta    sigma   weight residual
   119.90  120.00   -0.10 3.00e+00 1.11e-01 1.08e-03
angle pdb=" CA  VAL A  84 "
      pdb=" CB  VAL A  84 "
      pdb=" CG1 VAL A  84 "
    ideal   model   delta    sigma   weight residual
   110.40  110.45   -0.05 1.70e+00 3.46e-01 1.04e-03
angle pdb=" CE1 PHE A  68 "
      pdb=" CZ  PHE A  68 "
      pdb=" CE2 PHE A  68 "
    ideal   model   delta    sigma   weight residual
   120.00  120.06   -0.06 1.80e+00 3.09e-01 1.03e-03
angle pdb=" CB  LEU A  76 "
      pdb=" CG  LEU A  76 "
      pdb=" CD1 LEU A  76 "
    ideal   model   delta    sigma   weight residual
   110.70  110.79   -0.09 3.00e+00 1.11e-01 9.73e-04
angle pdb=" CG  TYR A  61 "
      pdb=" CD1 TYR A  61 "
      pdb=" CE1 TYR A  61 "
    ideal   model   delta    sigma   weight residual
   121.20  121.16    0.04 1.50e+00 4.44e-01 8.85e-04
angle pdb=" CB  LEU A  81 "
      pdb=" CG  LEU A  81 "
      pdb=" CD1 LEU A  81 "
    ideal   model   delta    sigma   weight residual
   110.70  110.61    0.09 3.00e+00 1.11e-01 8.85e-04
angle pdb=" CD  LYS A   7 "
      pdb=" CE  LYS A   7 "
      pdb=" NZ  LYS A   7 "
    ideal   model   delta    sigma   weight residual
   111.90  111.99   -0.09 3.20e+00 9.77e-02 8.57e-04
angle pdb=" CE1 TYR A  34 "
      pdb=" CZ  TYR A  34 "
      pdb=" CE2 TYR A  34 "
    ideal   model   delta    sigma   weight residual
   120.30  120.36   -0.06 2.00e+00 2.50e-01 8.23e-04
angle pdb=" CB  PRO A   8 "
      pdb=" CG  PRO A   8 "
      pdb=" CD  PRO A   8 "
    ideal   model   delta    sigma   weight residual
   106.10  106.18   -0.08 3.20e+00 9.77e-02 6.93e-04
angle pdb=" CD1 PHE A  73 "
      pdb=" CG  PHE A  73 "
      pdb=" CD2 PHE A  73 "
    ideal   model   delta    sigma   weight residual
   118.60  118.56    0.04 1.50e+00 4.44e-01 6.26e-04
angle pdb=" O   TYR A  61 "
      pdb=" C   TYR A  61 "
      pdb=" N   THR A  62 "
    ideal   model   delta    sigma   weight residual
   122.96  122.99   -0.03 1.26e+00 6.30e-01 6.10e-04
angle pdb=" CD2 PHE A  13 "
      pdb=" CE2 PHE A  13 "
      pdb=" CZ  PHE A  13 "
    ideal   model   delta    sigma   weight residual
   120.00  119.96    0.04 1.80e+00 3.09e-01 5.53e-04
angle pdb=" CB  LEU A  83 "
      pdb=" CG  LEU A  83 "
      pdb=" CD1 LEU A  83 "
    ideal   model   delta    sigma   weight residual
   110.70  110.77   -0.07 3.00e+00 1.11e-01 5.27e-04
angle pdb=" O   ASP A  36 "
      pdb=" C   ASP A  36 "
      pdb=" N   LEU A  37 "
    ideal   model   delta    sigma   weight residual
   122.82  122.79    0.03 1.30e+00 5.92e-01 4.70e-04
angle pdb=" CB  LYS A   7 "
      pdb=" CG  LYS A   7 "
      pdb=" CD  LYS A   7 "
    ideal   model   delta    sigma   weight residual
   111.30  111.35   -0.05 2.30e+00 1.89e-01 4.45e-04
angle pdb=" CB  ASN A  39 "
      pdb=" CG  ASN A  39 "
      pdb=" OD1 ASN A  39 "
    ideal   model   delta    sigma   weight residual
   120.80  120.76    0.04 2.00e+00 2.50e-01 4.23e-04
angle pdb=" CG  LYS A   3 "
      pdb=" CD  LYS A   3 "
      pdb=" CE  LYS A   3 "
    ideal   model   delta    sigma   weight residual
   111.30  111.34   -0.04 2.30e+00 1.89e-01 3.77e-04
angle pdb=" C   ILE A   6 "
      pdb=" N   LYS A   7 "
      pdb=" CA  LYS A   7 "
    ideal   model   delta    sigma   weight residual
   121.48  121.44    0.04 2.04e+00 2.40e-01 3.36e-04
angle pdb=" CA  VAL A  43 "
      pdb=" C   VAL A  43 "
      pdb=" O   VAL A  43 "
    ideal   model   delta    sigma   weight residual
   121.48  121.50   -0.02 1.27e+00 6.20e-01 2.69e-04
angle pdb=" CB  ASN A  29 "
      pdb=" CG  ASN A  29 "
      pdb=" OD1 ASN A  29 "
    ideal   model   delta    sigma   weight residual
   120.80  120.83   -0.03 2.00e+00 2.50e-01 2.17e-04
angle pdb=" CE1 TYR A  56 "
      pdb=" CZ  TYR A  56 "
      pdb=" OH  TYR A  56 "
    ideal   model   delta    sigma   weight residual
   119.90  119.94   -0.04 3.00e+00 1.11e-01 2.03e-04
angle pdb=" C   LEU A  81 "
      pdb=" N   ARG A  82 "
      pdb=" CA  ARG A  82 "
    ideal   model   delta    sigma   weight residual
   123.00  123.02   -0.02 1.38e+00 5.25e-01 1.98e-04
angle pdb=" CB  ASN A  29 "
      pdb=" CG  ASN A  29 "
      pdb=" ND2 ASN A  29 "
    ideal   model   delta    sigma   weight residual
   116.40  116.42   -0.02 1.50e+00 4.44e-01 1.96e-04
angle pdb=" CA  VAL A   4 "
      pdb=" CB  VAL A   4 "
      pdb=" CG2 VAL A   4 "
    ideal   model   delta    sigma   weight residual
   110.40  110.38    0.02 1.70e+00 3.46e-01 1.61e-04
angle pdb=" C   MSE A  77 "
      pdb=" N   ILE A  78 "
      pdb=" CA  ILE A  78 "
    ideal   model   delta    sigma   weight residual
   122.37  122.39   -0.02 1.29e+00 6.01e-01 1.42e-04
angle pdb=" OD1 ASP A  36 "
      pdb=" CG  ASP A  36 "
      pdb=" OD2 ASP A  36 "
    ideal   model   delta    sigma   weight residual
   122.90  122.92   -0.02 2.40e+00 1.74e-01 1.01e-04
angle pdb=" O   ASP A  50 "
      pdb=" C   ASP A  50 "
      pdb=" N   GLU A  51 "
    ideal   model   delta    sigma   weight residual
   122.68  122.67    0.01 1.17e+00 7.31e-01 8.75e-05
angle pdb=" CG  GLN A  31 "
      pdb=" CD  GLN A  31 "
      pdb=" NE2 GLN A  31 "
    ideal   model   delta    sigma   weight residual
   116.40  116.39    0.01 1.50e+00 4.44e-01 6.89e-05
angle pdb=" N   PRO A  42 "
      pdb=" CA  PRO A  42 "
      pdb=" CB  PRO A  42 "
    ideal   model   delta    sigma   weight residual
   103.35  103.36   -0.01 8.70e-01 1.32e+00 6.34e-05
angle pdb=" CG  TYR A  26 "
      pdb=" CD1 TYR A  26 "
      pdb=" CE1 TYR A  26 "
    ideal   model   delta    sigma   weight residual
   121.20  121.19    0.01 1.50e+00 4.44e-01 5.69e-05
angle pdb=" CB  LEU A  49 "
      pdb=" CG  LEU A  49 "
      pdb=" CD2 LEU A  49 "
    ideal   model   delta    sigma   weight residual
   110.70  110.68    0.02 3.00e+00 1.11e-01 4.51e-05
angle pdb=" N   ASP A  36 "
      pdb=" CA  ASP A  36 "
      pdb=" CB  ASP A  36 "
    ideal   model   delta    sigma   weight residual
   109.94  109.95   -0.01 1.60e+00 3.91e-01 2.88e-05
angle pdb=" CD1 LEU A  81 "
      pdb=" CG  LEU A  81 "
      pdb=" CD2 LEU A  81 "
    ideal   model   delta    sigma   weight residual
   110.80  110.79    0.01 2.20e+00 2.07e-01 5.47e-06
angle pdb=" CD2 PHE A  68 "
      pdb=" CE2 PHE A  68 "
      pdb=" CZ  PHE A  68 "
    ideal   model   delta    sigma   weight residual
   120.00  120.00    0.00 1.80e+00 3.09e-01 4.97e-06
angle pdb=" CG  GLU A  30 "
      pdb=" CD  GLU A  30 "
      pdb=" OE2 GLU A  30 "
    ideal   model   delta    sigma   weight residual
   118.40  118.40   -0.00 2.30e+00 1.89e-01 4.31e-06
angle pdb=" CB  GLN A  31 "
      pdb=" CG  GLN A  31 "
      pdb=" CD  GLN A  31 "
    ideal   model   delta    sigma   weight residual
   112.60  112.60   -0.00 1.70e+00 3.46e-01 3.82e-06
angle pdb=" N   GLU A   5 "
      pdb=" CA  GLU A   5 "
      pdb=" CB  GLU A   5 "
    ideal   model   delta    sigma   weight residual
   111.00  111.00    0.00 1.81e+00 3.05e-01 1.32e-06
angle pdb=" OD1 ASP A  79 "
      pdb=" CG  ASP A  79 "
      pdb=" OD2 ASP A  79 "
    ideal   model   delta    sigma   weight residual
   122.90  122.90   -0.00 2.40e+00 1.74e-01 5.94e-08

Dihedral angle | covalent geometry | restraints: 229
  sinusoidal: 150
    harmonic: 79
Sorted by residual:
dihedral pdb=" N   GLN A  53 "
         pdb=" CA  GLN A  53 "
         pdb=" CB  GLN A  53 "
         pdb=" CG  GLN A  53 "
    ideal   model   delta sinusoidal    sigma   weight residual
    60.00  119.56  -59.56     3      1.50e+01 4.44e-03 9.48e+00
dihedral pdb=" CB  MSE A  77 "
         pdb=" CG  MSE A  77 "
         pdb="SE   MSE A  77 "
         pdb=" CE  MSE A  77 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00   -7.17  -52.83     3      1.50e+01 4.44e-03 9.15e+00
dihedral pdb=" CG  ARG A  82 "
         pdb=" CD  ARG A  82 "
         pdb=" NE  ARG A  82 "
         pdb=" CZ  ARG A  82 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  139.79   40.21     2      1.50e+01 4.44e-03 8.89e+00
dihedral pdb=" CB  LYS A   3 "
         pdb=" CG  LYS A   3 "
         pdb=" CD  LYS A   3 "
         pdb=" CE  LYS A   3 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00 -110.08   50.08     3      1.50e+01 4.44e-03 8.86e+00
dihedral pdb=" N   ARG A  80 "
         pdb=" CA  ARG A  80 "
         pdb=" CB  ARG A  80 "
         pdb=" CG  ARG A  80 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00 -105.09   45.09     3      1.50e+01 4.44e-03 8.11e+00
dihedral pdb=" CA  ILE A   6 "
         pdb=" CB  ILE A   6 "
         pdb=" CG1 ILE A   6 "
         pdb=" CD1 ILE A   6 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00 -104.71   44.71     3      1.50e+01 4.44e-03 8.04e+00
dihedral pdb=" N   LEU A  81 "
         pdb=" CA  LEU A  81 "
         pdb=" CB  LEU A  81 "
         pdb=" CG  LEU A  81 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -136.44  -43.56     3      1.50e+01 4.44e-03 7.83e+00
dihedral pdb=" CA  LEU A  28 "
         pdb=" CB  LEU A  28 "
         pdb=" CG  LEU A  28 "
         pdb=" CD1 LEU A  28 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -16.63  -43.37     3      1.50e+01 4.44e-03 7.80e+00
dihedral pdb=" N   LEU A  28 "
         pdb=" CA  LEU A  28 "
         pdb=" CB  LEU A  28 "
         pdb=" CG  LEU A  28 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00 -103.04   43.04     3      1.50e+01 4.44e-03 7.73e+00
dihedral pdb=" CA  THR A  15 "
         pdb=" C   THR A  15 "
         pdb=" N   ARG A  16 "
         pdb=" CA  ARG A  16 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  166.42   13.58     0      5.00e+00 4.00e-02 7.37e+00
dihedral pdb=" N   SER A  67 "
         pdb=" CA  SER A  67 "
         pdb=" CB  SER A  67 "
         pdb=" OG  SER A  67 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  141.16   38.84     3      1.50e+01 4.44e-03 6.86e+00
dihedral pdb=" N   SER A  27 "
         pdb=" CA  SER A  27 "
         pdb=" CB  SER A  27 "
         pdb=" OG  SER A  27 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  141.67   38.33     3      1.50e+01 4.44e-03 6.74e+00
dihedral pdb=" CA  ARG A  82 "
         pdb=" CB  ARG A  82 "
         pdb=" CG  ARG A  82 "
         pdb=" CD  ARG A  82 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  144.49   35.51     3      1.50e+01 4.44e-03 6.09e+00
dihedral pdb=" CA  LYS A  46 "
         pdb=" CB  LYS A  46 "
         pdb=" CG  LYS A  46 "
         pdb=" CD  LYS A  46 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -145.99  -34.01     3      1.50e+01 4.44e-03 5.73e+00
dihedral pdb=" CB  LYS A  46 "
         pdb=" CG  LYS A  46 "
         pdb=" CD  LYS A  46 "
         pdb=" CE  LYS A  46 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -93.31   33.31     3      1.50e+01 4.44e-03 5.56e+00
dihedral pdb=" N   TYR A  26 "
         pdb=" CA  TYR A  26 "
         pdb=" CB  TYR A  26 "
         pdb=" CG  TYR A  26 "
    ideal   model   delta sinusoidal    sigma   weight residual
    60.00   92.85  -32.85     3      1.50e+01 4.44e-03 5.45e+00
dihedral pdb=" CA  VAL A  43 "
         pdb=" C   VAL A  43 "
         pdb=" N   LEU A  44 "
         pdb=" CA  LEU A  44 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  168.47   11.53     0      5.00e+00 4.00e-02 5.32e+00
dihedral pdb=" CB  ARG A  80 "
         pdb=" CG  ARG A  80 "
         pdb=" CD  ARG A  80 "
         pdb=" NE  ARG A  80 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -147.95  -32.05     3      1.50e+01 4.44e-03 5.25e+00
dihedral pdb=" CB  GLN A  12 "
         pdb=" CG  GLN A  12 "
         pdb=" CD  GLN A  12 "
         pdb=" OE1 GLN A  12 "
    ideal   model   delta sinusoidal    sigma   weight residual
     0.00  -82.05   82.05     2      3.00e+01 1.11e-03 5.23e+00
dihedral pdb=" CB  GLN A  53 "
         pdb=" CG  GLN A  53 "
         pdb=" CD  GLN A  53 "
         pdb=" OE1 GLN A  53 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00   99.41   80.59     2      3.00e+01 1.11e-03 5.19e+00
dihedral pdb=" CG  LYS A   7 "
         pdb=" CD  LYS A   7 "
         pdb=" CE  LYS A   7 "
         pdb=" NZ  LYS A   7 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -149.56  -30.44     3      1.50e+01 4.44e-03 4.85e+00
dihedral pdb=" CA  LEU A  83 "
         pdb=" C   LEU A  83 "
         pdb=" N   VAL A  84 "
         pdb=" CA  VAL A  84 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  169.56   10.44     0      5.00e+00 4.00e-02 4.36e+00
dihedral pdb=" N   ILE A   2 "
         pdb=" CA  ILE A   2 "
         pdb=" CB  ILE A   2 "
         pdb=" CG1 ILE A   2 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -87.11   27.11     3      1.50e+01 4.44e-03 4.03e+00
dihedral pdb=" N   VAL A  45 "
         pdb=" CA  VAL A  45 "
         pdb=" CB  VAL A  45 "
         pdb=" CG1 VAL A  45 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  153.42   26.58     3      1.50e+01 4.44e-03 3.90e+00
dihedral pdb=" CA  ASP A  79 "
         pdb=" CB  ASP A  79 "
         pdb=" CG  ASP A  79 "
         pdb=" OD1 ASP A  79 "
    ideal   model   delta sinusoidal    sigma   weight residual
    70.00   37.50   32.50     1      2.00e+01 2.50e-03 3.76e+00
dihedral pdb=" CA  LEU A  32 "
         pdb=" CB  LEU A  32 "
         pdb=" CG  LEU A  32 "
         pdb=" CD1 LEU A  32 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  154.09   25.91     3      1.50e+01 4.44e-03 3.73e+00
dihedral pdb=" N   LEU A  44 "
         pdb=" CA  LEU A  44 "
         pdb=" CB  LEU A  44 "
         pdb=" CG  LEU A  44 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00 -155.12  -24.88     3      1.50e+01 4.44e-03 3.48e+00
dihedral pdb=" CA  ARG A  82 "
         pdb=" C   ARG A  82 "
         pdb=" N   LEU A  83 "
         pdb=" CA  LEU A  83 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -170.83   -9.17     0      5.00e+00 4.00e-02 3.37e+00
dihedral pdb=" N   PHE A  68 "
         pdb=" CA  PHE A  68 "
         pdb=" CB  PHE A  68 "
         pdb=" CG  PHE A  68 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -36.06  -23.94     3      1.50e+01 4.44e-03 3.26e+00
dihedral pdb=" N   LEU A  65 "
         pdb=" CA  LEU A  65 "
         pdb=" CB  LEU A  65 "
         pdb=" CG  LEU A  65 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -157.20  -22.80     3      1.50e+01 4.44e-03 3.00e+00
dihedral pdb=" N   LEU A  60 "
         pdb=" CA  LEU A  60 "
         pdb=" CB  LEU A  60 "
         pdb=" CG  LEU A  60 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -82.57   22.57     3      1.50e+01 4.44e-03 2.94e+00
dihedral pdb=" CA  CYS A  33 "
         pdb=" C   CYS A  33 "
         pdb=" N   TYR A  34 "
         pdb=" CA  TYR A  34 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  171.44    8.56     0      5.00e+00 4.00e-02 2.93e+00
dihedral pdb=" CB  LYS A   7 "
         pdb=" CG  LYS A   7 "
         pdb=" CD  LYS A   7 "
         pdb=" CE  LYS A   7 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -157.52  -22.48     3      1.50e+01 4.44e-03 2.92e+00
dihedral pdb=" CA  ILE A  78 "
         pdb=" CB  ILE A  78 "
         pdb=" CG1 ILE A  78 "
         pdb=" CD1 ILE A  78 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  157.54   22.46     3      1.50e+01 4.44e-03 2.92e+00
dihedral pdb=" CA  GLY A  71 "
         pdb=" C   GLY A  71 "
         pdb=" N   GLN A  72 "
         pdb=" CA  GLN A  72 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -171.74   -8.26     0      5.00e+00 4.00e-02 2.73e+00
dihedral pdb=" N   SER A  17 "
         pdb=" CA  SER A  17 "
         pdb=" CB  SER A  17 "
         pdb=" OG  SER A  17 "
    ideal   model   delta sinusoidal    sigma   weight residual
    60.00   81.37  -21.37     3      1.50e+01 4.44e-03 2.67e+00
dihedral pdb=" N   ILE A  47 "
         pdb=" CA  ILE A  47 "
         pdb=" CB  ILE A  47 "
         pdb=" CG1 ILE A  47 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -81.24   21.24     3      1.50e+01 4.44e-03 2.64e+00
dihedral pdb=" CA  TYR A  61 "
         pdb=" C   TYR A  61 "
         pdb=" N   THR A  62 "
         pdb=" CA  THR A  62 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  172.01    7.99     0      5.00e+00 4.00e-02 2.55e+00
dihedral pdb=" CA  LYS A   7 "
         pdb=" CB  LYS A   7 "
         pdb=" CG  LYS A   7 "
         pdb=" CD  LYS A   7 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -80.34   20.34     3      1.50e+01 4.44e-03 2.44e+00
dihedral pdb=" N   ARG A  82 "
         pdb=" CA  ARG A  82 "
         pdb=" CB  ARG A  82 "
         pdb=" CG  ARG A  82 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -79.39   19.39     3      1.50e+01 4.44e-03 2.24e+00
dihedral pdb=" CB  GLN A  10 "
         pdb=" CG  GLN A  10 "
         pdb=" CD  GLN A  10 "
         pdb=" OE1 GLN A  10 "
    ideal   model   delta sinusoidal    sigma   weight residual
     0.00  -40.35   40.35     2      3.00e+01 1.11e-03 2.24e+00
dihedral pdb=" N   LYS A  46 "
         pdb=" CA  LYS A  46 "
         pdb=" CB  LYS A  46 "
         pdb=" CG  LYS A  46 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -160.73  -19.27     3      1.50e+01 4.44e-03 2.21e+00
dihedral pdb=" N   THR A  62 "
         pdb=" CA  THR A  62 "
         pdb=" CB  THR A  62 "
         pdb=" OG1 THR A  62 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -161.12  -18.88     3      1.50e+01 4.44e-03 2.13e+00
dihedral pdb=" CG  ARG A  80 "
         pdb=" CD  ARG A  80 "
         pdb=" NE  ARG A  80 "
         pdb=" CZ  ARG A  80 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00 -161.84  -18.16     2      1.50e+01 4.44e-03 2.07e+00
dihedral pdb=" N   LEU A  76 "
         pdb=" CA  LEU A  76 "
         pdb=" CB  LEU A  76 "
         pdb=" CG  LEU A  76 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00 -161.49  -18.51     3      1.50e+01 4.44e-03 2.06e+00
dihedral pdb=" CB  GLU A  51 "
         pdb=" CG  GLU A  51 "
         pdb=" CD  GLU A  51 "
         pdb=" OE1 GLU A  51 "
    ideal   model   delta sinusoidal    sigma   weight residual
     0.00   35.93  -35.93     1      3.00e+01 1.11e-03 2.03e+00
dihedral pdb=" N   VAL A  43 "
         pdb=" CA  VAL A  43 "
         pdb=" CB  VAL A  43 "
         pdb=" CG1 VAL A  43 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -78.11   18.11     3      1.50e+01 4.44e-03 1.98e+00
dihedral pdb=" CA  GLN A  12 "
         pdb=" CB  GLN A  12 "
         pdb=" CG  GLN A  12 "
         pdb=" CD  GLN A  12 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -77.92   17.92     3      1.50e+01 4.44e-03 1.94e+00
dihedral pdb=" CB  ARG A  16 "
         pdb=" CG  ARG A  16 "
         pdb=" CD  ARG A  16 "
         pdb=" NE  ARG A  16 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -77.87   17.87     3      1.50e+01 4.44e-03 1.93e+00
dihedral pdb=" CA  MSE A  77 "
         pdb=" C   MSE A  77 "
         pdb=" N   ILE A  78 "
         pdb=" CA  ILE A  78 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  173.10    6.90     0      5.00e+00 4.00e-02 1.90e+00
dihedral pdb=" N   CYS A  33 "
         pdb=" CA  CYS A  33 "
         pdb=" CB  CYS A  33 "
         pdb=" SG  CYS A  33 "
    ideal   model   delta sinusoidal    sigma   weight residual
    60.00   77.03  -17.03     3      1.50e+01 4.44e-03 1.76e+00
dihedral pdb=" N   GLU A  40 "
         pdb=" CA  GLU A  40 "
         pdb=" CB  GLU A  40 "
         pdb=" CG  GLU A  40 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -43.01  -16.99     3      1.50e+01 4.44e-03 1.76e+00
dihedral pdb=" N   GLN A  12 "
         pdb=" CA  GLN A  12 "
         pdb=" CB  GLN A  12 "
         pdb=" CG  GLN A  12 "
    ideal   model   delta sinusoidal    sigma   weight residual
    60.00   76.74  -16.74     3      1.50e+01 4.44e-03 1.71e+00
dihedral pdb=" N   SER A   9 "
         pdb=" CA  SER A   9 "
         pdb=" CB  SER A   9 "
         pdb=" OG  SER A   9 "
    ideal   model   delta sinusoidal    sigma   weight residual
    60.00   76.69  -16.69     3      1.50e+01 4.44e-03 1.70e+00
dihedral pdb=" CA  PHE A  13 "
         pdb=" C   PHE A  13 "
         pdb=" N   THR A  14 "
         pdb=" CA  THR A  14 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  174.14    5.86     0      5.00e+00 4.00e-02 1.38e+00
dihedral pdb=" CA  GLN A  10 "
         pdb=" C   GLN A  10 "
         pdb=" N   ALA A  11 "
         pdb=" CA  ALA A  11 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -174.21   -5.79     0      5.00e+00 4.00e-02 1.34e+00
dihedral pdb=" CA  ASP A  50 "
         pdb=" CB  ASP A  50 "
         pdb=" CG  ASP A  50 "
         pdb=" OD1 ASP A  50 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -30.00  -49.16   19.16     1      2.00e+01 2.50e-03 1.33e+00
dihedral pdb=" CA  ARG A  80 "
         pdb=" C   ARG A  80 "
         pdb=" N   LEU A  81 "
         pdb=" CA  LEU A  81 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  174.24    5.76     0      5.00e+00 4.00e-02 1.33e+00
dihedral pdb=" CA  TYR A  41 "
         pdb=" C   TYR A  41 "
         pdb=" N   PRO A  42 "
         pdb=" CA  PRO A  42 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  174.49    5.51     0      5.00e+00 4.00e-02 1.22e+00
dihedral pdb=" CB  GLU A  40 "
         pdb=" CG  GLU A  40 "
         pdb=" CD  GLU A  40 "
         pdb=" OE1 GLU A  40 "
    ideal   model   delta sinusoidal    sigma   weight residual
     0.00   27.21  -27.21     1      3.00e+01 1.11e-03 1.18e+00
dihedral pdb=" N   ASP A  50 "
         pdb=" CA  ASP A  50 "
         pdb=" CB  ASP A  50 "
         pdb=" CG  ASP A  50 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -73.65   13.65     3      1.50e+01 4.44e-03 1.16e+00
dihedral pdb=" CA  GLN A  12 "
         pdb=" C   GLN A  12 "
         pdb=" N   PHE A  13 "
         pdb=" CA  PHE A  13 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  174.79    5.21     0      5.00e+00 4.00e-02 1.08e+00
dihedral pdb=" CA  LEU A  32 "
         pdb=" C   LEU A  32 "
         pdb=" N   CYS A  33 "
         pdb=" CA  CYS A  33 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00 -174.86   -5.14     0      5.00e+00 4.00e-02 1.05e+00
dihedral pdb=" CA  GLY A  52 "
         pdb=" C   GLY A  52 "
         pdb=" N   GLN A  53 "
         pdb=" CA  GLN A  53 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -174.87   -5.13     0      5.00e+00 4.00e-02 1.05e+00
dihedral pdb=" CB  GLU A  30 "
         pdb=" CG  GLU A  30 "
         pdb=" CD  GLU A  30 "
         pdb=" OE1 GLU A  30 "
    ideal   model   delta sinusoidal    sigma   weight residual
     0.00  -25.44   25.44     1      3.00e+01 1.11e-03 1.03e+00
dihedral pdb=" CB  LYS A  69 "
         pdb=" CG  LYS A  69 "
         pdb=" CD  LYS A  69 "
         pdb=" CE  LYS A  69 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -72.67   12.67     3      1.50e+01 4.44e-03 1.01e+00
dihedral pdb=" CA  PHE A  73 "
         pdb=" C   PHE A  73 "
         pdb=" N   GLY A  74 "
         pdb=" CA  GLY A  74 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -175.00   -5.00     0      5.00e+00 4.00e-02 9.99e-01
dihedral pdb=" CA  ASP A  50 "
         pdb=" C   ASP A  50 "
         pdb=" N   GLU A  51 "
         pdb=" CA  GLU A  51 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -175.15   -4.85     0      5.00e+00 4.00e-02 9.41e-01
dihedral pdb=" CA  LEU A  49 "
         pdb=" C   LEU A  49 "
         pdb=" N   ASP A  50 "
         pdb=" CA  ASP A  50 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  175.23    4.77     0      5.00e+00 4.00e-02 9.10e-01
dihedral pdb=" N   MSE A  77 "
         pdb=" CA  MSE A  77 "
         pdb=" CB  MSE A  77 "
         pdb=" CG  MSE A  77 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -72.00   12.00     3      1.50e+01 4.44e-03 9.06e-01
dihedral pdb=" N   LEU A  37 "
         pdb=" CA  LEU A  37 "
         pdb=" CB  LEU A  37 "
         pdb=" CG  LEU A  37 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -71.69   11.69     3      1.50e+01 4.44e-03 8.61e-01
dihedral pdb=" CA  GLN A  53 "
         pdb=" CB  GLN A  53 "
         pdb=" CG  GLN A  53 "
         pdb=" CD  GLN A  53 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  168.46   11.54     3      1.50e+01 4.44e-03 8.39e-01
dihedral pdb=" CG  LYS A   3 "
         pdb=" CD  LYS A   3 "
         pdb=" CE  LYS A   3 "
         pdb=" NZ  LYS A   3 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  168.54   11.46     3      1.50e+01 4.44e-03 8.28e-01
dihedral pdb=" N   HIS A  64 "
         pdb=" CA  HIS A  64 "
         pdb=" CB  HIS A  64 "
         pdb=" CG  HIS A  64 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -168.91  -11.09     3      1.50e+01 4.44e-03 7.77e-01
dihedral pdb=" N   ILE A  78 "
         pdb=" CA  ILE A  78 "
         pdb=" CB  ILE A  78 "
         pdb=" CG1 ILE A  78 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -70.70   10.70     3      1.50e+01 4.44e-03 7.25e-01
dihedral pdb=" CA  ILE A  78 "
         pdb=" C   ILE A  78 "
         pdb=" N   ASP A  79 "
         pdb=" CA  ASP A  79 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  175.92    4.08     0      5.00e+00 4.00e-02 6.66e-01
dihedral pdb=" N   SER A  66 "
         pdb=" CA  SER A  66 "
         pdb=" CB  SER A  66 "
         pdb=" OG  SER A  66 "
    ideal   model   delta sinusoidal    sigma   weight residual
    60.00   49.89   10.11     3      1.50e+01 4.44e-03 6.49e-01
dihedral pdb=" CA  LEU A  37 "
         pdb=" C   LEU A  37 "
         pdb=" N   GLY A  38 "
         pdb=" CA  GLY A  38 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  176.00    4.00     0      5.00e+00 4.00e-02 6.41e-01
dihedral pdb=" CA  ILE A   2 "
         pdb=" C   ILE A   2 "
         pdb=" N   LYS A   3 "
         pdb=" CA  LYS A   3 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  176.01    3.99     0      5.00e+00 4.00e-02 6.37e-01
dihedral pdb=" CA  PRO A  54 "
         pdb=" C   PRO A  54 "
         pdb=" N   ALA A  55 "
         pdb=" CA  ALA A  55 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  176.01    3.99     0      5.00e+00 4.00e-02 6.35e-01
dihedral pdb=" CA  VAL A  35 "
         pdb=" C   VAL A  35 "
         pdb=" N   ASP A  36 "
         pdb=" CA  ASP A  36 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  176.05    3.95     0      5.00e+00 4.00e-02 6.23e-01
dihedral pdb=" CA  LYS A  69 "
         pdb=" C   LYS A  69 "
         pdb=" N   VAL A  70 "
         pdb=" CA  VAL A  70 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  176.09    3.91     0      5.00e+00 4.00e-02 6.12e-01
dihedral pdb=" N   LYS A   7 "
         pdb=" CA  LYS A   7 "
         pdb=" CB  LYS A   7 "
         pdb=" CG  LYS A   7 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -69.63    9.63     3      1.50e+01 4.44e-03 5.90e-01
dihedral pdb=" CA  LEU A  60 "
         pdb=" C   LEU A  60 "
         pdb=" N   TYR A  61 "
         pdb=" CA  TYR A  61 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00 -176.17   -3.83     0      5.00e+00 4.00e-02 5.86e-01
dihedral pdb=" CA  TYR A  41 "
         pdb=" CB  TYR A  41 "
         pdb=" CG  TYR A  41 "
         pdb=" CD1 TYR A  41 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -90.00  -77.48  -12.52     2      2.00e+01 2.50e-03 5.64e-01
dihedral pdb=" CA  LYS A   3 "
         pdb=" CB  LYS A   3 "
         pdb=" CG  LYS A   3 "
         pdb=" CD  LYS A   3 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -170.74   -9.26     3      1.50e+01 4.44e-03 5.47e-01
dihedral pdb=" N   ASP A  36 "
         pdb=" CA  ASP A  36 "
         pdb=" CB  ASP A  36 "
         pdb=" CG  ASP A  36 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -170.74   -9.26     3      1.50e+01 4.44e-03 5.47e-01
dihedral pdb=" CA  GLU A  40 "
         pdb=" CB  GLU A  40 "
         pdb=" CG  GLU A  40 "
         pdb=" CD  GLU A  40 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -69.23    9.23     3      1.50e+01 4.44e-03 5.43e-01
dihedral pdb=" CA  GLU A  51 "
         pdb=" CB  GLU A  51 "
         pdb=" CG  GLU A  51 "
         pdb=" CD  GLU A  51 "
    ideal   model   delta sinusoidal    sigma   weight residual
    60.00   69.22   -9.22     3      1.50e+01 4.44e-03 5.42e-01
dihedral pdb=" CA  ASP A  36 "
         pdb=" CB  ASP A  36 "
         pdb=" CG  ASP A  36 "
         pdb=" OD1 ASP A  36 "
    ideal   model   delta sinusoidal    sigma   weight residual
     0.00   12.20  -12.20     1      2.00e+01 2.50e-03 5.42e-01
dihedral pdb=" CA  SER A  67 "
         pdb=" C   SER A  67 "
         pdb=" N   PHE A  68 "
         pdb=" CA  PHE A  68 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -176.35   -3.65     0      5.00e+00 4.00e-02 5.32e-01
dihedral pdb=" CA  PRO A  42 "
         pdb=" C   PRO A  42 "
         pdb=" N   VAL A  43 "
         pdb=" CA  VAL A  43 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  176.38    3.62     0      5.00e+00 4.00e-02 5.24e-01
dihedral pdb=" CA  TYR A  56 "
         pdb=" CB  TYR A  56 "
         pdb=" CG  TYR A  56 "
         pdb=" CD1 TYR A  56 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -90.00  -78.17  -11.83     2      2.00e+01 2.50e-03 5.04e-01
dihedral pdb=" CA  LEU A  76 "
         pdb=" CB  LEU A  76 "
         pdb=" CG  LEU A  76 "
         pdb=" CD1 LEU A  76 "
    ideal   model   delta sinusoidal    sigma   weight residual
    60.00   68.81   -8.81     3      1.50e+01 4.44e-03 4.95e-01
dihedral pdb=" CA  GLU A   5 "
         pdb=" C   GLU A   5 "
         pdb=" N   ILE A   6 "
         pdb=" CA  ILE A   6 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  176.51    3.49     0      5.00e+00 4.00e-02 4.87e-01
dihedral pdb=" CA  THR A  62 "
         pdb=" C   THR A  62 "
         pdb=" N   VAL A  63 "
         pdb=" CA  VAL A  63 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -176.53   -3.47     0      5.00e+00 4.00e-02 4.83e-01
dihedral pdb=" N   VAL A  84 "
         pdb=" CA  VAL A  84 "
         pdb=" CB  VAL A  84 "
         pdb=" CG1 VAL A  84 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -68.54    8.54     3      1.50e+01 4.44e-03 4.66e-01
dihedral pdb=" CA  LEU A  37 "
         pdb=" CB  LEU A  37 "
         pdb=" CG  LEU A  37 "
         pdb=" CD1 LEU A  37 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00 -171.77   -8.23     3      1.50e+01 4.44e-03 4.33e-01
dihedral pdb=" CA  LEU A  65 "
         pdb=" CB  LEU A  65 "
         pdb=" CG  LEU A  65 "
         pdb=" CD1 LEU A  65 "
    ideal   model   delta sinusoidal    sigma   weight residual
    60.00   51.82    8.18     3      1.50e+01 4.44e-03 4.28e-01
dihedral pdb=" N   GLN A  31 "
         pdb=" CA  GLN A  31 "
         pdb=" CB  GLN A  31 "
         pdb=" CG  GLN A  31 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -171.88   -8.12     3      1.50e+01 4.44e-03 4.22e-01
dihedral pdb=" N   TYR A  34 "
         pdb=" CA  TYR A  34 "
         pdb=" CB  TYR A  34 "
         pdb=" CG  TYR A  34 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -68.01    8.01     3      1.50e+01 4.44e-03 4.11e-01
dihedral pdb=" CA  GLN A  10 "
         pdb=" CB  GLN A  10 "
         pdb=" CG  GLN A  10 "
         pdb=" CD  GLN A  10 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  172.04    7.96     3      1.50e+01 4.44e-03 4.05e-01
dihedral pdb=" CA  ARG A  16 "
         pdb=" C   ARG A  16 "
         pdb=" N   SER A  17 "
         pdb=" CA  SER A  17 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00 -176.85   -3.15     0      5.00e+00 4.00e-02 3.98e-01
dihedral pdb=" CA  ILE A  47 "
         pdb=" CB  ILE A  47 "
         pdb=" CG1 ILE A  47 "
         pdb=" CD1 ILE A  47 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  172.16    7.84     3      1.50e+01 4.44e-03 3.94e-01
dihedral pdb=" CA  SER A  75 "
         pdb=" C   SER A  75 "
         pdb=" N   LEU A  76 "
         pdb=" CA  LEU A  76 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  176.91    3.09     0      5.00e+00 4.00e-02 3.81e-01
dihedral pdb=" N   PRO A  85 "
         pdb=" CA  PRO A  85 "
         pdb=" CB  PRO A  85 "
         pdb=" CG  PRO A  85 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -30.00  -19.85  -10.15     1      2.00e+01 2.50e-03 3.75e-01
dihedral pdb=" CA  ALA A  55 "
         pdb=" C   ALA A  55 "
         pdb=" N   TYR A  56 "
         pdb=" CA  TYR A  56 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  176.95    3.05     0      5.00e+00 4.00e-02 3.73e-01
dihedral pdb=" CA  TYR A  26 "
         pdb=" CB  TYR A  26 "
         pdb=" CG  TYR A  26 "
         pdb=" CD1 TYR A  26 "
    ideal   model   delta sinusoidal    sigma   weight residual
    90.00   79.95   10.05     2      2.00e+01 2.50e-03 3.65e-01
dihedral pdb=" CA  GLU A   5 "
         pdb=" CB  GLU A   5 "
         pdb=" CG  GLU A   5 "
         pdb=" CD  GLU A   5 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  172.74    7.26     3      1.50e+01 4.44e-03 3.39e-01
dihedral pdb=" CA  TYR A  26 "
         pdb=" C   TYR A  26 "
         pdb=" N   SER A  27 "
         pdb=" CA  SER A  27 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  177.11    2.89     0      5.00e+00 4.00e-02 3.33e-01
dihedral pdb=" N   PRO A   8 "
         pdb=" CG  PRO A   8 "
         pdb=" CD  PRO A   8 "
         pdb=" CB  PRO A   8 "
    ideal   model   delta sinusoidal    sigma   weight residual
    30.00   22.95    7.05     1      1.50e+01 4.44e-03 3.23e-01
dihedral pdb=" N   VAL A  63 "
         pdb=" CA  VAL A  63 "
         pdb=" CB  VAL A  63 "
         pdb=" CG1 VAL A  63 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  173.02    6.98     3      1.50e+01 4.44e-03 3.13e-01
dihedral pdb=" CA  GLU A  30 "
         pdb=" C   GLU A  30 "
         pdb=" N   GLN A  31 "
         pdb=" CA  GLN A  31 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  177.21    2.79     0      5.00e+00 4.00e-02 3.12e-01
dihedral pdb=" CA  GLN A  53 "
         pdb=" C   GLN A  53 "
         pdb=" N   PRO A  54 "
         pdb=" CA  PRO A  54 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  177.23    2.77     0      5.00e+00 4.00e-02 3.06e-01
dihedral pdb=" CA  GLY A  59 "
         pdb=" C   GLY A  59 "
         pdb=" N   LEU A  60 "
         pdb=" CA  LEU A  60 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -177.27   -2.73     0      5.00e+00 4.00e-02 2.98e-01
dihedral pdb=" CA  VAL A  45 "
         pdb=" C   VAL A  45 "
         pdb=" N   LYS A  46 "
         pdb=" CA  LYS A  46 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  177.31    2.69     0      5.00e+00 4.00e-02 2.89e-01
dihedral pdb=" N   ARG A  16 "
         pdb=" CA  ARG A  16 "
         pdb=" CB  ARG A  16 "
         pdb=" CG  ARG A  16 "
    ideal   model   delta sinusoidal    sigma   weight residual
    60.00   66.67   -6.67     3      1.50e+01 4.44e-03 2.86e-01
dihedral pdb=" N   TYR A  41 "
         pdb=" CA  TYR A  41 "
         pdb=" CB  TYR A  41 "
         pdb=" CG  TYR A  41 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -66.64    6.64     3      1.50e+01 4.44e-03 2.83e-01
dihedral pdb=" CA  SER A   9 "
         pdb=" C   SER A   9 "
         pdb=" N   GLN A  10 "
         pdb=" CA  GLN A  10 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00 -177.40   -2.60     0      5.00e+00 4.00e-02 2.70e-01
dihedral pdb=" N   VAL A   4 "
         pdb=" CA  VAL A   4 "
         pdb=" CB  VAL A   4 "
         pdb=" CG1 VAL A   4 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  173.56    6.44     3      1.50e+01 4.44e-03 2.67e-01
dihedral pdb=" CA  LEU A  76 "
         pdb=" C   LEU A  76 "
         pdb=" N   MSE A  77 "
         pdb=" CA  MSE A  77 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  177.43    2.57     0      5.00e+00 4.00e-02 2.65e-01
dihedral pdb=" CA  GLU A  30 "
         pdb=" CB  GLU A  30 "
         pdb=" CG  GLU A  30 "
         pdb=" CD  GLU A  30 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  173.60    6.40     3      1.50e+01 4.44e-03 2.64e-01
dihedral pdb=" CA  LYS A  69 "
         pdb=" CB  LYS A  69 "
         pdb=" CG  LYS A  69 "
         pdb=" CD  LYS A  69 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  173.73    6.27     3      1.50e+01 4.44e-03 2.53e-01
dihedral pdb=" N   PHE A  73 "
         pdb=" CA  PHE A  73 "
         pdb=" CB  PHE A  73 "
         pdb=" CG  PHE A  73 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -66.26    6.26     3      1.50e+01 4.44e-03 2.52e-01
dihedral pdb=" N   ASN A  29 "
         pdb=" CA  ASN A  29 "
         pdb=" CB  ASN A  29 "
         pdb=" CG  ASN A  29 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -66.20    6.20     3      1.50e+01 4.44e-03 2.48e-01
dihedral pdb=" CA  ALA A  57 "
         pdb=" C   ALA A  57 "
         pdb=" N   PRO A  58 "
         pdb=" CA  PRO A  58 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  177.51    2.49     0      5.00e+00 4.00e-02 2.47e-01
dihedral pdb=" CA  PRO A  85 "
         pdb=" CB  PRO A  85 "
         pdb=" CG  PRO A  85 "
         pdb=" CD  PRO A  85 "
    ideal   model   delta sinusoidal    sigma   weight residual
    38.00   29.86    8.14     1      2.00e+01 2.50e-03 2.42e-01
dihedral pdb=" N   PHE A  13 "
         pdb=" CA  PHE A  13 "
         pdb=" CB  PHE A  13 "
         pdb=" CG  PHE A  13 "
    ideal   model   delta sinusoidal    sigma   weight residual
    60.00   65.98   -5.98     3      1.50e+01 4.44e-03 2.30e-01
dihedral pdb=" N   SER A  75 "
         pdb=" CA  SER A  75 "
         pdb=" CB  SER A  75 "
         pdb=" OG  SER A  75 "
    ideal   model   delta sinusoidal    sigma   weight residual
    60.00   65.97   -5.97     3      1.50e+01 4.44e-03 2.29e-01
dihedral pdb=" CA  SER A  27 "
         pdb=" C   SER A  27 "
         pdb=" N   LEU A  28 "
         pdb=" CA  LEU A  28 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  177.61    2.39     0      5.00e+00 4.00e-02 2.29e-01
dihedral pdb=" CA  PHE A  68 "
         pdb=" C   PHE A  68 "
         pdb=" N   LYS A  69 "
         pdb=" CA  LYS A  69 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  177.61    2.39     0      5.00e+00 4.00e-02 2.29e-01
dihedral pdb=" CA  HIS A  64 "
         pdb=" CB  HIS A  64 "
         pdb=" CG  HIS A  64 "
         pdb=" ND1 HIS A  64 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -90.00 -101.82   11.82     2      3.00e+01 1.11e-03 2.24e-01
dihedral pdb=" CA  ASN A  29 "
         pdb=" CB  ASN A  29 "
         pdb=" CG  ASN A  29 "
         pdb=" OD1 ASN A  29 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -30.00  -22.19   -7.81     2      2.00e+01 2.50e-03 2.21e-01
dihedral pdb=" CA  ASN A  39 "
         pdb=" C   ASN A  39 "
         pdb=" N   GLU A  40 "
         pdb=" CA  GLU A  40 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -177.68   -2.32     0      5.00e+00 4.00e-02 2.15e-01
dihedral pdb=" CA  LEU A  65 "
         pdb=" C   LEU A  65 "
         pdb=" N   SER A  66 "
         pdb=" CA  SER A  66 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  177.70    2.30     0      5.00e+00 4.00e-02 2.12e-01
dihedral pdb=" CA  GLN A  72 "
         pdb=" CB  GLN A  72 "
         pdb=" CG  GLN A  72 "
         pdb=" CD  GLN A  72 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  174.31    5.69     3      1.50e+01 4.44e-03 2.09e-01
dihedral pdb=" CA  PHE A  73 "
         pdb=" CB  PHE A  73 "
         pdb=" CG  PHE A  73 "
         pdb=" CD1 PHE A  73 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -90.00  -82.53   -7.47     2      2.00e+01 2.50e-03 2.03e-01
dihedral pdb=" CA  PRO A   8 "
         pdb=" C   PRO A   8 "
         pdb=" N   SER A   9 "
         pdb=" CA  SER A   9 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  177.76    2.24     0      5.00e+00 4.00e-02 2.00e-01
dihedral pdb=" CA  PRO A  42 "
         pdb=" CB  PRO A  42 "
         pdb=" CG  PRO A  42 "
         pdb=" CD  PRO A  42 "
    ideal   model   delta sinusoidal    sigma   weight residual
    38.00   30.61    7.39     1      2.00e+01 2.50e-03 1.99e-01
dihedral pdb=" CB  GLN A  72 "
         pdb=" CG  GLN A  72 "
         pdb=" CD  GLN A  72 "
         pdb=" OE1 GLN A  72 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  168.96   11.04     2      3.00e+01 1.11e-03 1.96e-01
dihedral pdb=" N   PRO A  42 "
         pdb=" CA  PRO A  42 "
         pdb=" CB  PRO A  42 "
         pdb=" CG  PRO A  42 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -30.00  -22.82   -7.18     1      2.00e+01 2.50e-03 1.88e-01
dihedral pdb=" CA  THR A  48 "
         pdb=" C   THR A  48 "
         pdb=" N   LEU A  49 "
         pdb=" CA  LEU A  49 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00 -177.86   -2.14     0      5.00e+00 4.00e-02 1.83e-01
dihedral pdb=" CA  LEU A  28 "
         pdb=" C   LEU A  28 "
         pdb=" N   ASN A  29 "
         pdb=" CA  ASN A  29 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  177.86    2.14     0      5.00e+00 4.00e-02 1.83e-01
dihedral pdb=" N   THR A  14 "
         pdb=" CA  THR A  14 "
         pdb=" CB  THR A  14 "
         pdb=" OG1 THR A  14 "
    ideal   model   delta sinusoidal    sigma   weight residual
    60.00   54.69    5.31     3      1.50e+01 4.44e-03 1.82e-01
dihedral pdb=" CA  ILE A   6 "
         pdb=" C   ILE A   6 "
         pdb=" N   LYS A   7 "
         pdb=" CA  LYS A   7 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -177.92   -2.08     0      5.00e+00 4.00e-02 1.73e-01
dihedral pdb=" CA  ILE A  47 "
         pdb=" C   ILE A  47 "
         pdb=" N   THR A  48 "
         pdb=" CA  THR A  48 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  178.05    1.95     0      5.00e+00 4.00e-02 1.52e-01
dihedral pdb=" CB  GLN A  31 "
         pdb=" CG  GLN A  31 "
         pdb=" CD  GLN A  31 "
         pdb=" OE1 GLN A  31 "
    ideal   model   delta sinusoidal    sigma   weight residual
     0.00    9.68   -9.68     2      3.00e+01 1.11e-03 1.51e-01
dihedral pdb=" N   PRO A  42 "
         pdb=" CG  PRO A  42 "
         pdb=" CD  PRO A  42 "
         pdb=" CB  PRO A  42 "
    ideal   model   delta sinusoidal    sigma   weight residual
    30.00   25.39    4.61     1      1.50e+01 4.44e-03 1.38e-01
dihedral pdb=" CA  VAL A   4 "
         pdb=" C   VAL A   4 "
         pdb=" N   GLU A   5 "
         pdb=" CA  GLU A   5 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  178.17    1.83     0      5.00e+00 4.00e-02 1.33e-01
dihedral pdb=" CA  PHE A  68 "
         pdb=" CB  PHE A  68 "
         pdb=" CG  PHE A  68 "
         pdb=" CD1 PHE A  68 "
    ideal   model   delta sinusoidal    sigma   weight residual
    90.00   84.00    6.00     2      2.00e+01 2.50e-03 1.31e-01
dihedral pdb=" CA  LEU A  44 "
         pdb=" C   LEU A  44 "
         pdb=" N   VAL A  45 "
         pdb=" CA  VAL A  45 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  178.22    1.78     0      5.00e+00 4.00e-02 1.26e-01
dihedral pdb=" CA  SER A  66 "
         pdb=" C   SER A  66 "
         pdb=" N   SER A  67 "
         pdb=" CA  SER A  67 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  178.24    1.76     0      5.00e+00 4.00e-02 1.24e-01
dihedral pdb=" CA  GLU A  40 "
         pdb=" C   GLU A  40 "
         pdb=" N   TYR A  41 "
         pdb=" CA  TYR A  41 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00 -178.24   -1.76     0      5.00e+00 4.00e-02 1.24e-01
dihedral pdb=" CA  VAL A  70 "
         pdb=" C   VAL A  70 "
         pdb=" N   GLY A  71 "
         pdb=" CA  GLY A  71 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00 -178.30   -1.70     0      5.00e+00 4.00e-02 1.15e-01
dihedral pdb=" CA  GLY A  74 "
         pdb=" C   GLY A  74 "
         pdb=" N   SER A  75 "
         pdb=" CA  SER A  75 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -178.35   -1.65     0      5.00e+00 4.00e-02 1.09e-01
dihedral pdb=" N   VAL A  35 "
         pdb=" CA  VAL A  35 "
         pdb=" CB  VAL A  35 "
         pdb=" CG1 VAL A  35 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  175.89    4.11     3      1.50e+01 4.44e-03 1.09e-01
dihedral pdb=" N   PRO A  54 "
         pdb=" CG  PRO A  54 "
         pdb=" CD  PRO A  54 "
         pdb=" CB  PRO A  54 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -30.00  -34.10    4.10     1      1.50e+01 4.44e-03 1.09e-01
dihedral pdb=" N   LEU A  83 "
         pdb=" CA  LEU A  83 "
         pdb=" CB  LEU A  83 "
         pdb=" CG  LEU A  83 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -55.97   -4.03     3      1.50e+01 4.44e-03 1.05e-01
dihedral pdb=" CA  ALA A  11 "
         pdb=" C   ALA A  11 "
         pdb=" N   GLN A  12 "
         pdb=" CA  GLN A  12 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  178.44    1.56     0      5.00e+00 4.00e-02 9.70e-02
dihedral pdb=" N   ILE A   6 "
         pdb=" CA  ILE A   6 "
         pdb=" CB  ILE A   6 "
         pdb=" CG1 ILE A   6 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -56.23   -3.77     3      1.50e+01 4.44e-03 9.19e-02
dihedral pdb=" CA  ASP A  36 "
         pdb=" C   ASP A  36 "
         pdb=" N   LEU A  37 "
         pdb=" CA  LEU A  37 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00 -178.54   -1.46     0      5.00e+00 4.00e-02 8.58e-02
dihedral pdb=" N   ASN A  39 "
         pdb=" CA  ASN A  39 "
         pdb=" CB  ASN A  39 "
         pdb=" CG  ASN A  39 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -56.37   -3.63     3      1.50e+01 4.44e-03 8.53e-02
dihedral pdb=" CA  LEU A  44 "
         pdb=" CB  LEU A  44 "
         pdb=" CG  LEU A  44 "
         pdb=" CD1 LEU A  44 "
    ideal   model   delta sinusoidal    sigma   weight residual
    60.00   56.39    3.61     3      1.50e+01 4.44e-03 8.46e-02
dihedral pdb=" CA  GLU A  51 "
         pdb=" C   GLU A  51 "
         pdb=" N   GLY A  52 "
         pdb=" CA  GLY A  52 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  178.56    1.44     0      5.00e+00 4.00e-02 8.30e-02
dihedral pdb=" CB  GLU A   5 "
         pdb=" CG  GLU A   5 "
         pdb=" CD  GLU A   5 "
         pdb=" OE1 GLU A   5 "
    ideal   model   delta sinusoidal    sigma   weight residual
     0.00   -7.10    7.10     1      3.00e+01 1.11e-03 8.18e-02
dihedral pdb=" CA  THR A  14 "
         pdb=" C   THR A  14 "
         pdb=" N   THR A  15 "
         pdb=" CA  THR A  15 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -178.62   -1.38     0      5.00e+00 4.00e-02 7.65e-02
dihedral pdb=" N   ASP A  79 "
         pdb=" CA  ASP A  79 "
         pdb=" CB  ASP A  79 "
         pdb=" CG  ASP A  79 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -176.65   -3.35     3      1.50e+01 4.44e-03 7.28e-02
dihedral pdb=" CA  TYR A  56 "
         pdb=" C   TYR A  56 "
         pdb=" N   ALA A  57 "
         pdb=" CA  ALA A  57 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  178.65    1.35     0      5.00e+00 4.00e-02 7.25e-02
dihedral pdb=" N   GLN A  10 "
         pdb=" CA  GLN A  10 "
         pdb=" CB  GLN A  10 "
         pdb=" CG  GLN A  10 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -63.31    3.31     3      1.50e+01 4.44e-03 7.10e-02
dihedral pdb=" N   TYR A  56 "
         pdb=" CA  TYR A  56 "
         pdb=" CB  TYR A  56 "
         pdb=" CG  TYR A  56 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -63.17    3.17     3      1.50e+01 4.44e-03 6.50e-02
dihedral pdb=" CB  ARG A  82 "
         pdb=" CG  ARG A  82 "
         pdb=" CD  ARG A  82 "
         pdb=" NE  ARG A  82 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -176.84   -3.16     3      1.50e+01 4.44e-03 6.47e-02
dihedral pdb=" CA  TYR A  61 "
         pdb=" CB  TYR A  61 "
         pdb=" CG  TYR A  61 "
         pdb=" CD1 TYR A  61 "
    ideal   model   delta sinusoidal    sigma   weight residual
    90.00   85.79    4.21     2      2.00e+01 2.50e-03 6.46e-02
dihedral pdb=" CA  ASP A  79 "
         pdb=" C   ASP A  79 "
         pdb=" N   ARG A  80 "
         pdb=" CA  ARG A  80 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  178.74    1.26     0      5.00e+00 4.00e-02 6.35e-02
dihedral pdb=" N   LEU A  32 "
         pdb=" CA  LEU A  32 "
         pdb=" CB  LEU A  32 "
         pdb=" CG  LEU A  32 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -63.03    3.03     3      1.50e+01 4.44e-03 5.97e-02
dihedral pdb=" CA  LYS A   7 "
         pdb=" C   LYS A   7 "
         pdb=" N   PRO A   8 "
         pdb=" CA  PRO A   8 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -178.78   -1.22     0      5.00e+00 4.00e-02 5.91e-02
dihedral pdb=" CA  LEU A  83 "
         pdb=" CB  LEU A  83 "
         pdb=" CG  LEU A  83 "
         pdb=" CD1 LEU A  83 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00 -176.99   -3.01     3      1.50e+01 4.44e-03 5.86e-02
dihedral pdb=" CA  VAL A  84 "
         pdb=" C   VAL A  84 "
         pdb=" N   PRO A  85 "
         pdb=" CA  PRO A  85 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  178.80    1.20     0      5.00e+00 4.00e-02 5.74e-02
dihedral pdb=" CA  LEU A  49 "
         pdb=" CB  LEU A  49 "
         pdb=" CG  LEU A  49 "
         pdb=" CD1 LEU A  49 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  177.03    2.97     3      1.50e+01 4.44e-03 5.71e-02
dihedral pdb=" CA  GLN A  31 "
         pdb=" C   GLN A  31 "
         pdb=" N   LEU A  32 "
         pdb=" CA  LEU A  32 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  178.84    1.16     0      5.00e+00 4.00e-02 5.37e-02
dihedral pdb=" CA  ARG A  16 "
         pdb=" CB  ARG A  16 "
         pdb=" CG  ARG A  16 "
         pdb=" CD  ARG A  16 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -177.14   -2.86     3      1.50e+01 4.44e-03 5.32e-02
dihedral pdb=" N   THR A  48 "
         pdb=" CA  THR A  48 "
         pdb=" CB  THR A  48 "
         pdb=" OG1 THR A  48 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -57.15   -2.85     3      1.50e+01 4.44e-03 5.27e-02
dihedral pdb=" N   LEU A  49 "
         pdb=" CA  LEU A  49 "
         pdb=" CB  LEU A  49 "
         pdb=" CG  LEU A  49 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -57.16   -2.84     3      1.50e+01 4.44e-03 5.25e-02
dihedral pdb=" N   PRO A  85 "
         pdb=" CG  PRO A  85 "
         pdb=" CD  PRO A  85 "
         pdb=" CB  PRO A  85 "
    ideal   model   delta sinusoidal    sigma   weight residual
    30.00   27.36    2.64     1      1.50e+01 4.44e-03 4.52e-02
dihedral pdb=" CA  PRO A  58 "
         pdb=" C   PRO A  58 "
         pdb=" N   GLY A  59 "
         pdb=" CA  GLY A  59 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -178.94   -1.06     0      5.00e+00 4.00e-02 4.46e-02
dihedral pdb=" N   LYS A  69 "
         pdb=" CA  LYS A  69 "
         pdb=" CB  LYS A  69 "
         pdb=" CG  LYS A  69 "
    ideal   model   delta sinusoidal    sigma   weight residual
    60.00   57.44    2.56     3      1.50e+01 4.44e-03 4.27e-02
dihedral pdb=" CA  GLY A  38 "
         pdb=" C   GLY A  38 "
         pdb=" N   ASN A  39 "
         pdb=" CA  ASN A  39 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -178.99   -1.01     0      5.00e+00 4.00e-02 4.10e-02
dihedral pdb=" CA  PHE A  13 "
         pdb=" CB  PHE A  13 "
         pdb=" CG  PHE A  13 "
         pdb=" CD1 PHE A  13 "
    ideal   model   delta sinusoidal    sigma   weight residual
    90.00   86.66    3.34     2      2.00e+01 2.50e-03 4.06e-02
dihedral pdb=" CA  GLN A  72 "
         pdb=" C   GLN A  72 "
         pdb=" N   PHE A  73 "
         pdb=" CA  PHE A  73 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  179.07    0.93     0      5.00e+00 4.00e-02 3.50e-02
dihedral pdb=" CD  ARG A  16 "
         pdb=" NE  ARG A  16 "
         pdb=" CZ  ARG A  16 "
         pdb=" NH1 ARG A  16 "
    ideal   model   delta sinusoidal    sigma   weight residual
     0.00    1.55   -1.55     1      1.00e+01 1.00e-02 3.49e-02
dihedral pdb=" N   VAL A  70 "
         pdb=" CA  VAL A  70 "
         pdb=" CB  VAL A  70 "
         pdb=" CG1 VAL A  70 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  177.71    2.29     3      1.50e+01 4.44e-03 3.42e-02
dihedral pdb=" CD1 TYR A  26 "
         pdb=" CE1 TYR A  26 "
         pdb=" CZ  TYR A  26 "
         pdb=" OH  TYR A  26 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -179.14   -0.86     0      5.00e+00 4.00e-02 2.99e-02
dihedral pdb=" CA  TYR A  34 "
         pdb=" CB  TYR A  34 "
         pdb=" CG  TYR A  34 "
         pdb=" CD1 TYR A  34 "
    ideal   model   delta sinusoidal    sigma   weight residual
    90.00   87.27    2.73     2      2.00e+01 2.50e-03 2.71e-02
dihedral pdb=" CA  PRO A   8 "
         pdb=" CB  PRO A   8 "
         pdb=" CG  PRO A   8 "
         pdb=" CD  PRO A   8 "
    ideal   model   delta sinusoidal    sigma   weight residual
    38.00   35.39    2.61     1      2.00e+01 2.50e-03 2.49e-02
dihedral pdb=" N   PRO A   8 "
         pdb=" CA  PRO A   8 "
         pdb=" CB  PRO A   8 "
         pdb=" CG  PRO A   8 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -30.00  -32.60    2.60     1      2.00e+01 2.50e-03 2.47e-02
dihedral pdb=" N   GLN A  72 "
         pdb=" CA  GLN A  72 "
         pdb=" CB  GLN A  72 "
         pdb=" CG  GLN A  72 "
    ideal   model   delta sinusoidal    sigma   weight residual
    60.00   58.06    1.94     3      1.50e+01 4.44e-03 2.45e-02
dihedral pdb=" N   GLU A  51 "
         pdb=" CA  GLU A  51 "
         pdb=" CB  GLU A  51 "
         pdb=" CG  GLU A  51 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -61.93    1.93     3      1.50e+01 4.44e-03 2.41e-02
dihedral pdb=" CG  ARG A  16 "
         pdb=" CD  ARG A  16 "
         pdb=" NE  ARG A  16 "
         pdb=" CZ  ARG A  16 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00 -178.23   -1.77     2      1.50e+01 4.44e-03 2.04e-02
dihedral pdb=" CA  LYS A   3 "
         pdb=" C   LYS A   3 "
         pdb=" N   VAL A   4 "
         pdb=" CA  VAL A   4 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  179.29    0.71     0      5.00e+00 4.00e-02 2.00e-02
dihedral pdb=" CA  LEU A  81 "
         pdb=" CB  LEU A  81 "
         pdb=" CG  LEU A  81 "
         pdb=" CD1 LEU A  81 "
    ideal   model   delta sinusoidal    sigma   weight residual
    60.00   61.72   -1.72     3      1.50e+01 4.44e-03 1.92e-02
dihedral pdb=" CG  LYS A  46 "
         pdb=" CD  LYS A  46 "
         pdb=" CE  LYS A  46 "
         pdb=" NZ  LYS A  46 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  178.28    1.72     3      1.50e+01 4.44e-03 1.91e-02
dihedral pdb=" CA  ASN A  39 "
         pdb=" CB  ASN A  39 "
         pdb=" CG  ASN A  39 "
         pdb=" OD1 ASN A  39 "
    ideal   model   delta sinusoidal    sigma   weight residual
   120.00  122.17   -2.17     2      2.00e+01 2.50e-03 1.73e-02
dihedral pdb=" N   GLU A   5 "
         pdb=" CA  GLU A   5 "
         pdb=" CB  GLU A   5 "
         pdb=" CG  GLU A   5 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00 -178.43   -1.57     3      1.50e+01 4.44e-03 1.60e-02
dihedral pdb=" CA  GLN A  31 "
         pdb=" CB  GLN A  31 "
         pdb=" CG  GLN A  31 "
         pdb=" CD  GLN A  31 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00 -178.52   -1.48     3      1.50e+01 4.44e-03 1.42e-02
dihedral pdb=" CA  HIS A  64 "
         pdb=" C   HIS A  64 "
         pdb=" N   LEU A  65 "
         pdb=" CA  LEU A  65 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -179.41   -0.59     0      5.00e+00 4.00e-02 1.41e-02
dihedral pdb=" CA  MSE A  77 "
         pdb=" CB  MSE A  77 "
         pdb=" CG  MSE A  77 "
         pdb="SE   MSE A  77 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -178.53   -1.47     3      1.50e+01 4.44e-03 1.40e-02
dihedral pdb=" CA  PRO A  54 "
         pdb=" CB  PRO A  54 "
         pdb=" CG  PRO A  54 "
         pdb=" CD  PRO A  54 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -38.00  -39.91    1.91     1      2.00e+01 2.50e-03 1.34e-02
dihedral pdb=" CD1 TYR A  56 "
         pdb=" CE1 TYR A  56 "
         pdb=" CZ  TYR A  56 "
         pdb=" OH  TYR A  56 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  179.45    0.55     0      5.00e+00 4.00e-02 1.20e-02
dihedral pdb=" N   PRO A  58 "
         pdb=" CG  PRO A  58 "
         pdb=" CD  PRO A  58 "
         pdb=" CB  PRO A  58 "
    ideal   model   delta sinusoidal    sigma   weight residual
    30.00   28.87    1.13     1      1.50e+01 4.44e-03 8.31e-03
dihedral pdb=" CA  LEU A  60 "
         pdb=" CB  LEU A  60 "
         pdb=" CG  LEU A  60 "
         pdb=" CD1 LEU A  60 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  179.00    1.00     3      1.50e+01 4.44e-03 6.48e-03
dihedral pdb=" CD1 TYR A  61 "
         pdb=" CE1 TYR A  61 "
         pdb=" CZ  TYR A  61 "
         pdb=" OH  TYR A  61 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -179.60   -0.40     0      5.00e+00 4.00e-02 6.26e-03
dihedral pdb=" N   PRO A  54 "
         pdb=" CA  PRO A  54 "
         pdb=" CB  PRO A  54 "
         pdb=" CG  PRO A  54 "
    ideal   model   delta sinusoidal    sigma   weight residual
    30.00   28.84    1.16     1      2.00e+01 2.50e-03 4.92e-03
dihedral pdb=" CA  ASN A  29 "
         pdb=" C   ASN A  29 "
         pdb=" N   GLU A  30 "
         pdb=" CA  GLU A  30 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -179.66   -0.34     0      5.00e+00 4.00e-02 4.52e-03
dihedral pdb=" CA  ARG A  80 "
         pdb=" CB  ARG A  80 "
         pdb=" CG  ARG A  80 "
         pdb=" CD  ARG A  80 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -179.27   -0.73     3      1.50e+01 4.44e-03 3.46e-03
dihedral pdb=" CA  ILE A   2 "
         pdb=" CB  ILE A   2 "
         pdb=" CG1 ILE A   2 "
         pdb=" CD1 ILE A   2 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -60.71    0.71     3      1.50e+01 4.44e-03 3.24e-03
dihedral pdb=" CA  VAL A  63 "
         pdb=" C   VAL A  63 "
         pdb=" N   HIS A  64 "
         pdb=" CA  HIS A  64 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00 -179.74   -0.26     0      5.00e+00 4.00e-02 2.77e-03
dihedral pdb=" CA  PRO A  58 "
         pdb=" CB  PRO A  58 "
         pdb=" CG  PRO A  58 "
         pdb=" CD  PRO A  58 "
    ideal   model   delta sinusoidal    sigma   weight residual
    38.00   37.17    0.83     1      2.00e+01 2.50e-03 2.54e-03
dihedral pdb=" CD  ARG A  82 "
         pdb=" NE  ARG A  82 "
         pdb=" CZ  ARG A  82 "
         pdb=" NH1 ARG A  82 "
    ideal   model   delta sinusoidal    sigma   weight residual
     0.00    0.35   -0.35     1      1.00e+01 1.00e-02 1.82e-03
dihedral pdb=" N   TYR A  61 "
         pdb=" CA  TYR A  61 "
         pdb=" CB  TYR A  61 "
         pdb=" CG  TYR A  61 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -59.52   -0.48     3      1.50e+01 4.44e-03 1.47e-03
dihedral pdb=" N   GLU A  30 "
         pdb=" CA  GLU A  30 "
         pdb=" CB  GLU A  30 "
         pdb=" CG  GLU A  30 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -59.66   -0.34     3      1.50e+01 4.44e-03 7.53e-04
dihedral pdb=" CG  LYS A  69 "
         pdb=" CD  LYS A  69 "
         pdb=" CE  LYS A  69 "
         pdb=" NZ  LYS A  69 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -179.66   -0.34     3      1.50e+01 4.44e-03 7.32e-04
dihedral pdb=" CD  ARG A  80 "
         pdb=" NE  ARG A  80 "
         pdb=" CZ  ARG A  80 "
         pdb=" NH1 ARG A  80 "
    ideal   model   delta sinusoidal    sigma   weight residual
     0.00    0.22   -0.22     1      1.00e+01 1.00e-02 7.06e-04
dihedral pdb=" CD1 TYR A  34 "
         pdb=" CE1 TYR A  34 "
         pdb=" CZ  TYR A  34 "
         pdb=" OH  TYR A  34 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  179.89    0.11     0      5.00e+00 4.00e-02 4.90e-04
dihedral pdb=" N   LYS A   3 "
         pdb=" CA  LYS A   3 "
         pdb=" CB  LYS A   3 "
         pdb=" CG  LYS A   3 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  179.73    0.27     3      1.50e+01 4.44e-03 4.72e-04
dihedral pdb=" CA  LEU A  81 "
         pdb=" C   LEU A  81 "
         pdb=" N   ARG A  82 "
         pdb=" CA  ARG A  82 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -179.96   -0.04     0      5.00e+00 4.00e-02 7.40e-05
dihedral pdb=" CD1 TYR A  41 "
         pdb=" CE1 TYR A  41 "
         pdb=" CZ  TYR A  41 "
         pdb=" OH  TYR A  41 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -179.96   -0.04     0      5.00e+00 4.00e-02 5.64e-05
dihedral pdb=" CA  TYR A  34 "
         pdb=" C   TYR A  34 "
         pdb=" N   VAL A  35 "
         pdb=" CA  VAL A  35 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -179.96   -0.04     0      5.00e+00 4.00e-02 5.19e-05
dihedral pdb=" N   THR A  15 "
         pdb=" CA  THR A  15 "
         pdb=" CB  THR A  15 "
         pdb=" OG1 THR A  15 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -60.07    0.07     3      1.50e+01 4.44e-03 3.21e-05
dihedral pdb=" N   PRO A  58 "
         pdb=" CA  PRO A  58 "
         pdb=" CB  PRO A  58 "
         pdb=" CG  PRO A  58 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -30.00  -30.09    0.09     1      2.00e+01 2.50e-03 3.06e-05
dihedral pdb=" CA  LYS A  46 "
         pdb=" C   LYS A  46 "
         pdb=" N   ILE A  47 "
         pdb=" CA  ILE A  47 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -179.99   -0.01     0      5.00e+00 4.00e-02 4.18e-06

Dihedral angle | C-Beta improper | restraints: 142
Sorted by residual:
dihedral pdb=" C   MSE A  77 "
         pdb=" N   MSE A  77 "
         pdb=" CA  MSE A  77 "
         pdb=" CB  MSE A  77 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -105.99  -16.61     0      2.50e+00 1.60e-01 4.42e+01
dihedral pdb=" N   MSE A  77 "
         pdb=" C   MSE A  77 "
         pdb=" CA  MSE A  77 "
         pdb=" CB  MSE A  77 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  111.76   11.04     0      2.50e+00 1.60e-01 1.95e+01
dihedral pdb=" N   TYR A  26 "
         pdb=" C   TYR A  26 "
         pdb=" CA  TYR A  26 "
         pdb=" CB  TYR A  26 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  129.70   -6.90     0      2.50e+00 1.60e-01 7.62e+00
dihedral pdb=" C   TYR A  26 "
         pdb=" N   TYR A  26 "
         pdb=" CA  TYR A  26 "
         pdb=" CB  TYR A  26 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -128.63    6.03     0      2.50e+00 1.60e-01 5.82e+00
dihedral pdb=" C   GLN A  53 "
         pdb=" N   GLN A  53 "
         pdb=" CA  GLN A  53 "
         pdb=" CB  GLN A  53 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -127.78    5.18     0      2.50e+00 1.60e-01 4.29e+00
dihedral pdb=" C   ASP A  36 "
         pdb=" N   ASP A  36 "
         pdb=" CA  ASP A  36 "
         pdb=" CB  ASP A  36 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -127.68    5.08     0      2.50e+00 1.60e-01 4.13e+00
dihedral pdb=" C   VAL A  63 "
         pdb=" N   VAL A  63 "
         pdb=" CA  VAL A  63 "
         pdb=" CB  VAL A  63 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.00 -126.59    4.59     0      2.50e+00 1.60e-01 3.37e+00
dihedral pdb=" C   TYR A  61 "
         pdb=" N   TYR A  61 "
         pdb=" CA  TYR A  61 "
         pdb=" CB  TYR A  61 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -118.16   -4.44     0      2.50e+00 1.60e-01 3.15e+00
dihedral pdb=" C   CYS A  33 "
         pdb=" N   CYS A  33 "
         pdb=" CA  CYS A  33 "
         pdb=" CB  CYS A  33 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -118.21   -4.39     0      2.50e+00 1.60e-01 3.08e+00
dihedral pdb=" N   SER A   9 "
         pdb=" C   SER A   9 "
         pdb=" CA  SER A   9 "
         pdb=" CB  SER A   9 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  118.86    3.94     0      2.50e+00 1.60e-01 2.48e+00
dihedral pdb=" N   GLN A  10 "
         pdb=" C   GLN A  10 "
         pdb=" CA  GLN A  10 "
         pdb=" CB  GLN A  10 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  119.06    3.74     0      2.50e+00 1.60e-01 2.24e+00
dihedral pdb=" C   VAL A  45 "
         pdb=" N   VAL A  45 "
         pdb=" CA  VAL A  45 "
         pdb=" CB  VAL A  45 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.00 -125.41    3.41     0      2.50e+00 1.60e-01 1.86e+00
dihedral pdb=" N   PHE A  68 "
         pdb=" C   PHE A  68 "
         pdb=" CA  PHE A  68 "
         pdb=" CB  PHE A  68 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  126.15   -3.35     0      2.50e+00 1.60e-01 1.80e+00
dihedral pdb=" C   TYR A  56 "
         pdb=" N   TYR A  56 "
         pdb=" CA  TYR A  56 "
         pdb=" CB  TYR A  56 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -119.31   -3.29     0      2.50e+00 1.60e-01 1.73e+00
dihedral pdb=" N   ASP A  36 "
         pdb=" C   ASP A  36 "
         pdb=" CA  ASP A  36 "
         pdb=" CB  ASP A  36 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  125.95   -3.15     0      2.50e+00 1.60e-01 1.59e+00
dihedral pdb=" C   SER A   9 "
         pdb=" N   SER A   9 "
         pdb=" CA  SER A   9 "
         pdb=" CB  SER A   9 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -119.53   -3.07     0      2.50e+00 1.60e-01 1.51e+00
dihedral pdb=" N   PHE A  13 "
         pdb=" C   PHE A  13 "
         pdb=" CA  PHE A  13 "
         pdb=" CB  PHE A  13 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  125.87   -3.07     0      2.50e+00 1.60e-01 1.51e+00
dihedral pdb=" C   PRO A  54 "
         pdb=" N   PRO A  54 "
         pdb=" CA  PRO A  54 "
         pdb=" CB  PRO A  54 "
    ideal   model   delta  harmonic     sigma   weight residual
  -120.70 -117.91   -2.79     0      2.50e+00 1.60e-01 1.25e+00
dihedral pdb=" N   ASP A  79 "
         pdb=" C   ASP A  79 "
         pdb=" CA  ASP A  79 "
         pdb=" CB  ASP A  79 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  120.02    2.78     0      2.50e+00 1.60e-01 1.24e+00
dihedral pdb=" C   GLU A   5 "
         pdb=" N   GLU A   5 "
         pdb=" CA  GLU A   5 "
         pdb=" CB  GLU A   5 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -119.82   -2.78     0      2.50e+00 1.60e-01 1.24e+00
dihedral pdb=" N   TYR A  61 "
         pdb=" C   TYR A  61 "
         pdb=" CA  TYR A  61 "
         pdb=" CB  TYR A  61 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  120.03    2.77     0      2.50e+00 1.60e-01 1.23e+00
dihedral pdb=" N   GLN A  12 "
         pdb=" C   GLN A  12 "
         pdb=" CA  GLN A  12 "
         pdb=" CB  GLN A  12 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  120.14    2.66     0      2.50e+00 1.60e-01 1.13e+00
dihedral pdb=" C   LEU A  60 "
         pdb=" N   LEU A  60 "
         pdb=" CA  LEU A  60 "
         pdb=" CB  LEU A  60 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -125.25    2.65     0      2.50e+00 1.60e-01 1.12e+00
dihedral pdb=" N   VAL A  45 "
         pdb=" C   VAL A  45 "
         pdb=" CA  VAL A  45 "
         pdb=" CB  VAL A  45 "
    ideal   model   delta  harmonic     sigma   weight residual
   123.40  126.03   -2.63     0      2.50e+00 1.60e-01 1.11e+00
dihedral pdb=" C   VAL A  35 "
         pdb=" N   VAL A  35 "
         pdb=" CA  VAL A  35 "
         pdb=" CB  VAL A  35 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.00 -124.54    2.54     0      2.50e+00 1.60e-01 1.03e+00
dihedral pdb=" N   CYS A  33 "
         pdb=" C   CYS A  33 "
         pdb=" CA  CYS A  33 "
         pdb=" CB  CYS A  33 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  120.28    2.52     0      2.50e+00 1.60e-01 1.01e+00
dihedral pdb=" N   GLN A  53 "
         pdb=" C   GLN A  53 "
         pdb=" CA  GLN A  53 "
         pdb=" CB  GLN A  53 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  125.26   -2.46     0      2.50e+00 1.60e-01 9.65e-01
dihedral pdb=" N   PRO A  54 "
         pdb=" C   PRO A  54 "
         pdb=" CA  PRO A  54 "
         pdb=" CB  PRO A  54 "
    ideal   model   delta  harmonic     sigma   weight residual
   115.10  112.67    2.43     0      2.50e+00 1.60e-01 9.41e-01
dihedral pdb=" C   PHE A  68 "
         pdb=" N   PHE A  68 "
         pdb=" CA  PHE A  68 "
         pdb=" CB  PHE A  68 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -124.97    2.37     0      2.50e+00 1.60e-01 9.00e-01
dihedral pdb=" C   ILE A   6 "
         pdb=" N   ILE A   6 "
         pdb=" CA  ILE A   6 "
         pdb=" CB  ILE A   6 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.00 -119.65   -2.35     0      2.50e+00 1.60e-01 8.87e-01
dihedral pdb=" N   ALA A  57 "
         pdb=" C   ALA A  57 "
         pdb=" CA  ALA A  57 "
         pdb=" CB  ALA A  57 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.90  120.58    2.32     0      2.50e+00 1.60e-01 8.62e-01
dihedral pdb=" C   GLN A  12 "
         pdb=" N   GLN A  12 "
         pdb=" CA  GLN A  12 "
         pdb=" CB  GLN A  12 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -120.30   -2.30     0      2.50e+00 1.60e-01 8.46e-01
dihedral pdb=" N   ILE A   6 "
         pdb=" C   ILE A   6 "
         pdb=" CA  ILE A   6 "
         pdb=" CB  ILE A   6 "
    ideal   model   delta  harmonic     sigma   weight residual
   123.40  121.10    2.30     0      2.50e+00 1.60e-01 8.45e-01
dihedral pdb=" C   PHE A  13 "
         pdb=" N   PHE A  13 "
         pdb=" CA  PHE A  13 "
         pdb=" CB  PHE A  13 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -124.89    2.29     0      2.50e+00 1.60e-01 8.36e-01
dihedral pdb=" N   VAL A  63 "
         pdb=" C   VAL A  63 "
         pdb=" CA  VAL A  63 "
         pdb=" CB  VAL A  63 "
    ideal   model   delta  harmonic     sigma   weight residual
   123.40  125.66   -2.26     0      2.50e+00 1.60e-01 8.17e-01
dihedral pdb=" C   LEU A  37 "
         pdb=" N   LEU A  37 "
         pdb=" CA  LEU A  37 "
         pdb=" CB  LEU A  37 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -124.85    2.25     0      2.50e+00 1.60e-01 8.08e-01
dihedral pdb=" N   LEU A  81 "
         pdb=" C   LEU A  81 "
         pdb=" CA  LEU A  81 "
         pdb=" CB  LEU A  81 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  125.04   -2.24     0      2.50e+00 1.60e-01 8.01e-01
dihedral pdb=" C   ASP A  79 "
         pdb=" N   ASP A  79 "
         pdb=" CA  ASP A  79 "
         pdb=" CB  ASP A  79 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -120.41   -2.19     0      2.50e+00 1.60e-01 7.67e-01
dihedral pdb=" N   LEU A  76 "
         pdb=" C   LEU A  76 "
         pdb=" CA  LEU A  76 "
         pdb=" CB  LEU A  76 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  124.97   -2.17     0      2.50e+00 1.60e-01 7.55e-01
dihedral pdb=" C   ARG A  82 "
         pdb=" N   ARG A  82 "
         pdb=" CA  ARG A  82 "
         pdb=" CB  ARG A  82 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -124.77    2.17     0      2.50e+00 1.60e-01 7.54e-01
dihedral pdb=" C   THR A  62 "
         pdb=" N   THR A  62 "
         pdb=" CA  THR A  62 "
         pdb=" CB  THR A  62 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.00 -124.13    2.13     0      2.50e+00 1.60e-01 7.25e-01
dihedral pdb=" C   PRO A  42 "
         pdb=" N   PRO A  42 "
         pdb=" CA  PRO A  42 "
         pdb=" CB  PRO A  42 "
    ideal   model   delta  harmonic     sigma   weight residual
  -120.70 -118.60   -2.10     0      2.50e+00 1.60e-01 7.03e-01
dihedral pdb=" C   GLN A  31 "
         pdb=" N   GLN A  31 "
         pdb=" CA  GLN A  31 "
         pdb=" CB  GLN A  31 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -124.68    2.08     0      2.50e+00 1.60e-01 6.91e-01
dihedral pdb=" C   LEU A  32 "
         pdb=" N   LEU A  32 "
         pdb=" CA  LEU A  32 "
         pdb=" CB  LEU A  32 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -124.50    1.90     0      2.50e+00 1.60e-01 5.79e-01
dihedral pdb=" N   GLU A  30 "
         pdb=" C   GLU A  30 "
         pdb=" CA  GLU A  30 "
         pdb=" CB  GLU A  30 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  124.70   -1.90     0      2.50e+00 1.60e-01 5.78e-01
dihedral pdb=" N   SER A  67 "
         pdb=" C   SER A  67 "
         pdb=" CA  SER A  67 "
         pdb=" CB  SER A  67 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  120.90    1.90     0      2.50e+00 1.60e-01 5.75e-01
dihedral pdb=" N   TYR A  56 "
         pdb=" C   TYR A  56 "
         pdb=" CA  TYR A  56 "
         pdb=" CB  TYR A  56 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  120.94    1.86     0      2.50e+00 1.60e-01 5.55e-01
dihedral pdb=" N   LEU A  60 "
         pdb=" C   LEU A  60 "
         pdb=" CA  LEU A  60 "
         pdb=" CB  LEU A  60 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  124.65   -1.85     0      2.50e+00 1.60e-01 5.50e-01
dihedral pdb=" C   LEU A  44 "
         pdb=" N   LEU A  44 "
         pdb=" CA  LEU A  44 "
         pdb=" CB  LEU A  44 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -120.75   -1.85     0      2.50e+00 1.60e-01 5.45e-01
dihedral pdb=" N   SER A  17 "
         pdb=" C   SER A  17 "
         pdb=" CA  SER A  17 "
         pdb=" CB  SER A  17 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  120.96    1.84     0      2.50e+00 1.60e-01 5.42e-01
dihedral pdb=" N   ARG A  80 "
         pdb=" C   ARG A  80 "
         pdb=" CA  ARG A  80 "
         pdb=" CB  ARG A  80 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  120.96    1.84     0      2.50e+00 1.60e-01 5.41e-01
dihedral pdb=" N   ILE A   2 "
         pdb=" C   ILE A   2 "
         pdb=" CA  ILE A   2 "
         pdb=" CB  ILE A   2 "
    ideal   model   delta  harmonic     sigma   weight residual
   123.40  125.21   -1.81     0      2.50e+00 1.60e-01 5.25e-01
dihedral pdb=" N   ARG A  82 "
         pdb=" C   ARG A  82 "
         pdb=" CA  ARG A  82 "
         pdb=" CB  ARG A  82 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  121.05    1.75     0      2.50e+00 1.60e-01 4.90e-01
dihedral pdb=" C   SER A  17 "
         pdb=" N   SER A  17 "
         pdb=" CA  SER A  17 "
         pdb=" CB  SER A  17 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -120.93   -1.67     0      2.50e+00 1.60e-01 4.47e-01
dihedral pdb=" N   LEU A  37 "
         pdb=" C   LEU A  37 "
         pdb=" CA  LEU A  37 "
         pdb=" CB  LEU A  37 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  124.47   -1.67     0      2.50e+00 1.60e-01 4.45e-01
dihedral pdb=" C   LEU A  65 "
         pdb=" N   LEU A  65 "
         pdb=" CA  LEU A  65 "
         pdb=" CB  LEU A  65 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -124.27    1.67     0      2.50e+00 1.60e-01 4.45e-01
dihedral pdb=" C   PRO A  85 "
         pdb=" N   PRO A  85 "
         pdb=" CA  PRO A  85 "
         pdb=" CB  PRO A  85 "
    ideal   model   delta  harmonic     sigma   weight residual
  -120.70 -119.04   -1.66     0      2.50e+00 1.60e-01 4.40e-01
dihedral pdb=" C   LEU A  76 "
         pdb=" N   LEU A  76 "
         pdb=" CA  LEU A  76 "
         pdb=" CB  LEU A  76 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -124.25    1.65     0      2.50e+00 1.60e-01 4.34e-01
dihedral pdb=" C   GLU A  51 "
         pdb=" N   GLU A  51 "
         pdb=" CA  GLU A  51 "
         pdb=" CB  GLU A  51 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -124.24    1.64     0      2.50e+00 1.60e-01 4.29e-01
dihedral pdb=" C   SER A  67 "
         pdb=" N   SER A  67 "
         pdb=" CA  SER A  67 "
         pdb=" CB  SER A  67 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -124.14    1.54     0      2.50e+00 1.60e-01 3.80e-01
dihedral pdb=" C   THR A  48 "
         pdb=" N   THR A  48 "
         pdb=" CA  THR A  48 "
         pdb=" CB  THR A  48 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.00 -120.47   -1.53     0      2.50e+00 1.60e-01 3.74e-01
dihedral pdb=" N   TYR A  34 "
         pdb=" C   TYR A  34 "
         pdb=" CA  TYR A  34 "
         pdb=" CB  TYR A  34 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  124.29   -1.49     0      2.50e+00 1.60e-01 3.55e-01
dihedral pdb=" N   ILE A  47 "
         pdb=" C   ILE A  47 "
         pdb=" CA  ILE A  47 "
         pdb=" CB  ILE A  47 "
    ideal   model   delta  harmonic     sigma   weight residual
   123.40  121.96    1.44     0      2.50e+00 1.60e-01 3.31e-01
dihedral pdb=" C   LEU A  81 "
         pdb=" N   LEU A  81 "
         pdb=" CA  LEU A  81 "
         pdb=" CB  LEU A  81 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -124.01    1.41     0      2.50e+00 1.60e-01 3.18e-01
dihedral pdb=" N   LEU A  32 "
         pdb=" C   LEU A  32 "
         pdb=" CA  LEU A  32 "
         pdb=" CB  LEU A  32 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  124.20   -1.40     0      2.50e+00 1.60e-01 3.15e-01
dihedral pdb=" N   LEU A  28 "
         pdb=" C   LEU A  28 "
         pdb=" CA  LEU A  28 "
         pdb=" CB  LEU A  28 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  121.46    1.34     0      2.50e+00 1.60e-01 2.89e-01
dihedral pdb=" C   SER A  66 "
         pdb=" N   SER A  66 "
         pdb=" CA  SER A  66 "
         pdb=" CB  SER A  66 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -121.26   -1.34     0      2.50e+00 1.60e-01 2.88e-01
dihedral pdb=" N   THR A  48 "
         pdb=" C   THR A  48 "
         pdb=" CA  THR A  48 "
         pdb=" CB  THR A  48 "
    ideal   model   delta  harmonic     sigma   weight residual
   123.40  122.07    1.33     0      2.50e+00 1.60e-01 2.84e-01
dihedral pdb=" C   GLU A  30 "
         pdb=" N   GLU A  30 "
         pdb=" CA  GLU A  30 "
         pdb=" CB  GLU A  30 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -123.90    1.30     0      2.50e+00 1.60e-01 2.71e-01
dihedral pdb=" N   LYS A  69 "
         pdb=" C   LYS A  69 "
         pdb=" CA  LYS A  69 "
         pdb=" CB  LYS A  69 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  121.52    1.28     0      2.50e+00 1.60e-01 2.64e-01
dihedral pdb=" N   GLN A  72 "
         pdb=" C   GLN A  72 "
         pdb=" CA  GLN A  72 "
         pdb=" CB  GLN A  72 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  124.07   -1.27     0      2.50e+00 1.60e-01 2.59e-01
dihedral pdb=" N   PRO A  58 "
         pdb=" C   PRO A  58 "
         pdb=" CA  PRO A  58 "
         pdb=" CB  PRO A  58 "
    ideal   model   delta  harmonic     sigma   weight residual
   115.10  116.36   -1.26     0      2.50e+00 1.60e-01 2.53e-01
dihedral pdb=" N   PRO A   8 "
         pdb=" C   PRO A   8 "
         pdb=" CA  PRO A   8 "
         pdb=" CB  PRO A   8 "
    ideal   model   delta  harmonic     sigma   weight residual
   115.10  113.85    1.25     0      2.50e+00 1.60e-01 2.52e-01
dihedral pdb=" C   ASN A  39 "
         pdb=" N   ASN A  39 "
         pdb=" CA  ASN A  39 "
         pdb=" CB  ASN A  39 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -121.35   -1.25     0      2.50e+00 1.60e-01 2.50e-01
dihedral pdb=" N   LYS A   7 "
         pdb=" C   LYS A   7 "
         pdb=" CA  LYS A   7 "
         pdb=" CB  LYS A   7 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  121.56    1.24     0      2.50e+00 1.60e-01 2.46e-01
dihedral pdb=" N   GLU A  51 "
         pdb=" C   GLU A  51 "
         pdb=" CA  GLU A  51 "
         pdb=" CB  GLU A  51 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  121.57    1.23     0      2.50e+00 1.60e-01 2.42e-01
dihedral pdb=" N   VAL A  70 "
         pdb=" C   VAL A  70 "
         pdb=" CA  VAL A  70 "
         pdb=" CB  VAL A  70 "
    ideal   model   delta  harmonic     sigma   weight residual
   123.40  122.18    1.22     0      2.50e+00 1.60e-01 2.37e-01
dihedral pdb=" C   THR A  15 "
         pdb=" N   THR A  15 "
         pdb=" CA  THR A  15 "
         pdb=" CB  THR A  15 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.00 -123.22    1.22     0      2.50e+00 1.60e-01 2.36e-01
dihedral pdb=" N   HIS A  64 "
         pdb=" C   HIS A  64 "
         pdb=" CA  HIS A  64 "
         pdb=" CB  HIS A  64 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  121.58    1.22     0      2.50e+00 1.60e-01 2.36e-01
dihedral pdb=" C   ARG A  80 "
         pdb=" N   ARG A  80 "
         pdb=" CA  ARG A  80 "
         pdb=" CB  ARG A  80 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -121.39   -1.21     0      2.50e+00 1.60e-01 2.36e-01
dihedral pdb=" C   SER A  27 "
         pdb=" N   SER A  27 "
         pdb=" CA  SER A  27 "
         pdb=" CB  SER A  27 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -123.79    1.19     0      2.50e+00 1.60e-01 2.28e-01
dihedral pdb=" N   ALA A  11 "
         pdb=" C   ALA A  11 "
         pdb=" CA  ALA A  11 "
         pdb=" CB  ALA A  11 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.90  121.75    1.15     0      2.50e+00 1.60e-01 2.12e-01
dihedral pdb=" N   VAL A   4 "
         pdb=" C   VAL A   4 "
         pdb=" CA  VAL A   4 "
         pdb=" CB  VAL A   4 "
    ideal   model   delta  harmonic     sigma   weight residual
   123.40  122.27    1.13     0      2.50e+00 1.60e-01 2.06e-01
dihedral pdb=" C   VAL A  43 "
         pdb=" N   VAL A  43 "
         pdb=" CA  VAL A  43 "
         pdb=" CB  VAL A  43 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.00 -123.10    1.10     0      2.50e+00 1.60e-01 1.95e-01
dihedral pdb=" C   PHE A  73 "
         pdb=" N   PHE A  73 "
         pdb=" CA  PHE A  73 "
         pdb=" CB  PHE A  73 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -121.50   -1.10     0      2.50e+00 1.60e-01 1.93e-01
dihedral pdb=" N   LEU A  44 "
         pdb=" C   LEU A  44 "
         pdb=" CA  LEU A  44 "
         pdb=" CB  LEU A  44 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  121.75    1.05     0      2.50e+00 1.60e-01 1.77e-01
dihedral pdb=" C   ILE A  78 "
         pdb=" N   ILE A  78 "
         pdb=" CA  ILE A  78 "
         pdb=" CB  ILE A  78 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.00 -120.95   -1.05     0      2.50e+00 1.60e-01 1.77e-01
dihedral pdb=" C   GLU A  40 "
         pdb=" N   GLU A  40 "
         pdb=" CA  GLU A  40 "
         pdb=" CB  GLU A  40 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -121.59   -1.01     0      2.50e+00 1.60e-01 1.62e-01
dihedral pdb=" C   ASN A  29 "
         pdb=" N   ASN A  29 "
         pdb=" CA  ASN A  29 "
         pdb=" CB  ASN A  29 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -123.59    0.99     0      2.50e+00 1.60e-01 1.57e-01
dihedral pdb=" N   ASN A  39 "
         pdb=" C   ASN A  39 "
         pdb=" CA  ASN A  39 "
         pdb=" CB  ASN A  39 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  121.82    0.98     0      2.50e+00 1.60e-01 1.52e-01
dihedral pdb=" C   LYS A   7 "
         pdb=" N   LYS A   7 "
         pdb=" CA  LYS A   7 "
         pdb=" CB  LYS A   7 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -123.56    0.96     0      2.50e+00 1.60e-01 1.46e-01
dihedral pdb=" C   GLN A  72 "
         pdb=" N   GLN A  72 "
         pdb=" CA  GLN A  72 "
         pdb=" CB  GLN A  72 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -123.50    0.90     0      2.50e+00 1.60e-01 1.28e-01
dihedral pdb=" N   SER A  66 "
         pdb=" C   SER A  66 "
         pdb=" CA  SER A  66 "
         pdb=" CB  SER A  66 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  121.90    0.90     0      2.50e+00 1.60e-01 1.28e-01
dihedral pdb=" C   GLN A  10 "
         pdb=" N   GLN A  10 "
         pdb=" CA  GLN A  10 "
         pdb=" CB  GLN A  10 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -121.72   -0.88     0      2.50e+00 1.60e-01 1.24e-01
dihedral pdb=" C   PRO A  58 "
         pdb=" N   PRO A  58 "
         pdb=" CA  PRO A  58 "
         pdb=" CB  PRO A  58 "
    ideal   model   delta  harmonic     sigma   weight residual
  -120.70 -121.57    0.87     0      2.50e+00 1.60e-01 1.20e-01
dihedral pdb=" C   VAL A  70 "
         pdb=" N   VAL A  70 "
         pdb=" CA  VAL A  70 "
         pdb=" CB  VAL A  70 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.00 -122.81    0.81     0      2.50e+00 1.60e-01 1.06e-01
dihedral pdb=" C   ALA A  11 "
         pdb=" N   ALA A  11 "
         pdb=" CA  ALA A  11 "
         pdb=" CB  ALA A  11 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -121.79   -0.81     0      2.50e+00 1.60e-01 1.05e-01
dihedral pdb=" N   ARG A  16 "
         pdb=" C   ARG A  16 "
         pdb=" CA  ARG A  16 "
         pdb=" CB  ARG A  16 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  121.99    0.81     0      2.50e+00 1.60e-01 1.04e-01
dihedral pdb=" C   ALA A  57 "
         pdb=" N   ALA A  57 "
         pdb=" CA  ALA A  57 "
         pdb=" CB  ALA A  57 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -121.80   -0.80     0      2.50e+00 1.60e-01 1.02e-01
dihedral pdb=" C   ARG A  16 "
         pdb=" N   ARG A  16 "
         pdb=" CA  ARG A  16 "
         pdb=" CB  ARG A  16 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -123.37    0.77     0      2.50e+00 1.60e-01 9.48e-02
dihedral pdb=" C   ILE A   2 "
         pdb=" N   ILE A   2 "
         pdb=" CA  ILE A   2 "
         pdb=" CB  ILE A   2 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.00 -122.75    0.75     0      2.50e+00 1.60e-01 9.12e-02
dihedral pdb=" N   ILE A  78 "
         pdb=" C   ILE A  78 "
         pdb=" CA  ILE A  78 "
         pdb=" CB  ILE A  78 "
    ideal   model   delta  harmonic     sigma   weight residual
   123.40  122.65    0.75     0      2.50e+00 1.60e-01 9.10e-02
dihedral pdb=" N   GLU A  40 "
         pdb=" C   GLU A  40 "
         pdb=" CA  GLU A  40 "
         pdb=" CB  GLU A  40 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  122.09    0.71     0      2.50e+00 1.60e-01 8.07e-02
dihedral pdb=" N   GLU A   5 "
         pdb=" C   GLU A   5 "
         pdb=" CA  GLU A   5 "
         pdb=" CB  GLU A   5 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  122.09    0.71     0      2.50e+00 1.60e-01 8.00e-02
dihedral pdb=" N   LEU A  83 "
         pdb=" C   LEU A  83 "
         pdb=" CA  LEU A  83 "
         pdb=" CB  LEU A  83 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  123.51   -0.71     0      2.50e+00 1.60e-01 7.96e-02
dihedral pdb=" C   HIS A  64 "
         pdb=" N   HIS A  64 "
         pdb=" CA  HIS A  64 "
         pdb=" CB  HIS A  64 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -123.29    0.69     0      2.50e+00 1.60e-01 7.65e-02
dihedral pdb=" N   ASN A  29 "
         pdb=" C   ASN A  29 "
         pdb=" CA  ASN A  29 "
         pdb=" CB  ASN A  29 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  122.16    0.64     0      2.50e+00 1.60e-01 6.63e-02
dihedral pdb=" C   THR A  14 "
         pdb=" N   THR A  14 "
         pdb=" CA  THR A  14 "
         pdb=" CB  THR A  14 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.00 -121.38   -0.62     0      2.50e+00 1.60e-01 6.06e-02
dihedral pdb=" N   LYS A  46 "
         pdb=" C   LYS A  46 "
         pdb=" CA  LYS A  46 "
         pdb=" CB  LYS A  46 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  123.40   -0.60     0      2.50e+00 1.60e-01 5.82e-02
dihedral pdb=" C   LEU A  49 "
         pdb=" N   LEU A  49 "
         pdb=" CA  LEU A  49 "
         pdb=" CB  LEU A  49 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -123.18    0.58     0      2.50e+00 1.60e-01 5.29e-02
dihedral pdb=" N   THR A  14 "
         pdb=" C   THR A  14 "
         pdb=" CA  THR A  14 "
         pdb=" CB  THR A  14 "
    ideal   model   delta  harmonic     sigma   weight residual
   123.40  122.84    0.56     0      2.50e+00 1.60e-01 5.00e-02
dihedral pdb=" N   SER A  27 "
         pdb=" C   SER A  27 "
         pdb=" CA  SER A  27 "
         pdb=" CB  SER A  27 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  122.24    0.56     0      2.50e+00 1.60e-01 4.98e-02
dihedral pdb=" C   ILE A  47 "
         pdb=" N   ILE A  47 "
         pdb=" CA  ILE A  47 "
         pdb=" CB  ILE A  47 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.00 -122.54    0.54     0      2.50e+00 1.60e-01 4.67e-02
dihedral pdb=" N   VAL A  43 "
         pdb=" C   VAL A  43 "
         pdb=" CA  VAL A  43 "
         pdb=" CB  VAL A  43 "
    ideal   model   delta  harmonic     sigma   weight residual
   123.40  123.94   -0.54     0      2.50e+00 1.60e-01 4.62e-02
dihedral pdb=" N   ALA A  55 "
         pdb=" C   ALA A  55 "
         pdb=" CA  ALA A  55 "
         pdb=" CB  ALA A  55 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.90  122.37    0.53     0      2.50e+00 1.60e-01 4.45e-02
dihedral pdb=" C   LYS A  69 "
         pdb=" N   LYS A  69 "
         pdb=" CA  LYS A  69 "
         pdb=" CB  LYS A  69 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -122.07   -0.53     0      2.50e+00 1.60e-01 4.44e-02
dihedral pdb=" N   GLN A  31 "
         pdb=" C   GLN A  31 "
         pdb=" CA  GLN A  31 "
         pdb=" CB  GLN A  31 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  123.31   -0.51     0      2.50e+00 1.60e-01 4.24e-02
dihedral pdb=" C   VAL A  84 "
         pdb=" N   VAL A  84 "
         pdb=" CA  VAL A  84 "
         pdb=" CB  VAL A  84 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.00 -122.51    0.51     0      2.50e+00 1.60e-01 4.09e-02
dihedral pdb=" C   LEU A  83 "
         pdb=" N   LEU A  83 "
         pdb=" CA  LEU A  83 "
         pdb=" CB  LEU A  83 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -123.09    0.49     0      2.50e+00 1.60e-01 3.90e-02
dihedral pdb=" N   PHE A  73 "
         pdb=" C   PHE A  73 "
         pdb=" CA  PHE A  73 "
         pdb=" CB  PHE A  73 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  123.29   -0.49     0      2.50e+00 1.60e-01 3.86e-02
dihedral pdb=" C   PRO A   8 "
         pdb=" N   PRO A   8 "
         pdb=" CA  PRO A   8 "
         pdb=" CB  PRO A   8 "
    ideal   model   delta  harmonic     sigma   weight residual
  -120.70 -120.24   -0.46     0      2.50e+00 1.60e-01 3.42e-02
dihedral pdb=" N   ASP A  50 "
         pdb=" C   ASP A  50 "
         pdb=" CA  ASP A  50 "
         pdb=" CB  ASP A  50 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  123.23   -0.43     0      2.50e+00 1.60e-01 2.92e-02
dihedral pdb=" N   LEU A  65 "
         pdb=" C   LEU A  65 "
         pdb=" CA  LEU A  65 "
         pdb=" CB  LEU A  65 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  123.21   -0.41     0      2.50e+00 1.60e-01 2.75e-02
dihedral pdb=" N   PRO A  85 "
         pdb=" C   PRO A  85 "
         pdb=" CA  PRO A  85 "
         pdb=" CB  PRO A  85 "
    ideal   model   delta  harmonic     sigma   weight residual
   115.10  114.71    0.39     0      2.50e+00 1.60e-01 2.47e-02
dihedral pdb=" N   VAL A  84 "
         pdb=" C   VAL A  84 "
         pdb=" CA  VAL A  84 "
         pdb=" CB  VAL A  84 "
    ideal   model   delta  harmonic     sigma   weight residual
   123.40  123.79   -0.39     0      2.50e+00 1.60e-01 2.46e-02
dihedral pdb=" C   LYS A  46 "
         pdb=" N   LYS A  46 "
         pdb=" CA  LYS A  46 "
         pdb=" CB  LYS A  46 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -122.25   -0.35     0      2.50e+00 1.60e-01 1.96e-02
dihedral pdb=" N   PRO A  42 "
         pdb=" C   PRO A  42 "
         pdb=" CA  PRO A  42 "
         pdb=" CB  PRO A  42 "
    ideal   model   delta  harmonic     sigma   weight residual
   115.10  114.76    0.34     0      2.50e+00 1.60e-01 1.84e-02
dihedral pdb=" C   TYR A  34 "
         pdb=" N   TYR A  34 "
         pdb=" CA  TYR A  34 "
         pdb=" CB  TYR A  34 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -122.93    0.33     0      2.50e+00 1.60e-01 1.74e-02
dihedral pdb=" C   LYS A   3 "
         pdb=" N   LYS A   3 "
         pdb=" CA  LYS A   3 "
         pdb=" CB  LYS A   3 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -122.89    0.29     0      2.50e+00 1.60e-01 1.38e-02
dihedral pdb=" C   LEU A  28 "
         pdb=" N   LEU A  28 "
         pdb=" CA  LEU A  28 "
         pdb=" CB  LEU A  28 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -122.31   -0.29     0      2.50e+00 1.60e-01 1.36e-02
dihedral pdb=" C   ASP A  50 "
         pdb=" N   ASP A  50 "
         pdb=" CA  ASP A  50 "
         pdb=" CB  ASP A  50 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -122.31   -0.29     0      2.50e+00 1.60e-01 1.31e-02
dihedral pdb=" N   LEU A  49 "
         pdb=" C   LEU A  49 "
         pdb=" CA  LEU A  49 "
         pdb=" CB  LEU A  49 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  123.08   -0.28     0      2.50e+00 1.60e-01 1.22e-02
dihedral pdb=" C   ALA A  55 "
         pdb=" N   ALA A  55 "
         pdb=" CA  ALA A  55 "
         pdb=" CB  ALA A  55 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -122.32   -0.28     0      2.50e+00 1.60e-01 1.21e-02
dihedral pdb=" C   TYR A  41 "
         pdb=" N   TYR A  41 "
         pdb=" CA  TYR A  41 "
         pdb=" CB  TYR A  41 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -122.38   -0.22     0      2.50e+00 1.60e-01 7.76e-03
dihedral pdb=" N   THR A  15 "
         pdb=" C   THR A  15 "
         pdb=" CA  THR A  15 "
         pdb=" CB  THR A  15 "
    ideal   model   delta  harmonic     sigma   weight residual
   123.40  123.21    0.19     0      2.50e+00 1.60e-01 5.86e-03
dihedral pdb=" N   THR A  62 "
         pdb=" C   THR A  62 "
         pdb=" CA  THR A  62 "
         pdb=" CB  THR A  62 "
    ideal   model   delta  harmonic     sigma   weight residual
   123.40  123.22    0.18     0      2.50e+00 1.60e-01 5.34e-03
dihedral pdb=" N   VAL A  35 "
         pdb=" C   VAL A  35 "
         pdb=" CA  VAL A  35 "
         pdb=" CB  VAL A  35 "
    ideal   model   delta  harmonic     sigma   weight residual
   123.40  123.56   -0.16     0      2.50e+00 1.60e-01 3.93e-03
dihedral pdb=" C   VAL A   4 "
         pdb=" N   VAL A   4 "
         pdb=" CA  VAL A   4 "
         pdb=" CB  VAL A   4 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.00 -122.12    0.12     0      2.50e+00 1.60e-01 2.42e-03
dihedral pdb=" N   TYR A  41 "
         pdb=" C   TYR A  41 "
         pdb=" CA  TYR A  41 "
         pdb=" CB  TYR A  41 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  122.70    0.10     0      2.50e+00 1.60e-01 1.52e-03
dihedral pdb=" C   SER A  75 "
         pdb=" N   SER A  75 "
         pdb=" CA  SER A  75 "
         pdb=" CB  SER A  75 "
    ideal   model   delta  harmonic     sigma   weight residual
  -122.60 -122.51   -0.09     0      2.50e+00 1.60e-01 1.34e-03
dihedral pdb=" N   LYS A   3 "
         pdb=" C   LYS A   3 "
         pdb=" CA  LYS A   3 "
         pdb=" CB  LYS A   3 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  122.74    0.06     0      2.50e+00 1.60e-01 5.34e-04
dihedral pdb=" N   SER A  75 "
         pdb=" C   SER A  75 "
         pdb=" CA  SER A  75 "
         pdb=" CB  SER A  75 "
    ideal   model   delta  harmonic     sigma   weight residual
   122.80  122.77    0.03     0      2.50e+00 1.60e-01 1.94e-04

Chirality | covalent geometry | restraints: 96
Sorted by residual:
chirality pdb=" CA  TYR A  26 "
          pdb=" N   TYR A  26 "
          pdb=" C   TYR A  26 "
          pdb=" CB  TYR A  26 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.22    0.29 2.00e-01 2.50e+01 2.07e+00
chirality pdb=" CB  ILE A   2 "
          pdb=" CA  ILE A   2 "
          pdb=" CG1 ILE A   2 "
          pdb=" CG2 ILE A   2 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.64    2.89   -0.24 2.00e-01 2.50e+01 1.44e+00
chirality pdb=" CA  GLN A  53 "
          pdb=" N   GLN A  53 "
          pdb=" C   GLN A  53 "
          pdb=" CB  GLN A  53 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.30    0.21 2.00e-01 2.50e+01 1.13e+00
chirality pdb=" CA  LEU A  32 "
          pdb=" N   LEU A  32 "
          pdb=" C   LEU A  32 "
          pdb=" CB  LEU A  32 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.31    0.20 2.00e-01 2.50e+01 1.04e+00
chirality pdb=" CA  ASP A  36 "
          pdb=" N   ASP A  36 "
          pdb=" C   ASP A  36 "
          pdb=" CB  ASP A  36 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.33    0.18 2.00e-01 2.50e+01 7.95e-01
chirality pdb=" CA  MSE A  77 "
          pdb=" N   MSE A  77 "
          pdb=" C   MSE A  77 "
          pdb=" CB  MSE A  77 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.50    2.67   -0.17 2.00e-01 2.50e+01 7.32e-01
chirality pdb=" CA  LEU A  60 "
          pdb=" N   LEU A  60 "
          pdb=" C   LEU A  60 "
          pdb=" CB  LEU A  60 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.34    0.17 2.00e-01 2.50e+01 7.13e-01
chirality pdb=" CG  LEU A  32 "
          pdb=" CB  LEU A  32 "
          pdb=" CD1 LEU A  32 "
          pdb=" CD2 LEU A  32 "
  both_signs  ideal   model   delta    sigma   weight residual
    False     -2.59   -2.42   -0.17 2.00e-01 2.50e+01 7.13e-01
chirality pdb=" CA  PHE A  68 "
          pdb=" N   PHE A  68 "
          pdb=" C   PHE A  68 "
          pdb=" CB  PHE A  68 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.35    0.16 2.00e-01 2.50e+01 6.80e-01
chirality pdb=" CA  PRO A  58 "
          pdb=" N   PRO A  58 "
          pdb=" C   PRO A  58 "
          pdb=" CB  PRO A  58 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.72    2.55    0.16 2.00e-01 2.50e+01 6.78e-01
chirality pdb=" CA  GLU A  51 "
          pdb=" N   GLU A  51 "
          pdb=" C   GLU A  51 "
          pdb=" CB  GLU A  51 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.35    0.16 2.00e-01 2.50e+01 6.68e-01
chirality pdb=" CA  GLU A  30 "
          pdb=" N   GLU A  30 "
          pdb=" C   GLU A  30 "
          pdb=" CB  GLU A  30 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.35    0.16 2.00e-01 2.50e+01 6.66e-01
chirality pdb=" CA  LEU A  37 "
          pdb=" N   LEU A  37 "
          pdb=" C   LEU A  37 "
          pdb=" CB  LEU A  37 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.36    0.15 2.00e-01 2.50e+01 5.75e-01
chirality pdb=" CA  LEU A  76 "
          pdb=" N   LEU A  76 "
          pdb=" C   LEU A  76 "
          pdb=" CB  LEU A  76 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.36    0.15 2.00e-01 2.50e+01 5.67e-01
chirality pdb=" CA  VAL A   4 "
          pdb=" N   VAL A   4 "
          pdb=" C   VAL A   4 "
          pdb=" CB  VAL A   4 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.44    2.59   -0.14 2.00e-01 2.50e+01 5.23e-01
chirality pdb=" CA  PHE A  13 "
          pdb=" N   PHE A  13 "
          pdb=" C   PHE A  13 "
          pdb=" CB  PHE A  13 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.37    0.14 2.00e-01 2.50e+01 4.65e-01
chirality pdb=" CA  LYS A  46 "
          pdb=" N   LYS A  46 "
          pdb=" C   LYS A  46 "
          pdb=" CB  LYS A  46 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.37    0.14 2.00e-01 2.50e+01 4.62e-01
chirality pdb=" CA  LEU A  49 "
          pdb=" N   LEU A  49 "
          pdb=" C   LEU A  49 "
          pdb=" CB  LEU A  49 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.38    0.13 2.00e-01 2.50e+01 4.34e-01
chirality pdb=" CA  LEU A  65 "
          pdb=" N   LEU A  65 "
          pdb=" C   LEU A  65 "
          pdb=" CB  LEU A  65 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.38    0.13 2.00e-01 2.50e+01 4.33e-01
chirality pdb=" CA  ALA A  11 "
          pdb=" N   ALA A  11 "
          pdb=" C   ALA A  11 "
          pdb=" CB  ALA A  11 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.48    2.36    0.13 2.00e-01 2.50e+01 4.13e-01
chirality pdb=" CG  LEU A  44 "
          pdb=" CB  LEU A  44 "
          pdb=" CD1 LEU A  44 "
          pdb=" CD2 LEU A  44 "
  both_signs  ideal   model   delta    sigma   weight residual
    False     -2.59   -2.71    0.12 2.00e-01 2.50e+01 3.90e-01
chirality pdb=" CA  VAL A  63 "
          pdb=" N   VAL A  63 "
          pdb=" C   VAL A  63 "
          pdb=" CB  VAL A  63 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.44    2.32    0.12 2.00e-01 2.50e+01 3.89e-01
chirality pdb=" CA  ALA A  57 "
          pdb=" N   ALA A  57 "
          pdb=" C   ALA A  57 "
          pdb=" CB  ALA A  57 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.48    2.37    0.12 2.00e-01 2.50e+01 3.43e-01
chirality pdb=" CA  ILE A   6 "
          pdb=" N   ILE A   6 "
          pdb=" C   ILE A   6 "
          pdb=" CB  ILE A   6 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.43    2.55   -0.11 2.00e-01 2.50e+01 3.30e-01
chirality pdb=" CA  LYS A   7 "
          pdb=" N   LYS A   7 "
          pdb=" C   LYS A   7 "
          pdb=" CB  LYS A   7 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.41    0.10 2.00e-01 2.50e+01 2.63e-01
chirality pdb=" CA  ILE A  78 "
          pdb=" N   ILE A  78 "
          pdb=" C   ILE A  78 "
          pdb=" CB  ILE A  78 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.43    2.54   -0.10 2.00e-01 2.50e+01 2.60e-01
chirality pdb=" CA  VAL A  35 "
          pdb=" N   VAL A  35 "
          pdb=" C   VAL A  35 "
          pdb=" CB  VAL A  35 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.44    2.54   -0.10 2.00e-01 2.50e+01 2.53e-01
chirality pdb=" CA  HIS A  64 "
          pdb=" N   HIS A  64 "
          pdb=" C   HIS A  64 "
          pdb=" CB  HIS A  64 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.42    0.09 2.00e-01 2.50e+01 2.20e-01
chirality pdb=" CB  VAL A  84 "
          pdb=" CA  VAL A  84 "
          pdb=" CG1 VAL A  84 "
          pdb=" CG2 VAL A  84 "
  both_signs  ideal   model   delta    sigma   weight residual
    False     -2.63   -2.54   -0.09 2.00e-01 2.50e+01 2.11e-01
chirality pdb=" CA  ASN A  39 "
          pdb=" N   ASN A  39 "
          pdb=" C   ASN A  39 "
          pdb=" CB  ASN A  39 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.42    0.09 2.00e-01 2.50e+01 2.07e-01
chirality pdb=" CA  LEU A  81 "
          pdb=" N   LEU A  81 "
          pdb=" C   LEU A  81 "
          pdb=" CB  LEU A  81 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.42    0.09 2.00e-01 2.50e+01 1.88e-01
chirality pdb=" CA  PRO A   8 "
          pdb=" N   PRO A   8 "
          pdb=" C   PRO A   8 "
          pdb=" CB  PRO A   8 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.72    2.63    0.09 2.00e-01 2.50e+01 1.84e-01
chirality pdb=" CA  THR A  15 "
          pdb=" N   THR A  15 "
          pdb=" C   THR A  15 "
          pdb=" CB  THR A  15 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.53    2.44    0.09 2.00e-01 2.50e+01 1.83e-01
chirality pdb=" CA  GLU A   5 "
          pdb=" N   GLU A   5 "
          pdb=" C   GLU A   5 "
          pdb=" CB  GLU A   5 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.43    0.09 2.00e-01 2.50e+01 1.82e-01
chirality pdb=" CA  ASP A  50 "
          pdb=" N   ASP A  50 "
          pdb=" C   ASP A  50 "
          pdb=" CB  ASP A  50 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.43    0.08 2.00e-01 2.50e+01 1.68e-01
chirality pdb=" CA  TYR A  34 "
          pdb=" N   TYR A  34 "
          pdb=" C   TYR A  34 "
          pdb=" CB  TYR A  34 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.43    0.08 2.00e-01 2.50e+01 1.66e-01
chirality pdb=" CA  SER A  67 "
          pdb=" N   SER A  67 "
          pdb=" C   SER A  67 "
          pdb=" CB  SER A  67 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.43    0.08 2.00e-01 2.50e+01 1.62e-01
chirality pdb=" CB  ILE A  47 "
          pdb=" CA  ILE A  47 "
          pdb=" CG1 ILE A  47 "
          pdb=" CG2 ILE A  47 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.64    2.57    0.07 2.00e-01 2.50e+01 1.35e-01
chirality pdb=" CG  LEU A  65 "
          pdb=" CB  LEU A  65 "
          pdb=" CD1 LEU A  65 "
          pdb=" CD2 LEU A  65 "
  both_signs  ideal   model   delta    sigma   weight residual
    False     -2.59   -2.66    0.07 2.00e-01 2.50e+01 1.27e-01
chirality pdb=" CA  LEU A  83 "
          pdb=" N   LEU A  83 "
          pdb=" C   LEU A  83 "
          pdb=" CB  LEU A  83 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.44    0.07 2.00e-01 2.50e+01 1.08e-01
chirality pdb=" CA  GLN A  31 "
          pdb=" N   GLN A  31 "
          pdb=" C   GLN A  31 "
          pdb=" CB  GLN A  31 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.45    0.06 2.00e-01 2.50e+01 1.01e-01
chirality pdb=" CA  GLN A  12 "
          pdb=" N   GLN A  12 "
          pdb=" C   GLN A  12 "
          pdb=" CB  GLN A  12 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.45    0.06 2.00e-01 2.50e+01 9.88e-02
chirality pdb=" CA  ARG A  16 "
          pdb=" N   ARG A  16 "
          pdb=" C   ARG A  16 "
          pdb=" CB  ARG A  16 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.57   -0.06 2.00e-01 2.50e+01 8.99e-02
chirality pdb=" CA  VAL A  84 "
          pdb=" N   VAL A  84 "
          pdb=" C   VAL A  84 "
          pdb=" CB  VAL A  84 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.44    2.50   -0.06 2.00e-01 2.50e+01 8.95e-02
chirality pdb=" CA  LEU A  28 "
          pdb=" N   LEU A  28 "
          pdb=" C   LEU A  28 "
          pdb=" CB  LEU A  28 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.45    0.06 2.00e-01 2.50e+01 8.82e-02
chirality pdb=" CA  ARG A  82 "
          pdb=" N   ARG A  82 "
          pdb=" C   ARG A  82 "
          pdb=" CB  ARG A  82 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.45    0.06 2.00e-01 2.50e+01 7.76e-02
chirality pdb=" CA  GLN A  72 "
          pdb=" N   GLN A  72 "
          pdb=" C   GLN A  72 "
          pdb=" CB  GLN A  72 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.46    0.05 2.00e-01 2.50e+01 7.29e-02
chirality pdb=" CA  SER A  66 "
          pdb=" N   SER A  66 "
          pdb=" C   SER A  66 "
          pdb=" CB  SER A  66 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.46    0.05 2.00e-01 2.50e+01 7.27e-02
chirality pdb=" CA  ALA A  55 "
          pdb=" N   ALA A  55 "
          pdb=" C   ALA A  55 "
          pdb=" CB  ALA A  55 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.48    2.54   -0.05 2.00e-01 2.50e+01 6.37e-02
chirality pdb=" CB  VAL A  35 "
          pdb=" CA  VAL A  35 "
          pdb=" CG1 VAL A  35 "
          pdb=" CG2 VAL A  35 "
  both_signs  ideal   model   delta    sigma   weight residual
    False     -2.63   -2.68    0.05 2.00e-01 2.50e+01 5.69e-02
chirality pdb=" CB  VAL A  45 "
          pdb=" CA  VAL A  45 "
          pdb=" CG1 VAL A  45 "
          pdb=" CG2 VAL A  45 "
  both_signs  ideal   model   delta    sigma   weight residual
    False     -2.63   -2.58   -0.05 2.00e-01 2.50e+01 5.52e-02
chirality pdb=" CA  VAL A  70 "
          pdb=" N   VAL A  70 "
          pdb=" C   VAL A  70 "
          pdb=" CB  VAL A  70 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.44    2.49   -0.05 2.00e-01 2.50e+01 5.50e-02
chirality pdb=" CA  CYS A  33 "
          pdb=" N   CYS A  33 "
          pdb=" C   CYS A  33 "
          pdb=" CB  CYS A  33 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.56   -0.05 2.00e-01 2.50e+01 5.47e-02
chirality pdb=" CA  ILE A  47 "
          pdb=" N   ILE A  47 "
          pdb=" C   ILE A  47 "
          pdb=" CB  ILE A  47 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.43    2.48   -0.05 2.00e-01 2.50e+01 5.11e-02
chirality pdb=" CB  THR A  48 "
          pdb=" CA  THR A  48 "
          pdb=" OG1 THR A  48 "
          pdb=" CG2 THR A  48 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.55    2.51    0.04 2.00e-01 2.50e+01 4.70e-02
chirality pdb=" CA  SER A  17 "
          pdb=" N   SER A  17 "
          pdb=" C   SER A  17 "
          pdb=" CB  SER A  17 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.47    0.04 2.00e-01 2.50e+01 4.51e-02
chirality pdb=" CA  GLU A  40 "
          pdb=" N   GLU A  40 "
          pdb=" C   GLU A  40 "
          pdb=" CB  GLU A  40 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.55   -0.04 2.00e-01 2.50e+01 4.19e-02
chirality pdb=" CB  VAL A   4 "
          pdb=" CA  VAL A   4 "
          pdb=" CG1 VAL A   4 "
          pdb=" CG2 VAL A   4 "
  both_signs  ideal   model   delta    sigma   weight residual
    False     -2.63   -2.67    0.04 2.00e-01 2.50e+01 4.05e-02
chirality pdb=" CB  VAL A  63 "
          pdb=" CA  VAL A  63 "
          pdb=" CG1 VAL A  63 "
          pdb=" CG2 VAL A  63 "
  both_signs  ideal   model   delta    sigma   weight residual
    False     -2.63   -2.67    0.04 2.00e-01 2.50e+01 3.93e-02
chirality pdb=" CB  VAL A  70 "
          pdb=" CA  VAL A  70 "
          pdb=" CG1 VAL A  70 "
          pdb=" CG2 VAL A  70 "
  both_signs  ideal   model   delta    sigma   weight residual
    False     -2.63   -2.59   -0.04 2.00e-01 2.50e+01 3.45e-02
chirality pdb=" CG  LEU A  37 "
          pdb=" CB  LEU A  37 "
          pdb=" CD1 LEU A  37 "
          pdb=" CD2 LEU A  37 "
  both_signs  ideal   model   delta    sigma   weight residual
    False     -2.59   -2.63    0.04 2.00e-01 2.50e+01 3.41e-02
chirality pdb=" CB  ILE A   6 "
          pdb=" CA  ILE A   6 "
          pdb=" CG1 ILE A   6 "
          pdb=" CG2 ILE A   6 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.64    2.61    0.04 2.00e-01 2.50e+01 3.31e-02
chirality pdb=" CA  LYS A  69 "
          pdb=" N   LYS A  69 "
          pdb=" C   LYS A  69 "
          pdb=" CB  LYS A  69 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.54   -0.03 2.00e-01 2.50e+01 2.92e-02
chirality pdb=" CB  THR A  62 "
          pdb=" CA  THR A  62 "
          pdb=" OG1 THR A  62 "
          pdb=" CG2 THR A  62 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.55    2.52    0.03 2.00e-01 2.50e+01 2.56e-02
chirality pdb=" CG  LEU A  83 "
          pdb=" CB  LEU A  83 "
          pdb=" CD1 LEU A  83 "
          pdb=" CD2 LEU A  83 "
  both_signs  ideal   model   delta    sigma   weight residual
    False     -2.59   -2.56   -0.03 2.00e-01 2.50e+01 2.15e-02
chirality pdb=" CA  GLN A  10 "
          pdb=" N   GLN A  10 "
          pdb=" C   GLN A  10 "
          pdb=" CB  GLN A  10 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.48    0.03 2.00e-01 2.50e+01 2.09e-02
chirality pdb=" CA  SER A   9 "
          pdb=" N   SER A   9 "
          pdb=" C   SER A   9 "
          pdb=" CB  SER A   9 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.54   -0.03 2.00e-01 2.50e+01 1.88e-02
chirality pdb=" CA  TYR A  41 "
          pdb=" N   TYR A  41 "
          pdb=" C   TYR A  41 "
          pdb=" CB  TYR A  41 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.53   -0.02 2.00e-01 2.50e+01 1.41e-02
chirality pdb=" CG  LEU A  28 "
          pdb=" CB  LEU A  28 "
          pdb=" CD1 LEU A  28 "
          pdb=" CD2 LEU A  28 "
  both_signs  ideal   model   delta    sigma   weight residual
    False     -2.59   -2.57   -0.02 2.00e-01 2.50e+01 1.40e-02
chirality pdb=" CA  ASN A  29 "
          pdb=" N   ASN A  29 "
          pdb=" C   ASN A  29 "
          pdb=" CB  ASN A  29 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.49    0.02 2.00e-01 2.50e+01 1.26e-02
chirality pdb=" CA  ILE A   2 "
          pdb=" N   ILE A   2 "
          pdb=" C   ILE A   2 "
          pdb=" CB  ILE A   2 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.43    2.45   -0.02 2.00e-01 2.50e+01 1.12e-02
chirality pdb=" CB  THR A  15 "
          pdb=" CA  THR A  15 "
          pdb=" OG1 THR A  15 "
          pdb=" CG2 THR A  15 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.55    2.57   -0.02 2.00e-01 2.50e+01 9.26e-03
chirality pdb=" CA  ASP A  79 "
          pdb=" N   ASP A  79 "
          pdb=" C   ASP A  79 "
          pdb=" CB  ASP A  79 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.53   -0.02 2.00e-01 2.50e+01 7.45e-03
chirality pdb=" CA  VAL A  45 "
          pdb=" N   VAL A  45 "
          pdb=" C   VAL A  45 "
          pdb=" CB  VAL A  45 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.44    2.43    0.01 2.00e-01 2.50e+01 5.35e-03
chirality pdb=" CA  THR A  62 "
          pdb=" N   THR A  62 "
          pdb=" C   THR A  62 "
          pdb=" CB  THR A  62 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.53    2.51    0.01 2.00e-01 2.50e+01 4.79e-03
chirality pdb=" CA  PHE A  73 "
          pdb=" N   PHE A  73 "
          pdb=" C   PHE A  73 "
          pdb=" CB  PHE A  73 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.50    0.01 2.00e-01 2.50e+01 4.53e-03
chirality pdb=" CA  TYR A  61 "
          pdb=" N   TYR A  61 "
          pdb=" C   TYR A  61 "
          pdb=" CB  TYR A  61 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.50    0.01 2.00e-01 2.50e+01 3.60e-03
chirality pdb=" CA  PRO A  54 "
          pdb=" N   PRO A  54 "
          pdb=" C   PRO A  54 "
          pdb=" CB  PRO A  54 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.72    2.71    0.01 2.00e-01 2.50e+01 3.30e-03
chirality pdb=" CB  THR A  14 "
          pdb=" CA  THR A  14 "
          pdb=" OG1 THR A  14 "
          pdb=" CG2 THR A  14 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.55    2.54    0.01 2.00e-01 2.50e+01 2.98e-03
chirality pdb=" CB  ILE A  78 "
          pdb=" CA  ILE A  78 "
          pdb=" CG1 ILE A  78 "
          pdb=" CG2 ILE A  78 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.64    2.63    0.01 2.00e-01 2.50e+01 2.58e-03
chirality pdb=" CG  LEU A  49 "
          pdb=" CB  LEU A  49 "
          pdb=" CD1 LEU A  49 "
          pdb=" CD2 LEU A  49 "
  both_signs  ideal   model   delta    sigma   weight residual
    False     -2.59   -2.58   -0.01 2.00e-01 2.50e+01 2.51e-03
chirality pdb=" CA  THR A  48 "
          pdb=" N   THR A  48 "
          pdb=" C   THR A  48 "
          pdb=" CB  THR A  48 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.53    2.53   -0.01 2.00e-01 2.50e+01 1.53e-03
chirality pdb=" CA  VAL A  43 "
          pdb=" N   VAL A  43 "
          pdb=" C   VAL A  43 "
          pdb=" CB  VAL A  43 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.44    2.43    0.01 2.00e-01 2.50e+01 1.49e-03
chirality pdb=" CG  LEU A  60 "
          pdb=" CB  LEU A  60 "
          pdb=" CD1 LEU A  60 "
          pdb=" CD2 LEU A  60 "
  both_signs  ideal   model   delta    sigma   weight residual
    False     -2.59   -2.60    0.01 2.00e-01 2.50e+01 1.36e-03
chirality pdb=" CA  SER A  75 "
          pdb=" N   SER A  75 "
          pdb=" C   SER A  75 "
          pdb=" CB  SER A  75 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.50    0.01 2.00e-01 2.50e+01 1.32e-03
chirality pdb=" CB  VAL A  43 "
          pdb=" CA  VAL A  43 "
          pdb=" CG1 VAL A  43 "
          pdb=" CG2 VAL A  43 "
  both_signs  ideal   model   delta    sigma   weight residual
    False     -2.63   -2.62   -0.00 2.00e-01 2.50e+01 4.90e-04
chirality pdb=" CA  TYR A  56 "
          pdb=" N   TYR A  56 "
          pdb=" C   TYR A  56 "
          pdb=" CB  TYR A  56 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.51   -0.00 2.00e-01 2.50e+01 4.37e-04
chirality pdb=" CG  LEU A  76 "
          pdb=" CB  LEU A  76 "
          pdb=" CD1 LEU A  76 "
          pdb=" CD2 LEU A  76 "
  both_signs  ideal   model   delta    sigma   weight residual
    False     -2.59   -2.59    0.00 2.00e-01 2.50e+01 3.95e-04
chirality pdb=" CA  LEU A  44 "
          pdb=" N   LEU A  44 "
          pdb=" C   LEU A  44 "
          pdb=" CB  LEU A  44 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.51    0.00 2.00e-01 2.50e+01 3.90e-04
chirality pdb=" CA  SER A  27 "
          pdb=" N   SER A  27 "
          pdb=" C   SER A  27 "
          pdb=" CB  SER A  27 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.51    0.00 2.00e-01 2.50e+01 3.42e-04
chirality pdb=" CA  THR A  14 "
          pdb=" N   THR A  14 "
          pdb=" C   THR A  14 "
          pdb=" CB  THR A  14 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.53    2.52    0.00 2.00e-01 2.50e+01 3.34e-04
chirality pdb=" CA  PRO A  85 "
          pdb=" N   PRO A  85 "
          pdb=" C   PRO A  85 "
          pdb=" CB  PRO A  85 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.72    2.72   -0.00 2.00e-01 2.50e+01 2.99e-04
chirality pdb=" CA  PRO A  42 "
          pdb=" N   PRO A  42 "
          pdb=" C   PRO A  42 "
          pdb=" CB  PRO A  42 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.72    2.72    0.00 2.00e-01 2.50e+01 2.54e-05
chirality pdb=" CA  ARG A  80 "
          pdb=" N   ARG A  80 "
          pdb=" C   ARG A  80 "
          pdb=" CB  ARG A  80 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.51    0.00 2.00e-01 2.50e+01 1.37e-05
chirality pdb=" CG  LEU A  81 "
          pdb=" CB  LEU A  81 "
          pdb=" CD1 LEU A  81 "
          pdb=" CD2 LEU A  81 "
  both_signs  ideal   model   delta    sigma   weight residual
    False     -2.59   -2.59    0.00 2.00e-01 2.50e+01 1.29e-05
chirality pdb=" CA  LYS A   3 "
          pdb=" N   LYS A   3 "
          pdb=" C   LYS A   3 "
          pdb=" CB  LYS A   3 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.51    0.00 2.00e-01 2.50e+01 9.61e-06

Planarity | covalent geometry | restraints: 105
Sorted by residual:
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  ARG A  16 "   -0.008 2.00e-02 2.50e+03   1.57e-02 2.45e+00
      pdb=" C   ARG A  16 "    0.027 2.00e-02 2.50e+03
      pdb=" O   ARG A  16 "   -0.010 2.00e-02 2.50e+03
      pdb=" N   SER A  17 "   -0.009 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  VAL A  35 "   -0.006 2.00e-02 2.50e+03   1.26e-02 1.58e+00
      pdb=" C   VAL A  35 "    0.022 2.00e-02 2.50e+03
      pdb=" O   VAL A  35 "   -0.008 2.00e-02 2.50e+03
      pdb=" N   ASP A  36 "   -0.007 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  LYS A   7 "    0.006 2.00e-02 2.50e+03   1.21e-02 1.46e+00
      pdb=" C   LYS A   7 "   -0.021 2.00e-02 2.50e+03
      pdb=" O   LYS A   7 "    0.008 2.00e-02 2.50e+03
      pdb=" N   PRO A   8 "    0.007 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  LEU A  44 "    0.006 2.00e-02 2.50e+03   1.20e-02 1.45e+00
      pdb=" C   LEU A  44 "   -0.021 2.00e-02 2.50e+03
      pdb=" O   LEU A  44 "    0.008 2.00e-02 2.50e+03
      pdb=" N   VAL A  45 "    0.007 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" C   LYS A   7 "    0.019 5.00e-02 4.00e+02   2.94e-02 1.39e+00
      pdb=" N   PRO A   8 "   -0.051 5.00e-02 4.00e+02
      pdb=" CA  PRO A   8 "    0.015 5.00e-02 4.00e+02
      pdb=" CD  PRO A   8 "    0.016 5.00e-02 4.00e+02
                               delta    sigma   weight rms_deltas residual
plane pdb=" CB  PHE A  68 "    0.008 2.00e-02 2.50e+03   8.90e-03 1.39e+00
      pdb=" CG  PHE A  68 "   -0.021 2.00e-02 2.50e+03
      pdb=" CD1 PHE A  68 "    0.007 2.00e-02 2.50e+03
      pdb=" CD2 PHE A  68 "    0.003 2.00e-02 2.50e+03
      pdb=" CE1 PHE A  68 "   -0.001 2.00e-02 2.50e+03
      pdb=" CE2 PHE A  68 "    0.003 2.00e-02 2.50e+03
      pdb=" CZ  PHE A  68 "    0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  GLN A  10 "   -0.005 2.00e-02 2.50e+03   1.10e-02 1.22e+00
      pdb=" C   GLN A  10 "    0.019 2.00e-02 2.50e+03
      pdb=" O   GLN A  10 "   -0.007 2.00e-02 2.50e+03
      pdb=" N   ALA A  11 "   -0.006 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CB  TYR A  26 "    0.007 2.00e-02 2.50e+03   7.22e-03 1.04e+00
      pdb=" CG  TYR A  26 "   -0.015 2.00e-02 2.50e+03
      pdb=" CD1 TYR A  26 "    0.009 2.00e-02 2.50e+03
      pdb=" CD2 TYR A  26 "   -0.001 2.00e-02 2.50e+03
      pdb=" CE1 TYR A  26 "   -0.006 2.00e-02 2.50e+03
      pdb=" CE2 TYR A  26 "    0.003 2.00e-02 2.50e+03
      pdb=" CZ  TYR A  26 "   -0.000 2.00e-02 2.50e+03
      pdb=" OH  TYR A  26 "    0.003 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" C   TYR A  41 "    0.017 5.00e-02 4.00e+02   2.54e-02 1.04e+00
      pdb=" N   PRO A  42 "   -0.044 5.00e-02 4.00e+02
      pdb=" CA  PRO A  42 "    0.013 5.00e-02 4.00e+02
      pdb=" CD  PRO A  42 "    0.014 5.00e-02 4.00e+02
                               delta    sigma   weight rms_deltas residual
plane pdb=" CB  TYR A  56 "    0.007 2.00e-02 2.50e+03   6.85e-03 9.37e-01
      pdb=" CG  TYR A  56 "   -0.016 2.00e-02 2.50e+03
      pdb=" CD1 TYR A  56 "    0.005 2.00e-02 2.50e+03
      pdb=" CD2 TYR A  56 "    0.003 2.00e-02 2.50e+03
      pdb=" CE1 TYR A  56 "   -0.000 2.00e-02 2.50e+03
      pdb=" CE2 TYR A  56 "    0.001 2.00e-02 2.50e+03
      pdb=" CZ  TYR A  56 "   -0.003 2.00e-02 2.50e+03
      pdb=" OH  TYR A  56 "    0.003 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  GLN A  53 "   -0.005 2.00e-02 2.50e+03   9.67e-03 9.35e-01
      pdb=" C   GLN A  53 "    0.017 2.00e-02 2.50e+03
      pdb=" O   GLN A  53 "   -0.006 2.00e-02 2.50e+03
      pdb=" N   PRO A  54 "   -0.006 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  VAL A   4 "    0.005 2.00e-02 2.50e+03   9.65e-03 9.30e-01
      pdb=" C   VAL A   4 "   -0.017 2.00e-02 2.50e+03
      pdb=" O   VAL A   4 "    0.006 2.00e-02 2.50e+03
      pdb=" N   GLU A   5 "    0.006 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CB  TYR A  61 "   -0.008 2.00e-02 2.50e+03   6.78e-03 9.18e-01
      pdb=" CG  TYR A  61 "    0.016 2.00e-02 2.50e+03
      pdb=" CD1 TYR A  61 "   -0.005 2.00e-02 2.50e+03
      pdb=" CD2 TYR A  61 "   -0.002 2.00e-02 2.50e+03
      pdb=" CE1 TYR A  61 "    0.003 2.00e-02 2.50e+03
      pdb=" CE2 TYR A  61 "   -0.001 2.00e-02 2.50e+03
      pdb=" CZ  TYR A  61 "   -0.001 2.00e-02 2.50e+03
      pdb=" OH  TYR A  61 "   -0.002 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  GLU A  51 "    0.005 2.00e-02 2.50e+03   9.23e-03 8.53e-01
      pdb=" C   GLU A  51 "   -0.016 2.00e-02 2.50e+03
      pdb=" O   GLU A  51 "    0.006 2.00e-02 2.50e+03
      pdb=" N   GLY A  52 "    0.005 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  THR A  15 "    0.004 2.00e-02 2.50e+03   8.75e-03 7.66e-01
      pdb=" C   THR A  15 "   -0.015 2.00e-02 2.50e+03
      pdb=" O   THR A  15 "    0.006 2.00e-02 2.50e+03
      pdb=" N   ARG A  16 "    0.005 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  SER A  67 "   -0.004 2.00e-02 2.50e+03   8.58e-03 7.36e-01
      pdb=" C   SER A  67 "    0.015 2.00e-02 2.50e+03
      pdb=" O   SER A  67 "   -0.006 2.00e-02 2.50e+03
      pdb=" N   PHE A  68 "   -0.005 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  TYR A  41 "    0.004 2.00e-02 2.50e+03   7.79e-03 6.07e-01
      pdb=" C   TYR A  41 "   -0.013 2.00e-02 2.50e+03
      pdb=" O   TYR A  41 "    0.005 2.00e-02 2.50e+03
      pdb=" N   PRO A  42 "    0.005 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" C   ALA A  57 "   -0.012 5.00e-02 4.00e+02   1.84e-02 5.44e-01
      pdb=" N   PRO A  58 "    0.032 5.00e-02 4.00e+02
      pdb=" CA  PRO A  58 "   -0.009 5.00e-02 4.00e+02
      pdb=" CD  PRO A  58 "   -0.010 5.00e-02 4.00e+02
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  PHE A  13 "    0.004 2.00e-02 2.50e+03   7.11e-03 5.06e-01
      pdb=" C   PHE A  13 "   -0.012 2.00e-02 2.50e+03
      pdb=" O   PHE A  13 "    0.005 2.00e-02 2.50e+03
      pdb=" N   THR A  14 "    0.004 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  MSE A  77 "   -0.003 2.00e-02 2.50e+03   6.37e-03 4.06e-01
      pdb=" C   MSE A  77 "    0.011 2.00e-02 2.50e+03
      pdb=" O   MSE A  77 "   -0.004 2.00e-02 2.50e+03
      pdb=" N   ILE A  78 "   -0.004 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  SER A  27 "   -0.003 2.00e-02 2.50e+03   6.12e-03 3.74e-01
      pdb=" C   SER A  27 "    0.011 2.00e-02 2.50e+03
      pdb=" O   SER A  27 "   -0.004 2.00e-02 2.50e+03
      pdb=" N   LEU A  28 "   -0.004 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  GLU A   5 "    0.003 2.00e-02 2.50e+03   5.99e-03 3.59e-01
      pdb=" C   GLU A   5 "   -0.010 2.00e-02 2.50e+03
      pdb=" O   GLU A   5 "    0.004 2.00e-02 2.50e+03
      pdb=" N   ILE A   6 "    0.003 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CB  PHE A  13 "   -0.003 2.00e-02 2.50e+03   4.32e-03 3.27e-01
      pdb=" CG  PHE A  13 "   -0.002 2.00e-02 2.50e+03
      pdb=" CD1 PHE A  13 "    0.009 2.00e-02 2.50e+03
      pdb=" CD2 PHE A  13 "    0.003 2.00e-02 2.50e+03
      pdb=" CE1 PHE A  13 "   -0.006 2.00e-02 2.50e+03
      pdb=" CE2 PHE A  13 "   -0.000 2.00e-02 2.50e+03
      pdb=" CZ  PHE A  13 "   -0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CB  HIS A  64 "   -0.005 2.00e-02 2.50e+03   4.54e-03 3.09e-01
      pdb=" CG  HIS A  64 "    0.010 2.00e-02 2.50e+03
      pdb=" ND1 HIS A  64 "   -0.001 2.00e-02 2.50e+03
      pdb=" CD2 HIS A  64 "   -0.001 2.00e-02 2.50e+03
      pdb=" CE1 HIS A  64 "   -0.001 2.00e-02 2.50e+03
      pdb=" NE2 HIS A  64 "   -0.002 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  CYS A  33 "   -0.003 2.00e-02 2.50e+03   5.46e-03 2.98e-01
      pdb=" C   CYS A  33 "    0.009 2.00e-02 2.50e+03
      pdb=" O   CYS A  33 "   -0.004 2.00e-02 2.50e+03
      pdb=" N   TYR A  34 "   -0.003 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CB  TYR A  34 "   -0.005 2.00e-02 2.50e+03   3.85e-03 2.96e-01
      pdb=" CG  TYR A  34 "    0.008 2.00e-02 2.50e+03
      pdb=" CD1 TYR A  34 "    0.000 2.00e-02 2.50e+03
      pdb=" CD2 TYR A  34 "   -0.004 2.00e-02 2.50e+03
      pdb=" CE1 TYR A  34 "   -0.001 2.00e-02 2.50e+03
      pdb=" CE2 TYR A  34 "    0.003 2.00e-02 2.50e+03
      pdb=" CZ  TYR A  34 "    0.001 2.00e-02 2.50e+03
      pdb=" OH  TYR A  34 "   -0.003 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CB  PHE A  73 "    0.004 2.00e-02 2.50e+03   4.03e-03 2.84e-01
      pdb=" CG  PHE A  73 "   -0.009 2.00e-02 2.50e+03
      pdb=" CD1 PHE A  73 "    0.001 2.00e-02 2.50e+03
      pdb=" CD2 PHE A  73 "    0.003 2.00e-02 2.50e+03
      pdb=" CE1 PHE A  73 "    0.002 2.00e-02 2.50e+03
      pdb=" CE2 PHE A  73 "    0.000 2.00e-02 2.50e+03
      pdb=" CZ  PHE A  73 "   -0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  ASP A  50 "    0.003 2.00e-02 2.50e+03   5.20e-03 2.70e-01
      pdb=" C   ASP A  50 "   -0.009 2.00e-02 2.50e+03
      pdb=" O   ASP A  50 "    0.003 2.00e-02 2.50e+03
      pdb=" N   GLU A  51 "    0.003 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  ASP A  79 "   -0.003 2.00e-02 2.50e+03   5.14e-03 2.64e-01
      pdb=" C   ASP A  79 "    0.009 2.00e-02 2.50e+03
      pdb=" O   ASP A  79 "   -0.003 2.00e-02 2.50e+03
      pdb=" N   ARG A  80 "   -0.003 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" C   GLN A  53 "   -0.008 5.00e-02 4.00e+02   1.26e-02 2.52e-01
      pdb=" N   PRO A  54 "    0.022 5.00e-02 4.00e+02
      pdb=" CA  PRO A  54 "   -0.007 5.00e-02 4.00e+02
      pdb=" CD  PRO A  54 "   -0.007 5.00e-02 4.00e+02
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  PRO A   8 "    0.002 2.00e-02 2.50e+03   4.93e-03 2.43e-01
      pdb=" C   PRO A   8 "   -0.009 2.00e-02 2.50e+03
      pdb=" O   PRO A   8 "    0.003 2.00e-02 2.50e+03
      pdb=" N   SER A   9 "    0.003 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  GLN A  12 "    0.002 2.00e-02 2.50e+03   4.88e-03 2.38e-01
      pdb=" C   GLN A  12 "   -0.008 2.00e-02 2.50e+03
      pdb=" O   GLN A  12 "    0.003 2.00e-02 2.50e+03
      pdb=" N   PHE A  13 "    0.003 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CB  TYR A  41 "   -0.006 2.00e-02 2.50e+03   3.45e-03 2.38e-01
      pdb=" CG  TYR A  41 "    0.004 2.00e-02 2.50e+03
      pdb=" CD1 TYR A  41 "    0.002 2.00e-02 2.50e+03
      pdb=" CD2 TYR A  41 "    0.002 2.00e-02 2.50e+03
      pdb=" CE1 TYR A  41 "    0.002 2.00e-02 2.50e+03
      pdb=" CE2 TYR A  41 "    0.002 2.00e-02 2.50e+03
      pdb=" CZ  TYR A  41 "   -0.003 2.00e-02 2.50e+03
      pdb=" OH  TYR A  41 "   -0.003 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  ILE A   2 "   -0.002 2.00e-02 2.50e+03   4.87e-03 2.38e-01
      pdb=" C   ILE A   2 "    0.008 2.00e-02 2.50e+03
      pdb=" O   ILE A   2 "   -0.003 2.00e-02 2.50e+03
      pdb=" N   LYS A   3 "   -0.003 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CB  ASP A  50 "    0.002 2.00e-02 2.50e+03   4.85e-03 2.36e-01
      pdb=" CG  ASP A  50 "   -0.008 2.00e-02 2.50e+03
      pdb=" OD1 ASP A  50 "    0.003 2.00e-02 2.50e+03
      pdb=" OD2 ASP A  50 "    0.003 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  ILE A  47 "   -0.002 2.00e-02 2.50e+03   4.76e-03 2.26e-01
      pdb=" C   ILE A  47 "    0.008 2.00e-02 2.50e+03
      pdb=" O   ILE A  47 "   -0.003 2.00e-02 2.50e+03
      pdb=" N   THR A  48 "   -0.003 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  ARG A  80 "    0.002 2.00e-02 2.50e+03   4.70e-03 2.21e-01
      pdb=" C   ARG A  80 "   -0.008 2.00e-02 2.50e+03
      pdb=" O   ARG A  80 "    0.003 2.00e-02 2.50e+03
      pdb=" N   LEU A  81 "    0.003 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CD  ARG A  16 "   -0.038 9.50e-02 1.11e+02   1.72e-02 2.10e-01
      pdb=" NE  ARG A  16 "    0.001 2.00e-02 2.50e+03
      pdb=" CZ  ARG A  16 "    0.003 2.00e-02 2.50e+03
      pdb=" NH1 ARG A  16 "   -0.001 2.00e-02 2.50e+03
      pdb=" NH2 ARG A  16 "   -0.002 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  SER A   9 "    0.002 2.00e-02 2.50e+03   4.37e-03 1.91e-01
      pdb=" C   SER A   9 "   -0.008 2.00e-02 2.50e+03
      pdb=" O   SER A   9 "    0.003 2.00e-02 2.50e+03
      pdb=" N   GLN A  10 "    0.003 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  ASN A  39 "   -0.002 2.00e-02 2.50e+03   4.36e-03 1.90e-01
      pdb=" C   ASN A  39 "    0.008 2.00e-02 2.50e+03
      pdb=" O   ASN A  39 "   -0.003 2.00e-02 2.50e+03
      pdb=" N   GLU A  40 "   -0.003 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  GLY A  52 "   -0.002 2.00e-02 2.50e+03   4.30e-03 1.85e-01
      pdb=" C   GLY A  52 "    0.007 2.00e-02 2.50e+03
      pdb=" O   GLY A  52 "   -0.003 2.00e-02 2.50e+03
      pdb=" N   GLN A  53 "   -0.002 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  ILE A  78 "    0.002 2.00e-02 2.50e+03   4.17e-03 1.74e-01
      pdb=" C   ILE A  78 "   -0.007 2.00e-02 2.50e+03
      pdb=" O   ILE A  78 "    0.003 2.00e-02 2.50e+03
      pdb=" N   ASP A  79 "    0.002 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  ASP A  36 "    0.002 2.00e-02 2.50e+03   4.14e-03 1.72e-01
      pdb=" C   ASP A  36 "   -0.007 2.00e-02 2.50e+03
      pdb=" O   ASP A  36 "    0.003 2.00e-02 2.50e+03
      pdb=" N   LEU A  37 "    0.002 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CB  ASP A  79 "    0.002 2.00e-02 2.50e+03   4.02e-03 1.62e-01
      pdb=" CG  ASP A  79 "   -0.007 2.00e-02 2.50e+03
      pdb=" OD1 ASP A  79 "    0.003 2.00e-02 2.50e+03
      pdb=" OD2 ASP A  79 "    0.002 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  ASN A  29 "   -0.002 2.00e-02 2.50e+03   3.92e-03 1.53e-01
      pdb=" C   ASN A  29 "    0.007 2.00e-02 2.50e+03
      pdb=" O   ASN A  29 "   -0.003 2.00e-02 2.50e+03
      pdb=" N   GLU A  30 "   -0.002 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  PHE A  73 "   -0.002 2.00e-02 2.50e+03   3.75e-03 1.41e-01
      pdb=" C   PHE A  73 "    0.006 2.00e-02 2.50e+03
      pdb=" O   PHE A  73 "   -0.002 2.00e-02 2.50e+03
      pdb=" N   GLY A  74 "   -0.002 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  VAL A  84 "   -0.002 2.00e-02 2.50e+03   3.74e-03 1.40e-01
      pdb=" C   VAL A  84 "    0.006 2.00e-02 2.50e+03
      pdb=" O   VAL A  84 "   -0.002 2.00e-02 2.50e+03
      pdb=" N   PRO A  85 "   -0.002 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  GLU A  30 "    0.002 2.00e-02 2.50e+03   3.50e-03 1.23e-01
      pdb=" C   GLU A  30 "   -0.006 2.00e-02 2.50e+03
      pdb=" O   GLU A  30 "    0.002 2.00e-02 2.50e+03
      pdb=" N   GLN A  31 "    0.002 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  PRO A  42 "   -0.002 2.00e-02 2.50e+03   3.40e-03 1.15e-01
      pdb=" C   PRO A  42 "    0.006 2.00e-02 2.50e+03
      pdb=" O   PRO A  42 "   -0.002 2.00e-02 2.50e+03
      pdb=" N   VAL A  43 "   -0.002 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  GLY A  74 "   -0.002 2.00e-02 2.50e+03   3.38e-03 1.14e-01
      pdb=" C   GLY A  74 "    0.006 2.00e-02 2.50e+03
      pdb=" O   GLY A  74 "   -0.002 2.00e-02 2.50e+03
      pdb=" N   SER A  75 "   -0.002 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  ALA A  55 "   -0.002 2.00e-02 2.50e+03   3.35e-03 1.12e-01
      pdb=" C   ALA A  55 "    0.006 2.00e-02 2.50e+03
      pdb=" O   ALA A  55 "   -0.002 2.00e-02 2.50e+03
      pdb=" N   TYR A  56 "   -0.002 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  ALA A  57 "   -0.002 2.00e-02 2.50e+03   3.32e-03 1.10e-01
      pdb=" C   ALA A  57 "    0.006 2.00e-02 2.50e+03
      pdb=" O   ALA A  57 "   -0.002 2.00e-02 2.50e+03
      pdb=" N   PRO A  58 "   -0.002 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" C   VAL A  84 "    0.005 5.00e-02 4.00e+02   8.18e-03 1.07e-01
      pdb=" N   PRO A  85 "   -0.014 5.00e-02 4.00e+02
      pdb=" CA  PRO A  85 "    0.004 5.00e-02 4.00e+02
      pdb=" CD  PRO A  85 "    0.004 5.00e-02 4.00e+02
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  THR A  14 "    0.002 2.00e-02 2.50e+03   3.11e-03 9.68e-02
      pdb=" C   THR A  14 "   -0.005 2.00e-02 2.50e+03
      pdb=" O   THR A  14 "    0.002 2.00e-02 2.50e+03
      pdb=" N   THR A  15 "    0.002 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  LEU A  60 "    0.002 2.00e-02 2.50e+03   3.04e-03 9.24e-02
      pdb=" C   LEU A  60 "   -0.005 2.00e-02 2.50e+03
      pdb=" O   LEU A  60 "    0.002 2.00e-02 2.50e+03
      pdb=" N   TYR A  61 "    0.002 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  TYR A  26 "   -0.001 2.00e-02 2.50e+03   2.95e-03 8.70e-02
      pdb=" C   TYR A  26 "    0.005 2.00e-02 2.50e+03
      pdb=" O   TYR A  26 "   -0.002 2.00e-02 2.50e+03
      pdb=" N   SER A  27 "   -0.002 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  LEU A  76 "   -0.001 2.00e-02 2.50e+03   2.95e-03 8.69e-02
      pdb=" C   LEU A  76 "    0.005 2.00e-02 2.50e+03
      pdb=" O   LEU A  76 "   -0.002 2.00e-02 2.50e+03
      pdb=" N   MSE A  77 "   -0.002 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CG  GLN A  53 "    0.001 2.00e-02 2.50e+03   2.56e-03 6.56e-02
      pdb=" CD  GLN A  53 "   -0.004 2.00e-02 2.50e+03
      pdb=" OE1 GLN A  53 "    0.002 2.00e-02 2.50e+03
      pdb=" NE2 GLN A  53 "    0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  VAL A  63 "    0.001 2.00e-02 2.50e+03   2.26e-03 5.12e-02
      pdb=" C   VAL A  63 "   -0.004 2.00e-02 2.50e+03
      pdb=" O   VAL A  63 "    0.001 2.00e-02 2.50e+03
      pdb=" N   HIS A  64 "    0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  VAL A  45 "   -0.001 2.00e-02 2.50e+03   2.24e-03 5.00e-02
      pdb=" C   VAL A  45 "    0.004 2.00e-02 2.50e+03
      pdb=" O   VAL A  45 "   -0.001 2.00e-02 2.50e+03
      pdb=" N   LYS A  46 "   -0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  LYS A  69 "    0.001 2.00e-02 2.50e+03   2.23e-03 4.99e-02
      pdb=" C   LYS A  69 "   -0.004 2.00e-02 2.50e+03
      pdb=" O   LYS A  69 "    0.001 2.00e-02 2.50e+03
      pdb=" N   VAL A  70 "    0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  GLY A  71 "    0.001 2.00e-02 2.50e+03   2.22e-03 4.91e-02
      pdb=" C   GLY A  71 "   -0.004 2.00e-02 2.50e+03
      pdb=" O   GLY A  71 "    0.001 2.00e-02 2.50e+03
      pdb=" N   GLN A  72 "    0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CG  GLN A  31 "   -0.001 2.00e-02 2.50e+03   2.09e-03 4.37e-02
      pdb=" CD  GLN A  31 "    0.004 2.00e-02 2.50e+03
      pdb=" OE1 GLN A  31 "   -0.001 2.00e-02 2.50e+03
      pdb=" NE2 GLN A  31 "   -0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CB  ASN A  39 "   -0.001 2.00e-02 2.50e+03   1.92e-03 3.68e-02
      pdb=" CG  ASN A  39 "    0.003 2.00e-02 2.50e+03
      pdb=" OD1 ASN A  39 "   -0.001 2.00e-02 2.50e+03
      pdb=" ND2 ASN A  39 "   -0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  GLY A  38 "   -0.001 2.00e-02 2.50e+03   1.90e-03 3.63e-02
      pdb=" C   GLY A  38 "    0.003 2.00e-02 2.50e+03
      pdb=" O   GLY A  38 "   -0.001 2.00e-02 2.50e+03
      pdb=" N   ASN A  39 "   -0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  LEU A  81 "   -0.001 2.00e-02 2.50e+03   1.86e-03 3.45e-02
      pdb=" C   LEU A  81 "    0.003 2.00e-02 2.50e+03
      pdb=" O   LEU A  81 "   -0.001 2.00e-02 2.50e+03
      pdb=" N   ARG A  82 "   -0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CG  GLU A  51 "    0.001 2.00e-02 2.50e+03   1.82e-03 3.30e-02
      pdb=" CD  GLU A  51 "   -0.003 2.00e-02 2.50e+03
      pdb=" OE1 GLU A  51 "    0.001 2.00e-02 2.50e+03
      pdb=" OE2 GLU A  51 "    0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CB  ASN A  29 "   -0.001 2.00e-02 2.50e+03   1.72e-03 2.94e-02
      pdb=" CG  ASN A  29 "    0.003 2.00e-02 2.50e+03
      pdb=" OD1 ASN A  29 "   -0.001 2.00e-02 2.50e+03
      pdb=" ND2 ASN A  29 "   -0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  SER A  66 "   -0.001 2.00e-02 2.50e+03   1.66e-03 2.77e-02
      pdb=" C   SER A  66 "    0.003 2.00e-02 2.50e+03
      pdb=" O   SER A  66 "   -0.001 2.00e-02 2.50e+03
      pdb=" N   SER A  67 "   -0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CG  GLN A  12 "   -0.001 2.00e-02 2.50e+03   1.64e-03 2.68e-02
      pdb=" CD  GLN A  12 "    0.003 2.00e-02 2.50e+03
      pdb=" OE1 GLN A  12 "   -0.001 2.00e-02 2.50e+03
      pdb=" NE2 GLN A  12 "   -0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CG  GLU A  40 "   -0.001 2.00e-02 2.50e+03   1.63e-03 2.66e-02
      pdb=" CD  GLU A  40 "    0.003 2.00e-02 2.50e+03
      pdb=" OE1 GLU A  40 "   -0.001 2.00e-02 2.50e+03
      pdb=" OE2 GLU A  40 "   -0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  VAL A  70 "   -0.001 2.00e-02 2.50e+03   1.32e-03 1.75e-02
      pdb=" C   VAL A  70 "    0.002 2.00e-02 2.50e+03
      pdb=" O   VAL A  70 "   -0.001 2.00e-02 2.50e+03
      pdb=" N   GLY A  71 "   -0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  PRO A  54 "    0.001 2.00e-02 2.50e+03   1.31e-03 1.72e-02
      pdb=" C   PRO A  54 "   -0.002 2.00e-02 2.50e+03
      pdb=" O   PRO A  54 "    0.001 2.00e-02 2.50e+03
      pdb=" N   ALA A  55 "    0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  THR A  62 "   -0.001 2.00e-02 2.50e+03   1.19e-03 1.42e-02
      pdb=" C   THR A  62 "    0.002 2.00e-02 2.50e+03
      pdb=" O   THR A  62 "   -0.001 2.00e-02 2.50e+03
      pdb=" N   VAL A  63 "   -0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  TYR A  34 "    0.001 2.00e-02 2.50e+03   1.10e-03 1.21e-02
      pdb=" C   TYR A  34 "   -0.002 2.00e-02 2.50e+03
      pdb=" O   TYR A  34 "    0.001 2.00e-02 2.50e+03
      pdb=" N   VAL A  35 "    0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  LEU A  83 "    0.001 2.00e-02 2.50e+03   1.08e-03 1.18e-02
      pdb=" C   LEU A  83 "   -0.002 2.00e-02 2.50e+03
      pdb=" O   LEU A  83 "    0.001 2.00e-02 2.50e+03
      pdb=" N   VAL A  84 "    0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  GLN A  31 "   -0.000 2.00e-02 2.50e+03   1.01e-03 1.03e-02
      pdb=" C   GLN A  31 "    0.002 2.00e-02 2.50e+03
      pdb=" O   GLN A  31 "   -0.001 2.00e-02 2.50e+03
      pdb=" N   LEU A  32 "   -0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  ALA A  11 "    0.000 2.00e-02 2.50e+03   1.00e-03 1.01e-02
      pdb=" C   ALA A  11 "   -0.002 2.00e-02 2.50e+03
      pdb=" O   ALA A  11 "    0.001 2.00e-02 2.50e+03
      pdb=" N   GLN A  12 "    0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  SER A  75 "    0.000 2.00e-02 2.50e+03   9.75e-04 9.52e-03
      pdb=" C   SER A  75 "   -0.002 2.00e-02 2.50e+03
      pdb=" O   SER A  75 "    0.001 2.00e-02 2.50e+03
      pdb=" N   LEU A  76 "    0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  VAL A  43 "    0.000 2.00e-02 2.50e+03   9.71e-04 9.44e-03
      pdb=" C   VAL A  43 "   -0.002 2.00e-02 2.50e+03
      pdb=" O   VAL A  43 "    0.001 2.00e-02 2.50e+03
      pdb=" N   LEU A  44 "    0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CD  ARG A  82 "   -0.008 9.50e-02 1.11e+02   3.69e-03 9.28e-03
      pdb=" NE  ARG A  82 "    0.000 2.00e-02 2.50e+03
      pdb=" CZ  ARG A  82 "    0.001 2.00e-02 2.50e+03
      pdb=" NH1 ARG A  82 "   -0.000 2.00e-02 2.50e+03
      pdb=" NH2 ARG A  82 "   -0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  PHE A  68 "    0.000 2.00e-02 2.50e+03   9.26e-04 8.58e-03
      pdb=" C   PHE A  68 "   -0.002 2.00e-02 2.50e+03
      pdb=" O   PHE A  68 "    0.001 2.00e-02 2.50e+03
      pdb=" N   LYS A  69 "    0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  LYS A   3 "    0.000 2.00e-02 2.50e+03   9.16e-04 8.39e-03
      pdb=" C   LYS A   3 "   -0.002 2.00e-02 2.50e+03
      pdb=" O   LYS A   3 "    0.001 2.00e-02 2.50e+03
      pdb=" N   VAL A   4 "    0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  LEU A  37 "    0.000 2.00e-02 2.50e+03   8.68e-04 7.54e-03
      pdb=" C   LEU A  37 "   -0.002 2.00e-02 2.50e+03
      pdb=" O   LEU A  37 "    0.001 2.00e-02 2.50e+03
      pdb=" N   GLY A  38 "    0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  LEU A  28 "    0.000 2.00e-02 2.50e+03   8.65e-04 7.48e-03
      pdb=" C   LEU A  28 "   -0.001 2.00e-02 2.50e+03
      pdb=" O   LEU A  28 "    0.001 2.00e-02 2.50e+03
      pdb=" N   ASN A  29 "    0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  LEU A  65 "   -0.000 2.00e-02 2.50e+03   8.18e-04 6.70e-03
      pdb=" C   LEU A  65 "    0.001 2.00e-02 2.50e+03
      pdb=" O   LEU A  65 "   -0.001 2.00e-02 2.50e+03
      pdb=" N   SER A  66 "   -0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CG  GLN A  72 "    0.000 2.00e-02 2.50e+03   7.50e-04 5.63e-03
      pdb=" CD  GLN A  72 "   -0.001 2.00e-02 2.50e+03
      pdb=" OE1 GLN A  72 "    0.000 2.00e-02 2.50e+03
      pdb=" NE2 GLN A  72 "    0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CB  ASP A  36 "   -0.000 2.00e-02 2.50e+03   7.46e-04 5.56e-03
      pdb=" CG  ASP A  36 "    0.001 2.00e-02 2.50e+03
      pdb=" OD1 ASP A  36 "   -0.000 2.00e-02 2.50e+03
      pdb=" OD2 ASP A  36 "   -0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CG  GLU A   5 "    0.000 2.00e-02 2.50e+03   6.40e-04 4.09e-03
      pdb=" CD  GLU A   5 "   -0.001 2.00e-02 2.50e+03
      pdb=" OE1 GLU A   5 "    0.000 2.00e-02 2.50e+03
      pdb=" OE2 GLU A   5 "    0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  PRO A  58 "   -0.000 2.00e-02 2.50e+03   6.37e-04 4.05e-03
      pdb=" C   PRO A  58 "    0.001 2.00e-02 2.50e+03
      pdb=" O   PRO A  58 "   -0.000 2.00e-02 2.50e+03
      pdb=" N   GLY A  59 "   -0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CG  GLN A  10 "   -0.000 2.00e-02 2.50e+03   5.99e-04 3.58e-03
      pdb=" CD  GLN A  10 "    0.001 2.00e-02 2.50e+03
      pdb=" OE1 GLN A  10 "   -0.000 2.00e-02 2.50e+03
      pdb=" NE2 GLN A  10 "   -0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  ILE A   6 "    0.000 2.00e-02 2.50e+03   5.87e-04 3.44e-03
      pdb=" C   ILE A   6 "   -0.001 2.00e-02 2.50e+03
      pdb=" O   ILE A   6 "    0.000 2.00e-02 2.50e+03
      pdb=" N   LYS A   7 "    0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CG  GLU A  30 "   -0.000 2.00e-02 2.50e+03   5.12e-04 2.63e-03
      pdb=" CD  GLU A  30 "    0.001 2.00e-02 2.50e+03
      pdb=" OE1 GLU A  30 "   -0.000 2.00e-02 2.50e+03
      pdb=" OE2 GLU A  30 "   -0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  ARG A  82 "    0.000 2.00e-02 2.50e+03   4.26e-04 1.82e-03
      pdb=" C   ARG A  82 "   -0.001 2.00e-02 2.50e+03
      pdb=" O   ARG A  82 "    0.000 2.00e-02 2.50e+03
      pdb=" N   LEU A  83 "    0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  THR A  48 "    0.000 2.00e-02 2.50e+03   4.21e-04 1.77e-03
      pdb=" C   THR A  48 "   -0.001 2.00e-02 2.50e+03
      pdb=" O   THR A  48 "    0.000 2.00e-02 2.50e+03
      pdb=" N   LEU A  49 "    0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  LYS A  46 "   -0.000 2.00e-02 2.50e+03   4.15e-04 1.72e-03
      pdb=" C   LYS A  46 "    0.001 2.00e-02 2.50e+03
      pdb=" O   LYS A  46 "   -0.000 2.00e-02 2.50e+03
      pdb=" N   ILE A  47 "   -0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  GLY A  59 "    0.000 2.00e-02 2.50e+03   4.12e-04 1.70e-03
      pdb=" C   GLY A  59 "   -0.001 2.00e-02 2.50e+03
      pdb=" O   GLY A  59 "    0.000 2.00e-02 2.50e+03
      pdb=" N   LEU A  60 "    0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CD  ARG A  80 "    0.003 9.50e-02 1.11e+02   1.35e-03 1.62e-03
      pdb=" NE  ARG A  80 "   -0.000 2.00e-02 2.50e+03
      pdb=" CZ  ARG A  80 "    0.000 2.00e-02 2.50e+03
      pdb=" NH1 ARG A  80 "   -0.000 2.00e-02 2.50e+03
      pdb=" NH2 ARG A  80 "   -0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  TYR A  56 "   -0.000 2.00e-02 2.50e+03   3.69e-04 1.36e-03
      pdb=" C   TYR A  56 "    0.001 2.00e-02 2.50e+03
      pdb=" O   TYR A  56 "   -0.000 2.00e-02 2.50e+03
      pdb=" N   ALA A  57 "   -0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  TYR A  61 "   -0.000 2.00e-02 2.50e+03   2.99e-04 8.94e-04
      pdb=" C   TYR A  61 "    0.001 2.00e-02 2.50e+03
      pdb=" O   TYR A  61 "   -0.000 2.00e-02 2.50e+03
      pdb=" N   THR A  62 "   -0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  LEU A  32 "    0.000 2.00e-02 2.50e+03   2.67e-04 7.15e-04
      pdb=" C   LEU A  32 "   -0.000 2.00e-02 2.50e+03
      pdb=" O   LEU A  32 "    0.000 2.00e-02 2.50e+03
      pdb=" N   CYS A  33 "    0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  GLN A  72 "    0.000 2.00e-02 2.50e+03   2.17e-04 4.70e-04
      pdb=" C   GLN A  72 "   -0.000 2.00e-02 2.50e+03
      pdb=" O   GLN A  72 "    0.000 2.00e-02 2.50e+03
      pdb=" N   PHE A  73 "    0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  HIS A  64 "    0.000 2.00e-02 2.50e+03   1.61e-04 2.58e-04
      pdb=" C   HIS A  64 "   -0.000 2.00e-02 2.50e+03
      pdb=" O   HIS A  64 "    0.000 2.00e-02 2.50e+03
      pdb=" N   LEU A  65 "    0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  GLU A  40 "    0.000 2.00e-02 2.50e+03   1.15e-04 1.32e-04
      pdb=" C   GLU A  40 "   -0.000 2.00e-02 2.50e+03
      pdb=" O   GLU A  40 "    0.000 2.00e-02 2.50e+03
      pdb=" N   TYR A  41 "    0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  LEU A  49 "   -0.000 2.00e-02 2.50e+03   1.40e-05 1.96e-06
      pdb=" C   LEU A  49 "    0.000 2.00e-02 2.50e+03
      pdb=" O   LEU A  49 "   -0.000 2.00e-02 2.50e+03
      pdb=" N   ASP A  50 "   -0.000 2.00e-02 2.50e+03

Nonbonded | unspecified | interactions: 5335
Sorted by model distance:
nonbonded pdb=" CE  MSE A  77 "
          pdb="O    HOH S   1 "
   model   vdw sym.op.
   0.710 3.460 -x,y+1,-z+1
nonbonded pdb="SE   MSE A  77 "
          pdb="O    HOH S   1 "
   model   vdw sym.op.
   1.444 3.420 -x,y+1,-z+1
nonbonded pdb=" O   ALA A  57 "
          pdb=" OH  TYR A  61 "
   model   vdw
   2.465 3.040
nonbonded pdb=" N   GLY A  52 "
          pdb=" N   GLN A  53 "
   model   vdw
   2.576 2.560
nonbonded pdb=" N   THR A  14 "
          pdb=" O   THR A  14 "
   model   vdw
   2.578 2.496
nonbonded pdb=" ND1 HIS A  64 "
          pdb=" OG  SER A  66 "
   model   vdw
   2.580 3.120
nonbonded pdb=" OG1 THR A  15 "
          pdb="O    HOH S  14 "
   model   vdw
   2.590 3.040
nonbonded pdb=" OG1 THR A  62 "
          pdb="O    HOH S  19 "
   model   vdw
   2.608 3.040
nonbonded pdb=" N   ILE A   2 "
          pdb="O    HOH S  30 "
   model   vdw
   2.614 3.120
nonbonded pdb=" N   ASP A  50 "
          pdb=" O   ASP A  50 "
   model   vdw
   2.633 2.496
nonbonded pdb=" N   MSE A  77 "
          pdb=" O   MSE A  77 "
   model   vdw
   2.637 2.496
nonbonded pdb=" CG2 ILE A   2 "
          pdb=" CD1 ILE A   2 "
   model   vdw
   2.643 3.104
nonbonded pdb=" N   LYS A  69 "
          pdb=" O   LYS A  69 "
   model   vdw
   2.650 2.496
nonbonded pdb=" O   PRO A  54 "
          pdb=" CA  ALA A  55 "
   model   vdw
   2.652 2.776
nonbonded pdb=" O   LEU A  49 "
          pdb=" CA  ASP A  50 "
   model   vdw
   2.654 2.776
nonbonded pdb=" O   CYS A  33 "
          pdb=" CA  TYR A  34 "
   model   vdw
   2.654 2.776
nonbonded pdb=" O   VAL A  35 "
          pdb=" CA  ASP A  36 "
   model   vdw
   2.657 2.776
nonbonded pdb=" N   SER A  66 "
          pdb=" N   SER A  67 "
   model   vdw
   2.658 2.560
nonbonded pdb=" N   VAL A  84 "
          pdb=" O   VAL A  84 "
   model   vdw
   2.660 2.496
nonbonded pdb=" O   GLY A  71 "
          pdb=" CA  GLN A  72 "
   model   vdw
   2.660 2.776
nonbonded pdb=" O   PHE A  13 "
          pdb=" CA  THR A  14 "
   model   vdw
   2.664 2.776
nonbonded pdb=" N   SER A  17 "
          pdb=" O   SER A  17 "
   model   vdw
   2.666 2.496
nonbonded pdb=" OE2 GLU A  40 "
          pdb=" OG  SER A   9 "
   model   vdw sym.op.
   2.670 3.040 -x+1,y,-z+1
nonbonded pdb=" OG  SER A   9 "
          pdb=" OE2 GLU A  40 "
   model   vdw sym.op.
   2.670 3.040 -x+1,y,-z+1
nonbonded pdb=" N   GLN A  10 "
          pdb=" N   ALA A  11 "
   model   vdw
   2.671 2.560
nonbonded pdb=" C   SER A  17 "
          pdb=" OG  SER A  17 "
   model   vdw
   2.671 2.616
nonbonded pdb=" N   CYS A  33 "
          pdb=" O   CYS A  33 "
   model   vdw
   2.677 2.496
nonbonded pdb=" O   TYR A  61 "
          pdb=" CA  THR A  62 "
   model   vdw
   2.677 2.776
nonbonded pdb=" N   GLN A  12 "
          pdb=" O   GLN A  12 "
   model   vdw
   2.678 2.496
nonbonded pdb=" O   LEU A  60 "
          pdb=" CA  TYR A  61 "
   model   vdw
   2.680 2.776
nonbonded pdb=" N   GLN A  72 "
          pdb=" N   PHE A  73 "
   model   vdw
   2.680 2.560
nonbonded pdb=" O   ALA A  57 "
          pdb=" CA  PRO A  58 "
   model   vdw
   2.681 2.776
nonbonded pdb=" O   GLY A  52 "
          pdb=" CA  GLN A  53 "
   model   vdw
   2.682 2.776
nonbonded pdb=" CB  GLN A  72 "
          pdb=" NE2 GLN A  72 "
   model   vdw
   2.683 2.816
nonbonded pdb=" N   PHE A  13 "
          pdb=" O   PHE A  13 "
   model   vdw
   2.685 2.496
nonbonded pdb=" N   PRO A  85 "
          pdb=" O   PRO A  85 "
   model   vdw
   2.685 2.496
nonbonded pdb=" C   ILE A   2 "
          pdb=" CG2 ILE A   2 "
   model   vdw
   2.687 2.952
nonbonded pdb=" N   THR A  62 "
          pdb=" O   THR A  62 "
   model   vdw
   2.687 2.496
nonbonded pdb=" C   SER A  67 "
          pdb=" OG  SER A  67 "
   model   vdw
   2.689 2.616
nonbonded pdb=" O   TYR A  56 "
          pdb=" CA  ALA A  57 "
   model   vdw
   2.690 2.776
nonbonded pdb=" N   LEU A  32 "
          pdb=" O   LEU A  32 "
   model   vdw
   2.691 2.496
nonbonded pdb=" N   SER A  27 "
          pdb=" O   SER A  27 "
   model   vdw
   2.695 2.496
nonbonded pdb=" N   VAL A   4 "
          pdb=" O   VAL A   4 "
   model   vdw
   2.695 2.496
nonbonded pdb=" O   GLY A  38 "
          pdb=" CA  ASN A  39 "
   model   vdw
   2.695 2.776
nonbonded pdb=" OE2 GLU A   5 "
          pdb="O    HOH S  12 "
   model   vdw
   2.696 3.040
nonbonded pdb=" O   GLU A  51 "
          pdb=" CA  GLY A  52 "
   model   vdw
   2.698 2.752
nonbonded pdb=" N   PHE A  73 "
          pdb=" N   GLY A  74 "
   model   vdw
   2.699 2.560
nonbonded pdb=" N   TYR A  61 "
          pdb=" O   TYR A  61 "
   model   vdw
   2.702 2.496
nonbonded pdb=" O   THR A  14 "
          pdb=" CA  THR A  15 "
   model   vdw
   2.704 2.776
nonbonded pdb=" O   LEU A  28 "
          pdb=" CA  ASN A  29 "
   model   vdw
   2.705 2.776
nonbonded pdb=" O   TYR A  26 "
          pdb=" CA  SER A  27 "
   model   vdw
   2.706 2.776
nonbonded pdb=" O   ASP A  50 "
          pdb=" CA  GLU A  51 "
   model   vdw
   2.707 2.776
nonbonded pdb=" O   LYS A   7 "
          pdb=" N   GLN A  10 "
   model   vdw
   2.708 3.120
nonbonded pdb=" O   TYR A  34 "
          pdb=" CA  VAL A  35 "
   model   vdw
   2.708 2.776
nonbonded pdb=" N   LYS A   7 "
          pdb=" O   LYS A   7 "
   model   vdw
   2.710 2.496
nonbonded pdb=" O   THR A  62 "
          pdb=" CA  VAL A  63 "
   model   vdw
   2.711 2.776
nonbonded pdb=" N   TYR A  41 "
          pdb=" O   TYR A  41 "
   model   vdw
   2.711 2.496
nonbonded pdb=" O   ARG A  82 "
          pdb=" CA  LEU A  83 "
   model   vdw
   2.711 2.776
nonbonded pdb=" N   ARG A  16 "
          pdb=" O   ARG A  16 "
   model   vdw
   2.714 2.496
nonbonded pdb=" N   PRO A  54 "
          pdb=" O   PRO A  54 "
   model   vdw
   2.715 2.496
nonbonded pdb=" O   GLN A  12 "
          pdb=" CA  PHE A  13 "
   model   vdw
   2.715 2.776
nonbonded pdb=" CB  GLU A   5 "
          pdb=" OE1 GLU A   5 "
   model   vdw
   2.716 2.752
nonbonded pdb=" O   ALA A  11 "
          pdb=" CA  GLN A  12 "
   model   vdw
   2.716 2.776
nonbonded pdb=" O   ARG A  16 "
          pdb=" CA  SER A  17 "
   model   vdw
   2.717 2.776
nonbonded pdb=" N   GLN A  31 "
          pdb=" O   GLN A  31 "
   model   vdw
   2.718 2.496
nonbonded pdb=" O   VAL A   4 "
          pdb=" N   TYR A  61 "
   model   vdw
   2.718 3.120
nonbonded pdb=" CB  MSE A  77 "
          pdb=" CE  MSE A  77 "
   model   vdw
   2.718 3.088
nonbonded pdb=" O   GLU A  30 "
          pdb=" CA  GLN A  31 "
   model   vdw
   2.719 2.776
nonbonded pdb=" O   GLN A  10 "
          pdb=" CA  ALA A  11 "
   model   vdw
   2.719 2.776
nonbonded pdb=" O   ASP A  36 "
          pdb="O    HOH S   5 "
   model   vdw
   2.719 3.040
nonbonded pdb=" O   SER A   9 "
          pdb=" CA  GLN A  10 "
   model   vdw
   2.720 2.776
nonbonded pdb=" O   GLY A  74 "
          pdb=" CA  SER A  75 "
   model   vdw
   2.722 2.776
nonbonded pdb=" N   PRO A   8 "
          pdb=" N   SER A   9 "
   model   vdw
   2.722 2.560
nonbonded pdb=" O   ILE A   6 "
          pdb=" CA  LYS A   7 "
   model   vdw
   2.727 2.776
nonbonded pdb=" O   SER A  67 "
          pdb=" CA  PHE A  68 "
   model   vdw
   2.728 2.776
nonbonded pdb=" N   GLU A  40 "
          pdb=" N   TYR A  41 "
   model   vdw
   2.729 2.560
nonbonded pdb=" O   PHE A  73 "
          pdb=" CA  GLY A  74 "
   model   vdw
   2.729 2.752
nonbonded pdb=" O   PRO A  42 "
          pdb=" CA  VAL A  43 "
   model   vdw
   2.729 2.776
nonbonded pdb=" N   ALA A  57 "
          pdb=" O   ALA A  57 "
   model   vdw
   2.730 2.496
nonbonded pdb=" N   SER A  67 "
          pdb=" N   PHE A  68 "
   model   vdw
   2.731 2.560
nonbonded pdb=" O   SER A  27 "
          pdb=" CA  LEU A  28 "
   model   vdw
   2.732 2.776
nonbonded pdb=" CD1 PHE A  13 "
          pdb=" CE2 PHE A  13 "
   model   vdw
   2.733 2.912
nonbonded pdb=" O   VAL A  63 "
          pdb=" CA  HIS A  64 "
   model   vdw
   2.733 2.776
nonbonded pdb=" O   LYS A  69 "
          pdb=" CA  VAL A  70 "
   model   vdw
   2.733 2.776
nonbonded pdb=" CD1 PHE A  68 "
          pdb=" CE2 PHE A  68 "
   model   vdw
   2.734 2.912
nonbonded pdb=" O   ASN A  29 "
          pdb=" CA  GLU A  30 "
   model   vdw
   2.736 2.776
nonbonded pdb=" CD1 TYR A  61 "
          pdb=" CE2 TYR A  61 "
   model   vdw
   2.738 2.912
nonbonded pdb=" CD2 PHE A  13 "
          pdb=" CE1 PHE A  13 "
   model   vdw
   2.739 2.912
nonbonded pdb=" O   ILE A  47 "
          pdb=" CA  THR A  48 "
   model   vdw
   2.739 2.776
nonbonded pdb=" N   LYS A   3 "
          pdb="O    HOH S   5 "
   model   vdw
   2.739 3.120
nonbonded pdb=" CD1 TYR A  56 "
          pdb=" CE2 TYR A  56 "
   model   vdw
   2.740 2.912
nonbonded pdb=" O   PRO A  58 "
          pdb=" CA  GLY A  59 "
   model   vdw
   2.741 2.752
nonbonded pdb=" O   LEU A  37 "
          pdb=" CB  LEU A  37 "
   model   vdw
   2.742 2.752
nonbonded pdb=" CD2 TYR A  56 "
          pdb=" CE1 TYR A  56 "
   model   vdw
   2.743 2.912
nonbonded pdb=" O   PHE A  68 "
          pdb=" CA  LYS A  69 "
   model   vdw
   2.743 2.776
nonbonded pdb=" N   LEU A  76 "
          pdb="O    HOH S   6 "
   model   vdw
   2.743 3.120
nonbonded pdb=" C   SER A  27 "
          pdb=" OG  SER A  27 "
   model   vdw
   2.743 2.616
nonbonded pdb=" O   ALA A  55 "
          pdb=" CA  TYR A  56 "
   model   vdw
   2.743 2.776
nonbonded pdb=" CB  ASN A  39 "
          pdb=" N   GLU A  40 "
   model   vdw
   2.744 2.816
nonbonded pdb=" O   LEU A  37 "
          pdb=" CA  GLY A  38 "
   model   vdw
   2.744 2.752
nonbonded pdb=" CD2 TYR A  61 "
          pdb=" CE1 TYR A  61 "
   model   vdw
   2.744 2.912
nonbonded pdb=" N   ALA A  11 "
          pdb=" N   GLN A  12 "
   model   vdw
   2.744 2.560
nonbonded pdb=" O   VAL A  45 "
          pdb=" CA  LYS A  46 "
   model   vdw
   2.744 2.776
nonbonded pdb=" N   TYR A  56 "
          pdb=" O   TYR A  56 "
   model   vdw
   2.745 2.496
nonbonded pdb=" CD2 PHE A  68 "
          pdb=" CE1 PHE A  68 "
   model   vdw
   2.745 2.912
nonbonded pdb=" O   LEU A  76 "
          pdb=" CA  MSE A  77 "
   model   vdw
   2.746 2.776
nonbonded pdb=" O   GLU A   5 "
          pdb=" CA  ILE A   6 "
   model   vdw
   2.746 2.776
nonbonded pdb=" O   PRO A   8 "
          pdb=" N   THR A  15 "
   model   vdw sym.op.
   2.747 3.120 -x+1/2,y+1/2,-z+1
nonbonded pdb=" O   ASP A  79 "
          pdb=" CA  ARG A  80 "
   model   vdw
   2.748 2.776
nonbonded pdb=" O   MSE A  77 "
          pdb=" CA  ILE A  78 "
   model   vdw
   2.748 2.776
nonbonded pdb=" O   GLN A  31 "
          pdb=" CA  LEU A  32 "
   model   vdw
   2.749 2.776
nonbonded pdb=" C   SER A   9 "
          pdb=" OG  SER A   9 "
   model   vdw
   2.749 2.616
nonbonded pdb=" CD1 TYR A  26 "
          pdb=" CE2 TYR A  26 "
   model   vdw
   2.749 2.912
nonbonded pdb=" N   ALA A  57 "
          pdb="O    HOH S   7 "
   model   vdw
   2.750 3.120
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" CD1 ILE A   6 "
   model   vdw
   2.750 3.104
nonbonded pdb=" CD2 TYR A  34 "
          pdb=" CE1 TYR A  34 "
   model   vdw
   2.751 2.912
nonbonded pdb=" O   LYS A  46 "
          pdb=" CA  ILE A  47 "
   model   vdw
   2.752 2.776
nonbonded pdb=" O   GLY A  59 "
          pdb=" CA  LEU A  60 "
   model   vdw
   2.752 2.776
nonbonded pdb=" N   LEU A  49 "
          pdb=" O   LEU A  49 "
   model   vdw
   2.752 2.496
nonbonded pdb=" O   ILE A   2 "
          pdb=" OG1 THR A  62 "
   model   vdw
   2.753 3.040
nonbonded pdb=" N   ARG A  80 "
          pdb=" O   ARG A  80 "
   model   vdw
   2.753 2.496
nonbonded pdb=" O   ARG A  80 "
          pdb=" CA  LEU A  81 "
   model   vdw
   2.754 2.776
nonbonded pdb=" O   ASP A  36 "
          pdb=" CA  LEU A  37 "
   model   vdw
   2.754 2.776
nonbonded pdb=" CG  TYR A  61 "
          pdb=" CZ  TYR A  61 "
   model   vdw
   2.755 2.784
nonbonded pdb=" CG  PHE A  13 "
          pdb=" CZ  PHE A  13 "
   model   vdw
   2.755 2.848
nonbonded pdb=" O   TYR A  41 "
          pdb=" CA  PRO A  42 "
   model   vdw
   2.756 2.776
nonbonded pdb=" CD2 TYR A  26 "
          pdb=" CE1 TYR A  26 "
   model   vdw
   2.756 2.912
nonbonded pdb=" N   ASN A  39 "
          pdb=" O   ASN A  39 "
   model   vdw
   2.756 2.496
nonbonded pdb=" CD2 PHE A  73 "
          pdb=" CE1 PHE A  73 "
   model   vdw
   2.756 2.912
nonbonded pdb=" CG  PHE A  68 "
          pdb=" CZ  PHE A  68 "
   model   vdw
   2.756 2.848
nonbonded pdb=" CA  ASP A  36 "
          pdb=" OD1 ASP A  36 "
   model   vdw
   2.757 2.776
nonbonded pdb=" CD1 TYR A  41 "
          pdb=" CE2 TYR A  41 "
   model   vdw
   2.757 2.912
nonbonded pdb=" CD2 TYR A  41 "
          pdb=" CE1 TYR A  41 "
   model   vdw
   2.758 2.912
nonbonded pdb=" N   VAL A  43 "
          pdb=" CG2 VAL A  43 "
   model   vdw
   2.759 2.832
nonbonded pdb=" CD1 TYR A  34 "
          pdb=" CE2 TYR A  34 "
   model   vdw
   2.760 2.912
nonbonded pdb=" O   PHE A  73 "
          pdb=" CB  PHE A  73 "
   model   vdw
   2.762 2.752
nonbonded pdb=" CD1 PHE A  73 "
          pdb=" CE2 PHE A  73 "
   model   vdw
   2.763 2.912
nonbonded pdb=" O   SER A  66 "
          pdb=" CA  SER A  67 "
   model   vdw
   2.763 2.776
nonbonded pdb=" N   HIS A  64 "
          pdb=" O   HIS A  64 "
   model   vdw
   2.763 2.496
nonbonded pdb=" N   LEU A  37 "
          pdb=" N   GLY A  38 "
   model   vdw
   2.763 2.560
nonbonded pdb=" O   GLN A  72 "
          pdb=" CA  PHE A  73 "
   model   vdw
   2.763 2.776
nonbonded pdb=" O   HIS A  64 "
          pdb=" CA  LEU A  65 "
   model   vdw
   2.764 2.776
nonbonded pdb=" N   VAL A  70 "
          pdb="O    HOH S  10 "
   model   vdw
   2.764 3.120
nonbonded pdb=" CB  GLN A  31 "
          pdb=" OE1 GLN A  31 "
   model   vdw
   2.764 2.752
nonbonded pdb=" CG  TYR A  56 "
          pdb=" CZ  TYR A  56 "
   model   vdw
   2.765 2.784
nonbonded pdb=" O   ASN A  39 "
          pdb=" CA  GLU A  40 "
   model   vdw
   2.765 2.776
nonbonded pdb=" O   ILE A  78 "
          pdb=" CA  ASP A  79 "
   model   vdw
   2.765 2.776
nonbonded pdb=" O   LEU A  81 "
          pdb=" CA  ARG A  82 "
   model   vdw
   2.768 2.776
nonbonded pdb=" O   LEU A  83 "
          pdb=" CA  VAL A  84 "
   model   vdw
   2.770 2.776
nonbonded pdb=" CG  TYR A  26 "
          pdb=" CZ  TYR A  26 "
   model   vdw
   2.771 2.784
nonbonded pdb=" O   GLN A  10 "
          pdb=" NE2 GLN A  31 "
   model   vdw
   2.773 3.120
nonbonded pdb=" CB  GLU A  30 "
          pdb=" OE1 GLU A  30 "
   model   vdw
   2.776 2.752
nonbonded pdb=" O   SER A  67 "
          pdb=" N   ASP A  79 "
   model   vdw
   2.777 3.120
nonbonded pdb=" CG  TYR A  41 "
          pdb=" CZ  TYR A  41 "
   model   vdw
   2.778 2.784
nonbonded pdb=" N   GLY A  71 "
          pdb=" O   GLY A  71 "
   model   vdw
   2.778 2.496
nonbonded pdb=" O   THR A  48 "
          pdb=" CA  LEU A  49 "
   model   vdw
   2.779 2.776
nonbonded pdb=" CG  TYR A  34 "
          pdb=" CZ  TYR A  34 "
   model   vdw
   2.779 2.784
nonbonded pdb=" O   LEU A  65 "
          pdb=" CA  SER A  66 "
   model   vdw
   2.779 2.776
nonbonded pdb=" O   TYR A  41 "
          pdb="O    HOH S   9 "
   model   vdw
   2.780 3.040
nonbonded pdb=" C   VAL A  45 "
          pdb=" CG1 VAL A  45 "
   model   vdw
   2.781 2.952
nonbonded pdb=" N   ARG A  82 "
          pdb=" O   ARG A  82 "
   model   vdw
   2.782 2.496
nonbonded pdb=" O   ALA A  11 "
          pdb=" CB  ALA A  11 "
   model   vdw
   2.782 2.768
nonbonded pdb=" C   ILE A  47 "
          pdb=" CG2 ILE A  47 "
   model   vdw
   2.782 2.952
nonbonded pdb=" O   SER A  75 "
          pdb=" CA  LEU A  76 "
   model   vdw
   2.783 2.776
nonbonded pdb=" O   GLN A  53 "
          pdb=" CA  PRO A  54 "
   model   vdw
   2.783 2.776
nonbonded pdb=" O   GLN A  31 "
          pdb=" N   ILE A  47 "
   model   vdw
   2.783 3.120
nonbonded pdb=" O   LEU A  32 "
          pdb=" CA  CYS A  33 "
   model   vdw
   2.784 2.776
nonbonded pdb=" N   ALA A  55 "
          pdb=" O   ALA A  55 "
   model   vdw
   2.784 2.496
nonbonded pdb=" CG  PHE A  73 "
          pdb=" CZ  PHE A  73 "
   model   vdw
   2.786 2.848
nonbonded pdb=" O   GLY A  52 "
          pdb="O    HOH S  20 "
   model   vdw
   2.787 3.040
nonbonded pdb=" N   VAL A  35 "
          pdb=" O   VAL A  35 "
   model   vdw
   2.789 2.496
nonbonded pdb=" N   SER A   9 "
          pdb=" N   GLN A  10 "
   model   vdw
   2.790 2.560
nonbonded pdb=" CB  GLU A  40 "
          pdb=" OE1 GLU A  40 "
   model   vdw
   2.791 2.752
nonbonded pdb=" O   LYS A   7 "
          pdb=" CA  PRO A   8 "
   model   vdw
   2.791 2.776
nonbonded pdb=" O   LEU A  44 "
          pdb=" CA  VAL A  45 "
   model   vdw
   2.791 2.776
nonbonded pdb=" N   ILE A   6 "
          pdb=" O   ILE A   6 "
   model   vdw
   2.795 2.496
nonbonded pdb=" N   GLU A   5 "
          pdb=" O   GLU A   5 "
   model   vdw
   2.795 2.496
nonbonded pdb=" O   PRO A   8 "
          pdb=" CA  SER A   9 "
   model   vdw
   2.796 2.776
nonbonded pdb=" N   PRO A  42 "
          pdb=" O   PRO A  42 "
   model   vdw
   2.797 2.496
nonbonded pdb=" OE1 GLU A  30 "
          pdb="O    HOH S  11 "
   model   vdw
   2.797 3.040
nonbonded pdb=" CA  LEU A  28 "
          pdb=" CD1 LEU A  28 "
   model   vdw
   2.798 3.112
nonbonded pdb=" O   THR A  15 "
          pdb=" CA  ARG A  16 "
   model   vdw
   2.798 2.776
nonbonded pdb=" N   SER A  66 "
          pdb=" OG  SER A  66 "
   model   vdw
   2.798 2.496
nonbonded pdb=" N   THR A  62 "
          pdb=" O   VAL A  84 "
   model   vdw
   2.799 3.120
nonbonded pdb=" O   ALA A  57 "
          pdb=" C   PRO A  58 "
   model   vdw
   2.800 3.270
nonbonded pdb=" O   VAL A  43 "
          pdb=" CA  LEU A  44 "
   model   vdw
   2.800 2.776
nonbonded pdb=" O   THR A  48 "
          pdb=" CB  THR A  48 "
   model   vdw
   2.800 2.776
nonbonded pdb=" O   ILE A   2 "
          pdb=" CA  LYS A   3 "
   model   vdw
   2.803 2.776
nonbonded pdb=" C   ILE A  78 "
          pdb=" CG2 ILE A  78 "
   model   vdw
   2.804 2.952
nonbonded pdb=" CA  ASN A  29 "
          pdb=" OD1 ASN A  29 "
   model   vdw
   2.806 2.776
nonbonded pdb=" N   ILE A  47 "
          pdb=" O   ILE A  47 "
   model   vdw
   2.807 2.496
nonbonded pdb=" OG1 THR A  15 "
          pdb=" OD1 ASN A  29 "
   model   vdw
   2.809 3.040
nonbonded pdb=" N   ILE A  78 "
          pdb=" O   ILE A  78 "
   model   vdw
   2.811 2.496
nonbonded pdb=" CD  ARG A  80 "
          pdb=" NH1 ARG A  80 "
   model   vdw
   2.812 2.816
nonbonded pdb=" NH2 ARG A  16 "
          pdb=" O   LEU A  60 "
   model   vdw sym.op.
   2.812 3.120 x,y-1,z
nonbonded pdb=" N   GLY A  59 "
          pdb=" O   GLY A  59 "
   model   vdw
   2.813 2.496
nonbonded pdb=" CD  ARG A  82 "
          pdb=" NH1 ARG A  82 "
   model   vdw
   2.813 2.816
nonbonded pdb=" N   LEU A  28 "
          pdb=" O   LEU A  28 "
   model   vdw
   2.814 2.496
nonbonded pdb=" O   LYS A  46 "
          pdb="O    HOH S   6 "
   model   vdw sym.op.
   2.817 3.040 -x+1,y,-z+2
nonbonded pdb=" N   VAL A  43 "
          pdb=" O   VAL A  43 "
   model   vdw
   2.820 2.496
nonbonded pdb=" O   GLN A  10 "
          pdb=" CB  GLN A  10 "
   model   vdw
   2.820 2.752
nonbonded pdb=" O   SER A  66 "
          pdb=" NH1 ARG A  82 "
   model   vdw
   2.820 3.120
nonbonded pdb=" O   VAL A  84 "
          pdb=" CA  PRO A  85 "
   model   vdw
   2.821 2.776
nonbonded pdb=" N   VAL A  45 "
          pdb=" O   VAL A  45 "
   model   vdw
   2.822 2.496
nonbonded pdb=" O   VAL A   4 "
          pdb=" CA  GLU A   5 "
   model   vdw
   2.823 2.776
nonbonded pdb=" N   PHE A  68 "
          pdb=" CG  PHE A  68 "
   model   vdw
   2.824 2.672
nonbonded pdb=" N   THR A  48 "
          pdb=" OG1 THR A  48 "
   model   vdw
   2.827 2.496
nonbonded pdb=" O   LYS A   3 "
          pdb=" CA  VAL A   4 "
   model   vdw
   2.828 2.776
nonbonded pdb=" N   SER A  75 "
          pdb=" O   SER A  75 "
   model   vdw
   2.828 2.496
nonbonded pdb=" NE2 GLN A  12 "
          pdb="O    HOH S   8 "
   model   vdw
   2.829 3.120
nonbonded pdb=" N   GLN A  53 "
          pdb=" O   GLN A  53 "
   model   vdw
   2.831 2.496
nonbonded pdb=" O   VAL A  70 "
          pdb=" CA  GLY A  71 "
   model   vdw
   2.832 2.752
nonbonded pdb=" O   LYS A   7 "
          pdb=" C   PRO A   8 "
   model   vdw
   2.835 3.270
nonbonded pdb=" N   THR A  15 "
          pdb=" OG1 THR A  15 "
   model   vdw
   2.839 2.496
nonbonded pdb=" O   GLU A  40 "
          pdb=" CA  TYR A  41 "
   model   vdw
   2.839 2.776
nonbonded pdb=" N   GLY A  38 "
          pdb=" N   ASN A  39 "
   model   vdw
   2.841 2.560
nonbonded pdb=" OG  SER A  75 "
          pdb="O    HOH S   3 "
   model   vdw
   2.842 3.040
nonbonded pdb=" NZ  LYS A   3 "
          pdb=" O   GLN A  72 "
   model   vdw sym.op.
   2.843 3.120 -x+1,y+1,-z+2
nonbonded pdb=" N   LEU A  65 "
          pdb=" N   SER A  66 "
   model   vdw
   2.843 2.560
nonbonded pdb=" O   ARG A  16 "
          pdb=" N   LEU A  28 "
   model   vdw
   2.843 3.120
nonbonded pdb=" N   THR A  15 "
          pdb=" O   THR A  15 "
   model   vdw
   2.844 2.496
nonbonded pdb=" C   SER A  75 "
          pdb=" OG  SER A  75 "
   model   vdw
   2.845 2.616
nonbonded pdb=" CD  ARG A  16 "
          pdb=" NH1 ARG A  16 "
   model   vdw
   2.848 2.816
nonbonded pdb=" CA  GLN A  53 "
          pdb=" CD  PRO A  54 "
   model   vdw
   2.852 3.096
nonbonded pdb=" N   GLY A  74 "
          pdb=" N   SER A  75 "
   model   vdw
   2.853 2.560
nonbonded pdb=" N   ASN A  29 "
          pdb=" O   ASN A  29 "
   model   vdw
   2.853 2.496
nonbonded pdb=" CB  GLN A  10 "
          pdb=" OE1 GLN A  10 "
   model   vdw
   2.855 2.752
nonbonded pdb=" C   GLN A  12 "
          pdb=" CG  GLN A  12 "
   model   vdw
   2.856 2.936
nonbonded pdb=" NE2 GLN A  31 "
          pdb=" O   TYR A  56 "
   model   vdw
   2.856 3.120
nonbonded pdb=" O   LYS A   7 "
          pdb=" N   SER A   9 "
   model   vdw
   2.856 3.120
nonbonded pdb=" C   VAL A  63 "
          pdb=" CG1 VAL A  63 "
   model   vdw
   2.856 2.952
nonbonded pdb=" CA  ASP A  79 "
          pdb=" OD1 ASP A  79 "
   model   vdw
   2.857 2.776
nonbonded pdb=" N   THR A  14 "
          pdb=" OG1 THR A  14 "
   model   vdw
   2.860 2.496
nonbonded pdb=" CB  ASP A  79 "
          pdb=" N   ARG A  80 "
   model   vdw
   2.865 2.816
nonbonded pdb=" O   LEU A  44 "
          pdb="O    HOH S  25 "
   model   vdw
   2.865 3.040
nonbonded pdb=" C   GLN A  53 "
          pdb=" CG  GLN A  53 "
   model   vdw
   2.865 2.936
nonbonded pdb=" OG1 THR A  48 "
          pdb="O    HOH S  38 "
   model   vdw
   2.866 3.040
nonbonded pdb=" N   GLY A  71 "
          pdb=" O   SER A  75 "
   model   vdw
   2.871 3.120
nonbonded pdb=" N   LEU A  44 "
          pdb=" O   LEU A  44 "
   model   vdw
   2.873 2.496
nonbonded pdb=" CA  ILE A   2 "
          pdb=" CD1 ILE A   2 "
   model   vdw
   2.874 3.112
nonbonded pdb=" N   ASP A  50 "
          pdb=" OE1 GLN A  53 "
   model   vdw
   2.877 3.120
nonbonded pdb=" O   ASN A  29 "
          pdb=" N   LEU A  49 "
   model   vdw
   2.880 3.120
nonbonded pdb=" N   SER A  75 "
          pdb=" OG  SER A  75 "
   model   vdw
   2.882 2.496
nonbonded pdb=" N   GLU A  51 "
          pdb=" O   GLU A  51 "
   model   vdw
   2.885 2.496
nonbonded pdb=" N   VAL A  70 "
          pdb=" CG2 VAL A  70 "
   model   vdw
   2.888 2.832
nonbonded pdb=" CA  LYS A   7 "
          pdb=" CD  PRO A   8 "
   model   vdw
   2.888 3.096
nonbonded pdb=" N   GLU A  51 "
          pdb=" CD  GLU A  51 "
   model   vdw
   2.888 3.350
nonbonded pdb=" OD2 ASP A  50 "
          pdb=" NE  ARG A  82 "
   model   vdw
   2.890 3.120
nonbonded pdb=" N   ASN A  39 "
          pdb=" CG  ASN A  39 "
   model   vdw
   2.890 2.680
nonbonded pdb=" N   LEU A  83 "
          pdb=" O   LEU A  83 "
   model   vdw
   2.891 2.496
nonbonded pdb=" N   LYS A  46 "
          pdb=" O   LYS A  46 "
   model   vdw
   2.891 2.496
nonbonded pdb=" N   VAL A  70 "
          pdb=" O   VAL A  70 "
   model   vdw
   2.893 2.496
nonbonded pdb=" O   ASN A  39 "
          pdb=" C   GLU A  40 "
   model   vdw
   2.893 3.270
nonbonded pdb=" N   VAL A  63 "
          pdb=" O   VAL A  63 "
   model   vdw
   2.894 2.496
nonbonded pdb="O    HOH S   1 "
          pdb=" CG  MSE A  77 "
   model   vdw sym.op.
   2.895 3.440 -x,y-1,-z+1
nonbonded pdb=" CG  MSE A  77 "
          pdb="O    HOH S   1 "
   model   vdw sym.op.
   2.895 3.440 -x,y+1,-z+1
nonbonded pdb=" O   GLN A  12 "
          pdb="O    HOH S   8 "
   model   vdw
   2.896 3.040
nonbonded pdb=" N   PRO A  58 "
          pdb=" O   PRO A  58 "
   model   vdw
   2.898 2.496
nonbonded pdb=" CA  VAL A  84 "
          pdb=" CD  PRO A  85 "
   model   vdw
   2.899 3.096
nonbonded pdb=" O   MSE A  77 "
          pdb=" CB  MSE A  77 "
   model   vdw
   2.900 2.752
nonbonded pdb=" N   GLU A  51 "
          pdb=" OE1 GLU A  51 "
   model   vdw
   2.900 3.120
nonbonded pdb=" N   HIS A  64 "
          pdb=" O   ARG A  82 "
   model   vdw
   2.900 3.120
nonbonded pdb=" CA  ASP A  50 "
          pdb=" OD1 ASP A  50 "
   model   vdw
   2.902 2.776
nonbonded pdb=" C   GLU A   5 "
          pdb=" CG  GLU A   5 "
   model   vdw
   2.904 2.936
nonbonded pdb=" N   ILE A  78 "
          pdb="O    HOH S  13 "
   model   vdw
   2.905 3.120
nonbonded pdb="O    HOH S  13 "
          pdb=" N   ILE A  78 "
   model   vdw sym.op.
   2.905 3.120 -x+1,y,-z+2
nonbonded pdb=" N   ILE A  78 "
          pdb="O    HOH S  13 "
   model   vdw sym.op.
   2.905 3.120 -x+1,y,-z+2
nonbonded pdb=" O   LEU A  81 "
          pdb=" CB  LEU A  81 "
   model   vdw
   2.906 2.752
nonbonded pdb=" C   THR A  62 "
          pdb=" CG2 THR A  62 "
   model   vdw
   2.906 2.952
nonbonded pdb=" C   TYR A  26 "
          pdb=" CG  TYR A  26 "
   model   vdw
   2.907 2.792
nonbonded pdb=" O   ILE A   6 "
          pdb=" N   GLY A  59 "
   model   vdw
   2.908 3.120
nonbonded pdb=" N   LYS A   7 "
          pdb=" OE1 GLN A  10 "
   model   vdw
   2.908 3.120
nonbonded pdb=" O   THR A  14 "
          pdb=" N   GLU A  30 "
   model   vdw
   2.908 3.120
nonbonded pdb=" CA  ALA A  57 "
          pdb=" CD  PRO A  58 "
   model   vdw
   2.909 3.096
nonbonded pdb=" O   GLN A  72 "
          pdb=" CB  GLN A  72 "
   model   vdw
   2.910 2.752
nonbonded pdb=" CD1 ILE A   2 "
          pdb=" CD1 LEU A  65 "
   model   vdw sym.op.
   2.910 3.880 -x+1,y,-z+2
nonbonded pdb=" O   LYS A   3 "
          pdb=" N   ASP A  36 "
   model   vdw
   2.911 3.120
nonbonded pdb=" N   TYR A  34 "
          pdb=" O   TYR A  34 "
   model   vdw
   2.912 2.496
nonbonded pdb=" O   SER A  67 "
          pdb=" OG  SER A  67 "
   model   vdw
   2.913 3.040
nonbonded pdb=" N   LEU A  32 "
          pdb=" CG  LEU A  32 "
   model   vdw
   2.914 2.840
nonbonded pdb=" C   LYS A   7 "
          pdb=" N   SER A   9 "
   model   vdw
   2.915 3.350
nonbonded pdb=" N   ILE A   6 "
          pdb=" CG1 ILE A   6 "
   model   vdw
   2.917 2.816
nonbonded pdb=" N   LEU A  76 "
          pdb=" O   LEU A  76 "
   model   vdw
   2.917 2.496
nonbonded pdb=" N   GLN A  31 "
          pdb=" O   ILE A  47 "
   model   vdw
   2.919 3.120
nonbonded pdb=" O   LEU A  49 "
          pdb=" NH1 ARG A  80 "
   model   vdw
   2.919 3.120
nonbonded pdb=" CA  TYR A  41 "
          pdb=" CD  PRO A  42 "
   model   vdw
   2.919 3.096
nonbonded pdb=" N   LEU A  60 "
          pdb=" O   LEU A  60 "
   model   vdw
   2.921 2.496
nonbonded pdb=" N   GLU A  30 "
          pdb=" O   GLU A  30 "
   model   vdw
   2.921 2.496
nonbonded pdb=" N   ASP A  79 "
          pdb=" N   ARG A  80 "
   model   vdw
   2.924 2.560
nonbonded pdb=" CB  ASP A  50 "
          pdb=" N   GLU A  51 "
   model   vdw
   2.925 2.816
nonbonded pdb=" N   PHE A  68 "
          pdb=" O   PHE A  68 "
   model   vdw
   2.926 2.496
nonbonded pdb=" N   GLU A  40 "
          pdb=" CG  GLU A  40 "
   model   vdw
   2.931 2.816
nonbonded pdb=" CA  LEU A  44 "
          pdb=" CD1 LEU A  44 "
   model   vdw
   2.932 3.112
nonbonded pdb=" N   VAL A  84 "
          pdb=" CG2 VAL A  84 "
   model   vdw
   2.933 2.832
nonbonded pdb=" O   THR A  48 "
          pdb=" C   LEU A  49 "
   model   vdw
   2.934 3.270
nonbonded pdb=" C   THR A  48 "
          pdb=" CG2 THR A  48 "
   model   vdw
   2.934 2.952
nonbonded pdb=" O   ILE A   6 "
          pdb=" CB  ILE A   6 "
   model   vdw
   2.936 2.776
nonbonded pdb=" C   ALA A  55 "
          pdb=" C   TYR A  56 "
   model   vdw
   2.937 2.800
nonbonded pdb=" O   VAL A  84 "
          pdb=" C   PRO A  85 "
   model   vdw
   2.937 3.270
nonbonded pdb=" OG1 THR A  14 "
          pdb="O    HOH S  11 "
   model   vdw
   2.937 3.040
nonbonded pdb=" C   THR A  15 "
          pdb=" CG2 THR A  15 "
   model   vdw
   2.937 2.952
nonbonded pdb=" CA  GLU A  40 "
          pdb=" OE1 GLU A  40 "
   model   vdw
   2.938 3.470
nonbonded pdb=" N   GLU A  51 "
          pdb=" CG  GLU A  51 "
   model   vdw
   2.938 2.816
nonbonded pdb=" C   VAL A  70 "
          pdb=" CG1 VAL A  70 "
   model   vdw
   2.939 2.952
nonbonded pdb=" C   THR A  14 "
          pdb=" OG1 THR A  14 "
   model   vdw
   2.942 2.616
nonbonded pdb=" N   GLN A  10 "
          pdb=" CG  GLN A  10 "
   model   vdw
   2.945 2.816
nonbonded pdb=" O   VAL A  70 "
          pdb=" CB  VAL A  70 "
   model   vdw
   2.947 2.776
nonbonded pdb=" CB  MSE A  77 "
          pdb="O    HOH S   1 "
   model   vdw sym.op.
   2.947 3.440 -x,y+1,-z+1
nonbonded pdb=" CB  TYR A  61 "
          pdb=" N   THR A  62 "
   model   vdw
   2.948 2.816
nonbonded pdb=" N   LEU A  37 "
          pdb="O    HOH S   9 "
   model   vdw
   2.951 3.120
nonbonded pdb=" N   VAL A  35 "
          pdb=" O   VAL A  43 "
   model   vdw
   2.953 3.120
nonbonded pdb=" N   ILE A   6 "
          pdb=" O   GLY A  59 "
   model   vdw
   2.953 3.120
nonbonded pdb=" O   CYS A  33 "
          pdb=" N   VAL A  45 "
   model   vdw
   2.955 3.120
nonbonded pdb=" OH  TYR A  56 "
          pdb=" N   LEU A  83 "
   model   vdw
   2.956 3.120
nonbonded pdb=" O   VAL A  70 "
          pdb=" O   GLY A  71 "
   model   vdw
   2.957 3.040
nonbonded pdb=" N   VAL A  63 "
          pdb=" CG2 VAL A  63 "
   model   vdw
   2.957 2.832
nonbonded pdb=" C   LYS A   7 "
          pdb=" C   PRO A   8 "
   model   vdw
   2.960 2.800
nonbonded pdb=" C   LYS A   3 "
          pdb=" CG  LYS A   3 "
   model   vdw
   2.961 2.936
nonbonded pdb=" C   ALA A  57 "
          pdb=" C   PRO A  58 "
   model   vdw
   2.963 2.800
nonbonded pdb=" O   ILE A   2 "
          pdb=" CB  ILE A   2 "
   model   vdw
   2.965 2.776
nonbonded pdb=" O   PRO A  54 "
          pdb=" C   ALA A  55 "
   model   vdw
   2.966 3.270
nonbonded pdb=" O   SER A  66 "
          pdb=" CB  SER A  66 "
   model   vdw
   2.968 2.752
nonbonded pdb=" N   TYR A  26 "
          pdb=" O   TYR A  26 "
   model   vdw
   2.968 2.496
nonbonded pdb=" N   SER A   9 "
          pdb=" OG  SER A   9 "
   model   vdw
   2.969 2.496
nonbonded pdb=" CA  LEU A  37 "
          pdb=" CD2 LEU A  37 "
   model   vdw
   2.970 3.112
nonbonded pdb=" C   ASN A  39 "
          pdb=" C   GLU A  40 "
   model   vdw
   2.970 2.800
nonbonded pdb=" CB  MSE A  77 "
          pdb=" N   ILE A  78 "
   model   vdw
   2.971 2.816
nonbonded pdb=" N   LYS A  69 "
          pdb=" CG  LYS A  69 "
   model   vdw
   2.971 2.816
nonbonded pdb=" C   THR A  48 "
          pdb=" C   LEU A  49 "
   model   vdw
   2.971 2.800
nonbonded pdb=" O   GLU A   5 "
          pdb=" N   TYR A  34 "
   model   vdw
   2.971 3.120
nonbonded pdb=" CB  GLU A  51 "
          pdb=" OE1 GLU A  51 "
   model   vdw
   2.975 2.752
nonbonded pdb=" O   ALA A  55 "
          pdb=" C   TYR A  56 "
   model   vdw
   2.975 3.270
nonbonded pdb=" C   LEU A  65 "
          pdb=" N   SER A  67 "
   model   vdw
   2.981 3.350
nonbonded pdb=" C   ILE A   6 "
          pdb=" CG2 ILE A   6 "
   model   vdw
   2.981 2.952
nonbonded pdb=" CG2 ILE A  47 "
          pdb=" CD1 ILE A  47 "
   model   vdw
   2.982 3.104
nonbonded pdb=" N   VAL A  35 "
          pdb=" CG2 VAL A  35 "
   model   vdw
   2.983 2.832
nonbonded pdb=" N   LYS A   3 "
          pdb=" O   LYS A   3 "
   model   vdw
   2.984 2.496
nonbonded pdb=" O   ASP A  36 "
          pdb=" CB  ASP A  36 "
   model   vdw
   2.984 2.752
nonbonded pdb=" CA  ASN A  39 "
          pdb=" ND2 ASN A  39 "
   model   vdw
   2.986 2.840
nonbonded pdb=" C   PRO A  54 "
          pdb=" C   ALA A  55 "
   model   vdw
   2.987 2.800
nonbonded pdb=" C   VAL A  35 "
          pdb=" CG1 VAL A  35 "
   model   vdw
   2.987 2.952
nonbonded pdb=" N   GLU A  30 "
          pdb=" CG  GLU A  30 "
   model   vdw
   2.988 2.816
nonbonded pdb=" N   GLN A  72 "
          pdb=" CG  GLN A  72 "
   model   vdw
   2.988 2.816
nonbonded pdb=" OG1 THR A  62 "
          pdb=" N   VAL A  63 "
   model   vdw
   2.988 3.120
nonbonded pdb=" N   ILE A   2 "
          pdb=" O   ILE A   2 "
   model   vdw
   2.989 2.496
nonbonded pdb=" CB  CYS A  33 "
          pdb=" N   TYR A  34 "
   model   vdw
   2.989 2.816
nonbonded pdb=" O   SER A   9 "
          pdb=" CB  SER A   9 "
   model   vdw
   2.992 2.752
nonbonded pdb=" N   LEU A  32 "
          pdb="O    HOH S   8 "
   model   vdw
   2.994 3.120
nonbonded pdb=" C   ASP A  79 "
          pdb=" CG  ASP A  79 "
   model   vdw
   2.994 2.800
nonbonded pdb=" N   PHE A  73 "
          pdb="O    HOH S   3 "
   model   vdw
   2.996 3.120
nonbonded pdb=" N   ASN A  29 "
          pdb=" CG  ASN A  29 "
   model   vdw
   3.000 2.680
nonbonded pdb=" OE2 GLU A  30 "
          pdb=" NZ  LYS A  46 "
   model   vdw
   3.005 3.120
nonbonded pdb=" C   VAL A  84 "
          pdb=" C   PRO A  85 "
   model   vdw
   3.007 2.800
nonbonded pdb=" C   ASP A  36 "
          pdb=" OD1 ASP A  36 "
   model   vdw
   3.008 3.270
nonbonded pdb=" C   VAL A   4 "
          pdb=" CG1 VAL A   4 "
   model   vdw
   3.008 2.952
nonbonded pdb=" O   LYS A  69 "
          pdb=" O   MSE A  77 "
   model   vdw
   3.009 3.040
nonbonded pdb=" N   LYS A  69 "
          pdb=" O   MSE A  77 "
   model   vdw
   3.009 3.120
nonbonded pdb=" O   PRO A  54 "
          pdb="O    HOH S  39 "
   model   vdw
   3.009 3.040
nonbonded pdb=" OD1 ASP A  50 "
          pdb=" NH1 ARG A  80 "
   model   vdw
   3.011 3.120
nonbonded pdb=" N   LYS A  46 "
          pdb=" O   GLY A  74 "
   model   vdw sym.op.
   3.012 3.120 -x+1,y,-z+2
nonbonded pdb=" C   PHE A  13 "
          pdb=" CG  PHE A  13 "
   model   vdw
   3.012 2.792
nonbonded pdb=" N   VAL A   4 "
          pdb=" CG2 VAL A   4 "
   model   vdw
   3.013 2.832
nonbonded pdb=" O   ARG A  80 "
          pdb=" C   LEU A  81 "
   model   vdw
   3.016 3.270
nonbonded pdb=" N   LYS A   7 "
          pdb=" CG  LYS A   7 "
   model   vdw
   3.016 2.816
nonbonded pdb=" O   LEU A  44 "
          pdb=" CB  LEU A  44 "
   model   vdw
   3.017 2.752
nonbonded pdb=" C   VAL A  84 "
          pdb=" CG2 VAL A  84 "
   model   vdw
   3.017 2.952
nonbonded pdb=" C   SER A  66 "
          pdb=" OG  SER A  66 "
   model   vdw
   3.018 2.616
nonbonded pdb=" CB  LEU A  32 "
          pdb=" N   CYS A  33 "
   model   vdw
   3.018 2.816
nonbonded pdb=" O   LEU A  76 "
          pdb=" CB  LEU A  76 "
   model   vdw
   3.019 2.752
nonbonded pdb=" O   LYS A  46 "
          pdb=" CB  LYS A  46 "
   model   vdw
   3.023 2.752
nonbonded pdb=" O   ARG A  80 "
          pdb=" CB  ARG A  80 "
   model   vdw
   3.024 2.752
nonbonded pdb=" O   HIS A  64 "
          pdb=" C   LEU A  65 "
   model   vdw
   3.027 3.270
nonbonded pdb=" N   THR A  14 "
          pdb=" O   GLU A  30 "
   model   vdw
   3.027 3.120
nonbonded pdb=" OE2 GLU A   5 "
          pdb=" NZ  LYS A   7 "
   model   vdw
   3.028 3.120
nonbonded pdb=" CA  LEU A  65 "
          pdb=" CD1 LEU A  65 "
   model   vdw
   3.028 3.112
nonbonded pdb=" N   THR A  48 "
          pdb=" O   THR A  48 "
   model   vdw
   3.030 2.496
nonbonded pdb=" N   TYR A  26 "
          pdb="O    HOH S  37 "
   model   vdw
   3.033 3.120
nonbonded pdb=" N   TYR A  61 "
          pdb=" CG  TYR A  61 "
   model   vdw
   3.034 2.672
nonbonded pdb=" N   THR A  14 "
          pdb=" CG2 THR A  14 "
   model   vdw
   3.035 2.832
nonbonded pdb=" CB  GLN A  12 "
          pdb=" N   PHE A  13 "
   model   vdw
   3.036 2.816
nonbonded pdb=" C   VAL A  70 "
          pdb=" O   GLY A  71 "
   model   vdw
   3.036 3.270
nonbonded pdb=" C   ARG A  16 "
          pdb=" CG  ARG A  16 "
   model   vdw
   3.037 2.936
nonbonded pdb=" CA  LEU A  60 "
          pdb=" CD2 LEU A  60 "
   model   vdw
   3.037 3.112
nonbonded pdb=" N   SER A  17 "
          pdb=" OG  SER A  17 "
   model   vdw
   3.037 2.496
nonbonded pdb=" C   ARG A  80 "
          pdb=" C   LEU A  81 "
   model   vdw
   3.043 2.800
nonbonded pdb=" N   LEU A  83 "
          pdb=" CG  LEU A  83 "
   model   vdw
   3.043 2.840
nonbonded pdb=" O   TYR A  41 "
          pdb=" C   PRO A  42 "
   model   vdw
   3.045 3.270
nonbonded pdb=" O   VAL A   4 "
          pdb=" O   TYR A  61 "
   model   vdw
   3.045 3.040
nonbonded pdb=" CB  THR A  62 "
          pdb=" N   VAL A  63 "
   model   vdw
   3.045 2.840
nonbonded pdb=" OE2 GLU A  40 "
          pdb=" CB  SER A   9 "
   model   vdw sym.op.
   3.046 3.440 -x+1,y,-z+1
nonbonded pdb=" CB  SER A   9 "
          pdb=" OE2 GLU A  40 "
   model   vdw sym.op.
   3.046 3.440 -x+1,y,-z+1
nonbonded pdb=" O   GLU A   5 "
          pdb=" CB  GLU A   5 "
   model   vdw
   3.046 2.752
nonbonded pdb=" O   SER A   9 "
          pdb="O    HOH S  23 "
   model   vdw
   3.046 3.040
nonbonded pdb=" N   MSE A  77 "
          pdb=" CG  MSE A  77 "
   model   vdw
   3.047 2.816
nonbonded pdb=" CB  LYS A  69 "
          pdb=" N   VAL A  70 "
   model   vdw
   3.047 2.816
nonbonded pdb=" O   VAL A  35 "
          pdb=" N   VAL A  43 "
   model   vdw
   3.048 3.120
nonbonded pdb=" N   ILE A  78 "
          pdb=" CG1 ILE A  78 "
   model   vdw
   3.049 2.816
nonbonded pdb=" N   LEU A  81 "
          pdb=" O   LEU A  81 "
   model   vdw
   3.050 2.496
nonbonded pdb=" O   TYR A  56 "
          pdb=" CB  TYR A  56 "
   model   vdw
   3.052 2.752
nonbonded pdb=" O   THR A  62 "
          pdb=" N   VAL A  84 "
   model   vdw
   3.052 3.120
nonbonded pdb=" CB  THR A  14 "
          pdb=" N   THR A  15 "
   model   vdw
   3.052 2.840
nonbonded pdb=" C   VAL A  84 "
          pdb=" O   PRO A  85 "
   model   vdw
   3.054 3.270
nonbonded pdb=" NH1 ARG A  16 "
          pdb=" O   LEU A  60 "
   model   vdw sym.op.
   3.054 3.120 x,y-1,z
nonbonded pdb=" O   LYS A  69 "
          pdb=" N   MSE A  77 "
   model   vdw
   3.054 3.120
nonbonded pdb=" O   ILE A   6 "
          pdb="O    HOH S  12 "
   model   vdw
   3.054 3.040
nonbonded pdb=" CB  PHE A  13 "
          pdb=" N   THR A  14 "
   model   vdw
   3.054 2.816
nonbonded pdb=" OH  TYR A  34 "
          pdb="O    HOH S  26 "
   model   vdw
   3.055 3.040
nonbonded pdb=" C   VAL A  43 "
          pdb=" C   LEU A  44 "
   model   vdw
   3.055 2.800
nonbonded pdb=" C   CYS A  33 "
          pdb=" SG  CYS A  33 "
   model   vdw
   3.056 2.904
nonbonded pdb=" O   PRO A  85 "
          pdb=" CB  PRO A  85 "
   model   vdw
   3.059 2.752
nonbonded pdb=" O   ARG A  80 "
          pdb=" N   ARG A  82 "
   model   vdw
   3.060 3.120
nonbonded pdb=" N   PHE A  68 "
          pdb=" CD1 PHE A  68 "
   model   vdw
   3.060 3.420
nonbonded pdb=" N   VAL A  84 "
          pdb=" CG1 VAL A  84 "
   model   vdw
   3.062 2.832
nonbonded pdb=" C   TYR A  41 "
          pdb=" C   PRO A  42 "
   model   vdw
   3.062 2.800
nonbonded pdb=" O   LEU A  65 "
          pdb=" N   SER A  67 "
   model   vdw
   3.062 3.120
nonbonded pdb=" C   LEU A  65 "
          pdb=" C   SER A  66 "
   model   vdw
   3.064 2.800
nonbonded pdb=" N   LEU A  49 "
          pdb=" CG  LEU A  49 "
   model   vdw
   3.064 2.840
nonbonded pdb=" O   LEU A  65 "
          pdb=" C   SER A  66 "
   model   vdw
   3.064 3.270
nonbonded pdb=" N   ARG A  16 "
          pdb=" CG  ARG A  16 "
   model   vdw
   3.066 2.816
nonbonded pdb=" O   TYR A  34 "
          pdb=" CB  TYR A  34 "
   model   vdw
   3.066 2.752
nonbonded pdb=" O   ILE A  78 "
          pdb=" CB  ILE A  78 "
   model   vdw
   3.067 2.776
nonbonded pdb=" N   ASP A  36 "
          pdb=" O   ASP A  36 "
   model   vdw
   3.069 2.496
nonbonded pdb=" C   TYR A  26 "
          pdb=" CD1 TYR A  26 "
   model   vdw
   3.070 3.570
nonbonded pdb=" C   LYS A  46 "
          pdb=" CG  LYS A  46 "
   model   vdw
   3.073 2.936
nonbonded pdb=" O   LYS A   3 "
          pdb=" CB  LYS A   3 "
   model   vdw
   3.074 2.752
nonbonded pdb=" N   VAL A   4 "
          pdb=" O   TYR A  61 "
   model   vdw
   3.076 3.120
nonbonded pdb=" O   HIS A  64 "
          pdb=" CB  SER A  67 "
   model   vdw
   3.076 3.440
nonbonded pdb=" N   PHE A  73 "
          pdb=" CG  PHE A  73 "
   model   vdw
   3.078 2.672
nonbonded pdb=" C   HIS A  64 "
          pdb=" CG  HIS A  64 "
   model   vdw
   3.078 2.792
nonbonded pdb=" C   TYR A  56 "
          pdb=" C   ALA A  57 "
   model   vdw
   3.078 2.800
nonbonded pdb=" C   LEU A  32 "
          pdb=" CB  CYS A  33 "
   model   vdw
   3.079 2.936
nonbonded pdb=" CA  LEU A  83 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   3.079 3.112
nonbonded pdb=" O   GLU A  30 "
          pdb=" CB  GLU A  30 "
   model   vdw
   3.080 2.752
nonbonded pdb=" C   ASP A  36 "
          pdb=" CG  ASP A  36 "
   model   vdw
   3.082 2.800
nonbonded pdb=" N   GLU A   5 "
          pdb=" O   TYR A  34 "
   model   vdw
   3.082 3.120
nonbonded pdb=" C   LEU A  49 "
          pdb=" C   ASP A  50 "
   model   vdw
   3.082 2.800
nonbonded pdb=" N   PHE A  13 "
          pdb=" CG  PHE A  13 "
   model   vdw
   3.084 2.672
nonbonded pdb=" C   THR A  48 "
          pdb=" O   LEU A  49 "
   model   vdw
   3.086 3.270
nonbonded pdb=" C   GLN A  72 "
          pdb=" CG  GLN A  72 "
   model   vdw
   3.087 2.936
nonbonded pdb=" N   TYR A  41 "
          pdb=" CG  TYR A  41 "
   model   vdw
   3.088 2.672
nonbonded pdb=" N   TYR A  56 "
          pdb=" CG  TYR A  56 "
   model   vdw
   3.089 2.672
nonbonded pdb=" N   CYS A  33 "
          pdb=" O   VAL A  45 "
   model   vdw
   3.092 3.120
nonbonded pdb=" N   TYR A  34 "
          pdb=" CG  TYR A  34 "
   model   vdw
   3.094 2.672
nonbonded pdb=" C   LYS A  69 "
          pdb=" CG  LYS A  69 "
   model   vdw
   3.095 2.936
nonbonded pdb=" O   LEU A  28 "
          pdb=" CB  LEU A  28 "
   model   vdw
   3.095 2.752
nonbonded pdb=" N   VAL A  43 "
          pdb=" CG1 VAL A  43 "
   model   vdw
   3.097 2.832
nonbonded pdb=" O   ILE A   2 "
          pdb=" CG2 ILE A   2 "
   model   vdw
   3.101 3.460
nonbonded pdb=" N   ARG A  82 "
          pdb=" CG  ARG A  82 "
   model   vdw
   3.103 2.816
nonbonded pdb=" O   GLU A  51 "
          pdb=" CB  GLU A  51 "
   model   vdw
   3.103 2.752
nonbonded pdb=" O   LYS A  46 "
          pdb="O    HOH S  38 "
   model   vdw
   3.106 3.040
nonbonded pdb=" CA  LEU A  81 "
          pdb=" CD1 LEU A  81 "
   model   vdw
   3.107 3.112
nonbonded pdb=" C   HIS A  64 "
          pdb=" C   LEU A  65 "
   model   vdw
   3.108 2.800
nonbonded pdb=" N   ASP A  50 "
          pdb=" CG  ASP A  50 "
   model   vdw
   3.108 2.680
nonbonded pdb=" O   ASN A  29 "
          pdb=" CB  ASN A  29 "
   model   vdw
   3.109 2.752
nonbonded pdb=" O   HIS A  64 "
          pdb=" N   SER A  67 "
   model   vdw
   3.110 3.120
nonbonded pdb=" C   THR A  62 "
          pdb=" OG1 THR A  62 "
   model   vdw
   3.110 2.616
nonbonded pdb=" CB  ALA A  57 "
          pdb=" N   PRO A  58 "
   model   vdw
   3.112 2.832
nonbonded pdb=" O   THR A  15 "
          pdb=" CB  THR A  15 "
   model   vdw
   3.112 2.776
nonbonded pdb=" C   SER A  66 "
          pdb=" C   SER A  67 "
   model   vdw
   3.112 2.800
nonbonded pdb=" CB  GLU A  40 "
          pdb=" N   TYR A  41 "
   model   vdw
   3.113 2.816
nonbonded pdb=" O   THR A  48 "
          pdb=" O   LEU A  49 "
   model   vdw
   3.114 3.040
nonbonded pdb=" O   ASP A  50 "
          pdb=" C   GLU A  51 "
   model   vdw
   3.114 3.270
nonbonded pdb=" C   GLY A  71 "
          pdb=" N   PHE A  73 "
   model   vdw
   3.116 3.350
nonbonded pdb=" C   GLU A  51 "
          pdb=" N   GLN A  53 "
   model   vdw
   3.119 3.350
nonbonded pdb=" N   GLN A  12 "
          pdb=" CG  GLN A  12 "
   model   vdw
   3.119 2.816
nonbonded pdb=" O   PRO A  58 "
          pdb=" CB  PRO A  58 "
   model   vdw
   3.119 2.752
nonbonded pdb=" CB  LEU A  49 "
          pdb=" N   ASP A  50 "
   model   vdw
   3.120 2.816
nonbonded pdb=" N   GLN A  12 "
          pdb=" NE2 GLN A  12 "
   model   vdw
   3.121 3.200
nonbonded pdb=" OE1 GLN A  31 "
          pdb=" N   TYR A  56 "
   model   vdw
   3.121 3.120
nonbonded pdb=" O   ARG A  82 "
          pdb=" CB  ARG A  82 "
   model   vdw
   3.122 2.752
nonbonded pdb=" N   ASN A  29 "
          pdb=" OD1 ASN A  29 "
   model   vdw
   3.122 3.120
nonbonded pdb=" O   VAL A  70 "
          pdb=" C   GLY A  71 "
   model   vdw
   3.122 3.270
nonbonded pdb=" O   VAL A  43 "
          pdb=" C   LEU A  44 "
   model   vdw
   3.122 3.270
nonbonded pdb=" O   LEU A  65 "
          pdb=" CB  LEU A  65 "
   model   vdw
   3.123 2.752
nonbonded pdb=" CE  LYS A   3 "
          pdb=" O   GLN A  72 "
   model   vdw sym.op.
   3.124 3.440 -x+1,y+1,-z+2
nonbonded pdb=" CB  ARG A  16 "
          pdb=" NE  ARG A  16 "
   model   vdw
   3.125 2.816
nonbonded pdb=" O   LEU A  60 "
          pdb=" CB  LEU A  60 "
   model   vdw
   3.126 2.752
nonbonded pdb=" O   VAL A  63 "
          pdb=" CB  VAL A  63 "
   model   vdw
   3.126 2.776
nonbonded pdb=" C   ASP A  50 "
          pdb=" C   GLU A  51 "
   model   vdw
   3.126 2.800
nonbonded pdb=" CG1 VAL A  45 "
          pdb=" N   LYS A  46 "
   model   vdw
   3.126 3.540
nonbonded pdb=" C   VAL A  70 "
          pdb=" C   GLY A  71 "
   model   vdw
   3.128 2.800
nonbonded pdb=" O   PHE A  68 "
          pdb=" CB  PHE A  68 "
   model   vdw
   3.130 2.752
nonbonded pdb=" CB  GLN A  53 "
          pdb=" NE2 GLN A  53 "
   model   vdw
   3.131 2.816
nonbonded pdb=" NE2 GLN A  53 "
          pdb="O    HOH S  39 "
   model   vdw
   3.133 3.120
nonbonded pdb=" N   LEU A  37 "
          pdb=" CG  LEU A  37 "
   model   vdw
   3.134 2.840
nonbonded pdb=" CG2 ILE A  47 "
          pdb=" N   THR A  48 "
   model   vdw
   3.137 3.540
nonbonded pdb=" O   TYR A  56 "
          pdb=" C   ALA A  57 "
   model   vdw
   3.139 3.270
nonbonded pdb=" N   THR A  62 "
          pdb=" CG2 THR A  62 "
   model   vdw
   3.139 2.832
nonbonded pdb=" OH  TYR A  26 "
          pdb=" CG  PRO A  85 "
   model   vdw sym.op.
   3.140 3.440 x,y-1,z
nonbonded pdb=" O   ALA A  57 "
          pdb=" O   PRO A  58 "
   model   vdw
   3.140 3.040
nonbonded pdb=" O   SER A  75 "
          pdb=" OG  SER A  75 "
   model   vdw
   3.141 3.040
nonbonded pdb=" C   VAL A  43 "
          pdb=" CG2 VAL A  43 "
   model   vdw
   3.141 2.952
nonbonded pdb=" C   GLN A  53 "
          pdb=" C   PRO A  54 "
   model   vdw
   3.141 2.800
nonbonded pdb=" N   ILE A  47 "
          pdb=" CG1 ILE A  47 "
   model   vdw
   3.141 2.816
nonbonded pdb=" O   VAL A  84 "
          pdb=" O   PRO A  85 "
   model   vdw
   3.141 3.040
nonbonded pdb=" CB  SER A  75 "
          pdb=" N   LEU A  76 "
   model   vdw
   3.142 2.816
nonbonded pdb=" N   GLN A  12 "
          pdb=" CD  GLN A  12 "
   model   vdw
   3.143 3.350
nonbonded pdb=" CA  LEU A  49 "
          pdb=" CD2 LEU A  49 "
   model   vdw
   3.144 3.112
nonbonded pdb=" C   SER A  75 "
          pdb=" C   LEU A  76 "
   model   vdw
   3.148 2.800
nonbonded pdb=" CG  GLU A   5 "
          pdb=" N   ILE A   6 "
   model   vdw
   3.149 3.520
nonbonded pdb=" CB  PRO A  54 "
          pdb=" N   ALA A  55 "
   model   vdw
   3.150 2.816
nonbonded pdb=" C   GLN A  53 "
          pdb=" O   PRO A  54 "
   model   vdw
   3.150 3.270
nonbonded pdb=" C   SER A  66 "
          pdb=" N   PHE A  68 "
   model   vdw
   3.153 3.350
nonbonded pdb=" O   SER A  67 "
          pdb=" CB  SER A  67 "
   model   vdw
   3.154 2.752
nonbonded pdb=" N   ARG A  16 "
          pdb=" O   LEU A  28 "
   model   vdw
   3.156 3.120
nonbonded pdb=" O   SER A  66 "
          pdb=" C   SER A  67 "
   model   vdw
   3.158 3.270
nonbonded pdb=" CB  TYR A  41 "
          pdb=" N   PRO A  42 "
   model   vdw
   3.159 2.816
nonbonded pdb=" C   LEU A  49 "
          pdb=" O   ASP A  50 "
   model   vdw
   3.159 3.270
nonbonded pdb=" O   LEU A  32 "
          pdb=" CB  CYS A  33 "
   model   vdw
   3.161 3.440
nonbonded pdb=" O   SER A  27 "
          pdb=" CB  SER A  27 "
   model   vdw
   3.162 2.752
nonbonded pdb=" N   ASN A  39 "
          pdb="O    HOH S   9 "
   model   vdw
   3.163 3.120
nonbonded pdb=" CB  GLN A  31 "
          pdb=" N   LEU A  32 "
   model   vdw
   3.166 2.816
nonbonded pdb=" ND1 HIS A  64 "
          pdb=" N   SER A  66 "
   model   vdw
   3.167 3.200
nonbonded pdb=" CA  LEU A  32 "
          pdb=" CD2 LEU A  32 "
   model   vdw
   3.167 3.112
nonbonded pdb=" O   PRO A  42 "
          pdb=" CB  PRO A  42 "
   model   vdw
   3.168 2.752
nonbonded pdb=" CB  VAL A  43 "
          pdb=" N   LEU A  44 "
   model   vdw
   3.168 2.840
nonbonded pdb=" O   GLY A  71 "
          pdb=" C   GLN A  72 "
   model   vdw
   3.170 3.270
nonbonded pdb=" O   ILE A  47 "
          pdb=" CB  ILE A  47 "
   model   vdw
   3.171 2.776
nonbonded pdb=" C   PRO A  54 "
          pdb=" CG  PRO A  54 "
   model   vdw
   3.172 2.936
nonbonded pdb=" C   GLY A  71 "
          pdb=" C   GLN A  72 "
   model   vdw
   3.173 2.800
nonbonded pdb=" CG  HIS A  64 "
          pdb=" N   LEU A  65 "
   model   vdw
   3.173 3.340
nonbonded pdb=" CB  TYR A  26 "
          pdb=" N   SER A  27 "
   model   vdw
   3.173 2.816
nonbonded pdb=" CG  GLN A  31 "
          pdb=" N   LEU A  32 "
   model   vdw
   3.177 3.520
nonbonded pdb=" C   GLN A  31 "
          pdb=" CG  GLN A  31 "
   model   vdw
   3.177 2.936
nonbonded pdb=" CA  SER A  67 "
          pdb=" O   ARG A  80 "
   model   vdw
   3.178 3.470
nonbonded pdb=" C   ILE A   6 "
          pdb=" C   LYS A   7 "
   model   vdw
   3.178 2.800
nonbonded pdb=" CB  LYS A  69 "
          pdb=" CE  LYS A  69 "
   model   vdw
   3.178 3.072
nonbonded pdb=" O   GLN A  53 "
          pdb=" CG  GLN A  53 "
   model   vdw
   3.179 3.440
nonbonded pdb=" O   TYR A  26 "
          pdb=" CG  TYR A  26 "
   model   vdw
   3.180 3.260
nonbonded pdb=" O   GLY A  71 "
          pdb=" N   PHE A  73 "
   model   vdw
   3.183 3.120
nonbonded pdb=" O   LEU A  65 "
          pdb=" N   PHE A  68 "
   model   vdw
   3.184 3.120
nonbonded pdb=" C   TYR A  41 "
          pdb=" O   PRO A  42 "
   model   vdw
   3.186 3.270
nonbonded pdb=" C   LEU A  76 "
          pdb=" CG  LEU A  76 "
   model   vdw
   3.186 2.960
nonbonded pdb=" CA  LEU A  76 "
          pdb=" CD1 LEU A  76 "
   model   vdw
   3.188 3.112
nonbonded pdb=" CB  LYS A   7 "
          pdb=" N   PRO A   8 "
   model   vdw
   3.188 2.816
nonbonded pdb=" CG2 ILE A  78 "
          pdb=" N   ASP A  79 "
   model   vdw
   3.188 3.540
nonbonded pdb=" CG2 ILE A  78 "
          pdb=" CD1 ILE A  78 "
   model   vdw
   3.191 3.104
nonbonded pdb=" C   ASN A  39 "
          pdb=" N   TYR A  41 "
   model   vdw
   3.192 3.350
nonbonded pdb=" C   ALA A  57 "
          pdb=" O   PRO A  58 "
   model   vdw
   3.193 3.270
nonbonded pdb=" C   GLU A  51 "
          pdb=" C   GLY A  52 "
   model   vdw
   3.193 2.800
nonbonded pdb=" O   ALA A  55 "
          pdb=" CB  ALA A  55 "
   model   vdw
   3.193 2.768
nonbonded pdb=" C   PHE A  13 "
          pdb=" CD1 PHE A  13 "
   model   vdw
   3.194 3.570
nonbonded pdb=" C   LEU A  44 "
          pdb=" CG  LEU A  44 "
   model   vdw
   3.197 2.960
nonbonded pdb=" CA  TYR A  34 "
          pdb=" O   VAL A  43 "
   model   vdw
   3.197 3.470
nonbonded pdb=" O   VAL A  84 "
          pdb=" CG2 VAL A  84 "
   model   vdw
   3.198 3.460
nonbonded pdb=" O   LEU A  83 "
          pdb=" CB  LEU A  83 "
   model   vdw
   3.198 2.752
nonbonded pdb=" C   LYS A  69 "
          pdb=" C   VAL A  70 "
   model   vdw
   3.198 2.800
nonbonded pdb=" O   THR A  48 "
          pdb=" CD  ARG A  80 "
   model   vdw
   3.198 3.440
nonbonded pdb=" O   VAL A   4 "
          pdb=" CB  VAL A   4 "
   model   vdw
   3.199 2.776
nonbonded pdb=" CB  HIS A  64 "
          pdb=" N   LEU A  65 "
   model   vdw
   3.199 2.816
nonbonded pdb=" N   ALA A  57 "
          pdb=" OH  TYR A  61 "
   model   vdw
   3.200 3.120
nonbonded pdb=" OD1 ASP A  36 "
          pdb=" N   LEU A  37 "
   model   vdw
   3.202 3.120
nonbonded pdb=" C   VAL A  35 "
          pdb=" C   ASP A  36 "
   model   vdw
   3.205 2.800
nonbonded pdb=" CA  GLY A  71 "
          pdb="O    HOH S   3 "
   model   vdw
   3.205 3.440
nonbonded pdb=" C   GLN A  10 "
          pdb=" N   GLN A  12 "
   model   vdw
   3.209 3.350
nonbonded pdb=" O   ASP A  36 "
          pdb=" CD2 LEU A  65 "
   model   vdw sym.op.
   3.210 3.460 -x+1,y,-z+2
nonbonded pdb=" C   HIS A  64 "
          pdb=" N   SER A  66 "
   model   vdw
   3.211 3.350
nonbonded pdb=" OH  TYR A  61 "
          pdb="O    HOH S   7 "
   model   vdw
   3.213 3.040
nonbonded pdb=" O   HIS A  64 "
          pdb=" N   SER A  66 "
   model   vdw
   3.214 3.120
nonbonded pdb=" CB  GLN A  12 "
          pdb=" OE1 GLN A  12 "
   model   vdw
   3.214 2.752
nonbonded pdb=" CB  GLU A   5 "
          pdb=" N   ILE A   6 "
   model   vdw
   3.215 2.816
nonbonded pdb=" CB  PRO A   8 "
          pdb=" N   SER A   9 "
   model   vdw
   3.216 2.816
nonbonded pdb=" N   VAL A  45 "
          pdb=" CG2 VAL A  45 "
   model   vdw
   3.216 2.832
nonbonded pdb=" O   HIS A  64 "
          pdb=" CB  HIS A  64 "
   model   vdw
   3.217 2.752
nonbonded pdb=" C   ILE A  78 "
          pdb=" C   ASP A  79 "
   model   vdw
   3.217 2.800
nonbonded pdb=" O   SER A  75 "
          pdb=" C   LEU A  76 "
   model   vdw
   3.218 3.270
nonbonded pdb=" O   GLN A  53 "
          pdb=" CB  GLN A  53 "
   model   vdw
   3.219 2.752
nonbonded pdb=" CB  LEU A  83 "
          pdb=" N   VAL A  84 "
   model   vdw
   3.219 2.816
nonbonded pdb=" CG1 VAL A  63 "
          pdb=" N   HIS A  64 "
   model   vdw
   3.220 3.540
nonbonded pdb=" N   ILE A   2 "
          pdb=" CG1 ILE A   2 "
   model   vdw
   3.222 2.816
nonbonded pdb=" OG  SER A   9 "
          pdb=" N   GLN A  10 "
   model   vdw
   3.223 3.120
nonbonded pdb=" O   GLN A  12 "
          pdb=" NE2 GLN A  12 "
   model   vdw
   3.226 3.120
nonbonded pdb=" O   ALA A  57 "
          pdb=" CB  ALA A  57 "
   model   vdw
   3.228 2.768
nonbonded pdb=" O   VAL A  45 "
          pdb=" CB  VAL A  45 "
   model   vdw
   3.228 2.776
nonbonded pdb=" C   VAL A  63 "
          pdb=" C   HIS A  64 "
   model   vdw
   3.229 2.800
nonbonded pdb=" O   SER A  27 "
          pdb=" OG  SER A  27 "
   model   vdw
   3.230 3.040
nonbonded pdb=" O   SER A  17 "
          pdb="O    HOH S   7 "
   model   vdw sym.op.
   3.230 3.040 x,y-1,z
nonbonded pdb=" O   VAL A  84 "
          pdb=" CB  VAL A  84 "
   model   vdw
   3.231 2.776
nonbonded pdb=" CA  LYS A   7 "
          pdb=" CD  LYS A   7 "
   model   vdw
   3.231 3.096
nonbonded pdb=" O   GLN A  10 "
          pdb=" N   GLN A  12 "
   model   vdw
   3.233 3.120
nonbonded pdb=" N   LEU A  60 "
          pdb=" CG  LEU A  60 "
   model   vdw
   3.233 2.840
nonbonded pdb=" O   VAL A  43 "
          pdb=" CB  VAL A  43 "
   model   vdw
   3.234 2.776
nonbonded pdb=" O   PRO A   8 "
          pdb=" CB  PRO A   8 "
   model   vdw
   3.234 2.752
nonbonded pdb=" O   TYR A  26 "
          pdb=" CD1 TYR A  26 "
   model   vdw
   3.235 3.340
nonbonded pdb=" O   GLN A  53 "
          pdb=" C   PRO A  54 "
   model   vdw
   3.236 3.270
nonbonded pdb=" CB  VAL A  84 "
          pdb=" N   PRO A  85 "
   model   vdw
   3.236 2.840
nonbonded pdb=" CA  GLU A  40 "
          pdb=" CD  GLU A  40 "
   model   vdw
   3.236 2.960
nonbonded pdb=" O   ILE A   6 "
          pdb=" CA  PRO A  58 "
   model   vdw
   3.237 3.470
nonbonded pdb=" O   LEU A  49 "
          pdb=" CB  LEU A  49 "
   model   vdw
   3.238 2.752
nonbonded pdb=" O   VAL A  35 "
          pdb=" CB  VAL A  35 "
   model   vdw
   3.239 2.776
nonbonded pdb=" C   ASP A  79 "
          pdb=" CB  ARG A  80 "
   model   vdw
   3.240 2.936
nonbonded pdb=" O   LEU A  49 "
          pdb=" C   ASP A  50 "
   model   vdw
   3.241 3.270
nonbonded pdb=" C   GLY A  71 "
          pdb="O    HOH S   3 "
   model   vdw
   3.241 3.270
nonbonded pdb=" O   GLN A  12 "
          pdb=" CG  GLN A  12 "
   model   vdw
   3.242 3.440
nonbonded pdb=" O   TYR A  26 "
          pdb=" CB  TYR A  26 "
   model   vdw
   3.242 2.752
nonbonded pdb=" C   PHE A  73 "
          pdb=" N   SER A  75 "
   model   vdw
   3.242 3.350
nonbonded pdb=" NE2 GLN A  10 "
          pdb=" CE1 TYR A  34 "
   model   vdw
   3.243 3.420
nonbonded pdb=" CB  SER A  67 "
          pdb=" O   ARG A  80 "
   model   vdw
   3.243 3.440
nonbonded pdb=" CB  ALA A  55 "
          pdb=" N   TYR A  56 "
   model   vdw
   3.243 2.832
nonbonded pdb=" O   ARG A  16 "
          pdb=" CG  ARG A  16 "
   model   vdw
   3.243 3.440
nonbonded pdb=" CG2 ILE A   2 "
          pdb=" N   LYS A   3 "
   model   vdw
   3.247 3.540
nonbonded pdb=" N   THR A  48 "
          pdb=" N   LEU A  49 "
   model   vdw
   3.249 2.560
nonbonded pdb=" C   TYR A  56 "
          pdb=" O   ALA A  57 "
   model   vdw
   3.251 3.270
nonbonded pdb=" C   MSE A  77 "
          pdb=" C   ILE A  78 "
   model   vdw
   3.253 2.800
nonbonded pdb=" O   SER A   9 "
          pdb=" NE2 GLN A  12 "
   model   vdw
   3.256 3.120
nonbonded pdb=" C   LEU A  65 "
          pdb=" CG  LEU A  65 "
   model   vdw
   3.257 2.960
nonbonded pdb=" C   ASP A  79 "
          pdb=" OD1 ASP A  79 "
   model   vdw
   3.258 3.270
nonbonded pdb=" C   TYR A  26 "
          pdb=" CB  SER A  27 "
   model   vdw
   3.260 2.936
nonbonded pdb=" CA  GLU A  51 "
          pdb=" CD  GLU A  51 "
   model   vdw
   3.262 2.960
nonbonded pdb=" C   GLN A  10 "
          pdb=" C   ALA A  11 "
   model   vdw
   3.263 2.800
nonbonded pdb=" O   THR A  48 "
          pdb=" CG2 THR A  48 "
   model   vdw
   3.263 3.460
nonbonded pdb=" C   ALA A  55 "
          pdb=" O   TYR A  56 "
   model   vdw
   3.264 3.270
nonbonded pdb=" C   PRO A  54 "
          pdb=" O   ALA A  55 "
   model   vdw
   3.265 3.270
nonbonded pdb=" CB  LYS A  46 "
          pdb=" N   ILE A  47 "
   model   vdw
   3.265 2.816
nonbonded pdb=" O   GLN A  12 "
          pdb=" CB  GLN A  12 "
   model   vdw
   3.267 2.752
nonbonded pdb=" CB  GLU A  30 "
          pdb=" N   GLN A  31 "
   model   vdw
   3.269 2.816
nonbonded pdb=" N   TYR A  61 "
          pdb=" CD1 TYR A  61 "
   model   vdw
   3.270 3.420
nonbonded pdb=" O   CYS A  33 "
          pdb=" CB  CYS A  33 "
   model   vdw
   3.271 2.752
nonbonded pdb=" O   TYR A  61 "
          pdb=" CB  TYR A  61 "
   model   vdw
   3.274 2.752
nonbonded pdb=" OD1 ASP A  36 "
          pdb=" N   GLY A  38 "
   model   vdw
   3.275 3.120
nonbonded pdb=" O   ILE A   6 "
          pdb=" C   LYS A   7 "
   model   vdw
   3.276 3.270
nonbonded pdb=" C   GLY A  52 "
          pdb=" C   GLN A  53 "
   model   vdw
   3.276 2.800
nonbonded pdb=" C   GLU A   5 "
          pdb=" C   ILE A   6 "
   model   vdw
   3.278 2.800
nonbonded pdb=" O   ALA A  57 "
          pdb=" CE1 TYR A  61 "
   model   vdw
   3.278 3.340
nonbonded pdb=" CA  PHE A  13 "
          pdb=" O   GLU A  30 "
   model   vdw
   3.278 3.470
nonbonded pdb=" CB  PHE A  68 "
          pdb=" N   LYS A  69 "
   model   vdw
   3.279 2.816
nonbonded pdb=" C   ARG A  16 "
          pdb=" CB  SER A  17 "
   model   vdw
   3.279 2.936
nonbonded pdb=" O   PRO A  54 "
          pdb=" CB  PRO A  54 "
   model   vdw
   3.279 2.752
nonbonded pdb=" O   GLN A  10 "
          pdb="O    HOH S   8 "
   model   vdw
   3.281 3.040
nonbonded pdb=" CA  GLN A  12 "
          pdb=" CD  GLN A  12 "
   model   vdw
   3.281 2.960
nonbonded pdb=" CB  TYR A  56 "
          pdb=" N   ALA A  57 "
   model   vdw
   3.281 2.816
nonbonded pdb=" C   GLY A  38 "
          pdb=" C   ASN A  39 "
   model   vdw
   3.282 2.800
nonbonded pdb=" CG1 VAL A   4 "
          pdb=" N   GLU A   5 "
   model   vdw
   3.283 3.540
nonbonded pdb=" CA  GLU A  30 "
          pdb=" O   ILE A  47 "
   model   vdw
   3.283 3.470
nonbonded pdb=" N   TYR A  34 "
          pdb=" CD1 TYR A  34 "
   model   vdw
   3.284 3.420
nonbonded pdb=" CA  THR A  15 "
          pdb=" O   LEU A  28 "
   model   vdw
   3.285 3.470
nonbonded pdb=" C   PHE A  73 "
          pdb=" C   GLY A  74 "
   model   vdw
   3.286 2.800
nonbonded pdb=" OH  TYR A  41 "
          pdb=" CG  PRO A  42 "
   model   vdw sym.op.
   3.288 3.440 -x+1,y,-z+1
nonbonded pdb=" CB  ILE A  47 "
          pdb=" N   THR A  48 "
   model   vdw
   3.289 2.840
nonbonded pdb=" O   ALA A  57 "
          pdb=" CZ  TYR A  61 "
   model   vdw
   3.290 3.260
nonbonded pdb=" O   SER A  75 "
          pdb=" CB  SER A  75 "
   model   vdw
   3.290 2.752
nonbonded pdb=" CB  PRO A  42 "
          pdb=" N   VAL A  43 "
   model   vdw
   3.291 2.816
nonbonded pdb=" OE2 GLU A  51 "
          pdb=" NH1 ARG A  80 "
   model   vdw
   3.291 3.120
nonbonded pdb=" C   LEU A  60 "
          pdb=" CB  TYR A  61 "
   model   vdw
   3.291 2.936
nonbonded pdb=" CB  GLN A  53 "
          pdb=" OE1 GLN A  53 "
   model   vdw
   3.292 2.752
nonbonded pdb=" O   ARG A  16 "
          pdb=" CB  ARG A  16 "
   model   vdw
   3.293 2.752
nonbonded pdb=" CB  LEU A  65 "
          pdb=" N   SER A  66 "
   model   vdw
   3.295 2.816
nonbonded pdb="O    HOH S  19 "
          pdb="O    HOH S  30 "
   model   vdw
   3.296 3.040
nonbonded pdb=" O   LYS A   7 "
          pdb=" CB  LYS A   7 "
   model   vdw
   3.297 2.752
nonbonded pdb=" N   ILE A   6 "
          pdb=" N   LYS A   7 "
   model   vdw
   3.299 2.560
nonbonded pdb=" O   THR A  14 "
          pdb=" CA  ASN A  29 "
   model   vdw
   3.302 3.470
nonbonded pdb=" C   THR A  62 "
          pdb=" C   VAL A  63 "
   model   vdw
   3.303 2.800
nonbonded pdb=" O   GLN A  10 "
          pdb=" C   ALA A  11 "
   model   vdw
   3.303 3.270
nonbonded pdb=" CA  GLU A   5 "
          pdb=" O   GLY A  59 "
   model   vdw
   3.304 3.470
nonbonded pdb=" C   THR A  14 "
          pdb=" OG1 THR A  15 "
   model   vdw
   3.304 3.270
nonbonded pdb=" CB  LYS A  46 "
          pdb=" CE  LYS A  46 "
   model   vdw
   3.307 3.072
nonbonded pdb=" CG2 THR A  15 "
          pdb=" N   ARG A  16 "
   model   vdw
   3.308 3.540
nonbonded pdb=" CB  LEU A  60 "
          pdb=" N   TYR A  61 "
   model   vdw
   3.309 2.816
nonbonded pdb=" O   ASN A  39 "
          pdb=" N   TYR A  41 "
   model   vdw
   3.309 3.120
nonbonded pdb=" CB  ALA A  57 "
          pdb="O    HOH S   7 "
   model   vdw
   3.310 3.460
nonbonded pdb=" C   GLY A  38 "
          pdb=" O   ASN A  39 "
   model   vdw
   3.311 3.270
nonbonded pdb=" O   GLU A  40 "
          pdb=" CB  GLU A  40 "
   model   vdw
   3.311 2.752
nonbonded pdb=" O   SER A   9 "
          pdb=" OG  SER A   9 "
   model   vdw
   3.313 3.040
nonbonded pdb=" O   LEU A  32 "
          pdb=" CB  LEU A  32 "
   model   vdw
   3.315 2.752
nonbonded pdb=" CG1 VAL A  45 "
          pdb="O    HOH S   6 "
   model   vdw sym.op.
   3.315 3.460 -x+1,y,-z+2
nonbonded pdb=" O   SER A   9 "
          pdb=" OE1 GLN A  12 "
   model   vdw
   3.316 3.040
nonbonded pdb=" CZ  TYR A  26 "
          pdb=" CG  PRO A  85 "
   model   vdw sym.op.
   3.316 3.660 x,y-1,z
nonbonded pdb=" C   PRO A   8 "
          pdb=" C   SER A   9 "
   model   vdw
   3.317 2.800
nonbonded pdb=" O   GLU A  51 "
          pdb=" C   GLY A  52 "
   model   vdw
   3.317 3.270
nonbonded pdb=" CA  PHE A  73 "
          pdb=" CD1 PHE A  73 "
   model   vdw
   3.320 3.016
nonbonded pdb=" CB  VAL A  45 "
          pdb=" N   LYS A  46 "
   model   vdw
   3.320 2.840
nonbonded pdb=" N   ASP A  79 "
          pdb=" O   ASP A  79 "
   model   vdw
   3.321 2.496
nonbonded pdb=" O   TYR A  41 "
          pdb=" CB  TYR A  41 "
   model   vdw
   3.321 2.752
nonbonded pdb=" O   SER A  66 "
          pdb=" N   PHE A  68 "
   model   vdw
   3.323 3.120
nonbonded pdb=" O   VAL A  35 "
          pdb=" C   ASP A  36 "
   model   vdw
   3.323 3.270
nonbonded pdb=" CB  LEU A  28 "
          pdb=" N   ASN A  29 "
   model   vdw
   3.324 2.816
nonbonded pdb=" OD2 ASP A  79 "
          pdb=" NH1 ARG A  82 "
   model   vdw
   3.325 3.120
nonbonded pdb=" C   GLY A  74 "
          pdb=" C   SER A  75 "
   model   vdw
   3.325 2.800
nonbonded pdb=" C   ILE A   6 "
          pdb=" O   LYS A   7 "
   model   vdw
   3.327 3.270
nonbonded pdb=" CA  TYR A  41 "
          pdb=" CD1 TYR A  41 "
   model   vdw
   3.329 3.016
nonbonded pdb=" OD1 ASP A  50 "
          pdb=" CD  ARG A  80 "
   model   vdw
   3.329 3.440
nonbonded pdb=" O   SER A  75 "
          pdb="O    HOH S   3 "
   model   vdw
   3.329 3.040
nonbonded pdb=" CA  TYR A  61 "
          pdb=" O   VAL A  84 "
   model   vdw
   3.331 3.470
nonbonded pdb=" N   ILE A   2 "
          pdb="O    HOH S  19 "
   model   vdw
   3.332 3.120
nonbonded pdb=" O   TYR A  41 "
          pdb=" O   PRO A  42 "
   model   vdw
   3.332 3.040
nonbonded pdb=" OD2 ASP A  79 "
          pdb=" NH2 ARG A  82 "
   model   vdw
   3.334 3.120
nonbonded pdb=" CB  SER A  75 "
          pdb="O    HOH S  38 "
   model   vdw sym.op.
   3.334 3.440 -x+1,y,-z+2
nonbonded pdb=" O   THR A  14 "
          pdb=" OG1 THR A  14 "
   model   vdw
   3.335 3.040
nonbonded pdb=" C   PRO A  42 "
          pdb=" C   VAL A  43 "
   model   vdw
   3.335 2.800
nonbonded pdb=" C   LEU A  28 "
          pdb=" C   ASN A  29 "
   model   vdw
   3.336 2.800
nonbonded pdb=" CB  SER A  66 "
          pdb=" N   SER A  67 "
   model   vdw
   3.336 2.816
nonbonded pdb=" OG  SER A  27 "
          pdb=" N   LEU A  28 "
   model   vdw
   3.337 3.120
nonbonded pdb=" C   LEU A  81 "
          pdb=" C   ARG A  82 "
   model   vdw
   3.338 2.800
nonbonded pdb=" O   GLN A  10 "
          pdb=" CG  GLN A  31 "
   model   vdw
   3.338 3.440
nonbonded pdb=" CB  TYR A  34 "
          pdb=" N   VAL A  35 "
   model   vdw
   3.339 2.816
nonbonded pdb=" CA  TYR A  34 "
          pdb=" CD1 TYR A  34 "
   model   vdw
   3.340 3.016
nonbonded pdb=" O   VAL A  43 "
          pdb=" CG2 VAL A  43 "
   model   vdw
   3.340 3.460
nonbonded pdb=" NE2 GLN A  10 "
          pdb=" N   CYS A  33 "
   model   vdw
   3.340 3.200
nonbonded pdb=" O   GLN A  31 "
          pdb=" CB  GLN A  31 "
   model   vdw
   3.340 2.752
nonbonded pdb=" OE1 GLU A  30 "
          pdb=" NZ  LYS A  46 "
   model   vdw
   3.341 3.120
nonbonded pdb=" CG1 VAL A  35 "
          pdb=" N   ASP A  36 "
   model   vdw
   3.341 3.540
nonbonded pdb=" CA  PHE A  13 "
          pdb=" CD1 PHE A  13 "
   model   vdw
   3.341 3.016
nonbonded pdb=" O   LEU A  44 "
          pdb=" CG2 VAL A  45 "
   model   vdw
   3.343 3.460
nonbonded pdb=" CA  TYR A  56 "
          pdb=" CD1 TYR A  56 "
   model   vdw
   3.343 3.016
nonbonded pdb=" C   LEU A  37 "
          pdb=" C   GLY A  38 "
   model   vdw
   3.343 2.800
nonbonded pdb=" CA  PHE A  68 "
          pdb=" CD1 PHE A  68 "
   model   vdw
   3.343 3.016
nonbonded pdb=" CB  VAL A   4 "
          pdb=" N   GLU A   5 "
   model   vdw
   3.343 2.840
nonbonded pdb=" O   LYS A  69 "
          pdb=" CD1 LEU A  76 "
   model   vdw
   3.345 3.460
nonbonded pdb=" C   GLU A  30 "
          pdb=" CB  GLN A  31 "
   model   vdw
   3.346 2.936
nonbonded pdb=" ND1 HIS A  64 "
          pdb=" N   LEU A  65 "
   model   vdw
   3.347 3.200
nonbonded pdb=" O   PHE A  73 "
          pdb=" N   SER A  75 "
   model   vdw
   3.348 3.120
nonbonded pdb=" CE1 PHE A  13 "
          pdb="O    HOH S  14 "
   model   vdw
   3.348 3.340
nonbonded pdb=" N   GLN A  72 "
          pdb="O    HOH S   3 "
   model   vdw
   3.348 3.120
nonbonded pdb=" O   LEU A  65 "
          pdb=" CG  LEU A  65 "
   model   vdw
   3.349 3.470
nonbonded pdb=" C   VAL A  45 "
          pdb=" C   LYS A  46 "
   model   vdw
   3.349 2.800
nonbonded pdb=" CD1 TYR A  56 "
          pdb="O    HOH S  39 "
   model   vdw
   3.349 3.340
nonbonded pdb=" CB  GLU A  51 "
          pdb=" N   GLY A  52 "
   model   vdw
   3.349 2.816
nonbonded pdb=" CB  ARG A  16 "
          pdb=" N   SER A  17 "
   model   vdw
   3.350 2.816
nonbonded pdb=" O   VAL A  63 "
          pdb=" C   HIS A  64 "
   model   vdw
   3.350 3.270
nonbonded pdb=" C   SER A   9 "
          pdb=" N   ALA A  11 "
   model   vdw
   3.351 3.350
nonbonded pdb=" O   THR A  14 "
          pdb=" CB  THR A  14 "
   model   vdw
   3.352 2.776
nonbonded pdb=" CB  ILE A  78 "
          pdb=" N   ASP A  79 "
   model   vdw
   3.352 2.840
nonbonded pdb=" CG  LYS A  46 "
          pdb=" N   ILE A  47 "
   model   vdw
   3.352 3.520
nonbonded pdb=" C   GLU A  40 "
          pdb=" CB  TYR A  41 "
   model   vdw
   3.352 2.936
nonbonded pdb=" N   VAL A  70 "
          pdb=" N   GLY A  71 "
   model   vdw
   3.353 2.560
nonbonded pdb=" CB  TYR A  61 "
          pdb=" O   VAL A  84 "
   model   vdw
   3.354 3.440
nonbonded pdb=" O   GLU A  51 "
          pdb=" N   GLN A  53 "
   model   vdw
   3.354 3.120
nonbonded pdb=" OD1 ASP A  50 "
          pdb=" NH2 ARG A  82 "
   model   vdw
   3.356 3.120
nonbonded pdb=" C   ILE A  47 "
          pdb=" C   THR A  48 "
   model   vdw
   3.356 2.800
nonbonded pdb=" CB  VAL A  63 "
          pdb=" N   HIS A  64 "
   model   vdw
   3.356 2.840
nonbonded pdb=" CA  SER A  17 "
          pdb=" O   TYR A  26 "
   model   vdw
   3.358 3.470
nonbonded pdb=" CB  LEU A  76 "
          pdb=" N   MSE A  77 "
   model   vdw
   3.359 2.816
nonbonded pdb=" C   TYR A  34 "
          pdb=" C   VAL A  35 "
   model   vdw
   3.359 2.800
nonbonded pdb=" O   LEU A  65 "
          pdb=" CD1 PHE A  68 "
   model   vdw
   3.360 3.340
nonbonded pdb=" CB  SER A   9 "
          pdb=" N   GLN A  10 "
   model   vdw
   3.360 2.816
nonbonded pdb=" CB  GLN A  12 "
          pdb=" NE2 GLN A  12 "
   model   vdw
   3.361 2.816
nonbonded pdb=" C   PHE A  68 "
          pdb=" CB  LYS A  69 "
   model   vdw
   3.361 2.936
nonbonded pdb=" ND1 HIS A  64 "
          pdb=" CB  SER A  66 "
   model   vdw
   3.361 3.520
nonbonded pdb=" C   PHE A  13 "
          pdb=" C   THR A  14 "
   model   vdw
   3.362 2.800
nonbonded pdb=" C   TYR A  61 "
          pdb=" CB  THR A  62 "
   model   vdw
   3.362 2.960
nonbonded pdb=" CB  LEU A  44 "
          pdb=" N   VAL A  45 "
   model   vdw
   3.362 2.816
nonbonded pdb=" O   VAL A  35 "
          pdb=" N   LEU A  37 "
   model   vdw
   3.363 3.120
nonbonded pdb=" O   PHE A  13 "
          pdb=" CB  PHE A  13 "
   model   vdw
   3.364 2.752
nonbonded pdb=" CB  THR A  15 "
          pdb=" N   ARG A  16 "
   model   vdw
   3.365 2.840
nonbonded pdb=" C   SER A   9 "
          pdb=" C   GLN A  10 "
   model   vdw
   3.366 2.800
nonbonded pdb=" CG2 THR A  62 "
          pdb=" N   VAL A  63 "
   model   vdw
   3.368 3.540
nonbonded pdb=" O   GLN A  53 "
          pdb=" O   PRO A  54 "
   model   vdw
   3.368 3.040
nonbonded pdb=" O   ASP A  50 "
          pdb=" N   GLN A  53 "
   model   vdw
   3.370 3.120
nonbonded pdb=" CZ  ARG A  16 "
          pdb=" O   LEU A  60 "
   model   vdw sym.op.
   3.370 3.270 x,y-1,z
nonbonded pdb=" CD  GLU A  30 "
          pdb=" NZ  LYS A  46 "
   model   vdw
   3.374 3.350
nonbonded pdb=" C   ALA A  57 "
          pdb=" OH  TYR A  61 "
   model   vdw
   3.375 3.270
nonbonded pdb=" C   THR A  15 "
          pdb=" C   ARG A  16 "
   model   vdw
   3.379 2.800
nonbonded pdb=" CB  PRO A  58 "
          pdb=" N   GLY A  59 "
   model   vdw
   3.379 2.816
nonbonded pdb=" N   ASP A  36 "
          pdb=" N   LEU A  37 "
   model   vdw
   3.380 2.560
nonbonded pdb=" O   ASN A  39 "
          pdb=" O   GLU A  40 "
   model   vdw
   3.381 3.040
nonbonded pdb=" C   LEU A  44 "
          pdb=" CB  VAL A  45 "
   model   vdw
   3.381 2.960
nonbonded pdb=" CA  TYR A  26 "
          pdb=" CD1 TYR A  26 "
   model   vdw
   3.382 3.016
nonbonded pdb=" N   PHE A  13 "
          pdb=" CD2 PHE A  13 "
   model   vdw
   3.382 3.420
nonbonded pdb=" CB  SER A  67 "
          pdb=" N   PHE A  68 "
   model   vdw
   3.384 2.816
nonbonded pdb=" O   ALA A  55 "
          pdb=" N   ALA A  57 "
   model   vdw
   3.385 3.120
nonbonded pdb=" C   PRO A   8 "
          pdb=" N   GLN A  10 "
   model   vdw
   3.385 3.350
nonbonded pdb=" CB  GLN A  53 "
          pdb=" N   PRO A  54 "
   model   vdw
   3.386 2.816
nonbonded pdb=" CE2 TYR A  34 "
          pdb="O    HOH S  26 "
   model   vdw
   3.387 3.340
nonbonded pdb=" C   THR A  14 "
          pdb=" CB  THR A  15 "
   model   vdw
   3.387 2.960
nonbonded pdb=" O   LEU A  28 "
          pdb=" OD1 ASN A  29 "
   model   vdw
   3.388 3.040
nonbonded pdb=" O   LEU A  83 "
          pdb=" CG1 VAL A  84 "
   model   vdw
   3.389 3.460
nonbonded pdb=" NE2 GLN A  53 "
          pdb=" OH  TYR A  56 "
   model   vdw
   3.389 3.120
nonbonded pdb=" CB  SER A  17 "
          pdb=" O   TYR A  26 "
   model   vdw
   3.390 3.440
nonbonded pdb=" O   ALA A  57 "
          pdb=" N   GLY A  59 "
   model   vdw
   3.391 3.120
nonbonded pdb=" C   VAL A   4 "
          pdb=" CB  GLU A   5 "
   model   vdw
   3.392 2.936
nonbonded pdb=" N   LEU A  81 "
          pdb=" N   ARG A  82 "
   model   vdw
   3.393 2.560
nonbonded pdb=" O   PHE A  73 "
          pdb=" C   GLY A  74 "
   model   vdw
   3.394 3.270
nonbonded pdb=" CA  PHE A  13 "
          pdb=" CD2 PHE A  13 "
   model   vdw
   3.396 3.016
nonbonded pdb=" C   ALA A  11 "
          pdb=" CB  GLN A  12 "
   model   vdw
   3.397 2.936
nonbonded pdb=" O   SER A  17 "
          pdb=" OH  TYR A  26 "
   model   vdw
   3.398 3.040
nonbonded pdb=" C   LEU A  60 "
          pdb=" CG  TYR A  61 "
   model   vdw
   3.398 3.490
nonbonded pdb=" O   GLU A  40 "
          pdb=" CG  TYR A  41 "
   model   vdw
   3.398 3.260
nonbonded pdb=" O   THR A  62 "
          pdb=" O   VAL A  84 "
   model   vdw
   3.399 3.040
nonbonded pdb=" CA  HIS A  64 "
          pdb=" CD2 HIS A  64 "
   model   vdw
   3.402 2.952
nonbonded pdb=" O   ILE A  47 "
          pdb=" CG2 ILE A  47 "
   model   vdw
   3.402 3.460
nonbonded pdb=" O   ASP A  79 "
          pdb=" CB  ASP A  79 "
   model   vdw
   3.402 2.752
nonbonded pdb=" O   LEU A  37 "
          pdb=" C   GLY A  38 "
   model   vdw
   3.404 3.270
nonbonded pdb=" CB  ILE A   2 "
          pdb=" N   LYS A   3 "
   model   vdw
   3.404 2.840
nonbonded pdb=" O   ASP A  50 "
          pdb=" CB  ASP A  50 "
   model   vdw
   3.404 2.752
nonbonded pdb=" CA  VAL A   4 "
          pdb=" O   TYR A  34 "
   model   vdw
   3.405 3.470
nonbonded pdb=" C   LEU A  28 "
          pdb=" OD1 ASN A  29 "
   model   vdw
   3.406 3.270
nonbonded pdb=" O   VAL A  70 "
          pdb=" CG1 VAL A  70 "
   model   vdw
   3.406 3.460
nonbonded pdb=" C   GLN A  31 "
          pdb=" C   LEU A  32 "
   model   vdw
   3.407 2.800
nonbonded pdb=" O   VAL A  35 "
          pdb=" CA  PRO A  42 "
   model   vdw
   3.407 3.470
nonbonded pdb=" OD1 ASN A  39 "
          pdb="O    HOH S   9 "
   model   vdw
   3.408 3.040
nonbonded pdb=" CA  TYR A  26 "
          pdb="O    HOH S  37 "
   model   vdw
   3.409 3.470
nonbonded pdb=" CB  PRO A   8 "
          pdb="O    HOH S  14 "
   model   vdw sym.op.
   3.409 3.440 -x+1/2,y+1/2,-z+1
nonbonded pdb=" N   ASN A  39 "
          pdb=" ND2 ASN A  39 "
   model   vdw
   3.410 3.200
nonbonded pdb=" C   LEU A  37 "
          pdb=" N   ASN A  39 "
   model   vdw
   3.413 3.350
nonbonded pdb=" O   VAL A  45 "
          pdb=" CG1 VAL A  45 "
   model   vdw
   3.413 3.460
nonbonded pdb=" CB  LYS A   3 "
          pdb=" N   VAL A   4 "
   model   vdw
   3.414 2.816
nonbonded pdb=" C   VAL A  43 "
          pdb=" O   LEU A  44 "
   model   vdw
   3.415 3.270
nonbonded pdb=" N   ARG A  80 "
          pdb=" CG  ARG A  80 "
   model   vdw
   3.415 2.816
nonbonded pdb=" N   LEU A  28 "
          pdb=" CG  LEU A  28 "
   model   vdw
   3.417 2.840
nonbonded pdb=" OE1 GLN A  10 "
          pdb=" CA  CYS A  33 "
   model   vdw
   3.417 3.470
nonbonded pdb=" N   TYR A  26 "
          pdb=" CG  TYR A  26 "
   model   vdw
   3.417 2.672
nonbonded pdb=" CE1 HIS A  64 "
          pdb=" OG  SER A  66 "
   model   vdw
   3.418 3.260
nonbonded pdb=" O   TYR A  26 "
          pdb=" CB  SER A  27 "
   model   vdw
   3.418 3.440
nonbonded pdb=" CG  LYS A   3 "
          pdb=" N   VAL A   4 "
   model   vdw
   3.420 3.520
nonbonded pdb=" O   ILE A  78 "
          pdb=" C   ASP A  79 "
   model   vdw
   3.420 3.270
nonbonded pdb=" CB  VAL A  35 "
          pdb=" N   ASP A  36 "
   model   vdw
   3.420 2.840
nonbonded pdb=" OG  SER A  66 "
          pdb=" N   SER A  67 "
   model   vdw
   3.421 3.120
nonbonded pdb=" C   SER A  27 "
          pdb=" CB  LEU A  28 "
   model   vdw
   3.421 2.936
nonbonded pdb=" O   LYS A  69 "
          pdb=" CB  LYS A  69 "
   model   vdw
   3.421 2.752
nonbonded pdb=" C   CYS A  33 "
          pdb=" C   TYR A  34 "
   model   vdw
   3.422 2.800
nonbonded pdb=" O   LYS A  69 "
          pdb=" C   VAL A  70 "
   model   vdw
   3.424 3.270
nonbonded pdb=" C   LYS A  46 "
          pdb=" C   ILE A  47 "
   model   vdw
   3.424 2.800
nonbonded pdb=" CA  TYR A  61 "
          pdb=" CD1 TYR A  61 "
   model   vdw
   3.425 3.016
nonbonded pdb=" O   CYS A  33 "
          pdb=" SG  CYS A  33 "
   model   vdw
   3.426 3.400
nonbonded pdb=" N   SER A  27 "
          pdb=" N   LEU A  28 "
   model   vdw
   3.428 2.560
nonbonded pdb=" O   GLY A  74 "
          pdb=" C   SER A  75 "
   model   vdw
   3.429 3.270
nonbonded pdb=" C   LEU A  76 "
          pdb=" CB  MSE A  77 "
   model   vdw
   3.429 2.936
nonbonded pdb=" C   GLY A  59 "
          pdb=" C   LEU A  60 "
   model   vdw
   3.430 2.800
nonbonded pdb=" CB  HIS A  64 "
          pdb=" O   ARG A  82 "
   model   vdw
   3.430 3.440
nonbonded pdb=" C   GLU A  40 "
          pdb=" CG  TYR A  41 "
   model   vdw
   3.430 3.490
nonbonded pdb=" O   ASP A  79 "
          pdb=" OD1 ASP A  79 "
   model   vdw
   3.431 3.040
nonbonded pdb=" N   GLU A  40 "
          pdb=" OE1 GLU A  40 "
   model   vdw
   3.431 3.120
nonbonded pdb=" O   ASP A  79 "
          pdb=" CB  ARG A  80 "
   model   vdw
   3.432 3.440
nonbonded pdb=" C   GLN A  12 "
          pdb=" C   PHE A  13 "
   model   vdw
   3.433 2.800
nonbonded pdb=" N   TYR A  56 "
          pdb=" N   ALA A  57 "
   model   vdw
   3.434 2.560
nonbonded pdb=" N   CYS A  33 "
          pdb=" SG  CYS A  33 "
   model   vdw
   3.435 2.784
nonbonded pdb=" C   ILE A   2 "
          pdb=" C   LYS A   3 "
   model   vdw
   3.435 2.800
nonbonded pdb=" CA  TYR A  34 "
          pdb=" CD2 TYR A  34 "
   model   vdw
   3.435 3.016
nonbonded pdb=" CB  PHE A  73 "
          pdb="O    HOH S   3 "
   model   vdw
   3.436 3.440
nonbonded pdb=" CB  SER A  27 "
          pdb=" N   LEU A  28 "
   model   vdw
   3.439 2.816
nonbonded pdb=" OG  SER A  66 "
          pdb=" CD  ARG A  82 "
   model   vdw
   3.439 3.440
nonbonded pdb=" CB  ARG A  82 "
          pdb=" N   LEU A  83 "
   model   vdw
   3.440 2.816
nonbonded pdb=" CG  GLU A   5 "
          pdb=" O   GLY A  59 "
   model   vdw
   3.440 3.440
nonbonded pdb=" C   ASP A  36 "
          pdb=" C   LEU A  37 "
   model   vdw
   3.441 2.800
nonbonded pdb=" N   VAL A   4 "
          pdb=" N   GLU A   5 "
   model   vdw
   3.441 2.560
nonbonded pdb=" CG  GLN A  53 "
          pdb=" O   PRO A  54 "
   model   vdw
   3.441 3.440
nonbonded pdb=" O   HIS A  64 "
          pdb=" CE1 PHE A  68 "
   model   vdw
   3.441 3.340
nonbonded pdb=" CB  ASN A  29 "
          pdb=" N   GLU A  30 "
   model   vdw
   3.442 2.816
nonbonded pdb=" CB  ALA A  57 "
          pdb=" CD  PRO A  58 "
   model   vdw
   3.442 3.860
nonbonded pdb=" O   GLN A  31 "
          pdb=" O   ILE A  47 "
   model   vdw
   3.442 3.040
nonbonded pdb=" C   GLN A  72 "
          pdb=" C   PHE A  73 "
   model   vdw
   3.442 2.800
nonbonded pdb=" O   THR A  62 "
          pdb=" C   VAL A  63 "
   model   vdw
   3.443 3.270
nonbonded pdb=" CB  ASP A  36 "
          pdb="O    HOH S   5 "
   model   vdw
   3.443 3.440
nonbonded pdb=" O   ILE A  78 "
          pdb=" CG2 ILE A  78 "
   model   vdw
   3.444 3.460
nonbonded pdb=" N   ARG A  80 "
          pdb=" N   LEU A  81 "
   model   vdw
   3.444 2.560
nonbonded pdb=" O   PRO A   8 "
          pdb=" CA  THR A  14 "
   model   vdw sym.op.
   3.444 3.470 -x+1/2,y+1/2,-z+1
nonbonded pdb=" C   LEU A  60 "
          pdb=" CD1 TYR A  61 "
   model   vdw
   3.445 3.570
nonbonded pdb=" O   VAL A  43 "
          pdb=" N   VAL A  45 "
   model   vdw
   3.445 3.120
nonbonded pdb=" CG2 THR A  15 "
          pdb=" OG  SER A  27 "
   model   vdw
   3.445 3.460
nonbonded pdb=" CA  SER A  75 "
          pdb="O    HOH S   6 "
   model   vdw
   3.445 3.470
nonbonded pdb=" CB  LYS A   7 "
          pdb=" CD  PRO A   8 "
   model   vdw
   3.445 3.840
nonbonded pdb=" C   ASN A  29 "
          pdb=" CB  GLU A  30 "
   model   vdw
   3.446 2.936
nonbonded pdb=" N   THR A  15 "
          pdb=" N   ARG A  16 "
   model   vdw
   3.447 2.560
nonbonded pdb=" CB  ARG A  80 "
          pdb=" N   LEU A  81 "
   model   vdw
   3.447 2.816
nonbonded pdb=" CG  GLN A  31 "
          pdb="O    HOH S   8 "
   model   vdw
   3.448 3.440
nonbonded pdb=" C   LEU A  83 "
          pdb=" CB  VAL A  84 "
   model   vdw
   3.449 2.960
nonbonded pdb=" N   ARG A  82 "
          pdb=" N   LEU A  83 "
   model   vdw
   3.449 2.560
nonbonded pdb=" O   PRO A  54 "
          pdb=" CG  PRO A  54 "
   model   vdw
   3.449 3.440
nonbonded pdb=" O   GLY A  38 "
          pdb=" C   ASN A  39 "
   model   vdw
   3.449 3.270
nonbonded pdb=" O   PHE A  13 "
          pdb=" CG  PHE A  13 "
   model   vdw
   3.450 3.260
nonbonded pdb=" O   THR A  14 "
          pdb=" OG1 THR A  15 "
   model   vdw
   3.450 3.040
nonbonded pdb=" C   ARG A  82 "
          pdb=" C   LEU A  83 "
   model   vdw
   3.452 2.800
nonbonded pdb=" N   PHE A  73 "
          pdb=" CD2 PHE A  73 "
   model   vdw
   3.454 3.420
nonbonded pdb=" C   ALA A  11 "
          pdb=" C   GLN A  12 "
   model   vdw
   3.455 2.800
nonbonded pdb=" C   PRO A  54 "
          pdb=" CD  PRO A  54 "
   model   vdw
   3.456 2.936
nonbonded pdb=" O   MSE A  77 "
          pdb=" C   ILE A  78 "
   model   vdw
   3.456 3.270
nonbonded pdb=" CG  ASP A  79 "
          pdb=" N   ARG A  80 "
   model   vdw
   3.456 3.350
nonbonded pdb=" C   LEU A  81 "
          pdb=" CG  LEU A  81 "
   model   vdw
   3.457 2.960
nonbonded pdb=" C   SER A   9 "
          pdb=" CB  GLN A  10 "
   model   vdw
   3.458 2.936
nonbonded pdb=" CB  ASN A  39 "
          pdb="O    HOH S   9 "
   model   vdw
   3.458 3.440
nonbonded pdb=" CB  LYS A   3 "
          pdb="O    HOH S   5 "
   model   vdw
   3.458 3.440
nonbonded pdb=" O   PRO A  54 "
          pdb=" O   ALA A  55 "
   model   vdw
   3.459 3.040
nonbonded pdb=" CB  VAL A  84 "
          pdb=" CD  PRO A  85 "
   model   vdw
   3.461 3.870
nonbonded pdb=" CA  PHE A  68 "
          pdb=" CD2 PHE A  68 "
   model   vdw
   3.461 3.016
nonbonded pdb=" C   VAL A  63 "
          pdb=" O   HIS A  64 "
   model   vdw
   3.461 3.270
nonbonded pdb=" O   GLY A  52 "
          pdb=" C   GLN A  53 "
   model   vdw
   3.461 3.270
nonbonded pdb=" C   ASP A  36 "
          pdb=" N   GLY A  38 "
   model   vdw
   3.461 3.350
nonbonded pdb=" CB  TYR A  41 "
          pdb=" CD  PRO A  42 "
   model   vdw
   3.462 3.840
nonbonded pdb=" C   PHE A  13 "
          pdb=" CB  THR A  14 "
   model   vdw
   3.463 2.960
nonbonded pdb=" CD1 TYR A  26 "
          pdb=" N   SER A  27 "
   model   vdw
   3.464 3.420
nonbonded pdb=" O   PRO A   8 "
          pdb=" C   SER A   9 "
   model   vdw
   3.464 3.270
nonbonded pdb=" CA  PHE A  73 "
          pdb=" CD2 PHE A  73 "
   model   vdw
   3.467 3.016
nonbonded pdb=" N   ARG A  16 "
          pdb="O    HOH S  11 "
   model   vdw
   3.468 3.120
nonbonded pdb=" O   LYS A   7 "
          pdb=" CA  GLN A  10 "
   model   vdw
   3.468 3.470
nonbonded pdb=" C   LYS A   3 "
          pdb=" CB  VAL A   4 "
   model   vdw
   3.469 2.960
nonbonded pdb=" C   THR A  14 "
          pdb=" C   THR A  15 "
   model   vdw
   3.470 2.800
nonbonded pdb=" O   ASP A  79 "
          pdb=" CG  ARG A  80 "
   model   vdw
   3.470 3.440
nonbonded pdb=" O   GLN A  12 "
          pdb=" CG  GLN A  31 "
   model   vdw
   3.470 3.440
nonbonded pdb=" O   TYR A  56 "
          pdb=" O   ALA A  57 "
   model   vdw
   3.471 3.040
nonbonded pdb=" CB  ILE A   6 "
          pdb=" N   LYS A   7 "
   model   vdw
   3.471 2.840
nonbonded pdb=" C   GLN A  12 "
          pdb=" CB  PHE A  13 "
   model   vdw
   3.472 2.936
nonbonded pdb=" O   THR A  62 "
          pdb=" CA  LEU A  83 "
   model   vdw
   3.472 3.470
nonbonded pdb=" C   LYS A   3 "
          pdb=" CG2 VAL A   4 "
   model   vdw
   3.472 3.690
nonbonded pdb=" C   SER A  27 "
          pdb=" C   LEU A  28 "
   model   vdw
   3.472 2.800
nonbonded pdb=" C   GLN A  10 "
          pdb=" NE2 GLN A  12 "
   model   vdw
   3.473 3.350
nonbonded pdb=" CA  LYS A  69 "
          pdb="O    HOH S  10 "
   model   vdw
   3.473 3.470
nonbonded pdb=" N   GLU A  40 "
          pdb=" O   GLU A  40 "
   model   vdw
   3.473 2.496
nonbonded pdb=" N   ASN A  29 "
          pdb=" N   GLU A  30 "
   model   vdw
   3.475 2.560
nonbonded pdb=" CG2 ILE A   2 "
          pdb=" CG2 VAL A  63 "
   model   vdw
   3.476 3.880
nonbonded pdb=" O   SER A  27 "
          pdb=" CD1 LEU A  28 "
   model   vdw
   3.476 3.460
nonbonded pdb=" O   CYS A  33 "
          pdb=" O   VAL A  45 "
   model   vdw
   3.476 3.040
nonbonded pdb=" CG2 VAL A  70 "
          pdb="O    HOH S  10 "
   model   vdw
   3.477 3.460
nonbonded pdb=" C   CYS A  33 "
          pdb=" CB  TYR A  34 "
   model   vdw
   3.477 2.936
nonbonded pdb=" O   GLY A  71 "
          pdb=" N   GLY A  74 "
   model   vdw
   3.477 3.120
nonbonded pdb=" O   SER A  17 "
          pdb=" CB  SER A  17 "
   model   vdw
   3.477 2.752
nonbonded pdb=" O   PHE A  13 "
          pdb=" CD1 PHE A  13 "
   model   vdw
   3.479 3.340
nonbonded pdb=" CE1 TYR A  56 "
          pdb=" CB  LEU A  83 "
   model   vdw
   3.479 3.740
nonbonded pdb=" C   LEU A  76 "
          pdb=" C   MSE A  77 "
   model   vdw
   3.479 2.800
nonbonded pdb=" CB  PHE A  13 "
          pdb=" O   GLU A  30 "
   model   vdw
   3.480 3.440
nonbonded pdb=" N   SER A  75 "
          pdb="O    HOH S   3 "
   model   vdw
   3.481 3.120
nonbonded pdb=" O   LYS A   3 "
          pdb=" CA  VAL A  35 "
   model   vdw
   3.481 3.470
nonbonded pdb=" CA  HIS A  64 "
          pdb=" ND1 HIS A  64 "
   model   vdw
   3.482 2.840
nonbonded pdb=" CA  ASN A  39 "
          pdb=" OD1 ASN A  39 "
   model   vdw
   3.483 2.776
nonbonded pdb=" N   GLY A  38 "
          pdb="O    HOH S   9 "
   model   vdw
   3.483 3.120
nonbonded pdb=" O   ASP A  50 "
          pdb=" N   GLY A  52 "
   model   vdw
   3.483 3.120
nonbonded pdb=" O   SER A  67 "
          pdb=" CA  ILE A  78 "
   model   vdw
   3.484 3.470
nonbonded pdb=" O   ARG A  16 "
          pdb=" CB  SER A  17 "
   model   vdw
   3.484 3.440
nonbonded pdb=" C   LYS A   3 "
          pdb=" C   VAL A   4 "
   model   vdw
   3.484 2.800
nonbonded pdb=" CB  LYS A   3 "
          pdb=" CE  LYS A   3 "
   model   vdw
   3.484 3.072
nonbonded pdb=" CB  ALA A  11 "
          pdb=" N   GLN A  12 "
   model   vdw
   3.484 2.832
nonbonded pdb=" C   HIS A  64 "
          pdb=" ND1 HIS A  64 "
   model   vdw
   3.484 3.350
nonbonded pdb=" O   PRO A  54 "
          pdb=" N   TYR A  56 "
   model   vdw
   3.485 3.120
nonbonded pdb=" OE1 GLN A  31 "
          pdb=" CD2 TYR A  56 "
   model   vdw
   3.486 3.340
nonbonded pdb=" N   ILE A   2 "
          pdb=" N   LYS A   3 "
   model   vdw
   3.486 2.560
nonbonded pdb=" O   LEU A  49 "
          pdb=" O   ASP A  50 "
   model   vdw
   3.487 3.040
nonbonded pdb=" O   LEU A  60 "
          pdb=" CG  TYR A  61 "
   model   vdw
   3.487 3.260
nonbonded pdb=" CD  GLU A  30 "
          pdb="O    HOH S  11 "
   model   vdw
   3.488 3.270
nonbonded pdb=" CB  LYS A   7 "
          pdb=" OE1 GLN A  10 "
   model   vdw
   3.488 3.440
nonbonded pdb=" N   LEU A  76 "
          pdb=" N   MSE A  77 "
   model   vdw
   3.490 2.560
nonbonded pdb=" C   TYR A  61 "
          pdb=" C   THR A  62 "
   model   vdw
   3.490 2.800
nonbonded pdb=" OE2 GLU A   5 "
          pdb=" CD  LYS A   7 "
   model   vdw
   3.490 3.440
nonbonded pdb=" O   ASN A  39 "
          pdb=" CB  ASN A  39 "
   model   vdw
   3.490 2.752
nonbonded pdb=" N   LEU A  44 "
          pdb=" N   VAL A  45 "
   model   vdw
   3.491 2.560
nonbonded pdb=" CA  GLN A  10 "
          pdb=" NE2 GLN A  12 "
   model   vdw
   3.491 3.550
nonbonded pdb=" C   LYS A  46 "
          pdb=" CB  ILE A  47 "
   model   vdw
   3.491 2.960
nonbonded pdb=" C   GLN A  72 "
          pdb=" N   GLY A  74 "
   model   vdw
   3.492 3.350
nonbonded pdb=" O   SER A  75 "
          pdb=" N   MSE A  77 "
   model   vdw
   3.493 3.120
nonbonded pdb=" C   SER A  67 "
          pdb=" CB  PHE A  68 "
   model   vdw
   3.493 2.936
nonbonded pdb=" C   PRO A   8 "
          pdb=" N   THR A  15 "
   model   vdw sym.op.
   3.495 3.350 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CD  ARG A  16 "
          pdb=" OE2 GLU A  30 "
   model   vdw
   3.495 3.440
nonbonded pdb=" N   GLN A  53 "
          pdb=" N   PRO A  54 "
   model   vdw
   3.496 2.560
nonbonded pdb=" N   GLU A  51 "
          pdb=" N   GLY A  52 "
   model   vdw
   3.496 2.560
nonbonded pdb=" N   ASN A  39 "
          pdb=" OD1 ASN A  39 "
   model   vdw
   3.496 3.120
nonbonded pdb=" CA  ILE A   6 "
          pdb=" CD1 ILE A   6 "
   model   vdw
   3.497 3.112
nonbonded pdb=" O   ALA A  55 "
          pdb=" O   TYR A  56 "
   model   vdw
   3.498 3.040
nonbonded pdb=" C   LEU A  83 "
          pdb=" C   VAL A  84 "
   model   vdw
   3.498 2.800
nonbonded pdb=" C   LEU A  81 "
          pdb=" CB  ARG A  82 "
   model   vdw
   3.500 2.936
nonbonded pdb=" N   GLN A  10 "
          pdb=" O   GLN A  10 "
   model   vdw
   3.501 2.496
nonbonded pdb=" N   ILE A  47 "
          pdb=" N   THR A  48 "
   model   vdw
   3.502 2.560
nonbonded pdb=" C   ASP A  36 "
          pdb=" CB  LEU A  37 "
   model   vdw
   3.503 2.936
nonbonded pdb=" O   VAL A  35 "
          pdb=" CG2 VAL A  43 "
   model   vdw
   3.503 3.460
nonbonded pdb=" CE1 TYR A  56 "
          pdb="O    HOH S  39 "
   model   vdw
   3.504 3.340
nonbonded pdb=" O   SER A  17 "
          pdb=" OG  SER A  17 "
   model   vdw
   3.505 3.040
nonbonded pdb=" C   GLY A  52 "
          pdb=" CB  GLN A  53 "
   model   vdw
   3.505 2.936
nonbonded pdb=" CA  TYR A  61 "
          pdb=" CD2 TYR A  61 "
   model   vdw
   3.505 3.016
nonbonded pdb=" O   ILE A   6 "
          pdb=" CG2 ILE A   6 "
   model   vdw
   3.506 3.460
nonbonded pdb=" C   LEU A  83 "
          pdb=" CG1 VAL A  84 "
   model   vdw
   3.507 3.690
nonbonded pdb=" CG  GLN A  12 "
          pdb=" N   PHE A  13 "
   model   vdw
   3.507 3.520
nonbonded pdb=" N   TYR A  41 "
          pdb=" CD2 TYR A  41 "
   model   vdw
   3.507 3.420
nonbonded pdb=" CA  TYR A  41 "
          pdb=" CD2 TYR A  41 "
   model   vdw
   3.508 3.016
nonbonded pdb=" C   TYR A  26 "
          pdb=" C   SER A  27 "
   model   vdw
   3.508 2.800
nonbonded pdb=" CA  LEU A  28 "
          pdb=" CD2 LEU A  28 "
   model   vdw
   3.510 3.112
nonbonded pdb=" C   GLN A  31 "
          pdb=" CB  LEU A  32 "
   model   vdw
   3.510 2.936
nonbonded pdb=" O   SER A  67 "
          pdb=" CG2 ILE A  78 "
   model   vdw
   3.510 3.460
nonbonded pdb=" O   THR A  62 "
          pdb=" CB  THR A  62 "
   model   vdw
   3.510 2.776
nonbonded pdb=" CA  MSE A  77 "
          pdb="O    HOH S  13 "
   model   vdw
   3.510 3.470
nonbonded pdb=" O   VAL A  63 "
          pdb=" CG1 VAL A  63 "
   model   vdw
   3.510 3.460
nonbonded pdb=" CD2 PHE A  68 "
          pdb=" CG1 ILE A  78 "
   model   vdw
   3.511 3.740
nonbonded pdb="O    HOH S  13 "
          pdb=" CA  MSE A  77 "
   model   vdw sym.op.
   3.511 3.470 -x+1,y,-z+2
nonbonded pdb=" CA  MSE A  77 "
          pdb="O    HOH S  13 "
   model   vdw sym.op.
   3.511 3.470 -x+1,y,-z+2
nonbonded pdb=" N   VAL A  35 "
          pdb=" N   ASP A  36 "
   model   vdw
   3.515 2.560
nonbonded pdb=" O   THR A  62 "
          pdb=" CG2 THR A  62 "
   model   vdw
   3.516 3.460
nonbonded pdb=" N   LYS A   3 "
          pdb=" N   VAL A   4 "
   model   vdw
   3.516 2.560
nonbonded pdb=" C   LEU A  28 "
          pdb=" CB  ASN A  29 "
   model   vdw
   3.516 2.936
nonbonded pdb=" C   LEU A  37 "
          pdb="O    HOH S   9 "
   model   vdw
   3.516 3.270
nonbonded pdb=" C   GLY A  59 "
          pdb=" CB  LEU A  60 "
   model   vdw
   3.516 2.936
nonbonded pdb=" N   GLU A   5 "
          pdb=" N   ILE A   6 "
   model   vdw
   3.516 2.560
nonbonded pdb=" CA  GLY A  71 "
          pdb="SE   MSE A  77 "
   model   vdw
   3.519 3.820
nonbonded pdb=" O   LYS A   7 "
          pdb=" CB  GLN A  10 "
   model   vdw
   3.519 3.440
nonbonded pdb=" OE1 GLU A  30 "
          pdb=" CE  LYS A  46 "
   model   vdw
   3.520 3.440
nonbonded pdb=" CB  TYR A  34 "
          pdb=" CB  PRO A  42 "
   model   vdw
   3.521 3.840
nonbonded pdb=" O   GLY A  38 "
          pdb=" O   ASN A  39 "
   model   vdw
   3.521 3.040
nonbonded pdb=" OG  SER A  67 "
          pdb=" N   PHE A  68 "
   model   vdw
   3.523 3.120
nonbonded pdb=" O   GLN A  10 "
          pdb=" CD  GLN A  31 "
   model   vdw
   3.523 3.270
nonbonded pdb=" C   THR A  15 "
          pdb=" CB  ARG A  16 "
   model   vdw
   3.524 2.936
nonbonded pdb=" O   ASP A  36 "
          pdb=" CG  ASP A  36 "
   model   vdw
   3.524 3.270
nonbonded pdb=" CB  PRO A   8 "
          pdb=" O   PHE A  13 "
   model   vdw sym.op.
   3.525 3.440 -x+1/2,y+1/2,-z+1
nonbonded pdb=" C   ARG A  82 "
          pdb=" CB  LEU A  83 "
   model   vdw
   3.525 2.936
nonbonded pdb=" CA  ASP A  50 "
          pdb=" OD2 ASP A  50 "
   model   vdw
   3.526 2.776
nonbonded pdb=" O   ARG A  16 "
          pdb=" CA  SER A  27 "
   model   vdw
   3.526 3.470
nonbonded pdb=" C   SER A  67 "
          pdb=" C   PHE A  68 "
   model   vdw
   3.527 2.800
nonbonded pdb=" O   ASN A  29 "
          pdb=" CA  THR A  48 "
   model   vdw
   3.527 3.470
nonbonded pdb=" N   LEU A  60 "
          pdb=" N   TYR A  61 "
   model   vdw
   3.527 2.560
nonbonded pdb=" O   ARG A  16 "
          pdb=" O   LEU A  28 "
   model   vdw
   3.527 3.040
nonbonded pdb=" N   VAL A  63 "
          pdb=" N   HIS A  64 "
   model   vdw
   3.528 2.560
nonbonded pdb=" CZ  TYR A  56 "
          pdb=" CB  LEU A  83 "
   model   vdw
   3.529 3.660
nonbonded pdb=" CB  VAL A  70 "
          pdb=" N   GLY A  71 "
   model   vdw
   3.529 2.840
nonbonded pdb=" NE2 GLN A  10 "
          pdb=" CA  CYS A  33 "
   model   vdw
   3.529 3.550
nonbonded pdb=" CB  LEU A  81 "
          pdb=" N   ARG A  82 "
   model   vdw
   3.530 2.816
nonbonded pdb=" N   LEU A  83 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   3.531 3.540
nonbonded pdb=" CB  THR A  48 "
          pdb=" N   LEU A  49 "
   model   vdw
   3.531 2.840
nonbonded pdb=" CB  SER A  75 "
          pdb="O    HOH S   6 "
   model   vdw
   3.532 3.440
nonbonded pdb=" CG2 THR A  62 "
          pdb=" CG2 VAL A  84 "
   model   vdw
   3.532 3.880
nonbonded pdb=" CE1 PHE A  13 "
          pdb=" OD1 ASN A  29 "
   model   vdw
   3.533 3.340
nonbonded pdb=" CB  GLN A  10 "
          pdb=" O   LEU A  32 "
   model   vdw
   3.533 3.440
nonbonded pdb=" O   VAL A   4 "
          pdb=" CA  TYR A  61 "
   model   vdw
   3.533 3.470
nonbonded pdb=" C   ASN A  29 "
          pdb=" C   GLU A  30 "
   model   vdw
   3.534 2.800
nonbonded pdb=" N   LYS A  46 "
          pdb=" N   ILE A  47 "
   model   vdw
   3.534 2.560
nonbonded pdb=" O   PRO A   8 "
          pdb=" C   THR A  14 "
   model   vdw sym.op.
   3.535 3.270 -x+1/2,y+1/2,-z+1
nonbonded pdb=" O   GLN A  72 "
          pdb=" CG  GLN A  72 "
   model   vdw
   3.536 3.440
nonbonded pdb=" C   GLN A  72 "
          pdb=" CB  PHE A  73 "
   model   vdw
   3.539 2.936
nonbonded pdb=" O   ILE A   6 "
          pdb=" C   PRO A  58 "
   model   vdw
   3.539 3.270
nonbonded pdb=" N   SER A  67 "
          pdb=" OG  SER A  67 "
   model   vdw
   3.540 2.496
nonbonded pdb=" C   ASP A  50 "
          pdb=" O   GLU A  51 "
   model   vdw
   3.540 3.270
nonbonded pdb=" CA  LEU A  37 "
          pdb="O    HOH S   9 "
   model   vdw
   3.541 3.470
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" N   LYS A   7 "
   model   vdw
   3.541 3.540
nonbonded pdb=" N   ILE A  78 "
          pdb=" N   ASP A  79 "
   model   vdw
   3.541 2.560
nonbonded pdb=" CG  GLN A  10 "
          pdb="O    HOH S  23 "
   model   vdw
   3.541 3.440
nonbonded pdb=" SG  CYS A  33 "
          pdb=" O   VAL A  45 "
   model   vdw
   3.542 3.400
nonbonded pdb=" C   GLU A  30 "
          pdb=" C   GLN A  31 "
   model   vdw
   3.542 2.800
nonbonded pdb=" O   THR A  14 "
          pdb=" O   LEU A  28 "
   model   vdw
   3.543 3.040
nonbonded pdb=" C   SER A  67 "
          pdb=" CG  PHE A  68 "
   model   vdw
   3.544 3.490
nonbonded pdb=" O   LEU A  37 "
          pdb=" N   ASN A  39 "
   model   vdw
   3.545 3.120
nonbonded pdb=" C   LEU A  60 "
          pdb=" C   TYR A  61 "
   model   vdw
   3.545 2.800
nonbonded pdb=" NH2 ARG A  16 "
          pdb=" CE2 TYR A  61 "
   model   vdw sym.op.
   3.545 3.420 x,y-1,z
nonbonded pdb=" O   LYS A   3 "
          pdb=" CG2 VAL A   4 "
   model   vdw
   3.545 3.460
nonbonded pdb=" CD  GLU A   5 "
          pdb="O    HOH S  12 "
   model   vdw
   3.545 3.270
nonbonded pdb=" N   ARG A  16 "
          pdb=" N   SER A  17 "
   model   vdw
   3.546 2.560
nonbonded pdb=" C   TYR A  61 "
          pdb=" O   VAL A  84 "
   model   vdw
   3.546 3.270
nonbonded pdb=" C   LYS A  69 "
          pdb="O    HOH S  10 "
   model   vdw
   3.546 3.270
nonbonded pdb=" CE1 PHE A  13 "
          pdb=" OG1 THR A  15 "
   model   vdw
   3.546 3.340
nonbonded pdb=" N   LEU A  37 "
          pdb=" O   LEU A  37 "
   model   vdw
   3.547 2.496
nonbonded pdb=" C   PHE A  68 "
          pdb=" C   LYS A  69 "
   model   vdw
   3.547 2.800
nonbonded pdb=" O   ASP A  50 "
          pdb=" CB  GLN A  53 "
   model   vdw
   3.547 3.440
nonbonded pdb=" N   LEU A  28 "
          pdb=" N   ASN A  29 "
   model   vdw
   3.547 2.560
nonbonded pdb=" N   PRO A   8 "
          pdb=" O   PRO A   8 "
   model   vdw
   3.547 2.496
nonbonded pdb=" N   ALA A  55 "
          pdb=" N   TYR A  56 "
   model   vdw
   3.547 2.560
nonbonded pdb=" N   VAL A  45 "
          pdb=" N   LYS A  46 "
   model   vdw
   3.548 2.560
nonbonded pdb=" CA  TYR A  26 "
          pdb=" CD2 TYR A  26 "
   model   vdw
   3.548 3.016
nonbonded pdb=" O   PRO A  85 "
          pdb=" CD  PRO A  85 "
   model   vdw
   3.549 3.440
nonbonded pdb=" N   SER A  66 "
          pdb=" O   SER A  66 "
   model   vdw
   3.549 2.496
nonbonded pdb=" CB  GLN A  72 "
          pdb=" N   PHE A  73 "
   model   vdw
   3.551 2.816
nonbonded pdb=" C   TYR A  34 "
          pdb=" O   VAL A  43 "
   model   vdw
   3.551 3.270
nonbonded pdb=" O   ASP A  36 "
          pdb=" CD1 LEU A  65 "
   model   vdw sym.op.
   3.551 3.460 -x+1,y,-z+2
nonbonded pdb=" C   TYR A  34 "
          pdb=" CB  VAL A  35 "
   model   vdw
   3.551 2.960
nonbonded pdb=" CG1 VAL A  63 "
          pdb=" O   HIS A  64 "
   model   vdw
   3.551 3.460
nonbonded pdb=" C   PRO A  85 "
          pdb=" CD  PRO A  85 "
   model   vdw
   3.551 2.936
nonbonded pdb=" CA  LEU A  32 "
          pdb=" O   VAL A  45 "
   model   vdw
   3.552 3.470
nonbonded pdb=" CA  GLN A  12 "
          pdb=" NE2 GLN A  12 "
   model   vdw
   3.552 3.550
nonbonded pdb=" C   VAL A   4 "
          pdb=" C   GLU A   5 "
   model   vdw
   3.552 2.800
nonbonded pdb=" C   ILE A  47 "
          pdb=" CB  THR A  48 "
   model   vdw
   3.552 2.960
nonbonded pdb=" N   TYR A  34 "
          pdb=" N   VAL A  35 "
   model   vdw
   3.553 2.560
nonbonded pdb=" N   SER A  67 "
          pdb=" O   SER A  67 "
   model   vdw
   3.553 2.496
nonbonded pdb=" C   SER A  75 "
          pdb="O    HOH S   6 "
   model   vdw
   3.554 3.270
nonbonded pdb=" CA  TYR A  56 "
          pdb=" CD2 TYR A  56 "
   model   vdw
   3.555 3.016
nonbonded pdb=" NE2 GLN A  10 "
          pdb=" CD1 TYR A  34 "
   model   vdw
   3.555 3.420
nonbonded pdb=" CD1 LEU A  37 "
          pdb=" O   PHE A  68 "
   model   vdw sym.op.
   3.556 3.460 -x+1,y,-z+2
nonbonded pdb=" O   LYS A   7 "
          pdb=" O   PRO A   8 "
   model   vdw
   3.559 3.040
nonbonded pdb=" CA  GLU A  51 "
          pdb=" OE1 GLU A  51 "
   model   vdw
   3.559 3.470
nonbonded pdb=" C   ASP A  79 "
          pdb=" C   ARG A  80 "
   model   vdw
   3.560 2.800
nonbonded pdb=" N   LEU A  49 "
          pdb=" N   ASP A  50 "
   model   vdw
   3.560 2.560
nonbonded pdb=" C   GLU A   5 "
          pdb=" CB  ILE A   6 "
   model   vdw
   3.560 2.960
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" O   GLN A  10 "
   model   vdw
   3.561 3.460
nonbonded pdb=" CE1 PHE A  13 "
          pdb=" CG  ASN A  29 "
   model   vdw
   3.562 3.570
nonbonded pdb=" N   ASP A  50 "
          pdb=" N   GLU A  51 "
   model   vdw
   3.562 2.560
nonbonded pdb=" O   PRO A  54 "
          pdb=" CD  PRO A  54 "
   model   vdw
   3.562 3.440
nonbonded pdb=" CD1 PHE A  13 "
          pdb=" CG  ASN A  29 "
   model   vdw
   3.562 3.570
nonbonded pdb=" O   PRO A  42 "
          pdb=" C   VAL A  43 "
   model   vdw
   3.562 3.270
nonbonded pdb=" CA  GLY A  71 "
          pdb=" O   SER A  75 "
   model   vdw
   3.562 3.440
nonbonded pdb=" N   GLY A  52 "
          pdb=" O   GLY A  52 "
   model   vdw
   3.564 2.496
nonbonded pdb=" O   SER A  67 "
          pdb=" C   ILE A  78 "
   model   vdw
   3.564 3.270
nonbonded pdb=" CB  ASP A  36 "
          pdb=" N   LEU A  37 "
   model   vdw
   3.564 2.816
nonbonded pdb=" O   LYS A  69 "
          pdb=" N   GLY A  71 "
   model   vdw
   3.565 3.120
nonbonded pdb=" N   THR A  14 "
          pdb=" N   THR A  15 "
   model   vdw
   3.565 2.560
nonbonded pdb=" N   ASP A  50 "
          pdb=" OD1 ASP A  50 "
   model   vdw
   3.565 3.120
nonbonded pdb=" C   ARG A  80 "
          pdb=" N   ARG A  82 "
   model   vdw
   3.566 3.350
nonbonded pdb=" C   TYR A  56 "
          pdb=" CB  ALA A  57 "
   model   vdw
   3.566 2.952
nonbonded pdb=" C   GLY A  38 "
          pdb=" CB  ASN A  39 "
   model   vdw
   3.566 2.936
nonbonded pdb=" CB  VAL A  70 "
          pdb="O    HOH S  10 "
   model   vdw
   3.567 3.470
nonbonded pdb=" N   TYR A  56 "
          pdb=" CD2 TYR A  56 "
   model   vdw
   3.568 3.420
nonbonded pdb=" CA  PHE A  73 "
          pdb="O    HOH S   3 "
   model   vdw
   3.568 3.470
nonbonded pdb=" O   ASP A  79 "
          pdb=" CG  ASP A  79 "
   model   vdw
   3.568 3.270
nonbonded pdb=" C   LEU A  44 "
          pdb=" CG2 VAL A  45 "
   model   vdw
   3.568 3.690
nonbonded pdb=" O   VAL A  45 "
          pdb=" C   LYS A  46 "
   model   vdw
   3.568 3.270
nonbonded pdb=" C   ASN A  29 "
          pdb=" CG  GLU A  30 "
   model   vdw
   3.568 3.670
nonbonded pdb=" C   ARG A  16 "
          pdb=" C   SER A  17 "
   model   vdw
   3.569 2.800
nonbonded pdb=" N   PHE A  73 "
          pdb=" O   PHE A  73 "
   model   vdw
   3.570 2.496
nonbonded pdb=" C   PHE A  13 "
          pdb=" CG2 THR A  14 "
   model   vdw
   3.570 3.690
nonbonded pdb=" O   LYS A  69 "
          pdb=" CG  LYS A  69 "
   model   vdw
   3.571 3.440
nonbonded pdb=" C   ILE A   2 "
          pdb=" CB  LYS A   3 "
   model   vdw
   3.572 2.936
nonbonded pdb=" O   ILE A   2 "
          pdb=" CB  THR A  62 "
   model   vdw
   3.572 3.470
nonbonded pdb=" N   GLU A  30 "
          pdb=" N   GLN A  31 "
   model   vdw
   3.573 2.560
nonbonded pdb=" CB  THR A  15 "
          pdb="O    HOH S  14 "
   model   vdw
   3.574 3.470
nonbonded pdb=" O   LEU A  60 "
          pdb=" CB  TYR A  61 "
   model   vdw
   3.576 3.440
nonbonded pdb=" NE2 GLN A  53 "
          pdb=" CZ  TYR A  56 "
   model   vdw
   3.576 3.340
nonbonded pdb=" O   CYS A  33 "
          pdb=" O   VAL A  43 "
   model   vdw
   3.577 3.040
nonbonded pdb=" N   GLN A  53 "
          pdb=" CG  GLN A  53 "
   model   vdw
   3.577 2.816
nonbonded pdb=" C   ALA A  57 "
          pdb=" CB  PRO A  58 "
   model   vdw
   3.578 2.936
nonbonded pdb=" O   CYS A  33 "
          pdb=" CA  LEU A  44 "
   model   vdw
   3.578 3.470
nonbonded pdb=" O   GLU A   5 "
          pdb=" CB  CYS A  33 "
   model   vdw
   3.578 3.440
nonbonded pdb=" N   ALA A  57 "
          pdb=" N   PRO A  58 "
   model   vdw
   3.578 2.560
nonbonded pdb=" CA  ASP A  50 "
          pdb=" NH1 ARG A  80 "
   model   vdw
   3.578 3.550
nonbonded pdb=" O   THR A  14 "
          pdb=" C   ASN A  29 "
   model   vdw
   3.579 3.270
nonbonded pdb=" N   LEU A  65 "
          pdb=" O   LEU A  65 "
   model   vdw
   3.579 2.496
nonbonded pdb=" CG1 VAL A  70 "
          pdb=" N   GLY A  71 "
   model   vdw
   3.580 3.540
nonbonded pdb=" CG1 VAL A  63 "
          pdb=" OG  SER A  67 "
   model   vdw
   3.581 3.460
nonbonded pdb=" C   ASP A  50 "
          pdb=" CB  GLU A  51 "
   model   vdw
   3.581 2.936
nonbonded pdb=" C   THR A  62 "
          pdb=" CB  VAL A  63 "
   model   vdw
   3.581 2.960
nonbonded pdb=" O   LYS A   3 "
          pdb=" CG  LYS A   3 "
   model   vdw
   3.581 3.440
nonbonded pdb=" N   VAL A  84 "
          pdb=" N   PRO A  85 "
   model   vdw
   3.581 2.560
nonbonded pdb=" CD1 PHE A  13 "
          pdb=" N   THR A  14 "
   model   vdw
   3.581 3.420
nonbonded pdb=" CA  PHE A  68 "
          pdb=" O   MSE A  77 "
   model   vdw
   3.582 3.470
nonbonded pdb=" C   GLN A  10 "
          pdb=" CB  ALA A  11 "
   model   vdw
   3.583 2.952
nonbonded pdb=" O   TYR A  61 "
          pdb=" CB  THR A  62 "
   model   vdw
   3.583 3.470
nonbonded pdb=" CG  GLU A   5 "
          pdb="O    HOH S  12 "
   model   vdw
   3.584 3.440
nonbonded pdb=" CD  GLU A   5 "
          pdb=" NZ  LYS A   7 "
   model   vdw
   3.585 3.350
nonbonded pdb=" C   GLY A  74 "
          pdb=" O   SER A  75 "
   model   vdw
   3.585 3.270
nonbonded pdb=" C   GLU A  30 "
          pdb=" O   ILE A  47 "
   model   vdw
   3.586 3.270
nonbonded pdb=" C   VAL A  45 "
          pdb=" CB  LYS A  46 "
   model   vdw
   3.586 2.936
nonbonded pdb=" CD2 LEU A  49 "
          pdb=" CE2 TYR A  56 "
   model   vdw
   3.587 3.760
nonbonded pdb=" C   PRO A  42 "
          pdb=" CB  VAL A  43 "
   model   vdw
   3.587 2.960
nonbonded pdb=" CA  VAL A  45 "
          pdb=" O   GLY A  74 "
   model   vdw sym.op.
   3.588 3.470 -x+1,y,-z+2
nonbonded pdb=" N   TYR A  61 "
          pdb=" N   THR A  62 "
   model   vdw
   3.588 2.560
nonbonded pdb=" CA  ASP A  79 "
          pdb=" OD2 ASP A  79 "
   model   vdw
   3.589 2.776
nonbonded pdb=" O   ILE A   6 "
          pdb=" O   LYS A   7 "
   model   vdw
   3.590 3.040
nonbonded pdb=" O   PHE A  13 "
          pdb=" CG2 THR A  14 "
   model   vdw
   3.590 3.460
nonbonded pdb=" O   ILE A   2 "
          pdb=" CA  THR A  62 "
   model   vdw
   3.590 3.470
nonbonded pdb=" C   LEU A  44 "
          pdb=" C   VAL A  45 "
   model   vdw
   3.591 2.800
nonbonded pdb=" N   MSE A  77 "
          pdb=" N   ILE A  78 "
   model   vdw
   3.591 2.560
nonbonded pdb=" C   LYS A   7 "
          pdb=" N   GLN A  10 "
   model   vdw
   3.591 3.350
nonbonded pdb=" C   GLN A  53 "
          pdb=" CB  PRO A  54 "
   model   vdw
   3.592 2.936
nonbonded pdb=" CE1 TYR A  26 "
          pdb=" CG  PRO A  85 "
   model   vdw sym.op.
   3.593 3.740 x,y-1,z
nonbonded pdb=" CD2 TYR A  41 "
          pdb=" OH  TYR A  41 "
   model   vdw
   3.593 2.672
nonbonded pdb=" O   GLN A  31 "
          pdb=" CA  LYS A  46 "
   model   vdw
   3.594 3.470
nonbonded pdb=" CB  GLN A  10 "
          pdb=" NE2 GLN A  10 "
   model   vdw
   3.594 2.816
nonbonded pdb=" N   GLU A  40 "
          pdb=" CD  GLU A  40 "
   model   vdw
   3.594 3.350
nonbonded pdb=" N   SER A  27 "
          pdb=" OG  SER A  27 "
   model   vdw
   3.594 2.496
nonbonded pdb=" CG  LEU A  76 "
          pdb=" N   MSE A  77 "
   model   vdw
   3.594 3.550
nonbonded pdb=" C   ILE A   6 "
          pdb=" CB  LYS A   7 "
   model   vdw
   3.595 2.936
nonbonded pdb=" O   GLU A   5 "
          pdb=" CA  CYS A  33 "
   model   vdw
   3.596 3.470
nonbonded pdb=" CG2 THR A  15 "
          pdb=" O   LEU A  28 "
   model   vdw
   3.597 3.460
nonbonded pdb=" N   ALA A  11 "
          pdb=" O   ALA A  11 "
   model   vdw
   3.597 2.496
nonbonded pdb=" C   VAL A  63 "
          pdb=" CB  HIS A  64 "
   model   vdw
   3.598 2.936
nonbonded pdb=" O   TYR A  41 "
          pdb=" CD  PRO A  42 "
   model   vdw
   3.598 2.752
nonbonded pdb=" CA  LYS A   3 "
          pdb="O    HOH S   5 "
   model   vdw
   3.598 3.470
nonbonded pdb=" O   ALA A  57 "
          pdb=" CD  PRO A  58 "
   model   vdw
   3.599 2.752
nonbonded pdb=" C   PHE A  13 "
          pdb=" O   THR A  14 "
   model   vdw
   3.599 3.270
nonbonded pdb=" N   PHE A  13 "
          pdb=" N   THR A  14 "
   model   vdw
   3.599 2.560
nonbonded pdb=" CA  TYR A  56 "
          pdb="O    HOH S   7 "
   model   vdw
   3.600 3.470
nonbonded pdb=" C   ALA A  57 "
          pdb=" CG  PRO A  58 "
   model   vdw
   3.601 2.936
nonbonded pdb=" C   LYS A   7 "
          pdb=" CB  PRO A   8 "
   model   vdw
   3.602 2.936
nonbonded pdb=" C   PRO A   8 "
          pdb=" CB  SER A   9 "
   model   vdw
   3.602 2.936
nonbonded pdb=" O   LYS A   7 "
          pdb=" CD  PRO A   8 "
   model   vdw
   3.603 2.752
nonbonded pdb=" CD  PRO A   8 "
          pdb="O    HOH S  12 "
   model   vdw
   3.603 3.440
nonbonded pdb=" O   LEU A  44 "
          pdb=" CB  VAL A  45 "
   model   vdw
   3.603 3.470
nonbonded pdb=" C   GLN A  53 "
          pdb=" CG  PRO A  54 "
   model   vdw
   3.604 2.936
nonbonded pdb=" N   PRO A  58 "
          pdb=" N   GLY A  59 "
   model   vdw
   3.604 2.560
nonbonded pdb=" N   GLN A  12 "
          pdb=" N   PHE A  13 "
   model   vdw
   3.604 2.560
nonbonded pdb=" CD1 TYR A  61 "
          pdb=" OH  TYR A  61 "
   model   vdw
   3.605 2.672
nonbonded pdb=" CB  PHE A  73 "
          pdb=" N   GLY A  74 "
   model   vdw
   3.605 2.816
nonbonded pdb=" CA  ALA A  57 "
          pdb="O    HOH S   7 "
   model   vdw
   3.605 3.470
nonbonded pdb=" CD  GLU A  30 "
          pdb=" CD  LYS A  46 "
   model   vdw
   3.606 3.670
nonbonded pdb=" C   VAL A  35 "
          pdb=" CB  ASP A  36 "
   model   vdw
   3.606 2.936
nonbonded pdb=" O   VAL A  35 "
          pdb=" CB  PRO A  42 "
   model   vdw
   3.606 3.440
nonbonded pdb=" CG  GLN A  53 "
          pdb=" N   PRO A  54 "
   model   vdw
   3.606 3.520
nonbonded pdb=" C   GLN A  31 "
          pdb=" CG  LEU A  32 "
   model   vdw
   3.607 3.700
nonbonded pdb=" CD2 TYR A  61 "
          pdb=" OH  TYR A  61 "
   model   vdw
   3.607 2.672
nonbonded pdb=" O   ILE A  78 "
          pdb=" O   ASP A  79 "
   model   vdw
   3.608 3.040
nonbonded pdb=" CA  ILE A   2 "
          pdb="O    HOH S   5 "
   model   vdw
   3.608 3.470
nonbonded pdb=" C   TYR A  41 "
          pdb=" CG  PRO A  42 "
   model   vdw
   3.608 2.936
nonbonded pdb=" CG2 VAL A   4 "
          pdb=" CG2 VAL A  35 "
   model   vdw
   3.608 3.880
nonbonded pdb=" O   SER A  67 "
          pdb=" N   ARG A  80 "
   model   vdw
   3.608 3.120
nonbonded pdb=" C   ILE A  47 "
          pdb=" OG1 THR A  48 "
   model   vdw
   3.608 3.270
nonbonded pdb=" O   GLY A  59 "
          pdb=" CD1 TYR A  61 "
   model   vdw
   3.608 3.340
nonbonded pdb=" N   VAL A  43 "
          pdb=" N   LEU A  44 "
   model   vdw
   3.609 2.560
nonbonded pdb=" O   GLU A  30 "
          pdb=" CB  GLN A  31 "
   model   vdw
   3.609 3.440
nonbonded pdb=" CG  HIS A  64 "
          pdb=" OG  SER A  66 "
   model   vdw
   3.610 3.260
nonbonded pdb=" O   LEU A  28 "
          pdb=" C   ASN A  29 "
   model   vdw
   3.612 3.270
nonbonded pdb=" N   GLU A  51 "
          pdb=" OE2 GLU A  51 "
   model   vdw
   3.612 3.120
nonbonded pdb=" CG  LEU A  44 "
          pdb=" N   VAL A  45 "
   model   vdw
   3.613 3.550
nonbonded pdb=" SG  CYS A  33 "
          pdb=" N   TYR A  34 "
   model   vdw
   3.614 3.480
nonbonded pdb=" C   LEU A  49 "
          pdb=" CB  ASP A  50 "
   model   vdw
   3.614 2.936
nonbonded pdb=" C   PRO A  42 "
          pdb=" CD  PRO A  42 "
   model   vdw
   3.614 2.936
nonbonded pdb=" O   VAL A   4 "
          pdb=" CD2 LEU A  60 "
   model   vdw
   3.615 3.460
nonbonded pdb=" C   LYS A  69 "
          pdb=" CB  VAL A  70 "
   model   vdw
   3.615 2.960
nonbonded pdb=" N   GLN A  72 "
          pdb=" O   GLN A  72 "
   model   vdw
   3.616 2.496
nonbonded pdb=" C   ILE A   2 "
          pdb="O    HOH S   5 "
   model   vdw
   3.616 3.270
nonbonded pdb=" C   SER A  75 "
          pdb=" O   LEU A  76 "
   model   vdw
   3.617 3.270
nonbonded pdb=" C   GLN A  31 "
          pdb=" O   LEU A  32 "
   model   vdw
   3.617 3.270
nonbonded pdb=" CB  HIS A  64 "
          pdb=" CE1 HIS A  64 "
   model   vdw
   3.618 2.928
nonbonded pdb=" CG  ARG A  82 "
          pdb=" CZ  ARG A  82 "
   model   vdw
   3.618 2.936
nonbonded pdb=" CD1 TYR A  56 "
          pdb=" OH  TYR A  56 "
   model   vdw
   3.619 2.672
nonbonded pdb=" O   PHE A  68 "
          pdb=" CB  LYS A  69 "
   model   vdw
   3.619 3.440
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" NE2 GLN A  31 "
   model   vdw
   3.619 3.540
nonbonded pdb=" CD2 TYR A  56 "
          pdb=" OH  TYR A  56 "
   model   vdw
   3.620 2.672
nonbonded pdb=" OG  SER A   9 "
          pdb=" CG  GLN A  10 "
   model   vdw
   3.620 3.440
nonbonded pdb=" C   LYS A   7 "
          pdb=" CG  PRO A   8 "
   model   vdw
   3.620 2.936
nonbonded pdb=" OG  SER A   9 "
          pdb="O    HOH S  23 "
   model   vdw
   3.621 3.040
nonbonded pdb=" C   GLY A  74 "
          pdb=" CB  SER A  75 "
   model   vdw
   3.622 2.936
nonbonded pdb=" CB  GLU A  30 "
          pdb=" OE2 GLU A  30 "
   model   vdw
   3.622 2.752
nonbonded pdb=" O   ASN A  29 "
          pdb=" C   THR A  48 "
   model   vdw
   3.622 3.270
nonbonded pdb=" O   GLN A  53 "
          pdb=" CD  PRO A  54 "
   model   vdw
   3.622 2.752
nonbonded pdb=" N   THR A  48 "
          pdb="O    HOH S  38 "
   model   vdw
   3.622 3.120
nonbonded pdb=" CB  GLN A  10 "
          pdb=" N   ALA A  11 "
   model   vdw
   3.622 2.816
nonbonded pdb=" CD2 TYR A  61 "
          pdb=" O   VAL A  84 "
   model   vdw
   3.624 3.340
nonbonded pdb=" C   GLU A   5 "
          pdb=" O   GLY A  59 "
   model   vdw
   3.625 3.270
nonbonded pdb=" CD2 TYR A  34 "
          pdb=" OH  TYR A  34 "
   model   vdw
   3.625 2.672
nonbonded pdb=" O   THR A  48 "
          pdb=" CG  ARG A  80 "
   model   vdw
   3.625 3.440
nonbonded pdb=" CD2 TYR A  26 "
          pdb=" OH  TYR A  26 "
   model   vdw
   3.626 2.672
nonbonded pdb=" N   LYS A  69 "
          pdb=" N   VAL A  70 "
   model   vdw
   3.627 2.560
nonbonded pdb=" O   GLN A  31 "
          pdb=" CA  ILE A  47 "
   model   vdw
   3.627 3.470
nonbonded pdb=" O   ARG A  82 "
          pdb=" C   LEU A  83 "
   model   vdw
   3.628 3.270
nonbonded pdb=" C   GLU A  40 "
          pdb=" C   TYR A  41 "
   model   vdw
   3.629 2.800
nonbonded pdb=" N   LYS A   7 "
          pdb=" N   PRO A   8 "
   model   vdw
   3.629 2.560
nonbonded pdb=" C   ASP A  36 "
          pdb="O    HOH S   5 "
   model   vdw
   3.630 3.270
nonbonded pdb=" CB  LEU A  76 "
          pdb="O    HOH S   6 "
   model   vdw
   3.630 3.440
nonbonded pdb=" CD1 TYR A  26 "
          pdb=" OH  TYR A  26 "
   model   vdw
   3.630 2.672
nonbonded pdb=" O   GLU A  40 "
          pdb=" CD1 TYR A  41 "
   model   vdw
   3.631 3.340
nonbonded pdb=" N   HIS A  64 "
          pdb=" N   LEU A  65 "
   model   vdw
   3.631 2.560
nonbonded pdb=" O   GLY A  52 "
          pdb=" CD  PRO A  54 "
   model   vdw
   3.631 3.440
nonbonded pdb=" C   SER A  66 "
          pdb=" CB  SER A  67 "
   model   vdw
   3.631 2.936
nonbonded pdb=" C   PHE A  13 "
          pdb=" O   GLU A  30 "
   model   vdw
   3.631 3.270
nonbonded pdb=" CD1 TYR A  26 "
          pdb=" CD2 LEU A  28 "
   model   vdw
   3.632 3.760
nonbonded pdb=" OD1 ASP A  36 "
          pdb="O    HOH S   9 "
   model   vdw
   3.633 3.040
nonbonded pdb=" N   PHE A  68 "
          pdb=" N   LYS A  69 "
   model   vdw
   3.633 2.560
nonbonded pdb=" OD2 ASP A  50 "
          pdb=" NH2 ARG A  82 "
   model   vdw
   3.634 3.120
nonbonded pdb=" C   VAL A  84 "
          pdb=" CG  PRO A  85 "
   model   vdw
   3.634 2.936
nonbonded pdb=" N   ASN A  39 "
          pdb=" N   GLU A  40 "
   model   vdw
   3.636 2.560
nonbonded pdb=" O   TYR A  34 "
          pdb=" C   VAL A  35 "
   model   vdw
   3.637 3.270
nonbonded pdb=" C   GLY A  71 "
          pdb=" CB  GLN A  72 "
   model   vdw
   3.637 2.936
nonbonded pdb=" N   CYS A  33 "
          pdb=" N   TYR A  34 "
   model   vdw
   3.638 2.560
nonbonded pdb=" N   GLY A  74 "
          pdb=" O   GLY A  74 "
   model   vdw
   3.638 2.496
nonbonded pdb=" N   LEU A  32 "
          pdb=" N   CYS A  33 "
   model   vdw
   3.639 2.560
nonbonded pdb=" C   TYR A  56 "
          pdb="O    HOH S   7 "
   model   vdw
   3.640 3.270
nonbonded pdb=" CD1 TYR A  34 "
          pdb=" OH  TYR A  34 "
   model   vdw
   3.640 2.672
nonbonded pdb=" C   TYR A  41 "
          pdb=" CB  PRO A  42 "
   model   vdw
   3.641 2.936
nonbonded pdb=" O   ILE A   6 "
          pdb=" CB  PRO A  58 "
   model   vdw
   3.642 3.440
nonbonded pdb=" O   LYS A   3 "
          pdb=" C   VAL A  35 "
   model   vdw
   3.643 3.270
nonbonded pdb=" O   VAL A   4 "
          pdb=" C   TYR A  61 "
   model   vdw
   3.643 3.270
nonbonded pdb=" C   ILE A  78 "
          pdb=" CB  ASP A  79 "
   model   vdw
   3.643 2.936
nonbonded pdb=" O   VAL A   4 "
          pdb=" C   LEU A  60 "
   model   vdw
   3.643 3.270
nonbonded pdb=" O   ARG A  16 "
          pdb=" C   SER A  27 "
   model   vdw
   3.644 3.270
nonbonded pdb=" C   PRO A  85 "
          pdb=" CG  PRO A  85 "
   model   vdw
   3.644 2.936
nonbonded pdb=" O   GLU A  40 "
          pdb=" CB  TYR A  41 "
   model   vdw
   3.645 3.440
nonbonded pdb=" CB  GLU A   5 "
          pdb=" OE2 GLU A   5 "
   model   vdw
   3.645 2.752
nonbonded pdb=" N   SER A   9 "
          pdb=" O   SER A   9 "
   model   vdw
   3.646 2.496
nonbonded pdb=" C   THR A  15 "
          pdb="O    HOH S  11 "
   model   vdw
   3.647 3.270
nonbonded pdb=" O   VAL A  84 "
          pdb=" CD  PRO A  85 "
   model   vdw
   3.647 2.752
nonbonded pdb=" N   GLN A  31 "
          pdb=" N   LEU A  32 "
   model   vdw
   3.648 2.560
nonbonded pdb=" CD  ARG A  82 "
          pdb=" NH2 ARG A  82 "
   model   vdw
   3.649 2.816
nonbonded pdb=" O   VAL A   4 "
          pdb=" CA  LEU A  60 "
   model   vdw
   3.649 3.470
nonbonded pdb=" NH2 ARG A  16 "
          pdb=" CZ  TYR A  61 "
   model   vdw sym.op.
   3.649 3.340 x,y-1,z
nonbonded pdb=" C   MSE A  77 "
          pdb="O    HOH S  13 "
   model   vdw
   3.649 3.270
nonbonded pdb="O    HOH S  13 "
          pdb=" C   MSE A  77 "
   model   vdw sym.op.
   3.650 3.270 -x+1,y,-z+2
nonbonded pdb=" C   MSE A  77 "
          pdb="O    HOH S  13 "
   model   vdw sym.op.
   3.650 3.270 -x+1,y,-z+2
nonbonded pdb=" C   TYR A  41 "
          pdb="O    HOH S   9 "
   model   vdw
   3.650 3.270
nonbonded pdb=" OE2 GLU A   5 "
          pdb=" CE  LYS A   7 "
   model   vdw
   3.650 3.440
nonbonded pdb=" N   LEU A  83 "
          pdb=" N   VAL A  84 "
   model   vdw
   3.650 2.560
nonbonded pdb=" N   TYR A  41 "
          pdb=" N   PRO A  42 "
   model   vdw
   3.651 2.560
nonbonded pdb=" CG1 ILE A   6 "
          pdb=" CE1 TYR A  61 "
   model   vdw
   3.651 3.740
nonbonded pdb=" N   GLY A  38 "
          pdb=" O   GLY A  38 "
   model   vdw
   3.652 2.496
nonbonded pdb=" CA  GLN A  10 "
          pdb="O    HOH S   8 "
   model   vdw
   3.652 3.470
nonbonded pdb=" O   ARG A  80 "
          pdb=" CD  ARG A  82 "
   model   vdw
   3.653 3.440
nonbonded pdb=" N   TYR A  26 "
          pdb=" N   SER A  27 "
   model   vdw
   3.653 2.560
nonbonded pdb=" CB  GLU A   5 "
          pdb=" CD2 LEU A  60 "
   model   vdw
   3.653 3.860
nonbonded pdb=" OD2 ASP A  50 "
          pdb=" CG  ARG A  82 "
   model   vdw
   3.654 3.440
nonbonded pdb=" C   GLU A  40 "
          pdb=" CD2 TYR A  41 "
   model   vdw
   3.654 3.570
nonbonded pdb=" CD  ARG A  80 "
          pdb=" NH2 ARG A  80 "
   model   vdw
   3.654 2.816
nonbonded pdb=" N   THR A  62 "
          pdb=" N   VAL A  63 "
   model   vdw
   3.654 2.560
nonbonded pdb=" O   GLN A  31 "
          pdb=" C   LYS A  46 "
   model   vdw
   3.654 3.270
nonbonded pdb=" C   GLN A  12 "
          pdb=" NE2 GLN A  12 "
   model   vdw
   3.656 3.350
nonbonded pdb=" CG2 THR A  48 "
          pdb=" CZ  ARG A  80 "
   model   vdw
   3.657 3.690
nonbonded pdb=" CD1 PHE A  13 "
          pdb=" OD1 ASN A  29 "
   model   vdw
   3.658 3.340
nonbonded pdb=" O   SER A  17 "
          pdb=" CZ  TYR A  26 "
   model   vdw
   3.658 3.260
nonbonded pdb=" O   LEU A  81 "
          pdb=" C   ARG A  82 "
   model   vdw
   3.659 3.270
nonbonded pdb=" CB  GLN A  72 "
          pdb=" OE1 GLN A  72 "
   model   vdw
   3.659 2.752
nonbonded pdb=" CB  LEU A  37 "
          pdb=" N   GLY A  38 "
   model   vdw
   3.659 2.816
nonbonded pdb=" O   THR A  15 "
          pdb=" CG2 THR A  15 "
   model   vdw
   3.659 3.460
nonbonded pdb=" C   TYR A  34 "
          pdb=" CG2 VAL A  35 "
   model   vdw
   3.660 3.690
nonbonded pdb=" C   MSE A  77 "
          pdb=" CB  ILE A  78 "
   model   vdw
   3.660 2.960
nonbonded pdb=" O   SER A   9 "
          pdb=" C   GLN A  10 "
   model   vdw
   3.661 3.270
nonbonded pdb=" C   ARG A  80 "
          pdb=" O   LEU A  81 "
   model   vdw
   3.661 3.270
nonbonded pdb=" CG  TYR A  26 "
          pdb=" N   SER A  27 "
   model   vdw
   3.661 3.340
nonbonded pdb=" CB  HIS A  64 "
          pdb=" NE2 HIS A  64 "
   model   vdw
   3.661 2.816
nonbonded pdb=" CB  GLU A  40 "
          pdb=" OE2 GLU A  40 "
   model   vdw
   3.661 2.752
nonbonded pdb=" CA  ASP A  36 "
          pdb=" OD2 ASP A  36 "
   model   vdw
   3.662 2.776
nonbonded pdb=" C   PRO A   8 "
          pdb=" CD  PRO A   8 "
   model   vdw
   3.662 2.936
nonbonded pdb=" O   LYS A   7 "
          pdb=" C   SER A   9 "
   model   vdw
   3.663 3.270
nonbonded pdb=" O   PRO A   8 "
          pdb=" N   GLN A  10 "
   model   vdw
   3.663 3.120
nonbonded pdb=" CD  GLU A  30 "
          pdb=" CE  LYS A  46 "
   model   vdw
   3.663 3.670
nonbonded pdb=" NE2 GLN A  31 "
          pdb=" N   TYR A  56 "
   model   vdw
   3.664 3.200
nonbonded pdb=" CD1 LEU A  28 "
          pdb=" NH2 ARG A  80 "
   model   vdw
   3.664 3.540
nonbonded pdb=" N   PRO A  42 "
          pdb=" N   VAL A  43 "
   model   vdw
   3.665 2.560
nonbonded pdb=" CD1 ILE A   6 "
          pdb=" O   LEU A  32 "
   model   vdw
   3.665 3.460
nonbonded pdb=" C   VAL A  84 "
          pdb=" CB  PRO A  85 "
   model   vdw
   3.665 2.936
nonbonded pdb=" C   PRO A  58 "
          pdb=" CD  PRO A  58 "
   model   vdw
   3.665 2.936
nonbonded pdb=" O   THR A  48 "
          pdb=" N   ASP A  50 "
   model   vdw
   3.665 3.120
nonbonded pdb=" CB  TYR A  56 "
          pdb=" OH  TYR A  61 "
   model   vdw
   3.666 3.440
nonbonded pdb=" C   PRO A  42 "
          pdb=" CG  PRO A  42 "
   model   vdw
   3.666 2.936
nonbonded pdb=" CD1 TYR A  41 "
          pdb=" OH  TYR A  41 "
   model   vdw
   3.667 2.672
nonbonded pdb=" CG2 THR A  15 "
          pdb=" O   ARG A  16 "
   model   vdw
   3.667 3.460
nonbonded pdb=" CD1 PHE A  13 "
          pdb=" O   THR A  14 "
   model   vdw
   3.667 3.340
nonbonded pdb=" O   ASN A  29 "
          pdb=" CB  LEU A  49 "
   model   vdw
   3.667 3.440
nonbonded pdb=" CD  ARG A  16 "
          pdb=" NH2 ARG A  16 "
   model   vdw
   3.667 2.816
nonbonded pdb=" CA  LEU A  49 "
          pdb=" OE1 GLN A  53 "
   model   vdw
   3.668 3.470
nonbonded pdb=" CA  SER A   9 "
          pdb=" O   THR A  15 "
   model   vdw sym.op.
   3.668 3.470 -x+1/2,y+1/2,-z+1
nonbonded pdb=" O   GLU A   5 "
          pdb=" C   ILE A   6 "
   model   vdw
   3.668 3.270
nonbonded pdb=" O   GLU A   5 "
          pdb=" CG  GLU A   5 "
   model   vdw
   3.669 3.440
nonbonded pdb=" NE2 GLN A  10 "
          pdb=" CD1 LEU A  44 "
   model   vdw
   3.669 3.540
nonbonded pdb=" N   THR A  62 "
          pdb=" OG1 THR A  62 "
   model   vdw
   3.669 2.496
nonbonded pdb=" C   SER A   9 "
          pdb=" CG  GLN A  10 "
   model   vdw
   3.669 3.670
nonbonded pdb=" C   MSE A  77 "
          pdb=" O   ILE A  78 "
   model   vdw
   3.669 3.270
nonbonded pdb=" CG1 VAL A  63 "
          pdb=" CZ  PHE A  68 "
   model   vdw
   3.669 3.760
nonbonded pdb=" CE2 PHE A  68 "
          pdb=" CG1 ILE A  78 "
   model   vdw
   3.670 3.740
nonbonded pdb=" C   GLN A  10 "
          pdb="O    HOH S   8 "
   model   vdw
   3.671 3.270
nonbonded pdb=" OG  SER A  67 "
          pdb=" O   ARG A  80 "
   model   vdw
   3.671 3.040
nonbonded pdb=" O   LEU A  83 "
          pdb=" CB  VAL A  84 "
   model   vdw
   3.671 3.470
nonbonded pdb=" N   LEU A  37 "
          pdb=" CD2 LEU A  37 "
   model   vdw
   3.672 3.540
nonbonded pdb=" C   PRO A  54 "
          pdb=" CB  ALA A  55 "
   model   vdw
   3.672 2.952
nonbonded pdb=" O   ARG A  80 "
          pdb=" NH1 ARG A  82 "
   model   vdw
   3.674 3.120
nonbonded pdb=" OG1 THR A  14 "
          pdb=" N   THR A  15 "
   model   vdw
   3.674 3.120
nonbonded pdb=" O   ILE A  47 "
          pdb=" C   THR A  48 "
   model   vdw
   3.676 3.270
nonbonded pdb=" CD1 ILE A   6 "
          pdb=" NE2 GLN A  31 "
   model   vdw
   3.677 3.540
nonbonded pdb=" C   THR A  48 "
          pdb=" CB  LEU A  49 "
   model   vdw
   3.677 2.936
nonbonded pdb=" C   MSE A  77 "
          pdb=" CG  MSE A  77 "
   model   vdw
   3.679 2.936
nonbonded pdb=" N   GLY A  59 "
          pdb=" N   LEU A  60 "
   model   vdw
   3.679 2.560
nonbonded pdb=" N   LEU A  49 "
          pdb=" CD2 LEU A  49 "
   model   vdw
   3.680 3.540
nonbonded pdb=" CA  GLY A  52 "
          pdb=" CA  GLN A  53 "
   model   vdw
   3.681 3.096
nonbonded pdb=" C   ALA A  55 "
          pdb=" CB  TYR A  56 "
   model   vdw
   3.681 2.936
nonbonded pdb=" C   GLU A   5 "
          pdb=" CG1 ILE A   6 "
   model   vdw
   3.682 3.670
nonbonded pdb=" CD  GLN A  10 "
          pdb=" CA  CYS A  33 "
   model   vdw
   3.682 3.700
nonbonded pdb=" C   PRO A  58 "
          pdb=" C   GLY A  59 "
   model   vdw
   3.682 2.800
nonbonded pdb=" CD2 TYR A  34 "
          pdb=" O   PRO A  42 "
   model   vdw
   3.683 3.340
nonbonded pdb=" C   HIS A  64 "
          pdb=" CB  LEU A  65 "
   model   vdw
   3.683 2.936
nonbonded pdb=" C   LEU A  49 "
          pdb=" NH1 ARG A  80 "
   model   vdw
   3.684 3.350
nonbonded pdb=" CB  GLU A  51 "
          pdb=" OE2 GLU A  51 "
   model   vdw
   3.684 2.752
nonbonded pdb=" CZ  TYR A  34 "
          pdb="O    HOH S  26 "
   model   vdw
   3.684 3.260
nonbonded pdb=" CD2 TYR A  61 "
          pdb=" C   VAL A  84 "
   model   vdw
   3.684 3.570
nonbonded pdb=" N   ALA A  11 "
          pdb=" NE2 GLN A  12 "
   model   vdw
   3.685 3.200
nonbonded pdb=" OE2 GLU A  30 "
          pdb=" CD  LYS A  46 "
   model   vdw
   3.685 3.440
nonbonded pdb=" CD  GLN A  10 "
          pdb=" N   CYS A  33 "
   model   vdw
   3.686 3.350
nonbonded pdb=" N   PRO A  54 "
          pdb=" N   ALA A  55 "
   model   vdw
   3.686 2.560
nonbonded pdb=" C   PRO A   8 "
          pdb=" CG  PRO A   8 "
   model   vdw
   3.686 2.936
nonbonded pdb=" C   LEU A  32 "
          pdb=" O   VAL A  45 "
   model   vdw
   3.687 3.270
nonbonded pdb=" CD1 PHE A  13 "
          pdb=" CB  ASN A  29 "
   model   vdw
   3.688 3.740
nonbonded pdb=" CA  LEU A  49 "
          pdb=" CA  ASP A  50 "
   model   vdw
   3.688 3.120
nonbonded pdb=" N   SER A  75 "
          pdb=" N   LEU A  76 "
   model   vdw
   3.688 2.560
nonbonded pdb=" O   ASP A  36 "
          pdb=" OD1 ASP A  36 "
   model   vdw
   3.688 3.040
nonbonded pdb=" C   VAL A  35 "
          pdb=" N   LEU A  37 "
   model   vdw
   3.689 3.350
nonbonded pdb=" O   GLY A  59 "
          pdb=" C   LEU A  60 "
   model   vdw
   3.690 3.270
nonbonded pdb=" CZ  TYR A  41 "
          pdb=" CG  PRO A  42 "
   model   vdw sym.op.
   3.690 3.660 -x+1,y,-z+1
nonbonded pdb=" CD2 TYR A  56 "
          pdb=" CD1 LEU A  83 "
   model   vdw
   3.690 3.760
nonbonded pdb=" CG2 THR A  48 "
          pdb=" N   LEU A  49 "
   model   vdw
   3.691 3.540
nonbonded pdb=" OG  SER A  75 "
          pdb=" N   LEU A  76 "
   model   vdw
   3.692 3.120
nonbonded pdb=" CG  PHE A  13 "
          pdb=" N   THR A  14 "
   model   vdw
   3.693 3.340
nonbonded pdb=" C   LEU A  32 "
          pdb=" C   CYS A  33 "
   model   vdw
   3.693 2.800
nonbonded pdb=" O   THR A  15 "
          pdb=" O   PRO A   8 "
   model   vdw sym.op.
   3.694 3.040 -x+1/2,y-1/2,-z+1
nonbonded pdb=" O   PRO A   8 "
          pdb=" O   THR A  15 "
   model   vdw sym.op.
   3.694 3.040 -x+1/2,y+1/2,-z+1
nonbonded pdb=" O   VAL A  35 "
          pdb=" C   PRO A  42 "
   model   vdw
   3.695 3.270
nonbonded pdb=" CD2 TYR A  34 "
          pdb=" O   VAL A  43 "
   model   vdw
   3.695 3.340
nonbonded pdb=" CE1 TYR A  41 "
          pdb=" CD  PRO A  42 "
   model   vdw sym.op.
   3.696 3.740 -x+1,y,-z+1
nonbonded pdb=" CD  PRO A  42 "
          pdb=" CE1 TYR A  41 "
   model   vdw sym.op.
   3.696 3.740 -x+1,y,-z+1
nonbonded pdb=" O   CYS A  33 "
          pdb=" CD1 LEU A  44 "
   model   vdw
   3.696 3.460
nonbonded pdb=" O   VAL A  43 "
          pdb=" O   LEU A  44 "
   model   vdw
   3.696 3.040
nonbonded pdb=" N   GLY A  71 "
          pdb=" N   GLN A  72 "
   model   vdw
   3.697 2.560
nonbonded pdb=" O   SER A   9 "
          pdb=" CD  GLN A  12 "
   model   vdw
   3.697 3.270
nonbonded pdb=" N   LEU A  28 "
          pdb=" CD1 LEU A  28 "
   model   vdw
   3.697 3.540
nonbonded pdb=" O   GLN A  31 "
          pdb=" C   LEU A  32 "
   model   vdw
   3.698 3.270
nonbonded pdb=" C   SER A  75 "
          pdb=" CB  LEU A  76 "
   model   vdw
   3.699 2.936
nonbonded pdb=" O   ASP A  50 "
          pdb=" O   GLU A  51 "
   model   vdw
   3.699 3.040
nonbonded pdb=" CZ  TYR A  56 "
          pdb=" N   LEU A  83 "
   model   vdw
   3.699 3.340
nonbonded pdb=" CA  TYR A  56 "
          pdb=" CA  ALA A  57 "
   model   vdw
   3.699 3.120
nonbonded pdb=" CG  GLN A  31 "
          pdb=" O   LEU A  32 "
   model   vdw
   3.701 3.440
nonbonded pdb=" CD2 TYR A  34 "
          pdb=" C   VAL A  43 "
   model   vdw
   3.701 3.570
nonbonded pdb=" OD2 ASP A  50 "
          pdb=" CZ  ARG A  82 "
   model   vdw
   3.701 3.270
nonbonded pdb=" O   GLN A  12 "
          pdb=" CD  GLN A  12 "
   model   vdw
   3.701 3.270
nonbonded pdb=" O   ASP A  50 "
          pdb=" CG  GLN A  53 "
   model   vdw
   3.702 3.440
nonbonded pdb=" C   PRO A  58 "
          pdb=" CG  PRO A  58 "
   model   vdw
   3.702 2.936
nonbonded pdb=" NH2 ARG A  16 "
          pdb=" CA  PRO A  85 "
   model   vdw sym.op.
   3.702 3.550 x,y-1,z
nonbonded pdb=" C   VAL A  43 "
          pdb=" CB  LEU A  44 "
   model   vdw
   3.703 2.936
nonbonded pdb=" O   THR A  14 "
          pdb=" CB  THR A  15 "
   model   vdw
   3.703 3.470
nonbonded pdb=" C   PRO A  42 "
          pdb=" O   VAL A  43 "
   model   vdw
   3.703 3.270
nonbonded pdb=" C   SER A   9 "
          pdb="O    HOH S  23 "
   model   vdw
   3.704 3.270
nonbonded pdb=" CD  GLN A  10 "
          pdb=" O   LEU A  32 "
   model   vdw
   3.704 3.270
nonbonded pdb=" CA  GLN A  31 "
          pdb="O    HOH S   8 "
   model   vdw
   3.705 3.470
nonbonded pdb=" CA  LEU A  76 "
          pdb="O    HOH S   6 "
   model   vdw
   3.705 3.470
nonbonded pdb=" O   PRO A   8 "
          pdb=" CA  THR A  15 "
   model   vdw sym.op.
   3.705 3.470 -x+1/2,y+1/2,-z+1
nonbonded pdb=" NE2 GLN A  10 "
          pdb=" C   LEU A  32 "
   model   vdw
   3.706 3.350
nonbonded pdb=" CB  ALA A  11 "
          pdb=" CG  PRO A  58 "
   model   vdw
   3.706 3.860
nonbonded pdb=" O   LYS A   7 "
          pdb=" C   GLN A  10 "
   model   vdw
   3.706 3.270
nonbonded pdb=" CB  ARG A  80 "
          pdb=" CZ  ARG A  82 "
   model   vdw
   3.707 3.670
nonbonded pdb=" C   LEU A  65 "
          pdb=" CB  SER A  66 "
   model   vdw
   3.707 2.936
nonbonded pdb=" CA  TYR A  61 "
          pdb=" CA  THR A  62 "
   model   vdw
   3.707 3.120
nonbonded pdb=" O   ASP A  36 "
          pdb=" CG  LEU A  65 "
   model   vdw sym.op.
   3.707 3.470 -x+1,y,-z+2
nonbonded pdb=" C   GLN A  12 "
          pdb=" O   PHE A  13 "
   model   vdw
   3.707 3.270
nonbonded pdb=" C   GLN A  12 "
          pdb=" CD  GLN A  12 "
   model   vdw
   3.708 3.500
nonbonded pdb=" C   ILE A   2 "
          pdb=" CG1 ILE A   2 "
   model   vdw
   3.708 2.936
nonbonded pdb=" O   SER A  66 "
          pdb=" OG  SER A  66 "
   model   vdw
   3.708 3.040
nonbonded pdb=" O   SER A   9 "
          pdb=" N   ALA A  11 "
   model   vdw
   3.709 3.120
nonbonded pdb=" CB  ARG A  80 "
          pdb=" NE  ARG A  80 "
   model   vdw
   3.711 2.816
nonbonded pdb=" CA  ALA A  57 "
          pdb=" OH  TYR A  61 "
   model   vdw
   3.711 3.470
nonbonded pdb=" CG  ARG A  80 "
          pdb=" CZ  ARG A  80 "
   model   vdw
   3.713 2.936
nonbonded pdb=" CB  ARG A  16 "
          pdb="O    HOH S  11 "
   model   vdw
   3.714 3.440
nonbonded pdb=" CB  LYS A  69 "
          pdb="O    HOH S  10 "
   model   vdw
   3.714 3.440
nonbonded pdb=" CE  LYS A   7 "
          pdb=" OH  TYR A  41 "
   model   vdw sym.op.
   3.714 3.440 -x+1,y,-z+1
nonbonded pdb=" CB  GLN A  31 "
          pdb=" NE2 GLN A  31 "
   model   vdw
   3.715 2.816
nonbonded pdb=" CA  ILE A   6 "
          pdb=" OE1 GLN A  10 "
   model   vdw
   3.715 3.470
nonbonded pdb=" OH  TYR A  56 "
          pdb=" CB  LEU A  83 "
   model   vdw
   3.715 3.440
nonbonded pdb=" O   SER A  67 "
          pdb=" CA  ASP A  79 "
   model   vdw
   3.715 3.470
nonbonded pdb=" OE2 GLU A  30 "
          pdb=" CE  LYS A  46 "
   model   vdw
   3.716 3.440
nonbonded pdb=" N   GLY A  38 "
          pdb=" CD2 LEU A  65 "
   model   vdw sym.op.
   3.716 3.540 -x+1,y,-z+2
nonbonded pdb=" CB  ASP A  50 "
          pdb=" OE1 GLN A  53 "
   model   vdw
   3.716 3.440
nonbonded pdb=" CA  VAL A  70 "
          pdb="O    HOH S  10 "
   model   vdw
   3.716 3.470
nonbonded pdb=" OG  SER A  66 "
          pdb=" CB  ARG A  82 "
   model   vdw
   3.716 3.440
nonbonded pdb=" CA  LEU A  60 "
          pdb=" CA  TYR A  61 "
   model   vdw
   3.717 3.120
nonbonded pdb=" CA  ASP A  50 "
          pdb=" CA  GLU A  51 "
   model   vdw
   3.718 3.120
nonbonded pdb=" C   THR A  48 "
          pdb=" OG1 THR A  48 "
   model   vdw
   3.719 2.616
nonbonded pdb=" O   HIS A  64 "
          pdb=" CA  SER A  67 "
   model   vdw
   3.720 3.470
nonbonded pdb=" O   ASP A  36 "
          pdb=" C   LEU A  37 "
   model   vdw
   3.720 3.270
nonbonded pdb=" C   ASN A  39 "
          pdb=" CB  GLU A  40 "
   model   vdw
   3.720 2.936
nonbonded pdb=" OE1 GLU A   5 "
          pdb=" NZ  LYS A   7 "
   model   vdw
   3.720 3.120
nonbonded pdb=" CB  SER A  67 "
          pdb=" N   ARG A  82 "
   model   vdw
   3.720 3.520
nonbonded pdb=" O   PHE A  13 "
          pdb=" CB  THR A  14 "
   model   vdw
   3.721 3.470
nonbonded pdb=" O   ARG A  80 "
          pdb=" CG  ARG A  82 "
   model   vdw
   3.721 3.440
nonbonded pdb=" CG1 VAL A   4 "
          pdb=" SG  CYS A  33 "
   model   vdw
   3.721 3.820
nonbonded pdb=" CE2 TYR A  56 "
          pdb=" CD1 LEU A  83 "
   model   vdw
   3.721 3.760
nonbonded pdb=" NH2 ARG A  16 "
          pdb=" C   LEU A  60 "
   model   vdw sym.op.
   3.722 3.350 x,y-1,z
nonbonded pdb=" O   ILE A   6 "
          pdb=" O   GLY A  59 "
   model   vdw
   3.723 3.040
nonbonded pdb=" O   LEU A  76 "
          pdb=" CD1 ILE A  78 "
   model   vdw sym.op.
   3.723 3.460 -x+1,y,-z+2
nonbonded pdb=" CG  LYS A  69 "
          pdb=" CE  MSE A  77 "
   model   vdw
   3.723 3.860
nonbonded pdb=" CZ  TYR A  56 "
          pdb=" CG  LEU A  83 "
   model   vdw
   3.724 3.690
nonbonded pdb=" O   TYR A  61 "
          pdb=" CE1 PHE A  73 "
   model   vdw sym.op.
   3.724 3.340 -x+1,y+1,-z+2
nonbonded pdb=" C   CYS A  33 "
          pdb=" CG  TYR A  34 "
   model   vdw
   3.725 3.490
nonbonded pdb=" CA  ASN A  29 "
          pdb=" ND2 ASN A  29 "
   model   vdw
   3.725 2.840
nonbonded pdb=" OG  SER A  67 "
          pdb=" CZ  PHE A  68 "
   model   vdw
   3.726 3.340
nonbonded pdb=" C   ALA A  11 "
          pdb=" O   GLN A  12 "
   model   vdw
   3.726 3.270
nonbonded pdb=" CA  LYS A   7 "
          pdb="O    HOH S  12 "
   model   vdw
   3.726 3.470
nonbonded pdb=" C   THR A  15 "
          pdb=" O   ARG A  16 "
   model   vdw
   3.726 3.270
nonbonded pdb=" C   TYR A  61 "
          pdb=" O   THR A  62 "
   model   vdw
   3.727 3.270
nonbonded pdb=" OG  SER A  67 "
          pdb=" CE1 PHE A  68 "
   model   vdw
   3.728 3.340
nonbonded pdb=" CD1 LEU A  65 "
          pdb=" CD2 LEU A  37 "
   model   vdw sym.op.
   3.729 3.880 -x+1,y,-z+2
nonbonded pdb=" CD2 LEU A  37 "
          pdb=" CD1 LEU A  65 "
   model   vdw sym.op.
   3.729 3.880 -x+1,y,-z+2
nonbonded pdb=" O   LEU A  65 "
          pdb=" CD1 LEU A  65 "
   model   vdw
   3.729 3.460
nonbonded pdb=" CA  PHE A  13 "
          pdb=" CA  THR A  14 "
   model   vdw
   3.729 3.120
nonbonded pdb=" CA  GLY A  38 "
          pdb=" CA  ASN A  39 "
   model   vdw
   3.729 3.096
nonbonded pdb=" O   GLN A  31 "
          pdb=" CB  ILE A  47 "
   model   vdw
   3.730 3.470
nonbonded pdb=" O   VAL A   4 "
          pdb=" CB  GLU A   5 "
   model   vdw
   3.730 3.440
nonbonded pdb=" CB  PRO A   8 "
          pdb=" CE1 PHE A  13 "
   model   vdw sym.op.
   3.730 3.740 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CA  GLU A  51 "
          pdb=" CA  GLY A  52 "
   model   vdw
   3.731 3.096
nonbonded pdb=" O   LYS A   7 "
          pdb=" N   ALA A  11 "
   model   vdw
   3.731 3.120
nonbonded pdb=" CA  GLU A   5 "
          pdb=" CA  ILE A   6 "
   model   vdw
   3.731 3.120
nonbonded pdb=" C   ARG A  80 "
          pdb=" CB  LEU A  81 "
   model   vdw
   3.731 2.936
nonbonded pdb=" CG  ARG A  16 "
          pdb=" CZ  ARG A  16 "
   model   vdw
   3.731 2.936
nonbonded pdb=" O   ILE A   2 "
          pdb=" C   LYS A   3 "
   model   vdw
   3.732 3.270
nonbonded pdb=" O   SER A  67 "
          pdb=" O   ARG A  80 "
   model   vdw
   3.732 3.040
nonbonded pdb=" CA  ASP A  79 "
          pdb=" CA  ARG A  80 "
   model   vdw
   3.732 3.120
nonbonded pdb=" C   LEU A  28 "
          pdb=" CG  ASN A  29 "
   model   vdw
   3.732 3.500
nonbonded pdb=" O   PRO A   8 "
          pdb=" CB  THR A  14 "
   model   vdw sym.op.
   3.733 3.470 -x+1/2,y+1/2,-z+1
nonbonded pdb=" NH2 ARG A  16 "
          pdb=" CB  PRO A  85 "
   model   vdw sym.op.
   3.733 3.520 x,y-1,z
nonbonded pdb=" O   CYS A  33 "
          pdb=" C   LEU A  44 "
   model   vdw
   3.734 3.270
nonbonded pdb=" CG2 VAL A  43 "
          pdb=" CG2 VAL A  70 "
   model   vdw sym.op.
   3.734 3.880 -x+1,y,-z+2
nonbonded pdb=" CB  ALA A  11 "
          pdb=" CD  PRO A  58 "
   model   vdw
   3.735 3.860
nonbonded pdb=" C   ARG A  80 "
          pdb=" CG  ARG A  80 "
   model   vdw
   3.735 2.936
nonbonded pdb=" CA  HIS A  64 "
          pdb=" O   ARG A  82 "
   model   vdw
   3.735 3.470
nonbonded pdb=" CA  SER A  66 "
          pdb=" CA  SER A  67 "
   model   vdw
   3.737 3.120
nonbonded pdb=" CG  ASP A  36 "
          pdb=" N   LEU A  37 "
   model   vdw
   3.738 3.350
nonbonded pdb=" O   GLY A  59 "
          pdb=" CE1 TYR A  61 "
   model   vdw
   3.738 3.340
nonbonded pdb=" CA  LEU A  76 "
          pdb=" CA  MSE A  77 "
   model   vdw
   3.739 3.120
nonbonded pdb=" C   SER A  66 "
          pdb=" NH1 ARG A  82 "
   model   vdw
   3.739 3.350
nonbonded pdb=" OG1 THR A  14 "
          pdb=" O   GLU A  30 "
   model   vdw
   3.740 3.040
nonbonded pdb=" CB  THR A  15 "
          pdb=" OD1 ASN A  29 "
   model   vdw
   3.741 3.470
nonbonded pdb=" N   LEU A  81 "
          pdb=" CG  LEU A  81 "
   model   vdw
   3.741 2.840
nonbonded pdb=" CA  TYR A  26 "
          pdb=" CA  SER A  27 "
   model   vdw
   3.741 3.120
nonbonded pdb=" CA  CYS A  33 "
          pdb=" CA  TYR A  34 "
   model   vdw
   3.742 3.120
nonbonded pdb=" O   CYS A  33 "
          pdb=" C   TYR A  34 "
   model   vdw
   3.742 3.270
nonbonded pdb=" CG  LYS A  69 "
          pdb=" N   VAL A  70 "
   model   vdw
   3.742 3.520
nonbonded pdb=" O   HIS A  64 "
          pdb=" O   LEU A  65 "
   model   vdw
   3.743 3.040
nonbonded pdb=" CA  ALA A  11 "
          pdb=" CA  GLN A  12 "
   model   vdw
   3.743 3.120
nonbonded pdb=" C   THR A  15 "
          pdb=" OG1 THR A  15 "
   model   vdw
   3.744 2.616
nonbonded pdb=" CG  LYS A   7 "
          pdb=" NZ  LYS A   7 "
   model   vdw
   3.745 2.816
nonbonded pdb=" CD1 ILE A  78 "
          pdb=" CG1 ILE A  78 "
   model   vdw sym.op.
   3.745 3.860 -x+1,y,-z+2
nonbonded pdb=" CG1 ILE A  78 "
          pdb=" CD1 ILE A  78 "
   model   vdw sym.op.
   3.745 3.860 -x+1,y,-z+2
nonbonded pdb=" CA  GLN A  12 "
          pdb=" CA  PHE A  13 "
   model   vdw
   3.745 3.120
nonbonded pdb=" CA  ILE A   6 "
          pdb=" CA  LYS A   7 "
   model   vdw
   3.745 3.120
nonbonded pdb=" CB  PHE A  13 "
          pdb=" CE2 PHE A  13 "
   model   vdw
   3.746 2.992
nonbonded pdb=" CA  THR A  14 "
          pdb=" CA  THR A  15 "
   model   vdw
   3.746 3.120
nonbonded pdb=" CG2 THR A  15 "
          pdb=" OD1 ASN A  29 "
   model   vdw
   3.746 3.460
nonbonded pdb=" C   LEU A  28 "
          pdb=" CG  LEU A  28 "
   model   vdw
   3.747 2.960
nonbonded pdb=" C   THR A  15 "
          pdb=" O   LEU A  28 "
   model   vdw
   3.747 3.270
nonbonded pdb=" CA  LYS A  46 "
          pdb=" CA  ILE A  47 "
   model   vdw
   3.747 3.120
nonbonded pdb=" CA  ALA A  55 "
          pdb=" CA  TYR A  56 "
   model   vdw
   3.748 3.120
nonbonded pdb=" O   CYS A  33 "
          pdb=" CB  TYR A  34 "
   model   vdw
   3.748 3.440
nonbonded pdb=" C   LEU A  49 "
          pdb=" OE1 GLN A  53 "
   model   vdw
   3.748 3.270
nonbonded pdb=" N   HIS A  64 "
          pdb=" CG  HIS A  64 "
   model   vdw
   3.748 2.672
nonbonded pdb=" CB  PHE A  68 "
          pdb=" CE2 PHE A  68 "
   model   vdw
   3.748 2.992
nonbonded pdb=" NE2 GLN A  10 "
          pdb=" C   CYS A  33 "
   model   vdw
   3.748 3.350
nonbonded pdb=" O   ASP A  36 "
          pdb=" CD2 LEU A  37 "
   model   vdw
   3.749 3.460
nonbonded pdb=" CA  THR A  15 "
          pdb=" CA  ARG A  16 "
   model   vdw
   3.749 3.120
nonbonded pdb=" CA  THR A  48 "
          pdb=" CA  LEU A  49 "
   model   vdw
   3.750 3.120
nonbonded pdb=" CA  VAL A   4 "
          pdb=" CA  GLU A   5 "
   model   vdw
   3.751 3.120
nonbonded pdb=" CB  PHE A  13 "
          pdb=" CE1 PHE A  13 "
   model   vdw
   3.751 2.992
nonbonded pdb=" CE2 TYR A  41 "
          pdb=" CD2 TYR A  34 "
   model   vdw sym.op.
   3.752 3.640 -x+1,y,-z+1
nonbonded pdb=" CD2 TYR A  34 "
          pdb=" CE2 TYR A  41 "
   model   vdw sym.op.
   3.752 3.640 -x+1,y,-z+1
nonbonded pdb=" O   GLN A  10 "
          pdb=" O   GLN A  12 "
   model   vdw
   3.752 3.040
nonbonded pdb=" N   ILE A  47 "
          pdb=" CG2 ILE A  47 "
   model   vdw
   3.753 2.832
nonbonded pdb=" CB  TYR A  34 "
          pdb=" O   VAL A  43 "
   model   vdw
   3.753 3.440
nonbonded pdb=" CD  GLN A  10 "
          pdb=" C   LEU A  32 "
   model   vdw
   3.753 3.500
nonbonded pdb=" CA  ALA A  57 "
          pdb=" CA  PRO A  58 "
   model   vdw
   3.753 3.120
nonbonded pdb=" O   THR A  62 "
          pdb=" C   LEU A  83 "
   model   vdw
   3.753 3.270
nonbonded pdb=" O   GLN A  12 "
          pdb=" CB  PHE A  13 "
   model   vdw
   3.754 3.440
nonbonded pdb=" O   ASN A  29 "
          pdb=" CG  GLU A  30 "
   model   vdw
   3.754 3.440
nonbonded pdb=" CA  VAL A  63 "
          pdb=" O   ARG A  82 "
   model   vdw
   3.754 3.470
nonbonded pdb=" CB  GLN A  53 "
          pdb=" CD  PRO A  54 "
   model   vdw
   3.755 3.840
nonbonded pdb=" C   THR A  14 "
          pdb="O    HOH S  11 "
   model   vdw
   3.757 3.270
nonbonded pdb=" C   LEU A  76 "
          pdb=" CG  MSE A  77 "
   model   vdw
   3.758 3.670
nonbonded pdb=" O   LEU A  65 "
          pdb=" O   PHE A  68 "
   model   vdw
   3.758 3.040
nonbonded pdb=" CA  SER A   9 "
          pdb=" CB  THR A  15 "
   model   vdw sym.op.
   3.758 3.900 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CB  THR A  15 "
          pdb=" CA  SER A   9 "
   model   vdw sym.op.
   3.758 3.900 -x+1/2,y-1/2,-z+1
nonbonded pdb=" O   ALA A  11 "
          pdb=" CB  GLN A  12 "
   model   vdw
   3.758 3.440
nonbonded pdb=" O   SER A  27 "
          pdb=" CB  LEU A  28 "
   model   vdw
   3.760 3.440
nonbonded pdb=" C   ARG A  16 "
          pdb=" O   SER A  17 "
   model   vdw
   3.760 3.270
nonbonded pdb=" O   GLU A   5 "
          pdb=" OE1 GLN A  10 "
   model   vdw
   3.760 3.040
nonbonded pdb=" CB  PHE A  68 "
          pdb=" CE1 PHE A  68 "
   model   vdw
   3.760 2.992
nonbonded pdb=" CA  GLY A  71 "
          pdb="O    HOH S   1 "
   model   vdw sym.op.
   3.761 3.440 -x,y+1,-z+1
nonbonded pdb=" CE1 PHE A  13 "
          pdb=" ND2 ASN A  29 "
   model   vdw
   3.761 3.420
nonbonded pdb=" O   GLU A   5 "
          pdb=" C   CYS A  33 "
   model   vdw
   3.761 3.270
nonbonded pdb=" CA  ARG A  82 "
          pdb=" CD  ARG A  82 "
   model   vdw
   3.761 3.096
nonbonded pdb=" CD2 TYR A  61 "
          pdb=" N   PRO A  85 "
   model   vdw
   3.762 3.420
nonbonded pdb=" C   VAL A   4 "
          pdb=" O   TYR A  34 "
   model   vdw
   3.762 3.270
nonbonded pdb=" C   GLN A  72 "
          pdb=" CG  PHE A  73 "
   model   vdw
   3.762 3.490
nonbonded pdb=" CB  TYR A  61 "
          pdb=" CE2 TYR A  61 "
   model   vdw
   3.763 2.992
nonbonded pdb=" N   LEU A  44 "
          pdb=" CG  LEU A  44 "
   model   vdw
   3.763 2.840
nonbonded pdb=" CA  LYS A   7 "
          pdb=" OE1 GLN A  10 "
   model   vdw
   3.764 3.470
nonbonded pdb=" O   ILE A  47 "
          pdb=" N   LEU A  49 "
   model   vdw
   3.764 3.120
nonbonded pdb=" C   SER A  67 "
          pdb=" CD1 PHE A  68 "
   model   vdw
   3.764 3.570
nonbonded pdb=" CE2 TYR A  41 "
          pdb=" CE2 TYR A  34 "
   model   vdw sym.op.
   3.765 3.640 -x+1,y,-z+1
nonbonded pdb=" CE2 TYR A  34 "
          pdb=" CE2 TYR A  41 "
   model   vdw sym.op.
   3.765 3.640 -x+1,y,-z+1
nonbonded pdb=" O   LYS A   7 "
          pdb=" CA  SER A   9 "
   model   vdw
   3.765 3.470
nonbonded pdb=" N   VAL A  70 "
          pdb=" CG1 VAL A  70 "
   model   vdw
   3.765 2.832
nonbonded pdb=" C   ALA A  55 "
          pdb=" N   ALA A  57 "
   model   vdw
   3.765 3.350
nonbonded pdb=" C   PHE A  68 "
          pdb=" O   MSE A  77 "
   model   vdw
   3.765 3.270
nonbonded pdb=" CA  LYS A  46 "
          pdb=" CD  LYS A  46 "
   model   vdw
   3.766 3.096
nonbonded pdb=" CA  GLY A  71 "
          pdb=" CA  GLN A  72 "
   model   vdw
   3.766 3.096
nonbonded pdb=" CB  TYR A  34 "
          pdb=" CE1 TYR A  34 "
   model   vdw
   3.766 2.992
nonbonded pdb=" CA  VAL A  63 "
          pdb=" CA  HIS A  64 "
   model   vdw
   3.766 3.120
nonbonded pdb=" CA  ASP A  50 "
          pdb=" OE1 GLN A  53 "
   model   vdw
   3.767 3.470
nonbonded pdb=" CA  LEU A  32 "
          pdb=" CA  CYS A  33 "
   model   vdw
   3.767 3.120
nonbonded pdb=" C   LYS A  69 "
          pdb=" N   GLY A  71 "
   model   vdw
   3.767 3.350
nonbonded pdb=" CA  ILE A  47 "
          pdb=" CA  THR A  48 "
   model   vdw
   3.767 3.120
nonbonded pdb=" CG  LYS A   7 "
          pdb=" OE1 GLN A  10 "
   model   vdw
   3.767 3.440
nonbonded pdb=" OG  SER A  67 "
          pdb=" CG2 ILE A  78 "
   model   vdw
   3.768 3.460
nonbonded pdb=" O   LYS A  46 "
          pdb=" C   ILE A  47 "
   model   vdw
   3.769 3.270
nonbonded pdb=" N   LYS A  46 "
          pdb=" CG  LYS A  46 "
   model   vdw
   3.769 2.816
nonbonded pdb=" O   LYS A  69 "
          pdb=" CA  LEU A  76 "
   model   vdw
   3.769 3.470
nonbonded pdb=" OE1 GLN A  10 "
          pdb=" O   LEU A  32 "
   model   vdw
   3.769 3.040
nonbonded pdb=" O   TYR A  41 "
          pdb=" N   VAL A  43 "
   model   vdw
   3.769 3.120
nonbonded pdb=" O   PHE A  13 "
          pdb=" C   THR A  14 "
   model   vdw
   3.769 3.270
nonbonded pdb=" CA  GLU A  30 "
          pdb=" CA  GLN A  31 "
   model   vdw
   3.770 3.120
nonbonded pdb=" CB  ILE A   2 "
          pdb="O    HOH S  19 "
   model   vdw
   3.770 3.470
nonbonded pdb=" O   SER A  67 "
          pdb=" CB  ASP A  79 "
   model   vdw
   3.770 3.440
nonbonded pdb=" O   VAL A  35 "
          pdb=" CG1 VAL A  35 "
   model   vdw
   3.770 3.460
nonbonded pdb=" C   ASP A  79 "
          pdb=" CG  ARG A  80 "
   model   vdw
   3.770 3.670
nonbonded pdb=" O   PRO A  42 "
          pdb=" CD  PRO A  42 "
   model   vdw
   3.771 3.440
nonbonded pdb=" OE1 GLN A  10 "
          pdb=" CD1 TYR A  34 "
   model   vdw
   3.771 3.340
nonbonded pdb=" CG  GLN A  72 "
          pdb=" N   PHE A  73 "
   model   vdw
   3.771 3.520
nonbonded pdb=" CE2 TYR A  41 "
          pdb=" CG  TYR A  34 "
   model   vdw sym.op.
   3.771 3.560 -x+1,y,-z+1
nonbonded pdb=" CG  TYR A  34 "
          pdb=" CE2 TYR A  41 "
   model   vdw sym.op.
   3.771 3.560 -x+1,y,-z+1
nonbonded pdb=" CB  TYR A  61 "
          pdb=" CE1 TYR A  61 "
   model   vdw
   3.772 2.992
nonbonded pdb=" C   LEU A  37 "
          pdb=" CD2 LEU A  65 "
   model   vdw sym.op.
   3.772 3.690 -x+1,y,-z+2
nonbonded pdb=" C   LYS A  46 "
          pdb=" CG1 ILE A  47 "
   model   vdw
   3.772 3.670
nonbonded pdb=" CA  ASN A  39 "
          pdb=" CA  GLU A  40 "
   model   vdw
   3.773 3.120
nonbonded pdb=" CD1 TYR A  41 "
          pdb=" CD1 TYR A  41 "
   model   vdw sym.op.
   3.773 3.640 -x+1,y,-z+1
nonbonded pdb=" CB  TYR A  56 "
          pdb=" CE2 TYR A  56 "
   model   vdw
   3.774 2.992
nonbonded pdb=" O   ASP A  36 "
          pdb=" N   GLY A  38 "
   model   vdw
   3.774 3.120
nonbonded pdb=" CA  MSE A  77 "
          pdb=" CA  ILE A  78 "
   model   vdw
   3.774 3.120
nonbonded pdb=" C   GLY A  52 "
          pdb=" O   GLN A  53 "
   model   vdw
   3.774 3.270
nonbonded pdb=" CB  THR A  14 "
          pdb="O    HOH S  11 "
   model   vdw
   3.775 3.470
nonbonded pdb=" O   SER A  67 "
          pdb=" C   PHE A  68 "
   model   vdw
   3.775 3.270
nonbonded pdb=" CA  GLN A  53 "
          pdb=" CA  PRO A  54 "
   model   vdw
   3.775 3.120
nonbonded pdb=" CA  GLN A  10 "
          pdb=" CA  ALA A  11 "
   model   vdw
   3.775 3.120
nonbonded pdb=" CD1 PHE A  13 "
          pdb=" OG1 THR A  15 "
   model   vdw
   3.775 3.340
nonbonded pdb=" CA  LEU A  44 "
          pdb=" CA  VAL A  45 "
   model   vdw
   3.775 3.120
nonbonded pdb=" C   LEU A  76 "
          pdb=" O   MSE A  77 "
   model   vdw
   3.775 3.270
nonbonded pdb=" OD2 ASP A  50 "
          pdb=" CD  ARG A  82 "
   model   vdw
   3.776 3.440
nonbonded pdb=" C   ASP A  50 "
          pdb=" CD  GLU A  51 "
   model   vdw
   3.776 3.500
nonbonded pdb=" CB  TYR A  56 "
          pdb=" CE1 TYR A  56 "
   model   vdw
   3.776 2.992
nonbonded pdb=" OD2 ASP A  79 "
          pdb=" CZ  ARG A  82 "
   model   vdw
   3.776 3.270
nonbonded pdb=" CD2 HIS A  64 "
          pdb=" CG1 VAL A  84 "
   model   vdw
   3.777 3.680
nonbonded pdb=" O   VAL A  63 "
          pdb=" O   HIS A  64 "
   model   vdw
   3.777 3.040
nonbonded pdb=" C   THR A  62 "
          pdb=" CG2 VAL A  63 "
   model   vdw
   3.777 3.690
nonbonded pdb=" CB  GLU A  30 "
          pdb=" O   ILE A  47 "
   model   vdw
   3.778 3.440
nonbonded pdb=" OE1 GLN A  31 "
          pdb=" CA  ALA A  55 "
   model   vdw
   3.778 3.470
nonbonded pdb=" C   TYR A  56 "
          pdb=" OH  TYR A  61 "
   model   vdw
   3.778 3.270
nonbonded pdb=" CA  GLY A  59 "
          pdb=" CA  LEU A  60 "
   model   vdw
   3.778 3.096
nonbonded pdb=" CA  ASN A  39 "
          pdb="O    HOH S   9 "
   model   vdw
   3.778 3.470
nonbonded pdb=" N   THR A  48 "
          pdb=" CG2 THR A  48 "
   model   vdw
   3.778 2.832
nonbonded pdb=" CA  LEU A  28 "
          pdb=" CA  ASN A  29 "
   model   vdw
   3.778 3.120
nonbonded pdb=" CA  PRO A  54 "
          pdb=" CA  ALA A  55 "
   model   vdw
   3.779 3.120
nonbonded pdb=" N   THR A  15 "
          pdb=" CG2 THR A  15 "
   model   vdw
   3.779 2.832
nonbonded pdb=" O   ASN A  29 "
          pdb=" CA  LEU A  49 "
   model   vdw
   3.779 3.470
nonbonded pdb=" O   GLN A  31 "
          pdb=" CG  LYS A  46 "
   model   vdw
   3.779 3.440
nonbonded pdb=" CA  PRO A  58 "
          pdb=" CA  GLY A  59 "
   model   vdw
   3.780 3.096
nonbonded pdb=" O   GLN A  72 "
          pdb=" C   PHE A  73 "
   model   vdw
   3.780 3.270
nonbonded pdb=" NZ  LYS A   7 "
          pdb=" OH  TYR A  41 "
   model   vdw sym.op.
   3.780 3.120 -x+1,y,-z+1
nonbonded pdb=" CA  VAL A   4 "
          pdb=" O   TYR A  61 "
   model   vdw
   3.781 3.470
nonbonded pdb=" C   ILE A   6 "
          pdb=" OE1 GLN A  10 "
   model   vdw
   3.781 3.270
nonbonded pdb=" O   ASN A  29 "
          pdb=" CB  GLU A  30 "
   model   vdw
   3.781 3.440
nonbonded pdb=" O   LEU A  60 "
          pdb=" CD1 TYR A  61 "
   model   vdw
   3.781 3.340
nonbonded pdb=" CA  LEU A  37 "
          pdb=" CA  GLY A  38 "
   model   vdw
   3.781 3.096
nonbonded pdb=" N   VAL A  45 "
          pdb=" CG1 VAL A  45 "
   model   vdw
   3.782 2.832
nonbonded pdb=" C   VAL A  45 "
          pdb=" O   GLY A  74 "
   model   vdw sym.op.
   3.783 3.270 -x+1,y,-z+2
nonbonded pdb=" O   THR A  14 "
          pdb="O    HOH S  11 "
   model   vdw
   3.783 3.040
nonbonded pdb=" CA  SER A   9 "
          pdb=" CA  GLN A  10 "
   model   vdw
   3.783 3.120
nonbonded pdb=" CD  GLN A  31 "
          pdb=" N   TYR A  56 "
   model   vdw
   3.784 3.350
nonbonded pdb=" NH2 ARG A  16 "
          pdb=" CD2 TYR A  61 "
   model   vdw sym.op.
   3.784 3.420 x,y-1,z
nonbonded pdb=" CG1 VAL A  63 "
          pdb=" CB  SER A  67 "
   model   vdw
   3.784 3.860
nonbonded pdb=" C   VAL A  43 "
          pdb=" CG1 VAL A  43 "
   model   vdw
   3.784 2.952
nonbonded pdb=" OE1 GLN A  31 "
          pdb=" CB  TYR A  56 "
   model   vdw
   3.785 3.440
nonbonded pdb=" O   VAL A   4 "
          pdb=" CG1 VAL A   4 "
   model   vdw
   3.785 3.460
nonbonded pdb=" CB  LEU A  32 "
          pdb="O    HOH S   8 "
   model   vdw
   3.786 3.440
nonbonded pdb=" N   VAL A  63 "
          pdb=" CG1 VAL A  63 "
   model   vdw
   3.786 2.832
nonbonded pdb=" CB  PHE A  73 "
          pdb=" CE1 PHE A  73 "
   model   vdw
   3.786 2.992
nonbonded pdb=" C   ILE A  78 "
          pdb=" O   ASP A  79 "
   model   vdw
   3.786 3.270
nonbonded pdb=" NE2 GLN A  10 "
          pdb=" CB  LEU A  32 "
   model   vdw
   3.786 3.520
nonbonded pdb=" N   ILE A   6 "
          pdb=" CG2 ILE A   6 "
   model   vdw
   3.787 2.832
nonbonded pdb=" OG  SER A   9 "
          pdb=" CD  GLU A  40 "
   model   vdw sym.op.
   3.787 3.270 -x+1,y,-z+1
nonbonded pdb=" CD  GLU A  40 "
          pdb=" OG  SER A   9 "
   model   vdw sym.op.
   3.787 3.270 -x+1,y,-z+1
nonbonded pdb=" N   GLU A   5 "
          pdb=" CG  GLU A   5 "
   model   vdw
   3.787 2.816
nonbonded pdb=" CG  ASN A  39 "
          pdb="O    HOH S   9 "
   model   vdw
   3.788 3.270
nonbonded pdb=" CA  PRO A  42 "
          pdb="O    HOH S   9 "
   model   vdw
   3.788 3.470
nonbonded pdb=" N   ASP A  79 "
          pdb=" CG  ASP A  79 "
   model   vdw
   3.788 2.680
nonbonded pdb=" C   PHE A  68 "
          pdb=" O   LYS A  69 "
   model   vdw
   3.788 3.270
nonbonded pdb=" N   ASP A  36 "
          pdb=" CG  ASP A  36 "
   model   vdw
   3.789 2.680
nonbonded pdb=" C   CYS A  33 "
          pdb=" CD1 TYR A  34 "
   model   vdw
   3.789 3.570
nonbonded pdb=" CB  TYR A  26 "
          pdb=" CE2 TYR A  26 "
   model   vdw
   3.789 2.992
nonbonded pdb=" O   THR A  48 "
          pdb=" NH1 ARG A  80 "
   model   vdw
   3.789 3.120
nonbonded pdb=" CD1 ILE A  47 "
          pdb=" CD1 LEU A  83 "
   model   vdw
   3.790 3.880
nonbonded pdb=" CA  LYS A  69 "
          pdb=" CA  VAL A  70 "
   model   vdw
   3.791 3.120
nonbonded pdb=" CA  LEU A  32 "
          pdb=" CD1 LEU A  32 "
   model   vdw
   3.792 3.112
nonbonded pdb=" CA  SER A  27 "
          pdb=" CA  LEU A  28 "
   model   vdw
   3.792 3.120
nonbonded pdb=" O   CYS A  33 "
          pdb=" CG  TYR A  34 "
   model   vdw
   3.792 3.260
nonbonded pdb=" CA  ARG A  82 "
          pdb=" CA  LEU A  83 "
   model   vdw
   3.792 3.120
nonbonded pdb=" OH  TYR A  56 "
          pdb=" CA  ARG A  82 "
   model   vdw
   3.792 3.470
nonbonded pdb=" C   ILE A  47 "
          pdb=" N   LEU A  49 "
   model   vdw
   3.793 3.350
nonbonded pdb=" CB  TYR A  41 "
          pdb=" CE2 TYR A  41 "
   model   vdw
   3.793 2.992
nonbonded pdb=" CA  VAL A  43 "
          pdb=" CA  LEU A  44 "
   model   vdw
   3.793 3.120
nonbonded pdb=" C   VAL A  63 "
          pdb=" O   ARG A  82 "
   model   vdw
   3.793 3.270
nonbonded pdb=" N   LEU A  28 "
          pdb=" CD2 LEU A  28 "
   model   vdw
   3.793 3.540
nonbonded pdb=" O   THR A  62 "
          pdb=" N   HIS A  64 "
   model   vdw
   3.794 3.120
nonbonded pdb=" CA  PRO A   8 "
          pdb=" CA  SER A   9 "
   model   vdw
   3.794 3.120
nonbonded pdb=" CB  PRO A   8 "
          pdb=" OG1 THR A  15 "
   model   vdw sym.op.
   3.794 3.440 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CA  TYR A  34 "
          pdb=" CA  VAL A  35 "
   model   vdw
   3.795 3.120
nonbonded pdb=" O   GLU A  40 "
          pdb=" CD2 TYR A  41 "
   model   vdw
   3.796 3.340
nonbonded pdb=" CA  PHE A  73 "
          pdb=" CA  GLY A  74 "
   model   vdw
   3.796 3.096
nonbonded pdb=" NE2 GLN A  53 "
          pdb=" CE1 TYR A  56 "
   model   vdw
   3.796 3.420
nonbonded pdb=" CA  GLU A  40 "
          pdb=" CA  TYR A  41 "
   model   vdw
   3.796 3.120
nonbonded pdb=" CB  ARG A  82 "
          pdb=" NE  ARG A  82 "
   model   vdw
   3.796 2.816
nonbonded pdb=" CA  SER A  67 "
          pdb=" CA  PHE A  68 "
   model   vdw
   3.796 3.120
nonbonded pdb=" CG2 ILE A   2 "
          pdb=" CG2 VAL A   4 "
   model   vdw
   3.797 3.880
nonbonded pdb=" CB  PHE A  73 "
          pdb=" CE2 PHE A  73 "
   model   vdw
   3.797 2.992
nonbonded pdb=" CA  VAL A  35 "
          pdb=" CA  ASP A  36 "
   model   vdw
   3.797 3.120
nonbonded pdb=" CB  LYS A   7 "
          pdb=" CE  LYS A   7 "
   model   vdw
   3.797 3.072
nonbonded pdb=" O   LYS A   3 "
          pdb=" CB  VAL A   4 "
   model   vdw
   3.798 3.470
nonbonded pdb=" C   SER A  17 "
          pdb=" O   TYR A  26 "
   model   vdw
   3.798 3.270
nonbonded pdb=" O   ARG A  16 "
          pdb=" CA  LEU A  28 "
   model   vdw
   3.798 3.470
nonbonded pdb=" CG1 VAL A  45 "
          pdb=" O   LYS A  46 "
   model   vdw
   3.798 3.460
nonbonded pdb=" CG1 VAL A  70 "
          pdb=" O   GLY A  71 "
   model   vdw
   3.799 3.460
nonbonded pdb=" N   ASP A  50 "
          pdb=" OD2 ASP A  50 "
   model   vdw
   3.799 3.120
nonbonded pdb=" O   GLU A   5 "
          pdb=" O   TYR A  34 "
   model   vdw
   3.799 3.040
nonbonded pdb=" CA  PHE A  68 "
          pdb=" CA  LYS A  69 "
   model   vdw
   3.799 3.120
nonbonded pdb=" N   ASP A  50 "
          pdb=" CD  GLN A  53 "
   model   vdw
   3.800 3.350
nonbonded pdb=" OD1 ASP A  50 "
          pdb=" CZ  ARG A  80 "
   model   vdw
   3.800 3.270
nonbonded pdb=" CE2 TYR A  41 "
          pdb=" CZ  TYR A  34 "
   model   vdw sym.op.
   3.800 3.560 -x+1,y,-z+1
nonbonded pdb=" CZ  TYR A  34 "
          pdb=" CE2 TYR A  41 "
   model   vdw sym.op.
   3.800 3.560 -x+1,y,-z+1
nonbonded pdb=" N   LEU A  65 "
          pdb=" CG  LEU A  65 "
   model   vdw
   3.801 2.840
nonbonded pdb=" CB  ARG A  80 "
          pdb=" NH2 ARG A  82 "
   model   vdw
   3.801 3.520
nonbonded pdb=" CB  LEU A  37 "
          pdb="O    HOH S   9 "
   model   vdw
   3.802 3.440
nonbonded pdb=" CA  LEU A  83 "
          pdb=" CA  VAL A  84 "
   model   vdw
   3.802 3.120
nonbonded pdb=" C   GLN A  31 "
          pdb="O    HOH S   8 "
   model   vdw
   3.803 3.270
nonbonded pdb=" CA  VAL A  45 "
          pdb=" CA  LYS A  46 "
   model   vdw
   3.803 3.120
nonbonded pdb=" NH2 ARG A  16 "
          pdb=" N   LEU A  60 "
   model   vdw sym.op.
   3.804 3.200 x,y-1,z
nonbonded pdb=" OE1 GLN A  31 "
          pdb=" CB  ALA A  55 "
   model   vdw
   3.804 3.460
nonbonded pdb=" C   THR A  62 "
          pdb=" O   VAL A  63 "
   model   vdw
   3.804 3.270
nonbonded pdb=" CG  ASP A  50 "
          pdb=" NE  ARG A  82 "
   model   vdw
   3.805 3.350
nonbonded pdb=" CE2 TYR A  41 "
          pdb=" CD1 TYR A  34 "
   model   vdw sym.op.
   3.805 3.640 -x+1,y,-z+1
nonbonded pdb=" CD1 TYR A  34 "
          pdb=" CE2 TYR A  41 "
   model   vdw sym.op.
   3.805 3.640 -x+1,y,-z+1
nonbonded pdb=" CB  TYR A  26 "
          pdb=" CE1 TYR A  26 "
   model   vdw
   3.805 2.992
nonbonded pdb=" CA  PRO A  42 "
          pdb=" CA  VAL A  43 "
   model   vdw
   3.805 3.120
nonbonded pdb=" N   ILE A   2 "
          pdb=" CG2 ILE A   2 "
   model   vdw
   3.805 2.832
nonbonded pdb=" CA  HIS A  64 "
          pdb=" CA  LEU A  65 "
   model   vdw
   3.806 3.120
nonbonded pdb=" N   ILE A  78 "
          pdb=" CG2 ILE A  78 "
   model   vdw
   3.806 2.832
nonbonded pdb=" C   LEU A  32 "
          pdb=" CG  LEU A  32 "
   model   vdw
   3.806 2.960
nonbonded pdb=" CA  ASP A  36 "
          pdb=" CA  LEU A  37 "
   model   vdw
   3.807 3.120
nonbonded pdb=" C   LYS A  69 "
          pdb=" CG2 VAL A  70 "
   model   vdw
   3.807 3.690
nonbonded pdb=" N   LYS A   3 "
          pdb=" CG  LYS A   3 "
   model   vdw
   3.807 2.816
nonbonded pdb=" C   ARG A  82 "
          pdb=" CG  LEU A  83 "
   model   vdw
   3.807 3.700
nonbonded pdb=" CA  GLN A  31 "
          pdb=" CA  LEU A  32 "
   model   vdw
   3.808 3.120
nonbonded pdb=" CA  THR A  62 "
          pdb=" CA  VAL A  63 "
   model   vdw
   3.808 3.120
nonbonded pdb=" C   LEU A  81 "
          pdb=" CG  ARG A  82 "
   model   vdw
   3.808 3.670
nonbonded pdb=" CD2 TYR A  34 "
          pdb=" N   LEU A  44 "
   model   vdw
   3.808 3.420
nonbonded pdb=" C   GLY A  38 "
          pdb=" CG  ASN A  39 "
   model   vdw
   3.808 3.500
nonbonded pdb=" O   SER A  66 "
          pdb=" CD  ARG A  82 "
   model   vdw
   3.809 3.440
nonbonded pdb=" CA  ILE A   2 "
          pdb=" CA  LYS A   3 "
   model   vdw
   3.810 3.120
nonbonded pdb=" CA  GLN A  72 "
          pdb=" CA  PHE A  73 "
   model   vdw
   3.810 3.120
nonbonded pdb=" N   VAL A  35 "
          pdb=" CG1 VAL A  35 "
   model   vdw
   3.810 2.832
nonbonded pdb=" CA  LEU A  81 "
          pdb=" CA  ARG A  82 "
   model   vdw
   3.810 3.120
nonbonded pdb=" CA  VAL A  70 "
          pdb=" CA  GLY A  71 "
   model   vdw
   3.810 3.096
nonbonded pdb=" O   LYS A  46 "
          pdb=" CA  SER A  75 "
   model   vdw sym.op.
   3.810 3.470 -x+1,y,-z+2
nonbonded pdb=" C   ASP A  36 "
          pdb=" CG  LEU A  37 "
   model   vdw
   3.811 3.700
nonbonded pdb=" CA  ASN A  29 "
          pdb=" CA  GLU A  30 "
   model   vdw
   3.811 3.120
nonbonded pdb=" O   ILE A   2 "
          pdb="O    HOH S  19 "
   model   vdw
   3.812 3.040
nonbonded pdb=" C   VAL A  43 "
          pdb=" N   VAL A  45 "
   model   vdw
   3.812 3.350
nonbonded pdb=" CE2 TYR A  34 "
          pdb=" CD2 TYR A  41 "
   model   vdw sym.op.
   3.813 3.640 -x+1,y,-z+1
nonbonded pdb=" CD2 TYR A  41 "
          pdb=" CE2 TYR A  34 "
   model   vdw sym.op.
   3.813 3.640 -x+1,y,-z+1
nonbonded pdb=" CA  LEU A  37 "
          pdb=" CD2 LEU A  65 "
   model   vdw sym.op.
   3.813 3.890 -x+1,y,-z+2
nonbonded pdb=" CB  LYS A   7 "
          pdb=" OE2 GLU A  40 "
   model   vdw sym.op.
   3.814 3.440 -x+1,y,-z+1
nonbonded pdb=" C   SER A  17 "
          pdb=" CZ  TYR A  26 "
   model   vdw
   3.814 3.490
nonbonded pdb=" O   THR A  62 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   3.814 3.460
nonbonded pdb=" CA  LEU A  44 "
          pdb=" CD2 LEU A  44 "
   model   vdw
   3.815 3.112
nonbonded pdb=" C   VAL A   4 "
          pdb=" O   TYR A  61 "
   model   vdw
   3.815 3.270
nonbonded pdb=" O   ALA A  11 "
          pdb=" CB  ALA A  55 "
   model   vdw
   3.815 3.460
nonbonded pdb=" C   ILE A  47 "
          pdb=" CG1 ILE A  47 "
   model   vdw
   3.816 2.936
nonbonded pdb=" C   ASP A  50 "
          pdb=" CG  ASP A  50 "
   model   vdw
   3.816 2.800
nonbonded pdb=" CD2 LEU A  49 "
          pdb=" CD2 TYR A  56 "
   model   vdw
   3.816 3.760
nonbonded pdb=" CA  LEU A  65 "
          pdb=" CA  SER A  66 "
   model   vdw
   3.816 3.120
nonbonded pdb=" N   PHE A  68 "
          pdb=" CD2 PHE A  68 "
   model   vdw
   3.816 3.420
nonbonded pdb=" CG  LYS A  46 "
          pdb=" NZ  LYS A  46 "
   model   vdw
   3.816 2.816
nonbonded pdb=" O   LEU A  37 "
          pdb=" OD1 ASN A  39 "
   model   vdw
   3.816 3.040
nonbonded pdb=" C   LEU A  44 "
          pdb="O    HOH S  25 "
   model   vdw
   3.816 3.270
nonbonded pdb=" CA  ILE A  78 "
          pdb=" CA  ASP A  79 "
   model   vdw
   3.817 3.120
nonbonded pdb=" C   TYR A  34 "
          pdb=" O   VAL A  35 "
   model   vdw
   3.819 3.270
nonbonded pdb=" C   ASN A  39 "
          pdb=" O   GLU A  40 "
   model   vdw
   3.819 3.270
nonbonded pdb=" CA  ARG A  80 "
          pdb=" CA  LEU A  81 "
   model   vdw
   3.819 3.120
nonbonded pdb=" O   GLN A  12 "
          pdb=" C   PHE A  13 "
   model   vdw
   3.819 3.270
nonbonded pdb=" O   PRO A   8 "
          pdb=" CB  ALA A  11 "
   model   vdw
   3.819 3.460
nonbonded pdb=" C   ILE A  78 "
          pdb=" CG1 ILE A  78 "
   model   vdw
   3.820 2.936
nonbonded pdb=" NE2 GLN A  31 "
          pdb=" C   TYR A  56 "
   model   vdw
   3.820 3.350
nonbonded pdb=" CA  ARG A  16 "
          pdb=" CA  SER A  17 "
   model   vdw
   3.820 3.120
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" O   LYS A   7 "
   model   vdw
   3.821 3.460
nonbonded pdb=" CE1 TYR A  56 "
          pdb=" O   LEU A  83 "
   model   vdw
   3.821 3.340
nonbonded pdb=" CA  LYS A   3 "
          pdb=" CA  VAL A   4 "
   model   vdw
   3.822 3.120
nonbonded pdb=" CE2 TYR A  41 "
          pdb=" CE1 TYR A  34 "
   model   vdw sym.op.
   3.822 3.640 -x+1,y,-z+1
nonbonded pdb=" CE1 TYR A  34 "
          pdb=" CE2 TYR A  41 "
   model   vdw sym.op.
   3.822 3.640 -x+1,y,-z+1
nonbonded pdb=" C   VAL A  63 "
          pdb=" CG2 VAL A  63 "
   model   vdw
   3.823 2.952
nonbonded pdb=" O   GLY A  52 "
          pdb=" N   PRO A  54 "
   model   vdw
   3.823 3.120
nonbonded pdb=" C   ASP A  79 "
          pdb=" OD2 ASP A  79 "
   model   vdw
   3.823 3.270
nonbonded pdb=" CA  VAL A  84 "
          pdb=" CA  PRO A  85 "
   model   vdw
   3.824 3.120
nonbonded pdb=" CA  LYS A   7 "
          pdb=" CA  PRO A   8 "
   model   vdw
   3.824 3.120
nonbonded pdb=" CB  GLU A   5 "
          pdb=" O   GLY A  59 "
   model   vdw
   3.825 3.440
nonbonded pdb=" CB  TYR A  34 "
          pdb=" CE2 TYR A  34 "
   model   vdw
   3.825 2.992
nonbonded pdb=" SG  CYS A  33 "
          pdb=" CG1 VAL A  45 "
   model   vdw
   3.825 3.820
nonbonded pdb=" C   VAL A  70 "
          pdb=" O   SER A  75 "
   model   vdw
   3.825 3.270
nonbonded pdb=" CB  MSE A  77 "
          pdb="O    HOH S  13 "
   model   vdw
   3.826 3.440
nonbonded pdb="O    HOH S  13 "
          pdb=" CB  MSE A  77 "
   model   vdw sym.op.
   3.826 3.440 -x+1,y,-z+2
nonbonded pdb=" CB  MSE A  77 "
          pdb="O    HOH S  13 "
   model   vdw sym.op.
   3.826 3.440 -x+1,y,-z+2
nonbonded pdb=" CB  TYR A  41 "
          pdb=" CE1 TYR A  41 "
   model   vdw
   3.826 2.992
nonbonded pdb=" CE2 TYR A  56 "
          pdb=" CG  LEU A  83 "
   model   vdw
   3.827 3.770
nonbonded pdb=" CG2 THR A  48 "
          pdb=" NE  ARG A  80 "
   model   vdw
   3.827 3.540
nonbonded pdb=" C   ASP A  50 "
          pdb=" OE1 GLU A  51 "
   model   vdw
   3.827 3.270
nonbonded pdb=" C   ASN A  39 "
          pdb=" CG  ASN A  39 "
   model   vdw
   3.827 2.800
nonbonded pdb=" O   ILE A   2 "
          pdb=" CZ  PHE A  73 "
   model   vdw sym.op.
   3.828 3.340 -x+1,y+1,-z+2
nonbonded pdb=" C   VAL A  45 "
          pdb=" CG2 VAL A  45 "
   model   vdw
   3.828 2.952
nonbonded pdb=" CA  SER A  75 "
          pdb=" CA  LEU A  76 "
   model   vdw
   3.828 3.120
nonbonded pdb=" O   ALA A  11 "
          pdb=" C   GLN A  12 "
   model   vdw
   3.828 3.270
nonbonded pdb=" CA  PRO A   8 "
          pdb=" CG  PRO A  58 "
   model   vdw
   3.828 3.870
nonbonded pdb=" CA  TYR A  41 "
          pdb=" CA  PRO A  42 "
   model   vdw
   3.829 3.120
nonbonded pdb=" OH  TYR A  56 "
          pdb=" CA  LEU A  83 "
   model   vdw
   3.829 3.470
nonbonded pdb=" OG  SER A  67 "
          pdb=" CE2 PHE A  68 "
   model   vdw
   3.832 3.340
nonbonded pdb=" OE1 GLN A  31 "
          pdb=" CD2 LEU A  49 "
   model   vdw
   3.832 3.460
nonbonded pdb=" CE1 HIS A  64 "
          pdb=" N   SER A  66 "
   model   vdw
   3.832 3.340
nonbonded pdb=" N   GLN A  31 "
          pdb=" CG  GLN A  31 "
   model   vdw
   3.833 2.816
nonbonded pdb=" CA  GLY A  74 "
          pdb=" CA  SER A  75 "
   model   vdw
   3.833 3.096
nonbonded pdb=" C   TYR A  61 "
          pdb=" CG  TYR A  61 "
   model   vdw
   3.834 2.792
nonbonded pdb=" CD2 TYR A  41 "
          pdb=" CZ  TYR A  34 "
   model   vdw sym.op.
   3.834 3.560 -x+1,y,-z+1
nonbonded pdb=" CZ  TYR A  34 "
          pdb=" CD2 TYR A  41 "
   model   vdw sym.op.
   3.834 3.560 -x+1,y,-z+1
nonbonded pdb=" CD  GLN A  10 "
          pdb=" CE1 TYR A  34 "
   model   vdw
   3.834 3.570
nonbonded pdb=" CB  THR A  48 "
          pdb="O    HOH S  38 "
   model   vdw
   3.834 3.470
nonbonded pdb=" C   ARG A  82 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   3.834 3.690
nonbonded pdb=" C   LEU A  60 "
          pdb=" CG  LEU A  60 "
   model   vdw
   3.834 2.960
nonbonded pdb=" C   LEU A  81 "
          pdb=" O   ARG A  82 "
   model   vdw
   3.834 3.270
nonbonded pdb=" C   VAL A  84 "
          pdb=" CG1 VAL A  84 "
   model   vdw
   3.835 2.952
nonbonded pdb=" OH  TYR A  56 "
          pdb=" C   ARG A  82 "
   model   vdw
   3.835 3.270
nonbonded pdb=" O   ARG A  80 "
          pdb=" O   LEU A  81 "
   model   vdw
   3.836 3.040
nonbonded pdb=" C   VAL A  70 "
          pdb=" CG2 VAL A  70 "
   model   vdw
   3.836 2.952
nonbonded pdb=" O   PRO A   8 "
          pdb=" CB  THR A  15 "
   model   vdw sym.op.
   3.837 3.470 -x+1/2,y+1/2,-z+1
nonbonded pdb=" O   HIS A  64 "
          pdb=" CD1 PHE A  68 "
   model   vdw
   3.838 3.340
nonbonded pdb=" CD2 PHE A  13 "
          pdb=" CB  ALA A  55 "
   model   vdw
   3.838 3.760
nonbonded pdb=" CA  ILE A  78 "
          pdb=" CD1 ILE A  78 "
   model   vdw
   3.838 3.112
nonbonded pdb=" C   VAL A  45 "
          pdb=" O   LYS A  46 "
   model   vdw
   3.838 3.270
nonbonded pdb=" C   ILE A   6 "
          pdb=" CG1 ILE A   6 "
   model   vdw
   3.839 2.936
nonbonded pdb=" N   THR A  15 "
          pdb="O    HOH S  11 "
   model   vdw
   3.840 3.120
nonbonded pdb=" N   VAL A  63 "
          pdb="O    HOH S  19 "
   model   vdw
   3.840 3.120
nonbonded pdb=" NH1 ARG A  16 "
          pdb=" N   LEU A  60 "
   model   vdw sym.op.
   3.840 3.200 x,y-1,z
nonbonded pdb=" OG  SER A  67 "
          pdb=" CD1 PHE A  68 "
   model   vdw
   3.840 3.340
nonbonded pdb=" CA  THR A  62 "
          pdb=" O   VAL A  84 "
   model   vdw
   3.841 3.470
nonbonded pdb=" CA  ILE A   2 "
          pdb="O    HOH S  30 "
   model   vdw
   3.841 3.470
nonbonded pdb=" O   VAL A   4 "
          pdb=" CB  TYR A  61 "
   model   vdw
   3.841 3.440
nonbonded pdb=" O   LYS A  46 "
          pdb=" CG  LYS A  46 "
   model   vdw
   3.842 3.440
nonbonded pdb=" C   LYS A  46 "
          pdb="O    HOH S  38 "
   model   vdw
   3.844 3.270
nonbonded pdb=" C   LYS A  69 "
          pdb=" O   VAL A  70 "
   model   vdw
   3.844 3.270
nonbonded pdb=" C   PHE A  73 "
          pdb=" CG  PHE A  73 "
   model   vdw
   3.844 2.792
nonbonded pdb=" O   THR A  14 "
          pdb=" C   THR A  15 "
   model   vdw
   3.845 3.270
nonbonded pdb=" C   LEU A  65 "
          pdb=" CD1 LEU A  65 "
   model   vdw
   3.845 3.690
nonbonded pdb=" CG2 VAL A  63 "
          pdb=" CD1 LEU A  81 "
   model   vdw
   3.845 3.880
nonbonded pdb=" C   THR A  14 "
          pdb=" CG2 THR A  14 "
   model   vdw
   3.845 2.952
nonbonded pdb=" C   LYS A  69 "
          pdb=" O   MSE A  77 "
   model   vdw
   3.845 3.270
nonbonded pdb=" C   LEU A  83 "
          pdb=" O   VAL A  84 "
   model   vdw
   3.845 3.270
nonbonded pdb=" SG  CYS A  33 "
          pdb=" CD1 ILE A  47 "
   model   vdw
   3.846 3.820
nonbonded pdb=" C   GLY A  59 "
          pdb=" CE1 TYR A  61 "
   model   vdw
   3.847 3.570
nonbonded pdb=" C   TYR A  34 "
          pdb=" CG  TYR A  34 "
   model   vdw
   3.847 2.792
nonbonded pdb=" N   LEU A  76 "
          pdb=" CG  LEU A  76 "
   model   vdw
   3.847 2.840
nonbonded pdb=" O   SER A  27 "
          pdb=" C   LEU A  28 "
   model   vdw
   3.848 3.270
nonbonded pdb=" O   LYS A   3 "
          pdb=" O   TYR A  34 "
   model   vdw
   3.848 3.040
nonbonded pdb=" O   ASN A  29 "
          pdb=" O   ILE A  47 "
   model   vdw
   3.849 3.040
nonbonded pdb=" C   PHE A  68 "
          pdb=" CG  PHE A  68 "
   model   vdw
   3.849 2.792
nonbonded pdb=" C   PHE A  73 "
          pdb="O    HOH S   3 "
   model   vdw
   3.849 3.270
nonbonded pdb=" OG1 THR A  62 "
          pdb="O    HOH S  30 "
   model   vdw
   3.849 3.040
nonbonded pdb=" CD2 LEU A  32 "
          pdb=" O   VAL A  45 "
   model   vdw
   3.849 3.460
nonbonded pdb=" O   ASN A  29 "
          pdb=" CG  LEU A  49 "
   model   vdw
   3.849 3.470
nonbonded pdb=" CG  LYS A   3 "
          pdb=" NZ  LYS A   3 "
   model   vdw
   3.850 2.816
nonbonded pdb=" C   TYR A  56 "
          pdb=" CG  TYR A  56 "
   model   vdw
   3.851 2.792
nonbonded pdb=" O   TYR A  56 "
          pdb=" N   PRO A  58 "
   model   vdw
   3.852 3.120
nonbonded pdb=" O   GLY A  71 "
          pdb="O    HOH S   3 "
   model   vdw
   3.852 3.040
nonbonded pdb=" O   LEU A  76 "
          pdb=" CB  MSE A  77 "
   model   vdw
   3.853 3.440
nonbonded pdb=" OE1 GLN A  53 "
          pdb=" OH  TYR A  56 "
   model   vdw
   3.853 3.040
nonbonded pdb=" CG2 VAL A  45 "
          pdb=" CG2 VAL A  70 "
   model   vdw sym.op.
   3.853 3.880 -x+1,y,-z+2
nonbonded pdb=" CG2 VAL A  70 "
          pdb=" CG2 VAL A  45 "
   model   vdw sym.op.
   3.853 3.880 -x+1,y,-z+2
nonbonded pdb=" C   GLU A  30 "
          pdb=" CG  GLU A  30 "
   model   vdw
   3.854 2.936
nonbonded pdb=" O   GLN A  10 "
          pdb=" NE2 GLN A  12 "
   model   vdw
   3.855 3.120
nonbonded pdb=" OE2 GLU A  51 "
          pdb=" NH2 ARG A  80 "
   model   vdw
   3.855 3.120
nonbonded pdb=" CB  PHE A  68 "
          pdb=" O   MSE A  77 "
   model   vdw
   3.857 3.440
nonbonded pdb=" CD2 LEU A  65 "
          pdb="O    HOH S   5 "
   model   vdw sym.op.
   3.857 3.460 -x+1,y,-z+2
nonbonded pdb=" C   GLU A  30 "
          pdb=" O   GLN A  31 "
   model   vdw
   3.857 3.270
nonbonded pdb=" C   ARG A  82 "
          pdb=" CG  ARG A  82 "
   model   vdw
   3.858 2.936
nonbonded pdb=" O   LYS A  69 "
          pdb=" C   MSE A  77 "
   model   vdw
   3.859 3.270
nonbonded pdb=" CD  GLN A  31 "
          pdb=" O   TYR A  56 "
   model   vdw
   3.859 3.270
nonbonded pdb=" CB  ILE A   6 "
          pdb=" O   ALA A  57 "
   model   vdw
   3.859 3.470
nonbonded pdb=" CA  GLU A   5 "
          pdb=" CD  GLU A   5 "
   model   vdw
   3.859 2.960
nonbonded pdb=" N   LEU A  32 "
          pdb=" CD2 LEU A  32 "
   model   vdw
   3.859 3.540
nonbonded pdb=" CD2 HIS A  64 "
          pdb=" N   LEU A  65 "
   model   vdw
   3.859 3.340
nonbonded pdb=" O   ASN A  29 "
          pdb=" C   GLU A  30 "
   model   vdw
   3.860 3.270
nonbonded pdb=" O   THR A  15 "
          pdb=" C   ARG A  16 "
   model   vdw
   3.861 3.270
nonbonded pdb=" C   SER A  75 "
          pdb=" N   MSE A  77 "
   model   vdw
   3.861 3.350
nonbonded pdb=" CD  LYS A  69 "
          pdb=" CE  MSE A  77 "
   model   vdw
   3.862 3.860
nonbonded pdb=" C   LYS A   7 "
          pdb=" CG  LYS A   7 "
   model   vdw
   3.863 2.936
nonbonded pdb=" O   LEU A  60 "
          pdb=" CA  PRO A  85 "
   model   vdw
   3.863 3.470
nonbonded pdb=" C   ILE A   6 "
          pdb="O    HOH S  12 "
   model   vdw
   3.863 3.270
nonbonded pdb=" SG  CYS A  33 "
          pdb=" CG2 VAL A  35 "
   model   vdw
   3.863 3.820
nonbonded pdb=" N   TYR A  26 "
          pdb=" CD2 TYR A  26 "
   model   vdw
   3.863 3.420
nonbonded pdb=" C   LEU A  37 "
          pdb=" CG  LEU A  37 "
   model   vdw
   3.864 2.960
nonbonded pdb=" CD  PRO A   8 "
          pdb=" N   SER A   9 "
   model   vdw
   3.864 3.520
nonbonded pdb=" N   VAL A   4 "
          pdb=" CG1 VAL A   4 "
   model   vdw
   3.866 2.832
nonbonded pdb=" C   LYS A  46 "
          pdb="O    HOH S   6 "
   model   vdw sym.op.
   3.867 3.270 -x+1,y,-z+2
nonbonded pdb=" CE  LYS A   7 "
          pdb=" CE2 TYR A  41 "
   model   vdw sym.op.
   3.867 3.740 -x+1,y,-z+1
nonbonded pdb=" OE1 GLN A  10 "
          pdb=" N   CYS A  33 "
   model   vdw
   3.868 3.120
nonbonded pdb=" CA  LEU A  37 "
          pdb=" CD1 LEU A  37 "
   model   vdw
   3.868 3.112
nonbonded pdb=" C   GLN A  10 "
          pdb=" NE2 GLN A  31 "
   model   vdw
   3.868 3.350
nonbonded pdb=" CD2 TYR A  61 "
          pdb=" CA  PRO A  85 "
   model   vdw
   3.869 3.770
nonbonded pdb=" C   SER A  17 "
          pdb=" CE1 TYR A  26 "
   model   vdw
   3.869 3.570
nonbonded pdb=" CA  LYS A   3 "
          pdb=" CD  LYS A   3 "
   model   vdw
   3.869 3.096
nonbonded pdb=" C   LEU A  44 "
          pdb=" CD1 LEU A  44 "
   model   vdw
   3.869 3.690
nonbonded pdb=" CG2 THR A  48 "
          pdb=" O   LEU A  49 "
   model   vdw
   3.869 3.460
nonbonded pdb=" C   GLN A  10 "
          pdb=" CG  GLN A  10 "
   model   vdw
   3.869 2.936
nonbonded pdb=" O   LEU A  76 "
          pdb=" CG  LEU A  76 "
   model   vdw
   3.870 3.470
nonbonded pdb=" CB  LEU A  49 "
          pdb=" O   ASP A  50 "
   model   vdw
   3.870 3.440
nonbonded pdb=" O   CYS A  33 "
          pdb=" CA  VAL A  45 "
   model   vdw
   3.870 3.470
nonbonded pdb=" CE1 TYR A  26 "
          pdb=" CD2 LEU A  28 "
   model   vdw
   3.871 3.760
nonbonded pdb=" OE1 GLU A  30 "
          pdb=" CD  LYS A  46 "
   model   vdw
   3.871 3.440
nonbonded pdb=" N   GLN A  12 "
          pdb=" OE1 GLN A  12 "
   model   vdw
   3.871 3.120
nonbonded pdb=" CZ  ARG A  16 "
          pdb=" CB  PRO A  85 "
   model   vdw sym.op.
   3.872 3.670 x,y-1,z
nonbonded pdb=" CA  GLN A  10 "
          pdb=" CD  GLN A  10 "
   model   vdw
   3.872 2.960
nonbonded pdb=" CG  TYR A  56 "
          pdb="O    HOH S  39 "
   model   vdw
   3.872 3.260
nonbonded pdb=" C   ILE A   2 "
          pdb=" OG1 THR A  62 "
   model   vdw
   3.872 3.270
nonbonded pdb=" C   ILE A  78 "
          pdb=" N   ARG A  80 "
   model   vdw
   3.874 3.350
nonbonded pdb=" O   ILE A   2 "
          pdb="O    HOH S  30 "
   model   vdw
   3.874 3.040
nonbonded pdb=" CG  GLN A  72 "
          pdb=" CD2 PHE A  73 "
   model   vdw
   3.874 3.740
nonbonded pdb=" CE1 HIS A  64 "
          pdb=" CB  SER A  66 "
   model   vdw
   3.875 3.660
nonbonded pdb=" CD1 ILE A   6 "
          pdb=" CD  GLN A  31 "
   model   vdw
   3.875 3.690
nonbonded pdb=" O   THR A  62 "
          pdb=" CG2 VAL A  84 "
   model   vdw
   3.875 3.460
nonbonded pdb=" O   THR A  15 "
          pdb=" CB  ARG A  16 "
   model   vdw
   3.876 3.440
nonbonded pdb=" CA  ARG A  80 "
          pdb=" CD  ARG A  80 "
   model   vdw
   3.876 3.096
nonbonded pdb=" CG  ASP A  50 "
          pdb=" NH2 ARG A  82 "
   model   vdw
   3.877 3.350
nonbonded pdb=" CB  THR A  15 "
          pdb=" O   LEU A  28 "
   model   vdw
   3.878 3.470
nonbonded pdb=" O   GLN A  31 "
          pdb=" CG  LEU A  32 "
   model   vdw
   3.878 3.470
nonbonded pdb=" O   LYS A  46 "
          pdb=" CB  SER A  75 "
   model   vdw sym.op.
   3.878 3.440 -x+1,y,-z+2
nonbonded pdb=" CB  LEU A  49 "
          pdb=" OE1 GLN A  53 "
   model   vdw
   3.879 3.440
nonbonded pdb=" ND1 HIS A  64 "
          pdb=" CA  SER A  66 "
   model   vdw
   3.879 3.550
nonbonded pdb=" CA  ILE A  47 "
          pdb=" CD1 ILE A  47 "
   model   vdw
   3.879 3.112
nonbonded pdb=" CZ  TYR A  41 "
          pdb=" CD  PRO A  42 "
   model   vdw sym.op.
   3.879 3.660 -x+1,y,-z+1
nonbonded pdb=" CD  PRO A  42 "
          pdb=" CZ  TYR A  41 "
   model   vdw sym.op.
   3.879 3.660 -x+1,y,-z+1
nonbonded pdb=" C   LYS A  46 "
          pdb=" O   ILE A  47 "
   model   vdw
   3.881 3.270
nonbonded pdb=" CD1 LEU A  49 "
          pdb=" O   PRO A  54 "
   model   vdw
   3.881 3.460
nonbonded pdb=" CB  GLU A  40 "
          pdb=" CD2 TYR A  41 "
   model   vdw
   3.883 3.740
nonbonded pdb=" C   GLY A  52 "
          pdb="O    HOH S  20 "
   model   vdw
   3.884 3.270
nonbonded pdb=" C   LEU A  28 "
          pdb=" O   ASN A  29 "
   model   vdw
   3.884 3.270
nonbonded pdb=" N   LEU A  44 "
          pdb="O    HOH S  25 "
   model   vdw
   3.884 3.120
nonbonded pdb=" O   SER A  67 "
          pdb=" CB  PHE A  68 "
   model   vdw
   3.885 3.440
nonbonded pdb=" O   SER A  66 "
          pdb=" CZ  ARG A  82 "
   model   vdw
   3.886 3.270
nonbonded pdb=" CA  LEU A  65 "
          pdb=" CD2 LEU A  65 "
   model   vdw
   3.886 3.112
nonbonded pdb=" N   SER A   9 "
          pdb=" CB  THR A  15 "
   model   vdw sym.op.
   3.886 3.550 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CA  LEU A  32 "
          pdb="O    HOH S   8 "
   model   vdw
   3.887 3.470
nonbonded pdb=" C   ARG A  82 "
          pdb=" O   LEU A  83 "
   model   vdw
   3.888 3.270
nonbonded pdb=" O   SER A   9 "
          pdb=" CB  GLN A  10 "
   model   vdw
   3.889 3.440
nonbonded pdb=" C   GLY A  59 "
          pdb=" CD1 TYR A  61 "
   model   vdw
   3.889 3.570
nonbonded pdb=" C   PRO A  54 "
          pdb=" N   TYR A  56 "
   model   vdw
   3.890 3.350
nonbonded pdb=" C   LEU A  65 "
          pdb=" CD1 PHE A  68 "
   model   vdw
   3.890 3.570
nonbonded pdb=" C   LEU A  60 "
          pdb=" O   TYR A  61 "
   model   vdw
   3.890 3.270
nonbonded pdb=" CA  ARG A  16 "
          pdb=" CD  ARG A  16 "
   model   vdw
   3.891 3.096
nonbonded pdb=" CG2 VAL A  35 "
          pdb=" CB  VAL A  45 "
   model   vdw
   3.892 3.890
nonbonded pdb=" CA  GLN A  72 "
          pdb=" CD  GLN A  72 "
   model   vdw
   3.892 2.960
nonbonded pdb=" CG2 ILE A  78 "
          pdb=" N   ARG A  80 "
   model   vdw
   3.892 3.540
nonbonded pdb=" CA  ILE A  78 "
          pdb="O    HOH S  13 "
   model   vdw
   3.892 3.470
nonbonded pdb="O    HOH S  13 "
          pdb=" CA  ILE A  78 "
   model   vdw sym.op.
   3.892 3.470 -x+1,y,-z+2
nonbonded pdb=" CA  ILE A  78 "
          pdb="O    HOH S  13 "
   model   vdw sym.op.
   3.892 3.470 -x+1,y,-z+2
nonbonded pdb=" C   VAL A  35 "
          pdb=" CG2 VAL A  35 "
   model   vdw
   3.893 2.952
nonbonded pdb=" CG  GLN A  72 "
          pdb=" CE2 PHE A  73 "
   model   vdw
   3.893 3.740
nonbonded pdb=" C   GLU A  51 "
          pdb=" CG  GLU A  51 "
   model   vdw
   3.893 2.936
nonbonded pdb=" O   ARG A  82 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   3.894 3.460
nonbonded pdb=" C   ILE A   2 "
          pdb=" CD1 ILE A   2 "
   model   vdw
   3.894 3.690
nonbonded pdb=" C   TYR A  41 "
          pdb=" CG  TYR A  41 "
   model   vdw
   3.894 2.792
nonbonded pdb=" C   ASP A  50 "
          pdb=" N   GLY A  52 "
   model   vdw
   3.894 3.350
nonbonded pdb=" C   GLU A   5 "
          pdb=" O   ILE A   6 "
   model   vdw
   3.894 3.270
nonbonded pdb=" O   MSE A  77 "
          pdb=" N   ASP A  79 "
   model   vdw
   3.894 3.120
nonbonded pdb=" CA  LEU A  60 "
          pdb=" CD1 LEU A  60 "
   model   vdw
   3.894 3.112
nonbonded pdb=" N   LYS A   7 "
          pdb=" CD  GLN A  10 "
   model   vdw
   3.895 3.350
nonbonded pdb=" O   LYS A  69 "
          pdb=" CA  MSE A  77 "
   model   vdw
   3.895 3.470
nonbonded pdb=" CG  PRO A   8 "
          pdb="O    HOH S  14 "
   model   vdw sym.op.
   3.895 3.440 -x+1/2,y+1/2,-z+1
nonbonded pdb=" O   GLY A  74 "
          pdb=" O   SER A  75 "
   model   vdw
   3.896 3.040
nonbonded pdb=" C   ALA A  57 "
          pdb=" N   GLY A  59 "
   model   vdw
   3.896 3.350
nonbonded pdb=" CA  GLU A  30 "
          pdb=" CD  GLU A  30 "
   model   vdw
   3.896 2.960
nonbonded pdb=" C   PRO A  42 "
          pdb=" CG1 VAL A  43 "
   model   vdw
   3.897 3.690
nonbonded pdb=" CG1 VAL A  63 "
          pdb=" CE1 PHE A  68 "
   model   vdw
   3.897 3.760
nonbonded pdb=" O   LYS A  69 "
          pdb=" C   LEU A  76 "
   model   vdw
   3.897 3.270
nonbonded pdb=" C   VAL A   4 "
          pdb=" CG2 VAL A   4 "
   model   vdw
   3.898 2.952
nonbonded pdb="O    HOH S  30 "
          pdb=" OE1 GLN A  72 "
   model   vdw sym.op.
   3.899 3.040 -x+1,y+1,-z+2
nonbonded pdb=" OE1 GLN A  72 "
          pdb="O    HOH S  30 "
   model   vdw sym.op.
   3.899 3.040 -x+1,y-1,-z+2
nonbonded pdb=" C   ASN A  29 "
          pdb=" CG  ASN A  29 "
   model   vdw
   3.899 2.800
nonbonded pdb=" CA  ASP A  50 "
          pdb=" OE1 GLU A  51 "
   model   vdw
   3.900 3.470
nonbonded pdb=" CA  LEU A  76 "
          pdb=" CD2 LEU A  76 "
   model   vdw
   3.901 3.112
nonbonded pdb=" N   ILE A   2 "
          pdb=" CD1 ILE A   2 "
   model   vdw
   3.901 3.540
nonbonded pdb=" O   LEU A  76 "
          pdb=" CG2 ILE A  78 "
   model   vdw sym.op.
   3.901 3.460 -x+1,y,-z+2
nonbonded pdb=" CG2 THR A  48 "
          pdb=" NH1 ARG A  80 "
   model   vdw
   3.902 3.540
nonbonded pdb=" OG1 THR A  15 "
          pdb=" CG  ASN A  29 "
   model   vdw
   3.902 3.270
nonbonded pdb=" O   THR A  48 "
          pdb=" NE  ARG A  80 "
   model   vdw
   3.902 3.120
nonbonded pdb=" O   LYS A  46 "
          pdb=" CB  ILE A  47 "
   model   vdw
   3.902 3.470
nonbonded pdb=" CA  LEU A  81 "
          pdb=" CD2 LEU A  81 "
   model   vdw
   3.903 3.112
nonbonded pdb=" CB  ARG A  80 "
          pdb=" NH1 ARG A  82 "
   model   vdw
   3.903 3.520
nonbonded pdb=" CA  ASP A  36 "
          pdb="O    HOH S   5 "
   model   vdw
   3.904 3.470
nonbonded pdb=" CD2 PHE A  73 "
          pdb="O    HOH S   3 "
   model   vdw
   3.904 3.340
nonbonded pdb=" CB  LEU A  49 "
          pdb=" CG  GLN A  53 "
   model   vdw
   3.904 3.840
nonbonded pdb=" C   LEU A  49 "
          pdb=" CG  LEU A  49 "
   model   vdw
   3.905 2.960
nonbonded pdb=" O   SER A  66 "
          pdb=" O   SER A  67 "
   model   vdw
   3.905 3.040
nonbonded pdb=" O   SER A  75 "
          pdb=" O   LEU A  76 "
   model   vdw
   3.906 3.040
nonbonded pdb=" O   LYS A   3 "
          pdb=" CG1 VAL A  35 "
   model   vdw
   3.906 3.460
nonbonded pdb=" N   ARG A  80 "
          pdb=" NH1 ARG A  82 "
   model   vdw
   3.906 3.200
nonbonded pdb=" O   GLN A  31 "
          pdb=" CB  LEU A  32 "
   model   vdw
   3.906 3.440
nonbonded pdb=" O   ILE A   2 "
          pdb=" O   TYR A  61 "
   model   vdw
   3.907 3.040
nonbonded pdb=" CB  LEU A  44 "
          pdb="O    HOH S  25 "
   model   vdw
   3.907 3.440
nonbonded pdb=" O   LEU A  76 "
          pdb=" C   MSE A  77 "
   model   vdw
   3.908 3.270
nonbonded pdb=" CD1 LEU A  28 "
          pdb=" CG2 THR A  48 "
   model   vdw
   3.908 3.880
nonbonded pdb=" C   GLU A  40 "
          pdb=" CG  GLU A  40 "
   model   vdw
   3.908 2.936
nonbonded pdb=" O   ASP A  36 "
          pdb=" CB  LEU A  37 "
   model   vdw
   3.908 3.440
nonbonded pdb=" CB  HIS A  64 "
          pdb=" OG  SER A  66 "
   model   vdw
   3.909 3.440
nonbonded pdb=" CB  VAL A   4 "
          pdb=" O   TYR A  61 "
   model   vdw
   3.909 3.470
nonbonded pdb=" C   LYS A   3 "
          pdb=" O   VAL A   4 "
   model   vdw
   3.910 3.270
nonbonded pdb=" CA  GLY A  71 "
          pdb=" CG  MSE A  77 "
   model   vdw
   3.910 3.840
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" O   TYR A  56 "
   model   vdw
   3.910 3.460
nonbonded pdb=" CD2 LEU A  76 "
          pdb=" CD1 LEU A  81 "
   model   vdw sym.op.
   3.911 3.880 -x+1,y,-z+2
nonbonded pdb=" CG2 VAL A  63 "
          pdb=" CG  LEU A  81 "
   model   vdw
   3.912 3.890
nonbonded pdb=" C   VAL A   4 "
          pdb=" N   TYR A  61 "
   model   vdw
   3.912 3.350
nonbonded pdb=" C   GLU A   5 "
          pdb=" N   LYS A   7 "
   model   vdw
   3.913 3.350
nonbonded pdb=" NE2 GLN A  31 "
          pdb=" CB  ALA A  55 "
   model   vdw
   3.913 3.540
nonbonded pdb=" O   LEU A  28 "
          pdb=" CB  ASN A  29 "
   model   vdw
   3.913 3.440
nonbonded pdb=" SG  CYS A  33 "
          pdb=" CB  VAL A  45 "
   model   vdw
   3.914 3.830
nonbonded pdb=" CB  ASN A  39 "
          pdb=" O   TYR A  41 "
   model   vdw
   3.914 3.440
nonbonded pdb=" N   GLY A  71 "
          pdb="O    HOH S   3 "
   model   vdw
   3.914 3.120
nonbonded pdb=" OE1 GLN A  31 "
          pdb=" C   ALA A  55 "
   model   vdw
   3.915 3.270
nonbonded pdb=" O   TYR A  61 "
          pdb=" C   THR A  62 "
   model   vdw
   3.915 3.270
nonbonded pdb=" O   LEU A  65 "
          pdb=" O   SER A  66 "
   model   vdw
   3.916 3.040
nonbonded pdb=" OD1 ASP A  50 "
          pdb=" NE  ARG A  80 "
   model   vdw
   3.916 3.120
nonbonded pdb=" O   PRO A  58 "
          pdb=" CD  PRO A  58 "
   model   vdw
   3.918 3.440
nonbonded pdb=" CG  GLU A  30 "
          pdb="O    HOH S  11 "
   model   vdw
   3.919 3.440
nonbonded pdb=" N   GLY A  74 "
          pdb="O    HOH S   3 "
   model   vdw
   3.919 3.120
nonbonded pdb=" CG  LYS A  69 "
          pdb=" NZ  LYS A  69 "
   model   vdw
   3.919 2.816
nonbonded pdb=" CB  LYS A  46 "
          pdb=" O   GLY A  74 "
   model   vdw sym.op.
   3.919 3.440 -x+1,y,-z+2
nonbonded pdb=" O   TYR A  34 "
          pdb=" CG2 VAL A  35 "
   model   vdw
   3.919 3.460
nonbonded pdb=" CB  TYR A  26 "
          pdb="O    HOH S  37 "
   model   vdw
   3.920 3.440
nonbonded pdb=" O   VAL A  63 "
          pdb="O    HOH S  19 "
   model   vdw
   3.921 3.040
nonbonded pdb=" CA  GLN A  53 "
          pdb=" CD  GLN A  53 "
   model   vdw
   3.921 2.960
nonbonded pdb=" CA  LEU A  37 "
          pdb=" CG  LEU A  65 "
   model   vdw sym.op.
   3.921 3.900 -x+1,y,-z+2
nonbonded pdb=" CB  ILE A  78 "
          pdb="O    HOH S  13 "
   model   vdw
   3.922 3.470
nonbonded pdb=" CB  ILE A  78 "
          pdb="O    HOH S  13 "
   model   vdw sym.op.
   3.922 3.470 -x+1,y,-z+2
nonbonded pdb=" O   LEU A  60 "
          pdb=" C   PRO A  85 "
   model   vdw
   3.923 3.270
nonbonded pdb=" O   TYR A  34 "
          pdb=" CB  VAL A  35 "
   model   vdw
   3.923 3.470
nonbonded pdb=" O   PRO A  85 "
          pdb=" CG  PRO A  85 "
   model   vdw
   3.923 3.440
nonbonded pdb=" OD2 ASP A  79 "
          pdb=" N   ARG A  80 "
   model   vdw
   3.923 3.120
nonbonded pdb=" C   LEU A  83 "
          pdb=" CG  LEU A  83 "
   model   vdw
   3.924 2.960
nonbonded pdb=" CA  LEU A  65 "
          pdb=" CD1 PHE A  68 "
   model   vdw
   3.924 3.770
nonbonded pdb=" O   LEU A  81 "
          pdb=" CB  ARG A  82 "
   model   vdw
   3.924 3.440
nonbonded pdb=" OG  SER A  67 "
          pdb=" CG  PHE A  68 "
   model   vdw
   3.925 3.260
nonbonded pdb=" O   GLN A  72 "
          pdb=" CB  PHE A  73 "
   model   vdw
   3.926 3.440
nonbonded pdb=" CG1 ILE A   6 "
          pdb=" CD1 TYR A  61 "
   model   vdw
   3.927 3.740
nonbonded pdb=" O   LYS A  46 "
          pdb=" CG1 ILE A  47 "
   model   vdw
   3.928 3.440
nonbonded pdb=" OE2 GLU A  40 "
          pdb="O    HOH S  14 "
   model   vdw sym.op.
   3.929 3.040 x+1/2,y+1/2,z
nonbonded pdb=" CA  LYS A  69 "
          pdb=" CD  LYS A  69 "
   model   vdw
   3.930 3.096
nonbonded pdb=" O   HIS A  64 "
          pdb=" OG  SER A  67 "
   model   vdw
   3.930 3.040
nonbonded pdb=" CA  VAL A  70 "
          pdb=" O   SER A  75 "
   model   vdw
   3.931 3.470
nonbonded pdb=" CB  THR A  62 "
          pdb="O    HOH S  19 "
   model   vdw
   3.931 3.470
nonbonded pdb=" CZ  TYR A  34 "
          pdb=" CD1 LEU A  44 "
   model   vdw
   3.931 3.680
nonbonded pdb=" CG1 ILE A   2 "
          pdb=" CD1 LEU A  65 "
   model   vdw sym.op.
   3.931 3.860 -x+1,y,-z+2
nonbonded pdb=" CD1 LEU A  65 "
          pdb=" CG1 ILE A   2 "
   model   vdw sym.op.
   3.931 3.860 -x+1,y,-z+2
nonbonded pdb=" CD  LYS A  69 "
          pdb=" CB  ASP A  79 "
   model   vdw
   3.932 3.840
nonbonded pdb=" CG2 THR A  48 "
          pdb=" NH2 ARG A  80 "
   model   vdw
   3.932 3.540
nonbonded pdb=" O   LEU A  76 "
          pdb=" CB  ILE A  78 "
   model   vdw sym.op.
   3.933 3.470 -x+1,y,-z+2
nonbonded pdb=" CA  LEU A  49 "
          pdb=" CD1 LEU A  49 "
   model   vdw
   3.934 3.112
nonbonded pdb=" C   GLY A  59 "
          pdb=" CG  LEU A  60 "
   model   vdw
   3.934 3.700
nonbonded pdb=" CA  CYS A  33 "
          pdb=" O   VAL A  45 "
   model   vdw
   3.935 3.470
nonbonded pdb=" O   ASP A  50 "
          pdb=" CA  GLN A  53 "
   model   vdw
   3.935 3.470
nonbonded pdb=" CD  LYS A   7 "
          pdb="O    HOH S  12 "
   model   vdw
   3.935 3.440
nonbonded pdb=" C   HIS A  64 "
          pdb=" N   SER A  67 "
   model   vdw
   3.936 3.350
nonbonded pdb=" O   VAL A  35 "
          pdb=" O   VAL A  43 "
   model   vdw
   3.936 3.040
nonbonded pdb=" OE1 GLN A  10 "
          pdb=" CE1 TYR A  34 "
   model   vdw
   3.937 3.340
nonbonded pdb=" CA  GLN A  31 "
          pdb=" CD  GLN A  31 "
   model   vdw
   3.937 2.960
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" C   GLN A  10 "
   model   vdw
   3.937 3.690
nonbonded pdb=" OG  SER A  67 "
          pdb=" CD2 PHE A  68 "
   model   vdw
   3.938 3.340
nonbonded pdb=" CB  SER A  66 "
          pdb=" CD  ARG A  82 "
   model   vdw
   3.938 3.840
nonbonded pdb=" C   GLU A  40 "
          pdb=" O   TYR A  41 "
   model   vdw
   3.938 3.270
nonbonded pdb=" C   VAL A  35 "
          pdb=" O   ASP A  36 "
   model   vdw
   3.939 3.270
nonbonded pdb=" OH  TYR A  41 "
          pdb=" CB  PRO A  42 "
   model   vdw sym.op.
   3.939 3.440 -x+1,y,-z+1
nonbonded pdb=" CA  ALA A  11 "
          pdb=" NE2 GLN A  31 "
   model   vdw
   3.939 3.550
nonbonded pdb=" O   GLY A  59 "
          pdb=" CB  LEU A  60 "
   model   vdw
   3.939 3.440
nonbonded pdb=" CG  GLU A   5 "
          pdb=" O   ILE A   6 "
   model   vdw
   3.940 3.440
nonbonded pdb=" C   LEU A  28 "
          pdb=" CD1 LEU A  28 "
   model   vdw
   3.940 3.690
nonbonded pdb=" CB  SER A  75 "
          pdb="O    HOH S   3 "
   model   vdw
   3.941 3.440
nonbonded pdb=" O   THR A  14 "
          pdb=" O   GLU A  30 "
   model   vdw
   3.941 3.040
nonbonded pdb=" C   SER A  67 "
          pdb=" N   ASP A  79 "
   model   vdw
   3.941 3.350
nonbonded pdb=" C   PRO A   8 "
          pdb=" CB  THR A  15 "
   model   vdw sym.op.
   3.942 3.700 -x+1/2,y+1/2,-z+1
nonbonded pdb=" OE1 GLU A   5 "
          pdb=" CD2 LEU A  60 "
   model   vdw
   3.944 3.460
nonbonded pdb=" CD1 LEU A  49 "
          pdb=" CA  ALA A  55 "
   model   vdw
   3.945 3.890
nonbonded pdb=" O   ILE A  47 "
          pdb=" OG1 THR A  48 "
   model   vdw
   3.945 3.040
nonbonded pdb=" CD1 PHE A  13 "
          pdb=" C   THR A  14 "
   model   vdw
   3.945 3.570
nonbonded pdb=" N   LEU A  60 "
          pdb=" CD2 LEU A  60 "
   model   vdw
   3.945 3.540
nonbonded pdb=" O   LYS A   3 "
          pdb=" CB  ASP A  36 "
   model   vdw
   3.945 3.440
nonbonded pdb=" OG  SER A  67 "
          pdb=" CD1 LEU A  81 "
   model   vdw
   3.947 3.460
nonbonded pdb=" N   GLY A  59 "
          pdb="O    HOH S  12 "
   model   vdw
   3.947 3.120
nonbonded pdb=" CE  LYS A   7 "
          pdb=" CZ  TYR A  41 "
   model   vdw sym.op.
   3.947 3.660 -x+1,y,-z+1
nonbonded pdb=" CG  GLU A   5 "
          pdb=" CD2 LEU A  60 "
   model   vdw
   3.948 3.860
nonbonded pdb=" O   GLU A  30 "
          pdb=" C   GLN A  31 "
   model   vdw
   3.948 3.270
nonbonded pdb=" C   SER A  27 "
          pdb=" CD1 LEU A  28 "
   model   vdw
   3.948 3.690
nonbonded pdb=" C   SER A  66 "
          pdb=" CD  ARG A  82 "
   model   vdw
   3.948 3.670
nonbonded pdb=" C   SER A  67 "
          pdb=" O   ARG A  80 "
   model   vdw
   3.948 3.270
nonbonded pdb=" C   ILE A   6 "
          pdb=" N   GLY A  59 "
   model   vdw
   3.948 3.350
nonbonded pdb=" CG  TYR A  61 "
          pdb=" O   VAL A  84 "
   model   vdw
   3.949 3.260
nonbonded pdb=" CD1 ILE A   2 "
          pdb="O    HOH S   5 "
   model   vdw
   3.949 3.460
nonbonded pdb=" O   LEU A  60 "
          pdb=" C   TYR A  61 "
   model   vdw
   3.949 3.270
nonbonded pdb=" OH  TYR A  56 "
          pdb=" CG  LEU A  83 "
   model   vdw
   3.950 3.470
nonbonded pdb=" CG1 ILE A  47 "
          pdb=" CB  LEU A  81 "
   model   vdw
   3.950 3.840
nonbonded pdb=" C   LYS A  69 "
          pdb=" CD1 LEU A  76 "
   model   vdw
   3.951 3.690
nonbonded pdb=" NE2 GLN A  10 "
          pdb=" O   CYS A  33 "
   model   vdw
   3.952 3.120
nonbonded pdb=" N   LYS A  46 "
          pdb=" C   GLY A  74 "
   model   vdw sym.op.
   3.952 3.350 -x+1,y,-z+2
nonbonded pdb=" O   ILE A  47 "
          pdb=" CB  THR A  48 "
   model   vdw
   3.953 3.470
nonbonded pdb=" O   GLN A  12 "
          pdb=" CB  GLN A  31 "
   model   vdw
   3.953 3.440
nonbonded pdb=" C   SER A  27 "
          pdb=" O   LEU A  28 "
   model   vdw
   3.953 3.270
nonbonded pdb=" O   LYS A   3 "
          pdb=" CA  ASP A  36 "
   model   vdw
   3.953 3.470
nonbonded pdb=" C   LYS A   7 "
          pdb=" O   PRO A   8 "
   model   vdw
   3.953 3.270
nonbonded pdb=" O   GLU A   5 "
          pdb=" N   LYS A   7 "
   model   vdw
   3.953 3.120
nonbonded pdb=" CD  GLN A  31 "
          pdb=" CB  ALA A  55 "
   model   vdw
   3.954 3.690
nonbonded pdb=" CA  LEU A  83 "
          pdb=" CD1 LEU A  83 "
   model   vdw
   3.954 3.112
nonbonded pdb=" CG  ASP A  50 "
          pdb=" NH1 ARG A  80 "
   model   vdw
   3.954 3.350
nonbonded pdb=" O   SER A  17 "
          pdb=" CE1 TYR A  26 "
   model   vdw
   3.955 3.340
nonbonded pdb=" CB  GLN A  10 "
          pdb="O    HOH S   8 "
   model   vdw
   3.955 3.440
nonbonded pdb=" O   SER A  67 "
          pdb=" CB  ILE A  78 "
   model   vdw
   3.955 3.470
nonbonded pdb=" CD1 LEU A  37 "
          pdb="O    HOH S  10 "
   model   vdw sym.op.
   3.955 3.460 -x+1,y,-z+2
nonbonded pdb=" CB  ASN A  29 "
          pdb=" CD1 LEU A  49 "
   model   vdw
   3.956 3.860
nonbonded pdb=" OE1 GLN A  31 "
          pdb=" CA  TYR A  56 "
   model   vdw
   3.956 3.470
nonbonded pdb=" O   LEU A  44 "
          pdb=" CG  LEU A  44 "
   model   vdw
   3.957 3.470
nonbonded pdb=" CE2 TYR A  34 "
          pdb=" CD1 LEU A  44 "
   model   vdw
   3.957 3.760
nonbonded pdb=" C   GLN A  31 "
          pdb=" N   ILE A  47 "
   model   vdw
   3.958 3.350
nonbonded pdb=" O   ARG A  82 "
          pdb=" CB  LEU A  83 "
   model   vdw
   3.958 3.440
nonbonded pdb=" CG2 THR A  62 "
          pdb=" O   VAL A  84 "
   model   vdw
   3.959 3.460
nonbonded pdb=" N   LEU A  81 "
          pdb=" CD1 LEU A  81 "
   model   vdw
   3.959 3.540
nonbonded pdb=" CB  LYS A   7 "
          pdb=" OG  SER A   9 "
   model   vdw
   3.960 3.440
nonbonded pdb=" CG  GLU A   5 "
          pdb=" C   ILE A   6 "
   model   vdw
   3.961 3.670
nonbonded pdb=" CA  LYS A  69 "
          pdb=" O   MSE A  77 "
   model   vdw
   3.963 3.470
nonbonded pdb=" C   ASP A  36 "
          pdb=" CD2 LEU A  37 "
   model   vdw
   3.963 3.690
nonbonded pdb=" CB  TYR A  56 "
          pdb=" CZ  TYR A  61 "
   model   vdw
   3.963 3.660
nonbonded pdb=" CG1 ILE A  78 "
          pdb=" CG1 ILE A  78 "
   model   vdw sym.op.
   3.964 3.840 -x+1,y,-z+2
nonbonded pdb=" O   GLY A  52 "
          pdb=" CB  GLN A  53 "
   model   vdw
   3.964 3.440
nonbonded pdb=" CA  ILE A   2 "
          pdb="O    HOH S  19 "
   model   vdw
   3.965 3.470
nonbonded pdb=" OD1 ASP A  50 "
          pdb=" NE  ARG A  82 "
   model   vdw
   3.965 3.120
nonbonded pdb=" CE1 TYR A  41 "
          pdb=" CG  PRO A  42 "
   model   vdw sym.op.
   3.965 3.740 -x+1,y,-z+1
nonbonded pdb=" O   GLN A  31 "
          pdb=" C   ILE A  47 "
   model   vdw
   3.966 3.270
nonbonded pdb=" C   TYR A  26 "
          pdb=" O   SER A  27 "
   model   vdw
   3.967 3.270
nonbonded pdb=" C   GLY A  38 "
          pdb=" ND2 ASN A  39 "
   model   vdw
   3.968 3.350
nonbonded pdb=" CD  GLN A  53 "
          pdb=" OH  TYR A  56 "
   model   vdw
   3.968 3.270
nonbonded pdb=" O   VAL A  45 "
          pdb=" N   ILE A  47 "
   model   vdw
   3.969 3.120
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" CB  GLN A  10 "
   model   vdw
   3.969 3.860
nonbonded pdb=" O   GLU A   5 "
          pdb=" CB  ILE A   6 "
   model   vdw
   3.969 3.470
nonbonded pdb=" O   GLN A  72 "
          pdb=" N   GLY A  74 "
   model   vdw
   3.970 3.120
nonbonded pdb=" OH  TYR A  41 "
          pdb=" CD  PRO A  42 "
   model   vdw sym.op.
   3.971 3.440 -x+1,y,-z+1
nonbonded pdb=" CD  PRO A  42 "
          pdb=" OH  TYR A  41 "
   model   vdw sym.op.
   3.971 3.440 -x+1,y,-z+1
nonbonded pdb=" CG1 VAL A  70 "
          pdb=" O   GLY A  74 "
   model   vdw
   3.971 3.460
nonbonded pdb=" O   ILE A   6 "
          pdb=" CA  GLY A  59 "
   model   vdw
   3.971 3.440
nonbonded pdb=" O   LEU A  65 "
          pdb=" CA  PHE A  68 "
   model   vdw
   3.971 3.470
nonbonded pdb=" O   TYR A  26 "
          pdb=" CD2 TYR A  26 "
   model   vdw
   3.972 3.340
nonbonded pdb=" CG2 ILE A  78 "
          pdb=" C   ASP A  79 "
   model   vdw
   3.972 3.690
nonbonded pdb=" O   LEU A  60 "
          pdb=" CD2 TYR A  61 "
   model   vdw
   3.972 3.340
nonbonded pdb=" CD  PRO A  54 "
          pdb="O    HOH S  20 "
   model   vdw
   3.975 3.440
nonbonded pdb=" NH2 ARG A  16 "
          pdb=" CE1 TYR A  61 "
   model   vdw sym.op.
   3.975 3.420 x,y-1,z
nonbonded pdb=" CB  ASP A  79 "
          pdb=" NH1 ARG A  82 "
   model   vdw
   3.976 3.520
nonbonded pdb=" C   GLY A  59 "
          pdb=" O   LEU A  60 "
   model   vdw
   3.978 3.270
nonbonded pdb=" CA  LYS A  46 "
          pdb=" O   GLY A  74 "
   model   vdw sym.op.
   3.979 3.470 -x+1,y,-z+2
nonbonded pdb=" O   LEU A  28 "
          pdb=" N   GLU A  30 "
   model   vdw
   3.979 3.120
nonbonded pdb=" C   SER A  17 "
          pdb=" OH  TYR A  26 "
   model   vdw
   3.979 3.270
nonbonded pdb=" C   ASP A  36 "
          pdb="O    HOH S   9 "
   model   vdw
   3.980 3.270
nonbonded pdb=" C   TYR A  26 "
          pdb=" CD2 TYR A  26 "
   model   vdw
   3.980 3.570
nonbonded pdb=" CD2 PHE A  68 "
          pdb=" CD1 ILE A  78 "
   model   vdw sym.op.
   3.981 3.760 -x+1,y,-z+2
nonbonded pdb=" CD1 ILE A  78 "
          pdb=" CD2 PHE A  68 "
   model   vdw sym.op.
   3.981 3.760 -x+1,y,-z+2
nonbonded pdb=" CG  TYR A  56 "
          pdb=" CD1 LEU A  83 "
   model   vdw
   3.981 3.680
nonbonded pdb=" CD2 LEU A  37 "
          pdb=" O   PHE A  68 "
   model   vdw sym.op.
   3.981 3.460 -x+1,y,-z+2
nonbonded pdb=" CE  LYS A  69 "
          pdb=" O   VAL A  70 "
   model   vdw
   3.982 3.440
nonbonded pdb=" CA  SER A  75 "
          pdb="O    HOH S   3 "
   model   vdw
   3.982 3.470
nonbonded pdb=" N   ASP A  50 "
          pdb=" NH1 ARG A  80 "
   model   vdw
   3.983 3.200
nonbonded pdb=" CA  ILE A   6 "
          pdb=" O   GLY A  59 "
   model   vdw
   3.983 3.470
nonbonded pdb=" CA  SER A  17 "
          pdb=" CE1 TYR A  26 "
   model   vdw
   3.983 3.770
nonbonded pdb=" O   THR A  14 "
          pdb=" CA  GLU A  30 "
   model   vdw
   3.983 3.470
nonbonded pdb=" OE1 GLN A  10 "
          pdb=" C   CYS A  33 "
   model   vdw
   3.983 3.270
nonbonded pdb=" N   SER A   9 "
          pdb=" OE2 GLU A  40 "
   model   vdw sym.op.
   3.983 3.120 -x+1,y,-z+1
nonbonded pdb=" CE2 TYR A  26 "
          pdb=" CG  PRO A  85 "
   model   vdw sym.op.
   3.984 3.740 x,y-1,z
nonbonded pdb=" C   LEU A  65 "
          pdb=" N   PHE A  68 "
   model   vdw
   3.984 3.350
nonbonded pdb=" CD1 LEU A  49 "
          pdb=" O   GLN A  53 "
   model   vdw
   3.984 3.460
nonbonded pdb=" C   PRO A  54 "
          pdb="O    HOH S  39 "
   model   vdw
   3.985 3.270
nonbonded pdb=" CG2 VAL A  84 "
          pdb=" N   PRO A  85 "
   model   vdw
   3.985 3.540
nonbonded pdb=" O   LEU A  83 "
          pdb=" C   VAL A  84 "
   model   vdw
   3.985 3.270
nonbonded pdb=" O   LEU A  49 "
          pdb=" CZ  ARG A  80 "
   model   vdw
   3.985 3.270
nonbonded pdb=" CG1 VAL A  70 "
          pdb="O    HOH S  25 "
   model   vdw sym.op.
   3.986 3.460 -x+1,y,-z+2
nonbonded pdb=" N   GLN A  53 "
          pdb=" CD  PRO A  54 "
   model   vdw
   3.987 3.520
nonbonded pdb=" O   LYS A   3 "
          pdb=" C   VAL A   4 "
   model   vdw
   3.987 3.270
nonbonded pdb=" O   THR A  62 "
          pdb=" CB  LEU A  83 "
   model   vdw
   3.987 3.440
nonbonded pdb=" CA  GLN A  31 "
          pdb=" O   ILE A  47 "
   model   vdw
   3.987 3.470
nonbonded pdb=" CD  ARG A  16 "
          pdb=" CD  GLU A  30 "
   model   vdw
   3.987 3.670
nonbonded pdb=" O   PRO A   8 "
          pdb=" N   ALA A  11 "
   model   vdw
   3.987 3.120
nonbonded pdb=" N   LYS A   7 "
          pdb=" CB  GLN A  10 "
   model   vdw
   3.987 3.520
nonbonded pdb=" C   MSE A  77 "
          pdb=" CG1 ILE A  78 "
   model   vdw
   3.988 3.670
nonbonded pdb=" CD2 LEU A  49 "
          pdb=" OE1 GLN A  53 "
   model   vdw
   3.988 3.460
nonbonded pdb=" CD  GLN A  53 "
          pdb="O    HOH S  39 "
   model   vdw
   3.989 3.270
nonbonded pdb=" CZ  PHE A  13 "
          pdb="O    HOH S  14 "
   model   vdw
   3.989 3.340
nonbonded pdb=" O   LYS A   3 "
          pdb="O    HOH S   5 "
   model   vdw
   3.989 3.040
nonbonded pdb=" O   HIS A  64 "
          pdb=" CG  HIS A  64 "
   model   vdw
   3.989 3.260
nonbonded pdb=" CG  ARG A  16 "
          pdb=" CB  LEU A  28 "
   model   vdw
   3.991 3.840
nonbonded pdb=" N   TYR A  56 "
          pdb=" CD1 TYR A  56 "
   model   vdw
   3.991 3.420
nonbonded pdb=" O   LYS A   7 "
          pdb=" CG  PRO A  58 "
   model   vdw
   3.992 3.440
nonbonded pdb=" C   ILE A  47 "
          pdb="O    HOH S  38 "
   model   vdw
   3.993 3.270
nonbonded pdb=" CD1 TYR A  26 "
          pdb=" CA  SER A  27 "
   model   vdw
   3.993 3.770
nonbonded pdb=" O   PHE A  68 "
          pdb=" C   LYS A  69 "
   model   vdw
   3.994 3.270
nonbonded pdb=" OD1 ASP A  36 "
          pdb=" CA  GLY A  38 "
   model   vdw
   3.995 3.440
nonbonded pdb=" O   THR A  62 "
          pdb=" O   ARG A  82 "
   model   vdw
   3.995 3.040
nonbonded pdb=" CG  GLU A  30 "
          pdb=" CD  LYS A  46 "
   model   vdw
   3.995 3.840
nonbonded pdb=" N   GLY A  52 "
          pdb=" CA  GLN A  53 "
   model   vdw
   3.995 3.550
nonbonded pdb=" CG1 VAL A   4 "
          pdb=" CB  CYS A  33 "
   model   vdw
   3.996 3.860
nonbonded pdb=" O   LYS A  69 "
          pdb=" CG  LEU A  76 "
   model   vdw
   3.996 3.470
nonbonded pdb=" CD  LYS A   7 "
          pdb=" CD  PRO A   8 "
   model   vdw
   3.996 3.840
nonbonded pdb=" CG  ARG A  16 "
          pdb=" N   SER A  17 "
   model   vdw
   3.997 3.520
nonbonded pdb=" C   LEU A  32 "
          pdb=" O   CYS A  33 "
   model   vdw
   3.997 3.270
nonbonded pdb=" C   THR A  48 "
          pdb=" N   ASP A  50 "
   model   vdw
   3.999 3.350
nonbonded pdb=" NZ  LYS A   3 "
          pdb=" C   GLN A  72 "
   model   vdw sym.op.
   4.000 3.350 -x+1,y+1,-z+2
nonbonded pdb=" N   ASP A  50 "
          pdb=" CG  GLN A  53 "
   model   vdw
   4.001 3.520
nonbonded pdb=" CG  ARG A  16 "
          pdb="O    HOH S  11 "
   model   vdw
   4.002 3.440
nonbonded pdb=" O   GLN A  72 "
          pdb=" CG  PHE A  73 "
   model   vdw
   4.002 3.260
nonbonded pdb=" CD2 TYR A  61 "
          pdb=" CB  LEU A  83 "
   model   vdw
   4.002 3.740
nonbonded pdb=" O   ARG A  16 "
          pdb=" CB  LEU A  28 "
   model   vdw
   4.002 3.440
nonbonded pdb=" C   SER A  75 "
          pdb="O    HOH S   3 "
   model   vdw
   4.002 3.270
nonbonded pdb=" CD1 LEU A  44 "
          pdb=" N   VAL A  45 "
   model   vdw
   4.003 3.540
nonbonded pdb=" C   CYS A  33 "
          pdb=" O   TYR A  34 "
   model   vdw
   4.003 3.270
nonbonded pdb=" O   THR A  14 "
          pdb=" OD1 ASN A  29 "
   model   vdw
   4.003 3.040
nonbonded pdb=" O   GLU A   5 "
          pdb=" CA  TYR A  34 "
   model   vdw
   4.005 3.470
nonbonded pdb=" NH1 ARG A  16 "
          pdb=" C   LEU A  60 "
   model   vdw sym.op.
   4.006 3.350 x,y-1,z
nonbonded pdb=" O   LEU A  76 "
          pdb=" CG  MSE A  77 "
   model   vdw
   4.007 3.440
nonbonded pdb=" C   ASP A  50 "
          pdb=" CG  GLU A  51 "
   model   vdw
   4.007 3.670
nonbonded pdb=" N   LYS A   7 "
          pdb=" CD  LYS A   7 "
   model   vdw
   4.007 3.520
nonbonded pdb=" C   THR A  62 "
          pdb=" O   VAL A  84 "
   model   vdw
   4.008 3.270
nonbonded pdb=" CA  TYR A  56 "
          pdb=" OH  TYR A  61 "
   model   vdw
   4.008 3.470
nonbonded pdb=" CB  SER A   9 "
          pdb=" CB  THR A  15 "
   model   vdw sym.op.
   4.008 3.870 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CB  THR A  15 "
          pdb=" CB  SER A   9 "
   model   vdw sym.op.
   4.008 3.870 -x+1/2,y-1/2,-z+1
nonbonded pdb=" O   VAL A  35 "
          pdb=" CB  ASP A  36 "
   model   vdw
   4.009 3.440
nonbonded pdb=" CB  ILE A   6 "
          pdb=" CA  PRO A  58 "
   model   vdw
   4.009 3.900
nonbonded pdb=" CG  GLN A  10 "
          pdb=" O   LEU A  32 "
   model   vdw
   4.009 3.440
nonbonded pdb=" CG2 ILE A  47 "
          pdb=" C   THR A  48 "
   model   vdw
   4.010 3.690
nonbonded pdb=" O   GLU A   5 "
          pdb=" CG1 ILE A   6 "
   model   vdw
   4.011 3.440
nonbonded pdb=" CG1 VAL A  63 "
          pdb=" CD1 LEU A  81 "
   model   vdw
   4.011 3.880
nonbonded pdb=" O   TYR A  26 "
          pdb=" CE1 TYR A  26 "
   model   vdw
   4.013 3.340
nonbonded pdb=" CZ  TYR A  56 "
          pdb=" CD1 LEU A  83 "
   model   vdw
   4.013 3.680
nonbonded pdb=" O   SER A   9 "
          pdb=" CG  GLN A  10 "
   model   vdw
   4.013 3.440
nonbonded pdb=" O   ARG A  16 "
          pdb=" C   SER A  17 "
   model   vdw
   4.013 3.270
nonbonded pdb=" O   ILE A   6 "
          pdb=" N   PRO A   8 "
   model   vdw
   4.014 3.120
nonbonded pdb=" N   GLN A  31 "
          pdb=" C   ILE A  47 "
   model   vdw
   4.015 3.350
nonbonded pdb=" O   LEU A  28 "
          pdb=" CG  ASN A  29 "
   model   vdw
   4.016 3.270
nonbonded pdb=" CG  LYS A   7 "
          pdb=" CD1 TYR A  34 "
   model   vdw
   4.016 3.740
nonbonded pdb=" CA  SER A  67 "
          pdb=" NH1 ARG A  82 "
   model   vdw
   4.016 3.550
nonbonded pdb=" O   SER A  27 "
          pdb=" CG  LEU A  28 "
   model   vdw
   4.016 3.470
nonbonded pdb=" CA  LYS A   3 "
          pdb=" O   TYR A  61 "
   model   vdw
   4.017 3.470
nonbonded pdb=" N   TYR A  41 "
          pdb=" CD1 TYR A  41 "
   model   vdw
   4.017 3.420
nonbonded pdb=" OE2 GLU A  51 "
          pdb=" CZ  ARG A  80 "
   model   vdw
   4.018 3.270
nonbonded pdb=" NE2 GLN A  10 "
          pdb=" CZ  TYR A  34 "
   model   vdw
   4.018 3.340
nonbonded pdb=" CD1 ILE A   6 "
          pdb=" CB  TYR A  56 "
   model   vdw
   4.018 3.860
nonbonded pdb=" CG  HIS A  64 "
          pdb=" N   SER A  66 "
   model   vdw
   4.018 3.340
nonbonded pdb=" O   PRO A  42 "
          pdb=" CB  VAL A  43 "
   model   vdw
   4.018 3.470
nonbonded pdb=" C   ILE A   6 "
          pdb=" CG  LYS A   7 "
   model   vdw
   4.019 3.670
nonbonded pdb=" OE1 GLU A  51 "
          pdb=" NH1 ARG A  80 "
   model   vdw
   4.020 3.120
nonbonded pdb=" CD  GLU A  51 "
          pdb=" NH1 ARG A  80 "
   model   vdw
   4.020 3.350
nonbonded pdb=" CD  GLN A  10 "
          pdb=" CD1 TYR A  34 "
   model   vdw
   4.020 3.570
nonbonded pdb=" O   LEU A  81 "
          pdb=" CG  ARG A  82 "
   model   vdw
   4.020 3.440
nonbonded pdb=" C   SER A  67 "
          pdb=" O   PHE A  68 "
   model   vdw
   4.021 3.270
nonbonded pdb=" O   TYR A  26 "
          pdb=" C   SER A  27 "
   model   vdw
   4.021 3.270
nonbonded pdb=" O   SER A  67 "
          pdb=" CG  PHE A  68 "
   model   vdw
   4.021 3.260
nonbonded pdb=" CG2 VAL A  35 "
          pdb=" CG2 VAL A  45 "
   model   vdw
   4.021 3.880
nonbonded pdb=" C   VAL A   4 "
          pdb=" O   GLU A   5 "
   model   vdw
   4.021 3.270
nonbonded pdb=" CG  LYS A  69 "
          pdb=" CB  ASP A  79 "
   model   vdw
   4.021 3.840
nonbonded pdb=" CB  LYS A   7 "
          pdb=" CD  GLN A  10 "
   model   vdw
   4.022 3.670
nonbonded pdb=" N   TYR A  56 "
          pdb="O    HOH S  39 "
   model   vdw
   4.022 3.120
nonbonded pdb=" C   LYS A   3 "
          pdb=" O   TYR A  61 "
   model   vdw
   4.022 3.270
nonbonded pdb=" CB  GLU A  30 "
          pdb="O    HOH S  11 "
   model   vdw
   4.023 3.440
nonbonded pdb=" O   LYS A  69 "
          pdb=" CB  MSE A  77 "
   model   vdw
   4.024 3.440
nonbonded pdb=" OH  TYR A  26 "
          pdb="O    HOH S   7 "
   model   vdw sym.op.
   4.024 3.040 x,y-1,z
nonbonded pdb=" O   SER A  75 "
          pdb=" CG  MSE A  77 "
   model   vdw
   4.024 3.440
nonbonded pdb=" O   LEU A  81 "
          pdb=" CG  LEU A  81 "
   model   vdw
   4.024 3.470
nonbonded pdb=" CG2 THR A  15 "
          pdb=" C   ARG A  16 "
   model   vdw
   4.024 3.690
nonbonded pdb=" OE1 GLN A  31 "
          pdb=" O   TYR A  56 "
   model   vdw
   4.024 3.040
nonbonded pdb=" CG  PRO A  54 "
          pdb="O    HOH S  39 "
   model   vdw
   4.025 3.440
nonbonded pdb=" CA  THR A  15 "
          pdb="O    HOH S  11 "
   model   vdw
   4.025 3.470
nonbonded pdb=" CD2 TYR A  34 "
          pdb=" C   PRO A  42 "
   model   vdw
   4.025 3.570
nonbonded pdb=" N   THR A  62 "
          pdb=" C   VAL A  84 "
   model   vdw
   4.025 3.350
nonbonded pdb=" CG2 ILE A  47 "
          pdb=" O   LEU A  81 "
   model   vdw
   4.026 3.460
nonbonded pdb=" O   ILE A   2 "
          pdb=" CB  LYS A   3 "
   model   vdw
   4.026 3.440
nonbonded pdb=" CG1 VAL A  35 "
          pdb=" CD2 LEU A  37 "
   model   vdw
   4.027 3.880
nonbonded pdb=" C   LEU A  76 "
          pdb=" CD1 LEU A  76 "
   model   vdw
   4.027 3.690
nonbonded pdb=" C   GLN A  12 "
          pdb="O    HOH S   8 "
   model   vdw
   4.028 3.270
nonbonded pdb=" CD1 LEU A  37 "
          pdb=" CD1 LEU A  76 "
   model   vdw sym.op.
   4.029 3.880 -x+1,y,-z+2
nonbonded pdb=" CD1 LEU A  76 "
          pdb=" CD1 LEU A  37 "
   model   vdw sym.op.
   4.029 3.880 -x+1,y,-z+2
nonbonded pdb=" C   ILE A   2 "
          pdb=" O   LYS A   3 "
   model   vdw
   4.029 3.270
nonbonded pdb=" O   VAL A  45 "
          pdb=" CB  LYS A  46 "
   model   vdw
   4.030 3.440
nonbonded pdb=" CG  GLN A  53 "
          pdb="O    HOH S  39 "
   model   vdw
   4.030 3.440
nonbonded pdb=" CG2 ILE A  47 "
          pdb=" CD2 LEU A  49 "
   model   vdw
   4.031 3.880
nonbonded pdb=" C   LYS A  46 "
          pdb=" CD  LYS A  46 "
   model   vdw
   4.032 3.670
nonbonded pdb=" O   ILE A  78 "
          pdb="O    HOH S  13 "
   model   vdw
   4.033 3.040
nonbonded pdb=" CG  LEU A  28 "
          pdb=" CG2 THR A  48 "
   model   vdw
   4.033 3.890
nonbonded pdb="O    HOH S  13 "
          pdb=" O   ILE A  78 "
   model   vdw sym.op.
   4.033 3.040 -x+1,y,-z+2
nonbonded pdb=" O   ILE A  78 "
          pdb="O    HOH S  13 "
   model   vdw sym.op.
   4.033 3.040 -x+1,y,-z+2
nonbonded pdb=" O   ASN A  29 "
          pdb=" CG2 THR A  48 "
   model   vdw
   4.035 3.460
nonbonded pdb=" NH1 ARG A  16 "
          pdb=" OE2 GLU A  30 "
   model   vdw
   4.036 3.120
nonbonded pdb=" N   PHE A  73 "
          pdb=" CD1 PHE A  73 "
   model   vdw
   4.036 3.420
nonbonded pdb=" CD1 LEU A  65 "
          pdb="O    HOH S   5 "
   model   vdw sym.op.
   4.036 3.460 -x+1,y,-z+2
nonbonded pdb=" O   VAL A  63 "
          pdb=" N   LEU A  65 "
   model   vdw
   4.036 3.120
nonbonded pdb=" O   THR A  62 "
          pdb=" CB  VAL A  63 "
   model   vdw
   4.037 3.470
nonbonded pdb=" CB  PRO A   8 "
          pdb=" CD1 PHE A  13 "
   model   vdw sym.op.
   4.037 3.740 -x+1/2,y+1/2,-z+1
nonbonded pdb=" N   LEU A  44 "
          pdb=" CD1 LEU A  44 "
   model   vdw
   4.038 3.540
nonbonded pdb=" C   THR A  14 "
          pdb=" O   THR A  15 "
   model   vdw
   4.038 3.270
nonbonded pdb=" C   GLN A  72 "
          pdb=" CD2 PHE A  73 "
   model   vdw
   4.038 3.570
nonbonded pdb=" CG  LYS A   7 "
          pdb=" CE1 TYR A  34 "
   model   vdw
   4.038 3.740
nonbonded pdb=" CD1 TYR A  56 "
          pdb=" CB  LEU A  83 "
   model   vdw
   4.038 3.740
nonbonded pdb=" OE1 GLU A  40 "
          pdb="O    HOH S  14 "
   model   vdw sym.op.
   4.039 3.040 x+1/2,y+1/2,z
nonbonded pdb=" O   ARG A  80 "
          pdb=" CB  ARG A  82 "
   model   vdw
   4.039 3.440
nonbonded pdb=" OE1 GLN A  10 "
          pdb=" C   LEU A  32 "
   model   vdw
   4.040 3.270
nonbonded pdb=" CA  ILE A  47 "
          pdb="O    HOH S  38 "
   model   vdw
   4.041 3.470
nonbonded pdb=" CD2 LEU A  49 "
          pdb=" CD  GLN A  53 "
   model   vdw
   4.041 3.690
nonbonded pdb=" CG  LEU A  65 "
          pdb=" CD2 LEU A  37 "
   model   vdw sym.op.
   4.041 3.890 -x+1,y,-z+2
nonbonded pdb=" CD2 LEU A  37 "
          pdb=" CG  LEU A  65 "
   model   vdw sym.op.
   4.041 3.890 -x+1,y,-z+2
nonbonded pdb=" CG1 VAL A   4 "
          pdb=" CD1 LEU A  83 "
   model   vdw
   4.042 3.880
nonbonded pdb=" OH  TYR A  26 "
          pdb=" CD  PRO A  85 "
   model   vdw sym.op.
   4.042 3.440 x,y-1,z
nonbonded pdb=" C   SER A  27 "
          pdb=" CG  LEU A  28 "
   model   vdw
   4.043 3.700
nonbonded pdb=" O   GLY A  38 "
          pdb=" CB  ASN A  39 "
   model   vdw
   4.043 3.440
nonbonded pdb=" C   PHE A  13 "
          pdb=" OG1 THR A  14 "
   model   vdw
   4.044 3.270
nonbonded pdb=" C   ASP A  79 "
          pdb=" O   ARG A  80 "
   model   vdw
   4.044 3.270
nonbonded pdb=" C   GLY A  52 "
          pdb=" N   PRO A  54 "
   model   vdw
   4.045 3.350
nonbonded pdb=" CD2 LEU A  32 "
          pdb=" CA  LYS A  46 "
   model   vdw
   4.047 3.890
nonbonded pdb=" CD1 ILE A   6 "
          pdb=" CB  CYS A  33 "
   model   vdw
   4.048 3.860
nonbonded pdb=" CG1 VAL A  45 "
          pdb=" C   LYS A  46 "
   model   vdw
   4.048 3.690
nonbonded pdb=" OG  SER A  27 "
          pdb=" OD1 ASN A  29 "
   model   vdw
   4.048 3.040
nonbonded pdb=" O   ARG A  80 "
          pdb=" NE  ARG A  82 "
   model   vdw
   4.049 3.120
nonbonded pdb=" CA  LEU A  60 "
          pdb=" CD1 TYR A  61 "
   model   vdw
   4.049 3.770
nonbonded pdb=" OE1 GLN A  72 "
          pdb=" CE2 PHE A  73 "
   model   vdw
   4.049 3.340
nonbonded pdb=" C   ILE A   2 "
          pdb="O    HOH S  30 "
   model   vdw
   4.049 3.270
nonbonded pdb=" CG  PRO A   8 "
          pdb=" CE1 PHE A  13 "
   model   vdw sym.op.
   4.051 3.740 -x+1/2,y+1/2,-z+1
nonbonded pdb=" C   HIS A  64 "
          pdb=" CD2 HIS A  64 "
   model   vdw
   4.051 3.490
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" CA  PRO A  58 "
   model   vdw
   4.051 3.890
nonbonded pdb=" CD  GLU A   5 "
          pdb=" CE  LYS A   7 "
   model   vdw
   4.052 3.670
nonbonded pdb=" CD1 ILE A  47 "
          pdb=" CD2 LEU A  81 "
   model   vdw
   4.052 3.880
nonbonded pdb=" O   VAL A   4 "
          pdb=" C   GLU A   5 "
   model   vdw
   4.053 3.270
nonbonded pdb=" C   THR A  14 "
          pdb=" N   GLU A  30 "
   model   vdw
   4.054 3.350
nonbonded pdb=" C   PRO A  42 "
          pdb=" CG2 VAL A  43 "
   model   vdw
   4.054 3.690
nonbonded pdb=" O   GLN A  31 "
          pdb=" O   VAL A  45 "
   model   vdw
   4.054 3.040
nonbonded pdb=" N   ARG A  82 "
          pdb=" CD  ARG A  82 "
   model   vdw
   4.054 3.520
nonbonded pdb=" CG  TYR A  34 "
          pdb=" O   VAL A  43 "
   model   vdw
   4.055 3.260
nonbonded pdb=" CD  GLN A  12 "
          pdb="O    HOH S   8 "
   model   vdw
   4.055 3.270
nonbonded pdb=" N   LEU A  32 "
          pdb=" CD1 LEU A  32 "
   model   vdw
   4.055 3.540
nonbonded pdb=" OD1 ASP A  79 "
          pdb=" N   ARG A  80 "
   model   vdw
   4.055 3.120
nonbonded pdb=" O   ILE A   2 "
          pdb=" N   VAL A   4 "
   model   vdw
   4.055 3.120
nonbonded pdb=" CB  ASP A  50 "
          pdb=" OE1 GLU A  51 "
   model   vdw
   4.055 3.440
nonbonded pdb=" CD1 LEU A  28 "
          pdb=" OE2 GLU A  51 "
   model   vdw
   4.055 3.460
nonbonded pdb=" CB  PHE A  13 "
          pdb=" CD1 LEU A  49 "
   model   vdw
   4.055 3.860
nonbonded pdb=" N   PRO A  42 "
          pdb="O    HOH S   9 "
   model   vdw
   4.057 3.120
nonbonded pdb=" C   ASN A  29 "
          pdb=" N   LEU A  49 "
   model   vdw
   4.057 3.350
nonbonded pdb=" N   ASN A  29 "
          pdb=" ND2 ASN A  29 "
   model   vdw
   4.057 3.200
nonbonded pdb=" CA  PRO A   8 "
          pdb=" CB  PRO A  58 "
   model   vdw
   4.057 3.870
nonbonded pdb=" CG1 ILE A  47 "
          pdb=" CD2 LEU A  81 "
   model   vdw
   4.059 3.860
nonbonded pdb=" CA  PRO A   8 "
          pdb=" O   PHE A  13 "
   model   vdw sym.op.
   4.059 3.470 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CE1 HIS A  64 "
          pdb=" N   LEU A  65 "
   model   vdw
   4.059 3.340
nonbonded pdb=" O   LEU A  65 "
          pdb=" CB  PHE A  68 "
   model   vdw
   4.060 3.440
nonbonded pdb=" CG  ASP A  79 "
          pdb=" NH1 ARG A  82 "
   model   vdw
   4.060 3.350
nonbonded pdb=" O   ASP A  36 "
          pdb=" CG  LEU A  37 "
   model   vdw
   4.060 3.470
nonbonded pdb=" C   PHE A  13 "
          pdb=" CD2 PHE A  13 "
   model   vdw
   4.060 3.570
nonbonded pdb=" C   THR A  62 "
          pdb=" N   HIS A  64 "
   model   vdw
   4.061 3.350
nonbonded pdb=" C   LEU A  49 "
          pdb=" CG  ASP A  50 "
   model   vdw
   4.063 3.500
nonbonded pdb=" CB  SER A  67 "
          pdb=" CE1 PHE A  68 "
   model   vdw
   4.063 3.740
nonbonded pdb=" O   LEU A  49 "
          pdb=" CB  ASP A  50 "
   model   vdw
   4.063 3.440
nonbonded pdb=" O   THR A  14 "
          pdb=" CB  ASN A  29 "
   model   vdw
   4.064 3.440
nonbonded pdb=" CD1 LEU A  37 "
          pdb=" CG2 VAL A  43 "
   model   vdw
   4.064 3.880
nonbonded pdb=" OD1 ASP A  50 "
          pdb=" OE1 GLU A  51 "
   model   vdw
   4.065 3.040
nonbonded pdb=" C   LEU A  44 "
          pdb=" O   VAL A  45 "
   model   vdw
   4.065 3.270
nonbonded pdb=" N   SER A  66 "
          pdb=" CA  SER A  67 "
   model   vdw
   4.065 3.550
nonbonded pdb=" C   PHE A  68 "
          pdb=" CG  LYS A  69 "
   model   vdw
   4.065 3.670
nonbonded pdb=" CD  GLU A   5 "
          pdb=" CD  LYS A   7 "
   model   vdw
   4.066 3.670
nonbonded pdb=" OG  SER A  67 "
          pdb=" CA  LEU A  81 "
   model   vdw
   4.066 3.470
nonbonded pdb=" CA  LEU A  65 "
          pdb=" CE1 PHE A  68 "
   model   vdw
   4.066 3.770
nonbonded pdb=" C   ARG A  16 "
          pdb=" N   LEU A  28 "
   model   vdw
   4.067 3.350
nonbonded pdb=" CD1 ILE A  78 "
          pdb=" C   MSE A  77 "
   model   vdw sym.op.
   4.067 3.690 -x+1,y,-z+2
nonbonded pdb=" C   MSE A  77 "
          pdb=" CD1 ILE A  78 "
   model   vdw sym.op.
   4.067 3.690 -x+1,y,-z+2
nonbonded pdb=" OE1 GLN A  31 "
          pdb=" CG  TYR A  56 "
   model   vdw
   4.067 3.260
nonbonded pdb=" CD  ARG A  80 "
          pdb=" NH2 ARG A  82 "
   model   vdw
   4.067 3.520
nonbonded pdb=" CE  MSE A  77 "
          pdb=" O   ILE A  78 "
   model   vdw
   4.067 3.460
nonbonded pdb=" NE2 GLN A  10 "
          pdb=" O   LEU A  32 "
   model   vdw
   4.067 3.120
nonbonded pdb=" O   LEU A  65 "
          pdb=" CA  SER A  67 "
   model   vdw
   4.068 3.470
nonbonded pdb=" O   LYS A  69 "
          pdb=" CB  VAL A  70 "
   model   vdw
   4.068 3.470
nonbonded pdb=" CD1 ILE A  78 "
          pdb=" CD1 ILE A  78 "
   model   vdw sym.op.
   4.068 3.880 -x+1,y,-z+2
nonbonded pdb=" CB  GLN A  31 "
          pdb="O    HOH S   8 "
   model   vdw
   4.069 3.440
nonbonded pdb=" C   ASN A  29 "
          pdb=" O   GLU A  30 "
   model   vdw
   4.070 3.270
nonbonded pdb=" CE2 PHE A  68 "
          pdb=" CE2 PHE A  68 "
   model   vdw sym.op.
   4.071 3.640 -x+1,y,-z+2
nonbonded pdb=" O   CYS A  33 "
          pdb=" CD1 TYR A  34 "
   model   vdw
   4.071 3.340
nonbonded pdb=" O   ARG A  80 "
          pdb=" CZ  ARG A  82 "
   model   vdw
   4.071 3.270
nonbonded pdb=" CG1 VAL A   4 "
          pdb=" O   TYR A  34 "
   model   vdw
   4.071 3.460
nonbonded pdb=" C   LEU A  83 "
          pdb=" CG2 VAL A  84 "
   model   vdw
   4.071 3.690
nonbonded pdb=" N   GLN A  10 "
          pdb=" CA  ALA A  11 "
   model   vdw
   4.072 3.550
nonbonded pdb=" N   LEU A  60 "
          pdb=" CD1 TYR A  61 "
   model   vdw
   4.072 3.420
nonbonded pdb=" CD1 TYR A  56 "
          pdb=" CE2 TYR A  61 "
   model   vdw
   4.073 3.640
nonbonded pdb=" C   CYS A  33 "
          pdb=" O   VAL A  45 "
   model   vdw
   4.073 3.270
nonbonded pdb=" O   SER A   9 "
          pdb=" O   THR A  15 "
   model   vdw sym.op.
   4.073 3.040 -x+1/2,y+1/2,-z+1
nonbonded pdb=" N   THR A  14 "
          pdb=" C   GLU A  30 "
   model   vdw
   4.074 3.350
nonbonded pdb=" C   PRO A  58 "
          pdb=" O   GLY A  59 "
   model   vdw
   4.074 3.270
nonbonded pdb=" C   LEU A  28 "
          pdb=" N   GLU A  30 "
   model   vdw
   4.074 3.350
nonbonded pdb=" O   GLN A  31 "
          pdb=" CD2 LEU A  32 "
   model   vdw
   4.075 3.460
nonbonded pdb=" CD1 PHE A  13 "
          pdb=" ND2 ASN A  29 "
   model   vdw
   4.075 3.420
nonbonded pdb=" N   PHE A  13 "
          pdb=" CD1 PHE A  13 "
   model   vdw
   4.075 3.420
nonbonded pdb=" CB  ALA A  11 "
          pdb=" CG2 THR A  14 "
   model   vdw sym.op.
   4.075 3.880 -x+1/2,y+1/2,-z+1
nonbonded pdb=" N   HIS A  64 "
          pdb=" C   ARG A  82 "
   model   vdw
   4.076 3.350
nonbonded pdb=" C   ALA A  11 "
          pdb=" NE2 GLN A  31 "
   model   vdw
   4.077 3.350
nonbonded pdb=" O   VAL A   4 "
          pdb=" O   GLY A  59 "
   model   vdw
   4.077 3.040
nonbonded pdb=" CG  ASP A  36 "
          pdb="O    HOH S   5 "
   model   vdw
   4.077 3.270
nonbonded pdb=" C   HIS A  64 "
          pdb=" O   LEU A  65 "
   model   vdw
   4.078 3.270
nonbonded pdb=" C   MSE A  77 "
          pdb=" N   ASP A  79 "
   model   vdw
   4.078 3.350
nonbonded pdb=" N   GLY A  71 "
          pdb=" C   SER A  75 "
   model   vdw
   4.078 3.350
nonbonded pdb=" CG2 VAL A   4 "
          pdb=" CG2 VAL A  63 "
   model   vdw
   4.078 3.880
nonbonded pdb=" O   THR A  15 "
          pdb="O    HOH S  11 "
   model   vdw
   4.079 3.040
nonbonded pdb=" C   LEU A  65 "
          pdb=" OG  SER A  66 "
   model   vdw
   4.079 3.270
nonbonded pdb=" C   CYS A  33 "
          pdb=" N   VAL A  45 "
   model   vdw
   4.079 3.350
nonbonded pdb=" O   VAL A  35 "
          pdb="O    HOH S   9 "
   model   vdw
   4.079 3.040
nonbonded pdb=" CB  SER A  67 "
          pdb=" CD1 PHE A  68 "
   model   vdw
   4.080 3.740
nonbonded pdb=" C   ASP A  36 "
          pdb=" CD2 LEU A  65 "
   model   vdw sym.op.
   4.080 3.690 -x+1,y,-z+2
nonbonded pdb=" O   GLY A  74 "
          pdb=" CB  SER A  75 "
   model   vdw
   4.080 3.440
nonbonded pdb=" CA  LEU A  44 "
          pdb="O    HOH S  25 "
   model   vdw
   4.081 3.470
nonbonded pdb=" CD2 LEU A  32 "
          pdb=" CG  LYS A  46 "
   model   vdw
   4.081 3.860
nonbonded pdb=" O   LEU A  81 "
          pdb=" N   LEU A  83 "
   model   vdw
   4.082 3.120
nonbonded pdb=" CB  ALA A  57 "
          pdb=" OH  TYR A  61 "
   model   vdw
   4.083 3.460
nonbonded pdb=" C   PRO A   8 "
          pdb=" OG1 THR A  15 "
   model   vdw sym.op.
   4.083 3.270 -x+1/2,y+1/2,-z+1
nonbonded pdb=" OH  TYR A  26 "
          pdb=" CB  PRO A  85 "
   model   vdw sym.op.
   4.085 3.440 x,y-1,z
nonbonded pdb=" N   ILE A  78 "
          pdb=" CD1 ILE A  78 "
   model   vdw sym.op.
   4.085 3.540 -x+1,y,-z+2
nonbonded pdb=" CD1 ILE A  78 "
          pdb=" N   ILE A  78 "
   model   vdw sym.op.
   4.085 3.540 -x+1,y,-z+2
nonbonded pdb=" CE1 TYR A  56 "
          pdb=" N   LEU A  83 "
   model   vdw
   4.086 3.420
nonbonded pdb=" CA  LEU A  65 "
          pdb=" N   SER A  67 "
   model   vdw
   4.086 3.550
nonbonded pdb=" CG  PRO A   8 "
          pdb=" O   PHE A  13 "
   model   vdw sym.op.
   4.087 3.440 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CG2 VAL A  35 "
          pdb=" CG1 VAL A  45 "
   model   vdw
   4.087 3.880
nonbonded pdb=" C   LYS A   7 "
          pdb=" CA  SER A   9 "
   model   vdw
   4.087 3.700
nonbonded pdb=" C   GLN A  72 "
          pdb="O    HOH S   3 "
   model   vdw
   4.087 3.270
nonbonded pdb=" C   SER A   9 "
          pdb=" NE2 GLN A  12 "
   model   vdw
   4.089 3.350
nonbonded pdb=" O   ASP A  79 "
          pdb=" C   ARG A  80 "
   model   vdw
   4.089 3.270
nonbonded pdb=" O   ASP A  50 "
          pdb=" O   GLN A  53 "
   model   vdw
   4.089 3.040
nonbonded pdb=" N   PRO A   8 "
          pdb=" CB  PRO A  58 "
   model   vdw
   4.089 3.520
nonbonded pdb=" OD1 ASN A  29 "
          pdb="O    HOH S  14 "
   model   vdw
   4.089 3.040
nonbonded pdb=" N   VAL A  35 "
          pdb=" C   VAL A  43 "
   model   vdw
   4.090 3.350
nonbonded pdb=" O   LEU A  65 "
          pdb=" C   SER A  67 "
   model   vdw
   4.090 3.270
nonbonded pdb=" CG  LYS A  69 "
          pdb=" O   MSE A  77 "
   model   vdw
   4.090 3.440
nonbonded pdb=" O   TYR A  56 "
          pdb=" CB  ALA A  57 "
   model   vdw
   4.090 3.460
nonbonded pdb=" O   LEU A  44 "
          pdb=" C   VAL A  45 "
   model   vdw
   4.090 3.270
nonbonded pdb=" CA  GLN A  10 "
          pdb="O    HOH S  23 "
   model   vdw
   4.090 3.470
nonbonded pdb=" CG  MSE A  77 "
          pdb="O    HOH S   3 "
   model   vdw
   4.091 3.440
nonbonded pdb=" CB  ARG A  80 "
          pdb=" NE  ARG A  82 "
   model   vdw
   4.092 3.520
nonbonded pdb=" C   ILE A   6 "
          pdb=" CA  PRO A  58 "
   model   vdw
   4.092 3.700
nonbonded pdb=" N   ILE A   6 "
          pdb=" C   GLY A  59 "
   model   vdw
   4.093 3.350
nonbonded pdb=" CA  GLU A   5 "
          pdb=" O   TYR A  34 "
   model   vdw
   4.094 3.470
nonbonded pdb=" CB  HIS A  64 "
          pdb=" CG1 VAL A  84 "
   model   vdw
   4.094 3.860
nonbonded pdb=" CD2 TYR A  34 "
          pdb=" CB  PRO A  42 "
   model   vdw
   4.095 3.740
nonbonded pdb=" CA  TYR A  56 "
          pdb="O    HOH S  39 "
   model   vdw
   4.095 3.470
nonbonded pdb=" CG  LEU A  32 "
          pdb="O    HOH S   8 "
   model   vdw
   4.096 3.470
nonbonded pdb=" NH2 ARG A  16 "
          pdb=" CG  TYR A  61 "
   model   vdw sym.op.
   4.096 3.340 x,y-1,z
nonbonded pdb=" CB  PHE A  13 "
          pdb=" C   GLU A  30 "
   model   vdw
   4.096 3.670
nonbonded pdb=" N   THR A  14 "
          pdb=" N   GLU A  30 "
   model   vdw
   4.096 3.200
nonbonded pdb=" OD2 ASP A  50 "
          pdb=" OE1 GLN A  53 "
   model   vdw
   4.097 3.040
nonbonded pdb=" O   GLY A  59 "
          pdb=" N   TYR A  61 "
   model   vdw
   4.097 3.120
nonbonded pdb=" CA  LEU A  49 "
          pdb=" O   ASP A  50 "
   model   vdw
   4.097 3.470
nonbonded pdb=" O   THR A  62 "
          pdb=" CA  VAL A  84 "
   model   vdw
   4.097 3.470
nonbonded pdb=" OD1 ASP A  50 "
          pdb=" CZ  ARG A  82 "
   model   vdw
   4.098 3.270
nonbonded pdb=" O   ARG A  80 "
          pdb=" CA  ARG A  82 "
   model   vdw
   4.098 3.470
nonbonded pdb=" CD1 ILE A   2 "
          pdb=" N   LYS A   3 "
   model   vdw
   4.099 3.540
nonbonded pdb=" CG1 VAL A  45 "
          pdb=" N   LEU A  76 "
   model   vdw sym.op.
   4.099 3.540 -x+1,y,-z+2
nonbonded pdb=" CA  GLU A   5 "
          pdb=" CD2 LEU A  60 "
   model   vdw
   4.099 3.890
nonbonded pdb=" O   LEU A  37 "
          pdb=" CG  ASN A  39 "
   model   vdw
   4.100 3.270
nonbonded pdb=" O   GLY A  71 "
          pdb=" CB  GLN A  72 "
   model   vdw
   4.100 3.440
nonbonded pdb=" C   GLU A  40 "
          pdb=" CD1 TYR A  41 "
   model   vdw
   4.100 3.570
nonbonded pdb=" CA  ASP A  50 "
          pdb=" CD  GLU A  51 "
   model   vdw
   4.100 3.700
nonbonded pdb=" O   TYR A  34 "
          pdb=" N   ASP A  36 "
   model   vdw
   4.101 3.120
nonbonded pdb=" CD1 LEU A  28 "
          pdb=" N   ASN A  29 "
   model   vdw
   4.101 3.540
nonbonded pdb=" OE1 GLN A  10 "
          pdb=" N   TYR A  34 "
   model   vdw
   4.101 3.120
nonbonded pdb=" CB  ASN A  29 "
          pdb=" CB  LEU A  49 "
   model   vdw
   4.101 3.840
nonbonded pdb=" CD2 LEU A  32 "
          pdb=" CB  LYS A  46 "
   model   vdw
   4.101 3.860
nonbonded pdb=" CB  GLU A  30 "
          pdb=" CD  LYS A  46 "
   model   vdw
   4.101 3.840
nonbonded pdb=" CD2 LEU A  49 "
          pdb=" CG  GLN A  53 "
   model   vdw
   4.103 3.860
nonbonded pdb=" CA  GLU A  51 "
          pdb=" OE2 GLU A  51 "
   model   vdw
   4.103 3.470
nonbonded pdb=" CG1 VAL A  45 "
          pdb=" CA  LYS A  46 "
   model   vdw
   4.103 3.890
nonbonded pdb=" O   PRO A  42 "
          pdb=" CG  PRO A  42 "
   model   vdw
   4.104 3.440
nonbonded pdb=" O   GLN A  10 "
          pdb=" CB  ALA A  11 "
   model   vdw
   4.104 3.460
nonbonded pdb=" OG  SER A  66 "
          pdb=" CG  ARG A  82 "
   model   vdw
   4.104 3.440
nonbonded pdb=" CG2 VAL A  84 "
          pdb=" O   PRO A  85 "
   model   vdw
   4.106 3.460
nonbonded pdb=" O   CYS A  33 "
          pdb=" C   VAL A  45 "
   model   vdw
   4.106 3.270
nonbonded pdb=" CE1 TYR A  56 "
          pdb=" CG  LEU A  83 "
   model   vdw
   4.106 3.770
nonbonded pdb=" C   TYR A  56 "
          pdb=" N   PRO A  58 "
   model   vdw
   4.108 3.350
nonbonded pdb=" NE2 GLN A  31 "
          pdb=" CA  TYR A  56 "
   model   vdw
   4.108 3.550
nonbonded pdb=" O   VAL A  63 "
          pdb=" CB  HIS A  64 "
   model   vdw
   4.108 3.440
nonbonded pdb=" C   TYR A  41 "
          pdb=" N   VAL A  43 "
   model   vdw
   4.108 3.350
nonbonded pdb=" CB  CYS A  33 "
          pdb=" O   VAL A  45 "
   model   vdw
   4.108 3.440
nonbonded pdb=" CA  VAL A  35 "
          pdb=" O   VAL A  43 "
   model   vdw
   4.109 3.470
nonbonded pdb=" CG1 VAL A   4 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   4.110 3.880
nonbonded pdb=" C   LYS A   3 "
          pdb=" N   ASP A  36 "
   model   vdw
   4.110 3.350
nonbonded pdb=" CB  TYR A  61 "
          pdb=" CB  LEU A  83 "
   model   vdw
   4.112 3.840
nonbonded pdb=" ND1 HIS A  64 "
          pdb=" C   LEU A  65 "
   model   vdw
   4.113 3.350
nonbonded pdb=" CG2 THR A  15 "
          pdb="O    HOH S  14 "
   model   vdw
   4.113 3.460
nonbonded pdb=" CG  TYR A  61 "
          pdb=" OH  TYR A  61 "
   model   vdw
   4.114 3.260
nonbonded pdb=" O   ARG A  16 "
          pdb=" C   LEU A  28 "
   model   vdw
   4.114 3.270
nonbonded pdb=" CB  TYR A  41 "
          pdb=" O   PRO A  42 "
   model   vdw
   4.114 3.440
nonbonded pdb=" CD1 LEU A  37 "
          pdb=" CA  LYS A  69 "
   model   vdw sym.op.
   4.115 3.890 -x+1,y,-z+2
nonbonded pdb=" CG  ARG A  82 "
          pdb=" NH1 ARG A  82 "
   model   vdw
   4.115 3.520
nonbonded pdb=" CG  LYS A   3 "
          pdb=" CE1 PHE A  73 "
   model   vdw sym.op.
   4.116 3.740 -x+1,y+1,-z+2
nonbonded pdb=" C   SER A  66 "
          pdb=" O   SER A  67 "
   model   vdw
   4.116 3.270
nonbonded pdb=" CB  SER A  67 "
          pdb=" CA  LEU A  81 "
   model   vdw
   4.118 3.870
nonbonded pdb=" CG2 VAL A  43 "
          pdb=" N   LEU A  44 "
   model   vdw
   4.118 3.540
nonbonded pdb=" CB  ILE A   6 "
          pdb=" N   GLY A  59 "
   model   vdw
   4.119 3.550
nonbonded pdb=" O   HIS A  64 "
          pdb=" C   SER A  66 "
   model   vdw
   4.119 3.270
nonbonded pdb=" O   ILE A   6 "
          pdb=" CB  LYS A   7 "
   model   vdw
   4.119 3.440
nonbonded pdb=" C   LEU A  81 "
          pdb=" N   LEU A  83 "
   model   vdw
   4.119 3.350
nonbonded pdb=" CE2 TYR A  56 "
          pdb=" CB  LEU A  83 "
   model   vdw
   4.120 3.740
nonbonded pdb=" CA  LYS A   7 "
          pdb=" N   SER A   9 "
   model   vdw
   4.120 3.550
nonbonded pdb=" CG2 ILE A  47 "
          pdb=" CA  THR A  48 "
   model   vdw
   4.120 3.890
nonbonded pdb=" CG  LEU A  81 "
          pdb=" N   ARG A  82 "
   model   vdw
   4.120 3.550
nonbonded pdb=" CA  MSE A  77 "
          pdb=" CE  MSE A  77 "
   model   vdw
   4.120 3.890
nonbonded pdb=" O   SER A  67 "
          pdb=" C   ASP A  79 "
   model   vdw
   4.120 3.270
nonbonded pdb=" OH  TYR A  56 "
          pdb=" O   LEU A  83 "
   model   vdw
   4.121 3.040
nonbonded pdb=" OG1 THR A  15 "
          pdb=" O   LEU A  28 "
   model   vdw
   4.122 3.040
nonbonded pdb=" C   LEU A  37 "
          pdb=" CG  LEU A  65 "
   model   vdw sym.op.
   4.122 3.700 -x+1,y,-z+2
nonbonded pdb=" O   VAL A  35 "
          pdb=" CA  VAL A  43 "
   model   vdw
   4.124 3.470
nonbonded pdb=" C   VAL A  35 "
          pdb=" CB  PRO A  42 "
   model   vdw
   4.124 3.670
nonbonded pdb=" C   LEU A  60 "
          pdb=" CD2 LEU A  60 "
   model   vdw
   4.125 3.690
nonbonded pdb=" CD1 LEU A  49 "
          pdb=" C   PRO A  54 "
   model   vdw
   4.125 3.690
nonbonded pdb=" CD1 ILE A  47 "
          pdb=" CG  LEU A  83 "
   model   vdw
   4.126 3.890
nonbonded pdb=" C   VAL A  45 "
          pdb=" N   ILE A  47 "
   model   vdw
   4.126 3.350
nonbonded pdb=" C   GLY A  71 "
          pdb=" N   GLY A  74 "
   model   vdw
   4.127 3.350
nonbonded pdb=" O   MSE A  77 "
          pdb=" CB  ILE A  78 "
   model   vdw
   4.127 3.470
nonbonded pdb=" N   PHE A  68 "
          pdb=" CE1 PHE A  68 "
   model   vdw
   4.127 3.420
nonbonded pdb=" CG  PRO A  54 "
          pdb=" N   ALA A  55 "
   model   vdw
   4.127 3.520
nonbonded pdb=" N   PHE A  73 "
          pdb=" CA  GLY A  74 "
   model   vdw
   4.127 3.520
nonbonded pdb=" N   TYR A  61 "
          pdb=" CD2 TYR A  61 "
   model   vdw
   4.128 3.420
nonbonded pdb=" O   GLY A  74 "
          pdb=" N   LEU A  76 "
   model   vdw
   4.128 3.120
nonbonded pdb=" CG  TYR A  56 "
          pdb=" OH  TYR A  56 "
   model   vdw
   4.129 3.260
nonbonded pdb=" CE2 PHE A  68 "
          pdb=" CD1 ILE A  78 "
   model   vdw
   4.129 3.760
nonbonded pdb=" O   ALA A  57 "
          pdb=" CB  PRO A  58 "
   model   vdw
   4.130 3.440
nonbonded pdb=" CG2 ILE A  47 "
          pdb=" N   LEU A  49 "
   model   vdw
   4.130 3.540
nonbonded pdb=" CG  TYR A  61 "
          pdb=" CD1 LEU A  83 "
   model   vdw
   4.130 3.680
nonbonded pdb=" N   GLN A  72 "
          pdb=" CA  PHE A  73 "
   model   vdw
   4.130 3.550
nonbonded pdb=" N   SER A  67 "
          pdb=" CD  ARG A  82 "
   model   vdw
   4.131 3.520
nonbonded pdb=" C   GLU A   5 "
          pdb=" N   TYR A  34 "
   model   vdw
   4.132 3.350
nonbonded pdb=" CZ  PHE A  13 "
          pdb=" ND2 ASN A  29 "
   model   vdw
   4.132 3.420
nonbonded pdb=" C   LEU A  65 "
          pdb=" O   SER A  66 "
   model   vdw
   4.132 3.270
nonbonded pdb=" O   LEU A  49 "
          pdb=" N   GLU A  51 "
   model   vdw
   4.133 3.120
nonbonded pdb=" CZ  TYR A  56 "
          pdb=" CA  LEU A  83 "
   model   vdw
   4.134 3.690
nonbonded pdb=" O   ILE A  78 "
          pdb=" CB  ASP A  79 "
   model   vdw
   4.134 3.440
nonbonded pdb=" CB  PRO A  54 "
          pdb=" O   ALA A  55 "
   model   vdw
   4.134 3.440
nonbonded pdb=" O   ASP A  50 "
          pdb=" CB  GLU A  51 "
   model   vdw
   4.134 3.440
nonbonded pdb=" N   PRO A   8 "
          pdb=" CA  SER A   9 "
   model   vdw
   4.135 3.550
nonbonded pdb=" O   GLN A  31 "
          pdb=" O   LEU A  32 "
   model   vdw
   4.135 3.040
nonbonded pdb=" CE1 TYR A  56 "
          pdb=" CA  LEU A  83 "
   model   vdw
   4.136 3.770
nonbonded pdb=" O   PRO A  58 "
          pdb=" C   GLY A  59 "
   model   vdw
   4.136 3.270
nonbonded pdb=" O   GLU A  40 "
          pdb=" C   TYR A  41 "
   model   vdw
   4.136 3.270
nonbonded pdb=" CA  ARG A  16 "
          pdb="O    HOH S  11 "
   model   vdw
   4.137 3.470
nonbonded pdb=" O   MSE A  77 "
          pdb=" O   ILE A  78 "
   model   vdw
   4.137 3.040
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" O   ALA A  57 "
   model   vdw
   4.138 3.460
nonbonded pdb=" NH2 ARG A  16 "
          pdb=" OH  TYR A  61 "
   model   vdw sym.op.
   4.138 3.120 x,y-1,z
nonbonded pdb=" N   GLU A  40 "
          pdb=" CA  TYR A  41 "
   model   vdw
   4.138 3.550
nonbonded pdb=" CD  LYS A  69 "
          pdb=" CG  ASP A  79 "
   model   vdw
   4.139 3.670
nonbonded pdb=" C   ILE A   2 "
          pdb=" N   VAL A   4 "
   model   vdw
   4.139 3.350
nonbonded pdb=" O   GLN A  10 "
          pdb=" O   LEU A  32 "
   model   vdw
   4.139 3.040
nonbonded pdb=" O   PRO A  54 "
          pdb=" CB  ALA A  55 "
   model   vdw
   4.139 3.460
nonbonded pdb=" CD  GLU A   5 "
          pdb=" CD2 LEU A  60 "
   model   vdw
   4.140 3.690
nonbonded pdb=" C   ILE A  47 "
          pdb=" O   THR A  48 "
   model   vdw
   4.141 3.270
nonbonded pdb=" O   GLY A  71 "
          pdb=" O   GLN A  72 "
   model   vdw
   4.141 3.040
nonbonded pdb=" CZ  ARG A  16 "
          pdb=" N   LEU A  60 "
   model   vdw sym.op.
   4.141 3.350 x,y-1,z
nonbonded pdb=" CB  TYR A  61 "
          pdb=" O   THR A  62 "
   model   vdw
   4.141 3.440
nonbonded pdb=" O   ASP A  50 "
          pdb=" OE1 GLN A  53 "
   model   vdw
   4.141 3.040
nonbonded pdb=" CD2 TYR A  41 "
          pdb=" OH  TYR A  34 "
   model   vdw sym.op.
   4.141 3.340 -x+1,y,-z+1
nonbonded pdb=" OH  TYR A  34 "
          pdb=" CD2 TYR A  41 "
   model   vdw sym.op.
   4.141 3.340 -x+1,y,-z+1
nonbonded pdb=" CA  GLN A  12 "
          pdb=" OE1 GLN A  12 "
   model   vdw
   4.142 3.470
nonbonded pdb=" CA  GLU A  51 "
          pdb=" N   GLN A  53 "
   model   vdw
   4.142 3.550
nonbonded pdb=" CG  PHE A  13 "
          pdb=" CB  ASN A  29 "
   model   vdw
   4.143 3.660
nonbonded pdb=" O   PRO A  42 "
          pdb=" N   LEU A  44 "
   model   vdw
   4.143 3.120
nonbonded pdb=" CG  TYR A  34 "
          pdb=" OH  TYR A  34 "
   model   vdw
   4.143 3.260
nonbonded pdb=" CG  TYR A  26 "
          pdb=" OH  TYR A  26 "
   model   vdw
   4.143 3.260
nonbonded pdb=" CB  ASN A  39 "
          pdb=" CA  GLU A  40 "
   model   vdw
   4.143 3.870
nonbonded pdb=" CB  GLN A  10 "
          pdb=" C   LEU A  32 "
   model   vdw
   4.143 3.670
nonbonded pdb=" C   LEU A  76 "
          pdb=" CD1 ILE A  78 "
   model   vdw sym.op.
   4.144 3.690 -x+1,y,-z+2
nonbonded pdb=" CG  HIS A  64 "
          pdb=" CG1 VAL A  84 "
   model   vdw
   4.144 3.680
nonbonded pdb=" CD1 PHE A  13 "
          pdb=" CA  THR A  14 "
   model   vdw
   4.144 3.770
nonbonded pdb=" CD1 LEU A  76 "
          pdb=" N   MSE A  77 "
   model   vdw
   4.144 3.540
nonbonded pdb=" CG  TYR A  41 "
          pdb=" OH  TYR A  41 "
   model   vdw
   4.144 3.260
nonbonded pdb=" C   GLN A  31 "
          pdb=" O   ILE A  47 "
   model   vdw
   4.144 3.270
nonbonded pdb=" N   ILE A   6 "
          pdb=" CD1 ILE A   6 "
   model   vdw
   4.145 3.540
nonbonded pdb=" O   GLN A  53 "
          pdb=" N   ALA A  55 "
   model   vdw
   4.146 3.120
nonbonded pdb=" CZ  TYR A  56 "
          pdb="O    HOH S  39 "
   model   vdw
   4.148 3.260
nonbonded pdb=" CB  VAL A  84 "
          pdb=" O   PRO A  85 "
   model   vdw
   4.149 3.470
nonbonded pdb=" C   ARG A  16 "
          pdb=" OG  SER A  17 "
   model   vdw
   4.149 3.270
nonbonded pdb=" NE  ARG A  16 "
          pdb=" CB  PRO A  85 "
   model   vdw sym.op.
   4.149 3.520 x,y-1,z
nonbonded pdb=" CD1 LEU A  49 "
          pdb=" N   ALA A  55 "
   model   vdw
   4.149 3.540
nonbonded pdb=" O   ASN A  29 "
          pdb=" O   LEU A  49 "
   model   vdw
   4.149 3.040
nonbonded pdb=" O   LEU A  37 "
          pdb="O    HOH S   9 "
   model   vdw
   4.150 3.040
nonbonded pdb=" O   GLY A  59 "
          pdb=" CD2 LEU A  60 "
   model   vdw
   4.150 3.460
nonbonded pdb=" CG  LYS A   3 "
          pdb=" CD2 LEU A  60 "
   model   vdw
   4.151 3.860
nonbonded pdb=" CB  VAL A  43 "
          pdb=" O   LEU A  44 "
   model   vdw
   4.153 3.470
nonbonded pdb=" O   LEU A  65 "
          pdb=" CG  PHE A  68 "
   model   vdw
   4.153 3.260
nonbonded pdb=" O   GLY A  59 "
          pdb=" CG  LEU A  60 "
   model   vdw
   4.153 3.470
nonbonded pdb=" O   THR A  48 "
          pdb=" OG1 THR A  48 "
   model   vdw
   4.153 3.040
nonbonded pdb=" C   ASP A  36 "
          pdb=" OD2 ASP A  36 "
   model   vdw
   4.154 3.270
nonbonded pdb=" O   LEU A  37 "
          pdb=" CG  LEU A  37 "
   model   vdw
   4.155 3.470
nonbonded pdb=" C   THR A  15 "
          pdb=" O   PRO A   8 "
   model   vdw sym.op.
   4.155 3.270 -x+1/2,y-1/2,-z+1
nonbonded pdb=" O   PRO A   8 "
          pdb=" C   THR A  15 "
   model   vdw sym.op.
   4.155 3.270 -x+1/2,y+1/2,-z+1
nonbonded pdb=" N   VAL A  35 "
          pdb=" N   VAL A  43 "
   model   vdw
   4.155 3.200
nonbonded pdb=" CA  THR A  14 "
          pdb=" O   GLU A  30 "
   model   vdw
   4.156 3.470
nonbonded pdb=" O   THR A  48 "
          pdb=" CZ  ARG A  80 "
   model   vdw
   4.156 3.270
nonbonded pdb=" ND1 HIS A  64 "
          pdb=" CA  LEU A  65 "
   model   vdw
   4.156 3.550
nonbonded pdb=" CG  TYR A  34 "
          pdb=" CB  PRO A  42 "
   model   vdw
   4.157 3.660
nonbonded pdb=" CB  SER A  67 "
          pdb=" C   ARG A  80 "
   model   vdw
   4.157 3.670
nonbonded pdb=" N   LEU A  65 "
          pdb=" CD1 LEU A  65 "
   model   vdw
   4.157 3.540
nonbonded pdb=" N   VAL A   4 "
          pdb=" C   TYR A  61 "
   model   vdw
   4.158 3.350
nonbonded pdb=" CB  SER A   9 "
          pdb="O    HOH S  23 "
   model   vdw
   4.158 3.440
nonbonded pdb=" O   GLN A  31 "
          pdb=" CG  GLN A  31 "
   model   vdw
   4.159 3.440
nonbonded pdb=" CG  PHE A  73 "
          pdb="O    HOH S   3 "
   model   vdw
   4.161 3.260
nonbonded pdb=" C   VAL A  35 "
          pdb=" N   VAL A  43 "
   model   vdw
   4.162 3.350
nonbonded pdb=" CG  ASP A  36 "
          pdb=" N   GLY A  38 "
   model   vdw
   4.163 3.350
nonbonded pdb=" CG2 ILE A  78 "
          pdb=" N   LEU A  81 "
   model   vdw
   4.163 3.540
nonbonded pdb=" CB  THR A  62 "
          pdb=" CZ  PHE A  73 "
   model   vdw sym.op.
   4.163 3.770 -x+1,y+1,-z+2
nonbonded pdb=" N   SER A   9 "
          pdb=" N   THR A  15 "
   model   vdw sym.op.
   4.164 3.200 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CE2 TYR A  34 "
          pdb=" N   LEU A  44 "
   model   vdw
   4.165 3.420
nonbonded pdb=" O   GLY A  38 "
          pdb=" ND2 ASN A  39 "
   model   vdw
   4.165 3.120
nonbonded pdb=" NE2 GLN A  31 "
          pdb=" CB  TYR A  56 "
   model   vdw
   4.165 3.520
nonbonded pdb=" OG1 THR A  62 "
          pdb=" CZ  PHE A  73 "
   model   vdw sym.op.
   4.165 3.340 -x+1,y+1,-z+2
nonbonded pdb=" CG  GLU A   5 "
          pdb=" CA  ILE A   6 "
   model   vdw
   4.165 3.870
nonbonded pdb=" N   ALA A  11 "
          pdb=" CA  GLN A  12 "
   model   vdw
   4.165 3.550
nonbonded pdb=" O   PRO A  42 "
          pdb=" CG1 VAL A  43 "
   model   vdw
   4.166 3.460
nonbonded pdb=" N   ASP A  36 "
          pdb=" OD1 ASP A  36 "
   model   vdw
   4.166 3.120
nonbonded pdb=" O   GLN A  12 "
          pdb=" CD  GLN A  31 "
   model   vdw
   4.167 3.270
nonbonded pdb=" CD1 ILE A  78 "
          pdb=" CA  MSE A  77 "
   model   vdw sym.op.
   4.167 3.890 -x+1,y,-z+2
nonbonded pdb=" CA  MSE A  77 "
          pdb=" CD1 ILE A  78 "
   model   vdw sym.op.
   4.167 3.890 -x+1,y,-z+2
nonbonded pdb=" CB  LYS A   7 "
          pdb=" N   SER A   9 "
   model   vdw
   4.168 3.520
nonbonded pdb=" CG2 ILE A  78 "
          pdb=" C   ARG A  80 "
   model   vdw
   4.168 3.690
nonbonded pdb=" C   ALA A  55 "
          pdb="O    HOH S  39 "
   model   vdw
   4.169 3.270
nonbonded pdb=" OH  TYR A  26 "
          pdb=" CE2 TYR A  61 "
   model   vdw sym.op.
   4.169 3.340 x,y-1,z
nonbonded pdb=" NZ  LYS A   7 "
          pdb=" CZ  TYR A  41 "
   model   vdw sym.op.
   4.169 3.340 -x+1,y,-z+1
nonbonded pdb=" CB  HIS A  64 "
          pdb=" C   ARG A  82 "
   model   vdw
   4.169 3.670
nonbonded pdb=" CA  ASP A  36 "
          pdb="O    HOH S   9 "
   model   vdw
   4.170 3.470
nonbonded pdb=" CA  MSE A  77 "
          pdb="SE   MSE A  77 "
   model   vdw
   4.170 3.080
nonbonded pdb=" N   GLY A  71 "
          pdb=" CG  MSE A  77 "
   model   vdw
   4.170 3.520
nonbonded pdb=" OG1 THR A  14 "
          pdb=" CB  GLU A  30 "
   model   vdw
   4.171 3.440
nonbonded pdb=" N   ALA A  11 "
          pdb=" CD  GLN A  12 "
   model   vdw
   4.171 3.350
nonbonded pdb=" CG2 ILE A  78 "
          pdb=" CA  ASP A  79 "
   model   vdw
   4.171 3.890
nonbonded pdb=" C   ASP A  50 "
          pdb=" OE2 GLU A  51 "
   model   vdw
   4.171 3.270
nonbonded pdb=" C   TYR A  26 "
          pdb=" CE1 TYR A  26 "
   model   vdw
   4.172 3.570
nonbonded pdb=" CB  MSE A  77 "
          pdb=" CA  ILE A  78 "
   model   vdw
   4.172 3.870
nonbonded pdb=" OH  TYR A  34 "
          pdb=" CD1 LEU A  44 "
   model   vdw
   4.172 3.460
nonbonded pdb=" CB  LYS A   3 "
          pdb=" CB  ASP A  36 "
   model   vdw
   4.172 3.840
nonbonded pdb=" O   PRO A   8 "
          pdb=" CB  SER A   9 "
   model   vdw
   4.173 3.440
nonbonded pdb=" CB  THR A  48 "
          pdb=" NE  ARG A  80 "
   model   vdw
   4.173 3.550
nonbonded pdb=" OH  TYR A  56 "
          pdb=" O   LEU A  81 "
   model   vdw
   4.173 3.040
nonbonded pdb=" CB  TYR A  61 "
          pdb=" C   VAL A  84 "
   model   vdw
   4.173 3.670
nonbonded pdb=" CG  LYS A  69 "
          pdb="O    HOH S   1 "
   model   vdw sym.op.
   4.175 3.440 -x,y+1,-z+1
nonbonded pdb=" N   SER A  67 "
          pdb=" CA  PHE A  68 "
   model   vdw
   4.176 3.550
nonbonded pdb=" CD1 ILE A   6 "
          pdb=" OE1 GLN A  31 "
   model   vdw
   4.176 3.460
nonbonded pdb=" C   TYR A  34 "
          pdb=" N   ASP A  36 "
   model   vdw
   4.177 3.350
nonbonded pdb=" OE2 GLU A  40 "
          pdb=" CA  SER A   9 "
   model   vdw sym.op.
   4.178 3.470 -x+1,y,-z+1
nonbonded pdb=" CA  SER A   9 "
          pdb=" OE2 GLU A  40 "
   model   vdw sym.op.
   4.178 3.470 -x+1,y,-z+1
nonbonded pdb=" N   GLN A  10 "
          pdb="O    HOH S  23 "
   model   vdw
   4.178 3.120
nonbonded pdb=" CB  PHE A  13 "
          pdb=" O   THR A  14 "
   model   vdw
   4.179 3.440
nonbonded pdb=" CG1 VAL A  70 "
          pdb=" C   GLY A  74 "
   model   vdw
   4.179 3.690
nonbonded pdb=" CB  VAL A  45 "
          pdb=" O   GLY A  74 "
   model   vdw sym.op.
   4.179 3.470 -x+1,y,-z+2
nonbonded pdb=" CD1 LEU A  37 "
          pdb=" C   PHE A  68 "
   model   vdw sym.op.
   4.179 3.690 -x+1,y,-z+2
nonbonded pdb=" CB  LEU A  32 "
          pdb=" O   VAL A  45 "
   model   vdw
   4.179 3.440
nonbonded pdb=" CD2 TYR A  34 "
          pdb=" CA  LEU A  44 "
   model   vdw
   4.180 3.770
nonbonded pdb=" C   ASN A  39 "
          pdb=" CG  GLU A  40 "
   model   vdw
   4.181 3.670
nonbonded pdb=" O   LYS A   7 "
          pdb=" CB  PRO A  58 "
   model   vdw
   4.181 3.440
nonbonded pdb=" O   CYS A  33 "
          pdb=" N   VAL A  35 "
   model   vdw
   4.181 3.120
nonbonded pdb=" O   PRO A  58 "
          pdb=" CG  PRO A  58 "
   model   vdw
   4.182 3.440
nonbonded pdb=" C   SER A   9 "
          pdb=" O   THR A  15 "
   model   vdw sym.op.
   4.182 3.270 -x+1/2,y+1/2,-z+1
nonbonded pdb=" O   PRO A  42 "
          pdb=" O   VAL A  43 "
   model   vdw
   4.182 3.040
nonbonded pdb=" CA  THR A  15 "
          pdb=" OD1 ASN A  29 "
   model   vdw
   4.182 3.470
nonbonded pdb=" CG1 VAL A  63 "
          pdb=" O   ARG A  82 "
   model   vdw
   4.183 3.460
nonbonded pdb=" CB  LEU A  81 "
          pdb="O    HOH S   6 "
   model   vdw sym.op.
   4.183 3.440 -x+1,y,-z+2
nonbonded pdb=" CG2 ILE A   2 "
          pdb=" C   LYS A   3 "
   model   vdw
   4.183 3.690
nonbonded pdb=" CB  TYR A  61 "
          pdb=" CA  THR A  62 "
   model   vdw
   4.184 3.870
nonbonded pdb=" C   GLY A  38 "
          pdb="O    HOH S   9 "
   model   vdw
   4.184 3.270
nonbonded pdb=" CB  PRO A   8 "
          pdb=" CA  THR A  14 "
   model   vdw sym.op.
   4.184 3.870 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CG2 ILE A   2 "
          pdb=" CA  LYS A   3 "
   model   vdw
   4.184 3.890
nonbonded pdb=" O   PHE A  73 "
          pdb=" CG  PHE A  73 "
   model   vdw
   4.185 3.260
nonbonded pdb=" CD2 LEU A  37 "
          pdb=" CB  PHE A  68 "
   model   vdw sym.op.
   4.185 3.860 -x+1,y,-z+2
nonbonded pdb=" N   TYR A  34 "
          pdb=" CD2 TYR A  34 "
   model   vdw
   4.185 3.420
nonbonded pdb=" O   PRO A   8 "
          pdb=" OG1 THR A  15 "
   model   vdw sym.op.
   4.185 3.040 -x+1/2,y+1/2,-z+1
nonbonded pdb=" N   LYS A   7 "
          pdb="O    HOH S  12 "
   model   vdw
   4.186 3.120
nonbonded pdb=" CD2 LEU A  81 "
          pdb="O    HOH S   6 "
   model   vdw sym.op.
   4.186 3.460 -x+1,y,-z+2
nonbonded pdb=" O   ARG A  82 "
          pdb=" N   VAL A  84 "
   model   vdw
   4.187 3.120
nonbonded pdb=" O   THR A  62 "
          pdb=" C   VAL A  84 "
   model   vdw
   4.187 3.270
nonbonded pdb=" O   THR A  62 "
          pdb=" CG2 VAL A  63 "
   model   vdw
   4.188 3.460
nonbonded pdb=" CZ  ARG A  16 "
          pdb=" CA  PRO A  85 "
   model   vdw sym.op.
   4.188 3.700 x,y-1,z
nonbonded pdb=" O   TYR A  61 "
          pdb=" CZ  PHE A  73 "
   model   vdw sym.op.
   4.188 3.340 -x+1,y+1,-z+2
nonbonded pdb=" N   LEU A  37 "
          pdb=" CA  GLY A  38 "
   model   vdw
   4.189 3.520
nonbonded pdb=" CG2 VAL A  45 "
          pdb=" O   GLY A  74 "
   model   vdw sym.op.
   4.190 3.460 -x+1,y,-z+2
nonbonded pdb=" C   LYS A   7 "
          pdb=" CB  PRO A  58 "
   model   vdw
   4.190 3.670
nonbonded pdb=" CB  VAL A   4 "
          pdb=" O   TYR A  34 "
   model   vdw
   4.190 3.470
nonbonded pdb=" CA  VAL A  84 "
          pdb=" O   PRO A  85 "
   model   vdw
   4.190 3.470
nonbonded pdb=" CA  GLY A  71 "
          pdb=" CE  MSE A  77 "
   model   vdw
   4.191 3.860
nonbonded pdb=" CA  SER A  66 "
          pdb=" N   PHE A  68 "
   model   vdw
   4.192 3.550
nonbonded pdb=" NH2 ARG A  16 "
          pdb=" CD1 TYR A  61 "
   model   vdw sym.op.
   4.192 3.420 x,y-1,z
nonbonded pdb=" C   ASN A  39 "
          pdb=" O   TYR A  41 "
   model   vdw
   4.192 3.270
nonbonded pdb=" CG1 VAL A  35 "
          pdb=" CG  LEU A  37 "
   model   vdw
   4.193 3.890
nonbonded pdb=" CD1 LEU A  32 "
          pdb="O    HOH S   8 "
   model   vdw
   4.193 3.460
nonbonded pdb=" C   SER A  17 "
          pdb="O    HOH S   7 "
   model   vdw sym.op.
   4.193 3.270 x,y-1,z
nonbonded pdb=" CG2 ILE A   2 "
          pdb=" CB  VAL A  63 "
   model   vdw
   4.193 3.890
nonbonded pdb=" O   GLN A  53 "
          pdb=" CB  PRO A  54 "
   model   vdw
   4.194 3.440
nonbonded pdb=" C   CYS A  33 "
          pdb=" N   VAL A  35 "
   model   vdw
   4.194 3.350
nonbonded pdb=" C   SER A  27 "
          pdb=" CD2 LEU A  28 "
   model   vdw
   4.195 3.690
nonbonded pdb=" SG  CYS A  33 "
          pdb=" C   VAL A  45 "
   model   vdw
   4.195 3.630
nonbonded pdb=" O   THR A  62 "
          pdb=" O   VAL A  63 "
   model   vdw
   4.195 3.040
nonbonded pdb=" CG  ASN A  39 "
          pdb=" N   GLU A  40 "
   model   vdw
   4.195 3.350
nonbonded pdb=" OE1 GLU A   5 "
          pdb=" OH  TYR A  41 "
   model   vdw sym.op.
   4.196 3.040 -x+1,y,-z+1
nonbonded pdb=" CA  GLN A  72 "
          pdb=" NE2 GLN A  72 "
   model   vdw
   4.196 3.550
nonbonded pdb=" C   HIS A  64 "
          pdb=" CE1 PHE A  68 "
   model   vdw
   4.196 3.570
nonbonded pdb=" C   MSE A  77 "
          pdb=" CE  MSE A  77 "
   model   vdw
   4.196 3.690
nonbonded pdb=" O   GLN A  12 "
          pdb=" CA  GLN A  31 "
   model   vdw
   4.196 3.470
nonbonded pdb=" CG1 VAL A  45 "
          pdb=" O   GLY A  74 "
   model   vdw sym.op.
   4.196 3.460 -x+1,y,-z+2
nonbonded pdb=" CE1 PHE A  13 "
          pdb=" CB  ASN A  29 "
   model   vdw
   4.198 3.740
nonbonded pdb=" OD1 ASP A  36 "
          pdb=" C   LEU A  37 "
   model   vdw
   4.199 3.270
nonbonded pdb=" O   LYS A   7 "
          pdb=" CB  PRO A   8 "
   model   vdw
   4.199 3.440
nonbonded pdb=" CB  ILE A   6 "
          pdb=" CE1 TYR A  61 "
   model   vdw
   4.200 3.770
nonbonded pdb=" C   THR A  62 "
          pdb=" N   VAL A  84 "
   model   vdw
   4.200 3.350
nonbonded pdb=" CG  TYR A  61 "
          pdb=" CB  LEU A  83 "
   model   vdw
   4.200 3.660
nonbonded pdb=" C   LEU A  65 "
          pdb=" CA  SER A  67 "
   model   vdw
   4.201 3.700
nonbonded pdb=" N   ILE A   6 "
          pdb=" N   GLY A  59 "
   model   vdw
   4.201 3.200
nonbonded pdb=" CA  GLU A   5 "
          pdb=" OE1 GLU A   5 "
   model   vdw
   4.201 3.470
nonbonded pdb=" CB  ASN A  39 "
          pdb=" N   TYR A  41 "
   model   vdw
   4.201 3.520
nonbonded pdb=" CG  ARG A  16 "
          pdb=" O   LEU A  28 "
   model   vdw
   4.201 3.440
nonbonded pdb=" CG  LYS A  46 "
          pdb=" O   ILE A  47 "
   model   vdw
   4.201 3.440
nonbonded pdb=" C   GLY A  59 "
          pdb=" N   TYR A  61 "
   model   vdw
   4.203 3.350
nonbonded pdb=" O   HIS A  64 "
          pdb=" ND1 HIS A  64 "
   model   vdw
   4.203 3.120
nonbonded pdb=" CG  PRO A   8 "
          pdb=" N   SER A   9 "
   model   vdw
   4.203 3.520
nonbonded pdb=" C   PRO A   8 "
          pdb=" CA  THR A  14 "
   model   vdw sym.op.
   4.203 3.700 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CG  ASP A  50 "
          pdb=" N   GLU A  51 "
   model   vdw
   4.203 3.350
nonbonded pdb=" CG  GLU A  30 "
          pdb=" O   ILE A  47 "
   model   vdw
   4.204 3.440
nonbonded pdb=" O   LYS A   7 "
          pdb=" CG  GLN A  10 "
   model   vdw
   4.204 3.440
nonbonded pdb=" CD1 LEU A  37 "
          pdb=" CG2 VAL A  70 "
   model   vdw sym.op.
   4.204 3.880 -x+1,y,-z+2
nonbonded pdb=" O   LYS A   3 "
          pdb=" CB  VAL A  35 "
   model   vdw
   4.205 3.470
nonbonded pdb=" C   SER A  67 "
          pdb=" CD2 PHE A  68 "
   model   vdw
   4.205 3.570
nonbonded pdb=" OE1 GLN A  12 "
          pdb=" O   THR A  15 "
   model   vdw sym.op.
   4.205 3.040 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CA  GLN A  53 "
          pdb=" O   PRO A  54 "
   model   vdw
   4.206 3.470
nonbonded pdb=" CE  LYS A   7 "
          pdb=" CB  GLU A  40 "
   model   vdw sym.op.
   4.207 3.840 -x+1,y,-z+1
nonbonded pdb=" C   LEU A  49 "
          pdb=" OD1 ASP A  50 "
   model   vdw
   4.207 3.270
nonbonded pdb=" O   SER A  66 "
          pdb=" CB  SER A  67 "
   model   vdw
   4.207 3.440
nonbonded pdb=" N   SER A   9 "
          pdb=" OG1 THR A  15 "
   model   vdw sym.op.
   4.208 3.120 -x+1/2,y+1/2,-z+1
nonbonded pdb=" O   GLU A  40 "
          pdb=" CE1 TYR A  41 "
   model   vdw
   4.208 3.340
nonbonded pdb=" N   SER A   9 "
          pdb=" CA  GLN A  10 "
   model   vdw
   4.208 3.550
nonbonded pdb=" O   TYR A  41 "
          pdb=" CB  PRO A  42 "
   model   vdw
   4.209 3.440
nonbonded pdb=" O   ILE A   2 "
          pdb=" N   VAL A  63 "
   model   vdw
   4.209 3.120
nonbonded pdb=" O   HIS A  64 "
          pdb=" CA  SER A  66 "
   model   vdw
   4.210 3.470
nonbonded pdb=" O   GLN A  12 "
          pdb=" O   GLU A  30 "
   model   vdw
   4.210 3.040
nonbonded pdb=" CB  ASP A  79 "
          pdb=" CA  ARG A  80 "
   model   vdw
   4.210 3.870
nonbonded pdb=" O   GLY A  52 "
          pdb=" O   GLN A  53 "
   model   vdw
   4.211 3.040
nonbonded pdb=" C   GLY A  74 "
          pdb=" OG  SER A  75 "
   model   vdw
   4.211 3.270
nonbonded pdb=" OG  SER A  67 "
          pdb=" CG1 ILE A  78 "
   model   vdw
   4.211 3.440
nonbonded pdb=" N   LYS A  69 "
          pdb=" C   MSE A  77 "
   model   vdw
   4.212 3.350
nonbonded pdb=" CA  TYR A  34 "
          pdb=" C   VAL A  43 "
   model   vdw
   4.213 3.700
nonbonded pdb=" O   CYS A  33 "
          pdb=" CB  VAL A  45 "
   model   vdw
   4.213 3.470
nonbonded pdb=" CB  MSE A  77 "
          pdb=" O   ILE A  78 "
   model   vdw
   4.214 3.440
nonbonded pdb=" N   ILE A  78 "
          pdb=" CD1 ILE A  78 "
   model   vdw
   4.215 3.540
nonbonded pdb=" N   GLN A  10 "
          pdb=" NE2 GLN A  12 "
   model   vdw
   4.215 3.200
nonbonded pdb=" CB  PHE A  68 "
          pdb=" CD1 LEU A  76 "
   model   vdw
   4.215 3.860
nonbonded pdb=" OD2 ASP A  36 "
          pdb="O    HOH S   5 "
   model   vdw
   4.216 3.040
nonbonded pdb=" CG2 THR A  15 "
          pdb=" CB  SER A  27 "
   model   vdw
   4.216 3.860
nonbonded pdb=" CB  VAL A  43 "
          pdb=" CG2 VAL A  70 "
   model   vdw sym.op.
   4.216 3.890 -x+1,y,-z+2
nonbonded pdb=" N   LYS A   7 "
          pdb=" CD  PRO A   8 "
   model   vdw
   4.216 3.520
nonbonded pdb=" O   ARG A  16 "
          pdb=" CE1 TYR A  26 "
   model   vdw
   4.217 3.340
nonbonded pdb=" CD2 LEU A  37 "
          pdb=" O   LEU A  65 "
   model   vdw sym.op.
   4.217 3.460 -x+1,y,-z+2
nonbonded pdb=" C   ASP A  50 "
          pdb=" OD1 ASP A  50 "
   model   vdw
   4.217 3.270
nonbonded pdb=" CG2 THR A  15 "
          pdb=" CA  ARG A  16 "
   model   vdw
   4.217 3.890
nonbonded pdb=" CD1 LEU A  65 "
          pdb=" CD1 PHE A  68 "
   model   vdw
   4.217 3.760
nonbonded pdb=" CB  LYS A  46 "
          pdb=" C   GLY A  74 "
   model   vdw sym.op.
   4.218 3.670 -x+1,y,-z+2
nonbonded pdb=" N   ASP A  36 "
          pdb="O    HOH S   5 "
   model   vdw
   4.218 3.120
nonbonded pdb=" O   LEU A  44 "
          pdb=" CG1 VAL A  70 "
   model   vdw sym.op.
   4.218 3.460 -x+1,y,-z+2
nonbonded pdb=" CD2 TYR A  34 "
          pdb=" CD2 TYR A  41 "
   model   vdw sym.op.
   4.218 3.640 -x+1,y,-z+1
nonbonded pdb=" CD2 TYR A  41 "
          pdb=" CD2 TYR A  34 "
   model   vdw sym.op.
   4.218 3.640 -x+1,y,-z+1
nonbonded pdb=" C   LEU A  32 "
          pdb=" SG  CYS A  33 "
   model   vdw
   4.218 3.630
nonbonded pdb=" CD  LYS A  69 "
          pdb="O    HOH S   1 "
   model   vdw sym.op.
   4.219 3.440 -x,y+1,-z+1
nonbonded pdb=" C   ASP A  50 "
          pdb=" N   GLN A  53 "
   model   vdw
   4.219 3.350
nonbonded pdb=" CG1 VAL A  63 "
          pdb=" C   HIS A  64 "
   model   vdw
   4.221 3.690
nonbonded pdb=" C   LEU A  49 "
          pdb=" N   GLU A  51 "
   model   vdw
   4.223 3.350
nonbonded pdb=" C   LEU A  37 "
          pdb=" OD1 ASN A  39 "
   model   vdw
   4.223 3.270
nonbonded pdb=" C   THR A  14 "
          pdb=" N   ARG A  16 "
   model   vdw
   4.223 3.350
nonbonded pdb=" N   VAL A  84 "
          pdb=" CD  PRO A  85 "
   model   vdw
   4.224 3.520
nonbonded pdb=" OG  SER A   9 "
          pdb=" CA  GLN A  10 "
   model   vdw
   4.224 3.470
nonbonded pdb=" CD1 TYR A  56 "
          pdb=" CD1 LEU A  83 "
   model   vdw
   4.224 3.760
nonbonded pdb=" CG  GLN A  10 "
          pdb=" C   LEU A  32 "
   model   vdw
   4.224 3.670
nonbonded pdb=" N   ALA A  57 "
          pdb=" CD  PRO A  58 "
   model   vdw
   4.224 3.520
nonbonded pdb=" C   HIS A  64 "
          pdb=" CB  SER A  67 "
   model   vdw
   4.224 3.670
nonbonded pdb=" CD  LYS A  69 "
          pdb=" OD1 ASP A  79 "
   model   vdw
   4.224 3.440
nonbonded pdb=" C   GLY A  52 "
          pdb=" CD  PRO A  54 "
   model   vdw
   4.225 3.670
nonbonded pdb=" CA  SER A  67 "
          pdb=" C   ARG A  80 "
   model   vdw
   4.225 3.700
nonbonded pdb=" N   GLU A   5 "
          pdb=" C   TYR A  34 "
   model   vdw
   4.226 3.350
nonbonded pdb=" C   ILE A   6 "
          pdb=" N   PRO A   8 "
   model   vdw
   4.226 3.350
nonbonded pdb=" CB  CYS A  33 "
          pdb=" CA  TYR A  34 "
   model   vdw
   4.227 3.870
nonbonded pdb=" CB  LYS A   7 "
          pdb=" CD  GLU A  40 "
   model   vdw sym.op.
   4.227 3.670 -x+1,y,-z+1
nonbonded pdb=" CA  ARG A  16 "
          pdb=" O   LEU A  28 "
   model   vdw
   4.228 3.470
nonbonded pdb=" O   GLY A  71 "
          pdb=" CA  GLY A  74 "
   model   vdw
   4.228 3.440
nonbonded pdb=" CZ  TYR A  26 "
          pdb=" CD  PRO A  85 "
   model   vdw sym.op.
   4.228 3.660 x,y-1,z
nonbonded pdb=" CB  ALA A  55 "
          pdb=" O   TYR A  56 "
   model   vdw
   4.228 3.460
nonbonded pdb=" O   VAL A  70 "
          pdb=" N   GLN A  72 "
   model   vdw
   4.228 3.120
nonbonded pdb=" CD2 PHE A  13 "
          pdb=" N   ALA A  55 "
   model   vdw
   4.229 3.420
nonbonded pdb=" O   LEU A  65 "
          pdb=" CE1 PHE A  68 "
   model   vdw
   4.229 3.340
nonbonded pdb=" C   ILE A   6 "
          pdb=" O   GLY A  59 "
   model   vdw
   4.229 3.270
nonbonded pdb=" CA  SER A  67 "
          pdb=" CD1 PHE A  68 "
   model   vdw
   4.229 3.770
nonbonded pdb=" O   SER A  75 "
          pdb=" CB  LEU A  76 "
   model   vdw
   4.230 3.440
nonbonded pdb=" C   LEU A  37 "
          pdb=" CD2 LEU A  37 "
   model   vdw
   4.232 3.690
nonbonded pdb=" O   HIS A  64 "
          pdb=" CB  LEU A  65 "
   model   vdw
   4.232 3.440
nonbonded pdb=" C   ALA A  11 "
          pdb=" NE2 GLN A  12 "
   model   vdw
   4.232 3.350
nonbonded pdb=" CD  ARG A  16 "
          pdb=" OE1 GLU A  30 "
   model   vdw
   4.233 3.440
nonbonded pdb="O    HOH S   6 "
          pdb="O    HOH S  38 "
   model   vdw sym.op.
   4.233 3.040 -x+1,y,-z+2
nonbonded pdb=" N   GLY A  59 "
          pdb=" CE1 TYR A  61 "
   model   vdw
   4.234 3.420
nonbonded pdb=" C   VAL A  63 "
          pdb=" N   LEU A  65 "
   model   vdw
   4.234 3.350
nonbonded pdb=" OD1 ASP A  36 "
          pdb=" CA  LEU A  37 "
   model   vdw
   4.234 3.470
nonbonded pdb=" CB  LEU A  49 "
          pdb=" CD  GLN A  53 "
   model   vdw
   4.234 3.670
nonbonded pdb=" O   LEU A  32 "
          pdb=" C   CYS A  33 "
   model   vdw
   4.234 3.270
nonbonded pdb=" CE  LYS A   3 "
          pdb=" C   GLN A  72 "
   model   vdw sym.op.
   4.235 3.670 -x+1,y+1,-z+2
nonbonded pdb=" C   ASN A  39 "
          pdb=" OE1 GLU A  40 "
   model   vdw
   4.235 3.270
nonbonded pdb=" N   VAL A  43 "
          pdb="O    HOH S   9 "
   model   vdw
   4.236 3.120
nonbonded pdb=" CD  GLN A  53 "
          pdb=" CZ  TYR A  56 "
   model   vdw
   4.236 3.490
nonbonded pdb=" CD  GLN A  10 "
          pdb=" C   CYS A  33 "
   model   vdw
   4.237 3.500
nonbonded pdb=" CA  LYS A   3 "
          pdb=" CZ  PHE A  73 "
   model   vdw sym.op.
   4.237 3.770 -x+1,y+1,-z+2
nonbonded pdb=" N   ASP A  79 "
          pdb=" OD1 ASP A  79 "
   model   vdw
   4.237 3.120
nonbonded pdb=" CD1 TYR A  26 "
          pdb=" C   SER A  27 "
   model   vdw
   4.237 3.570
nonbonded pdb=" CA  PHE A  13 "
          pdb=" C   GLU A  30 "
   model   vdw
   4.237 3.700
nonbonded pdb=" CB  TYR A  61 "
          pdb=" CD1 LEU A  83 "
   model   vdw
   4.238 3.860
nonbonded pdb=" CB  THR A  48 "
          pdb=" CD  ARG A  80 "
   model   vdw
   4.239 3.870
nonbonded pdb=" CB  TYR A  34 "
          pdb=" OH  TYR A  41 "
   model   vdw sym.op.
   4.239 3.440 -x+1,y,-z+1
nonbonded pdb=" CG  LEU A  37 "
          pdb=" CG2 VAL A  43 "
   model   vdw
   4.240 3.890
nonbonded pdb=" CB  TYR A  56 "
          pdb=" O   ALA A  57 "
   model   vdw
   4.240 3.440
nonbonded pdb=" O   ALA A  55 "
          pdb=" CB  TYR A  56 "
   model   vdw
   4.241 3.440
nonbonded pdb=" O   ARG A  80 "
          pdb=" CB  LEU A  81 "
   model   vdw
   4.242 3.440
nonbonded pdb=" CG2 THR A  62 "
          pdb=" O   VAL A  63 "
   model   vdw
   4.242 3.460
nonbonded pdb=" O   LYS A  69 "
          pdb=" CG2 VAL A  70 "
   model   vdw
   4.243 3.460
nonbonded pdb=" O   ALA A  55 "
          pdb="O    HOH S   7 "
   model   vdw
   4.243 3.040
nonbonded pdb=" N   SER A  67 "
          pdb=" CD1 PHE A  68 "
   model   vdw
   4.244 3.420
nonbonded pdb=" N   SER A  67 "
          pdb=" NH1 ARG A  82 "
   model   vdw
   4.244 3.200
nonbonded pdb=" C   SER A   9 "
          pdb=" OE1 GLN A  12 "
   model   vdw
   4.244 3.270
nonbonded pdb=" CG  TYR A  34 "
          pdb=" OH  TYR A  41 "
   model   vdw sym.op.
   4.244 3.260 -x+1,y,-z+1
nonbonded pdb=" OH  TYR A  41 "
          pdb=" CG  TYR A  34 "
   model   vdw sym.op.
   4.244 3.260 -x+1,y,-z+1
nonbonded pdb=" N   ASP A  79 "
          pdb=" CA  ARG A  80 "
   model   vdw
   4.244 3.550
nonbonded pdb=" CB  PHE A  13 "
          pdb=" CZ  PHE A  13 "
   model   vdw
   4.245 3.740
nonbonded pdb=" CB  PRO A   8 "
          pdb=" N   THR A  15 "
   model   vdw sym.op.
   4.245 3.520 -x+1/2,y+1/2,-z+1
nonbonded pdb=" N   SER A  67 "
          pdb=" O   ARG A  80 "
   model   vdw
   4.245 3.120
nonbonded pdb=" CG  ASP A  50 "
          pdb=" CD  ARG A  80 "
   model   vdw
   4.246 3.670
nonbonded pdb=" CG  GLN A  10 "
          pdb=" CB  LEU A  32 "
   model   vdw
   4.246 3.840
nonbonded pdb=" CG  ASP A  50 "
          pdb=" OE1 GLN A  53 "
   model   vdw
   4.246 3.270
nonbonded pdb=" C   GLN A  31 "
          pdb=" CD2 LEU A  32 "
   model   vdw
   4.246 3.690
nonbonded pdb=" CB  PHE A  68 "
          pdb=" CZ  PHE A  68 "
   model   vdw
   4.246 3.740
nonbonded pdb=" O   TYR A  56 "
          pdb=" CD  PRO A  58 "
   model   vdw
   4.246 3.440
nonbonded pdb=" CA  GLN A  53 "
          pdb=" CG  PRO A  54 "
   model   vdw
   4.247 3.870
nonbonded pdb=" CD2 TYR A  41 "
          pdb=" CE1 TYR A  34 "
   model   vdw sym.op.
   4.248 3.640 -x+1,y,-z+1
nonbonded pdb=" CE1 TYR A  34 "
          pdb=" CD2 TYR A  41 "
   model   vdw sym.op.
   4.248 3.640 -x+1,y,-z+1
nonbonded pdb=" CB  THR A  48 "
          pdb=" CG  ARG A  80 "
   model   vdw
   4.248 3.870
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" N   PRO A  58 "
   model   vdw
   4.248 3.540
nonbonded pdb=" N   GLN A  10 "
          pdb=" CD  GLN A  10 "
   model   vdw
   4.249 3.350
nonbonded pdb=" CG1 ILE A   6 "
          pdb=" O   ALA A  57 "
   model   vdw
   4.249 3.440
nonbonded pdb=" CB  VAL A  43 "
          pdb="O    HOH S  25 "
   model   vdw
   4.251 3.470
nonbonded pdb=" CB  ILE A   6 "
          pdb=" O   GLY A  59 "
   model   vdw
   4.251 3.470
nonbonded pdb=" CB  TYR A  61 "
          pdb=" CZ  TYR A  61 "
   model   vdw
   4.252 3.660
nonbonded pdb=" N   CYS A  33 "
          pdb=" C   VAL A  45 "
   model   vdw
   4.253 3.350
nonbonded pdb=" CD2 LEU A  60 "
          pdb=" N   TYR A  61 "
   model   vdw
   4.253 3.540
nonbonded pdb=" CD  GLN A  10 "
          pdb=" CB  LEU A  32 "
   model   vdw
   4.253 3.670
nonbonded pdb=" N   LYS A   7 "
          pdb=" CG  GLN A  10 "
   model   vdw
   4.253 3.520
nonbonded pdb=" C   PRO A   8 "
          pdb=" CA  THR A  15 "
   model   vdw sym.op.
   4.253 3.700 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CA  GLU A  30 "
          pdb=" OE1 GLU A  30 "
   model   vdw
   4.254 3.470
nonbonded pdb=" CB  ILE A   2 "
          pdb=" CG2 VAL A  63 "
   model   vdw
   4.254 3.890
nonbonded pdb=" O   SER A  66 "
          pdb=" NE  ARG A  82 "
   model   vdw
   4.255 3.120
nonbonded pdb=" CA  VAL A  70 "
          pdb=" O   GLY A  71 "
   model   vdw
   4.256 3.470
nonbonded pdb=" CE1 TYR A  56 "
          pdb=" CD1 LEU A  83 "
   model   vdw
   4.256 3.760
nonbonded pdb=" CB  LYS A   7 "
          pdb=" CG  GLN A  10 "
   model   vdw
   4.256 3.840
nonbonded pdb=" C   PRO A   8 "
          pdb=" C   THR A  14 "
   model   vdw sym.op.
   4.257 3.500 -x+1/2,y+1/2,-z+1
nonbonded pdb=" OG  SER A  67 "
          pdb=" C   ARG A  80 "
   model   vdw
   4.257 3.270
nonbonded pdb=" C   ASP A  50 "
          pdb=" CB  GLN A  53 "
   model   vdw
   4.258 3.670
nonbonded pdb=" C   LYS A  69 "
          pdb=" N   MSE A  77 "
   model   vdw
   4.258 3.350
nonbonded pdb=" CE2 PHE A  73 "
          pdb="O    HOH S  30 "
   model   vdw sym.op.
   4.258 3.340 -x+1,y-1,-z+2
nonbonded pdb=" N   ILE A  47 "
          pdb="O    HOH S  38 "
   model   vdw
   4.259 3.120
nonbonded pdb=" C   ASN A  39 "
          pdb="O    HOH S   9 "
   model   vdw
   4.260 3.270
nonbonded pdb=" O   LEU A  32 "
          pdb="O    HOH S   8 "
   model   vdw
   4.260 3.040
nonbonded pdb=" CE2 TYR A  34 "
          pdb=" O   PRO A  42 "
   model   vdw
   4.260 3.340
nonbonded pdb=" O   LEU A  65 "
          pdb=" CB  SER A  66 "
   model   vdw
   4.261 3.440
nonbonded pdb=" CG  LEU A  28 "
          pdb=" N   ASN A  29 "
   model   vdw
   4.261 3.550
nonbonded pdb=" O   THR A  14 "
          pdb=" N   ARG A  16 "
   model   vdw
   4.262 3.120
nonbonded pdb=" O   ARG A  82 "
          pdb=" CG  LEU A  83 "
   model   vdw
   4.262 3.470
nonbonded pdb=" CG  ARG A  80 "
          pdb=" NH1 ARG A  80 "
   model   vdw
   4.262 3.520
nonbonded pdb=" NE2 GLN A  53 "
          pdb=" CE2 TYR A  56 "
   model   vdw
   4.262 3.420
nonbonded pdb=" CD1 ILE A  47 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   4.262 3.880
nonbonded pdb=" O   VAL A  43 "
          pdb=" CB  LEU A  44 "
   model   vdw
   4.262 3.440
nonbonded pdb=" C   PRO A   8 "
          pdb=" OG  SER A   9 "
   model   vdw
   4.263 3.270
nonbonded pdb=" C   LYS A  46 "
          pdb=" N   THR A  48 "
   model   vdw
   4.263 3.350
nonbonded pdb=" CG2 VAL A   4 "
          pdb=" CG1 VAL A  35 "
   model   vdw
   4.263 3.880
nonbonded pdb=" CB  TYR A  56 "
          pdb=" CZ  TYR A  56 "
   model   vdw
   4.263 3.660
nonbonded pdb=" CD1 ILE A   2 "
          pdb=" O   ASP A  36 "
   model   vdw
   4.263 3.460
nonbonded pdb=" C   PRO A  42 "
          pdb=" N   LEU A  44 "
   model   vdw
   4.264 3.350
nonbonded pdb=" CA  THR A  48 "
          pdb=" O   LEU A  49 "
   model   vdw
   4.265 3.470
nonbonded pdb=" O   PHE A  13 "
          pdb=" CD2 PHE A  13 "
   model   vdw
   4.265 3.340
nonbonded pdb=" N   TYR A  41 "
          pdb=" CD  PRO A  42 "
   model   vdw
   4.265 3.520
nonbonded pdb=" O   SER A  27 "
          pdb=" CD2 LEU A  28 "
   model   vdw
   4.266 3.460
nonbonded pdb=" CA  GLY A  59 "
          pdb=" CE1 TYR A  61 "
   model   vdw
   4.266 3.740
nonbonded pdb=" O   VAL A  43 "
          pdb=" CG2 VAL A  45 "
   model   vdw
   4.266 3.460
nonbonded pdb=" C   LEU A  60 "
          pdb=" CD2 TYR A  61 "
   model   vdw
   4.266 3.570
nonbonded pdb=" C   ALA A  11 "
          pdb=" CD  GLN A  12 "
   model   vdw
   4.267 3.500
nonbonded pdb=" N   LEU A  65 "
          pdb=" CA  SER A  66 "
   model   vdw
   4.268 3.550
nonbonded pdb=" N   GLY A  38 "
          pdb=" CA  ASN A  39 "
   model   vdw
   4.268 3.550
nonbonded pdb=" O   THR A  48 "
          pdb=" CB  LEU A  49 "
   model   vdw
   4.268 3.440
nonbonded pdb=" O   GLN A  10 "
          pdb=" CG  GLN A  10 "
   model   vdw
   4.268 3.440
nonbonded pdb=" CB  GLN A  53 "
          pdb=" O   PRO A  54 "
   model   vdw
   4.268 3.440
nonbonded pdb=" CA  GLY A  71 "
          pdb=" N   PHE A  73 "
   model   vdw
   4.269 3.520
nonbonded pdb=" CG  GLU A  40 "
          pdb=" OG  SER A   9 "
   model   vdw sym.op.
   4.269 3.440 -x+1,y,-z+1
nonbonded pdb=" OG  SER A   9 "
          pdb=" CG  GLU A  40 "
   model   vdw sym.op.
   4.269 3.440 -x+1,y,-z+1
nonbonded pdb=" N   PRO A   8 "
          pdb=" CG  PRO A  58 "
   model   vdw
   4.269 3.520
nonbonded pdb=" NH1 ARG A  16 "
          pdb=" CA  LEU A  60 "
   model   vdw sym.op.
   4.269 3.550 x,y-1,z
nonbonded pdb=" CA  SER A  67 "
          pdb=" CD  ARG A  82 "
   model   vdw
   4.269 3.870
nonbonded pdb=" CA  GLY A  59 "
          pdb="O    HOH S  12 "
   model   vdw
   4.271 3.440
nonbonded pdb=" CG1 VAL A  63 "
          pdb=" CA  HIS A  64 "
   model   vdw
   4.271 3.890
nonbonded pdb=" N   LEU A  60 "
          pdb=" CE1 TYR A  61 "
   model   vdw
   4.271 3.420
nonbonded pdb=" O   CYS A  33 "
          pdb=" CD2 TYR A  34 "
   model   vdw
   4.272 3.340
nonbonded pdb=" O   ASN A  39 "
          pdb=" CB  GLU A  40 "
   model   vdw
   4.272 3.440
nonbonded pdb=" SG  CYS A  33 "
          pdb=" CG1 ILE A  47 "
   model   vdw
   4.272 3.800
nonbonded pdb=" O   ASN A  39 "
          pdb=" CA  TYR A  41 "
   model   vdw
   4.272 3.470
nonbonded pdb=" CB  LEU A  37 "
          pdb=" OD1 ASN A  39 "
   model   vdw
   4.273 3.440
nonbonded pdb=" CB  SER A   9 "
          pdb=" CD  GLU A  40 "
   model   vdw sym.op.
   4.273 3.670 -x+1,y,-z+1
nonbonded pdb=" CD  GLU A  40 "
          pdb=" CB  SER A   9 "
   model   vdw sym.op.
   4.273 3.670 -x+1,y,-z+1
nonbonded pdb=" CG2 THR A  14 "
          pdb=" CG  PRO A  58 "
   model   vdw sym.op.
   4.274 3.860 -x+1/2,y-1/2,-z+1
nonbonded pdb=" O   LEU A  76 "
          pdb="O    HOH S   6 "
   model   vdw
   4.274 3.040
nonbonded pdb=" CE1 TYR A  56 "
          pdb=" C   LEU A  83 "
   model   vdw
   4.274 3.570
nonbonded pdb=" O   VAL A  84 "
          pdb=" CB  PRO A  85 "
   model   vdw
   4.274 3.440
nonbonded pdb=" O   LYS A  46 "
          pdb=" N   THR A  48 "
   model   vdw
   4.275 3.120
nonbonded pdb=" N   SER A   9 "
          pdb="O    HOH S  14 "
   model   vdw sym.op.
   4.275 3.120 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CG  GLN A  12 "
          pdb=" O   PHE A  13 "
   model   vdw
   4.276 3.440
nonbonded pdb=" O   VAL A   4 "
          pdb=" CD1 TYR A  61 "
   model   vdw
   4.276 3.340
nonbonded pdb=" CE  LYS A  69 "
          pdb=" CE  MSE A  77 "
   model   vdw
   4.276 3.860
nonbonded pdb=" CA  TYR A  41 "
          pdb=" O   PRO A  42 "
   model   vdw
   4.276 3.470
nonbonded pdb=" C   PRO A  42 "
          pdb="O    HOH S   9 "
   model   vdw
   4.276 3.270
nonbonded pdb=" CA  ASP A  50 "
          pdb=" OE2 GLU A  51 "
   model   vdw
   4.277 3.470
nonbonded pdb=" O   SER A  67 "
          pdb=" C   ARG A  80 "
   model   vdw
   4.277 3.270
nonbonded pdb=" O   ALA A  57 "
          pdb=" CA  GLY A  59 "
   model   vdw
   4.277 3.440
nonbonded pdb=" CG  GLN A  53 "
          pdb=" CD  PRO A  54 "
   model   vdw
   4.277 3.840
nonbonded pdb=" CD2 LEU A  32 "
          pdb=" C   VAL A  45 "
   model   vdw
   4.277 3.690
nonbonded pdb=" C   LEU A  81 "
          pdb=" CD1 LEU A  81 "
   model   vdw
   4.278 3.690
nonbonded pdb=" CG  LEU A  65 "
          pdb=" N   SER A  66 "
   model   vdw
   4.279 3.550
nonbonded pdb=" CB  PHE A  13 "
          pdb=" N   GLU A  30 "
   model   vdw
   4.279 3.520
nonbonded pdb=" CG  PRO A   8 "
          pdb=" CZ  PHE A  13 "
   model   vdw sym.op.
   4.279 3.740 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CD2 LEU A  49 "
          pdb=" O   PRO A  54 "
   model   vdw
   4.279 3.460
nonbonded pdb=" CA  SER A  17 "
          pdb=" CA  SER A  27 "
   model   vdw
   4.280 3.900
nonbonded pdb=" O   THR A  62 "
          pdb=" OG1 THR A  62 "
   model   vdw
   4.280 3.040
nonbonded pdb=" C   VAL A   4 "
          pdb=" CD2 LEU A  60 "
   model   vdw
   4.280 3.690
nonbonded pdb=" O   GLN A  31 "
          pdb=" CB  LYS A  46 "
   model   vdw
   4.280 3.440
nonbonded pdb=" CG  GLU A   5 "
          pdb=" C   GLY A  59 "
   model   vdw
   4.281 3.670
nonbonded pdb=" CB  VAL A  35 "
          pdb=" CG2 VAL A  45 "
   model   vdw
   4.281 3.890
nonbonded pdb=" C   GLN A  12 "
          pdb=" CG  PHE A  13 "
   model   vdw
   4.281 3.490
nonbonded pdb=" CG  LEU A  81 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   4.281 3.890
nonbonded pdb=" CD1 TYR A  61 "
          pdb=" CD1 LEU A  83 "
   model   vdw
   4.282 3.760
nonbonded pdb=" CA  TYR A  56 "
          pdb=" O   ALA A  57 "
   model   vdw
   4.283 3.470
nonbonded pdb=" O   SER A  67 "
          pdb=" N   LYS A  69 "
   model   vdw
   4.283 3.120
nonbonded pdb=" O   LEU A  49 "
          pdb=" OE2 GLU A  51 "
   model   vdw
   4.284 3.040
nonbonded pdb=" O   LEU A  49 "
          pdb=" OD1 ASP A  50 "
   model   vdw
   4.284 3.040
nonbonded pdb=" C   THR A  48 "
          pdb=" CD  ARG A  80 "
   model   vdw
   4.284 3.670
nonbonded pdb=" CG1 VAL A  70 "
          pdb=" O   SER A  75 "
   model   vdw
   4.285 3.460
nonbonded pdb=" C   LYS A   3 "
          pdb="O    HOH S   5 "
   model   vdw
   4.286 3.270
nonbonded pdb=" CB  ASP A  50 "
          pdb=" CA  GLU A  51 "
   model   vdw
   4.286 3.870
nonbonded pdb=" CB  TYR A  26 "
          pdb=" CZ  TYR A  26 "
   model   vdw
   4.286 3.660
nonbonded pdb=" C   ALA A  55 "
          pdb=" CG  TYR A  56 "
   model   vdw
   4.286 3.490
nonbonded pdb=" O   LEU A  37 "
          pdb=" O   GLY A  38 "
   model   vdw
   4.286 3.040
nonbonded pdb=" O   PHE A  13 "
          pdb=" CE1 PHE A  13 "
   model   vdw
   4.286 3.340
nonbonded pdb=" O   LYS A  69 "
          pdb=" O   SER A  75 "
   model   vdw
   4.287 3.040
nonbonded pdb=" CB  TYR A  34 "
          pdb=" CZ  TYR A  34 "
   model   vdw
   4.287 3.660
nonbonded pdb=" CD  PRO A  54 "
          pdb="O    HOH S  39 "
   model   vdw
   4.287 3.440
nonbonded pdb=" CA  GLN A  10 "
          pdb=" OE1 GLN A  10 "
   model   vdw
   4.288 3.470
nonbonded pdb=" CA  GLN A  31 "
          pdb=" OE1 GLN A  31 "
   model   vdw
   4.288 3.470
nonbonded pdb=" CA  ALA A  55 "
          pdb=" C   TYR A  56 "
   model   vdw
   4.290 3.700
nonbonded pdb=" CG1 VAL A  43 "
          pdb=" N   LEU A  44 "
   model   vdw
   4.290 3.540
nonbonded pdb=" OG  SER A  75 "
          pdb="O    HOH S  38 "
   model   vdw sym.op.
   4.290 3.040 -x+1,y,-z+2
nonbonded pdb=" CB  PHE A  73 "
          pdb=" CZ  PHE A  73 "
   model   vdw
   4.290 3.740
nonbonded pdb=" N   ARG A  16 "
          pdb=" C   LEU A  28 "
   model   vdw
   4.291 3.350
nonbonded pdb=" CG2 THR A  62 "
          pdb="O    HOH S  19 "
   model   vdw
   4.291 3.460
nonbonded pdb=" O   PHE A  13 "
          pdb=" O   THR A  14 "
   model   vdw
   4.291 3.040
nonbonded pdb=" C   THR A  15 "
          pdb=" N   SER A  17 "
   model   vdw
   4.291 3.350
nonbonded pdb=" N   ILE A   2 "
          pdb=" OG1 THR A  62 "
   model   vdw
   4.293 3.120
nonbonded pdb=" CB  ASP A  50 "
          pdb=" NH1 ARG A  80 "
   model   vdw
   4.293 3.520
nonbonded pdb=" O   GLU A  51 "
          pdb=" O   GLY A  52 "
   model   vdw
   4.293 3.040
nonbonded pdb=" CG2 ILE A  47 "
          pdb=" CE2 TYR A  56 "
   model   vdw
   4.294 3.760
nonbonded pdb=" CB  TYR A  41 "
          pdb=" CZ  TYR A  41 "
   model   vdw
   4.295 3.660
nonbonded pdb=" CD  ARG A  16 "
          pdb="O    HOH S  11 "
   model   vdw
   4.295 3.440
nonbonded pdb=" C   GLN A  10 "
          pdb=" O   GLN A  12 "
   model   vdw
   4.295 3.270
nonbonded pdb=" CG2 ILE A   2 "
          pdb=" O   LYS A   3 "
   model   vdw
   4.295 3.460
nonbonded pdb=" C   ASN A  29 "
          pdb=" OD1 ASN A  29 "
   model   vdw
   4.295 3.270
nonbonded pdb=" C   LYS A   3 "
          pdb=" CD  LYS A   3 "
   model   vdw
   4.296 3.670
nonbonded pdb=" N   GLU A  40 "
          pdb=" O   TYR A  41 "
   model   vdw
   4.297 3.120
nonbonded pdb=" NE2 GLN A  31 "
          pdb=" C   ALA A  55 "
   model   vdw
   4.297 3.350
nonbonded pdb=" CD2 TYR A  56 "
          pdb=" CG  LEU A  83 "
   model   vdw
   4.297 3.770
nonbonded pdb=" C   THR A  48 "
          pdb=" CG  LEU A  49 "
   model   vdw
   4.298 3.700
nonbonded pdb=" C   LEU A  60 "
          pdb=" CE1 TYR A  61 "
   model   vdw
   4.299 3.570
nonbonded pdb=" CA  ASN A  39 "
          pdb=" N   TYR A  41 "
   model   vdw
   4.299 3.550
nonbonded pdb=" O   SER A  66 "
          pdb=" O   PHE A  68 "
   model   vdw
   4.299 3.040
nonbonded pdb=" C   TYR A  61 "
          pdb=" CG2 THR A  62 "
   model   vdw
   4.299 3.690
nonbonded pdb=" O   GLN A  72 "
          pdb=" CD1 PHE A  73 "
   model   vdw
   4.299 3.340
nonbonded pdb=" C   GLN A  53 "
          pdb=" N   ALA A  55 "
   model   vdw
   4.299 3.350
nonbonded pdb=" N   TYR A  34 "
          pdb=" O   VAL A  43 "
   model   vdw
   4.300 3.120
nonbonded pdb=" CD  LYS A   7 "
          pdb=" OE1 GLU A  40 "
   model   vdw sym.op.
   4.301 3.440 -x+1,y,-z+1
nonbonded pdb=" C   VAL A  35 "
          pdb=" CA  PRO A  42 "
   model   vdw
   4.301 3.700
nonbonded pdb=" O   ILE A   6 "
          pdb=" C   GLY A  59 "
   model   vdw
   4.301 3.270
nonbonded pdb=" C   ARG A  16 "
          pdb=" O   LEU A  28 "
   model   vdw
   4.301 3.270
nonbonded pdb=" O   ARG A  82 "
          pdb=" O   LEU A  83 "
   model   vdw
   4.301 3.040
nonbonded pdb=" CG  GLN A  53 "
          pdb=" C   PRO A  54 "
   model   vdw
   4.302 3.670
nonbonded pdb=" C   SER A  17 "
          pdb=" CE2 TYR A  26 "
   model   vdw
   4.302 3.570
nonbonded pdb=" O   VAL A  35 "
          pdb=" O   ASP A  36 "
   model   vdw
   4.302 3.040
nonbonded pdb=" O   ARG A  16 "
          pdb=" CB  SER A  27 "
   model   vdw
   4.303 3.440
nonbonded pdb=" NZ  LYS A   3 "
          pdb=" CB  GLN A  72 "
   model   vdw sym.op.
   4.303 3.520 -x+1,y+1,-z+2
nonbonded pdb=" CB  GLN A  72 "
          pdb=" NZ  LYS A   3 "
   model   vdw sym.op.
   4.303 3.520 -x+1,y-1,-z+2
nonbonded pdb=" O   ILE A   6 "
          pdb=" CD  PRO A   8 "
   model   vdw
   4.303 3.440
nonbonded pdb=" CA  GLY A  38 "
          pdb="O    HOH S   9 "
   model   vdw
   4.303 3.440
nonbonded pdb=" N   GLY A  71 "
          pdb="SE   MSE A  77 "
   model   vdw
   4.303 3.500
nonbonded pdb=" O   LYS A  46 "
          pdb=" O   GLY A  74 "
   model   vdw sym.op.
   4.304 3.040 -x+1,y,-z+2
nonbonded pdb=" CG2 THR A  48 "
          pdb=" CD  ARG A  80 "
   model   vdw
   4.305 3.860
nonbonded pdb=" C   PHE A  13 "
          pdb=" CE1 PHE A  13 "
   model   vdw
   4.305 3.570
nonbonded pdb=" CG2 VAL A  63 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   4.306 3.880
nonbonded pdb=" CZ  TYR A  41 "
          pdb=" CB  PRO A  42 "
   model   vdw sym.op.
   4.306 3.660 -x+1,y,-z+1
nonbonded pdb=" CD1 ILE A  47 "
          pdb=" CB  LEU A  81 "
   model   vdw
   4.307 3.860
nonbonded pdb=" CA  ARG A  80 "
          pdb=" NH1 ARG A  82 "
   model   vdw
   4.307 3.550
nonbonded pdb=" CA  PHE A  73 "
          pdb=" N   SER A  75 "
   model   vdw
   4.308 3.550
nonbonded pdb=" C   GLY A  71 "
          pdb=" CG  GLN A  72 "
   model   vdw
   4.308 3.670
nonbonded pdb=" CG1 VAL A  35 "
          pdb=" CD2 LEU A  76 "
   model   vdw sym.op.
   4.308 3.880 -x+1,y,-z+2
nonbonded pdb=" CB  LYS A   3 "
          pdb=" CE1 PHE A  73 "
   model   vdw sym.op.
   4.308 3.740 -x+1,y+1,-z+2
nonbonded pdb=" CG  PHE A  13 "
          pdb=" CD1 LEU A  49 "
   model   vdw
   4.308 3.680
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" C   ALA A  57 "
   model   vdw
   4.308 3.690
nonbonded pdb=" CB  GLN A  12 "
          pdb=" CA  PHE A  13 "
   model   vdw
   4.309 3.870
nonbonded pdb=" N   THR A  15 "
          pdb=" O   LEU A  28 "
   model   vdw
   4.309 3.120
nonbonded pdb=" CA  THR A  48 "
          pdb="O    HOH S  38 "
   model   vdw
   4.310 3.470
nonbonded pdb=" CG  LEU A  37 "
          pdb=" O   PHE A  68 "
   model   vdw sym.op.
   4.310 3.470 -x+1,y,-z+2
nonbonded pdb=" CA  VAL A  84 "
          pdb=" CG  PRO A  85 "
   model   vdw
   4.311 3.870
nonbonded pdb=" O   TYR A  61 "
          pdb=" OG1 THR A  62 "
   model   vdw
   4.311 3.040
nonbonded pdb=" CG1 VAL A  35 "
          pdb=" C   ASP A  36 "
   model   vdw
   4.311 3.690
nonbonded pdb=" CD  GLN A  53 "
          pdb=" O   PRO A  54 "
   model   vdw
   4.312 3.270
nonbonded pdb=" O   VAL A  45 "
          pdb=" O   LYS A  46 "
   model   vdw
   4.312 3.040
nonbonded pdb=" CB  ALA A  57 "
          pdb=" O   PRO A  58 "
   model   vdw
   4.312 3.460
nonbonded pdb=" O   SER A  17 "
          pdb=" CE2 TYR A  26 "
   model   vdw
   4.313 3.340
nonbonded pdb=" CE  LYS A   3 "
          pdb=" CD2 LEU A  60 "
   model   vdw
   4.313 3.860
nonbonded pdb=" OG  SER A  27 "
          pdb=" CA  LEU A  28 "
   model   vdw
   4.314 3.470
nonbonded pdb=" OG1 THR A  62 "
          pdb=" CA  VAL A  63 "
   model   vdw
   4.315 3.470
nonbonded pdb=" CA  ALA A  57 "
          pdb=" CG  PRO A  58 "
   model   vdw
   4.316 3.870
nonbonded pdb=" OE2 GLU A   5 "
          pdb=" CG  LYS A   7 "
   model   vdw
   4.316 3.440
nonbonded pdb=" CA  GLN A  72 "
          pdb="O    HOH S   3 "
   model   vdw
   4.316 3.470
nonbonded pdb=" O   PRO A   8 "
          pdb=" CG2 THR A  14 "
   model   vdw sym.op.
   4.316 3.460 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CG  ASP A  50 "
          pdb=" CZ  ARG A  82 "
   model   vdw
   4.317 3.500
nonbonded pdb=" N   LEU A  76 "
          pdb=" CD1 LEU A  76 "
   model   vdw
   4.318 3.540
nonbonded pdb=" O   GLN A  12 "
          pdb=" NE2 GLN A  31 "
   model   vdw
   4.318 3.120
nonbonded pdb=" CA  ALA A  55 "
          pdb=" O   TYR A  56 "
   model   vdw
   4.318 3.470
nonbonded pdb=" C   GLY A  71 "
          pdb=" O   GLN A  72 "
   model   vdw
   4.318 3.270
nonbonded pdb=" N   GLY A  74 "
          pdb=" CA  SER A  75 "
   model   vdw
   4.318 3.550
nonbonded pdb=" CB  SER A  17 "
          pdb=" CA  SER A  27 "
   model   vdw
   4.319 3.870
nonbonded pdb=" C   GLY A  71 "
          pdb=" O   SER A  75 "
   model   vdw
   4.319 3.270
nonbonded pdb=" CA  LYS A   7 "
          pdb=" CG  PRO A   8 "
   model   vdw
   4.320 3.870
nonbonded pdb=" O   THR A  14 "
          pdb=" CB  GLU A  30 "
   model   vdw
   4.320 3.440
nonbonded pdb=" O   THR A  14 "
          pdb=" N   ASN A  29 "
   model   vdw
   4.320 3.120
nonbonded pdb=" CG1 VAL A  35 "
          pdb=" O   ASP A  36 "
   model   vdw
   4.322 3.460
nonbonded pdb=" OG1 THR A  14 "
          pdb=" OE1 GLU A  30 "
   model   vdw
   4.322 3.040
nonbonded pdb=" O   GLN A  10 "
          pdb=" O   ALA A  11 "
   model   vdw
   4.322 3.040
nonbonded pdb=" CG  LYS A   7 "
          pdb=" CD  PRO A   8 "
   model   vdw
   4.323 3.840
nonbonded pdb=" CA  SER A  17 "
          pdb=" CD1 TYR A  26 "
   model   vdw
   4.323 3.770
nonbonded pdb=" C   GLN A  12 "
          pdb=" CB  ALA A  55 "
   model   vdw
   4.323 3.690
nonbonded pdb=" CA  SER A   9 "
          pdb=" N   THR A  15 "
   model   vdw sym.op.
   4.323 3.550 -x+1/2,y+1/2,-z+1
nonbonded pdb=" N   THR A  15 "
          pdb=" CA  SER A   9 "
   model   vdw sym.op.
   4.323 3.550 -x+1/2,y-1/2,-z+1
nonbonded pdb=" N   VAL A  35 "
          pdb=" CB  PRO A  42 "
   model   vdw
   4.324 3.520
nonbonded pdb=" CD1 ILE A   2 "
          pdb=" CG1 VAL A  35 "
   model   vdw
   4.324 3.880
nonbonded pdb=" C   GLU A   5 "
          pdb=" CD  GLU A   5 "
   model   vdw
   4.324 3.500
nonbonded pdb=" O   GLY A  38 "
          pdb=" CG  ASN A  39 "
   model   vdw
   4.324 3.270
nonbonded pdb=" CA  PRO A  54 "
          pdb=" O   ALA A  55 "
   model   vdw
   4.324 3.470
nonbonded pdb=" CG2 VAL A  63 "
          pdb=" CD2 LEU A  81 "
   model   vdw
   4.325 3.880
nonbonded pdb=" CA  PRO A   8 "
          pdb=" N   THR A  15 "
   model   vdw sym.op.
   4.325 3.550 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CB  PHE A  13 "
          pdb=" CA  THR A  14 "
   model   vdw
   4.325 3.870
nonbonded pdb=" O   ILE A   6 "
          pdb=" CG1 ILE A   6 "
   model   vdw
   4.325 3.440
nonbonded pdb=" C   GLU A  40 "
          pdb=" OE1 GLU A  40 "
   model   vdw
   4.325 3.270
nonbonded pdb=" CG1 VAL A  45 "
          pdb=" CB  LEU A  76 "
   model   vdw sym.op.
   4.325 3.860 -x+1,y,-z+2
nonbonded pdb=" CG2 VAL A  45 "
          pdb=" CD1 LEU A  76 "
   model   vdw sym.op.
   4.325 3.880 -x+1,y,-z+2
nonbonded pdb=" NE2 GLN A  10 "
          pdb=" N   TYR A  34 "
   model   vdw
   4.326 3.200
nonbonded pdb=" CB  TYR A  56 "
          pdb="O    HOH S   7 "
   model   vdw
   4.326 3.440
nonbonded pdb=" N   GLN A  12 "
          pdb="O    HOH S   8 "
   model   vdw
   4.326 3.120
nonbonded pdb=" C   TYR A  61 "
          pdb=" CE1 PHE A  73 "
   model   vdw sym.op.
   4.327 3.570 -x+1,y+1,-z+2
nonbonded pdb=" O   GLU A   5 "
          pdb=" CB  TYR A  34 "
   model   vdw
   4.327 3.440
nonbonded pdb=" CG  MSE A  77 "
          pdb=" N   ILE A  78 "
   model   vdw
   4.328 3.520
nonbonded pdb=" CG1 ILE A   6 "
          pdb=" CB  TYR A  56 "
   model   vdw
   4.328 3.840
nonbonded pdb=" O   ALA A  55 "
          pdb="O    HOH S  39 "
   model   vdw
   4.328 3.040
nonbonded pdb=" C   THR A  15 "
          pdb=" CG  ARG A  16 "
   model   vdw
   4.329 3.670
nonbonded pdb=" CA  LYS A   3 "
          pdb=" CE1 PHE A  73 "
   model   vdw sym.op.
   4.329 3.770 -x+1,y+1,-z+2
nonbonded pdb=" CD1 LEU A  28 "
          pdb=" NH1 ARG A  80 "
   model   vdw
   4.330 3.540
nonbonded pdb=" C   SER A  27 "
          pdb=" N   ASN A  29 "
   model   vdw
   4.330 3.350
nonbonded pdb=" NE2 HIS A  64 "
          pdb=" N   LEU A  65 "
   model   vdw
   4.330 3.200
nonbonded pdb=" CA  LEU A  49 "
          pdb=" C   ASP A  50 "
   model   vdw
   4.331 3.700
nonbonded pdb=" CG  LEU A  76 "
          pdb=" CD1 ILE A  78 "
   model   vdw sym.op.
   4.332 3.890 -x+1,y,-z+2
nonbonded pdb=" O   LEU A  65 "
          pdb=" C   PHE A  68 "
   model   vdw
   4.333 3.270
nonbonded pdb=" CD  GLN A  72 "
          pdb=" CE2 PHE A  73 "
   model   vdw
   4.334 3.570
nonbonded pdb=" CA  PRO A   8 "
          pdb=" CA  THR A  14 "
   model   vdw sym.op.
   4.334 3.900 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CG  ARG A  16 "
          pdb=" NH1 ARG A  16 "
   model   vdw
   4.334 3.520
nonbonded pdb=" N   GLU A  30 "
          pdb=" CD  GLU A  30 "
   model   vdw
   4.334 3.350
nonbonded pdb=" CD1 LEU A  28 "
          pdb=" CZ  ARG A  80 "
   model   vdw
   4.334 3.690
nonbonded pdb=" NH2 ARG A  16 "
          pdb=" CA  LEU A  60 "
   model   vdw sym.op.
   4.334 3.550 x,y-1,z
nonbonded pdb=" CG  TYR A  61 "
          pdb=" N   THR A  62 "
   model   vdw
   4.334 3.340
nonbonded pdb=" CB  HIS A  64 "
          pdb=" N   SER A  66 "
   model   vdw
   4.335 3.520
nonbonded pdb=" CB  GLU A  30 "
          pdb=" CG  LYS A  46 "
   model   vdw
   4.335 3.840
nonbonded pdb=" CG1 VAL A   4 "
          pdb=" CA  GLU A   5 "
   model   vdw
   4.336 3.890
nonbonded pdb=" O   ASN A  29 "
          pdb=" N   GLN A  31 "
   model   vdw
   4.336 3.120
nonbonded pdb=" O   ALA A  55 "
          pdb=" CA  ALA A  57 "
   model   vdw
   4.336 3.470
nonbonded pdb=" C   ALA A  11 "
          pdb=" CG  GLN A  12 "
   model   vdw
   4.337 3.670
nonbonded pdb=" C   GLY A  74 "
          pdb=" N   LEU A  76 "
   model   vdw
   4.337 3.350
nonbonded pdb=" CG  LEU A  32 "
          pdb=" N   CYS A  33 "
   model   vdw
   4.337 3.550
nonbonded pdb=" C   CYS A  33 "
          pdb=" O   VAL A  43 "
   model   vdw
   4.337 3.270
nonbonded pdb=" O   LYS A  69 "
          pdb=" O   VAL A  70 "
   model   vdw
   4.337 3.040
nonbonded pdb=" C   THR A  14 "
          pdb=" O   LEU A  28 "
   model   vdw
   4.338 3.270
nonbonded pdb=" C   GLU A  51 "
          pdb=" O   GLY A  52 "
   model   vdw
   4.338 3.270
nonbonded pdb=" CB  GLN A  12 "
          pdb=" O   PHE A  13 "
   model   vdw
   4.338 3.440
nonbonded pdb=" C   ASP A  50 "
          pdb=" OE1 GLN A  53 "
   model   vdw
   4.338 3.270
nonbonded pdb=" C   GLN A  10 "
          pdb=" CD  GLN A  12 "
   model   vdw
   4.339 3.500
nonbonded pdb=" CA  TYR A  41 "
          pdb=" CG  PRO A  42 "
   model   vdw
   4.339 3.870
nonbonded pdb=" CD2 LEU A  76 "
          pdb=" CD1 ILE A  78 "
   model   vdw sym.op.
   4.340 3.880 -x+1,y,-z+2
nonbonded pdb=" CD1 LEU A  37 "
          pdb=" C   LYS A  69 "
   model   vdw sym.op.
   4.340 3.690 -x+1,y,-z+2
nonbonded pdb=" C   GLN A  53 "
          pdb=" CD  GLN A  53 "
   model   vdw
   4.341 3.500
nonbonded pdb=" C   LYS A   3 "
          pdb=" N   GLU A   5 "
   model   vdw
   4.341 3.350
nonbonded pdb=" O   THR A  14 "
          pdb=" C   LEU A  28 "
   model   vdw
   4.342 3.270
nonbonded pdb=" O   HIS A  64 "
          pdb=" O   ARG A  82 "
   model   vdw
   4.342 3.040
nonbonded pdb=" O   PRO A   8 "
          pdb=" O   SER A   9 "
   model   vdw
   4.342 3.040
nonbonded pdb=" CE1 TYR A  34 "
          pdb=" CD1 LEU A  44 "
   model   vdw
   4.342 3.760
nonbonded pdb=" N   PHE A  13 "
          pdb=" CB  ALA A  55 "
   model   vdw
   4.342 3.540
nonbonded pdb=" CB  VAL A   4 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   4.342 3.890
nonbonded pdb=" C   LYS A   7 "
          pdb=" CG  PRO A  58 "
   model   vdw
   4.342 3.670
nonbonded pdb=" CE2 PHE A  68 "
          pdb=" CD1 ILE A  78 "
   model   vdw sym.op.
   4.343 3.760 -x+1,y,-z+2
nonbonded pdb=" CD1 ILE A  78 "
          pdb=" CE2 PHE A  68 "
   model   vdw sym.op.
   4.343 3.760 -x+1,y,-z+2
nonbonded pdb=" CB  PHE A  68 "
          pdb=" CG  LEU A  76 "
   model   vdw
   4.343 3.870
nonbonded pdb=" CB  GLU A   5 "
          pdb=" O   TYR A  34 "
   model   vdw
   4.343 3.440
nonbonded pdb=" CZ  PHE A  13 "
          pdb=" CG  ASN A  29 "
   model   vdw
   4.344 3.570
nonbonded pdb=" CD2 TYR A  61 "
          pdb=" N   VAL A  84 "
   model   vdw
   4.344 3.420
nonbonded pdb=" C   TYR A  34 "
          pdb=" CB  PRO A  42 "
   model   vdw
   4.344 3.670
nonbonded pdb=" CB  GLN A  10 "
          pdb="O    HOH S  23 "
   model   vdw
   4.345 3.440
nonbonded pdb=" CB  THR A  62 "
          pdb=" O   VAL A  84 "
   model   vdw
   4.345 3.470
nonbonded pdb=" O   GLU A   5 "
          pdb=" C   TYR A  34 "
   model   vdw
   4.345 3.270
nonbonded pdb=" CG  MSE A  77 "
          pdb="O    HOH S  13 "
   model   vdw
   4.345 3.440
nonbonded pdb="O    HOH S  13 "
          pdb=" CG  MSE A  77 "
   model   vdw sym.op.
   4.346 3.440 -x+1,y,-z+2
nonbonded pdb=" CG  MSE A  77 "
          pdb="O    HOH S  13 "
   model   vdw sym.op.
   4.346 3.440 -x+1,y,-z+2
nonbonded pdb=" OE2 GLU A  30 "
          pdb="O    HOH S  11 "
   model   vdw
   4.346 3.040
nonbonded pdb=" C   ASN A  29 "
          pdb=" N   GLN A  31 "
   model   vdw
   4.346 3.350
nonbonded pdb=" CA  ILE A   6 "
          pdb=" N   GLY A  59 "
   model   vdw
   4.346 3.550
nonbonded pdb=" CA  GLY A  38 "
          pdb=" CD2 LEU A  65 "
   model   vdw sym.op.
   4.347 3.860 -x+1,y,-z+2
nonbonded pdb=" CD  LYS A  46 "
          pdb=" N   ILE A  47 "
   model   vdw
   4.347 3.520
nonbonded pdb=" O   GLU A  40 "
          pdb=" CE2 TYR A  41 "
   model   vdw
   4.347 3.340
nonbonded pdb=" C   LYS A   7 "
          pdb=" C   SER A   9 "
   model   vdw
   4.348 3.500
nonbonded pdb=" O   LEU A  37 "
          pdb=" ND2 ASN A  39 "
   model   vdw
   4.348 3.120
nonbonded pdb=" CA  PRO A  54 "
          pdb=" C   ALA A  55 "
   model   vdw
   4.348 3.700
nonbonded pdb=" CD1 ILE A   6 "
          pdb=" CD1 LEU A  83 "
   model   vdw
   4.348 3.880
nonbonded pdb=" O   GLY A  71 "
          pdb=" CA  PHE A  73 "
   model   vdw
   4.349 3.470
nonbonded pdb=" CB  LYS A   3 "
          pdb=" CZ  PHE A  73 "
   model   vdw sym.op.
   4.349 3.740 -x+1,y+1,-z+2
nonbonded pdb=" CD1 TYR A  56 "
          pdb=" CZ  TYR A  61 "
   model   vdw
   4.349 3.560
nonbonded pdb=" CA  TYR A  61 "
          pdb=" C   VAL A  84 "
   model   vdw
   4.350 3.700
nonbonded pdb=" O   ALA A  11 "
          pdb=" O   GLN A  12 "
   model   vdw
   4.350 3.040
nonbonded pdb=" O   MSE A  77 "
          pdb=" CG  MSE A  77 "
   model   vdw
   4.351 3.440
nonbonded pdb=" O   THR A  48 "
          pdb=" CB  ARG A  80 "
   model   vdw
   4.351 3.440
nonbonded pdb=" CB  ASN A  29 "
          pdb=" CG  LEU A  49 "
   model   vdw
   4.351 3.870
nonbonded pdb=" SG  CYS A  33 "
          pdb=" C   TYR A  34 "
   model   vdw
   4.351 3.630
nonbonded pdb=" CB  LEU A  49 "
          pdb=" CA  ASP A  50 "
   model   vdw
   4.351 3.870
nonbonded pdb=" N   PRO A   8 "
          pdb=" N   GLN A  10 "
   model   vdw
   4.352 3.200
nonbonded pdb=" CZ  TYR A  61 "
          pdb="O    HOH S   7 "
   model   vdw
   4.352 3.260
nonbonded pdb=" CD  GLN A  31 "
          pdb=" CA  ALA A  55 "
   model   vdw
   4.352 3.700
nonbonded pdb=" CB  ARG A  16 "
          pdb=" CZ  ARG A  16 "
   model   vdw
   4.352 3.670
nonbonded pdb=" CD  PRO A  42 "
          pdb=" CD1 TYR A  41 "
   model   vdw sym.op.
   4.352 3.740 -x+1,y,-z+1
nonbonded pdb=" CD1 TYR A  41 "
          pdb=" CD  PRO A  42 "
   model   vdw sym.op.
   4.352 3.740 -x+1,y,-z+1
nonbonded pdb=" CA  TYR A  61 "
          pdb=" C   PRO A  85 "
   model   vdw
   4.352 3.700
nonbonded pdb=" CA  ALA A  11 "
          pdb=" O   TYR A  56 "
   model   vdw
   4.353 3.470
nonbonded pdb=" C   ARG A  82 "
          pdb=" N   VAL A  84 "
   model   vdw
   4.354 3.350
nonbonded pdb=" CG  GLN A  31 "
          pdb=" CA  LEU A  32 "
   model   vdw
   4.354 3.870
nonbonded pdb=" CB  GLU A  40 "
          pdb=" CE2 TYR A  41 "
   model   vdw
   4.355 3.740
nonbonded pdb=" O   ASP A  36 "
          pdb=" OD2 ASP A  36 "
   model   vdw
   4.355 3.040
nonbonded pdb=" CD2 LEU A  32 "
          pdb=" N   LYS A  46 "
   model   vdw
   4.355 3.540
nonbonded pdb=" CA  VAL A  43 "
          pdb=" C   LEU A  44 "
   model   vdw
   4.355 3.700
nonbonded pdb=" O   GLN A  12 "
          pdb=" O   PHE A  13 "
   model   vdw
   4.355 3.040
nonbonded pdb=" O   LEU A  44 "
          pdb=" O   GLY A  74 "
   model   vdw sym.op.
   4.355 3.040 -x+1,y,-z+2
nonbonded pdb=" N   LEU A  37 "
          pdb=" CD2 LEU A  65 "
   model   vdw sym.op.
   4.358 3.540 -x+1,y,-z+2
nonbonded pdb=" CB  LYS A  69 "
          pdb=" CA  VAL A  70 "
   model   vdw
   4.358 3.870
nonbonded pdb=" CZ  ARG A  16 "
          pdb=" C   LEU A  60 "
   model   vdw sym.op.
   4.358 3.500 x,y-1,z
nonbonded pdb=" C   LYS A   7 "
          pdb=" CB  GLN A  10 "
   model   vdw
   4.358 3.670
nonbonded pdb=" C   ASN A  39 "
          pdb=" ND2 ASN A  39 "
   model   vdw
   4.358 3.350
nonbonded pdb=" CB  PRO A   8 "
          pdb=" C   PHE A  13 "
   model   vdw sym.op.
   4.359 3.670 -x+1/2,y+1/2,-z+1
nonbonded pdb=" OE1 GLU A   5 "
          pdb=" CE  LYS A   7 "
   model   vdw
   4.360 3.440
nonbonded pdb=" C   ILE A   2 "
          pdb="O    HOH S  19 "
   model   vdw
   4.361 3.270
nonbonded pdb=" CD  GLN A  31 "
          pdb=" CB  TYR A  56 "
   model   vdw
   4.361 3.670
nonbonded pdb=" O   VAL A  70 "
          pdb=" CG2 VAL A  70 "
   model   vdw
   4.361 3.460
nonbonded pdb=" CG2 THR A  15 "
          pdb=" N   LEU A  28 "
   model   vdw
   4.362 3.540
nonbonded pdb=" SG  CYS A  33 "
          pdb=" CA  TYR A  34 "
   model   vdw
   4.363 3.830
nonbonded pdb=" CA  SER A   9 "
          pdb=" CA  THR A  15 "
   model   vdw sym.op.
   4.363 3.900 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CA  THR A  15 "
          pdb=" CA  SER A   9 "
   model   vdw sym.op.
   4.363 3.900 -x+1/2,y-1/2,-z+1
nonbonded pdb=" CD1 PHE A  13 "
          pdb=" CA  ASN A  29 "
   model   vdw
   4.364 3.770
nonbonded pdb=" CA  ASN A  39 "
          pdb=" C   GLU A  40 "
   model   vdw
   4.364 3.700
nonbonded pdb=" O   SER A  67 "
          pdb=" CG1 ILE A  78 "
   model   vdw
   4.365 3.440
nonbonded pdb=" CG  HIS A  64 "
          pdb=" CA  LEU A  65 "
   model   vdw
   4.365 3.690
nonbonded pdb=" CD1 PHE A  13 "
          pdb="O    HOH S  14 "
   model   vdw
   4.365 3.340
nonbonded pdb=" CG  ARG A  16 "
          pdb=" OE2 GLU A  30 "
   model   vdw
   4.365 3.440
nonbonded pdb=" O   ILE A  78 "
          pdb=" N   ARG A  80 "
   model   vdw
   4.365 3.120
nonbonded pdb=" C   GLY A  59 "
          pdb=" CD2 LEU A  60 "
   model   vdw
   4.366 3.690
nonbonded pdb=" CG2 VAL A   4 "
          pdb=" CB  VAL A  35 "
   model   vdw
   4.366 3.890
nonbonded pdb=" C   PRO A   8 "
          pdb=" N   ALA A  11 "
   model   vdw
   4.366 3.350
nonbonded pdb=" N   LEU A  65 "
          pdb=" N   SER A  67 "
   model   vdw
   4.366 3.200
nonbonded pdb=" CA  SER A   9 "
          pdb=" C   THR A  15 "
   model   vdw sym.op.
   4.366 3.700 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CA  ALA A  57 "
          pdb=" O   PRO A  58 "
   model   vdw
   4.366 3.470
nonbonded pdb=" O   ASN A  29 "
          pdb=" CB  THR A  48 "
   model   vdw
   4.367 3.470
nonbonded pdb=" O   LEU A  37 "
          pdb=" CD2 LEU A  65 "
   model   vdw sym.op.
   4.367 3.460 -x+1,y,-z+2
nonbonded pdb=" CG1 VAL A  84 "
          pdb=" CD  PRO A  85 "
   model   vdw
   4.367 3.860
nonbonded pdb=" CB  TYR A  56 "
          pdb=" CE1 TYR A  61 "
   model   vdw
   4.368 3.740
nonbonded pdb=" CG1 VAL A  70 "
          pdb=" CA  GLY A  74 "
   model   vdw
   4.368 3.860
nonbonded pdb=" CA  SER A  17 "
          pdb=" C   TYR A  26 "
   model   vdw
   4.369 3.700
nonbonded pdb=" OG  SER A   9 "
          pdb=" CB  GLN A  10 "
   model   vdw
   4.369 3.440
nonbonded pdb=" CB  SER A   9 "
          pdb=" CG2 THR A  15 "
   model   vdw sym.op.
   4.370 3.860 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CG2 THR A  15 "
          pdb=" CB  SER A   9 "
   model   vdw sym.op.
   4.370 3.860 -x+1/2,y-1/2,-z+1
nonbonded pdb=" CG  PHE A  13 "
          pdb=" CG  ASN A  29 "
   model   vdw
   4.370 3.490
nonbonded pdb=" CB  MSE A  77 "
          pdb=" C   ILE A  78 "
   model   vdw
   4.370 3.670
nonbonded pdb=" CG  LEU A  49 "
          pdb=" CG  GLN A  53 "
   model   vdw
   4.370 3.870
nonbonded pdb=" NH1 ARG A  16 "
          pdb=" CB  PRO A  85 "
   model   vdw sym.op.
   4.371 3.520 x,y-1,z
nonbonded pdb=" CD2 LEU A  81 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   4.371 3.880
nonbonded pdb=" CG  ARG A  80 "
          pdb=" N   LEU A  81 "
   model   vdw
   4.371 3.520
nonbonded pdb=" CG  ASP A  79 "
          pdb=" NH2 ARG A  82 "
   model   vdw
   4.372 3.350
nonbonded pdb=" CD1 TYR A  26 "
          pdb=" N   LEU A  28 "
   model   vdw
   4.373 3.420
nonbonded pdb=" CA  LEU A  32 "
          pdb=" CB  CYS A  33 "
   model   vdw
   4.373 3.870
nonbonded pdb=" N   GLY A  71 "
          pdb="O    HOH S   1 "
   model   vdw sym.op.
   4.373 3.120 -x,y+1,-z+1
nonbonded pdb=" CA  GLN A  10 "
          pdb=" N   GLN A  12 "
   model   vdw
   4.374 3.550
nonbonded pdb=" O   SER A  67 "
          pdb=" CD2 PHE A  68 "
   model   vdw
   4.374 3.340
nonbonded pdb=" N   GLN A  12 "
          pdb=" NE2 GLN A  31 "
   model   vdw
   4.374 3.200
nonbonded pdb=" O   VAL A  43 "
          pdb=" CB  VAL A  45 "
   model   vdw
   4.374 3.470
nonbonded pdb=" CA  PHE A  68 "
          pdb=" CA  ILE A  78 "
   model   vdw
   4.375 3.900
nonbonded pdb="SE   MSE A  77 "
          pdb="O    HOH S   3 "
   model   vdw
   4.375 3.420
nonbonded pdb=" CE2 TYR A  61 "
          pdb=" N   PRO A  85 "
   model   vdw
   4.376 3.420
nonbonded pdb=" CA  SER A  75 "
          pdb="O    HOH S  38 "
   model   vdw sym.op.
   4.376 3.470 -x+1,y,-z+2
nonbonded pdb=" CA  ALA A  57 "
          pdb=" C   PRO A  58 "
   model   vdw
   4.376 3.700
nonbonded pdb=" CA  HIS A  64 "
          pdb=" N   SER A  66 "
   model   vdw
   4.376 3.550
nonbonded pdb=" CG2 VAL A  45 "
          pdb=" N   LYS A  46 "
   model   vdw
   4.376 3.540
nonbonded pdb=" CG1 ILE A   2 "
          pdb=" N   LYS A   3 "
   model   vdw
   4.377 3.520
nonbonded pdb=" C   VAL A  70 "
          pdb=" N   GLN A  72 "
   model   vdw
   4.377 3.350
nonbonded pdb=" O   GLY A  71 "
          pdb=" C   PHE A  73 "
   model   vdw
   4.377 3.270
nonbonded pdb=" CB  THR A  14 "
          pdb=" CA  THR A  15 "
   model   vdw
   4.377 3.900
nonbonded pdb=" CB  GLU A  40 "
          pdb=" OH  TYR A  34 "
   model   vdw sym.op.
   4.378 3.440 -x+1,y,-z+1
nonbonded pdb=" OH  TYR A  34 "
          pdb=" CB  GLU A  40 "
   model   vdw sym.op.
   4.378 3.440 -x+1,y,-z+1
nonbonded pdb=" CD2 PHE A  13 "
          pdb=" CD1 LEU A  49 "
   model   vdw
   4.378 3.760
nonbonded pdb=" C   SER A  67 "
          pdb=" N   LYS A  69 "
   model   vdw
   4.378 3.350
nonbonded pdb=" N   MSE A  77 "
          pdb=" CD1 ILE A  78 "
   model   vdw sym.op.
   4.380 3.540 -x+1,y,-z+2
nonbonded pdb=" O   TYR A  34 "
          pdb=" O   VAL A  35 "
   model   vdw
   4.380 3.040
nonbonded pdb=" CA  THR A  48 "
          pdb=" C   LEU A  49 "
   model   vdw
   4.381 3.700
nonbonded pdb=" C   ASN A  39 "
          pdb=" CA  TYR A  41 "
   model   vdw
   4.381 3.700
nonbonded pdb=" CA  THR A  14 "
          pdb="O    HOH S  11 "
   model   vdw
   4.381 3.470
nonbonded pdb=" N   ALA A  11 "
          pdb=" NE2 GLN A  31 "
   model   vdw
   4.383 3.200
nonbonded pdb=" CD2 LEU A  76 "
          pdb=" CD2 LEU A  81 "
   model   vdw sym.op.
   4.383 3.880 -x+1,y,-z+2
nonbonded pdb=" O   VAL A  70 "
          pdb="O    HOH S  10 "
   model   vdw
   4.384 3.040
nonbonded pdb=" CG1 ILE A  47 "
          pdb=" O   LEU A  81 "
   model   vdw
   4.384 3.440
nonbonded pdb=" CA  SER A   9 "
          pdb=" N   ALA A  11 "
   model   vdw
   4.384 3.550
nonbonded pdb=" CG2 ILE A  78 "
          pdb=" CA  ARG A  80 "
   model   vdw
   4.384 3.890
nonbonded pdb=" O   VAL A   4 "
          pdb=" CB  LEU A  60 "
   model   vdw
   4.384 3.440
nonbonded pdb=" CB  LEU A  32 "
          pdb=" CA  CYS A  33 "
   model   vdw
   4.384 3.870
nonbonded pdb=" NE2 GLN A  53 "
          pdb=" O   PRO A  54 "
   model   vdw
   4.384 3.120
nonbonded pdb=" CZ  TYR A  56 "
          pdb=" O   LEU A  83 "
   model   vdw
   4.385 3.260
nonbonded pdb=" CD2 TYR A  34 "
          pdb=" N   VAL A  43 "
   model   vdw
   4.385 3.420
nonbonded pdb=" O   MSE A  77 "
          pdb=" CG1 ILE A  78 "
   model   vdw
   4.385 3.440
nonbonded pdb=" CA  ILE A   6 "
          pdb=" O   LYS A   7 "
   model   vdw
   4.385 3.470
nonbonded pdb=" CB  PHE A  13 "
          pdb=" CB  ASN A  29 "
   model   vdw
   4.386 3.840
nonbonded pdb=" N   VAL A   4 "
          pdb=" O   TYR A  34 "
   model   vdw
   4.386 3.120
nonbonded pdb=" O   SER A  27 "
          pdb=" N   ASN A  29 "
   model   vdw
   4.387 3.120
nonbonded pdb=" CA  TYR A  56 "
          pdb=" C   ALA A  57 "
   model   vdw
   4.387 3.700
nonbonded pdb=" O   LYS A   7 "
          pdb=" OE1 GLN A  10 "
   model   vdw
   4.387 3.040
nonbonded pdb=" CA  GLY A  38 "
          pdb=" O   ASN A  39 "
   model   vdw
   4.387 3.440
nonbonded pdb=" O   ASN A  39 "
          pdb=" O   TYR A  41 "
   model   vdw
   4.388 3.040
nonbonded pdb=" CG1 ILE A  78 "
          pdb="O    HOH S  13 "
   model   vdw sym.op.
   4.388 3.440 -x+1,y,-z+2
nonbonded pdb=" CG1 ILE A  78 "
          pdb="O    HOH S  13 "
   model   vdw
   4.388 3.440
nonbonded pdb=" O   ASP A  50 "
          pdb=" CD  GLN A  53 "
   model   vdw
   4.388 3.270
nonbonded pdb=" C   TYR A  26 "
          pdb=" N   LEU A  28 "
   model   vdw
   4.389 3.350
nonbonded pdb=" O   CYS A  33 "
          pdb=" C   VAL A  43 "
   model   vdw
   4.389 3.270
nonbonded pdb=" CD2 TYR A  34 "
          pdb=" CA  VAL A  43 "
   model   vdw
   4.389 3.770
nonbonded pdb=" CG1 ILE A  47 "
          pdb=" N   THR A  48 "
   model   vdw
   4.390 3.520
nonbonded pdb=" NE2 GLN A  10 "
          pdb=" CA  LEU A  32 "
   model   vdw
   4.390 3.550
nonbonded pdb=" CD2 TYR A  34 "
          pdb=" CD1 LEU A  44 "
   model   vdw
   4.390 3.760
nonbonded pdb=" CG2 ILE A  47 "
          pdb=" O   THR A  48 "
   model   vdw
   4.390 3.460
nonbonded pdb=" N   ILE A   2 "
          pdb="O    HOH S   5 "
   model   vdw
   4.391 3.120
nonbonded pdb=" O   ASN A  39 "
          pdb="O    HOH S   9 "
   model   vdw
   4.391 3.040
nonbonded pdb=" CG1 VAL A   4 "
          pdb=" O   GLU A   5 "
   model   vdw
   4.391 3.460
nonbonded pdb=" C   ALA A  57 "
          pdb=" CZ  TYR A  61 "
   model   vdw
   4.392 3.490
nonbonded pdb=" OD2 ASP A  79 "
          pdb=" CB  ARG A  80 "
   model   vdw
   4.392 3.440
nonbonded pdb=" CE  LYS A  69 "
          pdb="O    HOH S   1 "
   model   vdw sym.op.
   4.393 3.440 -x,y+1,-z+1
nonbonded pdb=" CG1 VAL A  35 "
          pdb=" CA  ASP A  36 "
   model   vdw
   4.393 3.890
nonbonded pdb=" OE1 GLN A  72 "
          pdb=" CZ  PHE A  73 "
   model   vdw
   4.394 3.340
nonbonded pdb=" C   PRO A   8 "
          pdb=" O   SER A   9 "
   model   vdw
   4.394 3.270
nonbonded pdb=" N   PRO A   8 "
          pdb="O    HOH S  12 "
   model   vdw
   4.394 3.120
nonbonded pdb=" CB  PRO A   8 "
          pdb=" C   THR A  14 "
   model   vdw sym.op.
   4.395 3.670 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CG  LEU A  76 "
          pdb=" O   MSE A  77 "
   model   vdw
   4.396 3.470
nonbonded pdb=" CG2 THR A  14 "
          pdb=" N   THR A  15 "
   model   vdw
   4.396 3.540
nonbonded pdb=" CE2 TYR A  34 "
          pdb=" CA  LEU A  44 "
   model   vdw
   4.396 3.770
nonbonded pdb=" C   THR A  62 "
          pdb=" CG2 VAL A  84 "
   model   vdw
   4.396 3.690
nonbonded pdb=" CA  VAL A  43 "
          pdb=" O   LEU A  44 "
   model   vdw
   4.397 3.470
nonbonded pdb=" CB  VAL A  43 "
          pdb=" CA  LEU A  44 "
   model   vdw
   4.397 3.900
nonbonded pdb=" CD1 ILE A   2 "
          pdb=" CG  LEU A  65 "
   model   vdw sym.op.
   4.397 3.890 -x+1,y,-z+2
nonbonded pdb=" CB  ALA A  57 "
          pdb=" CA  PRO A  58 "
   model   vdw
   4.398 3.890
nonbonded pdb=" CE1 TYR A  41 "
          pdb=" CD1 TYR A  41 "
   model   vdw sym.op.
   4.398 3.640 -x+1,y,-z+1
nonbonded pdb=" CD1 TYR A  41 "
          pdb=" CE1 TYR A  41 "
   model   vdw sym.op.
   4.398 3.640 -x+1,y,-z+1
nonbonded pdb=" C   GLN A  10 "
          pdb=" O   ALA A  11 "
   model   vdw
   4.399 3.270
nonbonded pdb=" CA  LYS A   7 "
          pdb=" C   PRO A   8 "
   model   vdw
   4.400 3.700
nonbonded pdb=" C   ALA A  11 "
          pdb=" CB  ALA A  55 "
   model   vdw
   4.400 3.690
nonbonded pdb=" N   ALA A  57 "
          pdb=" CZ  TYR A  61 "
   model   vdw
   4.400 3.340
nonbonded pdb=" CG  GLU A  40 "
          pdb=" N   TYR A  41 "
   model   vdw
   4.401 3.520
nonbonded pdb=" CA  PRO A   8 "
          pdb=" N   GLN A  10 "
   model   vdw
   4.401 3.550
nonbonded pdb=" CG  TYR A  61 "
          pdb=" C   VAL A  84 "
   model   vdw
   4.401 3.490
nonbonded pdb=" C   HIS A  64 "
          pdb=" OG  SER A  66 "
   model   vdw
   4.402 3.270
nonbonded pdb=" C   GLU A   5 "
          pdb=" O   TYR A  34 "
   model   vdw
   4.402 3.270
nonbonded pdb=" O   ILE A   2 "
          pdb=" CG1 ILE A   2 "
   model   vdw
   4.402 3.440
nonbonded pdb=" C   LEU A  32 "
          pdb=" CD2 LEU A  32 "
   model   vdw
   4.402 3.690
nonbonded pdb=" CA  THR A  14 "
          pdb=" OG1 THR A  15 "
   model   vdw
   4.402 3.470
nonbonded pdb=" CA  VAL A  84 "
          pdb=" C   PRO A  85 "
   model   vdw
   4.403 3.700
nonbonded pdb=" CG1 VAL A   4 "
          pdb=" CG2 VAL A  35 "
   model   vdw
   4.403 3.880
nonbonded pdb=" C   LEU A  37 "
          pdb=" O   GLY A  38 "
   model   vdw
   4.404 3.270
nonbonded pdb=" CD  GLU A  40 "
          pdb="O    HOH S  14 "
   model   vdw sym.op.
   4.404 3.270 x+1/2,y+1/2,z
nonbonded pdb=" C   ASN A  29 "
          pdb=" CB  LEU A  49 "
   model   vdw
   4.404 3.670
nonbonded pdb=" O   GLN A  10 "
          pdb=" CA  GLN A  12 "
   model   vdw
   4.404 3.470
nonbonded pdb=" O   MSE A  77 "
          pdb=" CE  MSE A  77 "
   model   vdw
   4.405 3.460
nonbonded pdb=" OE1 GLN A  53 "
          pdb=" CZ  TYR A  56 "
   model   vdw
   4.405 3.260
nonbonded pdb=" O   PHE A  68 "
          pdb=" CG  PHE A  68 "
   model   vdw
   4.405 3.260
nonbonded pdb=" C   GLU A  51 "
          pdb=" CA  GLN A  53 "
   model   vdw
   4.406 3.700
nonbonded pdb=" OG  SER A  67 "
          pdb=" N   LEU A  81 "
   model   vdw
   4.406 3.120
nonbonded pdb=" C   ASN A  29 "
          pdb=" CG  LEU A  49 "
   model   vdw
   4.406 3.700
nonbonded pdb=" N   ILE A  47 "
          pdb=" CD1 ILE A  47 "
   model   vdw
   4.406 3.540
nonbonded pdb=" O   HIS A  64 "
          pdb=" CZ  PHE A  68 "
   model   vdw
   4.406 3.340
nonbonded pdb=" N   GLU A  30 "
          pdb=" O   ILE A  47 "
   model   vdw
   4.406 3.120
nonbonded pdb=" OD1 ASP A  36 "
          pdb=" N   ASN A  39 "
   model   vdw
   4.406 3.120
nonbonded pdb=" CG  LEU A  60 "
          pdb=" N   TYR A  61 "
   model   vdw
   4.407 3.550
nonbonded pdb=" CD2 LEU A  32 "
          pdb=" CG  LEU A  44 "
   model   vdw
   4.407 3.890
nonbonded pdb=" CA  PHE A  13 "
          pdb=" O   THR A  14 "
   model   vdw
   4.407 3.470
nonbonded pdb=" CA  TYR A  61 "
          pdb=" CA  PRO A  85 "
   model   vdw
   4.409 3.900
nonbonded pdb=" CG  PHE A  13 "
          pdb=" O   THR A  14 "
   model   vdw
   4.409 3.260
nonbonded pdb=" O   ARG A  16 "
          pdb=" O   TYR A  26 "
   model   vdw
   4.410 3.040
nonbonded pdb=" C   VAL A   4 "
          pdb=" N   ILE A   6 "
   model   vdw
   4.410 3.350
nonbonded pdb=" C   LEU A  76 "
          pdb=" CD2 LEU A  76 "
   model   vdw
   4.410 3.690
nonbonded pdb=" O   SER A  17 "
          pdb=" CB  ALA A  57 "
   model   vdw sym.op.
   4.410 3.460 x,y-1,z
nonbonded pdb=" O   CYS A  33 "
          pdb=" N   LEU A  44 "
   model   vdw
   4.411 3.120
nonbonded pdb=" C   GLN A  72 "
          pdb=" CD  GLN A  72 "
   model   vdw
   4.411 3.500
nonbonded pdb=" N   ARG A  16 "
          pdb=" CD  ARG A  16 "
   model   vdw
   4.411 3.520
nonbonded pdb=" O   LEU A  44 "
          pdb=" CG2 VAL A  70 "
   model   vdw sym.op.
   4.412 3.460 -x+1,y,-z+2
nonbonded pdb=" CG2 VAL A  70 "
          pdb=" O   LEU A  44 "
   model   vdw sym.op.
   4.412 3.460 -x+1,y,-z+2
nonbonded pdb=" C   SER A  17 "
          pdb=" CD1 TYR A  26 "
   model   vdw
   4.412 3.570
nonbonded pdb=" CA  ARG A  80 "
          pdb=" C   LEU A  81 "
   model   vdw
   4.412 3.700
nonbonded pdb=" OH  TYR A  34 "
          pdb=" CG  GLU A  40 "
   model   vdw sym.op.
   4.412 3.440 -x+1,y,-z+1
nonbonded pdb=" CG  GLU A  40 "
          pdb=" OH  TYR A  34 "
   model   vdw sym.op.
   4.412 3.440 -x+1,y,-z+1
nonbonded pdb=" CD2 PHE A  68 "
          pdb=" CD1 ILE A  78 "
   model   vdw
   4.413 3.760
nonbonded pdb=" O   THR A  15 "
          pdb=" OG1 THR A  15 "
   model   vdw
   4.413 3.040
nonbonded pdb=" O   LYS A  69 "
          pdb=" CB  LEU A  76 "
   model   vdw
   4.413 3.440
nonbonded pdb=" CD1 TYR A  41 "
          pdb=" CD  PRO A  42 "
   model   vdw
   4.414 3.740
nonbonded pdb=" CG  GLN A  12 "
          pdb=" CA  PHE A  13 "
   model   vdw
   4.414 3.870
nonbonded pdb=" O   ALA A  57 "
          pdb="O    HOH S   7 "
   model   vdw
   4.415 3.040
nonbonded pdb=" CB  ILE A   6 "
          pdb=" C   ALA A  57 "
   model   vdw
   4.415 3.700
nonbonded pdb=" O   VAL A  35 "
          pdb=" CG  LEU A  37 "
   model   vdw
   4.415 3.470
nonbonded pdb=" O   TYR A  61 "
          pdb=" O   THR A  62 "
   model   vdw
   4.415 3.040
nonbonded pdb=" C   TYR A  61 "
          pdb=" OG1 THR A  62 "
   model   vdw
   4.415 3.270
nonbonded pdb=" CA  MSE A  77 "
          pdb="O    HOH S   1 "
   model   vdw sym.op.
   4.415 3.470 -x,y+1,-z+1
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" O   LEU A  32 "
   model   vdw
   4.415 3.460
nonbonded pdb=" O   THR A  14 "
          pdb=" C   GLU A  30 "
   model   vdw
   4.417 3.270
nonbonded pdb=" CB  PRO A  54 "
          pdb=" CA  ALA A  55 "
   model   vdw
   4.418 3.870
nonbonded pdb=" N   PRO A  54 "
          pdb="O    HOH S  39 "
   model   vdw
   4.418 3.120
nonbonded pdb=" O   ARG A  16 "
          pdb=" O   SER A  17 "
   model   vdw
   4.418 3.040
nonbonded pdb=" C   LEU A  65 "
          pdb=" CE1 PHE A  68 "
   model   vdw
   4.419 3.570
nonbonded pdb=" O   ILE A   2 "
          pdb=" C   THR A  62 "
   model   vdw
   4.420 3.270
nonbonded pdb=" N   GLY A  71 "
          pdb=" N   MSE A  77 "
   model   vdw
   4.420 3.200
nonbonded pdb=" CA  SER A  17 "
          pdb=" CZ  TYR A  26 "
   model   vdw
   4.420 3.690
nonbonded pdb=" CB  PRO A   8 "
          pdb=" CZ  PHE A  13 "
   model   vdw sym.op.
   4.420 3.740 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CG2 THR A  15 "
          pdb=" C   LEU A  28 "
   model   vdw
   4.420 3.690
nonbonded pdb=" N   LEU A  49 "
          pdb=" CD1 LEU A  49 "
   model   vdw
   4.421 3.540
nonbonded pdb=" CB  THR A  62 "
          pdb=" CA  VAL A  63 "
   model   vdw
   4.421 3.900
nonbonded pdb=" N   THR A  62 "
          pdb=" N   VAL A  84 "
   model   vdw
   4.422 3.200
nonbonded pdb=" N   LYS A  69 "
          pdb=" CD  LYS A  69 "
   model   vdw
   4.423 3.520
nonbonded pdb=" N   GLN A  72 "
          pdb=" CD  GLN A  72 "
   model   vdw
   4.424 3.350
nonbonded pdb=" CD1 TYR A  26 "
          pdb=" CG  PRO A  85 "
   model   vdw sym.op.
   4.424 3.740 x,y-1,z
nonbonded pdb=" CG1 ILE A  47 "
          pdb="O    HOH S   6 "
   model   vdw sym.op.
   4.425 3.440 -x+1,y,-z+2
nonbonded pdb=" CD1 ILE A  47 "
          pdb=" O   LEU A  81 "
   model   vdw
   4.426 3.460
nonbonded pdb=" O   ASP A  50 "
          pdb=" C   GLY A  52 "
   model   vdw
   4.426 3.270
nonbonded pdb=" CD  LYS A   7 "
          pdb=" CD  GLU A  40 "
   model   vdw sym.op.
   4.426 3.670 -x+1,y,-z+1
nonbonded pdb=" C   GLN A  12 "
          pdb=" CG  GLN A  31 "
   model   vdw
   4.427 3.670
nonbonded pdb=" O   LEU A  81 "
          pdb=" O   ARG A  82 "
   model   vdw
   4.427 3.040
nonbonded pdb=" CA  GLU A  40 "
          pdb=" CD2 TYR A  41 "
   model   vdw
   4.427 3.770
nonbonded pdb=" CA  ILE A   2 "
          pdb=" OG1 THR A  62 "
   model   vdw
   4.428 3.470
nonbonded pdb=" CD  PRO A   8 "
          pdb="O    HOH S  14 "
   model   vdw sym.op.
   4.428 3.440 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CD2 TYR A  61 "
          pdb=" CA  VAL A  84 "
   model   vdw
   4.428 3.770
nonbonded pdb=" CE2 TYR A  61 "
          pdb=" CA  PRO A  85 "
   model   vdw
   4.428 3.770
nonbonded pdb=" CB  TYR A  26 "
          pdb=" CA  SER A  27 "
   model   vdw
   4.429 3.870
nonbonded pdb=" C   THR A  48 "
          pdb=" NH1 ARG A  80 "
   model   vdw
   4.429 3.350
nonbonded pdb=" CB  SER A  67 "
          pdb=" C   LEU A  81 "
   model   vdw
   4.430 3.670
nonbonded pdb=" CG  TYR A  41 "
          pdb=" CD  PRO A  42 "
   model   vdw
   4.430 3.660
nonbonded pdb=" NH2 ARG A  16 "
          pdb=" C   GLY A  59 "
   model   vdw sym.op.
   4.430 3.350 x,y-1,z
nonbonded pdb=" C   ARG A  80 "
          pdb=" NH1 ARG A  82 "
   model   vdw
   4.430 3.350
nonbonded pdb=" C   LYS A   7 "
          pdb=" CD  LYS A   7 "
   model   vdw
   4.431 3.670
nonbonded pdb=" N   GLN A  31 "
          pdb=" N   ILE A  47 "
   model   vdw
   4.431 3.200
nonbonded pdb=" N   GLU A   5 "
          pdb=" O   GLY A  59 "
   model   vdw
   4.431 3.120
nonbonded pdb=" O   HIS A  64 "
          pdb=" OG  SER A  66 "
   model   vdw
   4.432 3.040
nonbonded pdb=" C   GLY A  38 "
          pdb=" OD1 ASN A  39 "
   model   vdw
   4.432 3.270
nonbonded pdb=" O   LYS A   7 "
          pdb=" OG  SER A   9 "
   model   vdw
   4.432 3.040
nonbonded pdb=" CA  LEU A  49 "
          pdb=" CD  GLN A  53 "
   model   vdw
   4.432 3.700
nonbonded pdb=" CB  GLU A  40 "
          pdb=" CA  TYR A  41 "
   model   vdw
   4.432 3.870
nonbonded pdb=" CA  THR A  15 "
          pdb=" C   LEU A  28 "
   model   vdw
   4.433 3.700
nonbonded pdb=" C   LYS A   7 "
          pdb=" OG  SER A   9 "
   model   vdw
   4.434 3.270
nonbonded pdb=" O   ASN A  29 "
          pdb=" C   LEU A  49 "
   model   vdw
   4.434 3.270
nonbonded pdb=" OG  SER A  67 "
          pdb=" N   ARG A  82 "
   model   vdw
   4.434 3.120
nonbonded pdb=" N   ALA A  11 "
          pdb=" OE1 GLN A  12 "
   model   vdw
   4.434 3.120
nonbonded pdb=" O   LEU A  28 "
          pdb=" O   ASN A  29 "
   model   vdw
   4.434 3.040
nonbonded pdb=" N   SER A  66 "
          pdb=" N   PHE A  68 "
   model   vdw
   4.435 3.200
nonbonded pdb=" C   ASP A  79 "
          pdb=" N   LEU A  81 "
   model   vdw
   4.435 3.350
nonbonded pdb=" N   TYR A  61 "
          pdb=" CE1 TYR A  61 "
   model   vdw
   4.435 3.420
nonbonded pdb=" CA  SER A  66 "
          pdb=" C   SER A  67 "
   model   vdw
   4.435 3.700
nonbonded pdb=" O   CYS A  33 "
          pdb=" CG  LEU A  44 "
   model   vdw
   4.436 3.470
nonbonded pdb=" CG2 VAL A   4 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   4.436 3.880
nonbonded pdb=" CG  LYS A   7 "
          pdb=" CD  GLN A  10 "
   model   vdw
   4.436 3.670
nonbonded pdb=" O   GLY A  71 "
          pdb=" O   SER A  75 "
   model   vdw
   4.436 3.040
nonbonded pdb=" CB  GLU A   5 "
          pdb=" CA  ILE A   6 "
   model   vdw
   4.436 3.870
nonbonded pdb=" CB  LEU A  83 "
          pdb=" CA  VAL A  84 "
   model   vdw
   4.437 3.870
nonbonded pdb=" CG2 VAL A  35 "
          pdb=" CD2 LEU A  81 "
   model   vdw
   4.437 3.880
nonbonded pdb=" CA  TYR A  41 "
          pdb=" C   PRO A  42 "
   model   vdw
   4.437 3.700
nonbonded pdb=" CB  THR A  48 "
          pdb=" CZ  ARG A  80 "
   model   vdw
   4.437 3.700
nonbonded pdb=" C   HIS A  64 "
          pdb=" CA  SER A  66 "
   model   vdw
   4.437 3.700
nonbonded pdb=" O   ASP A  79 "
          pdb=" OD2 ASP A  79 "
   model   vdw
   4.437 3.040
nonbonded pdb=" CA  THR A  15 "
          pdb=" O   ARG A  16 "
   model   vdw
   4.438 3.470
nonbonded pdb=" O   LEU A  60 "
          pdb=" CE1 TYR A  61 "
   model   vdw
   4.438 3.340
nonbonded pdb=" O   LEU A  76 "
          pdb=" CG1 ILE A  78 "
   model   vdw sym.op.
   4.438 3.440 -x+1,y,-z+2
nonbonded pdb=" CD  GLN A  31 "
          pdb=" O   LEU A  32 "
   model   vdw
   4.439 3.270
nonbonded pdb=" CD  LYS A   3 "
          pdb=" CB  ASP A  36 "
   model   vdw
   4.440 3.840
nonbonded pdb=" CG2 ILE A  78 "
          pdb=" CD1 LEU A  81 "
   model   vdw
   4.440 3.880
nonbonded pdb=" C   LYS A  69 "
          pdb=" CD  LYS A  69 "
   model   vdw
   4.441 3.670
nonbonded pdb=" C   PHE A  13 "
          pdb=" N   THR A  15 "
   model   vdw
   4.441 3.350
nonbonded pdb=" OG  SER A  67 "
          pdb=" CA  PHE A  68 "
   model   vdw
   4.442 3.470
nonbonded pdb=" CG  GLU A   5 "
          pdb=" N   LYS A   7 "
   model   vdw
   4.442 3.520
nonbonded pdb=" O   THR A  15 "
          pdb=" C   PRO A   8 "
   model   vdw sym.op.
   4.442 3.270 -x+1/2,y-1/2,-z+1
nonbonded pdb=" C   PRO A   8 "
          pdb=" O   THR A  15 "
   model   vdw sym.op.
   4.442 3.270 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CA  GLU A   5 "
          pdb=" C   ILE A   6 "
   model   vdw
   4.442 3.700
nonbonded pdb=" CD1 ILE A   2 "
          pdb=" CD2 LEU A  37 "
   model   vdw
   4.443 3.880
nonbonded pdb=" C   GLN A  72 "
          pdb=" CD1 PHE A  73 "
   model   vdw
   4.443 3.570
nonbonded pdb=" CA  LEU A  65 "
          pdb=" C   SER A  66 "
   model   vdw
   4.443 3.700
nonbonded pdb=" O   VAL A  35 "
          pdb=" CB  VAL A  43 "
   model   vdw
   4.443 3.470
nonbonded pdb=" CB  PHE A  13 "
          pdb=" CB  ALA A  55 "
   model   vdw
   4.444 3.860
nonbonded pdb=" CB  SER A  75 "
          pdb=" CA  LEU A  76 "
   model   vdw
   4.444 3.870
nonbonded pdb=" N   TYR A  34 "
          pdb=" CE1 TYR A  34 "
   model   vdw
   4.444 3.420
nonbonded pdb=" CA  GLN A  72 "
          pdb=" N   GLY A  74 "
   model   vdw
   4.445 3.550
nonbonded pdb=" CA  PRO A   8 "
          pdb="O    HOH S  14 "
   model   vdw sym.op.
   4.445 3.470 -x+1/2,y+1/2,-z+1
nonbonded pdb=" O   SER A  66 "
          pdb=" CA  PHE A  68 "
   model   vdw
   4.445 3.470
nonbonded pdb=" N   LYS A  69 "
          pdb=" CD1 LEU A  76 "
   model   vdw
   4.445 3.540
nonbonded pdb=" CA  LEU A  37 "
          pdb=" CD1 LEU A  65 "
   model   vdw sym.op.
   4.446 3.890 -x+1,y,-z+2
nonbonded pdb=" CB  HIS A  64 "
          pdb=" CB  ARG A  82 "
   model   vdw
   4.446 3.840
nonbonded pdb=" OG  SER A  75 "
          pdb=" O   LEU A  76 "
   model   vdw
   4.448 3.040
nonbonded pdb=" N   TYR A  26 "
          pdb=" CD1 TYR A  26 "
   model   vdw
   4.448 3.420
nonbonded pdb=" CA  GLU A   5 "
          pdb=" C   GLY A  59 "
   model   vdw
   4.448 3.700
nonbonded pdb=" CG  LYS A   7 "
          pdb=" CD  GLU A  40 "
   model   vdw sym.op.
   4.449 3.670 -x+1,y,-z+1
nonbonded pdb=" NE2 GLN A  10 "
          pdb=" OH  TYR A  34 "
   model   vdw
   4.449 3.120
nonbonded pdb=" CD1 TYR A  56 "
          pdb=" OH  TYR A  61 "
   model   vdw
   4.449 3.340
nonbonded pdb=" CB  TYR A  41 "
          pdb=" CA  PRO A  42 "
   model   vdw
   4.449 3.870
nonbonded pdb=" NH2 ARG A  16 "
          pdb=" CG  PRO A  85 "
   model   vdw sym.op.
   4.449 3.520 x,y-1,z
nonbonded pdb=" CG  LYS A   7 "
          pdb=" N   PRO A   8 "
   model   vdw
   4.450 3.520
nonbonded pdb=" CG  LYS A   7 "
          pdb=" OE2 GLU A  40 "
   model   vdw sym.op.
   4.450 3.440 -x+1,y,-z+1
nonbonded pdb=" OE1 GLN A  31 "
          pdb=" CD1 LEU A  49 "
   model   vdw
   4.450 3.460
nonbonded pdb=" C   GLN A  12 "
          pdb=" CD2 PHE A  13 "
   model   vdw
   4.451 3.570
nonbonded pdb=" C   GLY A  71 "
          pdb=" CA  PHE A  73 "
   model   vdw
   4.451 3.700
nonbonded pdb=" CG2 THR A  62 "
          pdb=" CA  VAL A  63 "
   model   vdw
   4.451 3.890
nonbonded pdb=" CG  GLN A  31 "
          pdb=" C   LEU A  32 "
   model   vdw
   4.452 3.670
nonbonded pdb=" CB  SER A  17 "
          pdb=" CB  SER A  27 "
   model   vdw
   4.453 3.840
nonbonded pdb=" CG  TYR A  34 "
          pdb=" C   VAL A  43 "
   model   vdw
   4.453 3.490
nonbonded pdb=" CB  GLN A  31 "
          pdb=" O   LEU A  32 "
   model   vdw
   4.453 3.440
nonbonded pdb=" SG  CYS A  33 "
          pdb=" CA  VAL A  45 "
   model   vdw
   4.453 3.830
nonbonded pdb=" CG  ASP A  79 "
          pdb=" CB  ARG A  80 "
   model   vdw
   4.454 3.670
nonbonded pdb=" C   SER A  66 "
          pdb=" CA  PHE A  68 "
   model   vdw
   4.454 3.700
nonbonded pdb=" C   VAL A  35 "
          pdb=" CG2 VAL A  43 "
   model   vdw
   4.454 3.690
nonbonded pdb=" CA  GLU A  30 "
          pdb=" C   ILE A  47 "
   model   vdw
   4.454 3.700
nonbonded pdb=" CB  CYS A  33 "
          pdb=" CD1 ILE A  47 "
   model   vdw
   4.454 3.860
nonbonded pdb=" CA  LEU A  60 "
          pdb=" CG  TYR A  61 "
   model   vdw
   4.454 3.690
nonbonded pdb=" CE2 TYR A  34 "
          pdb=" C   VAL A  43 "
   model   vdw
   4.454 3.570
nonbonded pdb=" O   LEU A  49 "
          pdb=" CG  ASP A  50 "
   model   vdw
   4.454 3.270
nonbonded pdb=" CA  SER A  67 "
          pdb=" CG  PHE A  68 "
   model   vdw
   4.454 3.690
nonbonded pdb=" C   GLU A  40 "
          pdb=" CE2 TYR A  41 "
   model   vdw
   4.454 3.570
nonbonded pdb=" C   LYS A   7 "
          pdb="O    HOH S  12 "
   model   vdw
   4.455 3.270
nonbonded pdb=" O   ALA A  11 "
          pdb=" NE2 GLN A  31 "
   model   vdw
   4.456 3.120
nonbonded pdb=" CD1 LEU A  60 "
          pdb=" CD1 PHE A  73 "
   model   vdw sym.op.
   4.456 3.760 -x+1,y+1,-z+2
nonbonded pdb=" C   PHE A  73 "
          pdb=" O   GLY A  74 "
   model   vdw
   4.457 3.270
nonbonded pdb=" O   SER A  67 "
          pdb=" O   MSE A  77 "
   model   vdw
   4.457 3.040
nonbonded pdb=" O   LEU A  37 "
          pdb=" CG  LEU A  65 "
   model   vdw sym.op.
   4.457 3.470 -x+1,y,-z+2
nonbonded pdb=" O   THR A  14 "
          pdb=" CG  ASN A  29 "
   model   vdw
   4.457 3.270
nonbonded pdb=" CZ  TYR A  26 "
          pdb=" CB  PRO A  85 "
   model   vdw sym.op.
   4.457 3.660 x,y-1,z
nonbonded pdb=" NH1 ARG A  16 "
          pdb=" CB  LEU A  60 "
   model   vdw sym.op.
   4.458 3.520 x,y-1,z
nonbonded pdb=" CA  THR A  15 "
          pdb=" C   ARG A  16 "
   model   vdw
   4.458 3.700
nonbonded pdb=" OD1 ASP A  50 "
          pdb=" N   GLU A  51 "
   model   vdw
   4.458 3.120
nonbonded pdb=" O   ARG A  80 "
          pdb=" CG  ARG A  80 "
   model   vdw
   4.458 3.440
nonbonded pdb=" CB  TYR A  34 "
          pdb=" CG  PRO A  42 "
   model   vdw
   4.459 3.840
nonbonded pdb=" CG1 VAL A  45 "
          pdb=" CD2 LEU A  81 "
   model   vdw
   4.460 3.880
nonbonded pdb=" CG2 VAL A   4 "
          pdb=" CD2 LEU A  81 "
   model   vdw
   4.460 3.880
nonbonded pdb=" CG1 ILE A   2 "
          pdb=" CE1 PHE A  68 "
   model   vdw sym.op.
   4.460 3.740 -x+1,y,-z+2
nonbonded pdb=" CE1 PHE A  68 "
          pdb=" CG1 ILE A   2 "
   model   vdw sym.op.
   4.460 3.740 -x+1,y,-z+2
nonbonded pdb=" CA  GLN A  53 "
          pdb=" C   PRO A  54 "
   model   vdw
   4.461 3.700
nonbonded pdb=" O   PRO A   8 "
          pdb=" CG  PRO A  58 "
   model   vdw
   4.461 3.440
nonbonded pdb=" C   GLN A  12 "
          pdb=" N   THR A  14 "
   model   vdw
   4.461 3.350
nonbonded pdb=" C   LEU A  83 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   4.461 3.690
nonbonded pdb=" CD1 LEU A  49 "
          pdb=" CG  GLN A  53 "
   model   vdw
   4.461 3.860
nonbonded pdb=" CG2 VAL A  43 "
          pdb=" CG2 VAL A  45 "
   model   vdw
   4.461 3.880
nonbonded pdb=" O   ALA A  57 "
          pdb=" CG  PRO A  58 "
   model   vdw
   4.461 3.440
nonbonded pdb=" CD1 TYR A  34 "
          pdb=" OH  TYR A  41 "
   model   vdw sym.op.
   4.461 3.340 -x+1,y,-z+1
nonbonded pdb=" OH  TYR A  41 "
          pdb=" CD1 TYR A  34 "
   model   vdw sym.op.
   4.461 3.340 -x+1,y,-z+1
nonbonded pdb=" CD1 LEU A  37 "
          pdb=" N   LYS A  69 "
   model   vdw sym.op.
   4.463 3.540 -x+1,y,-z+2
nonbonded pdb=" CD  LYS A   3 "
          pdb=" CD2 LEU A  60 "
   model   vdw
   4.463 3.860
nonbonded pdb=" CA  LYS A  69 "
          pdb=" C   VAL A  70 "
   model   vdw
   4.464 3.700
nonbonded pdb=" CB  VAL A   4 "
          pdb=" CG2 VAL A  35 "
   model   vdw
   4.464 3.890
nonbonded pdb=" OH  TYR A  56 "
          pdb=" C   LEU A  83 "
   model   vdw
   4.464 3.270
nonbonded pdb=" N   SER A   9 "
          pdb=" O   THR A  15 "
   model   vdw sym.op.
   4.464 3.120 -x+1/2,y+1/2,-z+1
nonbonded pdb=" O   THR A  15 "
          pdb=" N   SER A   9 "
   model   vdw sym.op.
   4.464 3.120 -x+1/2,y-1/2,-z+1
nonbonded pdb=" CB  VAL A   4 "
          pdb=" C   TYR A  61 "
   model   vdw
   4.464 3.700
nonbonded pdb=" NZ  LYS A  46 "
          pdb=" O   PHE A  73 "
   model   vdw sym.op.
   4.465 3.120 -x+1,y,-z+2
nonbonded pdb=" CB  VAL A  63 "
          pdb=" O   ARG A  82 "
   model   vdw
   4.465 3.470
nonbonded pdb=" N   LEU A  83 "
          pdb=" CD1 LEU A  83 "
   model   vdw
   4.465 3.540
nonbonded pdb=" CZ  TYR A  41 "
          pdb=" CG  TYR A  34 "
   model   vdw sym.op.
   4.466 3.480 -x+1,y,-z+1
nonbonded pdb=" CG  TYR A  34 "
          pdb=" CZ  TYR A  41 "
   model   vdw sym.op.
   4.466 3.480 -x+1,y,-z+1
nonbonded pdb=" C   ARG A  16 "
          pdb=" CD  ARG A  16 "
   model   vdw
   4.467 3.670
nonbonded pdb=" C   SER A  67 "
          pdb=" N   ARG A  80 "
   model   vdw
   4.467 3.350
nonbonded pdb=" O   PHE A  73 "
          pdb=" O   GLY A  74 "
   model   vdw
   4.467 3.040
nonbonded pdb=" CA  LYS A   7 "
          pdb=" N   GLN A  10 "
   model   vdw
   4.468 3.550
nonbonded pdb=" O   ARG A  16 "
          pdb=" CD1 TYR A  26 "
   model   vdw
   4.468 3.340
nonbonded pdb=" CA  GLN A  12 "
          pdb=" CB  ALA A  55 "
   model   vdw
   4.468 3.890
nonbonded pdb=" CB  SER A  67 "
          pdb=" CB  ARG A  82 "
   model   vdw
   4.468 3.840
nonbonded pdb=" NE2 GLN A  31 "
          pdb=" CA  ALA A  55 "
   model   vdw
   4.469 3.550
nonbonded pdb=" C   ILE A  78 "
          pdb="O    HOH S  13 "
   model   vdw
   4.469 3.270
nonbonded pdb=" C   LEU A  49 "
          pdb=" CD2 LEU A  49 "
   model   vdw
   4.469 3.690
nonbonded pdb="O    HOH S  13 "
          pdb=" C   ILE A  78 "
   model   vdw sym.op.
   4.469 3.270 -x+1,y,-z+2
nonbonded pdb=" C   ILE A  78 "
          pdb="O    HOH S  13 "
   model   vdw sym.op.
   4.469 3.270 -x+1,y,-z+2
nonbonded pdb=" CB  SER A  67 "
          pdb=" CZ  PHE A  68 "
   model   vdw
   4.469 3.740
nonbonded pdb=" OE1 GLN A  31 "
          pdb=" C   TYR A  56 "
   model   vdw
   4.469 3.270
nonbonded pdb=" C   ASP A  50 "
          pdb=" CG  GLN A  53 "
   model   vdw
   4.471 3.670
nonbonded pdb=" O   THR A  15 "
          pdb=" N   SER A  17 "
   model   vdw
   4.471 3.120
nonbonded pdb=" CD1 ILE A   6 "
          pdb=" CG  GLN A  31 "
   model   vdw
   4.471 3.860
nonbonded pdb=" O   GLU A  51 "
          pdb=" CA  GLN A  53 "
   model   vdw
   4.471 3.470
nonbonded pdb=" O   TYR A  56 "
          pdb=" CG  TYR A  56 "
   model   vdw
   4.472 3.260
nonbonded pdb=" O   LYS A   7 "
          pdb=" O   GLN A  10 "
   model   vdw
   4.472 3.040
nonbonded pdb=" CA  TYR A  34 "
          pdb=" CB  PRO A  42 "
   model   vdw
   4.472 3.870
nonbonded pdb=" N   GLU A   5 "
          pdb=" N   TYR A  34 "
   model   vdw
   4.473 3.200
nonbonded pdb=" O   VAL A  43 "
          pdb=" CA  VAL A  45 "
   model   vdw
   4.473 3.470
nonbonded pdb=" O   ASN A  29 "
          pdb=" CD1 LEU A  49 "
   model   vdw
   4.473 3.460
nonbonded pdb=" CG2 ILE A  78 "
          pdb=" O   ASP A  79 "
   model   vdw
   4.473 3.460
nonbonded pdb=" CA  GLN A  53 "
          pdb=" NE2 GLN A  53 "
   model   vdw
   4.473 3.550
nonbonded pdb=" N   GLY A  71 "
          pdb=" CB  MSE A  77 "
   model   vdw
   4.473 3.520
nonbonded pdb=" N   LYS A  46 "
          pdb=" CA  SER A  75 "
   model   vdw sym.op.
   4.474 3.550 -x+1,y,-z+2
nonbonded pdb=" CB  THR A  14 "
          pdb=" O   GLU A  30 "
   model   vdw
   4.474 3.470
nonbonded pdb=" OG1 THR A  62 "
          pdb=" O   VAL A  63 "
   model   vdw
   4.474 3.040
nonbonded pdb=" CB  SER A  67 "
          pdb=" CG  PHE A  68 "
   model   vdw
   4.474 3.660
nonbonded pdb=" C   THR A  14 "
          pdb=" CA  ASN A  29 "
   model   vdw
   4.475 3.700
nonbonded pdb=" CB  TYR A  34 "
          pdb=" C   VAL A  43 "
   model   vdw
   4.475 3.670
nonbonded pdb=" CD2 TYR A  56 "
          pdb="O    HOH S  39 "
   model   vdw
   4.475 3.340
nonbonded pdb=" CA  PHE A  68 "
          pdb=" N   ASP A  79 "
   model   vdw
   4.475 3.550
nonbonded pdb=" CB  ILE A   2 "
          pdb=" CB  VAL A  63 "
   model   vdw
   4.475 3.900
nonbonded pdb=" CD  GLN A  31 "
          pdb=" CD2 TYR A  56 "
   model   vdw
   4.476 3.570
nonbonded pdb=" CD  GLN A  31 "
          pdb=" C   ALA A  55 "
   model   vdw
   4.476 3.500
nonbonded pdb=" C   ILE A   2 "
          pdb=" CZ  PHE A  73 "
   model   vdw sym.op.
   4.476 3.570 -x+1,y+1,-z+2
nonbonded pdb=" C   SER A  67 "
          pdb=" CG2 ILE A  78 "
   model   vdw
   4.477 3.690
nonbonded pdb=" C   LEU A  44 "
          pdb=" CD2 LEU A  44 "
   model   vdw
   4.477 3.690
nonbonded pdb=" OG  SER A  17 "
          pdb=" O   TYR A  26 "
   model   vdw
   4.477 3.040
nonbonded pdb=" CB  GLN A  31 "
          pdb=" CA  LEU A  32 "
   model   vdw
   4.477 3.870
nonbonded pdb=" O   ARG A  16 "
          pdb=" OG  SER A  27 "
   model   vdw
   4.478 3.040
nonbonded pdb=" CD  LYS A  46 "
          pdb="O    HOH S  38 "
   model   vdw
   4.478 3.440
nonbonded pdb=" NE2 GLN A  12 "
          pdb="O    HOH S  23 "
   model   vdw
   4.478 3.120
nonbonded pdb=" C   ALA A  57 "
          pdb=" CE1 TYR A  61 "
   model   vdw
   4.479 3.570
nonbonded pdb=" CE2 TYR A  41 "
          pdb=" CG  PRO A  42 "
   model   vdw sym.op.
   4.479 3.740 -x+1,y,-z+1
nonbonded pdb=" CG  LYS A  46 "
          pdb=" CA  ILE A  47 "
   model   vdw
   4.479 3.870
nonbonded pdb=" CG2 THR A  62 "
          pdb=" C   VAL A  63 "
   model   vdw
   4.480 3.690
nonbonded pdb=" O   TYR A  41 "
          pdb=" CG  PRO A  42 "
   model   vdw
   4.480 3.440
nonbonded pdb=" CA  GLU A  40 "
          pdb=" OE2 GLU A  40 "
   model   vdw
   4.481 3.470
nonbonded pdb=" O   LEU A  76 "
          pdb=" O   MSE A  77 "
   model   vdw
   4.481 3.040
nonbonded pdb=" CD  GLN A  31 "
          pdb=" CA  TYR A  56 "
   model   vdw
   4.481 3.700
nonbonded pdb=" C   LEU A  44 "
          pdb=" N   LYS A  46 "
   model   vdw
   4.482 3.350
nonbonded pdb=" C   VAL A  35 "
          pdb=" O   VAL A  43 "
   model   vdw
   4.482 3.270
nonbonded pdb=" CE1 TYR A  26 "
          pdb=" CB  PRO A  85 "
   model   vdw sym.op.
   4.482 3.740 x,y-1,z
nonbonded pdb=" CG  TYR A  41 "
          pdb=" N   PRO A  42 "
   model   vdw
   4.482 3.340
nonbonded pdb=" CD2 LEU A  37 "
          pdb=" CD1 LEU A  76 "
   model   vdw sym.op.
   4.483 3.880 -x+1,y,-z+2
nonbonded pdb=" CD1 LEU A  76 "
          pdb=" CD2 LEU A  37 "
   model   vdw sym.op.
   4.483 3.880 -x+1,y,-z+2
nonbonded pdb=" O   LYS A  46 "
          pdb=" CD  LYS A  46 "
   model   vdw
   4.483 3.440
nonbonded pdb=" CA  MSE A  77 "
          pdb=" C   ILE A  78 "
   model   vdw
   4.483 3.700
nonbonded pdb=" C   GLN A  31 "
          pdb=" N   CYS A  33 "
   model   vdw
   4.483 3.350
nonbonded pdb=" CB  VAL A  70 "
          pdb=" O   GLY A  71 "
   model   vdw
   4.483 3.470
nonbonded pdb=" O   GLN A  10 "
          pdb=" C   GLN A  12 "
   model   vdw
   4.484 3.270
nonbonded pdb=" O   LYS A  46 "
          pdb=" O   ILE A  47 "
   model   vdw
   4.484 3.040
nonbonded pdb=" CB  LEU A  32 "
          pdb=" CD1 LEU A  44 "
   model   vdw
   4.484 3.860
nonbonded pdb=" CG  GLU A  30 "
          pdb=" OG1 THR A  48 "
   model   vdw
   4.484 3.440
nonbonded pdb=" C   ALA A  57 "
          pdb="O    HOH S   7 "
   model   vdw
   4.484 3.270
nonbonded pdb=" CZ  PHE A  73 "
          pdb="O    HOH S  30 "
   model   vdw sym.op.
   4.485 3.340 -x+1,y-1,-z+2
nonbonded pdb=" OE1 GLN A  31 "
          pdb=" CE2 TYR A  56 "
   model   vdw
   4.485 3.340
nonbonded pdb=" CB  SER A  17 "
          pdb=" C   TYR A  26 "
   model   vdw
   4.486 3.670
nonbonded pdb=" O   ASP A  50 "
          pdb=" C   GLN A  53 "
   model   vdw
   4.486 3.270
nonbonded pdb=" CD1 LEU A  49 "
          pdb=" CB  ALA A  55 "
   model   vdw
   4.486 3.880
nonbonded pdb=" N   ARG A  80 "
          pdb=" CZ  ARG A  82 "
   model   vdw
   4.487 3.350
nonbonded pdb=" N   GLU A   5 "
          pdb=" CD2 LEU A  60 "
   model   vdw
   4.487 3.540
nonbonded pdb=" CA  GLN A  53 "
          pdb="O    HOH S  20 "
   model   vdw
   4.487 3.470
nonbonded pdb=" C   GLU A   5 "
          pdb=" CB  CYS A  33 "
   model   vdw
   4.487 3.670
nonbonded pdb=" CB  ALA A  11 "
          pdb=" CB  THR A  14 "
   model   vdw sym.op.
   4.488 3.890 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CD1 LEU A  37 "
          pdb=" N   VAL A  70 "
   model   vdw sym.op.
   4.489 3.540 -x+1,y,-z+2
nonbonded pdb=" CB  LEU A  60 "
          pdb=" CD1 PHE A  73 "
   model   vdw sym.op.
   4.489 3.740 -x+1,y+1,-z+2
nonbonded pdb=" CD2 PHE A  13 "
          pdb=" CA  ALA A  55 "
   model   vdw
   4.489 3.770
nonbonded pdb=" CG1 VAL A   4 "
          pdb=" C   GLU A   5 "
   model   vdw
   4.489 3.690
nonbonded pdb=" O   GLY A  59 "
          pdb=" O   LEU A  60 "
   model   vdw
   4.489 3.040
nonbonded pdb=" N   LEU A  65 "
          pdb=" CE1 PHE A  68 "
   model   vdw
   4.489 3.420
nonbonded pdb=" CG  LYS A   3 "
          pdb=" CA  VAL A   4 "
   model   vdw
   4.490 3.870
nonbonded pdb=" CB  VAL A  35 "
          pdb=" O   VAL A  43 "
   model   vdw
   4.491 3.470
nonbonded pdb=" C   LYS A   7 "
          pdb=" CA  GLN A  10 "
   model   vdw
   4.491 3.700
nonbonded pdb=" CG2 VAL A  70 "
          pdb=" CD1 LEU A  76 "
   model   vdw
   4.491 3.880
nonbonded pdb=" O   PHE A  68 "
          pdb=" O   LYS A  69 "
   model   vdw
   4.492 3.040
nonbonded pdb=" CE1 HIS A  64 "
          pdb=" CA  SER A  66 "
   model   vdw
   4.492 3.690
nonbonded pdb=" CA  ASP A  50 "
          pdb=" C   GLU A  51 "
   model   vdw
   4.492 3.700
nonbonded pdb=" CB  ALA A  55 "
          pdb=" CA  TYR A  56 "
   model   vdw
   4.492 3.890
nonbonded pdb=" C   SER A  66 "
          pdb=" O   PHE A  68 "
   model   vdw
   4.492 3.270
nonbonded pdb=" CA  HIS A  64 "
          pdb=" NE2 HIS A  64 "
   model   vdw
   4.493 3.550
nonbonded pdb=" C   GLY A  74 "
          pdb="O    HOH S   3 "
   model   vdw
   4.493 3.270
nonbonded pdb=" O   ILE A   6 "
          pdb=" N   PRO A  58 "
   model   vdw
   4.493 3.120
nonbonded pdb=" C   LEU A  76 "
          pdb="O    HOH S   6 "
   model   vdw
   4.494 3.270
nonbonded pdb=" C   LEU A  83 "
          pdb=" N   PRO A  85 "
   model   vdw
   4.494 3.350
nonbonded pdb=" CE2 TYR A  41 "
          pdb=" OH  TYR A  34 "
   model   vdw sym.op.
   4.494 3.340 -x+1,y,-z+1
nonbonded pdb=" OH  TYR A  34 "
          pdb=" CE2 TYR A  41 "
   model   vdw sym.op.
   4.494 3.340 -x+1,y,-z+1
nonbonded pdb=" C   GLN A  10 "
          pdb=" CG  GLN A  31 "
   model   vdw
   4.495 3.670
nonbonded pdb=" CG1 VAL A  84 "
          pdb=" N   PRO A  85 "
   model   vdw
   4.495 3.540
nonbonded pdb=" CD2 LEU A  49 "
          pdb=" CZ  TYR A  56 "
   model   vdw
   4.495 3.680
nonbonded pdb=" O   THR A  15 "
          pdb=" O   ARG A  16 "
   model   vdw
   4.496 3.040
nonbonded pdb=" CA  GLU A  51 "
          pdb=" C   GLY A  52 "
   model   vdw
   4.496 3.700
nonbonded pdb=" C   PRO A   8 "
          pdb="O    HOH S  14 "
   model   vdw sym.op.
   4.496 3.270 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CE2 TYR A  26 "
          pdb=" CD  PRO A  85 "
   model   vdw sym.op.
   4.496 3.740 x,y-1,z
nonbonded pdb=" CB  TYR A  56 "
          pdb=" CA  ALA A  57 "
   model   vdw
   4.496 3.870
nonbonded pdb=" OG  SER A  27 "
          pdb=" C   LEU A  28 "
   model   vdw
   4.497 3.270
nonbonded pdb=" CB  TYR A  56 "
          pdb=" CE2 TYR A  61 "
   model   vdw
   4.497 3.740
nonbonded pdb=" C   SER A  67 "
          pdb=" NH1 ARG A  82 "
   model   vdw
   4.498 3.350
nonbonded pdb=" CG2 ILE A   2 "
          pdb=" N   VAL A  63 "
   model   vdw
   4.498 3.540
nonbonded pdb=" N   SER A  17 "
          pdb=" CE1 TYR A  26 "
   model   vdw
   4.499 3.420
nonbonded pdb=" CG  LYS A  69 "
          pdb=" N   ASP A  79 "
   model   vdw
   4.499 3.520
nonbonded pdb=" OG  SER A   9 "
          pdb=" CD  GLN A  10 "
   model   vdw
   4.499 3.270
nonbonded pdb=" CG2 ILE A   2 "
          pdb=" CG1 VAL A  35 "
   model   vdw
   4.499 3.880
nonbonded pdb=" CA  ASP A  36 "
          pdb=" N   GLY A  38 "
   model   vdw
   4.500 3.550
nonbonded pdb=" CD  LYS A   3 "
          pdb=" OD2 ASP A  36 "
   model   vdw
   4.501 3.440
nonbonded pdb=" O   VAL A  35 "
          pdb=" C   VAL A  43 "
   model   vdw
   4.501 3.270
nonbonded pdb=" CA  GLN A  10 "
          pdb=" CD  GLN A  12 "
   model   vdw
   4.501 3.700
nonbonded pdb=" C   ARG A  80 "
          pdb=" CG  ARG A  82 "
   model   vdw
   4.501 3.670
nonbonded pdb=" N   THR A  48 "
          pdb=" CA  LEU A  49 "
   model   vdw
   4.502 3.550
nonbonded pdb=" NE2 GLN A  72 "
          pdb=" CB  LYS A   3 "
   model   vdw sym.op.
   4.502 3.520 -x+1,y-1,-z+2
nonbonded pdb=" CB  LYS A   3 "
          pdb=" NE2 GLN A  72 "
   model   vdw sym.op.
   4.502 3.520 -x+1,y+1,-z+2
nonbonded pdb=" CA  TYR A  61 "
          pdb=" O   THR A  62 "
   model   vdw
   4.502 3.470
nonbonded pdb=" C   GLY A  38 "
          pdb=" N   GLU A  40 "
   model   vdw
   4.502 3.350
nonbonded pdb=" CA  ASN A  39 "
          pdb=" O   TYR A  41 "
   model   vdw
   4.503 3.470
nonbonded pdb=" CD1 ILE A   6 "
          pdb=" CD2 TYR A  56 "
   model   vdw
   4.503 3.760
nonbonded pdb=" CG  ARG A  80 "
          pdb=" NH2 ARG A  82 "
   model   vdw
   4.503 3.520
nonbonded pdb=" CA  ILE A   6 "
          pdb=" C   LYS A   7 "
   model   vdw
   4.503 3.700
nonbonded pdb=" O   ILE A  78 "
          pdb=" CG1 ILE A  78 "
   model   vdw
   4.503 3.440
nonbonded pdb=" O   PRO A  54 "
          pdb=" CA  TYR A  56 "
   model   vdw
   4.503 3.470
nonbonded pdb=" CB  ILE A   6 "
          pdb=" N   PRO A  58 "
   model   vdw
   4.503 3.550
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" N   ALA A  11 "
   model   vdw
   4.504 3.540
nonbonded pdb=" CB  LEU A  76 "
          pdb=" CD1 LEU A  81 "
   model   vdw sym.op.
   4.504 3.860 -x+1,y,-z+2
nonbonded pdb=" N   PHE A  13 "
          pdb=" CE2 PHE A  13 "
   model   vdw
   4.504 3.420
nonbonded pdb=" CA  ILE A  78 "
          pdb=" C   ASP A  79 "
   model   vdw
   4.504 3.700
nonbonded pdb=" C   ALA A  11 "
          pdb=" N   PHE A  13 "
   model   vdw
   4.504 3.350
nonbonded pdb=" CA  LEU A  28 "
          pdb=" OD1 ASN A  29 "
   model   vdw
   4.505 3.470
nonbonded pdb=" CA  ASP A  79 "
          pdb=" CB  ARG A  80 "
   model   vdw
   4.505 3.870
nonbonded pdb=" CA  LEU A  60 "
          pdb=" CB  TYR A  61 "
   model   vdw
   4.506 3.870
nonbonded pdb=" C   SER A  67 "
          pdb=" CA  ILE A  78 "
   model   vdw
   4.506 3.700
nonbonded pdb=" O   GLN A  31 "
          pdb=" N   CYS A  33 "
   model   vdw
   4.506 3.120
nonbonded pdb=" O   GLU A  51 "
          pdb=" CB  GLN A  53 "
   model   vdw
   4.506 3.440
nonbonded pdb=" N   ILE A   6 "
          pdb=" CA  LYS A   7 "
   model   vdw
   4.506 3.550
nonbonded pdb=" CB  GLU A  40 "
          pdb=" CG  TYR A  41 "
   model   vdw
   4.506 3.660
nonbonded pdb=" CB  PHE A  68 "
          pdb=" CD2 LEU A  76 "
   model   vdw
   4.507 3.860
nonbonded pdb=" CB  SER A   9 "
          pdb=" O   THR A  15 "
   model   vdw sym.op.
   4.507 3.440 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CG  GLN A  72 "
          pdb=" CG  PHE A  73 "
   model   vdw
   4.507 3.660
nonbonded pdb=" C   SER A   9 "
          pdb=" O   GLN A  10 "
   model   vdw
   4.508 3.270
nonbonded pdb=" CG  GLU A   5 "
          pdb=" CD  LYS A   7 "
   model   vdw
   4.508 3.840
nonbonded pdb=" C   THR A  14 "
          pdb=" O   GLU A  30 "
   model   vdw
   4.508 3.270
nonbonded pdb=" N   LEU A  37 "
          pdb=" CD1 LEU A  37 "
   model   vdw
   4.509 3.540
nonbonded pdb=" CA  VAL A  63 "
          pdb=" O   HIS A  64 "
   model   vdw
   4.510 3.470
nonbonded pdb=" CA  SER A  67 "
          pdb=" N   ARG A  82 "
   model   vdw
   4.510 3.550
nonbonded pdb=" CG  LEU A  28 "
          pdb=" NH2 ARG A  80 "
   model   vdw
   4.511 3.550
nonbonded pdb=" C   HIS A  64 "
          pdb=" CE1 HIS A  64 "
   model   vdw
   4.511 3.490
nonbonded pdb=" CD2 TYR A  61 "
          pdb=" CD1 LEU A  83 "
   model   vdw
   4.511 3.760
nonbonded pdb=" O   GLN A  72 "
          pdb=" CD2 PHE A  73 "
   model   vdw
   4.512 3.340
nonbonded pdb=" CG  TYR A  56 "
          pdb=" CZ  TYR A  61 "
   model   vdw
   4.512 3.480
nonbonded pdb=" N   PHE A  73 "
          pdb=" N   SER A  75 "
   model   vdw
   4.513 3.200
nonbonded pdb=" CE  MSE A  77 "
          pdb=" C   ILE A  78 "
   model   vdw
   4.513 3.690
nonbonded pdb=" N   ASP A  36 "
          pdb=" CB  PRO A  42 "
   model   vdw
   4.513 3.520
nonbonded pdb=" CG  LYS A   3 "
          pdb=" O   VAL A   4 "
   model   vdw
   4.514 3.440
nonbonded pdb=" CG  ASP A  50 "
          pdb=" OE1 GLU A  51 "
   model   vdw
   4.514 3.270
nonbonded pdb=" C   THR A  62 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   4.514 3.690
nonbonded pdb=" CA  SER A  75 "
          pdb=" C   LEU A  76 "
   model   vdw
   4.514 3.700
nonbonded pdb=" CB  LEU A  49 "
          pdb=" C   ASP A  50 "
   model   vdw
   4.515 3.670
nonbonded pdb=" NE2 GLN A  10 "
          pdb=" CG  TYR A  34 "
   model   vdw
   4.515 3.340
nonbonded pdb=" CB  TYR A  56 "
          pdb="O    HOH S  39 "
   model   vdw
   4.515 3.440
nonbonded pdb=" CG2 VAL A  63 "
          pdb=" N   HIS A  64 "
   model   vdw
   4.516 3.540
nonbonded pdb=" CB  PRO A   8 "
          pdb=" CB  THR A  15 "
   model   vdw sym.op.
   4.516 3.870 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CB  VAL A  43 "
          pdb=" C   LEU A  44 "
   model   vdw
   4.516 3.700
nonbonded pdb=" CG  LEU A  49 "
          pdb=" N   ASP A  50 "
   model   vdw
   4.516 3.550
nonbonded pdb=" C   LYS A   3 "
          pdb=" O   TYR A  34 "
   model   vdw
   4.516 3.270
nonbonded pdb=" CA  HIS A  64 "
          pdb=" CE1 HIS A  64 "
   model   vdw
   4.516 3.690
nonbonded pdb=" CB  GLU A  30 "
          pdb=" CA  GLN A  31 "
   model   vdw
   4.516 3.870
nonbonded pdb=" N   LEU A  60 "
          pdb=" CD1 LEU A  60 "
   model   vdw
   4.516 3.540
nonbonded pdb=" CB  HIS A  64 "
          pdb=" CA  LEU A  65 "
   model   vdw
   4.517 3.870
nonbonded pdb=" NH1 ARG A  16 "
          pdb=" CA  PRO A  85 "
   model   vdw sym.op.
   4.517 3.550 x,y-1,z
nonbonded pdb=" OG  SER A  67 "
          pdb=" CB  ILE A  78 "
   model   vdw
   4.517 3.470
nonbonded pdb=" CG  TYR A  56 "
          pdb=" OH  TYR A  61 "
   model   vdw
   4.517 3.260
nonbonded pdb=" O   GLU A  30 "
          pdb=" CG  GLU A  30 "
   model   vdw
   4.518 3.440
nonbonded pdb=" CA  LYS A  69 "
          pdb=" CE  LYS A  69 "
   model   vdw
   4.518 3.870
nonbonded pdb=" N   GLY A  38 "
          pdb=" CG  LEU A  65 "
   model   vdw sym.op.
   4.518 3.550 -x+1,y,-z+2
nonbonded pdb=" C   VAL A   4 "
          pdb=" C   TYR A  61 "
   model   vdw
   4.518 3.500
nonbonded pdb=" CA  ASP A  36 "
          pdb=" CA  PRO A  42 "
   model   vdw
   4.519 3.900
nonbonded pdb=" CA  HIS A  64 "
          pdb=" C   LEU A  65 "
   model   vdw
   4.519 3.700
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" CA  GLN A  10 "
   model   vdw
   4.519 3.890
nonbonded pdb=" OG1 THR A  14 "
          pdb=" C   GLU A  30 "
   model   vdw
   4.519 3.270
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" OE1 GLN A  10 "
   model   vdw
   4.519 3.460
nonbonded pdb=" CA  VAL A   4 "
          pdb=" C   TYR A  34 "
   model   vdw
   4.519 3.700
nonbonded pdb=" C   LEU A  32 "
          pdb="O    HOH S   8 "
   model   vdw
   4.520 3.270
nonbonded pdb=" CA  PHE A  13 "
          pdb=" C   THR A  14 "
   model   vdw
   4.520 3.700
nonbonded pdb=" O   SER A  67 "
          pdb=" O   PHE A  68 "
   model   vdw
   4.521 3.040
nonbonded pdb=" O   LYS A   7 "
          pdb=" CG  PRO A   8 "
   model   vdw
   4.521 3.440
nonbonded pdb=" CG  GLU A  30 "
          pdb=" CE  LYS A  46 "
   model   vdw
   4.522 3.840
nonbonded pdb=" CA  LYS A   7 "
          pdb=" CD  GLN A  10 "
   model   vdw
   4.522 3.700
nonbonded pdb=" OG1 THR A  15 "
          pdb=" N   ARG A  16 "
   model   vdw
   4.522 3.120
nonbonded pdb=" CB  LYS A  46 "
          pdb=" CA  ILE A  47 "
   model   vdw
   4.522 3.870
nonbonded pdb=" CA  ARG A  16 "
          pdb=" NE  ARG A  16 "
   model   vdw
   4.522 3.550
nonbonded pdb=" CB  TYR A  61 "
          pdb=" CG  LEU A  83 "
   model   vdw
   4.523 3.870
nonbonded pdb=" CA  ALA A  11 "
          pdb=" NE2 GLN A  12 "
   model   vdw
   4.523 3.550
nonbonded pdb=" CG2 VAL A  45 "
          pdb=" CB  LEU A  76 "
   model   vdw sym.op.
   4.523 3.860 -x+1,y,-z+2
nonbonded pdb=" CG2 VAL A  45 "
          pdb=" CG1 VAL A  70 "
   model   vdw sym.op.
   4.523 3.880 -x+1,y,-z+2
nonbonded pdb=" CB  ILE A   6 "
          pdb=" C   PRO A  58 "
   model   vdw
   4.525 3.700
nonbonded pdb=" OE1 GLN A  72 "
          pdb=" N   ILE A   2 "
   model   vdw sym.op.
   4.525 3.120 -x+1,y-1,-z+2
nonbonded pdb=" N   ILE A   2 "
          pdb=" OE1 GLN A  72 "
   model   vdw sym.op.
   4.525 3.120 -x+1,y+1,-z+2
nonbonded pdb=" O   TYR A  34 "
          pdb=" CG  TYR A  34 "
   model   vdw
   4.525 3.260
nonbonded pdb=" C   PRO A   8 "
          pdb=" CG  PRO A  58 "
   model   vdw
   4.525 3.670
nonbonded pdb=" C   SER A  67 "
          pdb=" CE1 PHE A  68 "
   model   vdw
   4.526 3.570
nonbonded pdb=" N   PHE A  13 "
          pdb=" O   GLU A  30 "
   model   vdw
   4.526 3.120
nonbonded pdb=" CG  LYS A   7 "
          pdb="O    HOH S  12 "
   model   vdw
   4.526 3.440
nonbonded pdb=" CA  VAL A  70 "
          pdb=" C   GLY A  71 "
   model   vdw
   4.527 3.700
nonbonded pdb=" CB  ILE A   2 "
          pdb=" OG1 THR A  62 "
   model   vdw
   4.527 3.470
nonbonded pdb=" CB  SER A  67 "
          pdb=" N   LEU A  81 "
   model   vdw
   4.527 3.520
nonbonded pdb=" N   GLN A  72 "
          pdb=" N   GLY A  74 "
   model   vdw
   4.528 3.200
nonbonded pdb=" CB  PHE A  68 "
          pdb=" CA  LYS A  69 "
   model   vdw
   4.528 3.870
nonbonded pdb=" CG1 VAL A  63 "
          pdb=" CG  LEU A  81 "
   model   vdw
   4.529 3.890
nonbonded pdb=" CB  LYS A   7 "
          pdb=" CA  PRO A   8 "
   model   vdw
   4.529 3.870
nonbonded pdb=" O   GLU A  40 "
          pdb=" CZ  TYR A  41 "
   model   vdw
   4.529 3.260
nonbonded pdb=" CE  LYS A   3 "
          pdb=" CD1 LEU A  60 "
   model   vdw
   4.530 3.860
nonbonded pdb=" O   GLU A  30 "
          pdb=" O   GLN A  31 "
   model   vdw
   4.530 3.040
nonbonded pdb=" CA  ALA A  11 "
          pdb=" CD  PRO A  58 "
   model   vdw
   4.530 3.870
nonbonded pdb=" CA  ARG A  80 "
          pdb=" CZ  ARG A  82 "
   model   vdw
   4.531 3.700
nonbonded pdb=" CA  SER A   9 "
          pdb=" OG1 THR A  15 "
   model   vdw sym.op.
   4.531 3.470 -x+1/2,y+1/2,-z+1
nonbonded pdb=" OG1 THR A  15 "
          pdb=" CA  SER A   9 "
   model   vdw sym.op.
   4.531 3.470 -x+1/2,y-1/2,-z+1
nonbonded pdb=" C   GLN A  31 "
          pdb=" CB  ILE A  47 "
   model   vdw
   4.531 3.700
nonbonded pdb=" C   HIS A  64 "
          pdb=" O   ARG A  82 "
   model   vdw
   4.531 3.270
nonbonded pdb=" C   GLU A   5 "
          pdb=" OE1 GLN A  10 "
   model   vdw
   4.531 3.270
nonbonded pdb=" O   ASP A  50 "
          pdb=" CA  GLY A  52 "
   model   vdw
   4.532 3.440
nonbonded pdb=" C   GLN A  10 "
          pdb=" CA  GLN A  12 "
   model   vdw
   4.533 3.700
nonbonded pdb=" CG  PRO A   8 "
          pdb="O    HOH S  12 "
   model   vdw
   4.533 3.440
nonbonded pdb="O    HOH S  26 "
          pdb=" CD2 TYR A  41 "
   model   vdw sym.op.
   4.533 3.340 -x+1,y,-z+1
nonbonded pdb=" CD2 TYR A  41 "
          pdb="O    HOH S  26 "
   model   vdw sym.op.
   4.533 3.340 -x+1,y,-z+1
nonbonded pdb=" CG  GLN A  12 "
          pdb="O    HOH S   8 "
   model   vdw
   4.533 3.440
nonbonded pdb=" CG  GLN A  53 "
          pdb=" CA  PRO A  54 "
   model   vdw
   4.534 3.870
nonbonded pdb=" CG  LYS A  46 "
          pdb=" C   ILE A  47 "
   model   vdw
   4.534 3.670
nonbonded pdb=" C   LEU A  76 "
          pdb=" N   ILE A  78 "
   model   vdw
   4.534 3.350
nonbonded pdb=" CG  ASP A  79 "
          pdb=" CA  ARG A  80 "
   model   vdw
   4.534 3.700
nonbonded pdb=" OE1 GLN A  31 "
          pdb=" CG  LEU A  49 "
   model   vdw
   4.535 3.470
nonbonded pdb=" O   VAL A  63 "
          pdb=" CG2 VAL A  63 "
   model   vdw
   4.535 3.460
nonbonded pdb=" CE2 PHE A  13 "
          pdb=" N   ALA A  55 "
   model   vdw
   4.536 3.420
nonbonded pdb=" CG2 ILE A  78 "
          pdb=" O   ARG A  80 "
   model   vdw
   4.536 3.460
nonbonded pdb=" NZ  LYS A   7 "
          pdb=" CE2 TYR A  41 "
   model   vdw sym.op.
   4.537 3.420 -x+1,y,-z+1
nonbonded pdb=" N   SER A   9 "
          pdb=" CA  THR A  15 "
   model   vdw sym.op.
   4.537 3.550 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CA  VAL A  35 "
          pdb=" C   ASP A  36 "
   model   vdw
   4.537 3.700
nonbonded pdb=" CB  GLN A  31 "
          pdb=" O   ILE A  47 "
   model   vdw
   4.537 3.440
nonbonded pdb=" O   GLY A  59 "
          pdb="O    HOH S  12 "
   model   vdw
   4.537 3.040
nonbonded pdb=" C   CYS A  33 "
          pdb=" CD1 LEU A  44 "
   model   vdw
   4.537 3.690
nonbonded pdb=" CB  PRO A  42 "
          pdb=" CA  VAL A  43 "
   model   vdw
   4.537 3.870
nonbonded pdb=" C   LEU A  37 "
          pdb=" CG  ASN A  39 "
   model   vdw
   4.538 3.500
nonbonded pdb=" CE  LYS A   3 "
          pdb=" CD1 PHE A  73 "
   model   vdw sym.op.
   4.538 3.740 -x+1,y+1,-z+2
nonbonded pdb=" C   ILE A   6 "
          pdb=" CB  PRO A  58 "
   model   vdw
   4.538 3.670
nonbonded pdb=" O   LEU A  37 "
          pdb=" CD2 LEU A  37 "
   model   vdw
   4.539 3.460
nonbonded pdb=" O   THR A  62 "
          pdb=" CG  LEU A  83 "
   model   vdw
   4.539 3.470
nonbonded pdb=" N   CYS A  33 "
          pdb=" N   VAL A  45 "
   model   vdw
   4.539 3.200
nonbonded pdb=" CZ  PHE A  13 "
          pdb=" OD1 ASN A  29 "
   model   vdw
   4.539 3.340
nonbonded pdb=" CB  THR A  15 "
          pdb=" CA  ARG A  16 "
   model   vdw
   4.539 3.900
nonbonded pdb=" O   LYS A   3 "
          pdb=" N   GLU A   5 "
   model   vdw
   4.539 3.120
nonbonded pdb=" OH  TYR A  26 "
          pdb=" OH  TYR A  61 "
   model   vdw sym.op.
   4.541 3.040 x,y-1,z
nonbonded pdb=" CD1 LEU A  65 "
          pdb=" CE1 PHE A  68 "
   model   vdw
   4.541 3.760
nonbonded pdb=" CD  LYS A   3 "
          pdb=" O   GLN A  72 "
   model   vdw sym.op.
   4.541 3.440 -x+1,y+1,-z+2
nonbonded pdb=" C   GLN A  31 "
          pdb=" CD  GLN A  31 "
   model   vdw
   4.541 3.500
nonbonded pdb=" O   GLN A  53 "
          pdb=" CG  PRO A  54 "
   model   vdw
   4.541 3.440
nonbonded pdb=" CD1 ILE A   6 "
          pdb=" O   TYR A  56 "
   model   vdw
   4.543 3.460
nonbonded pdb=" N   SER A   9 "
          pdb=" N   ALA A  11 "
   model   vdw
   4.543 3.200
nonbonded pdb=" N   ASP A  50 "
          pdb=" CB  GLN A  53 "
   model   vdw
   4.544 3.520
nonbonded pdb=" N   GLU A  51 "
          pdb=" N   GLN A  53 "
   model   vdw
   4.544 3.200
nonbonded pdb=" CG  PHE A  68 "
          pdb=" CG1 ILE A  78 "
   model   vdw
   4.544 3.660
nonbonded pdb=" CD1 TYR A  56 "
          pdb=" CG  LEU A  83 "
   model   vdw
   4.544 3.770
nonbonded pdb=" CA  LYS A   7 "
          pdb=" CB  GLN A  10 "
   model   vdw
   4.544 3.870
nonbonded pdb=" CD  PRO A   8 "
          pdb=" CB  PRO A  58 "
   model   vdw
   4.544 3.840
nonbonded pdb=" O   PHE A  73 "
          pdb="O    HOH S   3 "
   model   vdw
   4.544 3.040
nonbonded pdb=" CG  ARG A  16 "
          pdb=" CD  GLU A  30 "
   model   vdw
   4.544 3.670
nonbonded pdb=" CB  VAL A  84 "
          pdb=" CA  PRO A  85 "
   model   vdw
   4.545 3.900
nonbonded pdb=" O   SER A  75 "
          pdb=" CB  MSE A  77 "
   model   vdw
   4.545 3.440
nonbonded pdb=" O   ASN A  29 "
          pdb=" N   THR A  48 "
   model   vdw
   4.545 3.120
nonbonded pdb=" CG  GLN A  72 "
          pdb=" CZ  PHE A  73 "
   model   vdw
   4.546 3.740
nonbonded pdb=" O   LEU A  28 "
          pdb=" CG  LEU A  28 "
   model   vdw
   4.546 3.470
nonbonded pdb=" N   VAL A  70 "
          pdb=" CD1 LEU A  76 "
   model   vdw
   4.546 3.540
nonbonded pdb=" O   GLU A   5 "
          pdb=" O   ILE A   6 "
   model   vdw
   4.546 3.040
nonbonded pdb=" CG1 ILE A   6 "
          pdb=" CD1 LEU A  83 "
   model   vdw
   4.546 3.860
nonbonded pdb=" CA  SER A   9 "
          pdb=" CG2 THR A  15 "
   model   vdw sym.op.
   4.546 3.890 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CG2 THR A  15 "
          pdb=" CA  SER A   9 "
   model   vdw sym.op.
   4.546 3.890 -x+1/2,y-1/2,-z+1
nonbonded pdb=" C   ASP A  50 "
          pdb=" NH1 ARG A  80 "
   model   vdw
   4.546 3.350
nonbonded pdb=" O   PRO A   8 "
          pdb=" CG  PRO A   8 "
   model   vdw
   4.547 3.440
nonbonded pdb=" CB  LYS A  69 "
          pdb=" NZ  LYS A  69 "
   model   vdw
   4.547 3.520
nonbonded pdb=" O   SER A  67 "
          pdb=" CD1 PHE A  68 "
   model   vdw
   4.548 3.340
nonbonded pdb=" CB  TYR A  34 "
          pdb=" CE2 TYR A  41 "
   model   vdw sym.op.
   4.549 3.740 -x+1,y,-z+1
nonbonded pdb=" CA  VAL A  63 "
          pdb=" C   HIS A  64 "
   model   vdw
   4.549 3.700
nonbonded pdb=" CA  LEU A  49 "
          pdb=" CG  GLN A  53 "
   model   vdw
   4.549 3.870
nonbonded pdb=" CE  LYS A  69 "
          pdb=" C   VAL A  70 "
   model   vdw
   4.551 3.670
nonbonded pdb=" CA  GLY A  52 "
          pdb=" C   GLN A  53 "
   model   vdw
   4.551 3.670
nonbonded pdb=" CG2 VAL A  45 "
          pdb=" N   LEU A  76 "
   model   vdw sym.op.
   4.551 3.540 -x+1,y,-z+2
nonbonded pdb=" CA  VAL A  63 "
          pdb="O    HOH S  19 "
   model   vdw
   4.551 3.470
nonbonded pdb=" O   GLY A  38 "
          pdb=" N   GLU A  40 "
   model   vdw
   4.551 3.120
nonbonded pdb=" NH2 ARG A  16 "
          pdb=" OH  TYR A  26 "
   model   vdw
   4.552 3.120
nonbonded pdb=" C   PHE A  68 "
          pdb=" CD1 PHE A  68 "
   model   vdw
   4.552 3.570
nonbonded pdb=" N   THR A  14 "
          pdb=" CA  GLU A  30 "
   model   vdw
   4.552 3.550
nonbonded pdb=" C   VAL A  70 "
          pdb="O    HOH S  10 "
   model   vdw
   4.552 3.270
nonbonded pdb=" CA  PHE A  13 "
          pdb=" CE1 PHE A  13 "
   model   vdw
   4.553 3.770
nonbonded pdb=" O   LYS A   7 "
          pdb=" CA  ALA A  11 "
   model   vdw
   4.553 3.470
nonbonded pdb=" O   ASN A  29 "
          pdb=" CG  ASN A  29 "
   model   vdw
   4.553 3.270
nonbonded pdb=" C   LYS A   7 "
          pdb=" OE1 GLN A  10 "
   model   vdw
   4.553 3.270
nonbonded pdb=" CB  PRO A   8 "
          pdb=" CA  SER A   9 "
   model   vdw
   4.554 3.870
nonbonded pdb=" O   ILE A   6 "
          pdb=" CG  LYS A   7 "
   model   vdw
   4.554 3.440
nonbonded pdb=" CG1 VAL A  35 "
          pdb=" CD1 LEU A  76 "
   model   vdw sym.op.
   4.554 3.880 -x+1,y,-z+2
nonbonded pdb=" CB  ASP A  50 "
          pdb=" O   GLU A  51 "
   model   vdw
   4.555 3.440
nonbonded pdb=" O   LEU A  60 "
          pdb=" O   TYR A  61 "
   model   vdw
   4.555 3.040
nonbonded pdb=" N   ARG A  16 "
          pdb=" N   LEU A  28 "
   model   vdw
   4.555 3.200
nonbonded pdb=" CB  LEU A  49 "
          pdb=" O   GLN A  53 "
   model   vdw
   4.555 3.440
nonbonded pdb=" OE1 GLN A  10 "
          pdb=" CB  CYS A  33 "
   model   vdw
   4.557 3.440
nonbonded pdb=" CD2 LEU A  37 "
          pdb=" C   PHE A  68 "
   model   vdw sym.op.
   4.557 3.690 -x+1,y,-z+2
nonbonded pdb=" CB  ASP A  50 "
          pdb=" CD  GLN A  53 "
   model   vdw
   4.557 3.670
nonbonded pdb=" CB  THR A  48 "
          pdb=" O   LEU A  49 "
   model   vdw
   4.557 3.470
nonbonded pdb=" CG2 VAL A   4 "
          pdb=" CA  VAL A  35 "
   model   vdw
   4.557 3.890
nonbonded pdb=" O   ILE A   2 "
          pdb=" CE1 PHE A  73 "
   model   vdw sym.op.
   4.558 3.340 -x+1,y+1,-z+2
nonbonded pdb=" CB  TYR A  61 "
          pdb=" N   VAL A  84 "
   model   vdw
   4.559 3.520
nonbonded pdb=" CB  LYS A  46 "
          pdb=" NZ  LYS A  46 "
   model   vdw
   4.559 3.520
nonbonded pdb=" O   ASN A  39 "
          pdb=" C   TYR A  41 "
   model   vdw
   4.559 3.270
nonbonded pdb=" CG  TYR A  61 "
          pdb=" CA  PRO A  85 "
   model   vdw
   4.560 3.690
nonbonded pdb=" O   ILE A   6 "
          pdb=" CG  PRO A  58 "
   model   vdw
   4.560 3.440
nonbonded pdb=" CB  SER A  75 "
          pdb=" O   LEU A  76 "
   model   vdw
   4.560 3.440
nonbonded pdb=" CG  GLU A   5 "
          pdb=" CG  LYS A   7 "
   model   vdw
   4.560 3.840
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" C   LYS A   7 "
   model   vdw
   4.560 3.690
nonbonded pdb=" CA  GLN A  12 "
          pdb=" O   PHE A  13 "
   model   vdw
   4.561 3.470
nonbonded pdb=" N   SER A  67 "
          pdb=" CB  ARG A  82 "
   model   vdw
   4.561 3.520
nonbonded pdb=" O   VAL A   4 "
          pdb=" CG  TYR A  61 "
   model   vdw
   4.561 3.260
nonbonded pdb=" CG  TYR A  41 "
          pdb=" CD1 TYR A  41 "
   model   vdw sym.op.
   4.561 3.560 -x+1,y,-z+1
nonbonded pdb=" CD1 TYR A  41 "
          pdb=" CG  TYR A  41 "
   model   vdw sym.op.
   4.561 3.560 -x+1,y,-z+1
nonbonded pdb=" CG1 ILE A  78 "
          pdb=" N   ASP A  79 "
   model   vdw
   4.562 3.520
nonbonded pdb=" CA  TYR A  26 "
          pdb=" CB  SER A  27 "
   model   vdw
   4.562 3.870
nonbonded pdb=" CD2 TYR A  61 "
          pdb=" C   LEU A  83 "
   model   vdw
   4.563 3.570
nonbonded pdb=" CA  ILE A  47 "
          pdb="O    HOH S   6 "
   model   vdw sym.op.
   4.563 3.470 -x+1,y,-z+2
nonbonded pdb=" CG  GLU A  30 "
          pdb=" N   GLN A  31 "
   model   vdw
   4.563 3.520
nonbonded pdb=" CA  ARG A  16 "
          pdb=" CB  SER A  17 "
   model   vdw
   4.563 3.870
nonbonded pdb=" C   PRO A   8 "
          pdb=" CB  ALA A  11 "
   model   vdw
   4.564 3.690
nonbonded pdb=" CA  GLY A  71 "
          pdb=" C   GLN A  72 "
   model   vdw
   4.564 3.670
nonbonded pdb=" CG  LEU A  49 "
          pdb=" OE1 GLN A  53 "
   model   vdw
   4.564 3.470
nonbonded pdb=" O   GLU A  51 "
          pdb=" CG  GLU A  51 "
   model   vdw
   4.564 3.440
nonbonded pdb=" CA  ILE A  47 "
          pdb=" C   THR A  48 "
   model   vdw
   4.564 3.700
nonbonded pdb=" CG  GLU A  30 "
          pdb=" NZ  LYS A  46 "
   model   vdw
   4.564 3.520
nonbonded pdb=" CB  LEU A  28 "
          pdb=" CA  ASN A  29 "
   model   vdw
   4.565 3.870
nonbonded pdb=" CG  GLN A  12 "
          pdb=" C   PHE A  13 "
   model   vdw
   4.565 3.670
nonbonded pdb=" CA  PHE A  73 "
          pdb=" CE1 PHE A  73 "
   model   vdw
   4.565 3.770
nonbonded pdb=" O   ALA A  11 "
          pdb=" O   TYR A  56 "
   model   vdw
   4.566 3.040
nonbonded pdb=" OG  SER A  27 "
          pdb=" O   LEU A  28 "
   model   vdw
   4.566 3.040
nonbonded pdb=" C   CYS A  33 "
          pdb=" CD2 TYR A  34 "
   model   vdw
   4.566 3.570
nonbonded pdb=" N   CYS A  33 "
          pdb=" CD1 LEU A  44 "
   model   vdw
   4.566 3.540
nonbonded pdb=" O   SER A  75 "
          pdb=" CA  MSE A  77 "
   model   vdw
   4.566 3.470
nonbonded pdb=" O   VAL A  35 "
          pdb=" CA  LEU A  37 "
   model   vdw
   4.566 3.470
nonbonded pdb=" O   THR A  48 "
          pdb=" CA  ASP A  50 "
   model   vdw
   4.567 3.470
nonbonded pdb=" CA  GLY A  71 "
          pdb=" CB  MSE A  77 "
   model   vdw
   4.568 3.840
nonbonded pdb=" C   PHE A  73 "
          pdb=" CD1 PHE A  73 "
   model   vdw
   4.568 3.570
nonbonded pdb=" O   GLN A  72 "
          pdb=" CD  GLN A  72 "
   model   vdw
   4.568 3.270
nonbonded pdb=" NE  ARG A  16 "
          pdb=" OH  TYR A  26 "
   model   vdw
   4.569 3.120
nonbonded pdb=" CB  ILE A  47 "
          pdb=" CA  THR A  48 "
   model   vdw
   4.569 3.900
nonbonded pdb=" O   LYS A   3 "
          pdb=" N   VAL A  35 "
   model   vdw
   4.569 3.120
nonbonded pdb=" C   ASN A  29 "
          pdb=" O   ILE A  47 "
   model   vdw
   4.569 3.270
nonbonded pdb=" O   ARG A  82 "
          pdb=" CG  ARG A  82 "
   model   vdw
   4.569 3.440
nonbonded pdb=" O   GLN A  12 "
          pdb=" N   THR A  14 "
   model   vdw
   4.569 3.120
nonbonded pdb=" CB  LEU A  60 "
          pdb=" CA  TYR A  61 "
   model   vdw
   4.570 3.870
nonbonded pdb=" C   ARG A  16 "
          pdb=" CE1 TYR A  26 "
   model   vdw
   4.570 3.570
nonbonded pdb=" CA  PRO A   8 "
          pdb=" OG1 THR A  15 "
   model   vdw sym.op.
   4.571 3.470 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CA  ASP A  36 "
          pdb=" CB  PRO A  42 "
   model   vdw
   4.571 3.870
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" CD  GLN A  31 "
   model   vdw
   4.571 3.690
nonbonded pdb=" O   SER A  67 "
          pdb=" NH1 ARG A  82 "
   model   vdw
   4.571 3.120
nonbonded pdb=" CA  LEU A  37 "
          pdb=" N   ASN A  39 "
   model   vdw
   4.571 3.550
nonbonded pdb=" CD2 PHE A  68 "
          pdb=" CA  ILE A  78 "
   model   vdw
   4.572 3.770
nonbonded pdb=" SG  CYS A  33 "
          pdb=" O   TYR A  34 "
   model   vdw
   4.572 3.400
nonbonded pdb=" N   GLN A  10 "
          pdb=" OE1 GLN A  10 "
   model   vdw
   4.572 3.120
nonbonded pdb=" OG  SER A  66 "
          pdb=" CA  SER A  67 "
   model   vdw
   4.572 3.470
nonbonded pdb=" CD1 ILE A  78 "
          pdb=" O   MSE A  77 "
   model   vdw sym.op.
   4.572 3.460 -x+1,y,-z+2
nonbonded pdb=" O   MSE A  77 "
          pdb=" CD1 ILE A  78 "
   model   vdw sym.op.
   4.572 3.460 -x+1,y,-z+2
nonbonded pdb=" CG  ARG A  82 "
          pdb=" N   LEU A  83 "
   model   vdw
   4.572 3.520
nonbonded pdb=" CA  TYR A  34 "
          pdb=" CE1 TYR A  34 "
   model   vdw
   4.572 3.770
nonbonded pdb=" CG  GLN A  10 "
          pdb=" N   CYS A  33 "
   model   vdw
   4.572 3.520
nonbonded pdb=" CD  GLU A   5 "
          pdb=" CG  LYS A   7 "
   model   vdw
   4.572 3.670
nonbonded pdb=" CD2 TYR A  61 "
          pdb=" CD  PRO A  85 "
   model   vdw
   4.573 3.740
nonbonded pdb=" O   VAL A  84 "
          pdb=" CG  PRO A  85 "
   model   vdw
   4.573 3.440
nonbonded pdb=" C   TYR A  26 "
          pdb=" OG  SER A  27 "
   model   vdw
   4.573 3.270
nonbonded pdb=" C   ILE A   6 "
          pdb=" C   PRO A  58 "
   model   vdw
   4.574 3.500
nonbonded pdb=" CB  SER A   9 "
          pdb=" CA  GLN A  10 "
   model   vdw
   4.575 3.870
nonbonded pdb=" CA  PHE A  68 "
          pdb=" CE1 PHE A  68 "
   model   vdw
   4.575 3.770
nonbonded pdb=" CG  LYS A   3 "
          pdb=" C   VAL A   4 "
   model   vdw
   4.575 3.670
nonbonded pdb=" C   SER A  67 "
          pdb=" CB  ASP A  79 "
   model   vdw
   4.576 3.670
nonbonded pdb=" N   PRO A  58 "
          pdb=" OH  TYR A  61 "
   model   vdw
   4.576 3.120
nonbonded pdb=" CA  GLY A  38 "
          pdb=" C   ASN A  39 "
   model   vdw
   4.576 3.670
nonbonded pdb=" CE  LYS A   7 "
          pdb=" OE1 GLU A  40 "
   model   vdw sym.op.
   4.576 3.440 -x+1,y,-z+1
nonbonded pdb=" O   ARG A  16 "
          pdb=" N   SER A  27 "
   model   vdw
   4.577 3.120
nonbonded pdb=" CD  GLN A  31 "
          pdb=" N   LEU A  32 "
   model   vdw
   4.577 3.350
nonbonded pdb=" CG1 ILE A   6 "
          pdb=" O   GLY A  59 "
   model   vdw
   4.577 3.440
nonbonded pdb=" CB  PRO A  54 "
          pdb=" C   ALA A  55 "
   model   vdw
   4.577 3.670
nonbonded pdb=" CB  LYS A  69 "
          pdb=" C   VAL A  70 "
   model   vdw
   4.577 3.670
nonbonded pdb=" CG  TYR A  26 "
          pdb=" CA  SER A  27 "
   model   vdw
   4.578 3.690
nonbonded pdb=" O   VAL A   4 "
          pdb=" CG2 VAL A   4 "
   model   vdw
   4.578 3.460
nonbonded pdb=" NH2 ARG A  16 "
          pdb=" C   PRO A  85 "
   model   vdw sym.op.
   4.578 3.350 x,y-1,z
nonbonded pdb=" CA  LEU A  81 "
          pdb=" C   ARG A  82 "
   model   vdw
   4.578 3.700
nonbonded pdb=" NE2 HIS A  64 "
          pdb=" OG  SER A  66 "
   model   vdw
   4.578 3.120
nonbonded pdb=" C   VAL A   4 "
          pdb=" CA  TYR A  61 "
   model   vdw
   4.578 3.700
nonbonded pdb=" CG1 ILE A   6 "
          pdb=" CB  CYS A  33 "
   model   vdw
   4.579 3.840
nonbonded pdb=" O   LEU A  81 "
          pdb=" CG  LEU A  83 "
   model   vdw
   4.579 3.470
nonbonded pdb=" C   LEU A  60 "
          pdb=" N   THR A  62 "
   model   vdw
   4.580 3.350
nonbonded pdb=" C   ASP A  36 "
          pdb=" O   LEU A  37 "
   model   vdw
   4.580 3.270
nonbonded pdb=" N   GLN A  10 "
          pdb=" CB  ALA A  11 "
   model   vdw
   4.580 3.540
nonbonded pdb=" CG  TYR A  34 "
          pdb=" N   VAL A  35 "
   model   vdw
   4.580 3.340
nonbonded pdb=" O   PRO A   8 "
          pdb=" CA  ALA A  11 "
   model   vdw
   4.580 3.470
nonbonded pdb=" CG  LYS A  69 "
          pdb=" C   VAL A  70 "
   model   vdw
   4.581 3.670
nonbonded pdb=" ND2 ASN A  29 "
          pdb=" O   GLN A  53 "
   model   vdw
   4.581 3.120
nonbonded pdb=" O   LYS A   7 "
          pdb=" CB  ALA A  11 "
   model   vdw
   4.581 3.460
nonbonded pdb=" CB  LEU A  76 "
          pdb=" CA  MSE A  77 "
   model   vdw
   4.581 3.870
nonbonded pdb=" CA  GLN A  31 "
          pdb=" O   LEU A  32 "
   model   vdw
   4.582 3.470
nonbonded pdb=" N   THR A  62 "
          pdb=" C   PRO A  85 "
   model   vdw
   4.582 3.350
nonbonded pdb=" CG  HIS A  64 "
          pdb=" CB  SER A  66 "
   model   vdw
   4.582 3.660
nonbonded pdb="O    HOH S  25 "
          pdb=" CG2 VAL A  70 "
   model   vdw sym.op.
   4.583 3.460 -x+1,y,-z+2
nonbonded pdb=" CG2 VAL A  70 "
          pdb="O    HOH S  25 "
   model   vdw sym.op.
   4.583 3.460 -x+1,y,-z+2
nonbonded pdb=" CA  GLU A  40 "
          pdb=" CB  TYR A  41 "
   model   vdw
   4.583 3.870
nonbonded pdb=" CD2 LEU A  32 "
          pdb=" N   CYS A  33 "
   model   vdw
   4.583 3.540
nonbonded pdb=" N   ILE A   6 "
          pdb=" OE1 GLN A  10 "
   model   vdw
   4.584 3.120
nonbonded pdb=" OD1 ASP A  36 "
          pdb=" C   GLY A  38 "
   model   vdw
   4.584 3.270
nonbonded pdb=" CE  LYS A   3 "
          pdb=" CE1 PHE A  73 "
   model   vdw sym.op.
   4.585 3.740 -x+1,y+1,-z+2
nonbonded pdb=" O   PHE A  13 "
          pdb=" N   THR A  15 "
   model   vdw
   4.585 3.120
nonbonded pdb=" CA  VAL A   4 "
          pdb=" CA  VAL A  35 "
   model   vdw
   4.585 3.900
nonbonded pdb=" C   GLU A  30 "
          pdb=" N   LEU A  32 "
   model   vdw
   4.585 3.350
nonbonded pdb=" CA  LEU A  28 "
          pdb=" C   ASN A  29 "
   model   vdw
   4.585 3.700
nonbonded pdb=" C   GLN A  72 "
          pdb=" O   PHE A  73 "
   model   vdw
   4.585 3.270
nonbonded pdb=" C   LEU A  65 "
          pdb=" CD2 LEU A  65 "
   model   vdw
   4.585 3.690
nonbonded pdb=" CE1 TYR A  26 "
          pdb=" N   SER A  27 "
   model   vdw
   4.585 3.420
nonbonded pdb=" CG  PRO A   8 "
          pdb=" CD1 PHE A  13 "
   model   vdw sym.op.
   4.586 3.740 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CG  LEU A  32 "
          pdb=" O   VAL A  45 "
   model   vdw
   4.586 3.470
nonbonded pdb=" NE  ARG A  16 "
          pdb=" OE2 GLU A  30 "
   model   vdw
   4.586 3.120
nonbonded pdb=" CB  VAL A  35 "
          pdb=" CB  VAL A  45 "
   model   vdw
   4.587 3.900
nonbonded pdb=" CG  LEU A  65 "
          pdb="O    HOH S   5 "
   model   vdw sym.op.
   4.587 3.470 -x+1,y,-z+2
nonbonded pdb=" O   ILE A   2 "
          pdb=" O   LYS A   3 "
   model   vdw
   4.588 3.040
nonbonded pdb=" OG1 THR A  14 "
          pdb=" N   GLU A  30 "
   model   vdw
   4.589 3.120
nonbonded pdb=" O   CYS A  33 "
          pdb=" CB  LEU A  44 "
   model   vdw
   4.589 3.440
nonbonded pdb=" N   PHE A  73 "
          pdb=" CE2 PHE A  73 "
   model   vdw
   4.589 3.420
nonbonded pdb=" CB  ILE A  78 "
          pdb=" CA  ASP A  79 "
   model   vdw
   4.589 3.900
nonbonded pdb=" CE  MSE A  77 "
          pdb=" N   ILE A  78 "
   model   vdw
   4.589 3.540
nonbonded pdb=" CD2 PHE A  68 "
          pdb=" O   MSE A  77 "
   model   vdw
   4.589 3.340
nonbonded pdb=" OG  SER A  66 "
          pdb=" NE  ARG A  82 "
   model   vdw
   4.590 3.120
nonbonded pdb=" CB  SER A  66 "
          pdb=" CA  SER A  67 "
   model   vdw
   4.590 3.870
nonbonded pdb=" CG2 VAL A  84 "
          pdb=" CD  PRO A  85 "
   model   vdw
   4.590 3.860
nonbonded pdb=" CG  PRO A  54 "
          pdb=" O   ALA A  55 "
   model   vdw
   4.590 3.440
nonbonded pdb=" O   THR A  62 "
          pdb=" CB  VAL A  84 "
   model   vdw
   4.590 3.470
nonbonded pdb=" C   SER A   9 "
          pdb=" CD  GLN A  12 "
   model   vdw
   4.591 3.500
nonbonded pdb=" CE1 PHE A  13 "
          pdb=" O   THR A  14 "
   model   vdw
   4.591 3.340
nonbonded pdb=" CA  TYR A  41 "
          pdb=" CE1 TYR A  41 "
   model   vdw
   4.591 3.770
nonbonded pdb=" CB  GLU A  51 "
          pdb=" CA  GLY A  52 "
   model   vdw
   4.591 3.840
nonbonded pdb=" CG2 VAL A  43 "
          pdb=" O   LEU A  44 "
   model   vdw
   4.591 3.460
nonbonded pdb=" O   LYS A  46 "
          pdb=" N   SER A  75 "
   model   vdw sym.op.
   4.592 3.120 -x+1,y,-z+2
nonbonded pdb=" O   PHE A  13 "
          pdb=" CG  PRO A  58 "
   model   vdw sym.op.
   4.593 3.440 -x+1/2,y-1/2,-z+1
nonbonded pdb=" CB  VAL A  45 "
          pdb=" CA  LYS A  46 "
   model   vdw
   4.593 3.900
nonbonded pdb=" CB  TYR A  34 "
          pdb=" CA  VAL A  35 "
   model   vdw
   4.593 3.870
nonbonded pdb=" O   SER A  67 "
          pdb=" CA  ARG A  80 "
   model   vdw
   4.593 3.470
nonbonded pdb=" CD2 PHE A  68 "
          pdb=" CB  ILE A  78 "
   model   vdw
   4.594 3.770
nonbonded pdb=" CA  LEU A  76 "
          pdb=" CB  MSE A  77 "
   model   vdw
   4.594 3.870
nonbonded pdb=" CB  ASP A  79 "
          pdb=" CB  ARG A  80 "
   model   vdw
   4.594 3.840
nonbonded pdb=" CZ  TYR A  41 "
          pdb=" CD2 TYR A  34 "
   model   vdw sym.op.
   4.594 3.560 -x+1,y,-z+1
nonbonded pdb=" CD2 TYR A  34 "
          pdb=" CZ  TYR A  41 "
   model   vdw sym.op.
   4.594 3.560 -x+1,y,-z+1
nonbonded pdb=" O   LEU A  32 "
          pdb=" SG  CYS A  33 "
   model   vdw
   4.595 3.400
nonbonded pdb=" O   SER A  66 "
          pdb=" C   PHE A  68 "
   model   vdw
   4.595 3.270
nonbonded pdb=" N   LYS A  46 "
          pdb="O    HOH S   6 "
   model   vdw sym.op.
   4.595 3.120 -x+1,y,-z+2
nonbonded pdb=" CD2 LEU A  28 "
          pdb=" CG  PRO A  85 "
   model   vdw sym.op.
   4.596 3.860 x,y-1,z
nonbonded pdb=" CE2 TYR A  56 "
          pdb="O    HOH S  39 "
   model   vdw
   4.596 3.340
nonbonded pdb=" CA  ALA A  11 "
          pdb=" CG  PRO A  58 "
   model   vdw
   4.596 3.870
nonbonded pdb=" O   TYR A  56 "
          pdb=" OH  TYR A  61 "
   model   vdw
   4.596 3.040
nonbonded pdb=" CA  GLU A  40 "
          pdb=" CG  TYR A  41 "
   model   vdw
   4.596 3.690
nonbonded pdb=" CA  ASP A  50 "
          pdb=" CD  GLN A  53 "
   model   vdw
   4.597 3.700
nonbonded pdb=" CB  ALA A  55 "
          pdb=" C   TYR A  56 "
   model   vdw
   4.597 3.690
nonbonded pdb=" CB  TYR A  61 "
          pdb=" C   THR A  62 "
   model   vdw
   4.597 3.670
nonbonded pdb=" CA  PHE A  13 "
          pdb=" CE2 PHE A  13 "
   model   vdw
   4.597 3.770
nonbonded pdb=" O   PRO A  58 "
          pdb=" OH  TYR A  61 "
   model   vdw
   4.597 3.040
nonbonded pdb=" O   CYS A  33 "
          pdb=" O   TYR A  34 "
   model   vdw
   4.598 3.040
nonbonded pdb=" CB  HIS A  64 "
          pdb=" CG2 VAL A  84 "
   model   vdw
   4.598 3.860
nonbonded pdb=" CG  TYR A  56 "
          pdb=" CB  LEU A  83 "
   model   vdw
   4.598 3.660
nonbonded pdb=" CB  TYR A  61 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   4.598 3.860
nonbonded pdb=" CB  VAL A   4 "
          pdb=" CB  TYR A  61 "
   model   vdw
   4.598 3.870
nonbonded pdb=" CE2 TYR A  56 "
          pdb=" N   LEU A  83 "
   model   vdw
   4.599 3.420
nonbonded pdb=" CB  GLN A  10 "
          pdb=" CB  LEU A  32 "
   model   vdw
   4.599 3.840
nonbonded pdb=" CG2 VAL A   4 "
          pdb=" O   TYR A  34 "
   model   vdw
   4.599 3.460
nonbonded pdb=" CD  LYS A  46 "
          pdb=" O   ILE A  47 "
   model   vdw
   4.599 3.440
nonbonded pdb=" CD  GLN A  53 "
          pdb=" CE2 TYR A  56 "
   model   vdw
   4.600 3.570
nonbonded pdb=" OH  TYR A  56 "
          pdb=" CB  ARG A  82 "
   model   vdw
   4.600 3.440
nonbonded pdb=" CA  SER A  67 "
          pdb=" N   ARG A  80 "
   model   vdw
   4.600 3.550
nonbonded pdb=" C   ARG A  80 "
          pdb=" CD  ARG A  82 "
   model   vdw
   4.600 3.670
nonbonded pdb=" CA  PHE A  73 "
          pdb=" C   GLY A  74 "
   model   vdw
   4.601 3.700
nonbonded pdb=" O   ALA A  57 "
          pdb=" CD1 TYR A  61 "
   model   vdw
   4.601 3.340
nonbonded pdb=" CD1 ILE A   2 "
          pdb=" CD1 PHE A  68 "
   model   vdw sym.op.
   4.601 3.760 -x+1,y,-z+2
nonbonded pdb=" CD1 PHE A  68 "
          pdb=" CD1 ILE A   2 "
   model   vdw sym.op.
   4.601 3.760 -x+1,y,-z+2
nonbonded pdb=" CG  TYR A  34 "
          pdb=" CD2 TYR A  41 "
   model   vdw sym.op.
   4.602 3.560 -x+1,y,-z+1
nonbonded pdb=" CD2 TYR A  41 "
          pdb=" CG  TYR A  34 "
   model   vdw sym.op.
   4.602 3.560 -x+1,y,-z+1
nonbonded pdb=" NZ  LYS A   3 "
          pdb=" CA  GLN A  72 "
   model   vdw sym.op.
   4.602 3.550 -x+1,y+1,-z+2
nonbonded pdb=" CA  GLN A  72 "
          pdb=" NZ  LYS A   3 "
   model   vdw sym.op.
   4.602 3.550 -x+1,y-1,-z+2
nonbonded pdb=" CA  MSE A  77 "
          pdb=" O   ILE A  78 "
   model   vdw
   4.603 3.470
nonbonded pdb=" N   GLY A  71 "
          pdb=" CE  MSE A  77 "
   model   vdw
   4.603 3.540
nonbonded pdb=" CB  VAL A  63 "
          pdb=" CD1 LEU A  81 "
   model   vdw
   4.603 3.890
nonbonded pdb=" CD2 TYR A  56 "
          pdb=" CB  LEU A  83 "
   model   vdw
   4.603 3.740
nonbonded pdb=" CA  TYR A  56 "
          pdb=" CE1 TYR A  56 "
   model   vdw
   4.603 3.770
nonbonded pdb=" O   THR A  48 "
          pdb=" OD1 ASP A  50 "
   model   vdw
   4.604 3.040
nonbonded pdb=" CG  LEU A  83 "
          pdb=" N   VAL A  84 "
   model   vdw
   4.604 3.550
nonbonded pdb=" CE2 TYR A  61 "
          pdb=" C   VAL A  84 "
   model   vdw
   4.604 3.570
nonbonded pdb=" C   ARG A  16 "
          pdb=" CA  SER A  27 "
   model   vdw
   4.604 3.700
nonbonded pdb=" CA  VAL A   4 "
          pdb=" CB  GLU A   5 "
   model   vdw
   4.604 3.870
nonbonded pdb=" CB  LEU A  65 "
          pdb=" CA  SER A  66 "
   model   vdw
   4.605 3.870
nonbonded pdb=" O   SER A  27 "
          pdb=" O   LEU A  28 "
   model   vdw
   4.605 3.040
nonbonded pdb=" CD1 LEU A  28 "
          pdb=" O   LEU A  49 "
   model   vdw
   4.605 3.460
nonbonded pdb=" CG  GLN A  10 "
          pdb="O    HOH S   8 "
   model   vdw
   4.606 3.440
nonbonded pdb=" N   LYS A   7 "
          pdb=" N   GLN A  10 "
   model   vdw
   4.606 3.200
nonbonded pdb=" CD  GLN A  31 "
          pdb=" C   TYR A  56 "
   model   vdw
   4.606 3.500
nonbonded pdb=" CB  PHE A  73 "
          pdb=" N   SER A  75 "
   model   vdw
   4.606 3.520
nonbonded pdb=" CB  LEU A  44 "
          pdb=" CA  VAL A  45 "
   model   vdw
   4.606 3.870
nonbonded pdb=" N   LEU A  65 "
          pdb=" OG  SER A  66 "
   model   vdw
   4.606 3.120
nonbonded pdb=" CB  VAL A  63 "
          pdb=" O   HIS A  64 "
   model   vdw
   4.606 3.470
nonbonded pdb=" CA  GLN A  12 "
          pdb=" C   PHE A  13 "
   model   vdw
   4.606 3.700
nonbonded pdb=" O   VAL A  84 "
          pdb=" CG1 VAL A  84 "
   model   vdw
   4.606 3.460
nonbonded pdb=" O   ALA A  11 "
          pdb=" N   PHE A  13 "
   model   vdw
   4.606 3.120
nonbonded pdb=" CD2 TYR A  41 "
          pdb=" CD1 TYR A  34 "
   model   vdw sym.op.
   4.607 3.640 -x+1,y,-z+1
nonbonded pdb=" CD1 TYR A  34 "
          pdb=" CD2 TYR A  41 "
   model   vdw sym.op.
   4.607 3.640 -x+1,y,-z+1
nonbonded pdb=" O   THR A  62 "
          pdb=" N   LEU A  83 "
   model   vdw
   4.607 3.120
nonbonded pdb=" CB  TYR A  34 "
          pdb=" C   PRO A  42 "
   model   vdw
   4.607 3.670
nonbonded pdb=" CD  GLU A   5 "
          pdb=" N   ILE A   6 "
   model   vdw
   4.607 3.350
nonbonded pdb=" CD1 LEU A  32 "
          pdb="O    HOH S  23 "
   model   vdw
   4.607 3.460
nonbonded pdb=" O   ASN A  29 "
          pdb=" C   ILE A  47 "
   model   vdw
   4.607 3.270
nonbonded pdb=" N   HIS A  64 "
          pdb=" CD2 HIS A  64 "
   model   vdw
   4.607 3.340
nonbonded pdb=" O   PHE A  73 "
          pdb=" CA  SER A  75 "
   model   vdw
   4.608 3.470
nonbonded pdb=" O   LEU A  60 "
          pdb=" CG  LEU A  60 "
   model   vdw
   4.608 3.470
nonbonded pdb=" CA  LEU A  76 "
          pdb=" O   MSE A  77 "
   model   vdw
   4.608 3.470
nonbonded pdb=" CA  ALA A  11 "
          pdb=" CB  GLN A  12 "
   model   vdw
   4.608 3.870
nonbonded pdb=" CB  LYS A   7 "
          pdb=" N   GLN A  10 "
   model   vdw
   4.608 3.520
nonbonded pdb=" O   LEU A  60 "
          pdb=" CE2 TYR A  61 "
   model   vdw
   4.608 3.340
nonbonded pdb=" CD  GLU A   5 "
          pdb=" O   GLY A  59 "
   model   vdw
   4.609 3.270
nonbonded pdb=" NH2 ARG A  16 "
          pdb=" CA  GLY A  59 "
   model   vdw sym.op.
   4.610 3.520 x,y-1,z
nonbonded pdb=" O   GLU A   5 "
          pdb=" CD1 TYR A  34 "
   model   vdw
   4.610 3.340
nonbonded pdb=" CB  VAL A   4 "
          pdb=" CA  GLU A   5 "
   model   vdw
   4.610 3.900
nonbonded pdb=" CB  LYS A   7 "
          pdb="O    HOH S  12 "
   model   vdw
   4.610 3.440
nonbonded pdb=" CB  LYS A  69 "
          pdb=" O   VAL A  70 "
   model   vdw
   4.610 3.440
nonbonded pdb=" CG2 THR A  14 "
          pdb=" CD  PRO A  58 "
   model   vdw sym.op.
   4.611 3.860 -x+1/2,y-1/2,-z+1
nonbonded pdb=" CA  TYR A  61 "
          pdb=" C   THR A  62 "
   model   vdw
   4.611 3.700
nonbonded pdb=" CD2 LEU A  28 "
          pdb=" CB  PRO A  85 "
   model   vdw sym.op.
   4.611 3.860 x,y-1,z
nonbonded pdb=" CA  GLU A  30 "
          pdb=" CB  GLN A  31 "
   model   vdw
   4.611 3.870
nonbonded pdb=" CG  TYR A  56 "
          pdb=" N   ALA A  57 "
   model   vdw
   4.611 3.340
nonbonded pdb=" O   ILE A  47 "
          pdb=" CG1 ILE A  47 "
   model   vdw
   4.611 3.440
nonbonded pdb=" N   VAL A  70 "
          pdb=" CA  GLY A  71 "
   model   vdw
   4.612 3.520
nonbonded pdb=" CD1 TYR A  56 "
          pdb=" CD2 TYR A  61 "
   model   vdw
   4.612 3.640
nonbonded pdb=" O   VAL A  35 "
          pdb=" CG2 VAL A  35 "
   model   vdw
   4.612 3.460
nonbonded pdb=" CB  PHE A  13 "
          pdb=" CB  GLN A  31 "
   model   vdw
   4.613 3.840
nonbonded pdb=" N   VAL A  35 "
          pdb=" CG2 VAL A  43 "
   model   vdw
   4.613 3.540
nonbonded pdb=" C   TYR A  61 "
          pdb=" N   VAL A  63 "
   model   vdw
   4.613 3.350
nonbonded pdb=" O   ALA A  57 "
          pdb=" CE2 TYR A  61 "
   model   vdw
   4.613 3.340
nonbonded pdb=" OD1 ASP A  50 "
          pdb=" CG  ARG A  80 "
   model   vdw
   4.613 3.440
nonbonded pdb=" CA  SER A   9 "
          pdb="O    HOH S  23 "
   model   vdw
   4.614 3.470
nonbonded pdb=" CA  SER A  66 "
          pdb=" CD  ARG A  82 "
   model   vdw
   4.615 3.870
nonbonded pdb=" CA  PHE A  68 "
          pdb=" C   MSE A  77 "
   model   vdw
   4.615 3.700
nonbonded pdb=" CA  THR A  14 "
          pdb=" CB  THR A  15 "
   model   vdw
   4.615 3.900
nonbonded pdb=" C   TYR A  56 "
          pdb=" CD1 TYR A  56 "
   model   vdw
   4.615 3.570
nonbonded pdb=" CB  LEU A  76 "
          pdb=" CD1 ILE A  78 "
   model   vdw sym.op.
   4.616 3.860 -x+1,y,-z+2
nonbonded pdb=" CD  LYS A   7 "
          pdb=" N   PRO A   8 "
   model   vdw
   4.616 3.520
nonbonded pdb=" CA  TYR A  34 "
          pdb=" C   VAL A  35 "
   model   vdw
   4.616 3.700
nonbonded pdb=" C   ASN A  39 "
          pdb=" C   TYR A  41 "
   model   vdw
   4.616 3.500
nonbonded pdb=" CD  GLN A  72 "
          pdb=" CB  LYS A   3 "
   model   vdw sym.op.
   4.617 3.670 -x+1,y-1,-z+2
nonbonded pdb=" CB  LYS A   3 "
          pdb=" CD  GLN A  72 "
   model   vdw sym.op.
   4.617 3.670 -x+1,y+1,-z+2
nonbonded pdb=" O   VAL A   4 "
          pdb=" N   ILE A   6 "
   model   vdw
   4.618 3.120
nonbonded pdb=" N   ILE A  47 "
          pdb="O    HOH S   6 "
   model   vdw sym.op.
   4.618 3.120 -x+1,y,-z+2
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" CA  LYS A   7 "
   model   vdw
   4.618 3.890
nonbonded pdb=" C   LYS A   3 "
          pdb=" CA  VAL A  35 "
   model   vdw
   4.618 3.700
nonbonded pdb=" O   VAL A  35 "
          pdb=" CB  LEU A  37 "
   model   vdw
   4.619 3.440
nonbonded pdb=" CB  CYS A  33 "
          pdb=" C   TYR A  34 "
   model   vdw
   4.619 3.670
nonbonded pdb=" CG  LYS A   3 "
          pdb=" CZ  PHE A  73 "
   model   vdw sym.op.
   4.619 3.740 -x+1,y+1,-z+2
nonbonded pdb=" O   LYS A   7 "
          pdb=" CA  PRO A  58 "
   model   vdw
   4.620 3.470
nonbonded pdb=" CB  LYS A  69 "
          pdb=" O   MSE A  77 "
   model   vdw
   4.621 3.440
nonbonded pdb=" CA  ALA A  11 "
          pdb=" O   GLN A  12 "
   model   vdw
   4.621 3.470
nonbonded pdb=" CA  TYR A  26 "
          pdb=" C   SER A  27 "
   model   vdw
   4.621 3.700
nonbonded pdb=" CA  CYS A  33 "
          pdb=" C   TYR A  34 "
   model   vdw
   4.621 3.700
nonbonded pdb=" CG2 THR A  48 "
          pdb=" C   LEU A  49 "
   model   vdw
   4.622 3.690
nonbonded pdb=" CG1 ILE A   6 "
          pdb=" CZ  TYR A  61 "
   model   vdw
   4.622 3.660
nonbonded pdb=" CA  LEU A  83 "
          pdb=" C   VAL A  84 "
   model   vdw
   4.622 3.700
nonbonded pdb=" C   TYR A  41 "
          pdb=" CD1 TYR A  41 "
   model   vdw
   4.622 3.570
nonbonded pdb=" CA  PRO A  42 "
          pdb=" C   VAL A  43 "
   model   vdw
   4.622 3.700
nonbonded pdb=" CA  PRO A   8 "
          pdb=" C   SER A   9 "
   model   vdw
   4.622 3.700
nonbonded pdb=" N   ARG A  82 "
          pdb=" CA  LEU A  83 "
   model   vdw
   4.622 3.550
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" CA  ALA A  11 "
   model   vdw
   4.623 3.890
nonbonded pdb=" C   ASP A  36 "
          pdb=" CG  LEU A  65 "
   model   vdw sym.op.
   4.623 3.700 -x+1,y,-z+2
nonbonded pdb=" C   ASP A  36 "
          pdb=" CD1 LEU A  65 "
   model   vdw sym.op.
   4.623 3.690 -x+1,y,-z+2
nonbonded pdb=" C   LEU A  49 "
          pdb=" CD  GLN A  53 "
   model   vdw
   4.623 3.500
nonbonded pdb=" C   ASN A  39 "
          pdb=" CD  GLU A  40 "
   model   vdw
   4.624 3.500
nonbonded pdb=" CD  GLN A  10 "
          pdb=" CA  LEU A  32 "
   model   vdw
   4.624 3.700
nonbonded pdb=" CA  GLY A  52 "
          pdb=" CB  GLN A  53 "
   model   vdw
   4.624 3.840
nonbonded pdb="O    HOH S  25 "
          pdb=" CB  VAL A  70 "
   model   vdw sym.op.
   4.625 3.470 -x+1,y,-z+2
nonbonded pdb=" CB  VAL A  70 "
          pdb="O    HOH S  25 "
   model   vdw sym.op.
   4.625 3.470 -x+1,y,-z+2
nonbonded pdb=" O   LEU A  60 "
          pdb=" O   VAL A  84 "
   model   vdw
   4.625 3.040
nonbonded pdb=" N   ALA A  11 "
          pdb=" O   GLN A  12 "
   model   vdw
   4.625 3.120
nonbonded pdb=" N   LYS A  46 "
          pdb=" N   SER A  75 "
   model   vdw sym.op.
   4.625 3.200 -x+1,y,-z+2
nonbonded pdb=" CG  LYS A  69 "
          pdb=" CA  ASP A  79 "
   model   vdw
   4.625 3.870
nonbonded pdb=" CG  TYR A  56 "
          pdb=" CE2 TYR A  61 "
   model   vdw
   4.625 3.560
nonbonded pdb=" CE  LYS A  69 "
          pdb=" N   VAL A  70 "
   model   vdw
   4.625 3.520
nonbonded pdb=" CG1 ILE A  47 "
          pdb=" CG  LEU A  81 "
   model   vdw
   4.626 3.870
nonbonded pdb=" CE2 TYR A  34 "
          pdb=" CB  LEU A  44 "
   model   vdw
   4.626 3.740
nonbonded pdb=" O   LEU A  83 "
          pdb=" O   VAL A  84 "
   model   vdw
   4.626 3.040
nonbonded pdb=" O   VAL A   4 "
          pdb=" CG  LEU A  60 "
   model   vdw
   4.627 3.470
nonbonded pdb=" CD2 TYR A  34 "
          pdb="O    HOH S  26 "
   model   vdw
   4.627 3.340
nonbonded pdb=" OG  SER A  75 "
          pdb=" C   LEU A  76 "
   model   vdw
   4.627 3.270
nonbonded pdb=" CB  VAL A  63 "
          pdb=" CA  HIS A  64 "
   model   vdw
   4.627 3.900
nonbonded pdb=" C   PRO A  58 "
          pdb=" CE1 TYR A  61 "
   model   vdw
   4.627 3.570
nonbonded pdb=" C   LEU A  65 "
          pdb=" C   SER A  67 "
   model   vdw
   4.627 3.500
nonbonded pdb=" CB  ILE A   6 "
          pdb=" O   LYS A   7 "
   model   vdw
   4.627 3.470
nonbonded pdb=" C   GLU A  51 "
          pdb=" CB  GLN A  53 "
   model   vdw
   4.627 3.670
nonbonded pdb=" CD1 LEU A  76 "
          pdb=" O   MSE A  77 "
   model   vdw
   4.628 3.460
nonbonded pdb=" CB  LEU A  37 "
          pdb=" CG2 VAL A  43 "
   model   vdw
   4.628 3.860
nonbonded pdb=" CB  SER A  67 "
          pdb=" O   ARG A  82 "
   model   vdw
   4.628 3.440
nonbonded pdb=" CA  VAL A   4 "
          pdb=" C   TYR A  61 "
   model   vdw
   4.628 3.700
nonbonded pdb=" CA  LYS A  46 "
          pdb=" C   ILE A  47 "
   model   vdw
   4.628 3.700
nonbonded pdb=" CA  LEU A  83 "
          pdb=" O   VAL A  84 "
   model   vdw
   4.628 3.470
nonbonded pdb=" CA  TYR A  26 "
          pdb=" CE1 TYR A  26 "
   model   vdw
   4.628 3.770
nonbonded pdb=" CG  LEU A  37 "
          pdb=" CD1 LEU A  76 "
   model   vdw sym.op.
   4.628 3.890 -x+1,y,-z+2
nonbonded pdb=" CD1 LEU A  76 "
          pdb=" CG  LEU A  37 "
   model   vdw sym.op.
   4.628 3.890 -x+1,y,-z+2
nonbonded pdb=" N   TYR A  56 "
          pdb=" CA  ALA A  57 "
   model   vdw
   4.628 3.550
nonbonded pdb=" ND1 HIS A  64 "
          pdb=" CB  LEU A  65 "
   model   vdw
   4.629 3.520
nonbonded pdb=" CB  VAL A  63 "
          pdb="O    HOH S  19 "
   model   vdw
   4.630 3.470
nonbonded pdb=" O   LYS A   3 "
          pdb=" O   ASP A  36 "
   model   vdw
   4.630 3.040
nonbonded pdb=" N   TYR A  41 "
          pdb=" CE2 TYR A  41 "
   model   vdw
   4.630 3.420
nonbonded pdb=" OE1 GLN A  72 "
          pdb=" CB  LYS A   3 "
   model   vdw sym.op.
   4.630 3.440 -x+1,y-1,-z+2
nonbonded pdb=" CB  LYS A   3 "
          pdb=" OE1 GLN A  72 "
   model   vdw sym.op.
   4.630 3.440 -x+1,y+1,-z+2
nonbonded pdb=" CB  VAL A  35 "
          pdb=" CG2 VAL A  43 "
   model   vdw
   4.630 3.890
nonbonded pdb=" N   GLN A  31 "
          pdb=" CA  ILE A  47 "
   model   vdw
   4.630 3.550
nonbonded pdb=" NE2 GLN A  53 "
          pdb=" CD1 TYR A  56 "
   model   vdw
   4.630 3.420
nonbonded pdb=" C   PRO A  58 "
          pdb=" OH  TYR A  61 "
   model   vdw
   4.630 3.270
nonbonded pdb=" CB  PHE A  13 "
          pdb=" C   THR A  14 "
   model   vdw
   4.631 3.670
nonbonded pdb=" CE2 TYR A  61 "
          pdb="O    HOH S   7 "
   model   vdw
   4.631 3.340
nonbonded pdb=" CA  GLN A  10 "
          pdb=" C   ALA A  11 "
   model   vdw
   4.631 3.700
nonbonded pdb=" C   VAL A   4 "
          pdb=" CB  TYR A  61 "
   model   vdw
   4.631 3.670
nonbonded pdb=" O   TYR A  41 "
          pdb=" CG1 VAL A  43 "
   model   vdw
   4.631 3.460
nonbonded pdb=" CA  TYR A  61 "
          pdb=" CB  THR A  62 "
   model   vdw
   4.632 3.900
nonbonded pdb=" OG1 THR A  15 "
          pdb=" CA  ASN A  29 "
   model   vdw
   4.632 3.470
nonbonded pdb=" N   SER A  66 "
          pdb=" CB  SER A  67 "
   model   vdw
   4.633 3.520
nonbonded pdb=" CA  LYS A   3 "
          pdb=" CG2 VAL A   4 "
   model   vdw
   4.633 3.890
nonbonded pdb=" CA  CYS A  33 "
          pdb=" CD1 TYR A  34 "
   model   vdw
   4.633 3.770
nonbonded pdb=" CG  PHE A  13 "
          pdb=" CB  ALA A  55 "
   model   vdw
   4.633 3.680
nonbonded pdb=" CA  PHE A  68 "
          pdb=" O   LYS A  69 "
   model   vdw
   4.634 3.470
nonbonded pdb=" C   TYR A  34 "
          pdb=" CD2 TYR A  34 "
   model   vdw
   4.634 3.570
nonbonded pdb=" O   LEU A  49 "
          pdb=" CD  ARG A  80 "
   model   vdw
   4.634 3.440
nonbonded pdb=" N   ILE A   6 "
          pdb=" CD1 TYR A  61 "
   model   vdw
   4.634 3.420
nonbonded pdb=" C   PHE A  73 "
          pdb=" CA  SER A  75 "
   model   vdw
   4.634 3.700
nonbonded pdb=" CG  GLU A  51 "
          pdb=" N   GLY A  52 "
   model   vdw
   4.635 3.520
nonbonded pdb=" CA  LYS A   3 "
          pdb=" C   VAL A   4 "
   model   vdw
   4.636 3.700
nonbonded pdb=" O   LEU A  83 "
          pdb=" CG2 VAL A  84 "
   model   vdw
   4.636 3.460
nonbonded pdb=" CA  VAL A  45 "
          pdb=" C   LYS A  46 "
   model   vdw
   4.636 3.700
nonbonded pdb=" CG1 VAL A  63 "
          pdb=" CE2 PHE A  68 "
   model   vdw
   4.636 3.760
nonbonded pdb=" CE  LYS A  46 "
          pdb=" O   PHE A  73 "
   model   vdw sym.op.
   4.636 3.440 -x+1,y,-z+2
nonbonded pdb=" CA  LYS A  46 "
          pdb=" C   GLY A  74 "
   model   vdw sym.op.
   4.636 3.700 -x+1,y,-z+2
nonbonded pdb=" CG  PRO A  42 "
          pdb=" N   VAL A  43 "
   model   vdw
   4.636 3.520
nonbonded pdb=" C   HIS A  64 "
          pdb=" CD1 PHE A  68 "
   model   vdw
   4.637 3.570
nonbonded pdb=" CA  ILE A  47 "
          pdb=" OG1 THR A  48 "
   model   vdw
   4.637 3.470
nonbonded pdb=" O   LYS A   3 "
          pdb=" CD  LYS A   3 "
   model   vdw
   4.637 3.440
nonbonded pdb=" O   LEU A  83 "
          pdb=" CG  LEU A  83 "
   model   vdw
   4.637 3.470
nonbonded pdb=" CG2 VAL A   4 "
          pdb=" N   GLU A   5 "
   model   vdw
   4.638 3.540
nonbonded pdb=" CB  PHE A  73 "
          pdb=" OG  SER A  75 "
   model   vdw
   4.638 3.440
nonbonded pdb=" CA  SER A   9 "
          pdb=" CB  GLN A  10 "
   model   vdw
   4.638 3.870
nonbonded pdb=" N   ALA A  11 "
          pdb="O    HOH S   8 "
   model   vdw
   4.638 3.120
nonbonded pdb=" CA  GLU A   5 "
          pdb=" CA  LEU A  60 "
   model   vdw
   4.639 3.900
nonbonded pdb=" O   PRO A   8 "
          pdb=" O   PHE A  13 "
   model   vdw sym.op.
   4.639 3.040 -x+1/2,y+1/2,-z+1
nonbonded pdb=" OG1 THR A  14 "
          pdb=" CA  GLU A  30 "
   model   vdw
   4.639 3.470
nonbonded pdb=" CA  SER A   9 "
          pdb=" C   GLN A  10 "
   model   vdw
   4.639 3.700
nonbonded pdb=" CB  SER A  67 "
          pdb=" CA  PHE A  68 "
   model   vdw
   4.639 3.870
nonbonded pdb=" CA  LEU A  76 "
          pdb=" C   MSE A  77 "
   model   vdw
   4.639 3.700
nonbonded pdb=" CD1 ILE A   6 "
          pdb=" CG  TYR A  56 "
   model   vdw
   4.640 3.680
nonbonded pdb=" O   TYR A  26 "
          pdb=" CE2 TYR A  26 "
   model   vdw
   4.640 3.340
nonbonded pdb=" NE2 GLN A  31 "
          pdb=" O   LEU A  32 "
   model   vdw
   4.640 3.120
nonbonded pdb=" CD  GLU A  30 "
          pdb=" CG  LYS A  46 "
   model   vdw
   4.640 3.670
nonbonded pdb=" CD  PRO A  54 "
          pdb=" N   ALA A  55 "
   model   vdw
   4.640 3.520
nonbonded pdb=" C   LEU A  81 "
          pdb=" CD2 LEU A  81 "
   model   vdw
   4.641 3.690
nonbonded pdb=" O   LYS A   3 "
          pdb=" C   TYR A  34 "
   model   vdw
   4.641 3.270
nonbonded pdb=" CD  GLN A  10 "
          pdb=" N   TYR A  34 "
   model   vdw
   4.642 3.350
nonbonded pdb=" CA  LYS A   7 "
          pdb=" CG  GLN A  10 "
   model   vdw
   4.642 3.870
nonbonded pdb=" O   PHE A  13 "
          pdb=" OG1 THR A  14 "
   model   vdw
   4.642 3.040
nonbonded pdb=" CG  LEU A  81 "
          pdb="O    HOH S   6 "
   model   vdw sym.op.
   4.642 3.470 -x+1,y,-z+2
nonbonded pdb=" N   SER A  27 "
          pdb=" CA  LEU A  28 "
   model   vdw
   4.642 3.550
nonbonded pdb=" N   GLY A  52 "
          pdb=" CB  GLN A  53 "
   model   vdw
   4.642 3.520
nonbonded pdb=" CG2 VAL A   4 "
          pdb=" O   TYR A  61 "
   model   vdw
   4.643 3.460
nonbonded pdb=" CA  PHE A  68 "
          pdb=" CB  LYS A  69 "
   model   vdw
   4.643 3.870
nonbonded pdb=" CB  SER A  67 "
          pdb=" CA  ARG A  82 "
   model   vdw
   4.643 3.870
nonbonded pdb=" CB  ASN A  39 "
          pdb=" C   GLU A  40 "
   model   vdw
   4.643 3.670
nonbonded pdb=" CG  ARG A  82 "
          pdb=" NH2 ARG A  82 "
   model   vdw
   4.644 3.520
nonbonded pdb=" N   SER A  17 "
          pdb=" O   TYR A  26 "
   model   vdw
   4.644 3.120
nonbonded pdb=" CE2 TYR A  41 "
          pdb=" CD  PRO A  42 "
   model   vdw sym.op.
   4.645 3.740 -x+1,y,-z+1
nonbonded pdb=" CD  PRO A  42 "
          pdb=" CE2 TYR A  41 "
   model   vdw sym.op.
   4.645 3.740 -x+1,y,-z+1
nonbonded pdb=" O   VAL A  43 "
          pdb=" CG1 VAL A  43 "
   model   vdw
   4.645 3.460
nonbonded pdb=" CB  LYS A   3 "
          pdb=" NZ  LYS A   3 "
   model   vdw
   4.645 3.520
nonbonded pdb=" CB  PRO A  58 "
          pdb=" CA  GLY A  59 "
   model   vdw
   4.646 3.840
nonbonded pdb=" C   VAL A  43 "
          pdb="O    HOH S  25 "
   model   vdw
   4.646 3.270
nonbonded pdb=" CG  PHE A  13 "
          pdb=" CA  THR A  14 "
   model   vdw
   4.646 3.690
nonbonded pdb=" CB  ILE A   2 "
          pdb=" CA  LYS A   3 "
   model   vdw
   4.646 3.900
nonbonded pdb=" NE2 GLN A  72 "
          pdb="O    HOH S   5 "
   model   vdw sym.op.
   4.647 3.120 -x+1,y-1,-z+2
nonbonded pdb=" N   LEU A  32 "
          pdb=" O   VAL A  45 "
   model   vdw
   4.647 3.120
nonbonded pdb=" N   ARG A  80 "
          pdb=" CD  ARG A  80 "
   model   vdw
   4.647 3.520
nonbonded pdb=" C   ASN A  29 "
          pdb=" CD1 LEU A  49 "
   model   vdw
   4.647 3.690
nonbonded pdb=" CD  ARG A  80 "
          pdb=" CZ  ARG A  82 "
   model   vdw
   4.648 3.670
nonbonded pdb=" C   LYS A  46 "
          pdb=" O   GLY A  74 "
   model   vdw sym.op.
   4.648 3.270 -x+1,y,-z+2
nonbonded pdb=" O   ARG A  16 "
          pdb=" OG  SER A  17 "
   model   vdw
   4.648 3.040
nonbonded pdb=" NE2 GLN A  72 "
          pdb=" NZ  LYS A   3 "
   model   vdw sym.op.
   4.648 3.200 -x+1,y-1,-z+2
nonbonded pdb=" NZ  LYS A   3 "
          pdb=" NE2 GLN A  72 "
   model   vdw sym.op.
   4.648 3.200 -x+1,y+1,-z+2
nonbonded pdb=" CA  LEU A  44 "
          pdb=" CB  VAL A  45 "
   model   vdw
   4.648 3.900
nonbonded pdb=" C   LEU A  65 "
          pdb=" CB  SER A  67 "
   model   vdw
   4.649 3.670
nonbonded pdb=" CB  LYS A  46 "
          pdb="O    HOH S  38 "
   model   vdw
   4.649 3.440
nonbonded pdb=" CB  GLU A  30 "
          pdb=" CE  LYS A  46 "
   model   vdw
   4.649 3.840
nonbonded pdb=" O   ASN A  39 "
          pdb=" OE1 GLU A  40 "
   model   vdw
   4.650 3.040
nonbonded pdb=" O   ILE A   2 "
          pdb=" N   THR A  62 "
   model   vdw
   4.650 3.120
nonbonded pdb=" CD  LYS A   7 "
          pdb=" CB  GLU A  40 "
   model   vdw sym.op.
   4.651 3.840 -x+1,y,-z+1
nonbonded pdb=" O   LYS A   3 "
          pdb=" CG2 VAL A  35 "
   model   vdw
   4.651 3.460
nonbonded pdb=" O   LEU A  32 "
          pdb=" CG  LEU A  32 "
   model   vdw
   4.651 3.470
nonbonded pdb=" CA  LEU A  32 "
          pdb=" C   VAL A  45 "
   model   vdw
   4.651 3.700
nonbonded pdb=" CG  LYS A  69 "
          pdb=" O   VAL A  70 "
   model   vdw
   4.651 3.440
nonbonded pdb=" CG  PRO A  58 "
          pdb=" N   GLY A  59 "
   model   vdw
   4.651 3.520
nonbonded pdb=" CB  VAL A  35 "
          pdb=" CA  ASP A  36 "
   model   vdw
   4.652 3.900
nonbonded pdb=" O   VAL A  45 "
          pdb=" CG2 VAL A  45 "
   model   vdw
   4.652 3.460
nonbonded pdb=" O   TYR A  61 "
          pdb=" CG  TYR A  61 "
   model   vdw
   4.653 3.260
nonbonded pdb=" O   TYR A  26 "
          pdb=" CZ  TYR A  26 "
   model   vdw
   4.653 3.260
nonbonded pdb=" CB  LYS A   7 "
          pdb=" CB  GLN A  10 "
   model   vdw
   4.653 3.840
nonbonded pdb=" CG  LEU A  49 "
          pdb=" O   PRO A  54 "
   model   vdw
   4.653 3.470
nonbonded pdb=" CA  ASN A  29 "
          pdb=" CG  GLU A  30 "
   model   vdw
   4.655 3.870
nonbonded pdb=" N   PHE A  68 "
          pdb=" N   ASP A  79 "
   model   vdw
   4.655 3.200
nonbonded pdb=" O   LEU A  49 "
          pdb=" CG  LEU A  49 "
   model   vdw
   4.656 3.470
nonbonded pdb=" CA  LYS A  46 "
          pdb=" CB  ILE A  47 "
   model   vdw
   4.656 3.900
nonbonded pdb=" CG1 VAL A  70 "
          pdb=" C   GLY A  71 "
   model   vdw
   4.656 3.690
nonbonded pdb=" C   THR A  14 "
          pdb=" CG2 THR A  15 "
   model   vdw
   4.656 3.690
nonbonded pdb=" O   LYS A   7 "
          pdb=" CB  SER A   9 "
   model   vdw
   4.657 3.440
nonbonded pdb=" O   HIS A  64 "
          pdb=" C   SER A  67 "
   model   vdw
   4.657 3.270
nonbonded pdb=" C   GLN A  31 "
          pdb=" CA  ILE A  47 "
   model   vdw
   4.657 3.700
nonbonded pdb=" O   PHE A  68 "
          pdb=" CG  LYS A  69 "
   model   vdw
   4.658 3.440
nonbonded pdb=" CG  GLU A   5 "
          pdb=" CG  LEU A  60 "
   model   vdw
   4.658 3.870
nonbonded pdb=" C   PHE A  68 "
          pdb=" N   VAL A  70 "
   model   vdw
   4.658 3.350
nonbonded pdb=" O   GLU A  30 "
          pdb=" CG  GLN A  31 "
   model   vdw
   4.658 3.440
nonbonded pdb=" CA  GLN A  53 "
          pdb=" CB  PRO A  54 "
   model   vdw
   4.658 3.870
nonbonded pdb=" CA  ALA A  11 "
          pdb=" C   GLN A  12 "
   model   vdw
   4.659 3.700
nonbonded pdb=" N   TYR A  61 "
          pdb=" O   VAL A  84 "
   model   vdw
   4.659 3.120
nonbonded pdb=" CB  ILE A   6 "
          pdb=" O   TYR A  56 "
   model   vdw
   4.659 3.470
nonbonded pdb=" CA  TYR A  61 "
          pdb=" CE1 TYR A  61 "
   model   vdw
   4.660 3.770
nonbonded pdb=" CA  TYR A  34 "
          pdb=" CE2 TYR A  34 "
   model   vdw
   4.660 3.770
nonbonded pdb=" C   GLU A  30 "
          pdb=" CG  GLN A  31 "
   model   vdw
   4.660 3.670
nonbonded pdb=" CG  LYS A   3 "
          pdb=" CB  ASP A  36 "
   model   vdw
   4.660 3.840
nonbonded pdb=" C   CYS A  33 "
          pdb=" CE1 TYR A  34 "
   model   vdw
   4.660 3.570
nonbonded pdb=" CB  GLN A  53 "
          pdb=" CA  PRO A  54 "
   model   vdw
   4.660 3.870
nonbonded pdb=" CB  ARG A  16 "
          pdb=" CA  SER A  17 "
   model   vdw
   4.661 3.870
nonbonded pdb=" CA  GLY A  74 "
          pdb=" O   SER A  75 "
   model   vdw
   4.661 3.440
nonbonded pdb=" O   LEU A  81 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   4.661 3.460
nonbonded pdb=" CZ  TYR A  41 "
          pdb=" CD1 TYR A  34 "
   model   vdw sym.op.
   4.661 3.560 -x+1,y,-z+1
nonbonded pdb=" CD1 TYR A  34 "
          pdb=" CZ  TYR A  41 "
   model   vdw sym.op.
   4.661 3.560 -x+1,y,-z+1
nonbonded pdb=" C   VAL A   4 "
          pdb=" O   GLY A  59 "
   model   vdw
   4.661 3.270
nonbonded pdb=" SG  CYS A  33 "
          pdb=" N   VAL A  45 "
   model   vdw
   4.661 3.480
nonbonded pdb=" CB  LYS A   7 "
          pdb=" OE1 GLU A  40 "
   model   vdw sym.op.
   4.661 3.440 -x+1,y,-z+1
nonbonded pdb=" CA  ILE A   2 "
          pdb=" C   LYS A   3 "
   model   vdw
   4.661 3.700
nonbonded pdb=" C   GLU A  40 "
          pdb=" CD  GLU A  40 "
   model   vdw
   4.661 3.500
nonbonded pdb=" C   GLY A  71 "
          pdb="SE   MSE A  77 "
   model   vdw
   4.662 3.650
nonbonded pdb=" CG2 VAL A  35 "
          pdb=" N   ASP A  36 "
   model   vdw
   4.662 3.540
nonbonded pdb=" C   THR A  48 "
          pdb=" CG  ARG A  80 "
   model   vdw
   4.662 3.670
nonbonded pdb=" N   ASP A  36 "
          pdb=" CA  LEU A  37 "
   model   vdw
   4.663 3.550
nonbonded pdb=" O   ASN A  29 "
          pdb=" O   GLU A  30 "
   model   vdw
   4.663 3.040
nonbonded pdb=" C   ASN A  29 "
          pdb=" CA  THR A  48 "
   model   vdw
   4.663 3.700
nonbonded pdb=" CD1 ILE A  78 "
          pdb=" CD1 LEU A  81 "
   model   vdw
   4.663 3.880
nonbonded pdb=" CA  ASP A  50 "
          pdb=" CB  GLU A  51 "
   model   vdw
   4.663 3.870
nonbonded pdb=" N   LYS A   3 "
          pdb=" CZ  PHE A  73 "
   model   vdw sym.op.
   4.663 3.420 -x+1,y+1,-z+2
nonbonded pdb=" CG1 ILE A   6 "
          pdb=" NE2 GLN A  31 "
   model   vdw
   4.664 3.520
nonbonded pdb=" CA  PHE A  68 "
          pdb=" CE2 PHE A  68 "
   model   vdw
   4.664 3.770
nonbonded pdb=" N   GLN A  53 "
          pdb="O    HOH S  20 "
   model   vdw
   4.664 3.120
nonbonded pdb=" O   TYR A  26 "
          pdb=" N   LEU A  28 "
   model   vdw
   4.664 3.120
nonbonded pdb=" CA  SER A   9 "
          pdb=" CG  GLN A  10 "
   model   vdw
   4.665 3.870
nonbonded pdb=" N   GLU A  40 "
          pdb=" C   TYR A  41 "
   model   vdw
   4.665 3.350
nonbonded pdb=" CA  THR A  62 "
          pdb=" C   VAL A  63 "
   model   vdw
   4.665 3.700
nonbonded pdb=" CG  TYR A  56 "
          pdb=" CG  LEU A  83 "
   model   vdw
   4.665 3.690
nonbonded pdb=" CA  SER A  27 "
          pdb=" CB  LEU A  28 "
   model   vdw
   4.666 3.870
nonbonded pdb=" CG  LEU A  76 "
          pdb=" CA  MSE A  77 "
   model   vdw
   4.666 3.900
nonbonded pdb=" CD1 ILE A  47 "
          pdb=" CG  LEU A  81 "
   model   vdw
   4.666 3.890
nonbonded pdb=" CB  PRO A  42 "
          pdb=" O   VAL A  43 "
   model   vdw
   4.667 3.440
nonbonded pdb=" CA  LYS A  69 "
          pdb=" CD1 LEU A  76 "
   model   vdw
   4.667 3.890
nonbonded pdb=" CD1 ILE A  78 "
          pdb="O    HOH S  13 "
   model   vdw sym.op.
   4.668 3.460 -x+1,y,-z+2
nonbonded pdb=" CD1 ILE A  78 "
          pdb="O    HOH S  13 "
   model   vdw
   4.668 3.460
nonbonded pdb=" O   GLN A  31 "
          pdb=" CG1 ILE A  47 "
   model   vdw
   4.668 3.440
nonbonded pdb=" CD2 LEU A  32 "
          pdb=" CD1 LEU A  44 "
   model   vdw
   4.668 3.880
nonbonded pdb=" CG  TYR A  61 "
          pdb=" N   PRO A  85 "
   model   vdw
   4.668 3.340
nonbonded pdb=" O   GLU A   5 "
          pdb=" CD1 ILE A   6 "
   model   vdw
   4.668 3.460
nonbonded pdb=" CB  LEU A  76 "
          pdb=" CD2 LEU A  81 "
   model   vdw sym.op.
   4.668 3.860 -x+1,y,-z+2
nonbonded pdb=" O   GLY A  71 "
          pdb=" C   GLY A  74 "
   model   vdw
   4.669 3.270
nonbonded pdb=" CA  GLN A  10 "
          pdb=" O   LEU A  32 "
   model   vdw
   4.669 3.470
nonbonded pdb=" CA  ASP A  79 "
          pdb=" C   ARG A  80 "
   model   vdw
   4.669 3.700
nonbonded pdb=" C   GLN A  31 "
          pdb=" CG  LYS A  46 "
   model   vdw
   4.669 3.670
nonbonded pdb=" CB  ARG A  80 "
          pdb=" CA  LEU A  81 "
   model   vdw
   4.669 3.870
nonbonded pdb=" C   TYR A  61 "
          pdb=" CD1 TYR A  61 "
   model   vdw
   4.670 3.570
nonbonded pdb=" CB  ASP A  50 "
          pdb=" CD  GLU A  51 "
   model   vdw
   4.671 3.670
nonbonded pdb=" C   GLU A  51 "
          pdb=" CD  GLU A  51 "
   model   vdw
   4.671 3.500
nonbonded pdb=" CA  PRO A  54 "
          pdb="O    HOH S  39 "
   model   vdw
   4.671 3.470
nonbonded pdb=" CA  ILE A   6 "
          pdb=" CA  PRO A  58 "
   model   vdw
   4.671 3.900
nonbonded pdb=" CG  ASP A  79 "
          pdb=" CZ  ARG A  82 "
   model   vdw
   4.672 3.500
nonbonded pdb=" CD  GLN A  12 "
          pdb=" N   PHE A  13 "
   model   vdw
   4.672 3.350
nonbonded pdb=" CA  GLN A  31 "
          pdb=" C   LEU A  32 "
   model   vdw
   4.673 3.700
nonbonded pdb=" C   THR A  14 "
          pdb=" OD1 ASN A  29 "
   model   vdw
   4.673 3.270
nonbonded pdb=" CB  GLN A  31 "
          pdb=" CD2 LEU A  49 "
   model   vdw
   4.674 3.860
nonbonded pdb=" CA  ASP A  50 "
          pdb=" O   GLU A  51 "
   model   vdw
   4.674 3.470
nonbonded pdb=" CD2 PHE A  68 "
          pdb=" CD2 LEU A  76 "
   model   vdw
   4.674 3.760
nonbonded pdb=" CG1 VAL A  70 "
          pdb=" CA  GLY A  71 "
   model   vdw
   4.674 3.860
nonbonded pdb=" CB  GLN A  72 "
          pdb=" CE  LYS A   3 "
   model   vdw sym.op.
   4.674 3.840 -x+1,y-1,-z+2
nonbonded pdb=" CE  LYS A   3 "
          pdb=" CB  GLN A  72 "
   model   vdw sym.op.
   4.674 3.840 -x+1,y+1,-z+2
nonbonded pdb=" CA  GLY A  74 "
          pdb=" C   SER A  75 "
   model   vdw
   4.674 3.670
nonbonded pdb=" CA  LYS A   7 "
          pdb=" CE  LYS A   7 "
   model   vdw
   4.674 3.870
nonbonded pdb=" O   GLN A  53 "
          pdb=" CD  GLN A  53 "
   model   vdw
   4.674 3.270
nonbonded pdb=" CA  SER A  67 "
          pdb=" CE1 PHE A  68 "
   model   vdw
   4.675 3.770
nonbonded pdb=" N   LEU A  81 "
          pdb=" CA  ARG A  82 "
   model   vdw
   4.675 3.550
nonbonded pdb=" OH  TYR A  56 "
          pdb=" CD1 LEU A  83 "
   model   vdw
   4.676 3.460
nonbonded pdb=" N   ILE A  78 "
          pdb=" CG1 ILE A  78 "
   model   vdw sym.op.
   4.676 3.520 -x+1,y,-z+2
nonbonded pdb=" CG1 ILE A  78 "
          pdb=" N   ILE A  78 "
   model   vdw sym.op.
   4.676 3.520 -x+1,y,-z+2
nonbonded pdb="O    HOH S  14 "
          pdb=" CB  SER A   9 "
   model   vdw sym.op.
   4.676 3.440 -x+1/2,y-1/2,-z+1
nonbonded pdb=" CB  SER A   9 "
          pdb="O    HOH S  14 "
   model   vdw sym.op.
   4.676 3.440 -x+1/2,y+1/2,-z+1
nonbonded pdb=" C   SER A  66 "
          pdb=" CZ  ARG A  82 "
   model   vdw
   4.676 3.500
nonbonded pdb=" CB  TYR A  56 "
          pdb=" CD1 LEU A  83 "
   model   vdw
   4.677 3.860
nonbonded pdb=" N   VAL A   4 "
          pdb=" CA  GLU A   5 "
   model   vdw
   4.677 3.550
nonbonded pdb=" C   VAL A  63 "
          pdb="O    HOH S  19 "
   model   vdw
   4.678 3.270
nonbonded pdb=" CA  TYR A  56 "
          pdb=" CB  ALA A  57 "
   model   vdw
   4.678 3.890
nonbonded pdb=" CB  LEU A  28 "
          pdb=" CG2 THR A  48 "
   model   vdw
   4.678 3.860
nonbonded pdb=" C   THR A  48 "
          pdb=" CD2 LEU A  49 "
   model   vdw
   4.678 3.690
nonbonded pdb=" CG2 ILE A  47 "
          pdb=" CA  LEU A  49 "
   model   vdw
   4.678 3.890
nonbonded pdb=" CA  PHE A  73 "
          pdb=" CE2 PHE A  73 "
   model   vdw
   4.679 3.770
nonbonded pdb=" OG1 THR A  48 "
          pdb=" N   LEU A  49 "
   model   vdw
   4.679 3.120
nonbonded pdb=" O   ASP A  50 "
          pdb=" CG  GLU A  51 "
   model   vdw
   4.679 3.440
nonbonded pdb=" CA  ALA A  57 "
          pdb=" CB  PRO A  58 "
   model   vdw
   4.680 3.870
nonbonded pdb=" CG2 ILE A   2 "
          pdb=" N   VAL A   4 "
   model   vdw
   4.680 3.540
nonbonded pdb=" CA  ARG A  82 "
          pdb=" CB  LEU A  83 "
   model   vdw
   4.680 3.870
nonbonded pdb=" O   ILE A  78 "
          pdb="O    HOH S   1 "
   model   vdw sym.op.
   4.680 3.040 -x,y+1,-z+1
nonbonded pdb=" O   LEU A  49 "
          pdb=" NE  ARG A  80 "
   model   vdw
   4.681 3.120
nonbonded pdb=" CG  PHE A  68 "
          pdb=" N   LYS A  69 "
   model   vdw
   4.681 3.340
nonbonded pdb=" CB  GLN A  10 "
          pdb=" NE2 GLN A  12 "
   model   vdw
   4.681 3.520
nonbonded pdb=" CA  THR A  14 "
          pdb=" C   THR A  15 "
   model   vdw
   4.681 3.700
nonbonded pdb=" CB  SER A   9 "
          pdb=" CG  GLN A  10 "
   model   vdw
   4.681 3.840
nonbonded pdb=" CD1 ILE A   2 "
          pdb=" CE1 PHE A  68 "
   model   vdw sym.op.
   4.682 3.760 -x+1,y,-z+2
nonbonded pdb=" CE1 PHE A  68 "
          pdb=" CD1 ILE A   2 "
   model   vdw sym.op.
   4.682 3.760 -x+1,y,-z+2
nonbonded pdb=" OE1 GLN A  53 "
          pdb=" CE2 TYR A  56 "
   model   vdw
   4.682 3.340
nonbonded pdb=" N   VAL A  35 "
          pdb=" CA  VAL A  43 "
   model   vdw
   4.682 3.550
nonbonded pdb=" CD  ARG A  16 "
          pdb=" CB  LEU A  28 "
   model   vdw
   4.682 3.840
nonbonded pdb=" O   HIS A  64 "
          pdb=" N   PHE A  68 "
   model   vdw
   4.682 3.120
nonbonded pdb=" N   VAL A   4 "
          pdb=" N   TYR A  61 "
   model   vdw
   4.682 3.200
nonbonded pdb=" CE  LYS A   7 "
          pdb=" O   GLU A  40 "
   model   vdw sym.op.
   4.682 3.440 -x+1,y,-z+1
nonbonded pdb=" O   THR A  14 "
          pdb=" CG2 THR A  14 "
   model   vdw
   4.682 3.460
nonbonded pdb=" CD  LYS A   7 "
          pdb=" OE2 GLU A  40 "
   model   vdw sym.op.
   4.683 3.440 -x+1,y,-z+1
nonbonded pdb=" N   VAL A  45 "
          pdb=" O   GLY A  74 "
   model   vdw sym.op.
   4.683 3.120 -x+1,y,-z+2
nonbonded pdb=" NH2 ARG A  16 "
          pdb=" N   TYR A  61 "
   model   vdw sym.op.
   4.683 3.200 x,y-1,z
nonbonded pdb=" CG  TYR A  26 "
          pdb=" CD2 LEU A  28 "
   model   vdw
   4.683 3.680
nonbonded pdb=" CA  GLY A  59 "
          pdb=" CB  LEU A  60 "
   model   vdw
   4.683 3.840
nonbonded pdb=" C   THR A  62 "
          pdb=" CA  LEU A  83 "
   model   vdw
   4.683 3.700
nonbonded pdb=" C   TYR A  61 "
          pdb=" CD2 TYR A  61 "
   model   vdw
   4.685 3.570
nonbonded pdb=" CD2 LEU A  49 "
          pdb=" NE2 GLN A  53 "
   model   vdw
   4.685 3.540
nonbonded pdb=" CA  LEU A  60 "
          pdb=" CE1 TYR A  61 "
   model   vdw
   4.685 3.770
nonbonded pdb=" CA  GLN A  31 "
          pdb=" CG  LEU A  32 "
   model   vdw
   4.685 3.900
nonbonded pdb=" NE  ARG A  16 "
          pdb=" O   LEU A  60 "
   model   vdw sym.op.
   4.685 3.120 x,y-1,z
nonbonded pdb=" CB  TYR A  41 "
          pdb=" C   PRO A  42 "
   model   vdw
   4.685 3.670
nonbonded pdb=" CD  LYS A  69 "
          pdb=" CA  ASP A  79 "
   model   vdw
   4.686 3.870
nonbonded pdb=" CB  GLN A  53 "
          pdb="O    HOH S  39 "
   model   vdw
   4.686 3.440
nonbonded pdb=" CG1 VAL A  43 "
          pdb="O    HOH S  25 "
   model   vdw
   4.686 3.460
nonbonded pdb=" CB  TYR A  41 "
          pdb=" CD1 TYR A  41 "
   model   vdw sym.op.
   4.686 3.740 -x+1,y,-z+1
nonbonded pdb=" CD1 TYR A  41 "
          pdb=" CB  TYR A  41 "
   model   vdw sym.op.
   4.686 3.740 -x+1,y,-z+1
nonbonded pdb=" C   LEU A  49 "
          pdb=" CG  GLN A  53 "
   model   vdw
   4.686 3.670
nonbonded pdb=" C   GLU A  40 "
          pdb=" N   PRO A  42 "
   model   vdw
   4.686 3.350
nonbonded pdb=" CB  LYS A  46 "
          pdb=" N   SER A  75 "
   model   vdw sym.op.
   4.686 3.520 -x+1,y,-z+2
nonbonded pdb=" CB  THR A  62 "
          pdb=" CE1 PHE A  73 "
   model   vdw sym.op.
   4.686 3.770 -x+1,y+1,-z+2
nonbonded pdb=" CG1 VAL A  45 "
          pdb=" CG1 ILE A  47 "
   model   vdw
   4.686 3.860
nonbonded pdb=" ND2 ASN A  39 "
          pdb=" N   GLU A  40 "
   model   vdw
   4.687 3.200
nonbonded pdb=" CB  THR A  15 "
          pdb=" O   ARG A  16 "
   model   vdw
   4.687 3.470
nonbonded pdb=" CA  PRO A  42 "
          pdb=" O   VAL A  43 "
   model   vdw
   4.687 3.470
nonbonded pdb=" CZ  TYR A  56 "
          pdb=" C   LEU A  83 "
   model   vdw
   4.687 3.490
nonbonded pdb=" OG  SER A  75 "
          pdb="O    HOH S   6 "
   model   vdw
   4.687 3.040
nonbonded pdb=" CA  SER A  67 "
          pdb=" CB  ARG A  82 "
   model   vdw
   4.688 3.870
nonbonded pdb=" C   LYS A  69 "
          pdb=" CE  LYS A  69 "
   model   vdw
   4.688 3.670
nonbonded pdb=" CA  GLN A  72 "
          pdb=" C   PHE A  73 "
   model   vdw
   4.688 3.700
nonbonded pdb=" CG  LEU A  49 "
          pdb=" CD  GLN A  53 "
   model   vdw
   4.688 3.700
nonbonded pdb=" C   MSE A  77 "
          pdb="O    HOH S   1 "
   model   vdw sym.op.
   4.689 3.270 -x,y+1,-z+1
nonbonded pdb=" CB  CYS A  33 "
          pdb=" O   TYR A  34 "
   model   vdw
   4.689 3.440
nonbonded pdb=" C   TYR A  34 "
          pdb=" C   VAL A  43 "
   model   vdw
   4.689 3.500
nonbonded pdb=" CB  SER A  27 "
          pdb=" CA  LEU A  28 "
   model   vdw
   4.689 3.870
nonbonded pdb=" C   LEU A  81 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   4.689 3.690
nonbonded pdb=" CA  ASN A  29 "
          pdb=" CB  GLU A  30 "
   model   vdw
   4.689 3.870
nonbonded pdb=" N   TYR A  56 "
          pdb=" CE2 TYR A  56 "
   model   vdw
   4.690 3.420
nonbonded pdb=" CD  GLN A  10 "
          pdb="O    HOH S  23 "
   model   vdw
   4.690 3.270
nonbonded pdb=" C   TYR A  56 "
          pdb=" CD  PRO A  58 "
   model   vdw
   4.690 3.670
nonbonded pdb=" C   GLU A   5 "
          pdb=" CD1 ILE A   6 "
   model   vdw
   4.690 3.690
nonbonded pdb=" CG2 THR A  15 "
          pdb=" CA  SER A  27 "
   model   vdw
   4.690 3.890
nonbonded pdb=" N   GLN A  72 "
          pdb="SE   MSE A  77 "
   model   vdw
   4.690 3.500
nonbonded pdb=" O   THR A  14 "
          pdb=" O   THR A  15 "
   model   vdw
   4.690 3.040
nonbonded pdb=" CA  VAL A   4 "
          pdb=" C   GLU A   5 "
   model   vdw
   4.690 3.700
nonbonded pdb=" O   LYS A   7 "
          pdb=" CG  LYS A   7 "
   model   vdw
   4.690 3.440
nonbonded pdb=" CB  TYR A  34 "
          pdb=" CA  PRO A  42 "
   model   vdw
   4.690 3.870
nonbonded pdb=" CB  ILE A   2 "
          pdb="O    HOH S   5 "
   model   vdw
   4.690 3.470
nonbonded pdb=" O   GLN A  12 "
          pdb=" CB  ALA A  55 "
   model   vdw
   4.691 3.460
nonbonded pdb=" CB  ALA A  11 "
          pdb=" CA  GLN A  12 "
   model   vdw
   4.691 3.890
nonbonded pdb=" CA  ARG A  82 "
          pdb=" CG  LEU A  83 "
   model   vdw
   4.691 3.900
nonbonded pdb=" OD2 ASP A  50 "
          pdb=" CD  ARG A  80 "
   model   vdw
   4.691 3.440
nonbonded pdb=" CG  ASN A  29 "
          pdb=" N   GLU A  30 "
   model   vdw
   4.691 3.350
nonbonded pdb=" O   LEU A  28 "
          pdb="O    HOH S  11 "
   model   vdw
   4.692 3.040
nonbonded pdb=" O   GLN A  31 "
          pdb=" N   LYS A  46 "
   model   vdw
   4.693 3.120
nonbonded pdb=" CD2 HIS A  64 "
          pdb=" OG  SER A  66 "
   model   vdw
   4.693 3.260
nonbonded pdb=" N   HIS A  64 "
          pdb=" CG2 VAL A  84 "
   model   vdw
   4.693 3.540
nonbonded pdb=" CA  LEU A  81 "
          pdb=" CB  ARG A  82 "
   model   vdw
   4.693 3.870
nonbonded pdb=" N   LYS A  69 "
          pdb=" N   ASP A  79 "
   model   vdw
   4.694 3.200
nonbonded pdb=" CA  ASP A  50 "
          pdb=" CG  GLN A  53 "
   model   vdw
   4.694 3.870
nonbonded pdb=" CB  LYS A   3 "
          pdb=" CA  VAL A   4 "
   model   vdw
   4.694 3.870
nonbonded pdb=" CG  PRO A   8 "
          pdb=" CB  PRO A  58 "
   model   vdw
   4.695 3.840
nonbonded pdb=" CD1 PHE A  13 "
          pdb=" N   THR A  15 "
   model   vdw
   4.695 3.420
nonbonded pdb=" OE2 GLU A  30 "
          pdb=" OG1 THR A  48 "
   model   vdw
   4.695 3.040
nonbonded pdb=" O   SER A  66 "
          pdb=" O   ARG A  80 "
   model   vdw
   4.695 3.040
nonbonded pdb=" O   GLY A  71 "
          pdb=" N   SER A  75 "
   model   vdw
   4.695 3.120
nonbonded pdb=" CB  VAL A  63 "
          pdb=" CZ  PHE A  68 "
   model   vdw
   4.695 3.770
nonbonded pdb=" CE  LYS A   3 "
          pdb=" NE2 GLN A  72 "
   model   vdw sym.op.
   4.695 3.520 -x+1,y+1,-z+2
nonbonded pdb=" NE2 GLN A  72 "
          pdb=" CE  LYS A   3 "
   model   vdw sym.op.
   4.695 3.520 -x+1,y-1,-z+2
nonbonded pdb=" N   LEU A  37 "
          pdb=" N   ASN A  39 "
   model   vdw
   4.696 3.200
nonbonded pdb=" CA  GLU A  30 "
          pdb=" CA  THR A  48 "
   model   vdw
   4.696 3.900
nonbonded pdb=" CE2 TYR A  41 "
          pdb=" CB  PRO A  42 "
   model   vdw sym.op.
   4.696 3.740 -x+1,y,-z+1
nonbonded pdb=" O   ILE A  47 "
          pdb=" O   THR A  48 "
   model   vdw
   4.696 3.040
nonbonded pdb=" C   GLN A  31 "
          pdb=" CA  LYS A  46 "
   model   vdw
   4.696 3.700
nonbonded pdb=" CA  SER A  67 "
          pdb=" CB  PHE A  68 "
   model   vdw
   4.697 3.870
nonbonded pdb=" C   GLY A  59 "
          pdb="O    HOH S  12 "
   model   vdw
   4.697 3.270
nonbonded pdb=" CA  SER A  27 "
          pdb=" C   LEU A  28 "
   model   vdw
   4.697 3.700
nonbonded pdb=" O   LYS A   3 "
          pdb=" O   VAL A   4 "
   model   vdw
   4.697 3.040
nonbonded pdb=" C   GLU A   5 "
          pdb=" CA  CYS A  33 "
   model   vdw
   4.698 3.700
nonbonded pdb=" O   ILE A   2 "
          pdb=" C   TYR A  61 "
   model   vdw
   4.698 3.270
nonbonded pdb=" CE2 TYR A  34 "
          pdb=" O   VAL A  43 "
   model   vdw
   4.699 3.340
nonbonded pdb=" C   PRO A   8 "
          pdb=" CA  GLN A  10 "
   model   vdw
   4.699 3.700
nonbonded pdb=" OD1 ASP A  50 "
          pdb=" CB  ARG A  80 "
   model   vdw
   4.699 3.440
nonbonded pdb=" CE2 PHE A  13 "
          pdb=" CB  ALA A  55 "
   model   vdw
   4.699 3.760
nonbonded pdb=" CA  GLY A  59 "
          pdb=" C   LEU A  60 "
   model   vdw
   4.700 3.670
nonbonded pdb=" CA  GLU A   5 "
          pdb=" CG1 ILE A   6 "
   model   vdw
   4.700 3.870
nonbonded pdb=" CA  VAL A  70 "
          pdb=" CD1 LEU A  76 "
   model   vdw
   4.701 3.890
nonbonded pdb=" CA  LYS A   7 "
          pdb=" CB  PRO A   8 "
   model   vdw
   4.701 3.870
nonbonded pdb=" O   LEU A  76 "
          pdb=" N   ILE A  78 "
   model   vdw
   4.702 3.120
nonbonded pdb=" N   ILE A   6 "
          pdb=" CA  GLY A  59 "
   model   vdw
   4.702 3.520
nonbonded pdb=" CA  THR A  14 "
          pdb=" N   GLU A  30 "
   model   vdw
   4.702 3.550
nonbonded pdb=" C   ARG A  80 "
          pdb=" CZ  ARG A  82 "
   model   vdw
   4.702 3.500
nonbonded pdb=" N   ARG A  80 "
          pdb=" CA  LEU A  81 "
   model   vdw
   4.702 3.550
nonbonded pdb=" CA  ASP A  36 "
          pdb=" CB  LEU A  37 "
   model   vdw
   4.703 3.870
nonbonded pdb=" N   GLU A  30 "
          pdb="O    HOH S  11 "
   model   vdw
   4.703 3.120
nonbonded pdb=" C   VAL A   4 "
          pdb=" CG  GLU A   5 "
   model   vdw
   4.703 3.670
nonbonded pdb=" CB  ILE A   6 "
          pdb=" CA  LYS A   7 "
   model   vdw
   4.703 3.900
nonbonded pdb=" CD  GLN A  72 "
          pdb=" CZ  PHE A  73 "
   model   vdw
   4.703 3.570
nonbonded pdb=" O   LYS A  69 "
          pdb="O    HOH S  10 "
   model   vdw
   4.704 3.040
nonbonded pdb=" N   ASN A  39 "
          pdb=" O   TYR A  41 "
   model   vdw
   4.704 3.120
nonbonded pdb=" CE  LYS A   7 "
          pdb=" CD2 TYR A  41 "
   model   vdw sym.op.
   4.704 3.740 -x+1,y,-z+1
nonbonded pdb=" CB  GLU A   5 "
          pdb=" C   ILE A   6 "
   model   vdw
   4.704 3.670
nonbonded pdb=" CG  GLU A  30 "
          pdb=" CG  LYS A  46 "
   model   vdw
   4.704 3.840
nonbonded pdb=" CB  ILE A   2 "
          pdb=" N   VAL A  63 "
   model   vdw
   4.704 3.550
nonbonded pdb=" CB  ILE A   6 "
          pdb=" CD1 TYR A  61 "
   model   vdw
   4.704 3.770
nonbonded pdb=" OG  SER A  75 "
          pdb=" CG  MSE A  77 "
   model   vdw
   4.705 3.440
nonbonded pdb=" N   GLN A  72 "
          pdb=" CD2 PHE A  73 "
   model   vdw
   4.705 3.420
nonbonded pdb="O    HOH S  26 "
          pdb=" CB  TYR A  41 "
   model   vdw sym.op.
   4.705 3.440 -x+1,y,-z+1
nonbonded pdb=" CB  TYR A  41 "
          pdb="O    HOH S  26 "
   model   vdw sym.op.
   4.705 3.440 -x+1,y,-z+1
nonbonded pdb=" O   GLN A  72 "
          pdb=" NE2 GLN A  72 "
   model   vdw
   4.706 3.120
nonbonded pdb=" O   LEU A  37 "
          pdb=" CA  ASN A  39 "
   model   vdw
   4.706 3.470
nonbonded pdb=" CB  PHE A  13 "
          pdb=" C   ASN A  29 "
   model   vdw
   4.706 3.670
nonbonded pdb=" CD1 TYR A  56 "
          pdb="O    HOH S   7 "
   model   vdw
   4.706 3.340
nonbonded pdb=" CE1 HIS A  64 "
          pdb=" CA  LEU A  65 "
   model   vdw
   4.706 3.690
nonbonded pdb=" C   ARG A  80 "
          pdb=" CA  ARG A  82 "
   model   vdw
   4.707 3.700
nonbonded pdb=" O   SER A   9 "
          pdb=" O   GLN A  10 "
   model   vdw
   4.707 3.040
nonbonded pdb=" CB  GLN A  12 "
          pdb=" C   PHE A  13 "
   model   vdw
   4.707 3.670
nonbonded pdb=" CA  THR A  62 "
          pdb="O    HOH S  19 "
   model   vdw
   4.707 3.470
nonbonded pdb=" CA  ASP A  36 "
          pdb=" C   LEU A  37 "
   model   vdw
   4.707 3.700
nonbonded pdb=" CB  ARG A  80 "
          pdb=" CD  ARG A  82 "
   model   vdw
   4.707 3.840
nonbonded pdb=" SG  CYS A  33 "
          pdb=" N   VAL A  35 "
   model   vdw
   4.707 3.480
nonbonded pdb=" CA  GLY A  38 "
          pdb=" CB  ASN A  39 "
   model   vdw
   4.708 3.840
nonbonded pdb=" O   LEU A  83 "
          pdb=" N   PRO A  85 "
   model   vdw
   4.708 3.120
nonbonded pdb=" CD1 ILE A   6 "
          pdb=" C   LEU A  32 "
   model   vdw
   4.708 3.690
nonbonded pdb=" CA  SER A  66 "
          pdb=" CB  SER A  67 "
   model   vdw
   4.709 3.870
nonbonded pdb=" C   ASN A  39 "
          pdb=" OD1 ASN A  39 "
   model   vdw
   4.709 3.270
nonbonded pdb=" C   GLN A  10 "
          pdb=" CD  GLN A  31 "
   model   vdw
   4.709 3.500
nonbonded pdb=" O   THR A  14 "
          pdb=" CG2 THR A  15 "
   model   vdw
   4.709 3.460
nonbonded pdb=" O   LEU A  44 "
          pdb=" N   LYS A  46 "
   model   vdw
   4.709 3.120
nonbonded pdb=" C   PRO A  58 "
          pdb=" N   LEU A  60 "
   model   vdw
   4.709 3.350
nonbonded pdb=" CG1 ILE A   6 "
          pdb=" O   LEU A  32 "
   model   vdw
   4.710 3.440
nonbonded pdb=" CG  TYR A  61 "
          pdb=" CG  LEU A  83 "
   model   vdw
   4.710 3.690
nonbonded pdb=" CA  THR A  15 "
          pdb=" CA  ASN A  29 "
   model   vdw
   4.710 3.900
nonbonded pdb=" N   ASN A  29 "
          pdb=" CA  GLU A  30 "
   model   vdw
   4.710 3.550
nonbonded pdb=" N   TYR A  56 "
          pdb="O    HOH S   7 "
   model   vdw
   4.710 3.120
nonbonded pdb=" CG  TYR A  34 "
          pdb=" O   PRO A  42 "
   model   vdw
   4.711 3.260
nonbonded pdb=" CB  ASN A  29 "
          pdb=" CA  GLU A  30 "
   model   vdw
   4.711 3.870
nonbonded pdb=" CD  GLN A  31 "
          pdb="O    HOH S   8 "
   model   vdw
   4.711 3.270
nonbonded pdb=" CG  HIS A  64 "
          pdb=" C   LEU A  65 "
   model   vdw
   4.711 3.490
nonbonded pdb=" C   PHE A  13 "
          pdb=" C   GLU A  30 "
   model   vdw
   4.711 3.500
nonbonded pdb=" CG  ASP A  36 "
          pdb="O    HOH S   9 "
   model   vdw
   4.712 3.270
nonbonded pdb=" CA  PRO A   8 "
          pdb=" C   THR A  14 "
   model   vdw sym.op.
   4.712 3.700 -x+1/2,y+1/2,-z+1
nonbonded pdb=" C   LYS A   7 "
          pdb=" CB  SER A   9 "
   model   vdw
   4.712 3.670
nonbonded pdb=" O   GLU A  40 "
          pdb=" O   TYR A  41 "
   model   vdw
   4.712 3.040
nonbonded pdb=" CB  TYR A  61 "
          pdb=" CA  PRO A  85 "
   model   vdw
   4.712 3.870
nonbonded pdb=" CG2 THR A  62 "
          pdb=" O   PRO A  85 "
   model   vdw
   4.712 3.460
nonbonded pdb=" N   MSE A  77 "
          pdb="SE   MSE A  77 "
   model   vdw
   4.713 3.500
nonbonded pdb=" CA  PRO A   8 "
          pdb=" CB  SER A   9 "
   model   vdw
   4.713 3.870
nonbonded pdb=" C   TYR A  34 "
          pdb=" CD1 TYR A  34 "
   model   vdw
   4.714 3.570
nonbonded pdb=" CA  ILE A   6 "
          pdb=" CB  LYS A   7 "
   model   vdw
   4.714 3.870
nonbonded pdb=" C   PRO A  58 "
          pdb="O    HOH S  12 "
   model   vdw
   4.714 3.270
nonbonded pdb=" O   ARG A  16 "
          pdb=" CD  ARG A  16 "
   model   vdw
   4.714 3.440
nonbonded pdb=" CB  ILE A   6 "
          pdb=" OE1 GLN A  10 "
   model   vdw
   4.714 3.470
nonbonded pdb=" N   GLU A  30 "
          pdb=" OE1 GLU A  30 "
   model   vdw
   4.714 3.120
nonbonded pdb=" CD2 HIS A  64 "
          pdb=" CG2 VAL A  84 "
   model   vdw
   4.715 3.680
nonbonded pdb=" CB  ALA A  57 "
          pdb=" C   PRO A  58 "
   model   vdw
   4.715 3.690
nonbonded pdb=" CA  TYR A  41 "
          pdb=" CE2 TYR A  41 "
   model   vdw
   4.715 3.770
nonbonded pdb=" OG  SER A  75 "
          pdb=" CA  LEU A  76 "
   model   vdw
   4.716 3.470
nonbonded pdb=" C   ILE A   6 "
          pdb=" CD  PRO A   8 "
   model   vdw
   4.716 3.670
nonbonded pdb=" CB  VAL A  70 "
          pdb=" O   SER A  75 "
   model   vdw
   4.716 3.470
nonbonded pdb=" OE1 GLN A  72 "
          pdb="O    HOH S   5 "
   model   vdw sym.op.
   4.716 3.040 -x+1,y-1,-z+2
nonbonded pdb=" CA  GLU A  30 "
          pdb=" O   GLN A  31 "
   model   vdw
   4.716 3.470
nonbonded pdb=" CA  GLN A  10 "
          pdb=" CB  ALA A  11 "
   model   vdw
   4.716 3.890
nonbonded pdb=" O   PRO A   8 "
          pdb=" O   THR A  14 "
   model   vdw sym.op.
   4.716 3.040 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CB  THR A  48 "
          pdb=" NH1 ARG A  80 "
   model   vdw
   4.716 3.550
nonbonded pdb=" C   HIS A  64 "
          pdb=" C   SER A  66 "
   model   vdw
   4.717 3.500
nonbonded pdb=" CA  LYS A   3 "
          pdb=" CB  VAL A   4 "
   model   vdw
   4.717 3.900
nonbonded pdb=" O   TYR A  41 "
          pdb=" CG  TYR A  41 "
   model   vdw
   4.717 3.260
nonbonded pdb=" C   THR A  62 "
          pdb="O    HOH S  19 "
   model   vdw
   4.717 3.270
nonbonded pdb=" CA  LEU A  37 "
          pdb=" C   GLY A  38 "
   model   vdw
   4.717 3.700
nonbonded pdb=" CB  TYR A  56 "
          pdb=" C   ALA A  57 "
   model   vdw
   4.718 3.670
nonbonded pdb=" CE1 HIS A  64 "
          pdb=" C   LEU A  65 "
   model   vdw
   4.718 3.490
nonbonded pdb=" O   ASP A  50 "
          pdb=" CD  GLU A  51 "
   model   vdw
   4.718 3.270
nonbonded pdb=" CA  SER A  75 "
          pdb=" O   LEU A  76 "
   model   vdw
   4.718 3.470
nonbonded pdb=" O   LYS A  46 "
          pdb=" N   LEU A  76 "
   model   vdw sym.op.
   4.719 3.120 -x+1,y,-z+2
nonbonded pdb=" N   PHE A  68 "
          pdb=" CE2 PHE A  68 "
   model   vdw
   4.719 3.420
nonbonded pdb=" N   GLN A  12 "
          pdb=" CB  ALA A  55 "
   model   vdw
   4.719 3.540
nonbonded pdb=" CG  PHE A  68 "
          pdb=" O   MSE A  77 "
   model   vdw
   4.719 3.260
nonbonded pdb=" CA  GLU A  30 "
          pdb=" C   GLN A  31 "
   model   vdw
   4.719 3.700
nonbonded pdb=" N   PRO A   8 "
          pdb="O    HOH S  14 "
   model   vdw sym.op.
   4.720 3.120 -x+1/2,y+1/2,-z+1
nonbonded pdb=" N   LEU A  60 "
          pdb=" CA  TYR A  61 "
   model   vdw
   4.720 3.550
nonbonded pdb=" CA  GLY A  38 "
          pdb=" CG  ASN A  39 "
   model   vdw
   4.720 3.670
nonbonded pdb=" CB  ARG A  16 "
          pdb=" O   LEU A  28 "
   model   vdw
   4.720 3.440
nonbonded pdb=" CA  LYS A   3 "
          pdb=" O   VAL A   4 "
   model   vdw
   4.720 3.470
nonbonded pdb=" O   LEU A  60 "
          pdb=" N   THR A  62 "
   model   vdw
   4.720 3.120
nonbonded pdb=" CA  ARG A  16 "
          pdb=" O   SER A  17 "
   model   vdw
   4.720 3.470
nonbonded pdb=" CA  GLN A  12 "
          pdb=" CB  PHE A  13 "
   model   vdw
   4.721 3.870
nonbonded pdb=" O   GLU A  30 "
          pdb=" N   LEU A  32 "
   model   vdw
   4.721 3.120
nonbonded pdb=" CD1 ILE A  47 "
          pdb=" CE2 TYR A  56 "
   model   vdw
   4.721 3.760
nonbonded pdb=" C   PHE A  68 "
          pdb=" CD1 LEU A  76 "
   model   vdw
   4.721 3.690
nonbonded pdb=" O   LEU A  83 "
          pdb=" CD  PRO A  85 "
   model   vdw
   4.721 3.440
nonbonded pdb=" OD1 ASP A  36 "
          pdb=" O   ASN A  39 "
   model   vdw
   4.721 3.040
nonbonded pdb=" CD2 TYR A  34 "
          pdb=" CA  PRO A  42 "
   model   vdw
   4.721 3.770
nonbonded pdb=" CG  PHE A  13 "
          pdb=" ND2 ASN A  29 "
   model   vdw
   4.722 3.340
nonbonded pdb=" N   LEU A  65 "
          pdb=" CD1 PHE A  68 "
   model   vdw
   4.722 3.420
nonbonded pdb=" CA  TYR A  61 "
          pdb=" CE2 TYR A  61 "
   model   vdw
   4.722 3.770
nonbonded pdb=" OE1 GLN A  72 "
          pdb=" N   LYS A   3 "
   model   vdw sym.op.
   4.723 3.120 -x+1,y-1,-z+2
nonbonded pdb=" N   LYS A   3 "
          pdb=" OE1 GLN A  72 "
   model   vdw sym.op.
   4.723 3.120 -x+1,y+1,-z+2
nonbonded pdb=" C   CYS A  33 "
          pdb=" CA  LEU A  44 "
   model   vdw
   4.724 3.700
nonbonded pdb=" CA  PHE A  68 "
          pdb=" C   LYS A  69 "
   model   vdw
   4.724 3.700
nonbonded pdb=" OG1 THR A  15 "
          pdb=" CB  ASN A  29 "
   model   vdw
   4.725 3.440
nonbonded pdb=" CB  SER A  66 "
          pdb=" NH1 ARG A  82 "
   model   vdw
   4.725 3.520
nonbonded pdb=" O   VAL A   4 "
          pdb=" N   LEU A  60 "
   model   vdw
   4.726 3.120
nonbonded pdb=" C   VAL A  35 "
          pdb=" CG  LEU A  37 "
   model   vdw
   4.726 3.700
nonbonded pdb=" CA  VAL A  63 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   4.726 3.890
nonbonded pdb=" N   THR A  14 "
          pdb=" CA  THR A  15 "
   model   vdw
   4.726 3.550
nonbonded pdb=" O   GLN A  10 "
          pdb=" O   TYR A  56 "
   model   vdw
   4.726 3.040
nonbonded pdb=" OG1 THR A  15 "
          pdb=" CB  SER A   9 "
   model   vdw sym.op.
   4.726 3.440 -x+1/2,y-1/2,-z+1
nonbonded pdb=" CB  SER A   9 "
          pdb=" OG1 THR A  15 "
   model   vdw sym.op.
   4.726 3.440 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CA  PHE A  13 "
          pdb=" CB  THR A  14 "
   model   vdw
   4.726 3.900
nonbonded pdb=" N   VAL A  35 "
          pdb=" CA  ASP A  36 "
   model   vdw
   4.726 3.550
nonbonded pdb=" O   LEU A  65 "
          pdb=" CB  SER A  67 "
   model   vdw
   4.727 3.440
nonbonded pdb=" CB  GLN A  31 "
          pdb=" CG  LEU A  49 "
   model   vdw
   4.727 3.870
nonbonded pdb=" N   ILE A   6 "
          pdb=" CE1 TYR A  61 "
   model   vdw
   4.727 3.420
nonbonded pdb=" CB  SER A  75 "
          pdb=" C   LEU A  76 "
   model   vdw
   4.727 3.670
nonbonded pdb=" N   HIS A  64 "
          pdb=" ND1 HIS A  64 "
   model   vdw
   4.728 3.200
nonbonded pdb=" N   LEU A  28 "
          pdb=" OD1 ASN A  29 "
   model   vdw
   4.728 3.120
nonbonded pdb=" N   ASP A  79 "
          pdb=" OD2 ASP A  79 "
   model   vdw
   4.728 3.120
nonbonded pdb=" CA  VAL A  63 "
          pdb=" CB  HIS A  64 "
   model   vdw
   4.728 3.870
nonbonded pdb=" O   THR A  62 "
          pdb=" C   ARG A  82 "
   model   vdw
   4.728 3.270
nonbonded pdb=" CA  GLN A  31 "
          pdb=" CB  LEU A  32 "
   model   vdw
   4.728 3.870
nonbonded pdb=" CG  ARG A  80 "
          pdb=" NH2 ARG A  80 "
   model   vdw
   4.728 3.520
nonbonded pdb=" CG  LYS A  69 "
          pdb=" CG  ASP A  79 "
   model   vdw
   4.728 3.670
nonbonded pdb=" O   PRO A   8 "
          pdb=" CD  PRO A   8 "
   model   vdw
   4.728 3.440
nonbonded pdb=" C   LYS A   7 "
          pdb=" CG  GLN A  10 "
   model   vdw
   4.728 3.670
nonbonded pdb=" O   GLN A  10 "
          pdb=" OE1 GLN A  31 "
   model   vdw
   4.729 3.040
nonbonded pdb=" C   TYR A  56 "
          pdb=" CZ  TYR A  61 "
   model   vdw
   4.729 3.490
nonbonded pdb=" CG  TYR A  34 "
          pdb=" N   LEU A  44 "
   model   vdw
   4.729 3.340
nonbonded pdb=" OE2 GLU A   5 "
          pdb=" O   ILE A   6 "
   model   vdw
   4.730 3.040
nonbonded pdb=" O   ILE A   6 "
          pdb=" O   PRO A  58 "
   model   vdw
   4.730 3.040
nonbonded pdb=" CA  ILE A  47 "
          pdb=" CB  THR A  48 "
   model   vdw
   4.731 3.900
nonbonded pdb=" CA  LEU A  32 "
          pdb=" CA  LYS A  46 "
   model   vdw
   4.731 3.900
nonbonded pdb=" CE2 TYR A  61 "
          pdb=" CB  LEU A  83 "
   model   vdw
   4.731 3.740
nonbonded pdb=" C   SER A   9 "
          pdb=" CA  ALA A  11 "
   model   vdw
   4.731 3.700
nonbonded pdb=" C   ALA A  11 "
          pdb=" O   TYR A  56 "
   model   vdw
   4.731 3.270
nonbonded pdb=" CG1 VAL A  45 "
          pdb=" CA  SER A  75 "
   model   vdw sym.op.
   4.731 3.890 -x+1,y,-z+2
nonbonded pdb=" CG  ARG A  16 "
          pdb=" N   LEU A  28 "
   model   vdw
   4.731 3.520
nonbonded pdb=" NE2 GLN A  10 "
          pdb="O    HOH S  23 "
   model   vdw
   4.732 3.120
nonbonded pdb=" O   SER A  67 "
          pdb=" N   ILE A  78 "
   model   vdw
   4.732 3.120
nonbonded pdb=" C   LEU A  37 "
          pdb=" CA  ASN A  39 "
   model   vdw
   4.732 3.700
nonbonded pdb=" CA  GLN A  12 "
          pdb="O    HOH S   8 "
   model   vdw
   4.733 3.470
nonbonded pdb=" CG1 ILE A   2 "
          pdb=" CZ  PHE A  68 "
   model   vdw sym.op.
   4.733 3.740 -x+1,y,-z+2
nonbonded pdb=" CZ  PHE A  68 "
          pdb=" CG1 ILE A   2 "
   model   vdw sym.op.
   4.733 3.740 -x+1,y,-z+2
nonbonded pdb=" CD2 TYR A  34 "
          pdb=" OH  TYR A  41 "
   model   vdw sym.op.
   4.734 3.340 -x+1,y,-z+1
nonbonded pdb=" OH  TYR A  41 "
          pdb=" CD2 TYR A  34 "
   model   vdw sym.op.
   4.734 3.340 -x+1,y,-z+1
nonbonded pdb=" O   TYR A  61 "
          pdb=" O   VAL A  84 "
   model   vdw
   4.734 3.040
nonbonded pdb=" CA  PHE A  13 "
          pdb=" CB  GLN A  31 "
   model   vdw
   4.735 3.870
nonbonded pdb=" CB  PRO A   8 "
          pdb=" N   THR A  14 "
   model   vdw sym.op.
   4.735 3.520 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CG1 VAL A   4 "
          pdb=" CG  LEU A  83 "
   model   vdw
   4.735 3.890
nonbonded pdb=" OE1 GLU A   5 "
          pdb="O    HOH S  12 "
   model   vdw
   4.735 3.040
nonbonded pdb=" N   GLU A  51 "
          pdb=" CA  GLY A  52 "
   model   vdw
   4.736 3.520
nonbonded pdb=" CG  GLU A   5 "
          pdb=" NZ  LYS A   7 "
   model   vdw
   4.736 3.520
nonbonded pdb=" C   SER A  67 "
          pdb=" C   ILE A  78 "
   model   vdw
   4.736 3.500
nonbonded pdb=" CA  TYR A  34 "
          pdb=" CG2 VAL A  35 "
   model   vdw
   4.737 3.890
nonbonded pdb=" CD  LYS A  69 "
          pdb=" OD2 ASP A  79 "
   model   vdw
   4.737 3.440
nonbonded pdb=" CA  LEU A  28 "
          pdb=" CB  ASN A  29 "
   model   vdw
   4.737 3.870
nonbonded pdb=" CG  ARG A  16 "
          pdb=" NH2 ARG A  16 "
   model   vdw
   4.737 3.520
nonbonded pdb=" CG  LYS A   7 "
          pdb=" OE1 GLU A  40 "
   model   vdw sym.op.
   4.737 3.440 -x+1,y,-z+1
nonbonded pdb=" CE1 PHE A  13 "
          pdb=" C   THR A  14 "
   model   vdw
   4.738 3.570
nonbonded pdb=" N   GLU A  40 "
          pdb=" OE2 GLU A  40 "
   model   vdw
   4.738 3.120
nonbonded pdb=" CB  VAL A  45 "
          pdb="O    HOH S   6 "
   model   vdw sym.op.
   4.738 3.470 -x+1,y,-z+2
nonbonded pdb=" N   ARG A  82 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   4.738 3.540
nonbonded pdb=" CA  GLU A   5 "
          pdb=" CB  ILE A   6 "
   model   vdw
   4.738 3.900
nonbonded pdb=" O   GLU A  30 "
          pdb="O    HOH S   8 "
   model   vdw
   4.738 3.040
nonbonded pdb=" CA  TYR A  56 "
          pdb=" CZ  TYR A  61 "
   model   vdw
   4.739 3.690
nonbonded pdb=" OG1 THR A  14 "
          pdb=" CA  THR A  15 "
   model   vdw
   4.739 3.470
nonbonded pdb=" N   ASN A  29 "
          pdb=" O   LEU A  49 "
   model   vdw
   4.739 3.120
nonbonded pdb=" N   LEU A  76 "
          pdb=" CA  MSE A  77 "
   model   vdw
   4.739 3.550
nonbonded pdb=" N   ARG A  16 "
          pdb=" CA  SER A  17 "
   model   vdw
   4.740 3.550
nonbonded pdb=" O   LEU A  49 "
          pdb=" NH2 ARG A  80 "
   model   vdw
   4.740 3.120
nonbonded pdb=" N   SER A  67 "
          pdb=" CE1 PHE A  68 "
   model   vdw
   4.740 3.420
nonbonded pdb=" CA  LEU A  44 "
          pdb=" C   VAL A  45 "
   model   vdw
   4.740 3.700
nonbonded pdb=" NH1 ARG A  16 "
          pdb=" C   PRO A  85 "
   model   vdw sym.op.
   4.741 3.350 x,y-1,z
nonbonded pdb=" N   LEU A  60 "
          pdb=" CG  TYR A  61 "
   model   vdw
   4.741 3.340
nonbonded pdb=" O   VAL A  35 "
          pdb=" CG  PRO A  42 "
   model   vdw
   4.741 3.440
nonbonded pdb=" CD1 LEU A  81 "
          pdb=" N   ARG A  82 "
   model   vdw
   4.741 3.540
nonbonded pdb=" O   LEU A  60 "
          pdb=" CB  PRO A  85 "
   model   vdw
   4.742 3.440
nonbonded pdb=" C   VAL A  35 "
          pdb=" C   PRO A  42 "
   model   vdw
   4.742 3.500
nonbonded pdb=" O   TYR A  26 "
          pdb=" O   SER A  27 "
   model   vdw
   4.742 3.040
nonbonded pdb=" O   TYR A  26 "
          pdb=" OG  SER A  27 "
   model   vdw
   4.742 3.040
nonbonded pdb=" N   GLY A  52 "
          pdb=" O   GLN A  53 "
   model   vdw
   4.742 3.120
nonbonded pdb=" CD1 TYR A  56 "
          pdb=" O   LEU A  83 "
   model   vdw
   4.742 3.340
nonbonded pdb=" CA  LEU A  60 "
          pdb=" C   TYR A  61 "
   model   vdw
   4.743 3.700
nonbonded pdb=" O   SER A  67 "
          pdb=" O   ILE A  78 "
   model   vdw
   4.743 3.040
nonbonded pdb=" CB  GLU A  40 "
          pdb=" CB  TYR A  41 "
   model   vdw
   4.743 3.840
nonbonded pdb=" CG2 ILE A  47 "
          pdb=" CG  LEU A  49 "
   model   vdw
   4.743 3.890
nonbonded pdb=" CA  LYS A  46 "
          pdb=" CE  LYS A  46 "
   model   vdw
   4.743 3.870
nonbonded pdb=" C   ILE A   6 "
          pdb=" CB  GLN A  10 "
   model   vdw
   4.744 3.670
nonbonded pdb=" CD1 TYR A  34 "
          pdb=" CD1 LEU A  44 "
   model   vdw
   4.744 3.760
nonbonded pdb=" CB  PHE A  13 "
          pdb=" N   GLN A  31 "
   model   vdw
   4.744 3.520
nonbonded pdb=" CG1 VAL A  45 "
          pdb=" C   SER A  75 "
   model   vdw sym.op.
   4.744 3.690 -x+1,y,-z+2
nonbonded pdb=" O   GLY A  59 "
          pdb=" CG  TYR A  61 "
   model   vdw
   4.744 3.260
nonbonded pdb=" O   LYS A  46 "
          pdb=" C   GLY A  74 "
   model   vdw sym.op.
   4.745 3.270 -x+1,y,-z+2
nonbonded pdb=" C   TYR A  61 "
          pdb=" C   VAL A  84 "
   model   vdw
   4.745 3.500
nonbonded pdb=" O   ASP A  79 "
          pdb=" N   LEU A  81 "
   model   vdw
   4.745 3.120
nonbonded pdb=" CA  GLY A  59 "
          pdb=" CD1 TYR A  61 "
   model   vdw
   4.745 3.740
nonbonded pdb=" C   THR A  48 "
          pdb=" NE  ARG A  80 "
   model   vdw
   4.746 3.350
nonbonded pdb=" O   LYS A  69 "
          pdb=" CA  GLY A  71 "
   model   vdw
   4.747 3.440
nonbonded pdb=" CA  GLU A  40 "
          pdb=" O   TYR A  41 "
   model   vdw
   4.747 3.470
nonbonded pdb=" CA  GLN A  53 "
          pdb=" OE1 GLN A  53 "
   model   vdw
   4.747 3.470
nonbonded pdb=" CB  TYR A  34 "
          pdb=" N   VAL A  43 "
   model   vdw
   4.747 3.520
nonbonded pdb=" CG2 VAL A  35 "
          pdb=" CD2 LEU A  76 "
   model   vdw sym.op.
   4.748 3.880 -x+1,y,-z+2
nonbonded pdb=" O   TYR A  41 "
          pdb=" CA  VAL A  43 "
   model   vdw
   4.748 3.470
nonbonded pdb=" CG2 VAL A  70 "
          pdb=" N   GLY A  71 "
   model   vdw
   4.748 3.540
nonbonded pdb=" O   ILE A  47 "
          pdb="O    HOH S  38 "
   model   vdw
   4.748 3.040
nonbonded pdb=" CD  GLN A  10 "
          pdb=" O   CYS A  33 "
   model   vdw
   4.748 3.270
nonbonded pdb=" CA  SER A  17 "
          pdb=" OH  TYR A  26 "
   model   vdw
   4.748 3.470
nonbonded pdb=" CG2 THR A  48 "
          pdb=" CA  LEU A  49 "
   model   vdw
   4.748 3.890
nonbonded pdb=" NH2 ARG A  16 "
          pdb=" N   PRO A  85 "
   model   vdw sym.op.
   4.748 3.200 x,y-1,z
nonbonded pdb=" O   GLN A  31 "
          pdb=" CG2 ILE A  47 "
   model   vdw
   4.749 3.460
nonbonded pdb=" CE1 PHE A  13 "
          pdb=" N   THR A  14 "
   model   vdw
   4.749 3.420
nonbonded pdb=" O   LYS A   3 "
          pdb=" C   ASP A  36 "
   model   vdw
   4.749 3.270
nonbonded pdb=" C   LYS A   3 "
          pdb=" CB  ASP A  36 "
   model   vdw
   4.749 3.670
nonbonded pdb=" O   GLU A  40 "
          pdb=" OE1 GLU A  40 "
   model   vdw
   4.749 3.040
nonbonded pdb=" C   LYS A  46 "
          pdb=" CA  SER A  75 "
   model   vdw sym.op.
   4.750 3.700 -x+1,y,-z+2
nonbonded pdb=" O   PHE A  73 "
          pdb=" CD1 PHE A  73 "
   model   vdw
   4.750 3.340
nonbonded pdb=" CG  ARG A  16 "
          pdb=" CA  LEU A  28 "
   model   vdw
   4.750 3.870
nonbonded pdb=" N   LEU A  49 "
          pdb=" CA  ASP A  50 "
   model   vdw
   4.750 3.550
nonbonded pdb=" CG  LEU A  44 "
          pdb=" CA  VAL A  45 "
   model   vdw
   4.751 3.900
nonbonded pdb=" CA  CYS A  33 "
          pdb=" CB  TYR A  34 "
   model   vdw
   4.751 3.870
nonbonded pdb=" CB  LYS A  46 "
          pdb=" CA  GLY A  74 "
   model   vdw sym.op.
   4.751 3.840 -x+1,y,-z+2
nonbonded pdb=" CB  ILE A   6 "
          pdb=" NE2 GLN A  31 "
   model   vdw
   4.751 3.550
nonbonded pdb=" CG  LYS A   7 "
          pdb=" CG  GLU A  40 "
   model   vdw sym.op.
   4.751 3.840 -x+1,y,-z+1
nonbonded pdb=" O   ASP A  50 "
          pdb=" CG  ASP A  50 "
   model   vdw
   4.751 3.270
nonbonded pdb=" CG2 THR A  15 "
          pdb=" N   SER A  17 "
   model   vdw
   4.752 3.540
nonbonded pdb=" CA  PHE A  13 "
          pdb=" CG2 THR A  14 "
   model   vdw
   4.752 3.890
nonbonded pdb=" C   ILE A   2 "
          pdb=" CA  THR A  62 "
   model   vdw
   4.752 3.700
nonbonded pdb=" CB  GLN A  10 "
          pdb=" CA  LEU A  32 "
   model   vdw
   4.752 3.870
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" C   TYR A  56 "
   model   vdw
   4.752 3.690
nonbonded pdb=" CG1 ILE A   2 "
          pdb="O    HOH S  19 "
   model   vdw
   4.753 3.440
nonbonded pdb=" CG  PHE A  13 "
          pdb=" OD1 ASN A  29 "
   model   vdw
   4.753 3.260
nonbonded pdb=" N   GLU A   5 "
          pdb=" CA  ILE A   6 "
   model   vdw
   4.753 3.550
nonbonded pdb=" CD2 LEU A  32 "
          pdb=" CD2 LEU A  44 "
   model   vdw
   4.753 3.880
nonbonded pdb=" C   ALA A  55 "
          pdb=" CD2 TYR A  56 "
   model   vdw
   4.753 3.570
nonbonded pdb=" CG2 THR A  48 "
          pdb=" CG  ARG A  80 "
   model   vdw
   4.753 3.860
nonbonded pdb=" N   LEU A  44 "
          pdb=" CA  VAL A  45 "
   model   vdw
   4.753 3.550
nonbonded pdb=" N   THR A  15 "
          pdb=" CA  ARG A  16 "
   model   vdw
   4.753 3.550
nonbonded pdb=" C   PRO A   8 "
          pdb=" CB  THR A  14 "
   model   vdw sym.op.
   4.754 3.700 -x+1/2,y+1/2,-z+1
nonbonded pdb=" C   SER A  66 "
          pdb=" NE  ARG A  82 "
   model   vdw
   4.754 3.350
nonbonded pdb=" O   LEU A  32 "
          pdb=" O   VAL A  45 "
   model   vdw
   4.755 3.040
nonbonded pdb=" N   PRO A   8 "
          pdb=" CB  SER A   9 "
   model   vdw
   4.755 3.520
nonbonded pdb=" CA  ILE A   2 "
          pdb=" CD1 LEU A  65 "
   model   vdw sym.op.
   4.755 3.890 -x+1,y,-z+2
nonbonded pdb=" CD1 LEU A  65 "
          pdb=" CA  ILE A   2 "
   model   vdw sym.op.
   4.755 3.890 -x+1,y,-z+2
nonbonded pdb=" CG1 ILE A   6 "
          pdb=" O   TYR A  56 "
   model   vdw
   4.755 3.440
nonbonded pdb=" CZ  PHE A  68 "
          pdb=" CE2 PHE A  68 "
   model   vdw sym.op.
   4.756 3.640 -x+1,y,-z+2
nonbonded pdb=" CE2 PHE A  68 "
          pdb=" CZ  PHE A  68 "
   model   vdw sym.op.
   4.756 3.640 -x+1,y,-z+2
nonbonded pdb=" CA  TYR A  26 "
          pdb=" CE2 TYR A  26 "
   model   vdw
   4.756 3.770
nonbonded pdb=" N   ASP A  50 "
          pdb=" CA  GLU A  51 "
   model   vdw
   4.756 3.550
nonbonded pdb=" CD  GLN A  72 "
          pdb=" CD2 PHE A  73 "
   model   vdw
   4.756 3.570
nonbonded pdb=" C   VAL A   4 "
          pdb=" CA  LEU A  60 "
   model   vdw
   4.756 3.700
nonbonded pdb=" CD  GLN A  53 "
          pdb=" CE1 TYR A  56 "
   model   vdw
   4.756 3.570
nonbonded pdb=" CA  GLN A  72 "
          pdb=" CD2 PHE A  73 "
   model   vdw
   4.756 3.770
nonbonded pdb=" CD1 ILE A   6 "
          pdb=" CA  CYS A  33 "
   model   vdw
   4.756 3.890
nonbonded pdb=" CA  VAL A  84 "
          pdb=" CB  PRO A  85 "
   model   vdw
   4.756 3.870
nonbonded pdb=" C   SER A  66 "
          pdb=" OG  SER A  67 "
   model   vdw
   4.757 3.270
nonbonded pdb=" CD  GLU A   5 "
          pdb=" CG  LEU A  60 "
   model   vdw
   4.757 3.700
nonbonded pdb=" NH1 ARG A  16 "
          pdb=" NZ  LYS A  46 "
   model   vdw
   4.757 3.200
nonbonded pdb=" CB  LEU A  83 "
          pdb=" O   VAL A  84 "
   model   vdw
   4.757 3.440
nonbonded pdb=" CB  THR A  48 "
          pdb=" CA  LEU A  49 "
   model   vdw
   4.757 3.900
nonbonded pdb=" O   VAL A  35 "
          pdb=" N   PRO A  42 "
   model   vdw
   4.757 3.120
nonbonded pdb=" CE2 PHE A  13 "
          pdb=" ND2 ASN A  29 "
   model   vdw
   4.757 3.420
nonbonded pdb=" C   SER A  67 "
          pdb=" C   ARG A  80 "
   model   vdw
   4.758 3.500
nonbonded pdb=" CA  ILE A   2 "
          pdb=" CB  LYS A   3 "
   model   vdw
   4.759 3.870
nonbonded pdb=" CG  PHE A  13 "
          pdb=" C   THR A  14 "
   model   vdw
   4.759 3.490
nonbonded pdb=" N   GLY A  38 "
          pdb=" OD1 ASN A  39 "
   model   vdw
   4.759 3.120
nonbonded pdb=" CA  THR A  15 "
          pdb=" CB  ARG A  16 "
   model   vdw
   4.759 3.870
nonbonded pdb=" N   HIS A  64 "
          pdb=" CA  LEU A  83 "
   model   vdw
   4.760 3.550
nonbonded pdb=" CZ  ARG A  16 "
          pdb=" CA  LEU A  60 "
   model   vdw sym.op.
   4.760 3.700 x,y-1,z
nonbonded pdb=" CB  THR A  15 "
          pdb=" OG  SER A  27 "
   model   vdw
   4.760 3.470
nonbonded pdb=" CA  TYR A  56 "
          pdb=" CE2 TYR A  56 "
   model   vdw
   4.760 3.770
nonbonded pdb=" OE1 GLN A  10 "
          pdb=" O   CYS A  33 "
   model   vdw
   4.761 3.040
nonbonded pdb=" N   TYR A  41 "
          pdb="O    HOH S   9 "
   model   vdw
   4.761 3.120
nonbonded pdb=" CE2 TYR A  61 "
          pdb=" CG  PRO A  85 "
   model   vdw
   4.761 3.740
nonbonded pdb=" CD2 TYR A  26 "
          pdb=" CG  PRO A  85 "
   model   vdw sym.op.
   4.761 3.740 x,y-1,z
nonbonded pdb=" OE1 GLU A  30 "
          pdb=" CG  LYS A  46 "
   model   vdw
   4.761 3.440
nonbonded pdb=" CG  LYS A  69 "
          pdb=" CA  VAL A  70 "
   model   vdw
   4.761 3.870
nonbonded pdb=" CG2 VAL A  45 "
          pdb=" CB  VAL A  70 "
   model   vdw sym.op.
   4.762 3.890 -x+1,y,-z+2
nonbonded pdb=" CB  VAL A  70 "
          pdb=" CG2 VAL A  45 "
   model   vdw sym.op.
   4.762 3.890 -x+1,y,-z+2
nonbonded pdb=" CA  VAL A  70 "
          pdb=" CA  LEU A  76 "
   model   vdw
   4.762 3.900
nonbonded pdb=" O   CYS A  33 "
          pdb=" CE1 TYR A  34 "
   model   vdw
   4.763 3.340
nonbonded pdb=" CB  GLU A   5 "
          pdb=" CG  LEU A  60 "
   model   vdw
   4.763 3.870
nonbonded pdb=" O   PHE A  73 "
          pdb=" CB  SER A  75 "
   model   vdw
   4.763 3.440
nonbonded pdb=" N   ASP A  36 "
          pdb=" CA  PRO A  42 "
   model   vdw
   4.763 3.550
nonbonded pdb=" O   ASN A  29 "
          pdb=" O   THR A  48 "
   model   vdw
   4.763 3.040
nonbonded pdb=" CA  HIS A  64 "
          pdb=" C   ARG A  82 "
   model   vdw
   4.764 3.700
nonbonded pdb=" N   GLN A  53 "
          pdb=" CA  PRO A  54 "
   model   vdw
   4.764 3.550
nonbonded pdb=" O   GLU A  40 "
          pdb=" CG  GLU A  40 "
   model   vdw
   4.764 3.440
nonbonded pdb=" N   LEU A  28 "
          pdb=" CA  ASN A  29 "
   model   vdw
   4.764 3.550
nonbonded pdb=" C   VAL A  45 "
          pdb=" CG  LYS A  46 "
   model   vdw
   4.764 3.670
nonbonded pdb=" CE1 HIS A  64 "
          pdb=" CB  LEU A  65 "
   model   vdw
   4.764 3.660
nonbonded pdb=" CG  LYS A   7 "
          pdb=" CB  GLU A  40 "
   model   vdw sym.op.
   4.765 3.840 -x+1,y,-z+1
nonbonded pdb=" C   ARG A  80 "
          pdb=" NE  ARG A  82 "
   model   vdw
   4.766 3.350
nonbonded pdb=" CA  GLU A  40 "
          pdb=" C   TYR A  41 "
   model   vdw
   4.766 3.700
nonbonded pdb=" OE1 GLU A   5 "
          pdb=" CD  LYS A   7 "
   model   vdw
   4.766 3.440
nonbonded pdb=" N   THR A  62 "
          pdb=" CG2 VAL A  84 "
   model   vdw
   4.766 3.540
nonbonded pdb=" CA  TYR A  41 "
          pdb=" CB  PRO A  42 "
   model   vdw
   4.766 3.870
nonbonded pdb=" CE1 TYR A  26 "
          pdb=" CD  PRO A  85 "
   model   vdw sym.op.
   4.766 3.740 x,y-1,z
nonbonded pdb=" C   GLU A  51 "
          pdb=" OE1 GLU A  51 "
   model   vdw
   4.766 3.270
nonbonded pdb=" O   LEU A  65 "
          pdb=" CD2 LEU A  65 "
   model   vdw
   4.766 3.460
nonbonded pdb=" N   LEU A  37 "
          pdb=" CG  LEU A  65 "
   model   vdw sym.op.
   4.767 3.550 -x+1,y,-z+2
nonbonded pdb=" O   PRO A   8 "
          pdb=" N   THR A  14 "
   model   vdw sym.op.
   4.767 3.120 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CD1 ILE A   6 "
          pdb=" CE1 TYR A  61 "
   model   vdw
   4.767 3.760
nonbonded pdb=" CA  GLY A  74 "
          pdb="O    HOH S   3 "
   model   vdw
   4.767 3.440
nonbonded pdb=" C   GLY A  71 "
          pdb=" C   PHE A  73 "
   model   vdw
   4.768 3.500
nonbonded pdb=" N   ALA A  55 "
          pdb=" CA  TYR A  56 "
   model   vdw
   4.768 3.550
nonbonded pdb=" CG1 ILE A   6 "
          pdb=" N   LYS A   7 "
   model   vdw
   4.768 3.520
nonbonded pdb=" CG1 VAL A  43 "
          pdb=" CG2 VAL A  70 "
   model   vdw sym.op.
   4.769 3.880 -x+1,y,-z+2
nonbonded pdb=" CG  ARG A  16 "
          pdb=" OE1 GLU A  30 "
   model   vdw
   4.769 3.440
nonbonded pdb=" C   TYR A  26 "
          pdb="O    HOH S  37 "
   model   vdw
   4.769 3.270
nonbonded pdb=" CB  VAL A  84 "
          pdb=" C   PRO A  85 "
   model   vdw
   4.769 3.700
nonbonded pdb=" C   HIS A  64 "
          pdb=" CA  SER A  67 "
   model   vdw
   4.769 3.700
nonbonded pdb=" CB  TYR A  61 "
          pdb=" N   PRO A  85 "
   model   vdw
   4.769 3.520
nonbonded pdb=" N   ILE A  47 "
          pdb=" CA  THR A  48 "
   model   vdw
   4.769 3.550
nonbonded pdb=" O   SER A  75 "
          pdb="O    HOH S   6 "
   model   vdw
   4.769 3.040
nonbonded pdb=" CA  LEU A  83 "
          pdb=" CB  VAL A  84 "
   model   vdw
   4.769 3.900
nonbonded pdb=" C   TYR A  56 "
          pdb=" CD2 TYR A  56 "
   model   vdw
   4.770 3.570
nonbonded pdb=" CA  LEU A  37 "
          pdb=" OD1 ASN A  39 "
   model   vdw
   4.770 3.470
nonbonded pdb=" C   ILE A  47 "
          pdb=" CG2 THR A  48 "
   model   vdw
   4.770 3.690
nonbonded pdb=" CB  ASP A  50 "
          pdb=" C   GLU A  51 "
   model   vdw
   4.770 3.670
nonbonded pdb=" N   MSE A  77 "
          pdb=" CE  MSE A  77 "
   model   vdw
   4.771 3.540
nonbonded pdb=" CA  GLN A  72 "
          pdb=" CB  PHE A  73 "
   model   vdw
   4.771 3.870
nonbonded pdb=" NZ  LYS A   7 "
          pdb=" CE1 TYR A  41 "
   model   vdw sym.op.
   4.771 3.420 -x+1,y,-z+1
nonbonded pdb=" CB  ARG A  82 "
          pdb=" CA  LEU A  83 "
   model   vdw
   4.771 3.870
nonbonded pdb=" CB  LYS A   7 "
          pdb=" CE1 TYR A  34 "
   model   vdw
   4.771 3.740
nonbonded pdb=" C   ASP A  50 "
          pdb=" OD2 ASP A  50 "
   model   vdw
   4.772 3.270
nonbonded pdb=" CG1 VAL A  43 "
          pdb="O    HOH S   9 "
   model   vdw
   4.772 3.460
nonbonded pdb=" CB  LEU A  81 "
          pdb=" CA  ARG A  82 "
   model   vdw
   4.772 3.870
nonbonded pdb=" CA  VAL A  35 "
          pdb=" N   VAL A  43 "
   model   vdw
   4.772 3.550
nonbonded pdb=" N   ASP A  79 "
          pdb=" C   ARG A  80 "
   model   vdw
   4.773 3.350
nonbonded pdb=" CG  LYS A   3 "
          pdb=" CD1 PHE A  73 "
   model   vdw sym.op.
   4.773 3.740 -x+1,y+1,-z+2
nonbonded pdb=" N   VAL A  63 "
          pdb=" CA  HIS A  64 "
   model   vdw
   4.773 3.550
nonbonded pdb=" O   VAL A  35 "
          pdb=" OD1 ASP A  36 "
   model   vdw
   4.773 3.040
nonbonded pdb=" CA  GLU A   5 "
          pdb=" O   ILE A   6 "
   model   vdw
   4.774 3.470
nonbonded pdb=" NE2 GLN A  12 "
          pdb=" N   PHE A  13 "
   model   vdw
   4.774 3.200
nonbonded pdb=" CD2 LEU A  49 "
          pdb=" CA  ALA A  55 "
   model   vdw
   4.774 3.890
nonbonded pdb=" CB  PHE A  13 "
          pdb=" CA  GLU A  30 "
   model   vdw
   4.775 3.870
nonbonded pdb=" O   TYR A  34 "
          pdb=" O   VAL A  43 "
   model   vdw
   4.775 3.040
nonbonded pdb=" CB  PHE A  73 "
          pdb=" CA  GLY A  74 "
   model   vdw
   4.775 3.840
nonbonded pdb=" CB  GLU A  40 "
          pdb=" CE1 TYR A  34 "
   model   vdw sym.op.
   4.775 3.740 -x+1,y,-z+1
nonbonded pdb=" CE1 TYR A  34 "
          pdb=" CB  GLU A  40 "
   model   vdw sym.op.
   4.775 3.740 -x+1,y,-z+1
nonbonded pdb=" OD1 ASN A  39 "
          pdb=" O   TYR A  41 "
   model   vdw
   4.775 3.040
nonbonded pdb=" CG1 ILE A   2 "
          pdb=" CD1 PHE A  68 "
   model   vdw sym.op.
   4.775 3.740 -x+1,y,-z+2
nonbonded pdb=" CD1 PHE A  68 "
          pdb=" CG1 ILE A   2 "
   model   vdw sym.op.
   4.775 3.740 -x+1,y,-z+2
nonbonded pdb=" NE2 HIS A  64 "
          pdb=" CG1 VAL A  84 "
   model   vdw
   4.775 3.540
nonbonded pdb=" CA  VAL A  70 "
          pdb=" C   SER A  75 "
   model   vdw
   4.775 3.700
nonbonded pdb=" CG1 VAL A  45 "
          pdb=" CA  LEU A  76 "
   model   vdw sym.op.
   4.775 3.890 -x+1,y,-z+2
nonbonded pdb=" OE1 GLU A   5 "
          pdb=" CG  LEU A  60 "
   model   vdw
   4.776 3.470
nonbonded pdb=" CA  TYR A  34 "
          pdb=" O   VAL A  35 "
   model   vdw
   4.776 3.470
nonbonded pdb=" CA  TYR A  34 "
          pdb=" CB  VAL A  35 "
   model   vdw
   4.776 3.900
nonbonded pdb=" O   GLU A  30 "
          pdb=" O   ILE A  47 "
   model   vdw
   4.777 3.040
nonbonded pdb=" CG  GLN A  10 "
          pdb=" CA  LEU A  32 "
   model   vdw
   4.777 3.870
nonbonded pdb=" CA  LEU A  81 "
          pdb=" O   ARG A  82 "
   model   vdw
   4.777 3.470
nonbonded pdb=" CA  TYR A  26 "
          pdb=" O   SER A  27 "
   model   vdw
   4.777 3.470
nonbonded pdb=" CG2 ILE A  78 "
          pdb=" CA  LEU A  81 "
   model   vdw
   4.777 3.890
nonbonded pdb=" CA  VAL A  45 "
          pdb=" CB  LYS A  46 "
   model   vdw
   4.777 3.870
nonbonded pdb=" N   GLY A  74 "
          pdb=" O   SER A  75 "
   model   vdw
   4.778 3.120
nonbonded pdb=" N   ALA A  11 "
          pdb=" CB  GLN A  12 "
   model   vdw
   4.778 3.520
nonbonded pdb=" CA  LEU A  49 "
          pdb=" CB  ASP A  50 "
   model   vdw
   4.778 3.870
nonbonded pdb=" C   ILE A   6 "
          pdb=" CD  LYS A   7 "
   model   vdw
   4.778 3.670
nonbonded pdb=" CZ  TYR A  56 "
          pdb=" C   ARG A  82 "
   model   vdw
   4.778 3.490
nonbonded pdb=" CB  PHE A  68 "
          pdb=" C   MSE A  77 "
   model   vdw
   4.779 3.670
nonbonded pdb=" CA  PHE A  13 "
          pdb=" CA  GLN A  31 "
   model   vdw
   4.779 3.900
nonbonded pdb=" NZ  LYS A   7 "
          pdb="O    HOH S  12 "
   model   vdw
   4.779 3.120
nonbonded pdb=" C   LEU A  49 "
          pdb=" CZ  ARG A  80 "
   model   vdw
   4.780 3.500
nonbonded pdb=" OG  SER A  67 "
          pdb=" CB  PHE A  68 "
   model   vdw
   4.780 3.440
nonbonded pdb=" O   ILE A   2 "
          pdb=" CE2 PHE A  73 "
   model   vdw sym.op.
   4.780 3.340 -x+1,y+1,-z+2
nonbonded pdb=" O   GLN A  10 "
          pdb=" N   LEU A  32 "
   model   vdw
   4.780 3.120
nonbonded pdb=" C   LYS A   7 "
          pdb=" CA  PRO A  58 "
   model   vdw
   4.780 3.700
nonbonded pdb=" C   GLU A  30 "
          pdb=" C   ILE A  47 "
   model   vdw
   4.781 3.500
nonbonded pdb=" CG  ARG A  80 "
          pdb=" CZ  ARG A  82 "
   model   vdw
   4.781 3.670
nonbonded pdb=" OE1 GLN A  72 "
          pdb=" CD2 PHE A  73 "
   model   vdw
   4.781 3.340
nonbonded pdb=" CA  THR A  62 "
          pdb=" CB  VAL A  63 "
   model   vdw
   4.781 3.900
nonbonded pdb=" CB  SER A  67 "
          pdb=" CD1 LEU A  81 "
   model   vdw
   4.782 3.860
nonbonded pdb=" CA  GLN A  31 "
          pdb=" N   ILE A  47 "
   model   vdw
   4.782 3.550
nonbonded pdb=" N   GLN A  31 "
          pdb=" CB  ILE A  47 "
   model   vdw
   4.782 3.550
nonbonded pdb=" C   LEU A  44 "
          pdb=" CG1 VAL A  45 "
   model   vdw
   4.783 3.690
nonbonded pdb=" C   ASP A  79 "
          pdb=" NH1 ARG A  82 "
   model   vdw
   4.783 3.350
nonbonded pdb=" CB  LEU A  81 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   4.783 3.860
nonbonded pdb="O    HOH S   7 "
          pdb="O    HOH S  39 "
   model   vdw
   4.783 3.040
nonbonded pdb=" O   ILE A   2 "
          pdb="O    HOH S   5 "
   model   vdw
   4.783 3.040
nonbonded pdb=" C   SER A  17 "
          pdb=" CD2 TYR A  26 "
   model   vdw
   4.783 3.570
nonbonded pdb=" CA  GLY A  52 "
          pdb=" O   GLN A  53 "
   model   vdw
   4.783 3.440
nonbonded pdb=" N   PRO A   8 "
          pdb=" OG  SER A   9 "
   model   vdw
   4.783 3.120
nonbonded pdb=" N   TYR A  34 "
          pdb=" CA  VAL A  35 "
   model   vdw
   4.784 3.550
nonbonded pdb=" C   PHE A  73 "
          pdb=" CD2 PHE A  73 "
   model   vdw
   4.784 3.570
nonbonded pdb=" O   LYS A   7 "
          pdb=" CD  GLN A  10 "
   model   vdw
   4.784 3.270
nonbonded pdb=" N   LYS A  46 "
          pdb=" CA  ILE A  47 "
   model   vdw
   4.784 3.550
nonbonded pdb=" C   GLN A  31 "
          pdb=" O   VAL A  45 "
   model   vdw
   4.784 3.270
nonbonded pdb=" CG  TYR A  34 "
          pdb=" C   PRO A  42 "
   model   vdw
   4.785 3.490
nonbonded pdb=" CB  LYS A  69 "
          pdb=" CB  ASP A  79 "
   model   vdw
   4.785 3.840
nonbonded pdb=" C   SER A  67 "
          pdb=" CA  ASP A  79 "
   model   vdw
   4.785 3.700
nonbonded pdb=" OG1 THR A  15 "
          pdb=" ND2 ASN A  29 "
   model   vdw
   4.785 3.120
nonbonded pdb=" O   ASP A  79 "
          pdb=" CD  ARG A  80 "
   model   vdw
   4.785 3.440
nonbonded pdb=" CB  GLN A  72 "
          pdb=" CA  PHE A  73 "
   model   vdw
   4.785 3.870
nonbonded pdb=" C   LEU A  81 "
          pdb=" CD  ARG A  82 "
   model   vdw
   4.785 3.670
nonbonded pdb=" N   GLY A  71 "
          pdb=" CA  LEU A  76 "
   model   vdw
   4.785 3.550
nonbonded pdb=" OG1 THR A  62 "
          pdb=" CE2 PHE A  73 "
   model   vdw sym.op.
   4.785 3.340 -x+1,y+1,-z+2
nonbonded pdb=" CZ  ARG A  16 "
          pdb=" CG  PRO A  85 "
   model   vdw sym.op.
   4.785 3.670 x,y-1,z
nonbonded pdb=" N   TYR A  61 "
          pdb=" CE1 PHE A  73 "
   model   vdw sym.op.
   4.785 3.420 -x+1,y+1,-z+2
nonbonded pdb=" CA  GLY A  71 "
          pdb=" C   SER A  75 "
   model   vdw
   4.785 3.670
nonbonded pdb=" CB  THR A  62 "
          pdb=" O   VAL A  63 "
   model   vdw
   4.785 3.470
nonbonded pdb=" N   ASP A  36 "
          pdb=" OD2 ASP A  36 "
   model   vdw
   4.786 3.120
nonbonded pdb=" C   GLY A  52 "
          pdb=" CG  GLN A  53 "
   model   vdw
   4.786 3.670
nonbonded pdb=" CB  ILE A  78 "
          pdb=" CD1 ILE A  78 "
   model   vdw sym.op.
   4.786 3.890 -x+1,y,-z+2
nonbonded pdb=" CD1 ILE A  78 "
          pdb=" CB  ILE A  78 "
   model   vdw sym.op.
   4.786 3.890 -x+1,y,-z+2
nonbonded pdb=" CZ  ARG A  16 "
          pdb=" OE2 GLU A  30 "
   model   vdw
   4.786 3.270
nonbonded pdb=" CD1 TYR A  26 "
          pdb=" O   SER A  27 "
   model   vdw
   4.786 3.340
nonbonded pdb=" N   GLY A  71 "
          pdb=" N   SER A  75 "
   model   vdw
   4.786 3.200
nonbonded pdb=" C   ILE A   2 "
          pdb=" O   TYR A  61 "
   model   vdw
   4.786 3.270
nonbonded pdb=" CA  LYS A  46 "
          pdb=" O   ILE A  47 "
   model   vdw
   4.786 3.470
nonbonded pdb=" CA  LEU A  60 "
          pdb=" O   TYR A  61 "
   model   vdw
   4.787 3.470
nonbonded pdb=" N   SER A  67 "
          pdb=" CG  PHE A  68 "
   model   vdw
   4.787 3.340
nonbonded pdb=" C   ILE A   6 "
          pdb=" CD1 ILE A   6 "
   model   vdw
   4.787 3.690
nonbonded pdb=" C   ALA A  11 "
          pdb=" OE1 GLN A  12 "
   model   vdw
   4.787 3.270
nonbonded pdb=" CA  ASN A  29 "
          pdb=" CB  LEU A  49 "
   model   vdw
   4.788 3.870
nonbonded pdb=" O   LEU A  28 "
          pdb=" CG  GLU A  30 "
   model   vdw
   4.788 3.440
nonbonded pdb=" O   ASN A  39 "
          pdb=" CG  ASN A  39 "
   model   vdw
   4.788 3.270
nonbonded pdb=" CA  ARG A  82 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   4.789 3.890
nonbonded pdb=" N   PHE A  13 "
          pdb=" CA  THR A  14 "
   model   vdw
   4.789 3.550
nonbonded pdb=" C   LEU A  32 "
          pdb=" N   TYR A  34 "
   model   vdw
   4.789 3.350
nonbonded pdb=" C   ILE A   2 "
          pdb=" CB  THR A  62 "
   model   vdw
   4.789 3.700
nonbonded pdb=" C   VAL A  43 "
          pdb=" CG2 VAL A  45 "
   model   vdw
   4.789 3.690
nonbonded pdb=" O   GLN A  10 "
          pdb=" CB  GLN A  31 "
   model   vdw
   4.789 3.440
nonbonded pdb=" O   VAL A   4 "
          pdb=" O   GLU A   5 "
   model   vdw
   4.789 3.040
nonbonded pdb=" C   GLN A  72 "
          pdb=" NE2 GLN A  72 "
   model   vdw
   4.789 3.350
nonbonded pdb=" CG  TYR A  34 "
          pdb=" CD1 LEU A  44 "
   model   vdw
   4.789 3.680
nonbonded pdb=" CB  PHE A  68 "
          pdb=" O   LYS A  69 "
   model   vdw
   4.789 3.440
nonbonded pdb=" N   HIS A  64 "
          pdb=" CB  SER A  67 "
   model   vdw
   4.790 3.520
nonbonded pdb=" CA  THR A  48 "
          pdb=" CB  LEU A  49 "
   model   vdw
   4.790 3.870
nonbonded pdb=" CG2 THR A  62 "
          pdb=" C   VAL A  84 "
   model   vdw
   4.790 3.690
nonbonded pdb=" CA  ARG A  82 "
          pdb=" C   LEU A  83 "
   model   vdw
   4.790 3.700
nonbonded pdb=" CA  VAL A   4 "
          pdb=" N   TYR A  61 "
   model   vdw
   4.790 3.550
nonbonded pdb=" N   ILE A   2 "
          pdb=" CA  LYS A   3 "
   model   vdw
   4.790 3.550
nonbonded pdb=" N   ALA A  57 "
          pdb=" CA  PRO A  58 "
   model   vdw
   4.791 3.550
nonbonded pdb=" CG  ASP A  50 "
          pdb=" CG  ARG A  82 "
   model   vdw
   4.791 3.670
nonbonded pdb=" C   TYR A  61 "
          pdb=" CZ  PHE A  73 "
   model   vdw sym.op.
   4.791 3.570 -x+1,y+1,-z+2
nonbonded pdb=" N   TYR A  61 "
          pdb=" CA  THR A  62 "
   model   vdw
   4.792 3.550
nonbonded pdb=" CZ  PHE A  13 "
          pdb=" OG1 THR A  15 "
   model   vdw
   4.792 3.340
nonbonded pdb=" CB  ALA A  11 "
          pdb=" N   PRO A  58 "
   model   vdw
   4.792 3.540
nonbonded pdb=" CE2 TYR A  61 "
          pdb=" O   VAL A  84 "
   model   vdw
   4.793 3.340
nonbonded pdb=" CA  ALA A  11 "
          pdb=" CD  GLN A  12 "
   model   vdw
   4.794 3.700
nonbonded pdb=" O   TYR A  34 "
          pdb=" CB  PRO A  42 "
   model   vdw
   4.794 3.440
nonbonded pdb=" O   ASP A  36 "
          pdb=" O   LEU A  37 "
   model   vdw
   4.794 3.040
nonbonded pdb=" CB  SER A  66 "
          pdb=" NE  ARG A  82 "
   model   vdw
   4.795 3.520
nonbonded pdb=" CA  ARG A  80 "
          pdb=" O   LEU A  81 "
   model   vdw
   4.795 3.470
nonbonded pdb=" CG  LEU A  65 "
          pdb=" CB  LEU A  37 "
   model   vdw sym.op.
   4.795 3.870 -x+1,y,-z+2
nonbonded pdb=" CB  LEU A  37 "
          pdb=" CG  LEU A  65 "
   model   vdw sym.op.
   4.795 3.870 -x+1,y,-z+2
nonbonded pdb=" O   PRO A  58 "
          pdb=" O   GLY A  59 "
   model   vdw
   4.795 3.040
nonbonded pdb=" CA  THR A  62 "
          pdb=" CG2 VAL A  63 "
   model   vdw
   4.796 3.890
nonbonded pdb=" O   THR A  14 "
          pdb=" O   ASN A  29 "
   model   vdw
   4.796 3.040
nonbonded pdb=" CA  ASP A  50 "
          pdb=" CB  GLN A  53 "
   model   vdw
   4.796 3.870
nonbonded pdb=" CD2 LEU A  49 "
          pdb=" N   ASP A  50 "
   model   vdw
   4.797 3.540
nonbonded pdb=" CA  GLN A  10 "
          pdb=" OE1 GLN A  12 "
   model   vdw
   4.797 3.470
nonbonded pdb=" N   ILE A  78 "
          pdb=" CA  ASP A  79 "
   model   vdw
   4.797 3.550
nonbonded pdb=" N   LEU A  65 "
          pdb=" CD2 LEU A  65 "
   model   vdw
   4.798 3.540
nonbonded pdb=" CE1 TYR A  26 "
          pdb=" N   LEU A  28 "
   model   vdw
   4.798 3.420
nonbonded pdb=" CD  PRO A  58 "
          pdb=" N   GLY A  59 "
   model   vdw
   4.798 3.520
nonbonded pdb=" N   GLU A  51 "
          pdb=" NH1 ARG A  80 "
   model   vdw
   4.798 3.200
nonbonded pdb=" CD  LYS A   3 "
          pdb=" NE2 GLN A  72 "
   model   vdw sym.op.
   4.798 3.520 -x+1,y+1,-z+2
nonbonded pdb=" NE2 GLN A  72 "
          pdb=" CD  LYS A   3 "
   model   vdw sym.op.
   4.798 3.520 -x+1,y-1,-z+2
nonbonded pdb=" N   GLY A  38 "
          pdb=" CG  ASN A  39 "
   model   vdw
   4.799 3.350
nonbonded pdb=" C   PHE A  68 "
          pdb=" CD2 PHE A  68 "
   model   vdw
   4.799 3.570
nonbonded pdb=" CB  THR A  62 "
          pdb=" CG2 VAL A  84 "
   model   vdw
   4.799 3.890
nonbonded pdb=" O   GLN A  72 "
          pdb=" O   PHE A  73 "
   model   vdw
   4.800 3.040
nonbonded pdb=" C   HIS A  64 "
          pdb=" NE2 HIS A  64 "
   model   vdw
   4.800 3.350
nonbonded pdb=" C   GLU A   5 "
          pdb=" CG2 ILE A   6 "
   model   vdw
   4.800 3.690
nonbonded pdb=" CD2 TYR A  61 "
          pdb=" CB  PRO A  85 "
   model   vdw
   4.800 3.740
nonbonded pdb=" O   VAL A   4 "
          pdb=" O   LEU A  60 "
   model   vdw
   4.800 3.040
nonbonded pdb=" CB  PRO A  58 "
          pdb="O    HOH S  12 "
   model   vdw
   4.800 3.440
nonbonded pdb=" CA  ASN A  29 "
          pdb=" C   GLU A  30 "
   model   vdw
   4.801 3.700
nonbonded pdb=" CA  GLU A   5 "
          pdb=" N   TYR A  34 "
   model   vdw
   4.801 3.550
nonbonded pdb=" CG2 VAL A  63 "
          pdb=" O   ARG A  82 "
   model   vdw
   4.801 3.460
nonbonded pdb=" N   GLY A  52 "
          pdb=" C   GLN A  53 "
   model   vdw
   4.801 3.350
nonbonded pdb=" N   VAL A  45 "
          pdb=" CA  LYS A  46 "
   model   vdw
   4.801 3.550
nonbonded pdb=" OD2 ASP A  79 "
          pdb=" CA  ARG A  80 "
   model   vdw
   4.802 3.470
nonbonded pdb=" O   TYR A  61 "
          pdb=" CD1 PHE A  73 "
   model   vdw sym.op.
   4.802 3.340 -x+1,y+1,-z+2
nonbonded pdb=" CB  VAL A  70 "
          pdb=" CA  GLY A  71 "
   model   vdw
   4.802 3.870
nonbonded pdb=" CG2 ILE A   2 "
          pdb="O    HOH S  19 "
   model   vdw
   4.802 3.460
nonbonded pdb=" C   LEU A  49 "
          pdb=" OD2 ASP A  50 "
   model   vdw
   4.802 3.270
nonbonded pdb=" CE  LYS A   7 "
          pdb=" CD  GLU A  40 "
   model   vdw sym.op.
   4.802 3.670 -x+1,y,-z+1
nonbonded pdb=" CA  HIS A  64 "
          pdb=" CG2 VAL A  84 "
   model   vdw
   4.803 3.890
nonbonded pdb=" CZ  PHE A  68 "
          pdb=" CG1 ILE A  78 "
   model   vdw
   4.803 3.740
nonbonded pdb=" CD2 TYR A  61 "
          pdb=" CG  PRO A  85 "
   model   vdw
   4.803 3.740
nonbonded pdb=" CA  VAL A  35 "
          pdb=" CG2 VAL A  43 "
   model   vdw
   4.803 3.890
nonbonded pdb=" CD  LYS A  69 "
          pdb=" N   VAL A  70 "
   model   vdw
   4.803 3.520
nonbonded pdb=" O   VAL A   4 "
          pdb=" CG  GLU A   5 "
   model   vdw
   4.804 3.440
nonbonded pdb=" N   PRO A   8 "
          pdb=" OE2 GLU A  40 "
   model   vdw sym.op.
   4.804 3.120 -x+1,y,-z+1
nonbonded pdb=" CA  VAL A  45 "
          pdb=" C   GLY A  74 "
   model   vdw sym.op.
   4.804 3.700 -x+1,y,-z+2
nonbonded pdb=" N   LYS A   3 "
          pdb=" CA  VAL A   4 "
   model   vdw
   4.804 3.550
nonbonded pdb=" C   THR A  14 "
          pdb=" C   ASN A  29 "
   model   vdw
   4.804 3.500
nonbonded pdb=" C   GLN A  10 "
          pdb=" OE1 GLN A  12 "
   model   vdw
   4.804 3.270
nonbonded pdb=" CG  LYS A  69 "
          pdb=" CB  MSE A  77 "
   model   vdw
   4.804 3.840
nonbonded pdb=" CA  ARG A  16 "
          pdb=" C   SER A  17 "
   model   vdw
   4.804 3.700
nonbonded pdb=" C   TYR A  34 "
          pdb=" CG1 VAL A  35 "
   model   vdw
   4.805 3.690
nonbonded pdb=" O   ILE A   6 "
          pdb=" O   ALA A  57 "
   model   vdw
   4.805 3.040
nonbonded pdb=" CA  HIS A  64 "
          pdb=" CB  LEU A  65 "
   model   vdw
   4.805 3.870
nonbonded pdb=" O   LYS A   7 "
          pdb=" O   SER A   9 "
   model   vdw
   4.805 3.040
nonbonded pdb=" CG2 VAL A  45 "
          pdb=" CA  LEU A  76 "
   model   vdw sym.op.
   4.805 3.890 -x+1,y,-z+2
nonbonded pdb=" O   LEU A  32 "
          pdb=" O   CYS A  33 "
   model   vdw
   4.806 3.040
nonbonded pdb=" CG2 ILE A   2 "
          pdb="O    HOH S   5 "
   model   vdw
   4.806 3.460
nonbonded pdb=" N   LYS A  69 "
          pdb=" N   MSE A  77 "
   model   vdw
   4.806 3.200
nonbonded pdb=" O   THR A  14 "
          pdb=" CG  GLU A  30 "
   model   vdw
   4.806 3.440
nonbonded pdb=" CD  PRO A  42 "
          pdb=" N   VAL A  43 "
   model   vdw
   4.806 3.520
nonbonded pdb=" O   TYR A  61 "
          pdb=" N   VAL A  63 "
   model   vdw
   4.807 3.120
nonbonded pdb=" CA  GLY A  71 "
          pdb=" CB  GLN A  72 "
   model   vdw
   4.807 3.840
nonbonded pdb=" O   PHE A  68 "
          pdb=" CD1 PHE A  68 "
   model   vdw
   4.807 3.340
nonbonded pdb=" CA  LYS A   7 "
          pdb=" OG  SER A   9 "
   model   vdw
   4.808 3.470
nonbonded pdb=" CD2 LEU A  76 "
          pdb=" CG  LEU A  81 "
   model   vdw sym.op.
   4.808 3.890 -x+1,y,-z+2
nonbonded pdb=" OG1 THR A  62 "
          pdb=" C   VAL A  63 "
   model   vdw
   4.808 3.270
nonbonded pdb=" N   SER A  66 "
          pdb=" C   SER A  67 "
   model   vdw
   4.808 3.350
nonbonded pdb=" CA  HIS A  64 "
          pdb=" OG  SER A  66 "
   model   vdw
   4.808 3.470
nonbonded pdb=" N   PRO A   8 "
          pdb=" C   SER A   9 "
   model   vdw
   4.809 3.350
nonbonded pdb=" CA  SER A  17 "
          pdb=" N   SER A  27 "
   model   vdw
   4.809 3.550
nonbonded pdb=" CA  LYS A  46 "
          pdb="O    HOH S   6 "
   model   vdw sym.op.
   4.809 3.470 -x+1,y,-z+2
nonbonded pdb=" O   TYR A  56 "
          pdb="O    HOH S   7 "
   model   vdw
   4.809 3.040
nonbonded pdb=" CA  LEU A  32 "
          pdb=" O   CYS A  33 "
   model   vdw
   4.809 3.470
nonbonded pdb=" CA  LEU A  83 "
          pdb=" CG1 VAL A  84 "
   model   vdw
   4.809 3.890
nonbonded pdb=" CG  PHE A  68 "
          pdb=" CD2 LEU A  76 "
   model   vdw
   4.810 3.680
nonbonded pdb=" O   PHE A  13 "
          pdb=" O   GLU A  30 "
   model   vdw
   4.810 3.040
nonbonded pdb=" CB  GLN A  10 "
          pdb=" N   CYS A  33 "
   model   vdw
   4.811 3.520
nonbonded pdb=" O   LEU A  60 "
          pdb=" CZ  TYR A  61 "
   model   vdw
   4.811 3.260
nonbonded pdb=" C   SER A  75 "
          pdb=" CG  MSE A  77 "
   model   vdw
   4.811 3.670
nonbonded pdb=" CA  LYS A  69 "
          pdb=" CB  VAL A  70 "
   model   vdw
   4.811 3.900
nonbonded pdb=" O   GLN A  31 "
          pdb=" C   VAL A  45 "
   model   vdw
   4.811 3.270
nonbonded pdb=" C   PHE A  73 "
          pdb=" OG  SER A  75 "
   model   vdw
   4.812 3.270
nonbonded pdb=" CG  LEU A  76 "
          pdb=" CD1 LEU A  81 "
   model   vdw sym.op.
   4.812 3.890 -x+1,y,-z+2
nonbonded pdb=" O   GLN A  10 "
          pdb=" CD  GLN A  12 "
   model   vdw
   4.812 3.270
nonbonded pdb=" CA  TYR A  41 "
          pdb="O    HOH S   9 "
   model   vdw
   4.812 3.470
nonbonded pdb=" N   VAL A  35 "
          pdb=" C   PRO A  42 "
   model   vdw
   4.812 3.350
nonbonded pdb=" CB  VAL A  35 "
          pdb=" CG  LEU A  37 "
   model   vdw
   4.812 3.900
nonbonded pdb=" N   CYS A  33 "
          pdb=" CA  TYR A  34 "
   model   vdw
   4.812 3.550
nonbonded pdb=" CG  LEU A  76 "
          pdb=" C   MSE A  77 "
   model   vdw
   4.813 3.700
nonbonded pdb=" N   LEU A  44 "
          pdb=" CD2 LEU A  44 "
   model   vdw
   4.813 3.540
nonbonded pdb=" N   PHE A  68 "
          pdb=" O   MSE A  77 "
   model   vdw
   4.813 3.120
nonbonded pdb=" C   ASN A  29 "
          pdb=" CA  LEU A  49 "
   model   vdw
   4.813 3.700
nonbonded pdb=" CB  ILE A   2 "
          pdb="O    HOH S  30 "
   model   vdw
   4.813 3.470
nonbonded pdb=" CB  ARG A  80 "
          pdb=" C   LEU A  81 "
   model   vdw
   4.813 3.670
nonbonded pdb=" CG1 VAL A  70 "
          pdb=" C   SER A  75 "
   model   vdw
   4.813 3.690
nonbonded pdb=" OD1 ASP A  50 "
          pdb=" CD  GLU A  51 "
   model   vdw
   4.813 3.270
nonbonded pdb=" CA  GLY A  52 "
          pdb="O    HOH S  20 "
   model   vdw
   4.813 3.440
nonbonded pdb=" CB  PRO A  54 "
          pdb="O    HOH S  39 "
   model   vdw
   4.813 3.440
nonbonded pdb=" C   GLN A  12 "
          pdb=" O   GLU A  30 "
   model   vdw
   4.813 3.270
nonbonded pdb=" CG  ARG A  16 "
          pdb=" C   LEU A  28 "
   model   vdw
   4.813 3.670
nonbonded pdb=" O   LEU A  76 "
          pdb=" CD2 LEU A  76 "
   model   vdw
   4.813 3.460
nonbonded pdb=" N   MSE A  77 "
          pdb=" CA  ILE A  78 "
   model   vdw
   4.814 3.550
nonbonded pdb=" O   LEU A  49 "
          pdb=" CD  GLU A  51 "
   model   vdw
   4.814 3.270
nonbonded pdb=" C   GLN A  12 "
          pdb=" OE1 GLN A  12 "
   model   vdw
   4.814 3.270
nonbonded pdb=" CD1 ILE A  78 "
          pdb=" CA  ILE A  78 "
   model   vdw sym.op.
   4.814 3.890 -x+1,y,-z+2
nonbonded pdb=" CA  ILE A  78 "
          pdb=" CD1 ILE A  78 "
   model   vdw sym.op.
   4.814 3.890 -x+1,y,-z+2
nonbonded pdb=" N   VAL A  84 "
          pdb=" CA  PRO A  85 "
   model   vdw
   4.814 3.550
nonbonded pdb=" N   VAL A  63 "
          pdb=" O   ARG A  82 "
   model   vdw
   4.815 3.120
nonbonded pdb=" O   GLN A  31 "
          pdb=" O   LYS A  46 "
   model   vdw
   4.815 3.040
nonbonded pdb=" C   GLN A  31 "
          pdb=" CD1 LEU A  32 "
   model   vdw
   4.815 3.690
nonbonded pdb=" CG2 VAL A  43 "
          pdb="O    HOH S   9 "
   model   vdw
   4.816 3.460
nonbonded pdb=" OE1 GLN A  72 "
          pdb=" C   ILE A   2 "
   model   vdw sym.op.
   4.816 3.270 -x+1,y-1,-z+2
nonbonded pdb=" C   ILE A   2 "
          pdb=" OE1 GLN A  72 "
   model   vdw sym.op.
   4.816 3.270 -x+1,y+1,-z+2
nonbonded pdb=" CA  ALA A  55 "
          pdb=" CB  TYR A  56 "
   model   vdw
   4.816 3.870
nonbonded pdb=" CG1 VAL A  70 "
          pdb=" N   SER A  75 "
   model   vdw
   4.816 3.540
nonbonded pdb=" CA  LEU A  28 "
          pdb=" CG  ASN A  29 "
   model   vdw
   4.816 3.700
nonbonded pdb=" CE  LYS A   7 "
          pdb=" CD1 TYR A  34 "
   model   vdw
   4.816 3.740
nonbonded pdb=" CE1 TYR A  26 "
          pdb=" CA  SER A  27 "
   model   vdw
   4.816 3.770
nonbonded pdb=" CB  GLN A  10 "
          pdb=" CA  ALA A  11 "
   model   vdw
   4.816 3.870
nonbonded pdb=" N   GLN A  53 "
          pdb=" CD  GLN A  53 "
   model   vdw
   4.816 3.350
nonbonded pdb=" C   LYS A  69 "
          pdb=" C   MSE A  77 "
   model   vdw
   4.816 3.500
nonbonded pdb=" CB  ILE A  78 "
          pdb=" C   ASP A  79 "
   model   vdw
   4.817 3.700
nonbonded pdb=" CB  LEU A  37 "
          pdb=" O   PHE A  68 "
   model   vdw sym.op.
   4.817 3.440 -x+1,y,-z+2
nonbonded pdb=" N   LYS A  69 "
          pdb="O    HOH S  10 "
   model   vdw
   4.817 3.120
nonbonded pdb=" CA  LYS A   3 "
          pdb=" CE  LYS A   3 "
   model   vdw
   4.817 3.870
nonbonded pdb=" CA  LEU A  32 "
          pdb=" C   CYS A  33 "
   model   vdw
   4.817 3.700
nonbonded pdb=" CA  SER A  67 "
          pdb=" C   PHE A  68 "
   model   vdw
   4.817 3.700
nonbonded pdb=" CE2 TYR A  61 "
          pdb=" CD  PRO A  85 "
   model   vdw
   4.817 3.740
nonbonded pdb=" N   GLN A  12 "
          pdb=" CA  PHE A  13 "
   model   vdw
   4.817 3.550
nonbonded pdb=" C   VAL A  35 "
          pdb=" CG  ASP A  36 "
   model   vdw
   4.817 3.500
nonbonded pdb=" N   THR A  15 "
          pdb=" OD1 ASN A  29 "
   model   vdw
   4.818 3.120
nonbonded pdb=" C   CYS A  33 "
          pdb=" CA  VAL A  45 "
   model   vdw
   4.818 3.700
nonbonded pdb=" CG  GLU A   5 "
          pdb=" CE  LYS A   7 "
   model   vdw
   4.818 3.840
nonbonded pdb=" C   THR A  48 "
          pdb=" CZ  ARG A  80 "
   model   vdw
   4.819 3.500
nonbonded pdb=" CA  VAL A  43 "
          pdb=" CB  LEU A  44 "
   model   vdw
   4.819 3.870
nonbonded pdb=" CA  ASP A  50 "
          pdb=" CG  GLU A  51 "
   model   vdw
   4.819 3.870
nonbonded pdb=" O   ASP A  79 "
          pdb=" O   ARG A  80 "
   model   vdw
   4.819 3.040
nonbonded pdb=" C   VAL A  63 "
          pdb=" CG2 VAL A  84 "
   model   vdw
   4.819 3.690
nonbonded pdb=" CB  ILE A  78 "
          pdb=" CA  MSE A  77 "
   model   vdw sym.op.
   4.820 3.900 -x+1,y,-z+2
nonbonded pdb=" CA  MSE A  77 "
          pdb=" CB  ILE A  78 "
   model   vdw sym.op.
   4.820 3.900 -x+1,y,-z+2
nonbonded pdb=" CG1 VAL A   4 "
          pdb=" C   TYR A  34 "
   model   vdw
   4.820 3.690
nonbonded pdb=" OG  SER A  67 "
          pdb=" C   LEU A  81 "
   model   vdw
   4.820 3.270
nonbonded pdb=" O   SER A  17 "
          pdb=" CD1 TYR A  26 "
   model   vdw
   4.821 3.340
nonbonded pdb=" CA  LEU A  76 "
          pdb=" CG  MSE A  77 "
   model   vdw
   4.821 3.870
nonbonded pdb=" CA  ILE A  78 "
          pdb=" CB  ASP A  79 "
   model   vdw
   4.821 3.870
nonbonded pdb=" CG  GLU A  30 "
          pdb=" CA  THR A  48 "
   model   vdw
   4.821 3.870
nonbonded pdb=" CB  GLU A  40 "
          pdb=" CZ  TYR A  34 "
   model   vdw sym.op.
   4.822 3.660 -x+1,y,-z+1
nonbonded pdb=" CZ  TYR A  34 "
          pdb=" CB  GLU A  40 "
   model   vdw sym.op.
   4.822 3.660 -x+1,y,-z+1
nonbonded pdb=" CA  ILE A   6 "
          pdb=" CB  GLN A  10 "
   model   vdw
   4.822 3.870
nonbonded pdb=" CB  GLU A   5 "
          pdb=" C   GLY A  59 "
   model   vdw
   4.822 3.670
nonbonded pdb=" CA  PRO A  42 "
          pdb=" CB  VAL A  43 "
   model   vdw
   4.823 3.900
nonbonded pdb=" CG  HIS A  64 "
          pdb=" O   ARG A  82 "
   model   vdw
   4.823 3.260
nonbonded pdb=" CD1 LEU A  60 "
          pdb=" CA  PHE A  73 "
   model   vdw sym.op.
   4.823 3.890 -x+1,y+1,-z+2
nonbonded pdb=" OH  TYR A  26 "
          pdb=" CZ  TYR A  61 "
   model   vdw sym.op.
   4.823 3.260 x,y-1,z
nonbonded pdb=" CG2 THR A  15 "
          pdb=" C   SER A  27 "
   model   vdw
   4.823 3.690
nonbonded pdb=" C   ALA A  55 "
          pdb=" CA  ALA A  57 "
   model   vdw
   4.823 3.700
nonbonded pdb=" CA  TYR A  61 "
          pdb=" N   PRO A  85 "
   model   vdw
   4.823 3.550
nonbonded pdb=" O   GLU A   5 "
          pdb=" O   GLY A  59 "
   model   vdw
   4.824 3.040
nonbonded pdb=" CE1 TYR A  61 "
          pdb=" CD1 LEU A  83 "
   model   vdw
   4.825 3.760
nonbonded pdb=" CA  SER A  66 "
          pdb=" NH1 ARG A  82 "
   model   vdw
   4.825 3.550
nonbonded pdb=" OH  TYR A  26 "
          pdb=" N   PRO A  85 "
   model   vdw sym.op.
   4.826 3.120 x,y-1,z
nonbonded pdb=" O   TYR A  61 "
          pdb=" CG2 THR A  62 "
   model   vdw
   4.826 3.460
nonbonded pdb=" CA  GLY A  74 "
          pdb=" CB  SER A  75 "
   model   vdw
   4.826 3.840
nonbonded pdb=" O   ARG A  16 "
          pdb=" O   SER A  27 "
   model   vdw
   4.826 3.040
nonbonded pdb=" CG  PHE A  13 "
          pdb=" O   GLU A  30 "
   model   vdw
   4.827 3.260
nonbonded pdb=" N   SER A  75 "
          pdb="O    HOH S   6 "
   model   vdw
   4.827 3.120
nonbonded pdb=" N   LYS A  69 "
          pdb=" CA  VAL A  70 "
   model   vdw
   4.828 3.550
nonbonded pdb=" N   GLU A   5 "
          pdb=" CA  TYR A  34 "
   model   vdw
   4.828 3.550
nonbonded pdb=" C   PRO A   8 "
          pdb=" O   PHE A  13 "
   model   vdw sym.op.
   4.829 3.270 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CB  ILE A  47 "
          pdb=" O   LEU A  81 "
   model   vdw
   4.829 3.470
nonbonded pdb=" CG  LEU A  49 "
          pdb=" O   GLN A  53 "
   model   vdw
   4.830 3.470
nonbonded pdb=" O   LEU A  44 "
          pdb=" O   VAL A  45 "
   model   vdw
   4.830 3.040
nonbonded pdb=" C   GLU A   5 "
          pdb=" C   GLY A  59 "
   model   vdw
   4.830 3.500
nonbonded pdb=" C   ASP A  50 "
          pdb=" CD  GLN A  53 "
   model   vdw
   4.830 3.500
nonbonded pdb=" C   LYS A   3 "
          pdb=" CG1 VAL A   4 "
   model   vdw
   4.831 3.690
nonbonded pdb=" N   MSE A  77 "
          pdb="O    HOH S  13 "
   model   vdw
   4.831 3.120
nonbonded pdb=" O   VAL A   4 "
          pdb=" C   GLY A  59 "
   model   vdw
   4.831 3.270
nonbonded pdb="O    HOH S  13 "
          pdb=" N   MSE A  77 "
   model   vdw sym.op.
   4.831 3.120 -x+1,y,-z+2
nonbonded pdb=" N   MSE A  77 "
          pdb="O    HOH S  13 "
   model   vdw sym.op.
   4.831 3.120 -x+1,y,-z+2
nonbonded pdb=" CA  ASN A  39 "
          pdb=" CB  GLU A  40 "
   model   vdw
   4.832 3.870
nonbonded pdb=" O   PHE A  73 "
          pdb=" OG  SER A  75 "
   model   vdw
   4.832 3.040
nonbonded pdb=" CZ  ARG A  16 "
          pdb=" C   PRO A  85 "
   model   vdw sym.op.
   4.832 3.500 x,y-1,z
nonbonded pdb=" N   GLU A  30 "
          pdb=" CA  GLN A  31 "
   model   vdw
   4.832 3.550
nonbonded pdb=" CA  TYR A  34 "
          pdb=" CA  LEU A  44 "
   model   vdw
   4.832 3.900
nonbonded pdb=" CA  LYS A  69 "
          pdb=" CG2 VAL A  70 "
   model   vdw
   4.832 3.890
nonbonded pdb=" OH  TYR A  56 "
          pdb=" N   ARG A  82 "
   model   vdw
   4.833 3.120
nonbonded pdb=" CA  VAL A   4 "
          pdb=" CG2 VAL A  35 "
   model   vdw
   4.833 3.890
nonbonded pdb=" CB  LYS A   7 "
          pdb=" CB  SER A   9 "
   model   vdw
   4.833 3.840
nonbonded pdb=" CD1 LEU A  49 "
          pdb=" C   GLN A  53 "
   model   vdw
   4.833 3.690
nonbonded pdb=" C   GLU A  40 "
          pdb=" CE1 TYR A  41 "
   model   vdw
   4.833 3.570
nonbonded pdb=" NE  ARG A  16 "
          pdb=" CG  PRO A  85 "
   model   vdw sym.op.
   4.833 3.520 x,y-1,z
nonbonded pdb=" C   GLY A  59 "
          pdb=" CZ  TYR A  61 "
   model   vdw
   4.834 3.490
nonbonded pdb=" CG2 VAL A  84 "
          pdb=" C   PRO A  85 "
   model   vdw
   4.834 3.690
nonbonded pdb=" C   VAL A  63 "
          pdb=" CG  HIS A  64 "
   model   vdw
   4.835 3.490
nonbonded pdb=" CB  LYS A   7 "
          pdb=" C   PRO A   8 "
   model   vdw
   4.835 3.670
nonbonded pdb=" N   SER A   9 "
          pdb=" CB  GLN A  10 "
   model   vdw
   4.835 3.520
nonbonded pdb=" CB  LYS A   7 "
          pdb=" CG  GLU A  40 "
   model   vdw sym.op.
   4.835 3.840 -x+1,y,-z+1
nonbonded pdb=" CB  ASP A  36 "
          pdb=" CA  LEU A  37 "
   model   vdw
   4.835 3.870
nonbonded pdb=" N   PRO A  58 "
          pdb=" CA  GLY A  59 "
   model   vdw
   4.835 3.520
nonbonded pdb=" CE  LYS A   7 "
          pdb=" CE1 TYR A  41 "
   model   vdw sym.op.
   4.836 3.740 -x+1,y,-z+1
nonbonded pdb=" CA  THR A  62 "
          pdb=" CZ  PHE A  73 "
   model   vdw sym.op.
   4.836 3.770 -x+1,y+1,-z+2
nonbonded pdb=" CA  LYS A  69 "
          pdb=" O   VAL A  70 "
   model   vdw
   4.836 3.470
nonbonded pdb=" C   TYR A  41 "
          pdb=" CD2 TYR A  41 "
   model   vdw
   4.836 3.570
nonbonded pdb=" CD1 TYR A  26 "
          pdb=" CG  LEU A  28 "
   model   vdw
   4.836 3.770
nonbonded pdb=" C   SER A  66 "
          pdb=" C   PHE A  68 "
   model   vdw
   4.837 3.500
nonbonded pdb=" CZ  ARG A  16 "
          pdb=" CE2 TYR A  61 "
   model   vdw sym.op.
   4.837 3.570 x,y-1,z
nonbonded pdb=" CA  ILE A   6 "
          pdb=" CD  GLN A  10 "
   model   vdw
   4.837 3.700
nonbonded pdb=" C   LYS A  69 "
          pdb=" CG1 VAL A  70 "
   model   vdw
   4.837 3.690
nonbonded pdb=" C   ASP A  36 "
          pdb=" CA  GLY A  38 "
   model   vdw
   4.838 3.670
nonbonded pdb=" CB  THR A  15 "
          pdb=" C   ARG A  16 "
   model   vdw
   4.838 3.700
nonbonded pdb=" C   SER A  17 "
          pdb=" CG  TYR A  26 "
   model   vdw
   4.838 3.490
nonbonded pdb=" C   GLN A  31 "
          pdb=" C   ILE A  47 "
   model   vdw
   4.838 3.500
nonbonded pdb=" OG  SER A  67 "
          pdb=" CG  LEU A  81 "
   model   vdw
   4.838 3.470
nonbonded pdb=" CA  VAL A  35 "
          pdb=" CB  ASP A  36 "
   model   vdw
   4.839 3.870
nonbonded pdb=" OD1 ASN A  39 "
          pdb=" CG1 VAL A  43 "
   model   vdw
   4.839 3.460
nonbonded pdb=" CG1 VAL A   4 "
          pdb=" CD1 ILE A  47 "
   model   vdw
   4.840 3.880
nonbonded pdb=" CD2 LEU A  65 "
          pdb=" CD2 LEU A  37 "
   model   vdw sym.op.
   4.840 3.880 -x+1,y,-z+2
nonbonded pdb=" CD2 LEU A  37 "
          pdb=" CD2 LEU A  65 "
   model   vdw sym.op.
   4.840 3.880 -x+1,y,-z+2
nonbonded pdb=" N   THR A  62 "
          pdb=" CA  VAL A  84 "
   model   vdw
   4.841 3.550
nonbonded pdb=" CB  PRO A   8 "
          pdb=" CG  PRO A  58 "
   model   vdw
   4.841 3.840
nonbonded pdb=" N   THR A  62 "
          pdb=" CA  VAL A  63 "
   model   vdw
   4.841 3.550
nonbonded pdb=" O   PRO A  42 "
          pdb=" CG2 VAL A  43 "
   model   vdw
   4.842 3.460
nonbonded pdb=" CG  LYS A   3 "
          pdb="O    HOH S   5 "
   model   vdw
   4.842 3.440
nonbonded pdb=" CA  MSE A  77 "
          pdb=" CB  ILE A  78 "
   model   vdw
   4.842 3.900
nonbonded pdb=" N   GLN A  72 "
          pdb=" CB  PHE A  73 "
   model   vdw
   4.842 3.520
nonbonded pdb=" OD2 ASP A  36 "
          pdb=" NE2 GLN A  72 "
   model   vdw sym.op.
   4.842 3.120 -x+1,y+1,-z+2
nonbonded pdb=" CD  GLU A   5 "
          pdb=" OH  TYR A  41 "
   model   vdw sym.op.
   4.842 3.270 -x+1,y,-z+1
nonbonded pdb=" OG1 THR A  15 "
          pdb=" OG  SER A  27 "
   model   vdw
   4.843 3.040
nonbonded pdb=" N   LEU A  37 "
          pdb="O    HOH S   5 "
   model   vdw
   4.843 3.120
nonbonded pdb=" C   GLN A  12 "
          pdb=" CD  GLN A  31 "
   model   vdw
   4.843 3.500
nonbonded pdb=" N   PHE A  73 "
          pdb=" C   GLY A  74 "
   model   vdw
   4.843 3.350
nonbonded pdb=" CE  LYS A   3 "
          pdb=" CG  GLN A  72 "
   model   vdw sym.op.
   4.844 3.840 -x+1,y+1,-z+2
nonbonded pdb=" CG  GLN A  72 "
          pdb=" CE  LYS A   3 "
   model   vdw sym.op.
   4.844 3.840 -x+1,y-1,-z+2
nonbonded pdb=" CE1 TYR A  56 "
          pdb=" CE2 TYR A  61 "
   model   vdw
   4.845 3.640
nonbonded pdb=" CB  TYR A  34 "
          pdb=" CZ  TYR A  41 "
   model   vdw sym.op.
   4.845 3.660 -x+1,y,-z+1
nonbonded pdb=" C   GLN A  10 "
          pdb=" O   LEU A  32 "
   model   vdw
   4.845 3.270
nonbonded pdb=" OE1 GLU A  40 "
          pdb=" OG  SER A   9 "
   model   vdw sym.op.
   4.845 3.040 -x+1,y,-z+1
nonbonded pdb=" OG  SER A   9 "
          pdb=" OE1 GLU A  40 "
   model   vdw sym.op.
   4.845 3.040 -x+1,y,-z+1
nonbonded pdb=" C   THR A  62 "
          pdb=" CG1 VAL A  63 "
   model   vdw
   4.846 3.690
nonbonded pdb=" O   PRO A   8 "
          pdb=" CA  GLN A  10 "
   model   vdw
   4.846 3.470
nonbonded pdb=" CA  VAL A  45 "
          pdb=" O   LYS A  46 "
   model   vdw
   4.846 3.470
nonbonded pdb=" N   PHE A  68 "
          pdb=" CZ  PHE A  68 "
   model   vdw
   4.847 3.420
nonbonded pdb=" O   LYS A  69 "
          pdb=" N   LEU A  76 "
   model   vdw
   4.847 3.120
nonbonded pdb=" CG2 THR A  15 "
          pdb=" CB  SER A  17 "
   model   vdw
   4.847 3.860
nonbonded pdb=" O   LYS A   3 "
          pdb=" O   VAL A  35 "
   model   vdw
   4.847 3.040
nonbonded pdb=" N   GLU A   5 "
          pdb=" N   TYR A  61 "
   model   vdw
   4.847 3.200
nonbonded pdb=" CG1 VAL A  35 "
          pdb=" N   LEU A  37 "
   model   vdw
   4.847 3.540
nonbonded pdb=" C   ASN A  29 "
          pdb=" C   THR A  48 "
   model   vdw
   4.848 3.500
nonbonded pdb=" O   MSE A  77 "
          pdb="O    HOH S  13 "
   model   vdw
   4.848 3.040
nonbonded pdb=" CA  LEU A  28 "
          pdb=" O   ASN A  29 "
   model   vdw
   4.848 3.470
nonbonded pdb=" NZ  LYS A   7 "
          pdb=" O   GLU A  40 "
   model   vdw sym.op.
   4.848 3.120 -x+1,y,-z+1
nonbonded pdb="O    HOH S  13 "
          pdb=" O   MSE A  77 "
   model   vdw sym.op.
   4.848 3.040 -x+1,y,-z+2
nonbonded pdb=" O   MSE A  77 "
          pdb="O    HOH S  13 "
   model   vdw sym.op.
   4.848 3.040 -x+1,y,-z+2
nonbonded pdb=" CD  LYS A   3 "
          pdb=" N   VAL A   4 "
   model   vdw
   4.848 3.520
nonbonded pdb=" C   THR A  62 "
          pdb=" O   ARG A  82 "
   model   vdw
   4.848 3.270
nonbonded pdb=" CG  ASP A  36 "
          pdb=" CA  LEU A  37 "
   model   vdw
   4.848 3.700
nonbonded pdb=" N   PRO A  54 "
          pdb=" CA  ALA A  55 "
   model   vdw
   4.848 3.550
nonbonded pdb=" O   LYS A  46 "
          pdb=" C   SER A  75 "
   model   vdw sym.op.
   4.849 3.270 -x+1,y,-z+2
nonbonded pdb=" C   ASP A  50 "
          pdb=" CA  GLN A  53 "
   model   vdw
   4.849 3.700
nonbonded pdb=" CG  LYS A  46 "
          pdb="O    HOH S  38 "
   model   vdw
   4.849 3.440
nonbonded pdb=" CA  LEU A  65 "
          pdb=" CB  SER A  66 "
   model   vdw
   4.850 3.870
nonbonded pdb=" C   VAL A   4 "
          pdb=" C   LEU A  60 "
   model   vdw
   4.850 3.500
nonbonded pdb=" C   LEU A  28 "
          pdb=" ND2 ASN A  29 "
   model   vdw
   4.850 3.350
nonbonded pdb=" N   ARG A  80 "
          pdb=" NH2 ARG A  82 "
   model   vdw
   4.851 3.200
nonbonded pdb=" CB  SER A  67 "
          pdb=" CE2 PHE A  68 "
   model   vdw
   4.851 3.740
nonbonded pdb=" CB  SER A  67 "
          pdb=" CG2 ILE A  78 "
   model   vdw
   4.851 3.860
nonbonded pdb=" O   LEU A  76 "
          pdb="O    HOH S  13 "
   model   vdw
   4.852 3.040
nonbonded pdb=" CA  VAL A   4 "
          pdb=" O   GLU A   5 "
   model   vdw
   4.852 3.470
nonbonded pdb="O    HOH S  13 "
          pdb=" O   LEU A  76 "
   model   vdw sym.op.
   4.852 3.040 -x+1,y,-z+2
nonbonded pdb=" O   LEU A  76 "
          pdb="O    HOH S  13 "
   model   vdw sym.op.
   4.852 3.040 -x+1,y,-z+2
nonbonded pdb=" NE2 HIS A  64 "
          pdb=" N   SER A  66 "
   model   vdw
   4.853 3.200
nonbonded pdb=" C   THR A  15 "
          pdb=" C   PRO A   8 "
   model   vdw sym.op.
   4.853 3.500 -x+1/2,y-1/2,-z+1
nonbonded pdb=" C   PRO A   8 "
          pdb=" C   THR A  15 "
   model   vdw sym.op.
   4.853 3.500 -x+1/2,y+1/2,-z+1
nonbonded pdb=" N   ILE A   6 "
          pdb="O    HOH S  12 "
   model   vdw
   4.853 3.120
nonbonded pdb=" CD2 LEU A  37 "
          pdb=" CD1 PHE A  68 "
   model   vdw sym.op.
   4.853 3.760 -x+1,y,-z+2
nonbonded pdb=" CG1 VAL A  45 "
          pdb=" N   ILE A  47 "
   model   vdw
   4.853 3.540
nonbonded pdb=" CD2 LEU A  49 "
          pdb=" CG  TYR A  56 "
   model   vdw
   4.853 3.680
nonbonded pdb=" CG2 ILE A  47 "
          pdb=" CD2 TYR A  56 "
   model   vdw
   4.853 3.760
nonbonded pdb=" CB  ASN A  39 "
          pdb=" CB  GLU A  40 "
   model   vdw
   4.854 3.840
nonbonded pdb=" CB  THR A  15 "
          pdb=" C   LEU A  28 "
   model   vdw
   4.854 3.700
nonbonded pdb=" C   GLN A  31 "
          pdb=" C   LYS A  46 "
   model   vdw
   4.854 3.500
nonbonded pdb=" O   ILE A   2 "
          pdb=" CD1 ILE A   2 "
   model   vdw
   4.854 3.460
nonbonded pdb=" CB  LYS A  46 "
          pdb=" CA  SER A  75 "
   model   vdw sym.op.
   4.854 3.870 -x+1,y,-z+2
nonbonded pdb=" C   SER A  66 "
          pdb=" O   ARG A  80 "
   model   vdw
   4.855 3.270
nonbonded pdb=" C   LYS A  69 "
          pdb=" CA  LEU A  76 "
   model   vdw
   4.855 3.700
nonbonded pdb=" C   LYS A  46 "
          pdb=" CG2 ILE A  47 "
   model   vdw
   4.855 3.690
nonbonded pdb=" CA  LEU A  44 "
          pdb=" CG2 VAL A  45 "
   model   vdw
   4.856 3.890
nonbonded pdb=" CD2 TYR A  34 "
          pdb=" CB  LEU A  44 "
   model   vdw
   4.856 3.740
nonbonded pdb=" CG  GLN A  72 "
          pdb=" CA  PHE A  73 "
   model   vdw
   4.856 3.870
nonbonded pdb=" CB  PHE A  13 "
          pdb=" CA  ASN A  29 "
   model   vdw
   4.857 3.870
nonbonded pdb=" CD1 ILE A   6 "
          pdb=" O   GLN A  10 "
   model   vdw
   4.857 3.460
nonbonded pdb=" C   ARG A  16 "
          pdb=" NE  ARG A  16 "
   model   vdw
   4.857 3.350
nonbonded pdb=" CG  GLN A  10 "
          pdb=" CA  CYS A  33 "
   model   vdw
   4.857 3.870
nonbonded pdb=" N   GLN A  72 "
          pdb=" C   PHE A  73 "
   model   vdw
   4.858 3.350
nonbonded pdb=" N   SER A  67 "
          pdb=" O   PHE A  68 "
   model   vdw
   4.858 3.120
nonbonded pdb=" CB  HIS A  64 "
          pdb=" N   LEU A  83 "
   model   vdw
   4.858 3.520
nonbonded pdb=" O   GLU A   5 "
          pdb=" SG  CYS A  33 "
   model   vdw
   4.859 3.400
nonbonded pdb=" CB  SER A  67 "
          pdb=" CD  ARG A  82 "
   model   vdw
   4.859 3.840
nonbonded pdb=" C   LEU A  28 "
          pdb=" CD2 LEU A  28 "
   model   vdw
   4.859 3.690
nonbonded pdb=" CB  ARG A  80 "
          pdb=" CG  ARG A  82 "
   model   vdw
   4.859 3.840
nonbonded pdb=" CB  GLU A  30 "
          pdb=" C   ILE A  47 "
   model   vdw
   4.860 3.670
nonbonded pdb=" CG  TYR A  34 "
          pdb=" CA  LEU A  44 "
   model   vdw
   4.860 3.690
nonbonded pdb=" CA  TYR A  34 "
          pdb=" N   VAL A  45 "
   model   vdw
   4.860 3.550
nonbonded pdb=" CB  SER A  67 "
          pdb=" CD2 PHE A  68 "
   model   vdw
   4.860 3.740
nonbonded pdb=" N   GLN A  31 "
          pdb=" CG  LYS A  46 "
   model   vdw
   4.860 3.520
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" CG  PRO A  58 "
   model   vdw
   4.861 3.860
nonbonded pdb=" C   MSE A  77 "
          pdb="SE   MSE A  77 "
   model   vdw
   4.861 3.650
nonbonded pdb=" CB  SER A  66 "
          pdb=" CB  ARG A  82 "
   model   vdw
   4.861 3.840
nonbonded pdb=" ND1 HIS A  64 "
          pdb=" C   SER A  66 "
   model   vdw
   4.861 3.350
nonbonded pdb=" O   THR A  48 "
          pdb=" CG  ASP A  50 "
   model   vdw
   4.862 3.270
nonbonded pdb=" C   ILE A   2 "
          pdb=" CG  LYS A   3 "
   model   vdw
   4.862 3.670
nonbonded pdb=" N   LEU A  32 "
          pdb=" CA  CYS A  33 "
   model   vdw
   4.862 3.550
nonbonded pdb=" CB  GLN A  31 "
          pdb=" CD1 LEU A  49 "
   model   vdw
   4.863 3.860
nonbonded pdb=" CE  LYS A   7 "
          pdb=" CA  GLU A  40 "
   model   vdw sym.op.
   4.863 3.870 -x+1,y,-z+1
nonbonded pdb=" CB  LYS A   7 "
          pdb=" CG  PRO A   8 "
   model   vdw
   4.863 3.840
nonbonded pdb=" C   GLN A  12 "
          pdb=" CB  GLN A  31 "
   model   vdw
   4.863 3.670
nonbonded pdb=" CB  ASP A  50 "
          pdb=" CB  GLN A  53 "
   model   vdw
   4.864 3.840
nonbonded pdb=" N   ASP A  79 "
          pdb=" O   ARG A  80 "
   model   vdw
   4.864 3.120
nonbonded pdb=" CD2 LEU A  83 "
          pdb=" N   VAL A  84 "
   model   vdw
   4.864 3.540
nonbonded pdb=" O   LEU A  65 "
          pdb=" OG  SER A  66 "
   model   vdw
   4.864 3.040
nonbonded pdb=" CA  LEU A  49 "
          pdb=" NH1 ARG A  80 "
   model   vdw
   4.865 3.550
nonbonded pdb=" N   HIS A  64 "
          pdb=" N   VAL A  84 "
   model   vdw
   4.865 3.200
nonbonded pdb=" C   ILE A   6 "
          pdb=" CD  GLN A  10 "
   model   vdw
   4.865 3.500
nonbonded pdb=" C   SER A  17 "
          pdb=" C   TYR A  26 "
   model   vdw
   4.865 3.500
nonbonded pdb=" CD  GLN A  10 "
          pdb=" CZ  TYR A  34 "
   model   vdw
   4.866 3.490
nonbonded pdb=" O   PRO A   8 "
          pdb=" C   GLN A  10 "
   model   vdw
   4.866 3.270
nonbonded pdb=" N   GLN A  31 "
          pdb=" CA  LEU A  32 "
   model   vdw
   4.866 3.550
nonbonded pdb=" CG1 ILE A   2 "
          pdb=" CG2 VAL A  63 "
   model   vdw
   4.866 3.860
nonbonded pdb=" C   LEU A  49 "
          pdb=" CD  ARG A  80 "
   model   vdw
   4.866 3.670
nonbonded pdb=" C   ARG A  16 "
          pdb=" C   SER A  27 "
   model   vdw
   4.867 3.500
nonbonded pdb=" CA  VAL A  43 "
          pdb="O    HOH S  25 "
   model   vdw
   4.867 3.470
nonbonded pdb=" O   LYS A  69 "
          pdb=" CG  MSE A  77 "
   model   vdw
   4.867 3.440
nonbonded pdb=" CB  ALA A  11 "
          pdb=" O   TYR A  56 "
   model   vdw
   4.867 3.460
nonbonded pdb=" CD1 LEU A  81 "
          pdb="O    HOH S   6 "
   model   vdw sym.op.
   4.867 3.460 -x+1,y,-z+2
nonbonded pdb=" O   SER A  17 "
          pdb=" O   TYR A  26 "
   model   vdw
   4.867 3.040
nonbonded pdb=" N   ARG A  16 "
          pdb=" CA  LEU A  28 "
   model   vdw
   4.867 3.550
nonbonded pdb=" CB  THR A  14 "
          pdb=" C   THR A  15 "
   model   vdw
   4.867 3.700
nonbonded pdb=" O   ARG A  16 "
          pdb=" C   TYR A  26 "
   model   vdw
   4.868 3.270
nonbonded pdb=" CA  ALA A  55 "
          pdb="O    HOH S  39 "
   model   vdw
   4.868 3.470
nonbonded pdb=" CA  GLU A   5 "
          pdb=" OE2 GLU A   5 "
   model   vdw
   4.868 3.470
nonbonded pdb=" CG1 ILE A   2 "
          pdb="O    HOH S   5 "
   model   vdw
   4.868 3.440
nonbonded pdb=" NE  ARG A  16 "
          pdb=" CA  PRO A  85 "
   model   vdw sym.op.
   4.868 3.550 x,y-1,z
nonbonded pdb=" CB  LEU A  83 "
          pdb=" C   VAL A  84 "
   model   vdw
   4.868 3.670
nonbonded pdb=" CG  LYS A  69 "
          pdb=" C   MSE A  77 "
   model   vdw
   4.869 3.670
nonbonded pdb=" CA  GLN A  72 "
          pdb=" CG  PHE A  73 "
   model   vdw
   4.869 3.690
nonbonded pdb=" CA  PRO A   8 "
          pdb=" CB  THR A  15 "
   model   vdw sym.op.
   4.869 3.900 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CE1 TYR A  41 "
          pdb=" CB  PRO A  42 "
   model   vdw sym.op.
   4.869 3.740 -x+1,y,-z+1
nonbonded pdb=" NH2 ARG A  16 "
          pdb=" CA  TYR A  61 "
   model   vdw sym.op.
   4.869 3.550 x,y-1,z
nonbonded pdb=" O   GLU A   5 "
          pdb=" CD  GLN A  10 "
   model   vdw
   4.869 3.270
nonbonded pdb=" CB  GLN A  72 "
          pdb=" CD2 PHE A  73 "
   model   vdw
   4.869 3.740
nonbonded pdb=" N   LYS A   7 "
          pdb=" CA  GLN A  10 "
   model   vdw
   4.870 3.550
nonbonded pdb=" CB  ARG A  82 "
          pdb=" CZ  ARG A  82 "
   model   vdw
   4.870 3.670
nonbonded pdb=" CG  GLN A  31 "
          pdb=" CB  ALA A  55 "
   model   vdw
   4.870 3.860
nonbonded pdb=" CA  THR A  15 "
          pdb="O    HOH S  14 "
   model   vdw
   4.870 3.470
nonbonded pdb=" CA  ARG A  82 "
          pdb=" NE  ARG A  82 "
   model   vdw
   4.870 3.550
nonbonded pdb=" OD1 ASP A  50 "
          pdb=" OE2 GLU A  51 "
   model   vdw
   4.871 3.040
nonbonded pdb=" OD2 ASP A  36 "
          pdb=" N   LEU A  37 "
   model   vdw
   4.871 3.120
nonbonded pdb=" O   LEU A  37 "
          pdb=" CB  ASN A  39 "
   model   vdw
   4.871 3.440
nonbonded pdb=" CA  ASP A  50 "
          pdb=" CZ  ARG A  80 "
   model   vdw
   4.871 3.700
nonbonded pdb=" N   LYS A  46 "
          pdb=" CA  GLY A  74 "
   model   vdw sym.op.
   4.872 3.520 -x+1,y,-z+2
nonbonded pdb=" CD1 TYR A  26 "
          pdb=" CB  LEU A  28 "
   model   vdw
   4.872 3.740
nonbonded pdb=" OH  TYR A  56 "
          pdb=" CG  ARG A  82 "
   model   vdw
   4.872 3.440
nonbonded pdb=" CD2 LEU A  49 "
          pdb=" N   TYR A  56 "
   model   vdw
   4.872 3.540
nonbonded pdb=" N   SER A   9 "
          pdb=" C   GLN A  10 "
   model   vdw
   4.872 3.350
nonbonded pdb=" CD  LYS A  46 "
          pdb=" OG1 THR A  48 "
   model   vdw
   4.872 3.440
nonbonded pdb=" N   LYS A   7 "
          pdb=" CA  PRO A   8 "
   model   vdw
   4.872 3.550
nonbonded pdb=" CB  ALA A  57 "
          pdb=" CG  PRO A  58 "
   model   vdw
   4.872 3.860
nonbonded pdb=" CA  TYR A  34 "
          pdb=" N   LEU A  44 "
   model   vdw
   4.872 3.550
nonbonded pdb=" NE  ARG A  80 "
          pdb=" NH2 ARG A  82 "
   model   vdw
   4.873 3.200
nonbonded pdb=" O   PHE A  68 "
          pdb=" N   VAL A  70 "
   model   vdw
   4.873 3.120
nonbonded pdb=" OD2 ASP A  36 "
          pdb=" N   GLY A  38 "
   model   vdw
   4.873 3.120
nonbonded pdb=" OG  SER A  27 "
          pdb=" CG  ASN A  29 "
   model   vdw
   4.873 3.270
nonbonded pdb=" O   GLN A  12 "
          pdb=" CG  PHE A  13 "
   model   vdw
   4.874 3.260
nonbonded pdb=" CG  ASP A  50 "
          pdb=" CD  ARG A  82 "
   model   vdw
   4.874 3.670
nonbonded pdb=" CA  VAL A  35 "
          pdb=" CB  PRO A  42 "
   model   vdw
   4.874 3.870
nonbonded pdb=" CA  SER A  75 "
          pdb=" CB  LEU A  76 "
   model   vdw
   4.874 3.870
nonbonded pdb=" CG1 VAL A   4 "
          pdb=" CB  TYR A  61 "
   model   vdw
   4.874 3.860
nonbonded pdb=" CB  GLN A  10 "
          pdb=" N   LEU A  32 "
   model   vdw
   4.875 3.520
nonbonded pdb=" N   ALA A  55 "
          pdb="O    HOH S  39 "
   model   vdw
   4.875 3.120
nonbonded pdb=" CB  VAL A  63 "
          pdb=" CG  LEU A  81 "
   model   vdw
   4.876 3.900
nonbonded pdb=" CB  LEU A  37 "
          pdb=" CA  GLY A  38 "
   model   vdw
   4.876 3.840
nonbonded pdb=" N   HIS A  64 "
          pdb=" N   LEU A  83 "
   model   vdw
   4.876 3.200
nonbonded pdb=" C   GLN A  12 "
          pdb=" NE2 GLN A  31 "
   model   vdw
   4.876 3.350
nonbonded pdb=" CA  VAL A  63 "
          pdb=" C   ARG A  82 "
   model   vdw
   4.876 3.700
nonbonded pdb=" CA  ILE A  78 "
          pdb=" N   ARG A  80 "
   model   vdw
   4.877 3.550
nonbonded pdb=" N   HIS A  64 "
          pdb=" CA  LEU A  65 "
   model   vdw
   4.877 3.550
nonbonded pdb=" CD2 HIS A  64 "
          pdb=" CB  VAL A  84 "
   model   vdw
   4.877 3.690
nonbonded pdb=" CB  HIS A  64 "
          pdb=" C   LEU A  83 "
   model   vdw
   4.877 3.670
nonbonded pdb=" C   ARG A  80 "
          pdb=" CD  ARG A  80 "
   model   vdw
   4.877 3.670
nonbonded pdb=" C   LYS A   3 "
          pdb=" C   VAL A  35 "
   model   vdw
   4.877 3.500
nonbonded pdb=" N   PRO A  42 "
          pdb=" CA  VAL A  43 "
   model   vdw
   4.878 3.550
nonbonded pdb=" NH1 ARG A  16 "
          pdb=" C   GLY A  59 "
   model   vdw sym.op.
   4.878 3.350 x,y-1,z
nonbonded pdb=" C   CYS A  33 "
          pdb=" C   VAL A  45 "
   model   vdw
   4.878 3.500
nonbonded pdb=" OH  TYR A  26 "
          pdb=" CA  PRO A  85 "
   model   vdw sym.op.
   4.879 3.470 x,y-1,z
nonbonded pdb=" CB  HIS A  64 "
          pdb=" CA  ARG A  82 "
   model   vdw
   4.879 3.870
nonbonded pdb=" CA  ASP A  79 "
          pdb=" O   ARG A  80 "
   model   vdw
   4.879 3.470
nonbonded pdb=" CG2 THR A  62 "
          pdb=" CB  VAL A  84 "
   model   vdw
   4.879 3.890
nonbonded pdb=" NE2 GLN A  31 "
          pdb="O    HOH S   8 "
   model   vdw
   4.880 3.120
nonbonded pdb=" CA  PRO A  58 "
          pdb=" C   GLY A  59 "
   model   vdw
   4.880 3.700
nonbonded pdb=" CB  ASN A  39 "
          pdb=" C   TYR A  41 "
   model   vdw
   4.880 3.670
nonbonded pdb=" N   GLY A  71 "
          pdb=" CA  GLN A  72 "
   model   vdw
   4.880 3.550
nonbonded pdb=" N   LEU A  65 "
          pdb=" C   SER A  66 "
   model   vdw
   4.880 3.350
nonbonded pdb=" CD2 TYR A  61 "
          pdb=" N   THR A  62 "
   model   vdw
   4.880 3.420
nonbonded pdb=" CA  LYS A   3 "
          pdb=" CB  ASP A  36 "
   model   vdw
   4.881 3.870
nonbonded pdb=" N   LEU A  81 "
          pdb=" CD2 LEU A  81 "
   model   vdw
   4.881 3.540
nonbonded pdb=" CD1 LEU A  37 "
          pdb=" O   LYS A  69 "
   model   vdw sym.op.
   4.881 3.460 -x+1,y,-z+2
nonbonded pdb=" OE1 GLU A  51 "
          pdb=" CZ  ARG A  80 "
   model   vdw
   4.881 3.270
nonbonded pdb=" N   LYS A   3 "
          pdb=" O   ASP A  36 "
   model   vdw
   4.881 3.120
nonbonded pdb=" CD2 TYR A  61 "
          pdb=" CG  LEU A  83 "
   model   vdw
   4.882 3.770
nonbonded pdb=" CG  ASN A  39 "
          pdb=" O   TYR A  41 "
   model   vdw
   4.882 3.270
nonbonded pdb=" CA  GLN A  10 "
          pdb=" NE2 GLN A  10 "
   model   vdw
   4.882 3.550
nonbonded pdb=" CA  CYS A  33 "
          pdb=" N   VAL A  45 "
   model   vdw
   4.882 3.550
nonbonded pdb=" O   VAL A   4 "
          pdb=" N   THR A  62 "
   model   vdw
   4.882 3.120
nonbonded pdb=" CG  LEU A  37 "
          pdb="O    HOH S   9 "
   model   vdw
   4.882 3.470
nonbonded pdb=" CG  ASP A  79 "
          pdb=" CG  ARG A  80 "
   model   vdw
   4.882 3.670
nonbonded pdb=" CZ  TYR A  26 "
          pdb="O    HOH S   7 "
   model   vdw sym.op.
   4.883 3.260 x,y-1,z
nonbonded pdb=" C   LEU A  83 "
          pdb=" CD  PRO A  85 "
   model   vdw
   4.883 3.670
nonbonded pdb=" O   ALA A  55 "
          pdb=" CB  ALA A  57 "
   model   vdw
   4.883 3.460
nonbonded pdb=" CB  ASN A  39 "
          pdb=" CG  GLU A  40 "
   model   vdw
   4.883 3.840
nonbonded pdb=" OG1 THR A  15 "
          pdb=" C   LEU A  28 "
   model   vdw
   4.884 3.270
nonbonded pdb=" CA  GLU A  30 "
          pdb=" N   LEU A  49 "
   model   vdw
   4.884 3.550
nonbonded pdb=" C   GLN A  72 "
          pdb=" CE2 PHE A  73 "
   model   vdw
   4.885 3.570
nonbonded pdb=" CA  SER A  27 "
          pdb=" O   LEU A  28 "
   model   vdw
   4.885 3.470
nonbonded pdb=" O   LEU A  44 "
          pdb=" CD1 LEU A  44 "
   model   vdw
   4.886 3.460
nonbonded pdb=" CD  GLU A  51 "
          pdb=" CZ  ARG A  80 "
   model   vdw
   4.886 3.500
nonbonded pdb=" N   TYR A  41 "
          pdb=" CA  PRO A  42 "
   model   vdw
   4.887 3.550
nonbonded pdb=" NE2 GLN A  10 "
          pdb=" CE2 TYR A  34 "
   model   vdw
   4.887 3.420
nonbonded pdb=" CB  PRO A   8 "
          pdb=" CB  PRO A  58 "
   model   vdw
   4.887 3.840
nonbonded pdb=" CB  LEU A  60 "
          pdb=" CE1 PHE A  73 "
   model   vdw sym.op.
   4.887 3.740 -x+1,y+1,-z+2
nonbonded pdb=" N   PHE A  68 "
          pdb=" CA  LYS A  69 "
   model   vdw
   4.887 3.550
nonbonded pdb=" O   GLN A  12 "
          pdb=" OE1 GLN A  12 "
   model   vdw
   4.888 3.040
nonbonded pdb=" C   GLN A  53 "
          pdb=" NE2 GLN A  53 "
   model   vdw
   4.888 3.350
nonbonded pdb=" N   VAL A  35 "
          pdb=" CA  PRO A  42 "
   model   vdw
   4.888 3.550
nonbonded pdb=" O   TYR A  56 "
          pdb=" CA  PRO A  58 "
   model   vdw
   4.888 3.470
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" CB  PRO A  58 "
   model   vdw
   4.888 3.860
nonbonded pdb=" N   GLY A  71 "
          pdb=" N   LEU A  76 "
   model   vdw
   4.889 3.200
nonbonded pdb=" C   VAL A  45 "
          pdb=" C   GLY A  74 "
   model   vdw sym.op.
   4.889 3.500 -x+1,y,-z+2
nonbonded pdb=" N   ASN A  39 "
          pdb=" CA  GLU A  40 "
   model   vdw
   4.889 3.550
nonbonded pdb=" C   GLY A  59 "
          pdb=" CG  TYR A  61 "
   model   vdw
   4.889 3.490
nonbonded pdb=" N   ASN A  29 "
          pdb=" CG  GLU A  30 "
   model   vdw
   4.889 3.520
nonbonded pdb=" N   LYS A   3 "
          pdb=" O   TYR A  61 "
   model   vdw
   4.889 3.120
nonbonded pdb=" C   TYR A  26 "
          pdb=" CE2 TYR A  26 "
   model   vdw
   4.890 3.570
nonbonded pdb=" CB  PHE A  68 "
          pdb=" CA  ILE A  78 "
   model   vdw
   4.890 3.870
nonbonded pdb=" CA  PRO A  54 "
          pdb=" CB  ALA A  55 "
   model   vdw
   4.890 3.890
nonbonded pdb="O    HOH S   8 "
          pdb="O    HOH S  23 "
   model   vdw
   4.890 3.040
nonbonded pdb=" N   VAL A  35 "
          pdb=" CB  VAL A  45 "
   model   vdw
   4.890 3.550
nonbonded pdb=" CA  LYS A  46 "
          pdb="O    HOH S  38 "
   model   vdw
   4.891 3.470
nonbonded pdb=" N   GLY A  38 "
          pdb=" CB  ASN A  39 "
   model   vdw
   4.892 3.520
nonbonded pdb=" CA  THR A  48 "
          pdb=" CD  ARG A  80 "
   model   vdw
   4.892 3.870
nonbonded pdb=" CD  GLU A  51 "
          pdb=" NH2 ARG A  80 "
   model   vdw
   4.892 3.350
nonbonded pdb=" OD1 ASP A  36 "
          pdb=" CA  PRO A  42 "
   model   vdw
   4.892 3.470
nonbonded pdb=" C   ARG A  80 "
          pdb=" CG  LEU A  81 "
   model   vdw
   4.892 3.700
nonbonded pdb=" OH  TYR A  56 "
          pdb="O    HOH S  39 "
   model   vdw
   4.892 3.040
nonbonded pdb=" CG1 VAL A  70 "
          pdb=" N   GLY A  74 "
   model   vdw
   4.893 3.540
nonbonded pdb=" CZ  TYR A  41 "
          pdb=" CE2 TYR A  34 "
   model   vdw sym.op.
   4.893 3.560 -x+1,y,-z+1
nonbonded pdb=" CE2 TYR A  34 "
          pdb=" CZ  TYR A  41 "
   model   vdw sym.op.
   4.893 3.560 -x+1,y,-z+1
nonbonded pdb=" CG  ASP A  50 "
          pdb=" CZ  ARG A  80 "
   model   vdw
   4.893 3.500
nonbonded pdb=" CA  SER A  17 "
          pdb=" CB  SER A  27 "
   model   vdw
   4.893 3.870
nonbonded pdb=" CG  LEU A  60 "
          pdb=" CD1 PHE A  73 "
   model   vdw sym.op.
   4.893 3.770 -x+1,y+1,-z+2
nonbonded pdb=" C   LEU A  32 "
          pdb=" C   VAL A  45 "
   model   vdw
   4.893 3.500
nonbonded pdb=" CA  ARG A  80 "
          pdb=" NH2 ARG A  82 "
   model   vdw
   4.894 3.550
nonbonded pdb=" C   LEU A  76 "
          pdb=" CB  ILE A  78 "
   model   vdw sym.op.
   4.894 3.700 -x+1,y,-z+2
nonbonded pdb=" CB  ASP A  36 "
          pdb=" N   GLY A  38 "
   model   vdw
   4.894 3.520
nonbonded pdb=" CA  LYS A  46 "
          pdb=" CG1 ILE A  47 "
   model   vdw
   4.894 3.870
nonbonded pdb=" C   LYS A   7 "
          pdb=" C   GLN A  10 "
   model   vdw
   4.895 3.500
nonbonded pdb=" CA  ASP A  36 "
          pdb=" CG  LEU A  37 "
   model   vdw
   4.895 3.900
nonbonded pdb=" CG  LYS A   3 "
          pdb=" O   TYR A  61 "
   model   vdw
   4.895 3.440
nonbonded pdb=" C   TYR A  61 "
          pdb=" C   PRO A  85 "
   model   vdw
   4.895 3.500
nonbonded pdb=" CA  ILE A   6 "
          pdb=" CA  CYS A  33 "
   model   vdw
   4.895 3.900
nonbonded pdb=" CA  ILE A   6 "
          pdb=" CB  CYS A  33 "
   model   vdw
   4.896 3.870
nonbonded pdb=" CA  THR A  62 "
          pdb=" CG2 VAL A  84 "
   model   vdw
   4.896 3.890
nonbonded pdb=" CB  HIS A  64 "
          pdb=" C   LEU A  65 "
   model   vdw
   4.896 3.670
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" CD  PRO A  58 "
   model   vdw
   4.896 3.860
nonbonded pdb=" CG  GLN A  10 "
          pdb=" N   ALA A  11 "
   model   vdw
   4.896 3.520
nonbonded pdb=" N   GLN A  10 "
          pdb=" OE1 GLN A  12 "
   model   vdw
   4.897 3.120
nonbonded pdb=" CA  GLU A  30 "
          pdb=" OE2 GLU A  30 "
   model   vdw
   4.897 3.470
nonbonded pdb=" CD  GLU A   5 "
          pdb=" O   ILE A   6 "
   model   vdw
   4.897 3.270
nonbonded pdb=" C   ALA A  55 "
          pdb="O    HOH S   7 "
   model   vdw
   4.897 3.270
nonbonded pdb=" CB  PHE A  13 "
          pdb=" CA  GLN A  31 "
   model   vdw
   4.897 3.870
nonbonded pdb=" CB  TYR A  41 "
          pdb=" CG  PRO A  42 "
   model   vdw
   4.897 3.840
nonbonded pdb=" C   LEU A  60 "
          pdb=" C   PRO A  85 "
   model   vdw
   4.897 3.500
nonbonded pdb=" N   GLY A  59 "
          pdb=" OH  TYR A  61 "
   model   vdw
   4.897 3.120
nonbonded pdb=" C   GLN A  10 "
          pdb=" C   GLN A  12 "
   model   vdw
   4.898 3.500
nonbonded pdb=" CB  LYS A   3 "
          pdb=" N   ASP A  36 "
   model   vdw
   4.898 3.520
nonbonded pdb=" O   LEU A  37 "
          pdb=" CD1 LEU A  37 "
   model   vdw
   4.898 3.460
nonbonded pdb=" CB  ARG A  80 "
          pdb=" CZ  ARG A  80 "
   model   vdw
   4.898 3.670
nonbonded pdb=" C   LEU A  60 "
          pdb=" CA  PRO A  85 "
   model   vdw
   4.898 3.700
nonbonded pdb=" OE1 GLN A  10 "
          pdb=" CG  TYR A  34 "
   model   vdw
   4.898 3.260
nonbonded pdb=" OD2 ASP A  79 "
          pdb=" CG  ARG A  80 "
   model   vdw
   4.898 3.440
nonbonded pdb=" CB  PRO A  42 "
          pdb=" C   VAL A  43 "
   model   vdw
   4.899 3.670
nonbonded pdb=" C   LYS A  69 "
          pdb=" CG  LEU A  76 "
   model   vdw
   4.899 3.700
nonbonded pdb=" O   PHE A  68 "
          pdb="O    HOH S  10 "
   model   vdw
   4.899 3.040
nonbonded pdb=" OD1 ASN A  29 "
          pdb=" N   GLU A  30 "
   model   vdw
   4.899 3.120
nonbonded pdb=" C   GLN A  72 "
          pdb=" CA  GLY A  74 "
   model   vdw
   4.899 3.670
nonbonded pdb=" C   ILE A  78 "
          pdb=" CG  ASP A  79 "
   model   vdw
   4.900 3.500
nonbonded pdb=" N   LYS A   3 "
          pdb=" CG2 VAL A   4 "
   model   vdw
   4.900 3.540
nonbonded pdb=" O   GLY A  74 "
          pdb="O    HOH S   6 "
   model   vdw
   4.900 3.040
nonbonded pdb=" CB  VAL A   4 "
          pdb=" CD1 LEU A  83 "
   model   vdw
   4.900 3.890

