Bacteriophage f1 Gene V protein — Se-SAD structure determination
================================================================
Date: 2026-07-23
Pipeline: Phenix (xtriage -> AutoSol -> AutoBuild -> Coot -> phenix.refine -> MolProbity)

INPUT DATA (not copied here; original location):
  peak.sca      : Scalepack anomalous intensities, Se peak wavelength
  sequence.dat  : 87-residue Gene V protein sequence
  Space group C2 (C 1 2 1); cell 76.08 27.97 42.36 A, beta 103.2 deg
  Resolution 21.3–2.59 A; non-anomalous completeness 93.7%, anomalous 95.1%

METHOD SUMMARY
  Phasing:   Se-SAD (single wavelength, peak). Anomalous signal measurable to ~3.1 A.
             HySS substructure -> Phaser SAD phasing -> RESOLVE density modification.
             2 principal Se sites (occ ~0.6) + 2 minor sites.
             Hand: chosen by map quality (Bayes-CC 44 for chosen hand vs 14.5 for inverse).
             Experimental phasing FOM 0.43; density-modified map R = 0.30.
  Building:  AutoSol initial build (62 res) -> AutoBuild full rebuild (76 res, CC 0.81).
  Finishing: Coot (completed SeMet77 side chain; fitted poorly-ordered side chains;
             removed standalone Se substructure atoms from the protein model) ->
             phenix.refine (5 macrocycles, individual ADP, ordered solvent).

FINAL MODEL (final_model.pdb / .cif)
  Chain A, residues 2–85 (76 residues modeled; N-terminal Met1 disordered/not modeled)
  1 selenomethionine (MSE 77, complete incl. Se); 25 ordered waters
  R-work / R-free      = 0.175 / 0.272   (2.59 A, 2633 reflections)
  MolProbity score     = 1.70
  Clashscore           = 4.13
  Ramachandran         = 97.2% favored, 0 outliers
  Rotamer outliers     = 2.94% (2 weak-density surface side chains: Glu40, Gln12)
  C-beta deviations    = 0
  RMS(bonds)/RMS(angles) = 0.009 A / 1.04 deg
  Mean map-model CC (all-atom / side-chain) = 0.81 / 0.82

FILES
  final_model.pdb / final_model.cif   Final refined coordinates
  final_model_maps.mtz                2mFo-DFc and mFo-DFc map coefficients (final)
  final_model_geometry.geo            Refinement geometry restraints/deviations
  final_refine.log                    phenix.refine log
  experimental_phases.mtz             SAD experimental phases (FP SIGFP PHIB FOM HL)
  experimental_denmod_map.mtz         Density-modified experimental map coefficients
  se_substructure.pdb                 Se anomalous substructure (phasing sites)
  data_Fobs_freeR_anom.mtz            Fobs + FreeR_flag + anomalous I(+)/I(-)
  autobuild_model.pdb                 AutoBuild model (pre-Coot/pre-final-refine)
  molprobity.out                      Full validation report
  xtriage.log                         Data-quality analysis

NOTES / PROVENANCE
  - The FreeR set generated during AutoSol was carried through all steps; it was
    never regenerated or extended.
  - Experimental (HL) phases were NOT used as restraints in the final refinement.
  - The 2 remaining rotamer outliers are mobile surface Glu/Gln with weak side-chain
    density at 2.6 A; auto-fitting did not improve them (not misbuilt).
  - Reference structure for this example: PDB 1VQB (Gene V protein).
