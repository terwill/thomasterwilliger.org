================================================================================
 Bacteriophage f1 Gene V protein  —  Se-SAD structure determination
 Prepared: 2026-07-23
================================================================================

INPUTS (as provided; README of the example was intentionally not used)
  - peak.sca      : Scalepack anomalous data, Se peak wavelength (single dataset)
  - sequence.dat  : 87-residue protein sequence

METHOD (Phenix)
  1. Data assessment      : phenix.xtriage
  2. Substructure + phasing + density mod + initial build : phenix.autosol
                            (HySS -> Phaser SAD -> RESOLVE -> build), atom_type=Se, sites=2
  3. Iterative build/refine from experimental phases       : phenix.autobuild
  4. Manual cleanup / rotamer + side-chain fitting         : Coot
                            (removed 4 spurious substructure Se; completed MSE 77
                             side chain; corrected rotamers A40 GLU, A47 ILE, A84 VAL)
  5. Final refinement     : phenix.refine (ordered_solvent, weight optimisation;
                            existing R-free set preserved, never regenerated)
  6. Validation           : phenix.molprobity / phenix.rotalyze

CRYSTAL / DATA
  Space group   : C 1 2 1  (No. 5)
  Unit cell     : 76.08 27.97 42.36  90 103.2 90
  Resolution    : 21.33 - 2.59 A
  Completeness  : 93.7% (non-anom), 95.1% (anomalous)
  Anomalous signal measurable to ~3.1 A  (xtriage)
  Content       : 1 protein copy / ASU (Matthews ~2.3, solvent ~46%)

EXPERIMENTAL PHASING (phenix.autosol)  -- see gene5_autosol_summary.dat
  Selenium substructure : 2 Se sought; hand resolved unambiguously.
     Correct hand = AutoSol Solution 2 (inverse):  BAYES-CC = 44.0   (vs 14.5 wrong hand)
     Overall figure of merit (experimental, after density mod) = 0.43
     Refined sites: 2 strong Se (occ 0.64, 0.58) + 2 minor (occ 0.28, 0.20)
     -> the 2 strong sites correspond to the 2 Met (MSE) of the monomer.
  EXPERIMENTAL MAP QUALITY (evidence it is interpretable):
     - BAYES-CC (estimated map CC to a perfect map) = 0.44
     - RESOLVE built 62/87 residues WITH correct sequence directly into the
       density-modified experimental map (AutoSol initial model, map-model CC 0.64).
     - AutoBuild then completed the chain to 84/84 residues sequenced with
       final map-model CC = 0.82.
     Density-modified experimental map coefficients:
       gene5_experimental_denmod_map_coeffs.mtz   (FWT,PHWT)

FINAL MODEL (gene5_final_model.pdb / .cif)
  Chain A, residues 2-85 (84 modelled; N-term Met1 and C-term 86-87 disordered)
  Selenomethionine : MSE 77 (full side chain, incl. Se)
  Waters           : 37
  R-work / R-free  : 0.177 / 0.226     (2.59 A)
  MolProbity score : 1.10
  Clashscore       : 2.25
  Ramachandran     : 98.78% favored, 0.00% outliers
  Rotamer outliers : 1.35%  (1 residue: A24 LYS)
  C-beta deviations: 0
  RMS bonds/angles : 0.005 A / 0.73 deg

  Note on A24 LYS: solvent-exposed lysine whose distal side-chain density is
  weak (side-chain real-space CC ~0.38). The flagged rotamer is not a build
  error; forcing a "favored" rotamer lowered density agreement and raised
  R-free, so the density-consistent conformation was retained. Genuinely
  disordered surface side chain.

WHERE IT STANDS
  Structure SOLVED and essentially complete. Experimental Se-SAD phasing was
  unambiguous (hand 44.0 vs 14.5 BAYES-CC), the experimental map was directly
  interpretable, and the refined model is of good quality for 2.6 A
  (R-free 0.226, MolProbity 1.10). Deposition-ready pending final curation.

FILE MANIFEST
  gene5_final_model.pdb / .cif ............ final refined model
  gene5_final_map_coeffs_2mFo-DFc_mFo-DFc.mtz  final map coefficients (FWT/PHWT + difference)
  gene5_final_model_geometry.geo .......... refinement restraints/geometry
  gene5_final_refine.log .................. final phenix.refine log
  gene5_experimental_data_and_phases.mtz .. Fobs, SIGF, experimental HL phases,
                                            FreeR_flag, anomalous (F+/F-)
  gene5_experimental_denmod_map_coeffs.mtz  density-modified experimental map
  gene5_selenium_substructure.pdb ......... refined Se substructure (correct hand)
  gene5_autosol_summary.dat ............... AutoSol phasing summary
  gene5_molprobity_final.log .............. final validation report
  gene5_peak_source_scaled_data.sca ....... original scaled anomalous data (source)
  sequence.dat ............................ protein sequence
================================================================================
