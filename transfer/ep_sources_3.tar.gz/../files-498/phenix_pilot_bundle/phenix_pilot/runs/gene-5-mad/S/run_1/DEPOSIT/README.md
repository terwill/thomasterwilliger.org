# Bacteriophage f1 Gene V protein — Se-SAD structure determination

De novo structure solution from a single selenomethionine peak-wavelength dataset
(`peak.sca`) and the target sequence (`sequence.dat`). No prior model was used at
any stage.

## 1. Data

Source: `peak.sca` (peak wavelength λ = 0.9792 Å, f′ = −3, f″ = 4)

| Quantity | Value | Source |
|---|---|---|
| Space group | C 1 2 1 | `logs/01_xtriage.log` |
| Unit cell | 76.08, 27.97, 42.36 Å; 90, 103.2, 90° | `logs/01_xtriage.log` |
| Resolution | 21.33 – 2.594 Å | `logs/01_xtriage.log` |
| Completeness (non-anomalous) | 93.69 % | `logs/01_xtriage.log` |
| Anomalous completeness | 95.14 % | `logs/01_xtriage.log` |
| ⟨I/σ⟩ overall | 29.9 | `logs/01_xtriage.log` |
| Reflections (merged) | 2642 | `logs/01_xtriage.log` |
| Twinning | none suspected (⟨I²⟩/⟨I⟩² = 2.076; untwinned = 2.000) | `logs/01_xtriage.log` |
| Matthews / solvent | 2.24 Å³ Da⁻¹, 45.2 % solvent, 1 copy per ASU | `logs/01_xtriage.log` |
| Anomalous signal extends to | ~3.1 Å (optimistically 2.9 Å) | `logs/01_xtriage.log` |
| Max anomalous measurability | 0.367 (21.3–5.6 Å shell) | `logs/01_xtriage.log` |

## 2. Experimental phasing (SAD)

`phenix.autosol`, 2 Se sites expected (2 Met in an 87-residue sequence).
Parameters: `logs/autosol_sad_params.eff`; log: `logs/02_autosol_sad.log`.

| Quantity | Value |
|---|---|
| HySS substructure CC | 0.272 |
| Sites input / refined by Phaser | 2 / 4 |
| Phaser SAD FOM | 0.435 |
| FOM after RESOLVE density modification | 0.72 |
| BAYES-CC, chosen hand | 44.5 ± 23.7 |
| BAYES-CC, inverse hand | 15.5 ± 36.3 |

**Hand was resolved unambiguously** — the correct hand scores 3× the inverse.

**Quality of the experimental map.** The strongest evidence is what the map
supported, not the scalar scores. The density-modified experimental map
(`experimental_phasing/autobuild_denmod_map_coeffs.mtz`) carried automated
building from 45 → 84 residues with correct sequence register throughout, and
the final refined model correlates with that map at **CC = 0.729 overall**
(main chain 0.663, side chain 0.588) — a model-independent measure, since that
map's phases do not come from the deposited model. The initial AutoSol BAYES-CC
of 44.5 is formally "marginal" (< 50), but it understated the map: iterative
density modification plus rebuilding in `phenix.autobuild` converged cleanly.

## 3. Model building

`phenix.autobuild` from the experimental phases (`logs/03_autobuild.log`):

| Cycle | R / R-free | Residues built | Sequence-assigned |
|---|---|---|---|
| 1 | 0.40 / 0.50 | 56 | 0 |
| 2 | 0.34 / 0.45 | 68 | 33 |
| 3 | 0.28 / 0.41 | 72 | 51 |
| 5 | 0.23 / 0.37 | 77 | 57 |
| 6 | 0.21 / 0.34 | 77 | 57 |
| 9 | 0.16 / 0.27 | 80 | 80 |
| 10 | 0.16 / 0.25 | 84 | 84 |

Subsequent manual/automated corrections:

- **Se-Met 77 completed.** AutoBuild left MSE 77 truncated at CB while a 3σ
  Fo−Fc peak sat 2.4 Å away. Completing the side chain in Coot placed **SE in
  3.85σ density** (CE 2.93σ), raising that residue's map CC 0.582 → 0.649. This
  is a direct, independent confirmation that the HySS/Phaser substructure site
  is real — the anomalous scatterer position is occupied by strong density in
  the refined map. A water (HOH 61, 0.70σ) had been mis-modelled there and was
  removed.
- **Loop 21–24 built** with `phenix.fit_loops` (loop CC 0.46), closing the only
  chain break. Justified by Fo−Fc density of +3.3σ to +4.4σ across the gap;
  R-free improved 0.2195 → 0.2182 on adding it.
- **Side chains of Arg21, Gln22, Lys24 truncated to CB.** Their distal atoms
  had 0.0–0.9σ density (several negative) — not supported by the data.
- **Six rotamer outliers repaired** in Coot with before/after measurement of
  rotamer probability and side-chain map CC.

## 4. Final model

`gene5_final.pdb` / `gene5_final.cif`

| Quantity | Value |
|---|---|
| Residues modelled | 84 / 87 (97 %), A/2 – A/85, no chain breaks |
| Unmodelled | Met1, Lys86, Ala87 (termini, disordered) |
| Waters | 46 |
| Sequence mismatches vs target | 0 |
| Mean B | 24.9 Å² (6.2 – 91.3) |
| **R-work** | **0.1422** |
| **R-free** | **0.2078** |
| Ramachandran favoured / outliers | 96.34 % / 0.00 % |
| Rotamer outliers | 5.63 % (4 residues) |
| Cβ deviations | 0 |
| Clashscore | 1.55 |
| RMS bonds / angles | 0.0104 Å / 1.15° |
| MolProbity score | 1.71 |
| Map-model CC (refined 2Fo−Fc) | 0.816 |
| Map-model CC (experimental DM map) | 0.729 |

Validation: `logs/06_molprobity_final.log`. Refinement: `logs/05_refine_final.log`.

The R-free set was generated once by AutoSol and carried unchanged through every
subsequent refinement; it was never regenerated or extended.

## 5. The one open trade-off — please read before depositing

The final model has **4 rotamer outliers (5.63 %)**: Ser17, Glu40, MSE77, Ile78.
Refining with `rotamer_restraints=True` removes all of them but costs R-free:

| | R-work | R-free | Rot. outliers | Rama outliers | Rama fav. | Clashscore | MolProbity |
|---|---|---|---|---|---|---|---|
| **`gene5_final.pdb`** (deposited) | 0.1422 | **0.2078** | 5.63 % | 0.00 % | 96.34 % | **1.55** | 1.71 |
| `alternative_model/gene5_rotamer_restrained.pdb` | 0.1511 | 0.2300 | **0.00 %** | 0.00 % | 95.12 % | 3.10 | **1.44** |

Why the unrestrained model was chosen as primary:

1. It fits the data better on **both** R-work and R-free — R-free being the
   cross-validation statistic that guards against overfitting.
2. It is better on Ramachandran favoured (96.34 vs 95.12 %), clashscore
   (1.55 vs 3.10) and Cβ deviations (0 in both). It is worse *only* on rotamers.
3. The 4 flagged conformations were tested against the **model-independent**
   density-modified experimental map: side-chain CC was 0.274/0.626/0.592/0.668
   (unrestrained) vs 0.287/0.647/0.576/0.649 (restrained) — differences of
   ≤ 0.02, i.e. **the density at 2.6 Å does not distinguish them**. Forcing the
   rotamers therefore buys no measurable improvement in fit while costing 0.022
   in R-free.
4. Glu40 specifically is a genuine non-rotameric conformation: its side-chain
   atoms sit in 1.13–2.44σ density (CD 2.44σ, OE2 2.39σ), side-chain CC 0.723.

This is a close call, not a clear win. With ~264 free reflections,
σ(R-free) ≈ 0.009, so the 0.022 gap is ≈ 2.4σ — real but modest. **If you prefer
a validation-report-clean entry, deposit the alternative model instead**; both
are chemically and crystallographically defensible, and both are included here.

## 6. Caveats and assumptions

- **Only 2 of 4 Phaser substructure sites are real.** Sites refined to
  occupancies 0.61, 0.58, 0.27, 0.20; the two weak ones are noise. All four
  cluster (through symmetry) around MSE 77. The N-terminal Met1 is disordered
  and its Se was never located — consistent with only one strong site.
- **Loop 21–24 is the least reliable region.** Main-chain density 1.24–1.83σ,
  B-factors 58–74 Å² vs 35–51 for the flanks, per-residue CC 0.40–0.55. The
  backbone path is plausible and improves R-free, but individual φ/ψ there
  should not be over-interpreted; the side chains are deliberately truncated.
- **Gln12** is modelled full-length but its CG sits near 0σ; treat the distal
  atoms as unreliable.
- SAD phasing used the peak dataset only, as requested. `infl.sca` and
  `high.sca` are present in the source directory; a 3-wavelength MAD run would
  give stronger phases and is the configuration the bundled `gene-5-mad.eff`
  was written for.
- No ligands or ions are modelled; no non-water density remained above 3σ apart
  from the Se site described above.

## 7. Directory contents

```
gene5_final.pdb / .cif              deposited model
gene5_final_map_coeffs.mtz          2Fo-Fc and Fo-Fc from final refinement
gene5_refine_data.mtz               F, SIGF, HL coefficients, FreeR_flag
gene5_structure_factors.cif         structure factors, mmCIF (for wwPDB)
sequence.dat                        target sequence

experimental_phasing/
  se_substructure.pdb               Se sites from HySS/Phaser
  experimental_phases.mtz           experimental SAD phases
  autosol_denmod_map_coeffs.mtz     AutoSol density-modified map
  autobuild_denmod_map_coeffs.mtz   AutoBuild density-modified map (used for
                                    the model-independent CC quoted above)
  AutoSol_summary.dat, AutoBuild_summary.dat

alternative_model/                  rotamer-restrained variant (see section 5)
logs/                               all program logs and parameter files
```

## 8. Remaining work before an actual deposition

- Populate deposition metadata (authors, title, crystallisation, beamline,
  detector, temperature) — `mmtbx.prepare_pdb_deposition`.
- Confirm SEQRES matches the crystallised construct, not just the modelled range.
- Decide the rotamer trade-off in section 5.
