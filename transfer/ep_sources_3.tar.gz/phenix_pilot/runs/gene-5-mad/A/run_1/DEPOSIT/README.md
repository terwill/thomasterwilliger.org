# Bacteriophage f1 Gene V protein — Se-Met SAD structure

Solved de novo from `peak.sca` (single-wavelength anomalous data) and `sequence.dat`.
Despite the dataset name (`gene-5-mad`), only one wavelength was supplied, so this is a
**SAD** experiment, not MAD.

## Final statistics

| Quantity | Value | Source file |
|---|---|---|
| Resolution | 21.33 – 2.59 Å | `logs/01_xtriage.log` |
| Space group | C 1 2 1 | `logs/01_xtriage.log` |
| Unit cell | 76.08 27.97 42.36 Å, β = 103.2° | `logs/01_xtriage.log` |
| Molecules / ASU | 1 (Vm 2.24, 45 % solvent) | `logs/01_xtriage.log` |
| R-work | **0.1366** | `logs/05_molprobity.out` |
| R-free | **0.2180** | `logs/05_molprobity.out` |
| MolProbity score | **1.82** | `logs/05_molprobity.out` |
| Clashscore | 3.05 | `logs/05_molprobity.out` |
| Ramachandran favored / outliers | 97.56 % / 0.00 % | `logs/05_molprobity.out` |
| Rotamer outliers | 6.76 % (5 residues) | `logs/05_molprobity.out` |
| Cβ deviations | 0 | `logs/05_molprobity.out` |
| RMS bonds / angles | 0.0105 Å / 1.18° | `logs/05_molprobity.out` |
| Rama-Z (whole) | 1.07 ± 0.94 | `logs/05_molprobity.out` |

## Experimental phasing quality

| Quantity | Value | Source |
|---|---|---|
| Max anomalous measurability | 0.367 (signal to 3.1 Å) | `logs/01_xtriage.log` |
| SAD phasing FOM (before DM) | 0.44 | `experimental_phasing/AutoSol_summary.dat` |
| FOM after density modification | 0.73 | `logs/02_autosol.log` |
| Density-modification R-factor | 0.298 | `logs/02_autosol.log` |
| AutoSol BAYES-CC (best solution) | 48.3 ± 20.2 | `experimental_phasing/AutoSol_summary.dat` |
| CC_mask, AutoSol DM map vs final model | **0.813** | `logs/07_map_model_cc.log` |
| CC_mask, AutoBuild DM map vs final model | 0.890 | `logs/07_map_model_cc.log` |

**Hand determination was unambiguous:** correct-hand solutions scored BAYES-CC 44–48,
inverse-hand solutions 14.1–14.5.

## Model contents

- **Chain A** — 84 residues, 2–85. Sequence matches `sequence.dat` positions 2–85 exactly.
  Met1, Ala86 and Lys87 are disordered and not modelled.
  Met77 is modelled as **MSE** (selenomethionine).
- **Chain S** — 50 ordered waters. 14 are flagged "poorly ordered"
  (2Fo-Fc ≈ 0.7–1.6 σ) in `logs/05_molprobity.out`; retained but low-confidence.
- **Chain Z** — a single partially-occupied **Se atom** (occ 0.84, B 107 Å²).

### The chain Z selenium — provisional assignment

This is **interpreted as the ordered selenium of Met1**, whose backbone is disordered.
Evidence:
- genuine anomalous signal, 5.98 σ peak, in `logs/06_anomalous_substructure.log`;
- 5.50 Å from Ile2 N — the span expected for the preceding residue's Met side-chain Se;
- no steric clashes (nearest contact 4.29 Å);
- the sequence has exactly two Met (M1, M77); M77 is accounted for as MSE77.

It is modelled as a bare Se rather than a full MSE1 because only the selenium is
resolved; building the Met1 backbone would not be supported by the density.
**A depositor should re-examine this assignment.**

## Files

| File | Description |
|---|---|
| `gene5_final.pdb` / `.cif` | Final refined model |
| `gene5_final_maps.mtz` | 2mFo-DFc and mFo-DFc map coefficients |
| `gene5_refine_data.mtz` | Data used for refinement (F, SIGF, HL, **FreeR_flag**) |
| `peak_original.sca` | Original unmodified input data |
| `sequence.dat` | Input sequence |
| `experimental_phasing/` | Experimental phases, DM map, Se substructure, AutoSol summary |
| `logs/` | Full logs for every reported number |

## Cross-validation provenance

The R-free flag set was generated once by AutoSol and carried unchanged through
AutoBuild and every refinement run (`FreeR_flag` in `gene5_refine_data.mtz`,
264 reflections, 10.03 %). It was never regenerated, extended, or re-randomized.
Reported R-free is therefore a valid cross-validation statistic.

## Known limitations

1. **Rotamer outliers 6.76 %** (target < 1 %). The five are A/12 GLN, A/19 VAL,
   A/32 LEU, A/40 GLU, A/80 ARG. Three (GLN12, and the disordered surface residues)
   have side-chain density correlation 0.42–0.50; A/40 and A/80 are well-ordered
   (corr 0.73–0.75) but genuinely non-rotameric. Repeated rotamer refitting did not
   improve them without degrading the fit to density.
2. **Arg21 and Lys24** have distal side-chain atoms set to **occupancy 0** — they sit
   in < 0.7 σ density with negative difference density.
3. **R-work/R-free gap is 8.1 %**, wider than the ~5–6 % typical at 2.6 Å, indicating
   some over-parameterization (2634 reflections vs ~660 atoms).
