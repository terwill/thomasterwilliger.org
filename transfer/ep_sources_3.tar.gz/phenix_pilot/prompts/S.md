# Shipped Expert system prompt (arm S)

Paste your current production Phenix Expert system prompt here, exactly as it runs today.
This file is the S (control) arm.
