# Building AI Agents for Crystallography — Hands-On Tutorials

Four tutorials, **done in order**. Each ends with a working agent.

> This is the **course overview**. Each tutorial has its own README inside its
> folder (`tutorial_1/README.md` … `tutorial_4/README.md`), and Tutorial 4 also
> has a `RUNBOOK.md` for running it live with a class. Start here, then open the
> folder for whichever tutorial you are doing.

---

## The arc

An agent is mostly ordinary, testable code wrapped around **one small model
decision per cycle**. These labs take that apart, then put a leash on it.

| # | Tutorial | You build | The agent is… |
|---|---|---|---|
| **1** | From Rules to Reasoning | the **decide** step | your code's, called once per cycle |
| **2** | Trust But Verify | the **validate** step — the trust boundary | still yours |
| **3** | Steering an Autonomous Agent | the **policy** — in *code* | **driving itself** |
| **4** | Governing the Real Expert | the **policy** — in *English* | **real Phenix, real Coot, real data** |

The escalation that matters is the last two:

* **Tutorial 3** — the agent owns the loop. You govern it with `policy.py`: a gate,
  a scope check, a cross-validation guardrail. **Code.**
* **Tutorial 4** — the same four teeth, on the *real* PHENIX expert, driving real
  Phenix and Coot on real data. You write **no Python at all** — you write its
  constitution, in English, and watch a real agent's behaviour change.

Governance stops being a library and becomes a document. That is the point of the
whole course.

---

## Two ways to do each one

**`python3 guide.py`** — the guided walkthrough. The code is pre-filled; you press
Enter to advance, and at the moments that matter you must commit to a prediction
before it will move on. Everyone finishes, and everyone reaches the punchline.
This is also the script for a **teacher-led, follow-along** session — in Tutorial
4 the room drives the real PHENIX expert together (see `tutorial_4/RUNBOOK.md`).

**`cat README.md`** — the hands-on path. Each tutorial has its own README in its
folder. In Tutorials 1–3 you write every line of Python yourself (~80 min each,
with stubs and a reference solution); in Tutorial 4 you write the agent's
constitution in English and drive the real expert.

Same files, same result.

---

## What is real, and what is simulated

Be clear about this from the start — it is the same discipline the course is
trying to teach you.

| | the LLM | the data and tools | what is ground truth |
|---|---|---|---|
| **1** | hand-written replies | mock runner, invented R-free | *nothing* |
| **2** | hand-written "chaos" | mock runner, invented R-free | *nothing* |
| **3** | a **real PHENIX-expert run** on gene-5, replayed — or a live model with `--live` | mock tools | **the run, and the three real gene-5 overfits** in the arbiter |
| **4** | **the real PHENIX expert** | **real Phenix + Coot, real data** | all of it |

**Tutorials 1 and 2 are entirely simulated.** No model is called, no data is
refined. The LLM's replies are hand-written — but written to be *faithful*: every
failure you meet (a hallucinated program name, an invented filename, a refusal to
stop refining) is one that real LLMs really produce.

That is enough to build against, and it means every student sees the same
behaviour. **But it is not evidence.**

Ground truth enters in **Tutorial 3**. The run you govern is modelled on a real
self-directed run of the PHENIX expert on a gene-V protein at 2.59 Å — a run in
which the agent **caught its own overfit and reverted** (`R-work` fell to 0.173
while the held-out `R-free` rose; it rejected the change). You rebuild that
arbiter from scratch, because the only way to trust a guardrail is to write it:
your cross-validation rule is tested against three real overfits measured on that
data, and the rule you would naively write is **proven wrong** by them. In
**Tutorial 4**, everything is real and the expert governs itself live.

---

## Install and check it works

```bash
python3 install.py ~/agent_course
```

This copies the tutorials and then **proves they work** — it runs every test suite
against the reference solutions, walks every guided path headless, checks the
assembler and the run-log auditor, and confirms your student files are still
unsolved. It ends with either `ALL CHECKS PASSED` or a list of exactly what broke.

`--check` re-verifies an existing install; `--verify-only` checks in place.

`--paranoid` additionally **mutation-tests** the course: it breaks each of the
15 functions you are asked to write, one at a time, and confirms the test suite
notices. If a test can be passed by broken code, that is a bug in the tutorial,
not in you — and this is how we catch it.

---

## What you'll need

* Python 3.8+. **No pip installs** — everything is standard library.
* Any terminal. If yours cannot print UTF-8 (Windows console, `LANG` unset),
  the arrows and ticks degrade to ASCII rather than crashing.
* Tutorial 3, optionally: an `ANTHROPIC_API_KEY` for `--live` (there is a `--demo`
  fallback that needs nothing).
* Tutorial 4: the PHENIX agent, with Phenix and Coot. **Or run it `--offline`** —
  it walks the same ladder against real run logs shipped with the tutorial.

---

## One thing worth knowing before you start

The guardrail you will write in Tutorial 3 — and the one you will write in prose in
Tutorial 4 — went through this exact process while these labs were being built. We
wrote the obvious rule (*"roll back if R-free rises"*), then tested it against three
real overfits on real crystallographic data.

**It caught one of the three.**

That failure is now **Tutorial 3's Exercise 4**, and it is the most important
thing in the course:

> A guardrail you reason out at the desk is not a guardrail
> until it has met real data.
