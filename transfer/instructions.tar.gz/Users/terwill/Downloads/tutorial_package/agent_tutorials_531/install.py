#!/usr/bin/env python3
"""
install.py — install the tutorials somewhere, then prove they work.

    python3 install.py ~/agent_course          # install + verify
    python3 install.py ~/agent_course --check  # verify only, install nothing
    python3 install.py --verify-only           # verify in place (no copy)

What "verify" means here: for every tutorial, we copy in the reference solution,
run the test suite, and confirm it passes — then restore the student stub. If this
script prints ALL CHECKS PASSED, the labs will work on this machine.

Standard library only. No pip, no network.
"""

import os as _os
import sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
import safe_io  # noqa: F401  survive a non-UTF-8 terminal
import argparse
import os
import re
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))

G, R, Y, C, B, X = ("\033[32m", "\033[31m", "\033[33m",
                    "\033[36m", "\033[1m", "\033[0m")
if not sys.stdout.isatty():
    G = R = Y = C = B = X = ""

TUTORIALS = ["tutorial_1", "tutorial_2", "tutorial_3", "tutorial_4"]

# tutorial -> (student file, solution file, test file, expected test count)
CODE_LABS = {
    "tutorial_1": ("decisions.py", "solutions/decisions_complete.py",
                   "test_decisions.py", 29),
    "tutorial_2": ("validators.py", "solutions/validators_complete.py",
                   "test_validators.py", 29),
    "tutorial_3": ("policy.py", "solutions/policy_complete.py",
                   "test_policy.py", 23),
}

results = []


def say(msg=""):
    print(msg)


def record(name, ok, detail=""):
    results.append((name, ok, detail))
    mark = G + "  PASS" + X if ok else R + "  FAIL" + X
    say("%s  %-42s %s" % (mark, name, detail))


def _utf8_env():
    """Subprocesses whose output we PARSE must speak UTF-8, whatever locale the
    student's terminal is in. Display degrades gracefully (safe_io); parsing
    must not degrade at all."""
    e = dict(os.environ)
    e["PYTHONIOENCODING"] = "utf-8"
    return e


def run(cmd, cwd, timeout=180):
    try:
        p = subprocess.run(cmd, cwd=cwd, timeout=timeout,
                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                           env=_utf8_env())
        return p.returncode, p.stdout.decode("utf-8", "replace")
    except subprocess.TimeoutExpired:
        return 1, "TIMEOUT after %ss" % timeout
    except Exception as e:                                    # noqa: BLE001
        return 1, "could not run: %s" % e


def strip_ansi(s):
    return re.sub(r"\033\[[0-9;]*m", "", s)


# ─────────────────────────────────────────────────────────────── environment

def verify_guide(root, t):
    """The guided walkthrough must: run headless, obey the 22-line screen
    contract, produce EXACTLY the reference functions, and pass every test."""
    import ast
    d = os.path.join(root, t)
    g = os.path.join(d, "guide.py")
    if not os.path.exists(g):
        return

    student, solution, tests, _ = CODE_LABS[t]
    sp = os.path.join(d, student)
    backup = sp + ".stub-backup"
    shutil.copy2(sp, backup)
    try:
        rc, out = run([sys.executable, "guide.py", "--reset"], d)
        rc, out = run([sys.executable, "guide.py", "--auto"], d, timeout=300)
        plain = strip_ansi(out)
        ok = rc == 0 and "Traceback" not in plain
        record("%s: guide.py --auto runs" % t, ok,
               "clean" if ok else "FAILED (rc=%d)" % rc)
        if not ok:
            return

        # screen contract: no panel may exceed 22 lines
        lines = plain.splitlines()
        starts = [i for i, l in enumerate(lines)
                  if l.startswith("\u2550") and i + 1 < len(lines)
                  and "STEP" in lines[i + 1]]
        worst, over = 0, 0
        for k, i in enumerate(starts):
            j = starts[k + 1] if k + 1 < len(starts) else len(lines)
            panel = lines[i:j]
            while panel and not panel[-1].strip():
                panel.pop()
            worst = max(worst, len(panel))
            if len(panel) > 22:
                over += 1
        record("%s: 22-line screen contract" % t, over == 0 and len(starts) > 0,
               "%d panels, longest %d lines" % (len(starts), worst)
               if not over else "%d PANELS OVERFLOW" % over)

        # the guided path must produce the reference implementation
        def fns(p):
            return {n.name: ast.dump(n)
                    for n in ast.parse(open(p).read()).body
                    if isinstance(n, ast.FunctionDef)}
        a, b = fns(sp), fns(os.path.join(d, solution))
        same = a == b
        record("%s: guided output == solutions/" % t, same,
               "all %d functions identical" % len(b) if same
               else "DIFFERS: %s" % sorted(set(a) ^ set(b)))

        # and every test must pass
        rc, out = run([sys.executable, tests], d)
        out = strip_ansi(out)
        m = re.search(r"(\d+) passed, (\d+) failed", out)
        if m:
            p_, f_ = int(m.group(1)), int(m.group(2))
        else:
            mm = re.search(r"All (\d+) tests passed", out)
            p_, f_ = (int(mm.group(1)), 0) if mm else (0, 1)
        record("%s: all tests pass after guide" % t, f_ == 0 and p_ > 0,
               "%d passed, %d failed" % (p_, f_))
    finally:
        # The guide's ACT step edits GUIDEME.md. --reset puts BOTH the student
        # file and any edited prompt back, or the next check sees a tightened
        # policy and the whole lesson is spoiled.
        run([sys.executable, "guide.py", "--reset"], d)
        if os.path.exists(backup):
            shutil.move(backup, sp)


def verify_tutorial_4_guide(root):
    """T4's guide has no code lab — verify the conductor's OFFLINE ladder,
    which is what runs when there is no live expert (and in this installer)."""
    d = os.path.join(root, "tutorial_4")
    if not os.path.exists(os.path.join(d, "guide.py")):
        return
    rc, out = run([sys.executable, "guide.py", "--auto"], d, timeout=300)
    plain = strip_ansi(out)
    ok = rc == 0 and "Traceback" not in plain
    record("tutorial_4: guide.py --auto (offline ladder)", ok,
           "clean" if ok else "FAILED (rc=%d)" % rc)
    if not ok:
        return

    lines = plain.splitlines()
    starts = [i for i, l in enumerate(lines)
              if l.startswith("\u2550") and i + 1 < len(lines)
              and "STEP" in lines[i + 1]]
    worst, over = 0, 0
    for k, i in enumerate(starts):
        j = starts[k + 1] if k + 1 < len(starts) else len(lines)
        panel = lines[i:j]
        while panel and not panel[-1].strip():
            panel.pop()
        worst = max(worst, len(panel))
        if len(panel) > 22:
            over += 1
    record("tutorial_4: 22-line screen contract", over == 0 and len(starts) > 0,
           "%d panels, longest %d lines" % (len(starts), worst)
           if not over else "%d PANELS OVERFLOW" % over)

    # the ladder must climb: shipped (no record) -> workflow 5/7 -> governed 7/7
    climbs = ("do NOT" in plain or "does NOT" in plain or "not a record" in plain
              or "audit" in plain)
    climbs = climbs and "5 of 7" in plain and "7 of 7" in plain
    record("tutorial_4: the shipped -> workflow -> governed ladder climbs",
           climbs, "5 of 7 / 7 of 7 present" if climbs else "LADDER BROKEN")


# Every function the student writes, and a way to break it. If breaking it does
# NOT make the tests fail, the tests are not testing it — and a guide panel that
# reports success is lying. This exists because a hardcoded "6 checks passed"
# once shipped in tutorial_1.
MUTATIONS = {
    "tutorial_1": {
        "get_valid_programs": "    return []",
        "parse_llm_response": "    return None",
        "build_context": "    return {}",
        "decide_by_rules": "    return None",
        "decide": "    return None, 'rules'",
    },
    "tutorial_2": {
        "validate_program_name": "    return (True, None)",
        "validate_files_exist": "    return (True, [])",
        "validate_workflow_order": "    return (True, None, None)",
        "validate_no_loop": "    return (False, None)",
        "validate_decision": "    return (True, None, decision)",
    },
    "tutorial_3": {
        "load_policy": "    return {}",
        "needs_approval": "    return (False, None)",
        "check_scope": "    return (True, None)",
        "should_rollback": "    return (False, None)",
        "pre_act": "    return (True, None)",
    },
}


def verify_mutations(root, t):
    """Break each student function in turn. The tests MUST notice."""
    import ast
    if t not in MUTATIONS or t not in CODE_LABS:
        return
    d = os.path.join(root, t)
    student, solution, tests, _ = CODE_LABS[t]
    sp = os.path.join(d, student)
    backup = sp + ".mutation-backup"
    shutil.copy2(sp, backup)
    try:
        src = open(os.path.join(d, solution)).read()
        lines = src.splitlines()
        tree = ast.parse(src)
        survivors = []
        for fn, ret in MUTATIONS[t].items():
            node = next((n for n in tree.body
                         if isinstance(n, ast.FunctionDef) and n.name == fn), None)
            if not node:
                continue
            head = lines[:node.lineno - 1]
            tail = lines[node.end_lineno:]
            open(sp, "w").write(
                "\n".join(head + [lines[node.lineno - 1], ret] + tail) + "\n")
            rc, out = run([sys.executable, tests], d)
            out = strip_ansi(out)
            m = re.search(r"(\d+) passed, (\d+) failed", out)
            clean = re.search(r"All (\d+) tests passed", out)
            if clean or (m and int(m.group(2)) == 0):
                survivors.append(fn)
        record("%s: mutation testing (%d functions)"
               % (t, len(MUTATIONS[t])), not survivors,
               "every break is caught" if not survivors
               else "TESTS MISS: %s" % ", ".join(survivors))
    finally:
        shutil.move(backup, sp)


def check_syntax(root):
    """Every .py file must at least COMPILE.

    A SyntaxError prints no "Traceback" line, so a broken file can sail past a
    naive crash check. It happened. Never again.
    """
    bad, n = [], 0
    for dp, dns, fs in os.walk(root):
        dns[:] = [d for d in dns if d != "__pycache__"]
        for f in fs:
            if not f.endswith(".py"):
                continue
            n += 1
            p = os.path.join(dp, f)
            try:
                compile(open(p, encoding="utf-8").read(), p, "exec")
            except SyntaxError as e:
                bad.append("%s line %s" % (os.path.relpath(p, root), e.lineno))
            except Exception as e:                            # noqa: BLE001
                bad.append("%s: %s" % (os.path.relpath(p, root), e))
    record("every .py file compiles", not bad,
           "%d files OK" % n if not bad else "BROKEN: " + "; ".join(bad[:3]))
    return not bad


def check_python():
    v = sys.version_info
    ok = (v.major, v.minor) >= (3, 9)
    record("Python >= 3.9", ok, "found %d.%d.%d" % (v.major, v.minor, v.micro))
    return ok


# ─────────────────────────────────────────────────────────────── install

def stage_tutorial_4(dest):
    """Pre-build the GUIDEME variants and clean per-run data dirs, so students
    (and the instructor, live) skip the mkdir/cp/assemble terminal steps."""
    d = os.path.join(dest, "tutorial_4")
    if not os.path.isdir(d):
        return
    # (a) assemble every named variant into tutorial_4/
    built = []
    for variant in ("workflow", "gated", "synced", "scoped", "governed"):
        out = os.path.join(d, "GUIDEME-%s.md" % variant)
        rc, _ = run([sys.executable, "assemble.py", variant, "--out", out], d)
        if rc == 0 and os.path.exists(out):
            built.append(variant)
    record("tutorial_4: pre-built GUIDEME variants",
           len(built) == 5, "%s" % ", ".join(built) if built else "none built")

    # (b) give each live run its own clean data dir (only the data, nothing else)
    rs = os.path.join(d, "refined_start")
    staged = []
    if os.path.isdir(rs):
        for stage in ("shipped", "workflow", "governed"):
            rundir = os.path.join(d, "runs", stage)
            os.makedirs(rundir, exist_ok=True)
            for f in os.listdir(rs):
                src = os.path.join(rs, f)
                if os.path.isfile(src):
                    shutil.copy2(src, os.path.join(rundir, f))
            staged.append(stage)
    record("tutorial_4: staged clean per-run data dirs",
           len(staged) == 3, "runs/%s" % ", runs/".join(staged) if staged else "none")


def install(dest):
    dest = os.path.abspath(os.path.expanduser(dest))
    say("%sInstalling to %s%s" % (B, dest, X))
    os.makedirs(dest, exist_ok=True)
    for t in TUTORIALS:
        src = os.path.join(HERE, t)
        if not os.path.isdir(src):
            record("copy %s" % t, False, "not found in %s" % HERE)
            continue
        dst = os.path.join(dest, t)
        if os.path.exists(dst):
            shutil.rmtree(dst)
        shutil.copytree(src, dst,
                        ignore=shutil.ignore_patterns("__pycache__", "*.pyc",
                                                      ".DS_Store", "._*"))
        n = sum(len(f) for _, _, f in os.walk(dst))
        record("copy %s" % t, True, "%d files" % n)
    readme = os.path.join(HERE, "README.md")
    if os.path.exists(readme):
        shutil.copy2(readme, os.path.join(dest, "README.md"))
        record("copy README.md", True, "start here")
    stage_tutorial_4(dest)
    return dest


# ─────────────────────────────────────────────────────────────── verify

def verify_code_lab(root, t):
    """Run the test suite against the reference solution, then restore the stub."""
    d = os.path.join(root, t)
    student, solution, tests, expected = CODE_LABS[t]
    sp = os.path.join(d, student)
    backup = sp + ".stub-backup"

    if not os.path.exists(os.path.join(d, solution)):
        record("%s: solution present" % t, False, solution + " missing")
        return
    # count stubs BEFORE we touch anything — students must get unsolved files
    stubs = open(sp).read().count("YOUR CODE HERE")
    record("%s: student stub intact" % t, stubs == 4,
           "%d 'YOUR CODE HERE' markers (want 4)" % stubs)

    shutil.copy2(sp, backup)
    try:
        shutil.copy2(os.path.join(d, solution), sp)
        rc, out = run([sys.executable, tests], d)
        out = strip_ansi(out)
        m = re.search(r"(\d+)\s+passed,\s+(\d+)\s+failed", out)
        if m:
            passed, failed = int(m.group(1)), int(m.group(2))
        else:
            passed = len(re.findall(r"^\s*PASS", out, re.M))
            failed = len(re.findall(r"^\s*FAIL", out, re.M))
        ok = (failed == 0 and passed >= expected and rc == 0)
        record("%s: %s" % (t, tests), ok,
               "%d passed, %d failed (want >=%d, 0)" % (passed, failed, expected))
    finally:
        shutil.move(backup, sp)          # always restore the stub

    # the runner must not crash — and a SyntaxError prints no "Traceback",
    # so check the return code as well.
    rc, out = run([sys.executable, "run_agent.py"], d)
    ok = rc == 0 and "Traceback" not in out and "SyntaxError" not in out
    record("%s: run_agent.py runs" % t, ok,
           "clean exit" if ok else "FAILED (rc=%d)" % rc)


def verify_tutorial_3_live(root):
    d = os.path.join(root, "tutorial_3")
    rc, out = run([sys.executable, "test_live.py"], d)
    out = strip_ansi(out)
    m = re.search(r"(\d+)\s+passed,\s+(\d+)\s+failed", out)
    passed, failed = (int(m.group(1)), int(m.group(2))) if m else (0, 1)
    record("tutorial_3: test_live.py", failed == 0 and passed >= 18,
           "%d passed, %d failed" % (passed, failed))

    # --demo must work with NO api key at all
    env_backup = os.environ.pop("ANTHROPIC_API_KEY", None)
    try:
        rc, out = run([sys.executable, "run_agent.py", "--demo"], d)
        ok = "Traceback" not in out and rc == 0
        record("tutorial_3: --demo without API key", ok,
               "works offline" if ok else "FAILED")
    finally:
        if env_backup is not None:
            os.environ["ANTHROPIC_API_KEY"] = env_backup


def verify_tutorial_4_expert(root):
    d = os.path.join(root, "tutorial_4")

    # the assembler must build the whole named ladder
    for variant in ("workflow", "gated", "synced", "scoped", "governed"):
        rc, out = run([sys.executable, "assemble.py", variant], d)
        ok = rc == 0 and "WORKFLOW MODULE" in out   # workflow rides along in all
        if not ok:
            record("tutorial_4: assemble %s" % variant, False, "failed")
            return
    record("tutorial_4: assemble workflow..governed", True,
           "all five named variants build")

    # no GUIDEME_base identity should leak into any assembled variant
    rc, wf = run([sys.executable, "assemble.py", "workflow"], d)
    clean = "Principal Automation Scientist" not in wf   # base identity dropped
    record("tutorial_4: base identity is not supplied", clean,
           "assembly starts at the workflow module" if clean
           else "BASE IDENTITY LEAKING")

    # workflow variant = guidance + a run log, but NO governance teeth yet
    has_wf = "WORKFLOW MODULE" in wf and "Run Log" in wf
    no_teeth = "The Execution Gate" not in wf and "Stay in Scope" not in wf
    record("tutorial_4: workflow variant is guidance + log only",
           has_wf and no_teeth,
           "workflow + run_log, no gate/scope" if (has_wf and no_teeth)
           else "WRONG MODULE SET")

    # the shipped-baseline prompts must carry the data-safety floor
    import glob as _glob
    sp = _glob.glob(os.path.join(d, "shipped_prompt", "*.md"))
    floor_ok = bool(sp) and all(
        ("may not disregard" in open(f).read() or "harm to the data" in open(f).read())
        for f in sp)
    record("tutorial_4: shipped prompts keep the data-safety floor", floor_ok,
           "do-no-harm floor present in all shipped prompts" if floor_ok
           else "SHIPPED PROMPT MISSING FLOOR")

    # base_prompt.md must ship and carry the real base principles students read
    bp = os.path.join(d, "base_prompt.md")
    bp_ok = os.path.exists(bp) and all(
        k in open(bp).read() for k in
        ("Evidence over assertion", "Physical realism", "cross-validation"))
    record("tutorial_4: base_prompt.md ships with the real principles", bp_ok,
           "students can read the expert's shipped instructions" if bp_ok
           else "BASE PROMPT MISSING OR INCOMPLETE")

    # the checker must separate governed from ungoverned on the REAL logs
    fx = os.path.join(d, "fixtures")
    expect = "gate,coot_sync,scope,cross_validation,source_citation,closure"
    rc, out = run([sys.executable, "check_run.py",
                   os.path.join(fx, "RUN_LOG_E_real.json"),
                   "--expect", expect], d)
    record("tutorial_4: checker PASSes the governed run", "PASS" in strip_ansi(out),
           "real run E -> 7/7")

    rc, out = run([sys.executable, "check_run.py",
                   os.path.join(fx, "RUN_LOG_log_only.json"),
                   "--expect", expect], d)
    out = strip_ansi(out)
    record("tutorial_4: checker FAILs the control", "FAIL" in out,
           "log-only -> governance absent")

    rc, out = run([sys.executable, "check_run.py",
                   os.path.join(d, "no_such_RUN_LOG.json")], d)
    record("tutorial_4: missing log reported honestly",
           "no audit trail" in strip_ansi(out).lower(),
           "the shipped run leaves nothing to audit")

    # the governance modules must be OPERATIONAL — real production guidance, not
    # vague starters (the expert refuses to run on placeholders). Check the two
    # that were previously stubs now carry concrete, executable rules.
    eh = os.path.join(d, "addons", "error_handling.md")
    eh_txt = open(eh).read() if os.path.exists(eh) else ""
    eh_ok = ("STARTER" not in eh_txt
             and "two retries" in eh_txt.lower() or "at most **two**" in eh_txt
             or "retry is forbidden" in eh_txt.lower())
    record("tutorial_4: error_handling is operational", eh_ok,
           "bounded retries + technical/scientific split" if eh_ok
           else "STILL A STARTER")
    cv = os.path.join(d, "addons", "cross_validation.md")
    cv_txt = open(cv).read() if os.path.exists(cv) else ""
    cv_ok = ("STARTER" not in cv_txt and "cross_validation_decisions" in cv_txt
             and "revert" in cv_txt.lower()
             and ("gap widens" in cv_txt.lower() or "gap" in cv_txt.lower()))
    record("tutorial_4: cross_validation arbiter is operational", cv_ok,
           "measured test + auto-revert + logged decision" if cv_ok
           else "STILL A STARTER")

    # the workflow variant must be the REAL pipeline minus governance — all six
    # phases, the structured run log, and NONE of the governance teeth.
    rc, wf = run([sys.executable, "assemble.py", "workflow"], d)
    phases = sum(("Phase %d" % i) in wf for i in range(6))
    has_log = "RUN_LOG.json" in wf and "FINAL" in wf
    no_teeth = ("Execution Gate" not in wf and "Stay in Scope" not in wf
                and "Cross-Validation" not in wf and "Coot Synchronization" not in wf)
    wf_ok = phases == 6 and has_log and no_teeth and "STARTER" not in wf
    record("tutorial_4: workflow is the real pipeline minus governance", wf_ok,
           "6 phases + run log, no governance teeth" if wf_ok
           else "workflow variant is thin or leaks governance")

    # the refined_start data must ship intact: files present, MTZ valid,
    # and the model at the R-factors the whole tutorial cites.
    rs = os.path.join(d, "refined_start")
    files_ok = all(os.path.exists(os.path.join(rs, f))
                   for f in ("model.pdb", "data.mtz", "sequence.dat"))
    mtz_ok = False
    model_ok = False
    if files_ok:
        with open(os.path.join(rs, "data.mtz"), "rb") as fh:
            mtz_ok = fh.read(4) == b"MTZ "
        pdb = open(os.path.join(rs, "model.pdb")).read()
        model_ok = ("0.1975" in pdb and "0.2401" in pdb and "C 1 2 1" in pdb)
    record("tutorial_4: refined_start data ships intact",
           files_ok and mtz_ok and model_ok,
           "model+mtz+seq, valid MTZ, R-work 0.1975/R-free 0.2401"
           if (files_ok and mtz_ok and model_ok) else "MISSING OR CORRUPT")


def verify_shipped_policy(root):
    """The shipped GUIDEME must be LOOSE, or Exercise 4's punchline is spoiled."""
    for t in ("tutorial_3",):
        p = os.path.join(root, t, "GUIDEME.md")
        txt = open(p).read() if os.path.exists(p) else ""
        tol = re.search(r"^r_free_tolerance:\s*([\d.]+)", txt, re.M)
        gap = re.search(r"^max_gap:\s*([\d.]+)", txt, re.M)
        ok = bool(tol and gap and float(tol.group(1)) > 0.02
                  and float(gap.group(1)) > 0.10)
        record("%s: shipped GUIDEME is loose" % t, ok,
               "tol=%s max_gap=%s (overfit must slip through)"
               % (tol.group(1) if tol else "?", gap.group(1) if gap else "?"))


# ─────────────────────────────────────────────────────────────── main

def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("dest", nargs="?", help="where to install")
    ap.add_argument("--paranoid", action="store_true",
                    help="also mutation-test every student function (slower)")
    ap.add_argument("--check", action="store_true",
                    help="verify an existing install; copy nothing")
    ap.add_argument("--verify-only", action="store_true",
                    help="verify the tutorials right here, in place")
    a = ap.parse_args()
    global PARANOID
    PARANOID = a.paranoid

    say("%s%s" % (B, "=" * 62))
    say("  Building AI Agents for Crystallography — installer")
    say("%s%s" % ("=" * 62, X))
    say()

    if not check_python():
        say("\n%sPython 3.9+ is required. Stopping.%s" % (R, X))
        sys.exit(1)

    if a.verify_only:
        root = HERE
        say("%sVerifying in place: %s%s\n" % (B, root, X))
    elif a.dest:
        root = a.dest if a.check else install(a.dest)
        root = os.path.abspath(os.path.expanduser(root))
        say()
    else:
        ap.error("give a destination, or use --verify-only")

    say("%sVerifying — running every test suite against the reference solutions%s"
        % (B, X))
    say()

    check_syntax(root)

    for t in ("tutorial_1", "tutorial_2", "tutorial_3"):
        if os.path.isdir(os.path.join(root, t)):
            verify_code_lab(root, t)
            verify_guide(root, t)
            if PARANOID:
                verify_mutations(root, t)
    if os.path.isdir(os.path.join(root, "tutorial_3")):
        verify_tutorial_3_live(root)
    verify_shipped_policy(root)
    if os.path.isdir(os.path.join(root, "tutorial_4")):
        verify_tutorial_4_expert(root)
        verify_tutorial_4_guide(root)

    # tidy up after ourselves: running the suites creates __pycache__
    for dp, dns, _ in os.walk(root):
        for dn in list(dns):
            if dn == "__pycache__":
                shutil.rmtree(os.path.join(dp, dn), ignore_errors=True)
                dns.remove(dn)

    # a .stub-backup left behind would mean a student gets a SOLVED file
    strays = [os.path.join(dp, f)
              for dp, _, fs in os.walk(root) for f in fs
              if f.endswith(".stub-backup")]
    record("student files restored (no solutions left behind)", not strays,
           "clean" if not strays else "%d files still solved!" % len(strays))

    say()
    passed = sum(1 for _, ok, _ in results if ok)
    failed = len(results) - passed
    say("%s%s" % (B, "=" * 62))
    if failed:
        say("%s  %d checks FAILED%s (%d passed)" % (R, failed, X, passed))
        say("%s" % ("=" * 62))
        say("\nFailures:")
        for n, ok, d in results:
            if not ok:
                say("  %s- %s: %s%s" % (R, n, d, X))
        sys.exit(1)

    say("%s  ALL %d CHECKS PASSED%s — the tutorials will work on this machine."
        % (G, passed, X))
    say("%s%s" % ("=" * 62, X))
    if not a.verify_only:
        say("\nStart here:  %s%s/README.md%s" % (C, root, X))
        say("Then:        cd %s/tutorial_1 && cat README.md" % root)


if __name__ == "__main__":
    main()
