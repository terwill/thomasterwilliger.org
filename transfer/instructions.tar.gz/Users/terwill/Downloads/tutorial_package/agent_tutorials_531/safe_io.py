"""
safe_io.py — do not let a box-drawing character kill the tutorial.

These labs print arrows, ticks and rules: → ✓ ✗ ═ · —

On a UTF-8 terminal that is fine. On a Windows console, or an SSH session with
LANG unset, or a machine with a legacy locale (cp1252, cp874, cp932), Python
raises UnicodeEncodeError on the FIRST print and the student sees a traceback
instead of Tutorial 1.

This module fixes that, and only when it needs to:

  * If stdout can encode the glyphs, it does nothing at all.
  * If it cannot, stdout is wrapped in a writer that transliterates them to
    ASCII (→ becomes ->, ✓ becomes OK) and replaces anything else rather
    than raising.

Import it — `import safe_io` — at the top of anything that prints. Standard
library only, no configuration, safe to import twice.
"""

import sys

# Only the characters this course actually emits.
_MAP = {
    "\u2192": "->",     # →
    "\u2190": "<-",     # ←
    "\u21a9": "<-",     # ↩
    "\u2713": "OK",     # ✓
    "\u2714": "OK",     # ✔
    "\u2717": "X",      # ✗
    "\u2718": "X",      # ✘
    "\u274c": "X",      # ❌
    "\u270b": "STOP",   # ✋
    "\u26a0": "!",      # ⚠
    "\u2550": "=",      # ═
    "\u2500": "-",      # ─
    "\u2502": "|",      # │
    "\u251c": "+",      # ├
    "\u2514": "+",      # └
    "\u2026": "...",    # …
    "\u2014": "-",      # —
    "\u2013": "-",      # –
    "\u00b7": ".",      # ·
    "\u00d7": "x",      # ×
    "\u2265": ">=",     # ≥
    "\u2264": "<=",     # ≤
    "\u2286": "subset of",
    "\u00c5": "A",      # Å
    "\u2018": "'", "\u2019": "'",
    "\u201c": '"', "\u201d": '"',
}

_PROBE = "\u2192\u2713\u2550\u00b7"        # → ✓ ═ ·


def _can_encode(stream):
    enc = getattr(stream, "encoding", None)
    if not enc:
        return False
    try:
        _PROBE.encode(enc)
        return True
    except (UnicodeEncodeError, LookupError):
        return False


class _AsciiWriter(object):
    """Transliterate what we can; replace what we cannot. Never raise."""

    def __init__(self, stream):
        self._stream = stream

    def write(self, text):
        for uni, plain in _MAP.items():
            text = text.replace(uni, plain)
        enc = getattr(self._stream, "encoding", None) or "ascii"
        text = text.encode(enc, "replace").decode(enc, "replace")
        return self._stream.write(text)

    def __getattr__(self, name):
        return getattr(self._stream, name)


def install():
    """Wrap stdout/stderr only if they cannot cope. Idempotent."""
    for name in ("stdout", "stderr"):
        stream = getattr(sys, name, None)
        if stream is None or isinstance(stream, _AsciiWriter):
            continue
        if not _can_encode(stream):
            setattr(sys, name, _AsciiWriter(stream))


install()
