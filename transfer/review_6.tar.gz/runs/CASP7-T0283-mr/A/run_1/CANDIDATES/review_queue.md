# Candidate review queue — CASP7-T0283-mr (arm A)

1 distinct leads for expert review (ranked by severity, then cross-vantage agreement).

## 1. [moderate] Conclude 2nd copy is real; re-run Phaser with copy 1 fixed as partial solution
- flagged_by: self   ·   triage: keep   ·   High R-free at 1 copy has many explanations (model errors, solvent, twinning, wrong space group) besides a missing second copy, so concluding the copy is real is an unjustified interpretive leap worth expert review.
- at decision, knew: 1-copy refine gave R-work 0.323 / R-free 0.335, geometry fine (bonds 0.015 Å)
- concern: Inference that unmodeled scattering implies a real second copy (interpretive leap from R-free)
- alternative: 
- provenance: #194
