# Candidate review queue — esterase_tNCS (arm A)

4 distinct leads for expert review (ranked by severity, then cross-vantage agreement).

## 1. [major] Reported final status, noting N-terminal 1–2 trimmed as disordered and SS-bonds applied
- flagged_by: self   ·   triage: keep   ·   Two SS-bond linkages applied in refinement but zero SSBOND records in the deposited PDB is a real annotation inconsistency that would misrepresent the model's connectivity to users.
- at decision, knew: Final DEPOSIT model: chains A/B 190 residues (3–192), 424 waters, 0 SSBOND in PDB but 2 SS-bond linkages applied in refinement
- concern: Discrepancy noted between SSBOND count in PDB (0) and 2 SS-bond linkages applied in refinement
- alternative: 
- provenance: #302

## 2. [moderate] Built no catalytic metal or ligand; treated the structure as apo.
- flagged_by: self+self_critique   ·   2 vantages   ·   triage: keep   ·   A 9.4 sigma unmodeled difference peak plus an unexamined conserved metal-binding triad warrants active-site-specific OMIT/polder inspection before declaring the structure apo.
- at decision, knew: find_peaks_holes reported max mFo-DFc 9.4 sigma near Arg/Gly/waters; no dominant peak; CE4 metal site not obviously occupied; global peak list only. README/buffer chemistry skipped by instruction.
- concern: The 'apo' call was inferred from the global peak list without an active-site-specific check of the conserved CE4 metal-binding triad (Asp/His/His) or an OMIT map; residual 9 sigma peaks left unmodeled. A real metal or anion could be under-modeled.
- alternative: Examine the conserved Asp/His/His triad for a coordinated difference peak and compute an OMIT/polder map at the active site; consult buffer chemistry for a likely anion (e.g. sulfate). Coordinated density at the triad or a well-defined OMIT peak would distinguish a genuine metal/anion from noise or disordered solvent.
- provenance: #214; D9
  - also flagged by self (#214): Interpreting residual 5–9σ peaks as waters/anions rather than a metal — inferred rather than confirmed ('appears to be')

## 3. [moderate] Proceeded without the planned hands-on Coot rebuild of outliers, documenting the tool failure.
- flagged_by: self+self_critique   ·   2 vantages   ·   triage: keep   ·   A planned hands-on rebuild step was skipped due to tool failure and only partially substituted by density checks, leaving subtle rebuildable errors potentially undetected, which warrants expert review.
- at decision, knew: Coot's Python interpreter returned 'Failed to get __main__ module' on every call; coot_info static text worked but run_python/run_python_multiline/coot_ping all failed. Retried ~30-60 s cadence for >15 min per instruction.
- concern: The requested rebuild step never executed, so coverage of subtle rebuildable errors is weaker than a normal run; density checks substitute for but do not equal hands-on inspection.
- alternative: Restore/restart a working Coot (or use an alternative interactive rebuild tool) and perform the outlier rebuild. Rebuildable errors surfacing under manual inspection would distinguish a genuinely clean model from one with unaddressed local errors.
- provenance: #244; D10
  - also flagged by self (#244): Rebuild not completed; notes targets were assessed independently via density as genuine features not errors

## 4. [moderate] Interpreted the 3 Ramachandran outliers as real; did not restrain or flip them.
- flagged_by: self_critique   ·   triage: keep   ·   Retaining Ramachandran outliers based solely on model-biased 2mFo-DFc RSCC and NCS consistency, without an independent OMIT/polder map, leaves a legitimate risk of unmodeled pepflips.
- at decision, knew: Per-residue RSCC 0.95-0.97 from the refined 2mFo-DFc map, occupancy 1.0, low B; Ile123 outlier appeared identically in both NCS copies. Coot unavailable.
- concern: Retention rests on model-biased RSCC plus NCS consistency rather than an independent bias-reduced map or hands-on inspection; Rama outliers at 0.80% exceed the <0.5% goal.
- alternative: Compute an OMIT/polder map at the outlier residues (and inspect visually in Coot) to confirm the conformation without model bias. Retained density in the OMIT map would support keeping the outliers; absence would argue for a pepflip or favored-region restraint.
- provenance: D7
