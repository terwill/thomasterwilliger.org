# Candidate review queue — beta-blip (arm A)

7 distinct leads for expert review (ranked by severity, then cross-vantage agreement).

## 1. [major] No deep/real rebuilding (autobuild, loop fitting, simulated annealing) was performed; only rotamer-level Coot passes and refinement.
- flagged_by: self+self_critique   ·   2 vantages   ·   triage: keep   ·   R-free ~0.31 at 3.0 Å with only rotamer-level rebuilding and untrimmed MR models leaves residual model error plausibly correctable by autobuild/loop fitting/SA that was never attempted.
- at decision, knew: R-free stuck at ~0.31 (higher than ideal for 3.0 Å) across all rounds; only rotamer-level rebuilding (D5/D7) was done; search models used untrimmed (D2); no autobuild/loop fitting ever run.
- concern: Whether the fold/register in weak-density regions is fully correct is not independently established beyond the strong MR signal and map fit; R-free was never reduced by real rebuilding.
- alternative: Run autobuild/loop fitting or simulated annealing to escape MR/rebuild bias and target weak-density loops. Distinguishing evidence: a targeted rebuild lowering R-free would indicate residual model error was correctable; unchanged R-free would support the residual being data-limited at 3.0 Å.
- provenance: #294; Backward-trace
  - also flagged by self (#294): R-free ~0.31 is on the high side for 3.0 Å; deeper rebuilding not performed

## 2. [major] Run one more polishing round restoring individual_sites_real_space term
- flagged_by: self   ·   triage: keep   ·   A clashscore of 20.4 is a real geometry regression traced to a deliberate strategy override, and the proposed fix rests on an unverified causal claim worth expert review.
- at decision, knew: refine5 stats: rotamer outliers down to 1.46%, Rama 0% outliers, but clashscore jumped to 20.4
- concern: Clashscore jumped to 20.4 due to overriding default strategy and dropping the real-space term
- alternative: 
- provenance: #240-#241

## 3. [major] Treat standalone MolProbity rotamer count as authoritative over refine-log value
- flagged_by: self   ·   triage: keep   ·   A 23-fold discrepancy (0.29% vs 6.7%) between refine-log and MolProbity rotamer counts is unusually large to attribute solely to library differences and warrants expert verification of which value reflects the true model quality.
- at decision, knew: Standalone MolProbity rotamer outliers 0.29% vs refine-log 6.7%
- concern: Discrepancy between refine-log and MolProbity rotamer counts due to different libraries
- alternative: 
- provenance: #261

## 4. [major] Include occupancy refinement in the very first refinement cycle, alongside rigid-body, coordinate, and ADP refinement.
- flagged_by: transcript_pass   ·   triage: keep   ·   Refining occupancies on a raw, unrefined MR model at 3.0 A risks the algorithm absorbing model errors into meaningless occupancy values, contravening standard protocol.
- at decision, knew: A raw molecular replacement solution at 3.0 A resolution, prior to any refinement.
- concern: Refining occupancies at this early stage is highly problematic. The model contains significant errors, and the refinement algorithm can easily reduce occupancy to compensate for poorly-fit atoms or high B-factors, trading a lower R-factor for a physically meaningless model. Occupancy refinement should typically be reserved for the final stages, and only when there is strong evidence for partial occupancy.
- alternative: Omit occupancy refinement from the initial refinement strategy. The standard protocol is rigid body, then coordinates and B-factors. Occupancies should be fixed at 1.0 until the model is substantially complete and validated. Comparing the B-factors and map-model fit from a run without occupancy refinement would demonstrate its inappropriateness here.
- provenance: 81 82

## 5. [moderate] First Coot rebuild pass: per-residue auto-fit + local (3-residue) real-space refinement.
- flagged_by: self+transcript_pass+self_critique   ·   3 vantages   ·   triage: keep   ·   Committing a full sweep of local 3-residue real-space refinement without a pre-sweep Ramachandran baseline is a defensible-but-risky choice at 3.0 Å where backbone can be perturbed to chase density, warranting expert review.
- at decision, knew: 9.6% rotamer outliers after refine1; coot-model-building skill recommends refining neighbours for context. Checked rotamers only mid-sweep, not Ramachandran before committing the whole sweep.
- concern: The 3-residue local refinement window strained the backbone: Ramachandran favored dropped 95.5%→90.6% and outliers rose 0.24%→1.89%, a real degradation visible in refine2 validation; even after recovery final favored (~91.5%) may still reflect residual strain.
- alternative: Use side-chain-only auto-fit (the approach eventually adopted in D7), which cannot perturb phi/psi. Distinguishing evidence: post-pass Ramachandran statistics (favored, outliers) compared before and after the sweep would have flagged the backbone strain earlier.
- provenance: #214-#215; D5
  - also flagged by both (#214-#215): Earlier aggressive Coot per-residue refines had displaced/strained the backbone, lowering favored fraction || AUDITOR: The agent's own analysis reveals this decision was harmful. At 3.0 A, per-residue real-space refinement in Coot can easily distort the backbone to chase ambiguous density, degrading Ramachandran geometry. This is exactly what happened, increasing Ramachandran outliers from 0.24% to 1.89%. This created a new problem (poor backbone) while solving another (C-beta deviations), necessitating several more rounds of refinement to fix a self-inflicted error.

## 6. [moderate] Do a gentle side-chain-only rotamer pass with no backbone perturbation, then a final refine
- flagged_by: both   ·   2 vantages   ·   triage: keep   ·   Accepting 41 automated rotamer fits at 3.0 Å density without visual inspection against the map is a real risk of introducing sterically-allowed but incorrect rotamers and new clashes.
- at decision, knew: refine4 stats: R-free 0.3084, rotamer outliers rose to 11.7%; R-free plateaued ~0.306-0.312
- concern: R-free genuinely plateaued; residual is real model error in long side chains poorly constrained by 3.0 Å density; backbone perturbation previously damaged Ramachandran || AUDITOR: The agent confidently states that outliers went from 41 to 0. While the strategy to avoid backbone movement is sound, automatically accepting the results for all 41 side chains without any mention of visual inspection is risky. At 3.0 A resolution, density for side chains is often weak or ambiguous. Automated fitting can easily choose a rotamer that is sterically allowed but incorrect, often leading to new clashes, which is exactly what happened in the next step (clashscore jumped to 20.4).
- alternative: After the automated fitting, manually inspect the 41 changed rotamers against the 2mFo-DFc map to confirm they are well-supported by density and not causing new problems. Reject any fits that are ambiguous or create clashes. This would have caught the clash issue before the next refinement round.
- provenance: #223

## 7. [moderate] Selected refine6 as final model over the lower-R-free refine2.
- flagged_by: transcript_pass+self_critique   ·   2 vantages   ·   triage: keep   ·   A defensible geometry-vs-R-free trade-off was made, but the 'within noise' claim was asserted qualitatively when a paired-significance test was readily available to confirm it.
- at decision, knew: Apples-to-apples MolProbity: refine6 score 2.10 vs refine2 2.82; R-free 0.3141 vs 0.3067 (+0.007) over 881 test reflections. Paired-model R-free significance test (Hamilton) not run.
- concern: The 'within noise' claim was asserted qualitatively rather than tested with a paired-significance check (Hamilton), so the R-free vs MolProbity trade-off rests on judgement.
- alternative: Pick refine2 for lowest R-free, or run a paired-model R-free significance test to quantitatively confirm the 0.007 difference is not meaningful. Both models were preserved in DEPOSIT to avoid silently committing.
- provenance: 270 270; D8
  - also flagged by transcript_pass (270 270): The choice is well-defended, but calling it 'unambiguously best' is an overstatement. The chosen model has a higher R-free (0.314) than the main alternative, `refine2` (0.307). While the difference is small, R-free is a critical cross-validation metric. A competent crystallographer could reasonably argue for prioritizing the lower R-free, accepting the poorer rotamer statistics as a reflection of the 3.0 A data quality rather than 'fixing' them at the expense of agreement with the test set. The confidence displayed ignores this valid scientific disagreement.
