# Candidate review queue — AF_7mjs_H_PredictAndBuild (arm A)

4 distinct leads for expert review (ranked by severity, then cross-vantage agreement).

## 1. [major] Report result with two explicit caveats
- flagged_by: self   ·   triage: keep   ·   A verified Trp47 repair may have been lost due to the Coot crash, meaning the deposited model could omit a correction that was validated, which warrants expert review.
- at decision, knew: Final validation metrics; Coot crash record; both deposited models
- concern: Coot crashed and never recovered; the verified Trp47 repair was not saved and is lost
- alternative: 
- provenance: #304

## 2. [moderate] Chose the post-Coot model as the primary deposited model despite the Trp47 backbone outlier.
- flagged_by: self+transcript_pass+self_critique   ·   3 vantages   ·   triage: keep   ·   Depositing a model with a known framework Ramachandran outlier over a clean-backbone alternate is a defensible but genuine judgment call trading global backbone geometry against CDR side-chain correctness, worth expert review.
- at decision, knew: Post-Coot model had better composite MolProbity (1.78 vs 1.81), CC (0.848 vs 0.844), clash (8.07 vs 8.57), and correct CDR-H2 interface rotamers (the task's explicit requirement), but carried a Trp47 Ramachandran outlier whose fix was verified but lost. No reliable non-interactive way to reproduce the pepflip in Phenix via MCP.
- concern: Reasonable reviewers could prefer the 0-outlier clean-backbone alternate (Model A); weighting one framework backbone outlier against CDR side-chain correctness is a genuine judgement call.
- alternative: Make the clean-backbone Model A the primary. Distinguishing evidence: whether reviewers weight one framework backbone outlier over CDR side-chain correctness — assessed via both models' MolProbity and map-model FSC. Both models were preserved rather than forcing the call.
- provenance: #283; D8
  - also flagged by both (#283): Model B carries one framework backbone Ramachandran outlier (Trp47) that Model A does not || AUDITOR: This is a difficult judgment call, and the agent's choice is well-reasoned. However, depositing a model with a known Ramachandran outlier as the primary version is a significant decision. While the CDR rotamers are better, some validation pipelines or users might automatically flag the model as problematic due to the backbone geometry. The agent confidently prioritizes side-chain fit in a specific region over perfect backbone geometry globally.

## 3. [moderate] Ran the interactive Coot pass without periodically saving checkpoints to disk during the session.
- flagged_by: self+self_critique   ·   2 vantages   ·   triage: keep   ·   Failing to checkpoint verified fixes to disk during an interactive session is a real robustness gap that led to loss of a validated repair, worth expert review.
- at decision, knew: The Coot interface-loop pass performed a Trp47 pepflip fix (verified probability 0.0004->0.092) held in-memory as imol 50. A run_python_multiline verification call triggered 'Failed to get __main__ module', crashing the interpreter; Coot did not recover within the 15-min retry window.
- concern: The interpreter crash lost the already-verified Trp47 repair because there was no periodic save-checkpoint-to-disk during the interactive pass, so the fix could not be recovered; the primary deposited model therefore carries the outlier.
- alternative: Save intermediate versioned models to disk after each verified fix during the interactive pass. Distinguishing evidence: presence of an on-disk model with the verified pepflip (prob 0.092) that would survive an interpreter crash.
- provenance: #214; plan divergence
  - also flagged by self (#214): The verified Trp47 fix is unsaved and will be lost if Coot doesn't recover

## 4. [moderate] Accepted the Glu46 rotamer fix, which re-refined residues 45-47.
- flagged_by: self_critique   ·   triage: keep   ·   Accepting a local re-refinement of 45-47 based solely on Glu46 CC/rotamer gains without re-checking neighbour backbone geometry is a plausible way to introduce an uncaught outlier.
- at decision, knew: At decision time: Glu46 side-chain CC improved 0.653->0.712 and rotamer outlier fraction dropped 0.71%->0.00%. The fix triggered a re-refinement of residues 45-47.
- concern: The local refine of 45-47 pushed neighbouring Trp47 into a Ramachandran outlier, but the backbone/phi of Trp47 was not re-checked immediately after refining; it was only caught later by MolProbity. This created the only Ramachandran outlier in the primary model.
- alternative: Refine only the Glu46 side chain, or refine 45-47 and then re-check the neighbour backbone. Distinguishing evidence: post-refine MolProbity Ramachandran status of Trp47 (independent of the CC gain that masked the problem).
- provenance: D7
