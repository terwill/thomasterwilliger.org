# Candidate review queue — nsf-d2-ligand (arm A)

9 distinct leads for expert review (ranked by severity, then cross-vantage agreement).

## 1. [major] Conclude atp.pdb is an unfitted starting conformer; decide it must be fitted de novo, not merely refined; find where density actually is
- flagged_by: self   ·   triage: keep   ·   Concluding the ligand must be fitted de novo based on apo mFo-DFc density at ATP coordinates is a legitimate but consequential structural call resting on a single probe, warranting expert confirmation that the map used is appropriate.
- at decision, knew: probe2.py: apo mFo-DFc at 31 ATP atoms mean +0.02 σ, 0/31 above 3σ
- concern: supplied ATP pose is not in the density; it is an unfitted starting conformer
- alternative: 
- provenance: #83

## 2. [major] Asserted in the user-facing PROPOSED PLAN that the supplied ATP sat in 'a bona fide nucleotide pocket'.
- flagged_by: self_critique   ·   triage: keep   ·   A confident 'bona fide nucleotide pocket' assertion in a user-facing plan was based on pattern-matching a misidentified P-loop (CSPDKMI is not a Walker-A motif) while both the sequence and a refuting apo difference map were available but unexamined.
- at decision, knew: A contact list produced by the agent's own script (CYS568-ILE574, PHE589, ASP590/591, TYR593, LEU608, VAL628, LYS632, ALA633), labelling CSPDKMI a 'P-loop'. The sequence hierarchy was loaded in the same script but not printed for residue types; the apo difference map was also available before the claim was written.
- concern: A confident structural site assignment made from pattern-matching a contact list, with the refuting evidence already in hand and unexamined. The claim was false and, absent the independently-planned density check, would have propagated into a deposited model with ATP in the wrong pocket.
- alternative: Extract and print the residue sequence (one extra line), or probe the difference map at the ligand atoms before asserting the site. Distinguishing evidence: the model sequence shows 543-550 = GPPHSGKT (a genuine Walker-A motif) while 568-574 = CSPDKMI is not one; the ligand-blind apo mFo-DFc map showed 0/31 atoms above 3 sigma at the supplied pose.
- provenance: D1b

## 3. [major] Lattice-shifted the ATP by -1 in a.
- flagged_by: self_critique   ·   triage: keep   ·   The decision applied a pure lattice translation based on an unverified assumption that the ligand-protein contact was via the identity operator, and this failed to place the ligand next to its protein, indicating a likely incorrect symmetry treatment.
- at decision, knew: Computed fractional centroid (1.237, 0.237, 0.090). Whether the ligand-protein contact was via the identity operator or a rotation was not checked before the shift.
- concern: Acted on the untested assumption that contact implies adjacency in the ASU via the identity operator; the contact was actually via a rotation, so the shifted ligand still did not sit beside chain A (closest direct approach 10.4 Å). The shift did not achieve its stated goal.
- alternative: Apply the actual symmetry operator relating ATP to chain A, which would have put it adjacent to the protein in the ASU. Distinguishing evidence: per-atom displacement min == max == 116.097 Å (exactly the a vector), proving the operation was a pure lattice translation that changed no geometry but also did not relocate the ligand next to its protein.
- provenance: D2

## 4. [moderate] Added ordered_solvent=True to the holo refinements but initially ran no matched control.
- flagged_by: self+transcript_pass+self_critique   ·   3 vantages   ·   triage: keep   ·   Adding ordered solvent to holo without a matched apo+solvent control confounded the ligand effect with 158 waters, inflating the headline ΔR-free by roughly 2x.
- at decision, knew: At launch time, the holo refinements were given ordered_solvent=True but there was no matched apo+solvent control. The apparent R-free improvement (0.2881 -> 0.2282) confounded the ligand with 158 added waters.
- concern: The ligand effect and the 158 added waters were confounded in the R-free improvement; the matched control was an afterthought, not part of the design. Had the control not been run, the headline ligand evidence would have been inflated by roughly a factor of two (-6.0 pp vs corrected -2.8 pp).
- alternative: Launch the matched apo+solvent control at the same time as the holo refinements. Distinguishing evidence: the protocol-matched comparison gives ligand ΔR-free = -2.8 pp (0.2563 -> 0.2282), correcting the misleading uncorrected -6.0 pp figure.
- provenance: #163; D10
  - also flagged by both (#163): the holo runs added waters, so R-factors are not directly comparable to the earlier apo baseline without a matched control || AUDITOR: This decision conflates two separate steps: validating the new ligand placement and modeling the solvent. Adding waters can significantly lower R-factors, potentially masking subtle problems with the ligand fit. It also prevents a direct, apples-to-apples comparison with the previous apo refinement, which did not include waters. The agent correctly identifies this issue later (line 163) and runs a matched control, but the initial decision was procedurally impure. Best practice is to establish the correctness of the macromolecule/ligand model first, then add solvent in a final round.

## 5. [moderate] Generated a new 10% R-free set.
- flagged_by: self+self_critique   ·   2 vantages   ·   triage: keep   ·   Generating a fresh R-free set when the model was likely already refined against all reflections introduces unquantifiable R-free bias that a reader could over-trust, warranting expert note even though it was a forced move.
- at decision, knew: phenix.mtz.dump showed only H K L F SIGF columns; no free-flag column existed in any supplied file.
- concern: The protein has almost certainly already seen these reflections, so the reported R-free is biased low by an unquantifiable amount; a reader could over-trust R-free = 0.2282. Nothing model-independent can validate the choice or quantify the bias.
- alternative: Attempt to reconstruct the original free set (e.g. by testing whether some reflection subset shows anomalously high R against the supplied model), which in principle could recover it. Alternatives: no cross-validation (worse) or 5% (noisier). No distinguishing evidence can quantify the residual bias.
- provenance: #36; #214; D3
  - also flagged by self (#36): "the apo model was almost certainly already refined against all these data, so a new free set is not clean cross-validation for the protein — R-free will be biased low"
  - also flagged by self (#214): "R-free is biased low and I can't quantify by how much" because the MTZ had no free-R column and the protein was already refined against all the data

## 6. [moderate] The agent launched refinements of both the apo and holo models simultaneously.
- flagged_by: transcript_pass   ·   triage: keep   ·   Launching the holo refinement in parallel preempts the planned unbiased difference-map check for ligand density, risking model bias and wasted effort if the ligand isn't supported.
- at decision, knew: The agent had created two models: `apo.pdb` (protein only) and `holo.pdb` (protein + unfitted ligand). The stated plan was to refine the apo model first to generate clean difference maps for inspection.
- concern: This action contradicts the agent's own well-reasoned, sequential plan. The plan was to use the refined apo model's phases to generate the best possible difference map to check for ligand density. By starting the holo refinement at the same time, it preempts this check and proceeds as if the ligand placement was already trustworthy, even though no evidence supported that yet.
- alternative: Follow the original plan: run only the apo refinement to completion. Then, use its output map coefficients (`..._map_coeffs.mtz`) to generate and inspect the mFo-DFc map at the ligand site before proceeding.
- provenance: 49 52

## 7. [moderate] Did not reconcile the two tools; reported the Coot number (0) in the narrative while the validate_ligands table (2) stands in the log.
- flagged_by: self_critique   ·   triage: keep   ·   Two validation tools disagree on ligand clashes and the more favorable figure was surfaced while the unfavorable one was left unreconciled, which warrants expert review of the specific flagged contacts.
- at decision, knew: validate_ligands reports 2 ligand clashes; Coot reports 0 atom overlaps involving chain B. The two tools disagree.
- concern: An unexamined inconsistency between two validation tools on the ligand's contacts, with the more favorable number surfaced in the narrative and the less favorable one left in the log unreconciled.
- alternative: Investigate which contacts validate_ligands flags as clashes and why Coot does not (e.g. differing distance cutoffs or symmetry handling), and report a reconciled figure. Distinguishing evidence: examining the specific atom pairs flagged by validate_ligands versus Coot's overlap criteria.
- provenance: unreconciled (backward trace)

## 8. [minor] Chose fitA over fitB as the primary model.
- flagged_by: self_critique   ·   triage: keep   ·   The primary-model selection rests on a 0.0006 R-free and 0.09 sigma difference, both plainly within noise, so the stated criterion does not defensibly separate the poses.
- at decision, knew: fitA vs fitB: R-free 0.2282 vs 0.2288; minimum per-atom 2mFo-DFc 3.49 sigma vs 3.40 sigma. No formal real-space CC difference or F-test computed.
- concern: The selection was made on a 0.0006 R-free and 0.09 sigma difference, both within noise; the criterion is not defensible. Only the retention of both models is defensible.
- alternative: Acknowledge the two poses are statistically indistinguishable and rely solely on retaining both in DEPOSIT/alternate/ per the preserve-competing-models rule. Distinguishing evidence: none of the available metrics separate the poses at any meaningful significance.
- provenance: D9

## 9. [minor] Guessed PHIL parameter names rather than querying them, across two different programs.
- flagged_by: self_critique   ·   triage: keep   ·   A recurring, avoidable process inefficiency—repeatedly guessing PHIL names across two programs when introspection tools were readily available—warrants brief expert note though it did not compromise scientific validity.
- at decision, knew: Two failed phenix.ligandfit invocations on input_labels and two failed phenix.refine invocations on refinement.output.prefix, with phenix_get_phil / --show-defaults introspection tools available.
- concern: Four job failures from guessed parameter names cost ~40 min wall clock; the pattern recurred with two different programs despite introspection tools being available and unused. A recurring process weakness.
- alternative: Query phenix_get_phil or --show-defaults once per program before invocation to obtain correct parameter names. Distinguishing evidence: the correct PHIL names would have been returned directly, avoiding all four failures.
- provenance: process (D8 and preceding failed invocations)
