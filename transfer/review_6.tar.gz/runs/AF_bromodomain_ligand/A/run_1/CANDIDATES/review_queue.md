# Candidate review queue — AF_bromodomain_ligand (arm A)

5 distinct leads for expert review (ranked by severity, then cross-vantage agreement).

## 1. [major] Modeled only ONE GQX copy though the deposited file has two.
- flagged_by: self+transcript_pass+self_critique   ·   3 vantages   ·   triage: keep   ·   Absence of a second GQX copy was concluded from a bulk peak-list without a targeted polder/OMIT map at the deposited symmetry-mapped 2nd-site position, so the negative call is not airtight against deposited data.
- at decision, knew: Post-refine mFo-DFc peak search — max 6.84σ, all peaks water-sized and next to existing atoms; no ligand-shaped cluster for a 2nd site.
- concern: No polder/OMIT map was run at the deposited 2nd-copy location; agent worked in its own frame and never transformed the deposited 2nd copy in to test its density, so the 'absent' call is not airtight.
- alternative: Add a 2nd GQX at high B and test, or compute a targeted polder map at the symmetry-mapped deposited 2nd-site position; presence/absence of ligand density in that polder would distinguish real second copy from noise.
- provenance: #231; D9
  - also flagged by both (#231): deposited 2nd GQX copy and Mg are not resolvable in this data || AUDITOR: This is a major scientific conclusion made without visual inspection of the electron density maps. A 6.84σ peak is significant and should not be dismissed based on a peak list. Characterizing it as being 'next to existing side chains/waters' is insufficient; its shape, size, and specific location are critical. It could represent a key alternate conformation or a different entity entirely. This is an overly confident interpretation based on incomplete evidence.

## 2. [moderate] Accept the molecular replacement solution as correct and the space group hand as resolved.
- flagged_by: self+transcript_pass   ·   2 vantages   ·   triage: keep   ·   Declaring the enantiomorph hand 'resolved' from a single LLG value without comparing the two hands' scores is an unsupported confidence claim worth expert review.
- at decision, knew: The `phenix.predict_and_build` log reported a top Phaser solution with LLG = 1188.
- concern: While a very high LLG is a strong indicator of success, it is not sufficient evidence on its own. The agent did not report the Z-score (a more robust indicator than raw LLG) or, crucially, the score of the next-best solution or the score for the alternative hand. Declaring the solution 'decisive' and the hand 'resolved' requires comparing the best solution to the alternatives. This was a confident assertion based on a single number.
- alternative: Inspect the full Phaser output within the log. Report the TF Z-score for the top solution. Most importantly, find the scores for both P 31 2 1 and P 32 2 1 and confirm that the top solution is significantly better (e.g., >100 LLG points and several sigma in Z-score) than the best solution in the other hand.
- provenance: #52; 92-92
  - also flagged by self (#52): enantiomorph fork needs to be resolved rather than assumed

## 3. [moderate] Defer to MolProbity for authoritative angle RMSD rather than trusting the refine-log value
- flagged_by: both   ·   2 vantages   ·   triage: keep   ·   Deferring to MolProbity for authoritative angle RMSD is a reasonable cross-check, but the run shows an angle RMSD of 2.0° that warrants attention to geometry/weighting.
- at decision, knew: refine log: Bond RMSD 0.015 Å, angle RMSD printed as 2.0°
- concern: refine-log angle RMSD of 2.0° looks high / may be unreliable || AUDITOR: The agent completely ignored the gap between R-work and R-free, which is 0.051. A gap this large (> 0.04-0.05) is often a sign of overfitting the model to the data. The agent should have noticed this and considered if the model was too complex (e.g., too many water molecules) or if the refinement restraints were inappropriate. Focusing only on the geometry and ignoring the R-free gap is a significant omission.
- alternative: Acknowledge the large R-work/R-free gap. Re-evaluate the model for signs of over-parameterization. One could try refining with different X-ray/geometry weighting, or re-running automated water picking with a stricter sigma cutoff to see if the gap improves.
- provenance: #276

## 4. [moderate] Did not model the Mg ion despite the deposited entry containing one.
- flagged_by: self_critique   ·   triage: keep   ·   Omitting a deposited Mg based solely on difference-peak geometry without ion-picking or nearest-water coordination checks is a defensible but under-tested call worth expert review.
- at decision, knew: No octahedral water cluster or short (≈2.1 Å) coordination peak in mFo-DFc; residual peaks 5–6.8σ sit on side chains/waters; deposited Mg–O LINK is 2.48 Å (long/loose).
- concern: The call rests on difference-peak geometry alone; Phenix ion-picking (ordered_solvent with elemental-ion picking) was never enabled, and coordination geometry of the nearest waters was not checked. Self-described as the weakest evidence-based call in the run.
- alternative: Place Mg and test with anomalous-free coordination plus B/occupancy behavior, or run phenix.refine ordered_solvent with elemental-ion picking to let Phenix propose Mg; coordination geometry of the two waters nearest the strongest peak would distinguish ion vs water.
- provenance: D10

## 5. [moderate] Stopped refinement at R-free 0.257 rather than pushing lower.
- flagged_by: self_critique   ·   triage: keep   ·   Standard R-free-lowering options (TLS, riding H, weight scan) were never tried, so the overfitting justification for stopping at 0.257 is untested and possibly premature.
- at decision, knew: Geometry pristine (MolProbity 1.03); R-Rfree gap 5.3% normal for 2.1 Å; TLS groups, resolution-dependent wxc_scale scan, and riding H not consulted.
- concern: R-free 0.257 is somewhat higher than typical for 2.1 Å, and standard refinement options (TLS, riding H, target-weight scan) that could legitimately lower R-free were never tried.
- alternative: Add TLS groups, riding hydrogens, and/or run a wxc_scale scan; a drop in R-free without geometry degradation would show the stop was premature, while no improvement would confirm the call.
- provenance: D12
