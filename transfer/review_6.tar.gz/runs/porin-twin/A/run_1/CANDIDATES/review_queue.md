# Candidate review queue — porin-twin (arm A)

6 distinct leads for expert review (ranked by severity, then cross-vantage agreement).

## 1. [major] Treat phenix.refine twinned R-factors as correct; interpret MolProbity R as untwinned-target R, not comparable
- flagged_by: self   ·   triage: keep   ·   The large gap between twinned R (0.13) and untwinned R (0.23) is a known twinning artifact but the decision to trust the very low twin R risks masking overfitting to the twin law, warranting expert review.
- at decision, knew: MolProbity summary reporting R-work/R-free 0.229/0.249 (untwinned target) vs phenix.refine twin R 0.1317/0.1585
- concern: Risk of misreading MolProbity's higher R-factors as the model's true R; twinned vs untwinned R not directly comparable
- alternative: 
- provenance: #135

## 2. [moderate] Added 165 ordered waters via ordered_solvent=True, accepting phenix's default automatic water-picking filters.
- flagged_by: transcript_pass+self_critique   ·   2 vantages   ·   triage: keep   ·   With acknowledged twinned data increasing model bias, 165 waters were added on aggregate metrics alone without independent per-water density validation, risking placement into biased density.
- at decision, knew: 2.25 A resolution, R-free 0.183, start model had zero solvent; solvent standard at this resolution. Relied on phenix's 2mFo-DFc/mFo-DFc + CC filters at default thresholds. Aware that twinned data maps carry more model bias.
- concern: With twinned data, maps carry more model bias, so a subset of waters may have been placed into biased density. Individual water validity was not independently confirmed; no per-water difference-density inspection was done.
- alternative: Perform a manual per-water audit inspecting each water's difference density and H-bonding, or use OMIT/difference maps to confirm placement independent of model bias; distinguishing evidence would be per-water density and H-bond geometry rather than aggregate R/clashscore metrics.
- provenance: 122 125; D5
  - also flagged by transcript_pass (122 125): Relying solely on the improvement in the global R-free statistic to validate the addition of a large number of solvent molecules is insufficient. At 2.25 Å resolution, electron density for solvent can be ambiguous. A competent crystallographer would manually inspect each added water molecule in Coot to ensure it sits in convincing 2mFo-DFc density, has no significant mFo-DFc difference density, and participates in a plausible hydrogen-bonding network. Accepting them all without a visual check risks incorporating unsupported atoms into the model.

## 3. [moderate] Treat this as a merohedral-twinning candidate; note it's a starting model
- flagged_by: self   ·   triage: keep   ·   R3 is not a merohedral-twinning space group (it permits pseudo-merohedral/hemihedral scenarios only under specific conditions), so the stated rationale is crystallographically questionable and worth expert check.
- at decision, knew: PDB header: space group R3 (:H), cell 104.4/104.4/124.25, single chain, uniform B=20
- concern: Implicit suspicion of twinning to be verified; noted uniform B indicates a starting model
- alternative: 
- provenance: #12

## 4. [moderate] Verify no waters were lost; conclude the '204' was a mid-run count and Coot preserved everything
- flagged_by: self   ·   triage: keep   ·   The conclusion that '204' was a mid-run count is asserted without documented cross-check of both files' water counts against a specific provenance, so a 39-water discrepancy warrants expert confirmation.
- at decision, knew: Coot-written file has 165 waters vs previously stated 204; round-2 PDB also has 165 waters
- concern: Apparent loss of waters (204→165) that could indicate Coot dropped atoms
- alternative: 
- provenance: #155-#158

## 5. [moderate] Made Coot rotamer fixes with a density-guarded accept/revert protocol using the refined 2mFo-DFc map; left two ambiguous side chains unforced.
- flagged_by: self_critique   ·   triage: keep   ·   Using the model-biased 2mFo-DFc map for accept/revert decisions in a twinned dataset genuinely undercuts independent verification of the kept rotamers, warranting expert review.
- at decision, knew: MolProbity rotamer outliers at 2.30%; per-residue all-atom map correlation computed before/after with revert-if-correlation-dropped >0.02 rule. Used the refined 2mFo-DFc map directly; did not compute OMIT/composite-omit maps.
- concern: Accept/revert relied on the model-derived, bias-carrying twin map rather than an OMIT map, so the four 'kept' rotamers are only weakly independently verified against twin-map bias.
- alternative: Compute OMIT or composite-omit maps at each rotamer site before fitting to reduce twin-map model bias; distinguishing evidence would be per-site OMIT-map density confirming the fitted rotamer independent of the current model.
- provenance: D6

## 6. [moderate] Accepted the final refined model with the wider-than-typical R-free gap, attributing it partly to intrinsic twin-target R scaling and partly to solvent/rotamer decisions.
- flagged_by: self_critique   ·   triage: keep   ·   The wider-than-typical R-free gap plausibly reflects over-fitting of solvent/rotamers into bias-carrying twin maps, and the intrinsic twin-scale contribution cannot be disentangled without the proposed cross-validated checks.
- at decision, knew: Residual R-work/R-free gap ~0.029 (0.129/0.158), larger than the ~0.01-0.02 typical at 2.25 A. Aware of modest data count with 9.16% free set and that twin-target refinement alters the R scale.
- concern: The wide gap may indicate mild over-fitting originating in D5 (solvent added into biased density) and D6 (rotamers fit on non-OMIT map); intrinsic twin scaling cannot fully be disentangled from over-fitting without further checks.
- alternative: Test whether removing questionable waters or refitting rotamers on OMIT maps narrows the gap; a cross-validated comparison (e.g., paired-refinement or resolution-cut) would distinguish intrinsic twin-scale contribution from genuine over-fitting.
- provenance: Backward trace (R-free gap)
