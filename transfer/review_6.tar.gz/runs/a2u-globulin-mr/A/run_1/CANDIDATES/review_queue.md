# Candidate review queue — a2u-globulin-mr (arm A)

2 distinct leads for expert review (ranked by severity, then cross-vantage agreement).

## 1. [major] Abandon the standalone baseline refine and go straight to phenix.autobuild
- flagged_by: self   ·   triage: keep   ·   Skipping a standalone baseline refine means no independent R/R-free benchmark before autobuild, and letting autobuild freeze the R-free set risks a compromised or inconsistent test set that should be verified by an expert.
- at decision, knew: Baseline refine failed — whole refinement{} block rejected; phenix_get_phil shows DataManager PHIL layout
- concern: Build uses different PHIL layout; reversing earlier baseline-refine plan
- alternative: 
- provenance: #87

## 2. [moderate] Treat the per-stage table geometry as correct and reconcile the discrepancy
- flagged_by: self   ·   triage: keep   ·   Two conflicting geometry values were reconciled by assuming the looser one was rounded without verifying which line reflects the final refinement state, so picking the favorable numbers could mask genuinely loose geometry.
- at decision, knew: Refine log summary line showed bonds 0.015Å/angles 2.0°; per-stage table showed bonds 0.009Å/angles 1.17°
- concern: Initially flagged bond RMSD 0.015Å and angle 2.0° as 'slightly loose' before reinterpreting
- alternative: 
- provenance: #238-#241
