# Candidate review queue — refined_start (arm A)

10 distinct leads for expert review (ranked by severity, then cross-vantage agreement).

## 1. [major] Relied on a string-pattern grep to make and then verify the Se-removal edit.
- flagged_by: self+self_critique   ·   2 vantages   ·   triage: keep   ·   Using the same flawed grep pattern for both edit and verification creates a circular check that cannot detect a silent no-op, risking shipment of uncleaned Se-containing models.
- at decision, knew: First Se-removal edit used a grep pattern with a spacing mismatch; the verification grep used the same bad pattern, so both read '0'.
- concern: The edit silently failed and would have shipped Se-containing 'cleaned' models; only an independent atom-count check (696 unchanged; candidate outputs still had 4 Se) exposed it.
- alternative: Verify edits by element/atom count rather than by the same string pattern used to make the edit; the atom-count check distinguishes a real edit from a no-op.
- provenance: #265; D6
  - also flagged by self (#265): Unexpected Se count of 4 in models that should have had Se removed

## 2. [major] Diagnose the divergence before trusting the result
- flagged_by: self   ·   triage: keep   ·   R-free ended worse than baseline (0.2531 vs 0.2417) with a large R-work/R-free gap (~0.058) and a mid-run dip, indicating possible overfitting or divergence that warrants diagnosis before trusting the result.
- at decision, knew: refine1 final stats: r_work=0.1950 r_free=0.2531 (mid-run dipped to ~0.224); baseline was 0.2417
- concern: R-free worse than baseline despite mid-run dip — a divergence not yet understood
- alternative: 
- provenance: #61

## 3. [major] From original model, add TLS, tighten xyz weight (wxc_scale=0.3), keep ordered_solvent
- flagged_by: self   ·   triage: keep   ·   A 0.10 R-work/R-free gap at 2.59 Å signals overfitting, and the decision's own diagnostics (xyzrec steps raise R-free) support the over-parameterization concern warranting expert review.
- at decision, knew: refine2 stats: R-work 0.1466, R-free 0.2465, 0.10 R-Rfree gap, bonds RMSD 0.010; _sol steps lower R-free, _xyzrec steps raise it
- concern: "at 2.59 Å (~4 obs/atom) individual x,y,z + individual B is over-parameterized"; even default weighting overfits
- alternative: 
- provenance: #79-#80

## 4. [major] Judge Se atoms as likely spurious; plan to validate each against density in Coot
- flagged_by: self   ·   triage: keep   ·   Four Se atoms with only one possible Met site (Met77), high B and partial occupancy, and no anomalous data strongly suggests spurious substructure peaks warranting expert review.
- at decision, knew: Se atoms refine to high B (34-92), occ 0.25-0.64; sequence has only 2 Met (pos 1, 77); chain modeled 2-85 so only Met77 present; no anomalous data
- concern: "There's no anomalous data here to confirm them"
- alternative: 
- provenance: #88-#89

## 5. [major] Re-remove chain Z robustly via awk and confirm count drops by exactly 4
- flagged_by: self   ·   triage: keep   ·   A silent grep failure meant Se was never removed, so prior refinements were done on the wrong model, invalidating those candidates.
- at decision, knew: model_noSe.pdb still had 696 lines (unchanged), still contained all 4 Se; grep pattern didn't match column spacing
- concern: "This is exactly the kind of silent mistake to catch" — earlier candidates invalid because Se not actually removed
- alternative: 
- provenance: #268-#269

## 6. [major] Reject all refinement variants; deposit baseline with 4 Se removed via bulk-solvent/scaling-only pass (0 macrocycles)
- flagged_by: self   ·   triage: keep   ·   Deciding that all reciprocal-space refinement worsens the model and depositing coordinates with 0 macrocycles after removing atoms is an unusual, non-standard choice that warrants expert scrutiny.
- at decision, knew: Candidate A MolProbity: clashscore 0.75→4.53, MolProbity 1.55→1.94, 3 rotamer outliers remaining; pattern across six refinements
- concern: "reciprocal-space refinement cannot improve on the baseline here — it either overfits R-work or introduces clashes"; rotamer outliers need Coot which is unavailable
- alternative: 
- provenance: #280-#281

## 7. [moderate] Did not force rotamer fixes in reciprocal space; left the 4 rotamer outliers unresolved.
- flagged_by: self+self_critique   ·   2 vantages   ·   triage: keep   ·   Four rotamer outliers remain unresolved because the intended real-space fix via Coot was blocked by a tool outage, making the decision reasonable but leaving verifiable unfinished business worth expert review.
- at decision, knew: Candidate A (gentle refine) fixed only 1/4 rotamers and raised clashscore 0.75->4.5; 4 rotamer outliers remain at A20/A45/A53/A84. Coot was unavailable (~15 min down; MCP returned 'Failed to get __main__ module').
- concern: The 4 rotamer outliers are the clearest unfinished business — the intended Coot rebuild never ran, so they remain unresolved and unverifiable in this run.
- alternative: Real-space rotamer fitting plus local refine that does not add clashes (requires Coot); distinguished by molprobity rotamer/clashscore after real-space fit.
- provenance: #253-#257; Backward trace — rotamers (relates to D4)
  - also flagged by self (#253-#257): "Coot never recovered within the 15-minute retry window" — interactive rebuild unavailable, marked explicitly as not completed

## 8. [moderate] Adopt plan preserving existing R-free set (generate=False), keep Se initially, refine with weight optimization + ordered_solvent
- flagged_by: self   ·   triage: keep   ·   Preserving R-free set is correct, but retaining 4 free Se atoms (occ 0.19-0.45) in a non-anomalous dataset with only 2 Met in sequence warrants expert review of the Se identity/placement rationale.
- at decision, knew: Baseline audit from model_vs_data.log and PDB header (R=0.1975/Rfree=0.2417 @2.59Å); mtz columns (FP/SIGFP + R-free-flags, non-anomalous); model composition (chain A 2-85, 36 HOH, 4 free Se occ 0.19-0.45); sequence with 2 Met
- concern: "Forks I'll auto-resolve with the recommended call ... Se identity/retention, TLS on/off, water updates. I'll log each with its basis."
- alternative: 
- provenance: #28

## 9. [moderate] Ran first refinement using optimize_xyz_weight/adp with ordered_solvent for 5 cycles.
- flagged_by: self_critique   ·   triage: keep   ·   Applying an aggressive polish protocol before characterizing the baseline risks overfitting a low-data model, a plausible methodological misstep worth expert review.
- at decision, knew: Standard 'best-shot' polish protocol chosen; had not yet run model_vs_data or molprobity on the baseline, so did not yet know the model was already reciprocal-space converged (~4 obs/atom).
- concern: An aggressive protocol was applied before characterizing an already-converged model; the per-stage R-free table showed 3_xyzrec drove R-free 0.2284->0.2529 while R-work fell — clear overfit.
- alternative: Run model_vs_data / molprobity on the baseline FIRST to learn it was converged, or use a conservative low-weight refine; distinguished by the per-stage R-free table.
- provenance: D1

## 10. [moderate] Removed the 4 free Se atoms (chain Z).
- flagged_by: self_critique   ·   triage: keep   ·   Removing 4 free Se atoms was justified by convergent evidence (unbonded, weak density, high B, no anomalous, only 2 Met), but the identity call relied on model-biased maps without an independent omit/polder test.
- at decision, knew: 4 free Se in chain Z not bonded (34-74 A from protein); 2mFo-DFc only 1.6-2.0 sigma with mFo-DFc ~0/neg; refined B up to 92; no anomalous data; only 2 Met in sequence. Anomalous/original SAD data genuinely unavailable in data.mtz.
- concern: Identity call on a heteroatom rested on model-biased 2mFo-DFc map sampling; a polder/omit map would have been a stronger independent test but was not run.
- alternative: Keep as Se or remodel as water/ion; distinguished by an anomalous difference map (absent here) or an omit-map density check around each Se.
- provenance: D3; Backward trace — MSE77
  - also flagged by self_critique (Backward trace — MSE77): Truncated selenomethionine side chain left incomplete and never tested against density (no omit map run).
