# Candidate review queue — gene-5-mad (arm A)

12 distinct leads for expert review (ranked by severity, then cross-vantage agreement).

## 1. [major] Verify whether the Coot fixes reached the file
- flagged_by: self+transcript_pass   ·   2 vantages   ·   triage: keep   ·   Identical rotamer outlier percentage after a refinement that should have changed it is a legitimate signal that edits failed to persist, warranting verification of whether Coot fixes reached the file.
- at decision, knew: B-only refine result: rotamer outliers still 12.16%, R nearly unchanged (0.1322→0.1336)
- concern: Suspected its own Coot fixes never persisted to disk || AUDITOR: The `restore_to_backup_checkpoint` function in Coot scripting is notoriously fragile and a common source of bugs. As the agent later discovered, its use led to a state where earlier accepted fixes were silently undone by a later restore operation, causing the entire step to fail. An experienced Coot scripter would likely have anticipated this and used a more robust method for state management.
- alternative: A more robust script would not use checkpoints. It could either save the coordinates of a residue before modification and restore them explicitly if the change is rejected, or simply not apply the change until it has been vetted. The safest method is to save the entire model to a new file after each accepted change, which the agent's second script did.
- provenance: #334; #337
  - also flagged by self (#337): Named the checkpoint-index instability as the cause of losing its own edits

## 2. [major] Used `restore_to_backup_checkpoint` for revert logic in Coot.
- flagged_by: self_critique   ·   triage: keep   ·   A tool reporting 4 residues 'FIXED' while writing a byte-identical file is a silent-failure pattern that corrupts outlier counts and warrants expert review of the revert/verification mechanism.
- at decision, knew: Coot skill documents checkpoints as the backtracking mechanism; a rotamer pass reported 4 residues 'FIXED' and wrote an output file; a manual coordinate diff against the input file was performed.
- concern: The checkpoint-revert silently failed: a rotamer pass reported 4 residues 'FIXED' but wrote a file byte-identical to its input. It was caught only because the coordinates were diffed against the input; had that not happened, four nonexistent rotamer fixes would have been reported and the outlier count would have been wrong.
- alternative: Verify every tool-reported 'success' against the artifact on disk (diff coordinates after every pass, not just suspicious ones); distinguishing evidence would be a byte-level or coordinate-level comparison showing whether the file actually changed.
- provenance: D16

## 3. [major] Kept SE Z/2 and assigned it as the Met1 selenium.
- flagged_by: self_critique   ·   triage: keep   ·   The Se identity rests solely on an elimination argument with no positive test, and a buffer-derived anomalous scatterer cannot be excluded absent a recipe, plus the 5.50 Å distance from Ile2 N is geometrically odd for a Met1 side chain.
- at decision, knew: 5.98 σ anomalous peak at the site; 5.50 Å from Ile2 N; no clashes; both sequence Met otherwise accounted for; no crystallization recipe available.
- concern: The identity rests on an elimination argument, not a positive test; a heavier ion from the crystallization buffer would also scatter anomalously and cannot be excluded without a recipe. It is a modelled atom with an asserted chemical identity resting on inference — the least-verified claim in the deposited model.
- alternative: Build the Met1 backbone and/or run a polder/OMIT map around the site, or examine occupancy-vs-B behaviour for different element assignments, which would discriminate identity better than the elimination argument used.
- provenance: D12

## 4. [major] Initially claimed the 3 free Se atoms were chemically impossible artifacts.
- flagged_by: self_critique   ·   triage: keep   ·   Asserting chemical impossibility from an ASU-only neighbour search omits the elementary symmetry-mate check, and acting on it risks deleting a genuine anomalous Se peak.
- at decision, knew: All three free Se atoms had no neighbours within 6 Å in the asymmetric unit; Se in a Se-Met crystal exists only covalently in selenomethionine. Crystallographic symmetry was NOT consulted at decision time.
- concern: The neighbour search was ASU-only; symmetry mates are the first thing to check for an isolated atom. A symmetry-aware search and `mmtbx.refine_anomalous_substructure` (Z/4 at 22.45 σ, stronger than the real Met77 Se) flatly contradicted the hypothesis. Acting on the chemistry argument alone would have deleted a real Met77-related peak and kept a mis-built side chain.
- alternative: Run a symmetry-aware neighbour search and an anomalous substructure check before asserting impossibility; the symmetry search and anomalous peak heights immediately overturned the conclusion.
- provenance: D7

## 5. [moderate] Judged 3 sites real (occ≥0.5), declared hand unambiguous, proceeded to AutoBuild
- flagged_by: both   ·   2 vantages   ·   triage: keep   ·   Sequence has 2 Met + 1 Cys, so 3 significant sites (Met1, Met77, plus Cys or ordered Se-Cys) is actually consistent with expectation, but the agent's rationale misframes this and the strong BAYES-CC hand discrimination plus reasonable occupancies make proceeding defensible while a brief check would add confidence.
- at decision, knew: AutoSol summary: 6 sites found, occupancies 1.00/0.56/0.52/0.22/0.21/0.14; BAYES-CC 44–48 vs inverse 14; sequence 2 Met + 1 Cys
- concern: Uncertainty over which of the 6 sites are genuine Se vs completion artifacts || AUDITOR: The agent correctly dismisses the three weakest sites but does not address the discrepancy between the 2 expected sites and the 3 found sites with significant occupancy. The presence of an unexpected third site is a red flag that warrants investigation before proceeding. It could be a strong noise peak that is confusing phasing, or a real non-covalently bound atom. Proceeding without checking its location or nature is a risk.
- alternative: The agent should have paused to investigate the 3-site substructure. Alternatives include: loading the sites PDB file and experimental map into Coot to visually inspect the peaks, checking if the two strongest sites are near Met1 and Met77, and evaluating the chemical environment of the third site. This would provide more confidence before starting a long build step.
- provenance: #102

## 6. [moderate] Abandon Coot approach; use targeted phenix.refine on residue 77 only
- flagged_by: self   ·   triage: keep   ·   A single-residue targeted refinement to fix persistent Cβ deviation while correlation dropped is a reasonable but non-trivial strategy worth confirming it doesn't mask a deeper model error.
- at decision, knew: v6 cbetadev still 1 deviation; rotamer held 2.92% but correlation dropped 0.739→0.726
- concern: Coot could not relieve the Cβ strain and lowered correlation; chose narrow refinement to avoid disturbing other rotamers
- alternative: 
- provenance: #373-#374

## 7. [moderate] Ran AutoSol with sites=2, thoroughness=thorough, defaults elsewhere; did not set an explicit res_hyss substructure-search resolution.
- flagged_by: self_critique   ·   triage: keep   ·   xtriage explicitly provided a resolution cutoff for HySS and it was not applied, a defensible-but-questionable choice that could yield a noisier substructure worth expert review.
- at decision, knew: Sequence has exactly 2 Met; 87 residues; Vm indicated 1 copy; xtriage explicitly stated anomalous signal extends to ~3.1 Å and could guide the HySS resolution cutoff.
- concern: xtriage handed the exact parameter to set (3.1 Å cutoff) and it was ignored; AutoSol found 6 sites where 2 were expected, 3 carried into the model and 2 later deleted — direct evidence the substructure was noisier than necessary. The downstream Se confusion (including the D12 identity ambiguity) traces back here.
- alternative: Set an explicit 3.1 Å HySS cutoff per xtriage guidance, which might have produced a cleaner substructure with fewer spurious low-occupancy sites; distinguishing evidence would be the number and occupancy of resulting sites.
- provenance: D3

## 8. [moderate] Fixed rotamers in Coot, then refined B-factors/occupancies only (no reciprocal-space coordinate refinement except residue 77).
- flagged_by: self_critique   ·   triage: keep   ·   Ending the refinement with manual Coot coordinate placement plus B/occ-only refinement leaves final coordinates not optimized against structure factors, with an 8.1% R-gap and 6.76% rotamer outliers unresolved, warranting expert review.
- at decision, knew: Three prior rounds showed phenix.refine coordinate refinement re-breaking rotamers (no rotamer restraints in reciprocal-space refinement); R-free moved 0.2194 → 0.2180 across the fix-then-B/occ-only change.
- concern: The deposited coordinates were last optimized against the map in Coot, not against structure factors — an unusual endgame. The R-work/R-free gap (8.1 %) and rotamer outliers (6.76 %) were both left unresolved; a reviewer may object that final coordinates were not refined against the data in reciprocal space.
- alternative: Use phenix.real_space_refine with rotamers.restraints.enabled=True, or AQuaRef, which might fix rotamers and allow coordinate refinement against the data simultaneously; distinguishing evidence would be whether the R-gap narrows and outliers drop while coordinates stay refined.
- provenance: D17

## 9. [moderate] Left Gln12 fully modelled.
- flagged_by: self_critique   ·   triage: keep   ·   An incoherent density pattern (strong OE1, absent CG) with an untested cheap water hypothesis and unresolved modeling warrants expert review.
- at decision, knew: Gln12 OE1 has 2.12 σ density while CG has −0.02 σ — an incoherent pattern; a 180° amide flip did not improve it. Whether the 2.12 σ at OE1 is actually a water was never tested.
- concern: Inconsistent with D13 (where weak side-chain atoms were zeroed), and the cheap-to-test hypothesis that the 2.12 σ OE1 density is actually a water was never checked.
- alternative: Test whether the OE1 density is an ordered water (e.g. place a water and re-refine, or examine the difference map); distinguishing evidence would be improved fit and coherent density interpretation.
- provenance: D14

## 10. [moderate] Treated the case as SAD using only peak.sca, and did not tell the user that MAD was possible.
- flagged_by: self_critique   ·   triage: keep   ·   SAD phasing succeeded, but the assistant should have informed the user that two additional wavelengths were present enabling a potentially stronger MAD experiment.
- at decision, knew: Only peak.sca (single wavelength) named in the prompt; high.sca and infl.sca present in the source directory; xtriage anomalous measurability 0.367 max, signal to 3.1 Å; DM FOM reached 0.73.
- concern: Two further wavelengths existed that would probably have produced a better substructure and phases; the user was never informed that a genuinely stronger MAD experiment was available.
- alternative: Inform the user that high.sca and infl.sca were available and run/offer a 3-wavelength MAD experiment; distinguishing evidence would be improved substructure quality and phasing statistics from MAD.
- provenance: D1

## 11. [minor] Trust cbetadev output over the log block value; run definitive MolProbity
- flagged_by: self   ·   triage: keep   ·   The decision to reconcile the discrepancy by running definitive MolProbity is reasonable, but the assumption that the log block reflects the input model rather than the output warrants a quick expert sanity check.
- at decision, knew: refine_5afd62b8 log: R-work 0.1364/R-free 0.2179, cbetadev output 0 deviations, but log block shows 1.30%
- concern: Discrepancy between log-reported Cβ statistic and independent cbetadev run
- alternative: 
- provenance: #381

## 12. [minor] Set occupancy 0 on distal atoms of Arg21 and Lys24.
- flagged_by: self_critique   ·   triage: keep   ·   Zeroing occupancy on distal atoms in weak/negative density is defensible, but the inconsistent treatment versus Gln12 and the misunderstanding about zero-occupancy atoms still counting in rotamer stats warrant a quick expert check.
- at decision, knew: 2Fo-Fc 0.39–0.65 σ with negative Fo-Fc on distal atoms of Arg21 and Lys24; did not check whether zero-occupancy atoms still count in MolProbity rotamer statistics (they do).
- concern: Inconsistent policy: Arg21/Lys24 distal atoms were zeroed but Gln12 (CG at −0.02 σ) was left fully modelled — the inconsistency is not principled. The move also did not help the validation metric it might have been expected to, since zero-occupancy atoms still count in MolProbity rotamer stats.
- alternative: Apply a consistent policy across weak side chains (either zero, truncate, or leave at high B uniformly); distinguishing evidence would be per-atom density probes applied identically to Gln12 and the zeroed residues.
- provenance: D13
