# Table 1 — per-run summary

_Numbers are **as reported by each run's own tools** unless marked independent. Each value carries its source, because validators disagree (a recurring finding of this project). Rows are not comparable across cases — different resolutions, methods and data types — this is a per-run report card, not a leaderboard._

| metric | AF_7mjs_H_PredictAndBuild | AF_7mjs_H_PredictAndBuild | AF_7mjs_H_PredictAndBuild | AF_7mjs_H_PredictAndBuild | AF_7mjs_H_PredictAndBuild | AF_bromodomain_ligand | AF_bromodomain_ligand | AF_bromodomain_ligand | AF_bromodomain_ligand | AF_bromodomain_ligand | CASP7-T0283-mr | CASP7-T0283-mr | CASP7-T0283-mr | CASP7-T0283-mr | CASP7-T0283-mr | a2u-globulin-mr | a2u-globulin-mr | a2u-globulin-mr | a2u-globulin-mr | a2u-globulin-mr | beta-blip | beta-blip | beta-blip | beta-blip | beta-blip | esterase_tNCS | esterase_tNCS | esterase_tNCS | esterase_tNCS | esterase_tNCS | gene-5-mad | gene-5-mad | gene-5-mad | gene-5-mad | gene-5-mad | nsf-d2-ligand | nsf-d2-ligand | nsf-d2-ligand | nsf-d2-ligand | nsf-d2-ligand | p9-sad | p9-sad | p9-sad | p9-sad | p9-sad | porin-twin | porin-twin | porin-twin | porin-twin | porin-twin | refined_start | refined_start | refined_start | refined_start | refined_start |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Resolution | — | — | — | — | — | 2 | — | — | — | — | 2 | — | — | — | — | 2 | — | — | — | — | 3 | — | — | — | — | 2 | — | — | — | — | 3 | — | — | — | — | 2 | — | — | — | — | — | — | — | — | — | 2 | — | — | — | — | 3 | — | — | — | — |
| Space group | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | C 1 2 1 | — | — | — | — | P6 without further testing | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — |
| R-work | — | — | — | — | — | 0.2045 | — | — | — | — | 0.3229 | — | — | — | — | 0.1932 | — | — | — | — | 0.2322 | — | — | — | — | 0.1794 | — | — | — | — | 0.1387 | — | — | — | — | 0.262 | — | — | — | — | — | — | — | — | — | 0.1317 | — | — | — | — | 0.195 | — | — | — | — |
| R-free | — | — | — | — | — | 0.2555 | — | — | — | — | 0.3346 | — | — | — | — | 0.2528 | — | — | — | — | 0.3098 | — | — | — | — | 0.2086 | — | — | — | — | 0.2297 | — | — | — | — | 0.302 | — | — | — | — | — | — | — | — | — | 0.1585 | — | — | — | — | 0.2525 | — | — | — | — |
| R-work (MolProbity) | — | — | — | — | — | 0.2045 | — | — | — | — | 0.4632 | — | — | — | — | 0.1967 | — | — | — | — | 0.2371 | — | — | — | — | 0.1716 | — | — | — | — | 0.1366 | — | — | — | — | 0.1963 | — | — | — | — | 0.231 | — | — | — | — | 0.2286 | — | — | — | — | 0.1553 | — | — | — | — |
| R-free (MolProbity) | — | — | — | — | — | 0.2573 | — | — | — | — | 0.475 | — | — | — | — | 0.2563 | — | — | — | — | 0.3094 | — | — | — | — | 0.205 | — | — | — | — | 0.218 | — | — | — | — | 0.2282 | — | — | — | — | 0.2462 | — | — | — | — | 0.2489 | — | — | — | — | 0.2475 | — | — | — | — |
| R-free (recomputed, independent) | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | 0.2417 | — | — | — | — |
| R-free (deposited) | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | 0.2 | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — |
| MolProbity score | 1.78 | — | — | — | — | 1.03 | — | — | — | — | — | — | — | — | — | 2.24 | — | — | — | — | 2.85 | — | — | — | — | 1.6 | — | — | — | — | 1.82 | — | — | — | — | 0.95 | — | — | — | — | 1.25 | — | — | — | — | 1.88 | — | — | — | — | 1.95 | — | — | — | — |
| Clashscore | 8.07 | — | — | — | — | 2.44 | — | — | — | — | 9.22 | — | — | — | — | 9.21 | — | — | — | — | 11.91 | — | — | — | — | 6.81 | — | — | — | — | 3.05 | — | — | — | — | 1.82 | — | — | — | — | 4.81 | — | — | — | — | 5.31 | — | — | — | — | 6.79 | — | — | — | — |
| Ramachandran favored % | 99.22 | — | — | — | — | 100 | — | — | — | — | 98.13 | — | — | — | — | 95.34 | — | — | — | — | 93.4 | — | — | — | — | 96.54 | — | — | — | — | 97.56 | — | — | — | — | 97.96 | — | — | — | — | 99.11 | — | — | — | — | 95.47 | — | — | — | — | 96.34 | — | — | — | — |
| Ramachandran outliers % | 0.78 | — | — | — | — | 0 | — | — | — | — | — | — | — | — | — | 0 | — | — | — | — | 0 | — | — | — | — | 0.8 | — | — | — | — | 0 | — | — | — | — | 0 | — | — | — | — | 0 | — | — | — | — | 0.35 | — | — | — | — | 0 | — | — | — | — |
| Rotamer outliers % (MolProbity) | 2.83 | — | — | — | — | 0 | — | — | — | — | — | — | — | — | — | 3.65 | — | — | — | — | 12.24 | — | — | — | — | 0.68 | — | — | — | — | 6.76 | — | — | — | — | 0 | — | — | — | — | 0 | — | — | — | — | 2.3 | — | — | — | — | 2.74 | — | — | — | — |
| Rotamer outliers % (refine log) | 2.83 | — | — | — | — | 2.25 | — | — | — | — | 1.11 | — | — | — | — | 0 | — | — | — | — | 1.46 | — | — | — | — | 0 | — | — | — | — | 12.16 | — | — | — | — | 2.3 | — | — | — | — | 0 | — | — | — | — | 3.23 | — | — | — | — | 5.48 | — | — | — | — |
| Cβ deviations | 0 | — | — | — | — | 0 | — | — | — | — | 0 | — | — | — | — | 0 | — | — | — | — | 0 | — | — | — | — | 0 | — | — | — | — | 0 | — | — | — | — | 0 | — | — | — | — | 0 | — | — | — | — | 0 | — | — | — | — | 0 | — | — | — | — |
| RMS bonds | 0.0024 | — | — | — | — | 0.0069 | — | — | — | — | 0.018 | — | — | — | — | 0.0091 | — | — | — | — | 0.0094 | — | — | — | — | 0.0184 | — | — | — | — | 0.0105 | — | — | — | — | 0.0085 | — | — | — | — | 0.0074 | — | — | — | — | 0.0087 | — | — | — | — | 0.0079 | — | — | — | — |
| RMS angles | 0.5 | — | — | — | — | 0.82 | — | — | — | — | 1.54 | — | — | — | — | 1.15 | — | — | — | — | 1.14 | — | — | — | — | 1.58 | — | — | — | — | 1.18 | — | — | — | — | 0.95 | — | — | — | — | 1.04 | — | — | — | — | 0.81 | — | — | — | — | 0.95 | — | — | — | — |
| FOM (after DM) | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | 0.73 | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — |
| Map-model CC_mask | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | 0.813 | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — |
| Twin fraction | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | 0.32 | — | — | — | — | — | — | — | — | — |
| Science grade (vs deposited) | no-reference | — | — | — | — | no-reference | — | — | — | — | no-reference | — | — | — | — | no-reference | — | — | — | — | no-reference | — | — | — | — | no-reference | — | — | — | — | none | — | — | — | — | no-reference | — | — | — | — | no-reference | — | — | — | — | no-reference | — | — | — | — | none | — | — | — | — |
| Cα-RMSD vs deposited (Å) | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | 0.19 | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | 0.21 | — | — | — | — |
| Matched fraction | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | 0.94 | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | 0.94 | — | — | — | — |
| Coverage | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | 0.977 | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | 0.977 | — | — | — | — |

## Tool-vs-tool discrepancies (the Class-3 diagnostic)

- **AF_bromodomain_ligand**
  - rotamer outliers %: 2.25 (refine-log:refine_23102cb5) vs 0 (molprobity.out)
- **CASP7-T0283-mr**
  - R-free: 0.3346 (refine-log:refine_f55b7d08) vs 0.475 (refine-log:refine_f55b7d08)
- **a2u-globulin-mr**
  - rotamer outliers %: 0 (refine-log:refine_167e34aa) vs 3.65 (molprobity.out)
- **beta-blip**
  - rotamer outliers %: 1.46 (refine-log:refine_94aa136a) vs 12.24 (molprobity.out)
- **esterase_tNCS**
  - rotamer outliers %: 0 (refine-log:refine_e05e00f1) vs 0.68 (molprobity.out)
- **gene-5-mad**
  - R-free: 0.2297 (refine-log:refine_7094b0f5) vs 0.218 (molprobity.out)
  - rotamer outliers %: 12.16 (refine-log:refine_7094b0f5) vs 6.76 (molprobity.out)
- **nsf-d2-ligand**
  - R-free: 0.302 (refine-log:refine_c9a2c036) vs 0.2282 (molprobity.out)
  - rotamer outliers %: 2.3 (refine-log:refine_c9a2c036) vs 0 (molprobity.out)
- **porin-twin**
  - R-free: 0.1585 (refine-log:refine_9ec29be9) vs 0.2489 (molprobity.out)
  - rotamer outliers %: 3.23 (refine-log:refine_9ec29be9) vs 2.3 (molprobity.out)
- **refined_start**
  - R-free: 0.2525 (refine-log:refine_36889d3a) vs 0.2475 (molprobity.log)
  - rotamer outliers %: 5.48 (refine-log:refine_36889d3a) vs 2.74 (molprobity.log)
