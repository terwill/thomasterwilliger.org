# Table 1 - per-run summary

_Numbers are **as reported by each run's own tools** unless marked independent. Every value carries a source marker (legend below), because validators disagree - a recurring finding of this project. Rows are not comparable across cases (different resolutions, methods, data types): this is a per-run report card, not a leaderboard._

| metric | AF_7mjs_H_PredictAndBuild/run_1 | AF_7mjs_H_PredictAndBuild/run_1 | AF_7mjs_H_PredictAndBuild/run_1 | AF_7mjs_H_PredictAndBuild/run_1 | AF_7mjs_H_PredictAndBuild/run_1 | AF_bromodomain_ligand/run_1 | AF_bromodomain_ligand/run_1 | AF_bromodomain_ligand/run_1 | AF_bromodomain_ligand/run_1 | AF_bromodomain_ligand/run_1 | CASP7-T0283-mr/run_1 | CASP7-T0283-mr/run_1 | CASP7-T0283-mr/run_1 | CASP7-T0283-mr/run_1 | CASP7-T0283-mr/run_1 | a2u-globulin-mr/run_1 | a2u-globulin-mr/run_1 | a2u-globulin-mr/run_1 | a2u-globulin-mr/run_1 | a2u-globulin-mr/run_1 | beta-blip/run_1 | beta-blip/run_1 | beta-blip/run_1 | beta-blip/run_1 | beta-blip/run_1 | esterase_tNCS/run_1 | esterase_tNCS/run_1 | esterase_tNCS/run_1 | esterase_tNCS/run_1 | esterase_tNCS/run_1 | gene-5-mad/run_1 | gene-5-mad/run_1 | gene-5-mad/run_1 | gene-5-mad/run_1 | gene-5-mad/run_1 | nsf-d2-ligand/run_1 | nsf-d2-ligand/run_1 | nsf-d2-ligand/run_1 | nsf-d2-ligand/run_1 | nsf-d2-ligand/run_1 | p9-sad/run_1 | p9-sad/run_1 | p9-sad/run_1 | p9-sad/run_1 | p9-sad/run_1 | porin-twin/run_1 | porin-twin/run_1 | porin-twin/run_1 | porin-twin/run_1 | porin-twin/run_1 | refined_start/run_1 | refined_start/run_1 | refined_start/run_1 | refined_start/run_1 | refined_start/run_1 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| Resolution | 3 ^a | — | — | — | — | 2 ^b | — | — | — | — | 2 ^c | — | — | — | — | 2 ^b | — | — | — | — | 3 ^b | — | — | — | — | 2 ^b | — | — | — | — | 21.33 – 2.59 Å ^d | — | — | — | — | 2 ^d | — | — | — | — | 2 ^b | — | — | — | — | 2 ^b | — | — | — | — | 3 ^e | — | — | — | — |
| Space group | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | C 1 2 1 ^d | — | — | — | — | P 6 ^d | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — |
| R-work (run-declared) | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | 0.1366 ^d | — | — | — | — | — | — | — | — | — | — | — | — | — | — | 0.1288 ^f | — | — | — | — | 0.2036 ^g | — | — | — | — |
| R-free (run-declared) | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | 0.218 ^d | — | — | — | — | 0.1963 ^d | — | — | — | — | — | — | — | — | — | 0.158 ^f | — | — | — | — | 0.2417 ^g | — | — | — | — |
| R-work (refine log) | — | — | — | — | — | 0.2045 ^h | — | — | — | — | 0.3229 ^c | — | — | — | — | 0.1932 ^i | — | — | — | — | 0.2318 ^j | — | — | — | — | 0.1833 ^k | — | — | — | — | 0.1364 ^l | — | — | — | — | 0.2217 ^m | — | — | — | — | — | — | — | — | — | 0.1288 ^f | — | — | — | — | 0.2036 ^g | — | — | — | — |
| R-free (refine log) | — | — | — | — | — | 0.2555 ^h | — | — | — | — | 0.3346 ^c | — | — | — | — | 0.2528 ^i | — | — | — | — | 0.3137 ^j | — | — | — | — | 0.2112 ^k | — | — | — | — | 0.2179 ^l | — | — | — | — | 0.2563 ^m | — | — | — | — | — | — | — | — | — | 0.158 ^f | — | — | — | — | 0.2417 ^g | — | — | — | — |
| R-work (MolProbity) | — | — | — | — | — | 0.2045 ^b | — | — | — | — | — | — | — | — | — | 0.1967 ^b | — | — | — | — | 0.2371 ^b | — | — | — | — | 0.1716 ^b | — | — | — | — | 0.1366 ^b | — | — | — | — | 0.1963 ^b | — | — | — | — | 0.231 ^b | — | — | — | — | 0.2286 ^b | — | — | — | — | 0.1553 ^e | — | — | — | — |
| R-free (MolProbity) | — | — | — | — | — | 0.2573 ^b | — | — | — | — | — | — | — | — | — | 0.2563 ^b | — | — | — | — | 0.3094 ^b | — | — | — | — | 0.205 ^b | — | — | — | — | 0.218 ^b | — | — | — | — | 0.2282 ^b | — | — | — | — | 0.2462 ^b | — | — | — | — | 0.2489 ^b | — | — | — | — | 0.2475 ^e | — | — | — | — |
| R-free (recomputed, independent) | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | 0.2417 ^n | — | — | — | — |
| R-free (deposited) | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | 0.2 ^n | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — |
| MolProbity score | 1.78 ^b | — | — | — | — | 1.03 ^b | — | — | — | — | — | — | — | — | — | 2.24 ^b | — | — | — | — | 2.85 ^b | — | — | — | — | 1.6 ^b | — | — | — | — | 1.82 ^d | — | — | — | — | 0.95 ^d | — | — | — | — | 1.25 ^b | — | — | — | — | 1.88 ^b | — | — | — | — | 1.95 ^e | — | — | — | — |
| Clashscore | 8.07 ^b | — | — | — | — | 2.44 ^b | — | — | — | — | 9.22 ^c | — | — | — | — | 9.21 ^b | — | — | — | — | 11.91 ^b | — | — | — | — | 6.81 ^b | — | — | — | — | 3.05 ^b | — | — | — | — | 1.82 ^b | — | — | — | — | 4.81 ^b | — | — | — | — | 5.31 ^b | — | — | — | — | 6.79 ^e | — | — | — | — |
| Ramachandran favored % | 99.22 ^b | — | — | — | — | 100 ^b | — | — | — | — | 98.13 ^c | — | — | — | — | 95.34 ^b | — | — | — | — | 93.4 ^b | — | — | — | — | 96.54 ^b | — | — | — | — | 97.56 ^b | — | — | — | — | 97.96 ^b | — | — | — | — | 99.11 ^b | — | — | — | — | 95.47 ^b | — | — | — | — | 96.34 ^e | — | — | — | — |
| Ramachandran outliers % | 0.78 ^b | — | — | — | — | 0 ^b | — | — | — | — | — | — | — | — | — | 0 ^b | — | — | — | — | 0 ^b | — | — | — | — | 0.8 ^b | — | — | — | — | 0 ^b | — | — | — | — | 0 ^b | — | — | — | — | 0 ^b | — | — | — | — | 0.35 ^b | — | — | — | — | 0 ^e | — | — | — | — |
| Rotamer outliers % (MolProbity) | 2.83 ^b | — | — | — | — | 0 ^b | — | — | — | — | — | — | — | — | — | 3.65 ^b | — | — | — | — | 12.24 ^b | — | — | — | — | 0.68 ^b | — | — | — | — | 6.76 ^b | — | — | — | — | 0 ^b | — | — | — | — | 0 ^b | — | — | — | — | 2.3 ^b | — | — | — | — | 2.74 ^e | — | — | — | — |
| Rotamer outliers % (refine log) | — | — | — | — | — | 2.25 ^h | — | — | — | — | 1.11 ^c | — | — | — | — | 0 ^i | — | — | — | — | 6.71 ^j | — | — | — | — | 0.68 ^k | — | — | — | — | 6.76 ^l | — | — | — | — | 0.46 ^m | — | — | — | — | — | — | — | — | — | 1.84 ^f | — | — | — | — | 5.48 ^g | — | — | — | — |
| C-beta deviations (count, MolProbity) | 0 ^b | — | — | — | — | 0 ^b | — | — | — | — | — | — | — | — | — | 0 ^b | — | — | — | — | 0 ^b | — | — | — | — | 0 ^b | — | — | — | — | 0 ^b | — | — | — | — | 0 ^b | — | — | — | — | 0 ^b | — | — | — | — | 0 ^b | — | — | — | — | 0 ^e | — | — | — | — |
| C-beta deviations (%, refine log) | — | — | — | — | — | 0 ^h | — | — | — | — | 0 ^c | — | — | — | — | 0 ^i | — | — | — | — | 0 ^j | — | — | — | — | 0 ^k | — | — | — | — | 1.3 ^l | — | — | — | — | 0 ^m | — | — | — | — | — | — | — | — | — | 0 ^f | — | — | — | — | 0 ^g | — | — | — | — |
| RMS bonds | 0.0024 ^b | — | — | — | — | 0.0069 ^b | — | — | — | — | 0.018 ^c | — | — | — | — | 0.0091 ^b | — | — | — | — | 0.0094 ^b | — | — | — | — | 0.0184 ^b | — | — | — | — | 0.0105 ^b | — | — | — | — | 0.0085 ^b | — | — | — | — | 0.0074 ^b | — | — | — | — | 0.0087 ^b | — | — | — | — | 0.0079 ^e | — | — | — | — |
| RMS angles | 0.5 ^b | — | — | — | — | 0.82 ^b | — | — | — | — | 1.54 ^c | — | — | — | — | 1.15 ^b | — | — | — | — | 1.14 ^b | — | — | — | — | 1.58 ^b | — | — | — | — | 1.18 ^b | — | — | — | — | 0.95 ^b | — | — | — | — | 1.04 ^b | — | — | — | — | 0.81 ^b | — | — | — | — | 0.95 ^e | — | — | — | — |
| FOM (after DM) | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | 0.73 ^d | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — |
| Map-model CC_mask | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | 0.813 ^d | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — |
| Twin fraction | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | 0.32 ^a | — | — | — | — | — | — | — | — | — |
| Science grade (vs deposited) | no-reference ^n | — | — | — | — | no-reference ^n | — | — | — | — | no-reference ^n | — | — | — | — | no-reference ^n | — | — | — | — | no-reference ^n | — | — | — | — | no-reference ^n | — | — | — | — | none ^n | — | — | — | — | no-reference ^n | — | — | — | — | no-reference ^n | — | — | — | — | no-reference ^n | — | — | — | — | none ^n | — | — | — | — |
| CA-RMSD vs deposited (A) | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | 0.19 ^n | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | 0.21 ^n | — | — | — | — |
| Matched fraction | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | 0.94 ^n | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | 0.94 ^n | — | — | — | — |
| Coverage | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | 0.977 ^n | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | — | 0.977 ^n | — | — | — | — |

**Sources:** ^a self_analysis · ^b molprobity.out · ^c refine-log:refine_f55b7d08/phenix_mcp_run.log · ^d DEPOSIT · ^e molprobity.log · ^f refine-log:DEPOSIT/refine_final.log · ^g refine-log:refine_25d1e773/final_deposit_001.log · ^h refine-log:refine_23102cb5/final_001.log · ^i refine-log:refine_167e34aa/phenix_mcp_run.log · ^j refine-log:refine_1fe1d82b/phenix_mcp_run.log · ^k refine-log:refine_c8bd3dd4/esterase_final_001.log · ^l refine-log:refine_5afd62b8/FIN2_001.log · ^m refine-log:refine_3c621c4e/phenix_mcp_run.log · ^n scores.json

## Tool-vs-tool discrepancies (the Class-3 diagnostic)

- **AF_bromodomain_ligand/run_1**
  - rotamer outliers %: 2.25 (refine-log:refine_23102cb5/final_001.log) vs 0 (molprobity.out)
  - C-beta reported in different units - 0 count (molprobity.out) vs 0% (refine-log:refine_23102cb5/final_001.log); not directly comparable
- **a2u-globulin-mr/run_1**
  - rotamer outliers %: 0 (refine-log:refine_167e34aa/phenix_mcp_run.log) vs 3.65 (molprobity.out)
  - C-beta reported in different units - 0 count (molprobity.out) vs 0% (refine-log:refine_167e34aa/phenix_mcp_run.log); not directly comparable
- **beta-blip/run_1**
  - rotamer outliers %: 6.71 (refine-log:refine_1fe1d82b/phenix_mcp_run.log) vs 12.24 (molprobity.out)
  - C-beta reported in different units - 0 count (molprobity.out) vs 0% (refine-log:refine_1fe1d82b/phenix_mcp_run.log); not directly comparable
- **esterase_tNCS/run_1**
  - R-free: 0.2112 (refine-log:refine_c8bd3dd4/esterase_final_001.log) vs 0.205 (molprobity.out)
  - C-beta reported in different units - 0 count (molprobity.out) vs 0% (refine-log:refine_c8bd3dd4/esterase_final_001.log); not directly comparable
- **gene-5-mad/run_1**
  - C-beta reported in different units - 0 count (molprobity.out) vs 1.3% (refine-log:refine_5afd62b8/FIN2_001.log); not directly comparable
- **nsf-d2-ligand/run_1**
  - R-free: 0.2563 (refine-log:refine_3c621c4e/phenix_mcp_run.log) vs 0.2282 (molprobity.out)
  - R-free (run-declared vs MolProbity): 0.1963 (DEPOSIT) vs 0.2282 (molprobity.out)
  - C-beta reported in different units - 0 count (molprobity.out) vs 0% (refine-log:refine_3c621c4e/phenix_mcp_run.log); not directly comparable
- **porin-twin/run_1**
  - R-free: 0.158 (refine-log:DEPOSIT/refine_final.log) vs 0.2489 (molprobity.out)
  - R-free (run-declared vs MolProbity): 0.158 (refine-log:DEPOSIT/refine_final.log) vs 0.2489 (molprobity.out)
  - C-beta reported in different units - 0 count (molprobity.out) vs 0% (refine-log:DEPOSIT/refine_final.log); not directly comparable
- **refined_start/run_1**
  - R-free: 0.2417 (refine-log:refine_25d1e773/final_deposit_001.log) vs 0.2475 (molprobity.log)
  - R-free (run-declared vs MolProbity): 0.2417 (refine-log:refine_25d1e773/final_deposit_001.log) vs 0.2475 (molprobity.log)
  - rotamer outliers %: 5.48 (refine-log:refine_25d1e773/final_deposit_001.log) vs 2.74 (molprobity.log)
  - C-beta reported in different units - 0 count (molprobity.log) vs 0% (refine-log:refine_25d1e773/final_deposit_001.log); not directly comparable
