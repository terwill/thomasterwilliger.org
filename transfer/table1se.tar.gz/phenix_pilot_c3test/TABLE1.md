# Table 1 - per-run summary

_Numbers are **as reported by each run's own tools** unless marked independent. Every value carries a source marker (legend below), because validators disagree - a recurring finding of this project. Rows are not comparable across cases (different resolutions, methods, data types): this is a per-run report card, not a leaderboard. **Caveat:** a "discrepancy" below is only a true tool disagreement if both numbers describe the SAME model; control/intermediate refinements are excluded by name, but verify the sources before citing one._

| metric | a2u-globulin-mr/A3 | a2u-globulin-mr/A3C | porin-twin/A3 | porin-twin/A3C | refined_start/A3 | refined_start/A3C |
|---|---|---|---|---|---|---|
| Resolution | 2.38 ^a | 2.38 ^b | 2.25 ^c | 2.25 ^d | 2.59 ^e | 2.59 ^f |
| Space group | P 21 21 21 ^g | P 21 21 21 ^h | R 3 :H ^i | R 3 :H ^j | C 1 2 1 ^k | C 1 2 1 ^l |
| R-work (refine log) | 0.1928 ^m | 0.1882 ^n | 0.2212 ^o | 0.2189 ^p | 0.1834 ^p | 0.1814 ^p |
| R-free (refine log) | 0.2591 ^m | 0.2414 ^n | 0.2378 ^o | 0.2395 ^p | 0.2329 ^p | 0.2365 ^p |
| R-work (MolProbity) | 0.1929 ^a | 0.1882 ^b | 0.2212 ^c | 0.2189 ^d | 0.1834 ^e | 0.1814 ^f |
| R-free (MolProbity) | 0.259 ^a | 0.2414 ^b | 0.2378 ^c | 0.2395 ^d | 0.2329 ^e | 0.2365 ^f |
| R-free (recomputed, independent) | — | — | — | — | 0.2365 ^q | 0.2365 ^q |
| MolProbity score | 2.1 ^a | 1.98 ^b | 1.29 ^c | 1.32 ^d | 1.47 ^e | 1.47 ^f |
| Clashscore | 8.03 ^a | 8.77 ^b | 3.14 ^c | 3.38 ^d | 1.51 ^e | 1.51 ^f |
| Ramachandran favored % | 94.32 ^a | 96.07 ^b | 96.86 ^c | 96.86 ^d | 96.34 ^e | 96.34 ^f |
| Ramachandran outliers % | 0 ^a | 0 ^b | 0 ^c | 0 ^d | 0 ^e | 0 ^f |
| Rotamer outliers % (MolProbity) | 2.3 ^a | 2.1 ^b | 0.46 ^c | 0.92 ^d | 2.74 ^e | 2.74 ^f |
| Rotamer outliers % (refine log) | 1.92 ^m | 0.35 ^n | 0.46 ^o | 0.92 ^p | 2.74 ^p | 2.74 ^p |
| C-beta deviations (count, MolProbity) | 0 ^a | 0 ^b | 0 ^c | 0 ^d | 0 ^e | 0 ^f |
| C-beta deviations (%, refine log) | 0 ^m | 0 ^n | 0 ^o | 0 ^p | 0 ^p | 0 ^p |
| RMS bonds | 0.0076 ^a | 0.0088 ^b | 0.008 ^c | 0.009 ^d | 0.0025 ^e | 0.002 ^f |
| RMS angles | 1.02 ^a | 0.94 ^b | 0.84 ^c | 0.93 ^d | 0.59 ^e | 0.54 ^f |
| Twin fraction | — | — | 0.32 ^r | 0.32 ^r | — | — |
| Science grade (vs deposited) | no-reference ^q | no-reference ^q | no-reference ^q | no-reference ^q | none ^q | none ^q |
| CA-RMSD vs deposited (A) | — | — | — | — | 0.19 ^q | 0.19 ^q |
| Matched fraction | — | — | — | — | 0.93 ^q | 0.93 ^q |
| Coverage | — | — | — | — | 0.977 ^q | 0.977 ^q |

**Sources:** ^a molprobity.out:molprobity_c4cc5d04[a2u_final_001.pdb] · ^b molprobity.out:molprobity_0939caf2[a2u_003.pdb] · ^c molprobity.out:molprobity_3ce81c28[porin_twin_final_001.pdb] · ^d molprobity.out:molprobity_261217e7[porin_twin_final_001.pdb] · ^e molprobity.out:molprobity_27876d28[refine9_optw_001.pdb] · ^f molprobity.out:molprobity_71af83b3[gene5_final_001.pdb] · ^g molprobity.log:molprobity_c4cc5d04[a2u_final_001.pdb] · ^h molprobity.log:molprobity_0939caf2[a2u_003.pdb] · ^i molprobity.log:molprobity_3ce81c28[porin_twin_final_001.pdb] · ^j molprobity.log:molprobity_261217e7[porin_twin_final_001.pdb] · ^k molprobity.log:molprobity_27876d28[refine9_optw_001.pdb] · ^l molprobity.log:molprobity_71af83b3[gene5_final_001.pdb] · ^m refine-log:refine_cdc40674/a2u_final_001.log · ^n refine-log:DEPOSIT/final_refine.log · ^o refine-log:DEPOSIT/molprobity.log · ^p refine-log:DEPOSIT/molprobity_final.log · ^q scores.json · ^r self_analysis

## Tool-vs-tool discrepancies (the Class-3 diagnostic)

- **a2u-globulin-mr/A3C**
  - rotamer outliers %: 0.35 (refine-log:DEPOSIT/final_refine.log) vs 2.1 (molprobity.out:molprobity_0939caf2[a2u_003.pdb])  [CHECK MODELS - MolProbity ran on a2u_003.pdb, which is not named as the run's final model; may not be a tool disagreement]
