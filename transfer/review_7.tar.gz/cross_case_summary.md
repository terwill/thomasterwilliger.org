# Candidate-finder cross-case summary
_11 cases · 61 kept leads · 70 dropped by triage_

## Decision ledger — self-assessed denominator
_The Expert's own forward-walk rating of every decision. Correlated self-critique, not independent verification, and a lower bound (silent defaults under-enumerated) — read it as context for the leads, not a rate._

| case | decisions | well-justified | got-lucky | weakly | wrong | % well |
|---|---|---|---|---|---|---|
| AF_7mjs_H_PredictAndBuild | 9 | 6 | 0 | 1 | 1 | 66% |
| AF_bromodomain_ligand | 12 | 10 | 1 | 1 | 0 | 83% |
| beta-blip | 8 | 7 | 0 | 1 | 0 | 87% |
| esterase_tNCS | 10 | 7 | 1 | 1 | 0 | 70% |
| gene-5-mad | 19 | 12 | 0 | 5 | 2 | 63% |
| nsf-d2-ligand | 12 | 7 | 1 | 3 | 1 | 58% |
| p9-sad | 5 | 5 | 0 | 0 | 0 | 100% |
| porin-twin | 8 | 8 | 0 | 0 | 0 | 100% |
| refined_start | 6 | 5 | 0 | 1 | 0 | 83% |
| **all** | 89 | 67 | 3 | 13 | 4 | 75% |

## Per-case

| case | kept | critical | major | moderate | minor | dropped |
|---|---|---|---|---|---|---|
| AF_7mjs_H_PredictAndBuild | 4 | 0 | 1 | 3 | 0 | 8 |
| AF_bromodomain_ligand | 5 | 0 | 1 | 4 | 0 | 8 |
| CASP7-T0283-mr | 0 | 0 | 0 | 0 | 0 |  |
| a2u-globulin-mr | 0 | 0 | 0 | 0 | 0 |  |
| beta-blip | 7 | 0 | 4 | 3 | 0 | 5 |
| esterase_tNCS | 4 | 0 | 1 | 3 | 0 | 10 |
| gene-5-mad | 12 | 0 | 4 | 6 | 2 | 12 |
| nsf-d2-ligand | 9 | 0 | 3 | 4 | 2 | 6 |
| p9-sad | 4 | 0 | 1 | 2 | 1 | 5 |
| porin-twin | 6 | 0 | 1 | 5 | 0 | 13 |
| refined_start | 10 | 0 | 6 | 4 | 0 | 3 |

## Vantage coverage (kept leads; a multi-vantage lead counts in each column)

| case | G0 self-critique | G1a self-flag | G1b independent | multi (≥2) |
|---|---|---|---|---|
| AF_7mjs_H_PredictAndBuild | 3 | 3 | 1 | 2 |
| AF_bromodomain_ligand | 3 | 3 | 3 | 3 |
| CASP7-T0283-mr | 0 | 0 | 0 | 0 |
| a2u-globulin-mr | 0 | 0 | 0 | 0 |
| beta-blip | 3 | 5 | 4 | 4 |
| esterase_tNCS | 3 | 3 | 0 | 2 |
| gene-5-mad | 8 | 4 | 2 | 2 |
| nsf-d2-ligand | 7 | 3 | 2 | 2 |
| p9-sad | 3 | 2 | 0 | 1 |
| porin-twin | 3 | 3 | 1 | 1 |
| refined_start | 4 | 8 | 0 | 2 |

## Look here first (all cases, by corroboration then severity)

- **[major · 3 vantages]** AF_bromodomain_ligand — Modeled only ONE GQX copy though the deposited file has two.  _(self+transcript_pass+self_critique)_
- **[moderate · 3 vantages]** AF_7mjs_H_PredictAndBuild — Chose the post-Coot model as the primary deposited model despite the Trp47 backbone outlier.  _(self+transcript_pass+self_critique)_
- **[moderate · 3 vantages]** beta-blip — First Coot rebuild pass: per-residue auto-fit + local (3-residue) real-space refinement.  _(self+transcript_pass+self_critique)_
- **[moderate · 3 vantages]** nsf-d2-ligand — Added ordered_solvent=True to the holo refinements but initially ran no matched control.  _(self+transcript_pass+self_critique)_
- **[major · 2 vantages]** beta-blip — No deep/real rebuilding (autobuild, loop fitting, simulated annealing) was performed; only rotamer-l…  _(self+self_critique)_
- **[major · 2 vantages]** gene-5-mad — Verify whether the Coot fixes reached the file  _(self+transcript_pass)_
- **[major · 2 vantages]** p9-sad — Substituted p9.sca (anomalous) for the user-named perfect.mtz as the phasing dataset.  _(self+self_critique)_
- **[major · 2 vantages]** refined_start — Relied on a string-pattern grep to make and then verify the Se-removal edit.  _(self+self_critique)_
- **[moderate · 2 vantages]** AF_7mjs_H_PredictAndBuild — Ran the interactive Coot pass without periodically saving checkpoints to disk during the session.  _(self+self_critique)_
- **[moderate · 2 vantages]** AF_bromodomain_ligand — Accept the molecular replacement solution as correct and the space group hand as resolved.  _(self+transcript_pass)_
- **[moderate · 2 vantages]** AF_bromodomain_ligand — Defer to MolProbity for authoritative angle RMSD rather than trusting the refine-log value  _(both)_
- **[moderate · 2 vantages]** beta-blip — Do a gentle side-chain-only rotamer pass with no backbone perturbation, then a final refine  _(both)_
- **[moderate · 2 vantages]** beta-blip — Selected refine6 as final model over the lower-R-free refine2.  _(transcript_pass+self_critique)_
- **[moderate · 2 vantages]** esterase_tNCS — Built no catalytic metal or ligand; treated the structure as apo.  _(self+self_critique)_
- **[moderate · 2 vantages]** esterase_tNCS — Proceeded without the planned hands-on Coot rebuild of outliers, documenting the tool failure.  _(self+self_critique)_
- **[moderate · 2 vantages]** gene-5-mad — Judged 3 sites real (occ≥0.5), declared hand unambiguous, proceeded to AutoBuild  _(both)_
- **[moderate · 2 vantages]** nsf-d2-ligand — Generated a new 10% R-free set.  _(self+self_critique)_
- **[moderate · 2 vantages]** porin-twin — Added 165 ordered waters via ordered_solvent=True, accepting phenix's default automatic water-pickin…  _(transcript_pass+self_critique)_
- **[moderate · 2 vantages]** refined_start — Did not force rotamer fixes in reciprocal space; left the 4 rotamer outliers unresolved.  _(self+self_critique)_
- **[major · 1 vantage]** AF_7mjs_H_PredictAndBuild — Report result with two explicit caveats  _(self)_
- **[major · 1 vantage]** beta-blip — Run one more polishing round restoring individual_sites_real_space term  _(self)_
- **[major · 1 vantage]** beta-blip — Treat standalone MolProbity rotamer count as authoritative over refine-log value  _(self)_
- **[major · 1 vantage]** beta-blip — Include occupancy refinement in the very first refinement cycle, alongside rigid-body, coordinate, a…  _(transcript_pass)_
- **[major · 1 vantage]** esterase_tNCS — Reported final status, noting N-terminal 1–2 trimmed as disordered and SS-bonds applied  _(self)_
- **[major · 1 vantage]** gene-5-mad — Used `restore_to_backup_checkpoint` for revert logic in Coot.  _(self_critique)_
- **[major · 1 vantage]** gene-5-mad — Kept SE Z/2 and assigned it as the Met1 selenium.  _(self_critique)_
- **[major · 1 vantage]** gene-5-mad — Initially claimed the 3 free Se atoms were chemically impossible artifacts.  _(self_critique)_
- **[major · 1 vantage]** nsf-d2-ligand — Conclude atp.pdb is an unfitted starting conformer; decide it must be fitted de novo, not merely ref…  _(self)_
- **[major · 1 vantage]** nsf-d2-ligand — Asserted in the user-facing PROPOSED PLAN that the supplied ATP sat in 'a bona fide nucleotide pocke…  _(self_critique)_
- **[major · 1 vantage]** nsf-d2-ligand — Lattice-shifted the ATP by -1 in a.  _(self_critique)_
- **[major · 1 vantage]** porin-twin — Treat phenix.refine twinned R-factors as correct; interpret MolProbity R as untwinned-target R, not …  _(self)_
- **[major · 1 vantage]** refined_start — Diagnose the divergence before trusting the result  _(self)_
- **[major · 1 vantage]** refined_start — From original model, add TLS, tighten xyz weight (wxc_scale=0.3), keep ordered_solvent  _(self)_
- **[major · 1 vantage]** refined_start — Judge Se atoms as likely spurious; plan to validate each against density in Coot  _(self)_
- **[major · 1 vantage]** refined_start — Re-remove chain Z robustly via awk and confirm count drops by exactly 4  _(self)_
- **[major · 1 vantage]** refined_start — Reject all refinement variants; deposit baseline with 4 Se removed via bulk-solvent/scaling-only pas…  _(self)_
- **[moderate · 1 vantage]** AF_7mjs_H_PredictAndBuild — Accepted the Glu46 rotamer fix, which re-refined residues 45-47.  _(self_critique)_
- **[moderate · 1 vantage]** AF_bromodomain_ligand — Did not model the Mg ion despite the deposited entry containing one.  _(self_critique)_
- **[moderate · 1 vantage]** AF_bromodomain_ligand — Stopped refinement at R-free 0.257 rather than pushing lower.  _(self_critique)_
- **[moderate · 1 vantage]** esterase_tNCS — Interpreted the 3 Ramachandran outliers as real; did not restrain or flip them.  _(self_critique)_
- **[moderate · 1 vantage]** gene-5-mad — Abandon Coot approach; use targeted phenix.refine on residue 77 only  _(self)_
- **[moderate · 1 vantage]** gene-5-mad — Ran AutoSol with sites=2, thoroughness=thorough, defaults elsewhere; did not set an explicit res_hys…  _(self_critique)_
- **[moderate · 1 vantage]** gene-5-mad — Fixed rotamers in Coot, then refined B-factors/occupancies only (no reciprocal-space coordinate refi…  _(self_critique)_
- **[moderate · 1 vantage]** gene-5-mad — Left Gln12 fully modelled.  _(self_critique)_
- **[moderate · 1 vantage]** gene-5-mad — Treated the case as SAD using only peak.sca, and did not tell the user that MAD was possible.  _(self_critique)_
- **[moderate · 1 vantage]** nsf-d2-ligand — The agent launched refinements of both the apo and holo models simultaneously.  _(transcript_pass)_
- **[moderate · 1 vantage]** nsf-d2-ligand — Did not reconcile the two tools; reported the Coot number (0) in the narrative while the validate_li…  _(self_critique)_
- **[moderate · 1 vantage]** p9-sad — Report structure as complete initial solution; mark weak Se sites provisional; note 14 unbuilt resid…  _(self)_
- **[moderate · 1 vantage]** p9-sad — Stopped at the AutoSol initial model; no manual Coot rebuild, no extra autobuild/refine.  _(self_critique)_
- **[moderate · 1 vantage]** porin-twin — Treat this as a merohedral-twinning candidate; note it's a starting model  _(self)_
- **[moderate · 1 vantage]** porin-twin — Verify no waters were lost; conclude the '204' was a mid-run count and Coot preserved everything  _(self)_
- **[moderate · 1 vantage]** porin-twin — Made Coot rotamer fixes with a density-guarded accept/revert protocol using the refined 2mFo-DFc map…  _(self_critique)_
- **[moderate · 1 vantage]** porin-twin — Accepted the final refined model with the wider-than-typical R-free gap, attributing it partly to in…  _(self_critique)_
- **[moderate · 1 vantage]** refined_start — Adopt plan preserving existing R-free set (generate=False), keep Se initially, refine with weight op…  _(self)_
- **[moderate · 1 vantage]** refined_start — Ran first refinement using optimize_xyz_weight/adp with ordered_solvent for 5 cycles.  _(self_critique)_
- **[moderate · 1 vantage]** refined_start — Removed the 4 free Se atoms (chain Z).  _(self_critique)_
- **[minor · 1 vantage]** gene-5-mad — Trust cbetadev output over the log block value; run definitive MolProbity  _(self)_
- **[minor · 1 vantage]** gene-5-mad — Set occupancy 0 on distal atoms of Arg21 and Lys24.  _(self_critique)_
- **[minor · 1 vantage]** nsf-d2-ligand — Chose fitA over fitB as the primary model.  _(self_critique)_
- **[minor · 1 vantage]** nsf-d2-ligand — Guessed PHIL parameter names rather than querying them, across two different programs.  _(self_critique)_
- **[minor · 1 vantage]** p9-sad — Reported '4 Se sites' as the headline (HySS number) while the refined HA file lists 5 Se, disclosing…  _(self_critique)_

## Notable good decisions (self-assessed well-justified, not flagged)

- **beta-blip** · Include BLIP (blip.pdb + blip.seq) though prompt named only beta.seq — _Phaser log — SINGLE solution, BLIP TFZ=30.2, LLG=1053, clean packing;_
- **beta-blip** · Ensemble identity = 1.0 for both search models — _Phaser VRMS/TFZ in log — strong solution._
- **beta-blip** · Generate fresh 10% R-free set, freeze it — _consistent 9.98–9.99% free fraction and identical n_refl across all 6 rounds_
- **gene-5-mad** · Did not read `sites.xyz` / `Facts.list` — _n/a — a process decision, not a data one._
- **gene-5-mad** · Accepted AutoSol's best solution (BAYES-CC 48.3) without re-running — _the DM map's CC_mask against the eventual model is 0.813, and AutoBuild reached R-free 0.22 from these phases — the map was genuinely good, independent of the final model's own refinement._
- **gene-5-mad** · Ran AutoBuild with `rebuild_in_place=False` — _residue count went 68 → 84 and R-free 0.46 → 0.22 across cycles; sequence register then matched the target exactly at every position 2–85._
- **nsf-d2-ligand** · Adopt `nsf-d2_noligand.pdb` as the protein scaffold — _symmetry-aware contact search showed the two files are geometrically matched_
- **nsf-d2-ligand** · Run an apo, ligand-blind baseline — _it did the job — it is the map that refuted the supplied pose and located the_
- **nsf-d2-ligand** · Use library restraints for ATP, no custom CIF — _`validate_ligands` reports 0 bond outliers of 33, 0 angle of 52, 0 dihedral of_
- **p9-sad** · Accept p9.sca as-is; no reprocessing / no resolution cut for substructure — _AutoSol found 4/4 expected sites with 0 special-position artifacts and clean hand_
- **p9-sad** · AutoSol params: atom_type=Se, sites=4, SG from data, defaults otherwise — _HySS found exactly 4 sites; BAYES-CC 0.539 and map CC 0.833 vs truth — defaults were_
- **porin-twin** · Twin law = h,-h-k,-l — _xtriage intensity statistics + operator table._
- **porin-twin** · Refined twin fraction reported as 0.32 — _agreement between refined value and three model-independent xtriage estimators._
- **porin-twin** · No-twin baseline as evidence — _baseline R-free 0.2618 vs twinned 0.183 at equal parameters/test set._
