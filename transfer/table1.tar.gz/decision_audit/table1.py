#!/usr/bin/env python3
"""
table1.py - a Table-1 style report card per run, with PROVENANCE.

Answers the outcome question the decision audit deliberately doesn't: are the models any good?
(Decision quality and model quality are independent axes - a run can make shaky calls and still
land a fine model.)

Design rules, all learned the hard way on this project:

  1. EVERY NUMBER NAMES ITS SOURCE - in the markdown, not just the CSV. Validators disagree
     (refine-log vs standalone MolProbity rotamers differed 23x in beta-blip; twinned vs
     untwinned R in porin-twin), so a bare "R-free" would be a lie of omission.
  2. NO SILENT CROSS-SOURCE FALLBACK. A column labelled "(MolProbity)" is filled ONLY from a
     MolProbity file; if there isn't one it stays as a dash. Otherwise the discrepancy check
     compares a number with itself and reports a vacuous "clean".
  3. THE FINAL REFINEMENT IS CHOSEN DETERMINISTICALLY - filename/dir hints (FINAL/FIN2/deposit)
     then newest by mtime. A real run has ~10 refine dirs with random hex names; picking by
     alphabetical order can report an INTERMEDIATE refinement as the run's result.
  4. INDEPENDENT COLUMN WHERE AVAILABLE. pilot's science grade (scores.json) recomputes R-free
     and compares against the deposited reference - the one cheap source of verification
     rather than self-report.

Deterministic: parses artifacts already on disk. NO API calls, no keys.

Usage:
    RUNS_ROOT=runs python table1.py                 # markdown to stdout
    RUNS_ROOT=runs python table1.py --out TABLE1.md
    RUNS_ROOT=runs python table1.py --csv table1.csv
"""
import os, re, sys, csv, json, pathlib

RUNS_ROOT = os.environ.get("RUNS_ROOT", "runs")
_FINAL_HINT = re.compile(r"final|fin\d|deposit", re.I)
# a control / apo / baseline refinement is NOT the run's result
_CONTROL_HINT = re.compile(r"control|apo|baseline|noligand|no_ligand", re.I)


# ---------- small helpers -------------------------------------------------
def _f(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None

def _first(pattern, text, flags=re.I):
    m = re.search(pattern, text, flags)
    return m.group(1) if m else None

def fmt(v, nd=4):
    if v is None:
        return "\u2014"
    if isinstance(v, float):
        return f"{v:.{nd}f}".rstrip("0").rstrip(".") if nd else f"{v:.0f}"
    return str(v)


class Val:
    """A number plus where it came from."""
    __slots__ = ("v", "src")
    def __init__(self, v, src=""):
        self.v, self.src = v, src
    def __bool__(self):
        return self.v is not None


# ---------- readers -------------------------------------------------------
def _refine_logs(run_dir):
    """Refine logs, best-first: FINAL/FIN2/deposit-named beat others, then newest by mtime.
    (Never alphabetical - refine dirs carry random hex suffixes.)"""
    cands = (list(run_dir.glob("refine*/*.log")) + list(run_dir.glob("*/refine*.log"))
             + list(run_dir.glob("DEPOSIT/**/*.log")))
    uniq, seen = [], set()
    for p in cands:
        if p not in seen:
            seen.add(p)
            uniq.append(p)
    cands = [p for p in cands if not _CONTROL_HINT.search(p.name)]
    def key(p):
        hint = 1 if (_FINAL_HINT.search(p.name) or _FINAL_HINT.search(p.parent.name)) else 0
        hint += 1 if "DEPOSIT" in p.parts else 0
        try:
            mt = p.stat().st_mtime
        except OSError:
            mt = 0
        return (hint, mt)
    uniq.sort(key=key, reverse=True)
    return uniq[:3]


def read_texts(run_dir):
    """Candidate text blobs, tagged by source class."""
    out = []
    for rel, tag in (("DEPOSIT/README.md", "DEPOSIT"),
                     ("artifacts/final_report.json", "final_report"),
                     ("artifacts/FINAL_REPORT.md", "FINAL_REPORT"),
                     ("FINAL_REPORT.md", "FINAL_REPORT"),
                     ("artifacts/self_analysis.md", "self_analysis")):
        p = run_dir / rel
        if p.exists():
            out.append((tag, p.read_text(errors="replace")))
    for p in sorted(run_dir.glob("*molprobity*/molprobity.out")):
        out.append(("molprobity.out", p.read_text(errors="replace")))
    for p in sorted(run_dir.glob("*molprobity*/*.log")):
        out.append(("molprobity.log", p.read_text(errors="replace")))
    for p in _refine_logs(run_dir):
        out.append((f"refine-log:{p.parent.name}/{p.name}", p.read_text(errors="replace")))
    return out


def src_class(tag):
    """Which SOURCE CLASS a tag belongs to. Must be exact, not substring: a refine log living in
    DEPOSIT/ is tagged 'refine-log:DEPOSIT/foo.log', and a substring test for 'DEPOSIT' would
    wrongly classify it as a run-declared report -- making the run-declared row duplicate the
    refine-log row and double-reporting the same discrepancy under two labels."""
    if tag.startswith("refine-log:"):
        return "refine"
    if "molprobity" in tag.lower():
        return "molprobity"
    if tag in ("DEPOSIT", "final_report", "FINAL_REPORT"):
        return "run"
    return tag


def pick(texts, patterns, prefer=(), strict=False):
    """First (value, source) match. `prefer` is an ordered list of SOURCE CLASSES
    ('run' | 'refine' | 'molprobity'). strict=True means: if no preferred class matched, return
    nothing rather than borrowing a value from a different class."""
    hits = []
    for src, txt in texts:
        for pat in patterns:
            got = _first(pat, txt)
            if got is not None:
                val = _f(got) if re.match(r"^[\d.]+$", got.strip()) else got.strip()
                hits.append(Val(val, src))
                break
    if prefer:
        for want in prefer:
            for h in hits:
                if src_class(h.src) == want:
                    return h
        if strict:
            return Val(None)
    return hits[0] if hits else Val(None)


def science_grade(run_dir):
    p = run_dir / "scores.json"
    if not p.exists():
        return {}
    try:
        d = json.loads(p.read_text())
    except Exception:
        return {}
    if any(k.startswith("sci.") for k in d):
        return {k[4:]: v for k, v in d.items() if k.startswith("sci.")}
    return d.get("science", {}) or {}


# ---------- per-run extraction -------------------------------------------
MP = ("molprobity",)
RL = ("refine",)
RUN = ("run",)

def build_row(label, run_dir):
    T = read_texts(run_dir)
    r = {"case": label}

    r["resolution"] = pick(T, [r"Resolution\s*\|?\s*([\d.]+\s*[\u2013\-]\s*[\d.]+\s*\u00c5)",
                               r"Resolution\s*[:|=]\s*([\d.]+)"])
    # require a plausible Hermann-Mauguin symbol (lattice letter + at least one number group),
    # else prose like "Space group identification----------" is captured as the space group
    _SG = r"([PABCIFRH](?:\s*-?\d+[a-z]?)+(?:\s*:\s*[HR])?)"
    r["spacegroup"] = pick(T, [r"[Ss]pace [Gg]roup\s*[:|=]?\s*\|?\s*\*{0,2}" + _SG,
                               r"SG\s*=\s*\"?" + _SG])

    # R-factors, one row per SOURCE CLASS - never blended, never borrowed.
    # NB: some reports use a COMBINED cell, e.g. "R-work / R-free | **0.1963 / 0.2282**".
    # Match that pair first — otherwise an R-free pattern matches the *label* and returns R-work.
    _pair_rw = r"R-?work\s*/\s*R-?free[^\d\n]{0,20}([\d.]+)\s*/\s*[\d.]+"
    _pair_rf = r"R-?work\s*/\s*R-?free[^\d\n]{0,20}[\d.]+\s*/\s*([\d.]+)"
    rw = [_pair_rw, r"Final R-work\s*=\s*([\d.]+)", r"R-work\s*[=|]\s*\*{0,2}([\d.]+)"]
    rf = [_pair_rf, r"Final R-work\s*=\s*[\d.]+,\s*R-free\s*=\s*([\d.]+)",
          r"R-free\s*[=|]\s*\*{0,2}([\d.]+)"]
    r["rwork_run"]    = pick(T, rw, prefer=RUN, strict=True)
    r["rfree_run"]    = pick(T, rf, prefer=RUN, strict=True)
    r["rwork_refine"] = pick(T, rw, prefer=RL, strict=True)
    r["rfree_refine"] = pick(T, rf, prefer=RL, strict=True)
    r["rwork_mp"]     = pick(T, rw, prefer=MP, strict=True)
    r["rfree_mp"]     = pick(T, rf, prefer=MP, strict=True)

    r["molprobity"] = pick(T, [r"MolProbity score\s*[=|]\s*\*{0,2}([\d.]+)"])
    r["clashscore"] = pick(T, [r"Clashscore\s*[=|]\s*\*{0,2}([\d.]+)",
                               r"All-atom Clashscore\s*:\s*([\d.]+)"], prefer=MP)
    r["rama_fav"]   = pick(T, [r"favored\s*[=|:]\s*\*{0,2}([\d.]+)\s*%"], prefer=MP)
    r["rama_out"]   = pick(T, [r"Ramachandran outliers\s*[=|:]\s*\*{0,2}([\d.]+)"], prefer=MP)
    r["rota_mp"]     = pick(T, [r"Rotamer outliers\s*[=|:]\s*\*{0,2}([\d.]+)"], prefer=MP, strict=True)
    r["rota_refine"] = pick(T, [r"Rotamer:\s*\n\s*Outliers\s*:\s*([\d.]+)"], prefer=RL, strict=True)
    # Cbeta: MolProbity reports a COUNT, refine logs a PERCENT - kept separate, never compared.
    r["cbeta_n"]   = pick(T, [r"C-?beta deviations\s*[=|:]\s*\*{0,2}(\d+)"], prefer=MP, strict=True)
    r["cbeta_pct"] = pick(T, [r"Cbeta Deviations\s*:\s*([\d.]+)"], prefer=RL, strict=True)
    r["bonds"]  = pick(T, [r"RMS\(bonds\)\s*[=|]\s*([\d.]+)", r"Bond\s*:\s*([\d.]+)"])
    r["angles"] = pick(T, [r"RMS\(angles\)\s*[=|]\s*([\d.]+)", r"Angle\s*:\s*([\d.]+)"])

    # phasing / map quality (regime-dependent; absent rows are dropped)
    r["fom"]   = pick(T, [r"FOM after density modification\s*\|\s*([\d.]+)",
                          r"New map fom is\s*([\d.]+)"])
    r["mapcc"] = pick(T, [r"CC_mask[^|]*\|\s*\*{0,2}([\d.]+)", r"CC_mask\s*:\s*([\d.]+)"])
    r["twin_frac"] = pick(T, [r"twin fraction[^\d\n]{0,25}?(0?\.\d+)",
                              r"Refined twin fraction[^\d\n]{0,25}?(0?\.\d+)"])

    # independent verification from the pilot science grade
    sci = science_grade(run_dir)
    met = (sci.get("metrics") or {}) if isinstance(sci, dict) else {}
    sup, cov, mvd = met.get("superpose") or {}, met.get("coverage") or {}, met.get("model_vs_data") or {}
    r["sci_grade"]    = Val(sci.get("grade"), "scores.json") if sci else Val(None)
    r["ca_rmsd"]      = Val(sup.get("ca_rmsd_A"), "scores.json")
    r["matched"]      = Val(sup.get("matched_fraction"), "scores.json")
    r["coverage"]     = Val(cov.get("coverage"), "scores.json")
    r["rfree_recomp"] = Val(mvd.get("r_free"), "scores.json")
    r["rfree_dep"]    = Val(met.get("deposited_rfree"), "scores.json")
    return r


# ---------- discrepancy detection (the Class-3 diagnostic) ----------------
def discrepancies(r):
    """Only compares values from GENUINELY DIFFERENT sources - otherwise a missing file
    would make the check vacuously 'clean'."""
    out = []
    def cmp(a, b, label, tol):
        if not (a and b):
            return
        if not (isinstance(a.v, float) and isinstance(b.v, float)):
            return
        if a.src == b.src:                       # same file: not an independent comparison
            return
        if abs(a.v - b.v) > tol:
            out.append(f"{label}: {fmt(a.v)} ({a.src}) vs {fmt(b.v)} ({b.src})")
    cmp(r["rwork_refine"], r["rwork_mp"], "R-work", 0.005)
    cmp(r["rfree_refine"], r["rfree_mp"], "R-free", 0.005)
    cmp(r["rfree_run"], r["rfree_mp"], "R-free (run-declared vs MolProbity)", 0.005)
    cmp(r["rota_refine"], r["rota_mp"], "rotamer outliers %", 0.5)
    cmp(r["rfree_refine"], r["rfree_recomp"], "R-free vs recomputed", 0.02)
    cmp(r["rfree_run"], r["rfree_recomp"], "R-free (run-declared) vs recomputed", 0.02)
    # only worth saying when they could actually conflict — "0 count vs 0%" is agreement,
    # and firing on every case buries the real discrepancies.
    if (r["cbeta_n"] and r["cbeta_pct"]
            and (float(r["cbeta_n"].v or 0) > 0 or float(r["cbeta_pct"].v or 0) > 0)):
        out.append(f"C-beta reported in different units - {fmt(r['cbeta_n'].v,0)} count "
                   f"({r['cbeta_n'].src}) vs {fmt(r['cbeta_pct'].v,2)}% ({r['cbeta_pct'].src}); "
                   f"not directly comparable")
    return out


# ---------- rendering -----------------------------------------------------
ROWS = [
    ("Resolution", "resolution", 2), ("Space group", "spacegroup", 0),
    ("R-work (run-declared)", "rwork_run", 4), ("R-free (run-declared)", "rfree_run", 4),
    ("R-work (refine log)", "rwork_refine", 4), ("R-free (refine log)", "rfree_refine", 4),
    ("R-work (MolProbity)", "rwork_mp", 4), ("R-free (MolProbity)", "rfree_mp", 4),
    ("R-free (recomputed, independent)", "rfree_recomp", 4),
    ("R-free (deposited)", "rfree_dep", 4),
    ("MolProbity score", "molprobity", 2), ("Clashscore", "clashscore", 2),
    ("Ramachandran favored %", "rama_fav", 2), ("Ramachandran outliers %", "rama_out", 2),
    ("Rotamer outliers % (MolProbity)", "rota_mp", 2),
    ("Rotamer outliers % (refine log)", "rota_refine", 2),
    ("C-beta deviations (count, MolProbity)", "cbeta_n", 0),
    ("C-beta deviations (%, refine log)", "cbeta_pct", 2),
    ("RMS bonds", "bonds", 4), ("RMS angles", "angles", 2),
    ("FOM (after DM)", "fom", 2), ("Map-model CC_mask", "mapcc", 3),
    ("Twin fraction", "twin_frac", 2),
    ("Science grade (vs deposited)", "sci_grade", 0),
    ("CA-RMSD vs deposited (A)", "ca_rmsd", 2),
    ("Matched fraction", "matched", 2), ("Coverage", "coverage", 3),
]


def render(rows):
    src_ids, order = {}, []
    def mark(v, nd):
        if not (v and v.v is not None):
            return "\u2014"
        s = fmt(v.v, nd)
        if v.src:
            if v.src not in src_ids:
                src_ids[v.src] = chr(ord("a") + len(src_ids))
                order.append(v.src)
            s += f" ^{src_ids[v.src]}"
        return s

    body = []
    for label, key, nd in ROWS:
        vals = [r.get(key) for r in rows]
        if not any(v and v.v is not None for v in vals):
            continue                              # drop rows nobody reported
        body.append(f"| {label} | " + " | ".join(mark(v, nd) for v in vals) + " |")

    out = ["# Table 1 - per-run summary", "",
           "_Numbers are **as reported by each run's own tools** unless marked independent. "
           "Every value carries a source marker (legend below), because validators disagree - "
           "a recurring finding of this project. Rows are not comparable across cases "
           "(different resolutions, methods, data types): this is a per-run report card, "
           "not a leaderboard. **Caveat:** a \"discrepancy\" below is only a true tool "
           "disagreement if both numbers describe the SAME model; control/intermediate "
           "refinements are excluded by name, but verify the sources before citing one._", "",
           "| metric | " + " | ".join(r["case"] for r in rows) + " |",
           "|" + "---|" * (len(rows) + 1)] + body

    if order:
        out += ["", "**Sources:** " + " \u00b7 ".join(f"^{src_ids[s]} {s}" for s in order)]

    out += ["", "## Tool-vs-tool discrepancies (the Class-3 diagnostic)", ""]
    any_d = False
    for r in rows:
        ds = discrepancies(r)
        if ds:
            any_d = True
            out.append(f"- **{r['case']}**")
            out += [f"  - {d}" for d in ds]
    if not any_d:
        out.append("_None detected among the fields that had two independent sources._")
    return "\n".join(out) + "\n"


def _argval(flag):
    i = sys.argv.index(flag)
    if i + 1 >= len(sys.argv):
        print(f"error: {flag} needs a filename", file=sys.stderr)
        sys.exit(2)
    return sys.argv[i + 1]


def main():
    root = pathlib.Path(RUNS_ROOT)
    run_dirs = sorted(p for p in root.glob("*/*/run_*") if p.is_dir())
    if not run_dirs:
        print(f"No runs found under {RUNS_ROOT}/", file=sys.stderr)
        sys.exit(1)

    # keep only run dirs that actually have something to report (setup-runs creates empty
    # dirs for every configured arm; those would otherwise become columns of dashes)
    # NB: `pilot capture` writes a scores.json into EVERY scheduled run dir, including the
    # empty ones it creates for unused arms — so mere existence proves nothing. Require real
    # artifacts, or a science grade that actually parsed.
    live = [rd for rd in run_dirs if read_texts(rd) or science_grade(rd)]
    if not live:
        print(f"No runs with parseable artifacts under {RUNS_ROOT}/", file=sys.stderr)
        sys.exit(1)

    # disambiguate columns: <case> alone if unique, else <case>/<arm> (or /<arm>/<run>)
    per_case = {}
    for rd in live:
        per_case.setdefault(rd.parts[-3], []).append(rd)
    rows = []
    for case, dirs in sorted(per_case.items()):
        arms = {rd.parts[-2] for rd in dirs}
        for rd in sorted(dirs):
            if len(dirs) == 1:
                label = case
            elif len(arms) == len(dirs):
                label = f"{case}/{rd.parts[-2]}"
            else:
                label = f"{case}/{rd.parts[-2]}/{rd.name}"
            rows.append(build_row(label, rd))

    if "--csv" in sys.argv:
        path = _argval("--csv")
        with open(path, "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["case"] + [lbl for lbl, _, _ in ROWS] + ["sources"])
            for r in rows:
                srcs = "; ".join(f"{k}={r[k].src}" for _, k, _ in ROWS
                                 if r.get(k) and r[k].v is not None and r[k].src)
                w.writerow([r["case"]] + [fmt(r[k].v if r.get(k) else None, nd)
                                          for _, k, nd in ROWS] + [srcs])
        print(f"wrote {path} ({len(rows)} runs)")
        return

    report = render(rows)
    if "--out" in sys.argv:
        path = _argval("--out")
        pathlib.Path(path).write_text(report)
        print(f"wrote {path} ({len(rows)} runs)")
    else:
        print(report)


if __name__ == "__main__":
    main()
