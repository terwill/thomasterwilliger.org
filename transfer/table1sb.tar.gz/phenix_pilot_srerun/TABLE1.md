# Table 1 - per-run summary

_Numbers are **as reported by each run's own tools** unless marked independent. Every value carries a source marker (legend below), because validators disagree - a recurring finding of this project. Rows are not comparable across cases (different resolutions, methods, data types): this is a per-run report card, not a leaderboard. **Caveat:** a "discrepancy" below is only a true tool disagreement if both numbers describe the SAME model; control/intermediate refinements are excluded by name, but verify the sources before citing one._

| metric | gene-5-mad/S/run_1 | gene-5-mad/S/run_2 | gene-5-mad/S/run_3 |
|---|---|---|---|
| Resolution | 2.59 ^a | 2.59 ^b | 2.59 ^c |
| Space group | C 1 2 1 ^d | C 1 2 1 ^e | C 1 2 1 ^f |
| R-work (refine log) | 0.1751 ^g | 0.1774 ^h | 0.1578 ^i |
| R-free (refine log) | 0.2715 ^g | 0.226 ^h | 0.2693 ^i |
| R-work (MolProbity) | 0.1749 ^a | 0.1774 ^b | 0.1514 ^c |
| R-free (MolProbity) | 0.2716 ^a | 0.226 ^b | 0.2694 ^c |
| R-free (deposited) | 0.2 ^j | 0.2 ^j | 0.2 ^j |
| MolProbity score | 1.7 ^a | 1.1 ^b | 1.97 ^c |
| Clashscore | 4.13 ^a | 2.25 ^b | 4.85 ^c |
| Ramachandran favored % | 97.22 ^a | 98.78 ^b | 97.26 ^c |
| Ramachandran outliers % | 0 ^a | 0 ^b | 0 ^c |
| Rotamer outliers % (MolProbity) | 2.94 ^a | 1.35 ^b | 5.8 ^c |
| Rotamer outliers % (refine log) | 8.82 ^g | 1.35 ^h | 2.9 ^i |
| C-beta deviations (count, MolProbity) | 0 ^a | 0 ^b | 0 ^c |
| C-beta deviations (%, refine log) | 1.41 ^g | 0 ^h | 0 ^i |
| RMS bonds | 0.0089 ^a | 0.0051 ^b | 0.0092 ^c |
| RMS angles | 1.04 ^a | 0.73 ^b | 1.05 ^c |
| Science grade (vs deposited) | major ^j | none ^j | critical ^j |
| CA-RMSD vs deposited (A) | 0.18 ^j | 0.19 ^j | 17.16 ^j |
| Matched fraction | 0.84 ^j | 0.94 ^j | 0.03 ^j |
| Coverage | 0.884 ^j | 0.977 ^j | 0 ^j |

**Sources:** ^a molprobity.out:molprobity_d29d04d1 · ^b molprobity.out:molprobity_6da24803 · ^c molprobity.out:molprobity_62be0f67 · ^d molprobity.log:molprobity_d29d04d1 · ^e molprobity.log:molprobity_6da24803 · ^f molprobity.log:molprobity_62be0f67 · ^g refine-log:DEPOSIT/final_refine.log · ^h refine-log:DEPOSIT/gene5_molprobity_final.log · ^i refine-log:DEPOSIT/gene5_final_molprobity.log · ^j scores.json

## Tool-vs-tool discrepancies (the Class-3 diagnostic)

- **gene-5-mad/S/run_1**
  - rotamer outliers %: 8.82 (refine-log:DEPOSIT/final_refine.log) vs 2.94 (molprobity.out:molprobity_d29d04d1)
  - C-beta reported in different units - 0 count (molprobity.out:molprobity_d29d04d1) vs 1.41% (refine-log:DEPOSIT/final_refine.log); not directly comparable
- **gene-5-mad/S/run_3**
  - R-work: 0.1578 (refine-log:DEPOSIT/gene5_final_molprobity.log) vs 0.1514 (molprobity.out:molprobity_62be0f67)
  - rotamer outliers %: 2.9 (refine-log:DEPOSIT/gene5_final_molprobity.log) vs 5.8 (molprobity.out:molprobity_62be0f67)
