#!/usr/bin/env python3
"""
install.py — install the tutorials somewhere, then prove they work.

    python3 install.py ~/agent_course          # install + verify
    python3 install.py ~/agent_course --check  # verify only, install nothing
    python3 install.py --verify-only           # verify in place (no copy)

What "verify" means here: for every tutorial, we copy in the reference solution,
run the test suite, and confirm it passes — then restore the student stub. If this
script prints ALL CHECKS PASSED, the labs will work on this machine.

Standard library only. No pip, no network.
"""

import glob
import os as _os
import sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
import safe_io  # noqa: F401  survive a non-UTF-8 terminal
import argparse
import atexit
import os
import signal
import re
import shutil
import tempfile
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))

G, R, Y, C, B, X = ("\033[32m", "\033[31m", "\033[33m",
                    "\033[36m", "\033[1m", "\033[0m")
if not sys.stdout.isatty():
    G = R = Y = C = B = X = ""

TUTORIALS = ["tutorial_1", "tutorial_2", "tutorial_3", "tutorial_4"]

# tutorial -> (student file, solution file, test file, expected test count)
CODE_LABS = {
    "tutorial_1": ("decisions.py", "solutions/decisions_complete.py",
                   "test_decisions.py", 29),
    "tutorial_2": ("validators.py", "solutions/validators_complete.py",
                   "test_validators.py", 29),
    "tutorial_3": ("policy.py", "solutions/policy_complete.py",
                   "test_policy.py", 23),
}

results = []


def say(msg=""):
    print(msg)


def record(name, ok, detail=""):
    results.append((name, ok, detail))
    mark = G + "  PASS" + X if ok else R + "  FAIL" + X
    say("%s  %-42s %s" % (mark, name, detail))


# Keys that make a tutorial reach for the network. Tutorial 3's run_agent.py goes
# LIVE whenever ANTHROPIC_API_KEY is set, and guide.py shells out to it four times —
# so an installer run on a machine with a key exported makes real, billed API calls
# and crawls. Verification must exercise the OFFLINE path: it is testing that the
# tutorials work, not that the network does.
LIVE_KEYS = ("ANTHROPIC_API_KEY", "OPENAI_API_KEY", "GOOGLE_API_KEY")


# ── protecting the student stubs ──────────────────────────────────────────
# Verification deliberately overwrites each student file with its reference
# solution, runs the tests, then puts the stub back. Two ways that went wrong:
#
#   * Ctrl-C during a slow step. try/finally covers a clean KeyboardInterrupt,
#     but not a second Ctrl-C landing inside the handler, or a SIGTERM.
#   * Worse: a SECOND run after an interrupted one. It backs up whatever is on
#     disk — by then the SOLVED file — over the good stub backup, then faithfully
#     restores the solved file. The corruption becomes permanent and the recovery
#     data is destroyed. That is how a tree ends up with 0 'YOUR CODE HERE'
#     markers and no .stub-backup to explain it.
#
# So: recover any leftover backup BEFORE touching anything, and restore through
# atexit + signal handlers rather than relying on try/finally alone.
_STUB_BACKUPS = set()


def recover_stub_backups(root, announce=True):
    """A leftover .stub-backup means a previous run died mid-verification. It holds
    the ORIGINAL stub, so it is the thing to trust — restore it before any new
    backup can overwrite it."""
    found = []
    for dirpath, _dirs, files in os.walk(root):
        for f in files:
            if f.endswith(".stub-backup"):
                bak = os.path.join(dirpath, f)
                orig = bak[:-len(".stub-backup")]
                try:
                    shutil.move(bak, orig)
                    found.append(os.path.relpath(orig, root))
                except Exception:                                 # noqa: BLE001
                    pass
    if found and announce:
        record("recovered stubs from an interrupted run", True,
               ", ".join(sorted(found)))
    return found


def _restore_all_backups():
    """Put every stub back, whatever killed us."""
    for bak in list(_STUB_BACKUPS):
        orig = bak[:-len(".stub-backup")]
        try:
            if os.path.exists(bak):
                shutil.move(bak, orig)
        except Exception:                                         # noqa: BLE001
            pass
        _STUB_BACKUPS.discard(bak)


def backup_stub(sp):
    """Take the backup and register it for restoration on any exit path."""
    bak = sp + ".stub-backup"
    shutil.copy2(sp, bak)
    _STUB_BACKUPS.add(bak)
    return bak


def restore_stub(bak):
    if os.path.exists(bak):
        shutil.move(bak, bak[:-len(".stub-backup")])
    _STUB_BACKUPS.discard(bak)


atexit.register(_restore_all_backups)
for _sig in ("SIGINT", "SIGTERM", "SIGHUP"):
    if hasattr(signal, _sig):
        def _handler(signum, frame):
            _restore_all_backups()
            sys.stderr.write("\ninterrupted — student stubs restored.\n")
            sys.exit(130)
        try:
            signal.signal(getattr(signal, _sig), _handler)
        except (ValueError, OSError):                             # not main thread
            pass


def _utf8_env():
    """Subprocesses whose output we PARSE must speak UTF-8, whatever locale the
    student's terminal is in. Display degrades gracefully (safe_io); parsing
    must not degrade at all.

    Also scrubs the API keys, so verification is deterministic and free."""
    e = dict(os.environ)
    e["PYTHONIOENCODING"] = "utf-8"
    for k in LIVE_KEYS:
        e.pop(k, None)
    return e


def run(cmd, cwd, timeout=180):
    try:
        p = subprocess.run(cmd, cwd=cwd, timeout=timeout,
                           stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                           env=_utf8_env())
        return p.returncode, p.stdout.decode("utf-8", "replace")
    except subprocess.TimeoutExpired:
        return 1, "TIMEOUT after %ss" % timeout
    except Exception as e:                                    # noqa: BLE001
        return 1, "could not run: %s" % e


def strip_ansi(s):
    return re.sub(r"\033\[[0-9;]*m", "", s)


# ─────────────────────────────────────────────────────────────── environment

def verify_guide(root, t):
    """The guided walkthrough must: run headless, obey the 22-line screen
    contract, produce EXACTLY the reference functions, and pass every test."""
    import ast
    d = os.path.join(root, t)
    g = os.path.join(d, "guide.py")
    if not os.path.exists(g):
        return

    student, solution, tests, _ = CODE_LABS[t]
    sp = os.path.join(d, student)
    backup = backup_stub(sp)
    try:
        rc, out = run([sys.executable, "guide.py", "--reset"], d)
        rc, out = run([sys.executable, "guide.py", "--auto"], d, timeout=300)
        plain = strip_ansi(out)
        ok = rc == 0 and "Traceback" not in plain
        record("%s: guide.py --auto runs" % t, ok,
               "clean" if ok else "FAILED (rc=%d)" % rc)
        if not ok:
            return

        # screen contract: no panel may exceed 22 lines
        lines = plain.splitlines()
        starts = [i for i, l in enumerate(lines)
                  if l.startswith("\u2550") and i + 1 < len(lines)
                  and "STEP" in lines[i + 1]]
        worst, over = 0, 0
        for k, i in enumerate(starts):
            j = starts[k + 1] if k + 1 < len(starts) else len(lines)
            panel = lines[i:j]
            while panel and not panel[-1].strip():
                panel.pop()
            worst = max(worst, len(panel))
            if len(panel) > 22:
                over += 1
        record("%s: 22-line screen contract" % t, over == 0 and len(starts) > 0,
               "%d panels, longest %d lines" % (len(starts), worst)
               if not over else "%d PANELS OVERFLOW" % over)

        # the guided path must produce the reference implementation
        def fns(p):
            return {n.name: ast.dump(n)
                    for n in ast.parse(open(p).read()).body
                    if isinstance(n, ast.FunctionDef)}
        a, b = fns(sp), fns(os.path.join(d, solution))
        same = a == b
        record("%s: guided output == solutions/" % t, same,
               "all %d functions identical" % len(b) if same
               else "DIFFERS: %s" % sorted(set(a) ^ set(b)))

        # and every test must pass
        rc, out = run([sys.executable, tests], d)
        out = strip_ansi(out)
        m = re.search(r"(\d+) passed, (\d+) failed", out)
        if m:
            p_, f_ = int(m.group(1)), int(m.group(2))
        else:
            mm = re.search(r"All (\d+) tests passed", out)
            p_, f_ = (int(mm.group(1)), 0) if mm else (0, 1)
        record("%s: all tests pass after guide" % t, f_ == 0 and p_ > 0,
               "%d passed, %d failed" % (p_, f_))
    finally:
        # The guide's ACT step edits GUIDEME.md. --reset puts BOTH the student
        # file and any edited prompt back, or the next check sees a tightened
        # policy and the whole lesson is spoiled.
        run([sys.executable, "guide.py", "--reset"], d)
        if os.path.exists(backup):
            restore_stub(backup)


def verify_tutorial_4_modes(root):
    """The interaction-mode ladder: two addons, their solutions, the comparator,
    the fixtures it reads, and the guard that stops a self-contradictory GUIDEME.

    Every check below is one a student would hit in the first five minutes of the
    session, so a green install means the session can actually be run.
    """
    d = os.path.join(root, "tutorial_4")
    if not os.path.exists(os.path.join(d, "compare_runs.py")):
        return

    # (a) both mode contracts assemble
    ok = True
    for m in ("execute", "propose"):
        rc, _ = run([sys.executable, "assemble.py", m], d)
        ok = ok and rc == 0
    record("tutorial_4: interaction modes assemble", ok,
           "execute + propose build" if ok else "FAILED")

    # (b) the student version must NOT give away the answer Exercise 6 asks for,
    #     and --use-solutions must reveal it. If these two are the same file, the
    #     exercise is dead on arrival.
    _, stu = run([sys.executable, "assemble.py", "execute"], d)
    _, sol = run([sys.executable, "assemble.py", "execute", "--use-solutions"], d)
    split = ("DEPOSIT/superseded/" not in stu) and ("DEPOSIT/superseded/" in sol)
    record("tutorial_4: Exercise 6 case is still open", split,
           "addon withholds the channel; solutions names it"
           if split else "STUDENT ADDON LEAKS THE ANSWER")

    # (c) a self-contradictory constitution is refused, not silently built
    rc, _ = run([sys.executable, "assemble.py", "execute", "gate"], d)
    record("tutorial_4: execute+gate refused", rc == 2,
           "exit 2 with both conflicting quotes" if rc == 2
           else "NOT REFUSED (rc=%d) — a silent incoherent GUIDEME" % rc)

    # (d) the fixtures Panels 8/10 and Exercise 6 read
    fx = os.path.join(d, "fixtures")
    need = ["transcript_S.md", "transcript_E.md", "transcript_P.md",
            "deposit_listings.txt"]
    missing = [f for f in need if not os.path.exists(os.path.join(fx, f))]
    record("tutorial_4: mode fixtures present", not missing,
           "%d files" % len(need) if not missing else "MISSING %s" % ", ".join(missing))
    if missing:
        return

    # (e) Panel 10's measurement — the channel rule held on all six later runs
    with open(os.path.join(fx, "deposit_listings.txt")) as f:
        yes = f.read().count("FINAL_REPORT.md present: yes")
    record("tutorial_4: channel rule verified in fixtures", yes == 6,
           "%d/6 runs wrote the file" % yes)

    # (f) the comparator runs and finds the two states the panels are built on
    args = ["%s=%s" % (k, os.path.join(fx, v)) for k, v in
            (("shipped", "transcript_S.md"), ("execute", "transcript_E.md"),
             ("propose", "transcript_P.md"))]
    rc, out = run([sys.executable, "compare_runs.py"] + args, d, timeout=120)
    plain = strip_ansi(out)
    good = (rc == 0 and "Traceback" not in plain
            and "yes!" in plain          # present though nothing asked for it
            and "yes~" in plain)         # present under an unspecified name
    record("tutorial_4: comparator finds the unpredicted cells", good,
           "surprises + misnamed cells present" if good
           else "FAILED (rc=%d)" % rc)


def verify_tutorial_4_guide(root):
    """T4's guide has no code lab — verify the conductor's OFFLINE ladder,
    which is what runs when there is no live expert (and in this installer)."""
    d = os.path.join(root, "tutorial_4")
    if not os.path.exists(os.path.join(d, "guide.py")):
        return
    rc, out = run([sys.executable, "guide.py", "--auto"], d, timeout=300)
    plain = strip_ansi(out)
    ok = rc == 0 and "Traceback" not in plain
    record("tutorial_4: guide.py --auto (offline ladder)", ok,
           "clean" if ok else "FAILED (rc=%d)" % rc)
    if not ok:
        return

    lines = plain.splitlines()
    starts = [i for i, l in enumerate(lines)
              if l.startswith("\u2550") and i + 1 < len(lines)
              and "STEP" in lines[i + 1]]
    worst, over = 0, 0
    for k, i in enumerate(starts):
        j = starts[k + 1] if k + 1 < len(starts) else len(lines)
        panel = lines[i:j]
        while panel and not panel[-1].strip():
            panel.pop()
        worst = max(worst, len(panel))
        if len(panel) > 22:
            over += 1
    record("tutorial_4: 22-line screen contract", over == 0 and len(starts) > 0,
           "%d panels, longest %d lines" % (len(starts), worst)
           if not over else "%d PANELS OVERFLOW" % over)

    # A step hands over a GUIDEME and then tells the student what to watch for.
    # Those two must agree. They did not: after a rename, step 5 handed over a
    # 22-line interaction-mode addon while its panel promised "the SAME phases
    # every run" and "it writes a RUN_LOG.json" — neither of which that file
    # asks for. The panel was asserting what its own artifact did not support,
    # which is the failure this tutorial is about.
    WATCH = {"execute": (("triage", "phases"), ("RUN_LOG", "a run log")),
             "propose": (("triage", "phases"), ("RUN_LOG", "a run log"),
                         ("proposed plan", "a plan gate"),
                         ("r-free", "cross-validation"))}
    missing = []
    for variant, wants in WATCH.items():
        # Assemble it here rather than reading a staged file: the variants are
        # written later in the run, so a staged-file check passes or fails on
        # ordering rather than on content.
        rc, txt = run([sys.executable, "assemble.py", variant], d)
        if rc != 0 or len(txt) < 200:
            missing.append("%s: assemble.py failed" % variant)
            continue
        txt = txt.lower()
        for token, human in wants:
            if token.lower() not in txt:
                missing.append("%s promises %s, GUIDEME-%s.md never mentions it"
                               % (variant, human, variant))
    record("tutorial_4: each step's GUIDEME asks for what its panel promises",
           not missing, "execute + propose both cover their panels"
           if not missing else "; ".join(missing[:2]))

    # The tutorial teaches the product's own words, so its mode addons must stay
    # the product's own text. addons/mode_execute.md is GUIDEME_EXECUTE.md with a
    # tutorial header prepended; if the shipping wording changes, this should fail
    # loudly rather than let the course drift away from the expert it describes.
    drift = []
    for mode in ("execute", "propose"):
        addon = os.path.join(d, "addons", "mode_%s.md" % mode)
        if not os.path.exists(addon):
            drift.append("addons/mode_%s.md missing" % mode)
            continue
        body = open(addon, encoding="utf-8", errors="replace").read()
        anchor = "**Mode: %s (" % mode.upper()
        if anchor not in body:
            drift.append("mode_%s.md no longer opens on the shipping "
                         "'%s...' line" % (mode, anchor))
    record("tutorial_4: mode addons still carry the shipping GUIDEME text",
           not drift, "mode_execute + mode_propose match the product"
           if not drift else "; ".join(drift))

    # The ladder must CLIMB: shipped (no record) -> execute -> propose.
    #
    # This used to match the literal strings "5 of 7" and "7 of 7". That broke the
    # moment scoring changed to count only what a run reached — correctly, since
    # the tutorial tells the student to stop the run after a few minutes and the
    # later behaviours cannot appear. Compare the scores instead of spelling them:
    # what the check is named for is the climb, not two particular numbers.
    said_no_record = ("do NOT" in plain or "does NOT" in plain
                      or "not a record" in plain or "audit" in plain)
    # The score line may carry a suffix ("4 of 4 — everything it reached"), so
    # do not require the mark legend to follow immediately.
    scores = [(int(a), int(b)) for a, b in
              re.findall(r"(\d+) of (\d+)(?:\s|\u2014|—|[a-z])*?\(\u2713", plain)]
    climbs = False
    detail = "only %d score line(s) found" % len(scores)
    if said_no_record and len(scores) >= 2:
        (g1, t1), (g2, t2) = scores[0], scores[-1]
        climbs = (g2, g2 / float(t2 or 1)) > (g1, g1 / float(t1 or 1))
        detail = "%d of %d -> %d of %d" % (g1, t1, g2, t2)
    record("tutorial_4: the shipped -> execute -> propose ladder climbs",
           climbs, detail if climbs else "LADDER BROKEN (%s)" % detail)


# Every function the student writes, and a way to break it. If breaking it does
# NOT make the tests fail, the tests are not testing it — and a guide panel that
# reports success is lying. This exists because a hardcoded "6 checks passed"
# once shipped in tutorial_1.
MUTATIONS = {
    "tutorial_1": {
        "get_valid_programs": "    return []",
        "parse_llm_response": "    return None",
        "build_context": "    return {}",
        "decide_by_rules": "    return None",
        "decide": "    return None, 'rules'",
    },
    "tutorial_2": {
        "validate_program_name": "    return (True, None)",
        "validate_files_exist": "    return (True, [])",
        "validate_workflow_order": "    return (True, None, None)",
        "validate_no_loop": "    return (False, None)",
        "validate_decision": "    return (True, None, decision)",
    },
    "tutorial_3": {
        "load_policy": "    return {}",
        "needs_approval": "    return (False, None)",
        "check_scope": "    return (True, None)",
        "should_rollback": "    return (False, None)",
        "pre_act": "    return (True, None)",
    },
}


def verify_mutations(root, t):
    """Break each student function in turn. The tests MUST notice."""
    import ast
    if t not in MUTATIONS or t not in CODE_LABS:
        return
    d = os.path.join(root, t)
    student, solution, tests, _ = CODE_LABS[t]
    sp = os.path.join(d, student)
    backup = sp + ".mutation-backup"
    shutil.copy2(sp, backup)
    try:
        src = open(os.path.join(d, solution)).read()
        lines = src.splitlines()
        tree = ast.parse(src)
        survivors = []
        for fn, ret in MUTATIONS[t].items():
            node = next((n for n in tree.body
                         if isinstance(n, ast.FunctionDef) and n.name == fn), None)
            if not node:
                continue
            head = lines[:node.lineno - 1]
            tail = lines[node.end_lineno:]
            open(sp, "w").write(
                "\n".join(head + [lines[node.lineno - 1], ret] + tail) + "\n")
            rc, out = run([sys.executable, tests], d)
            out = strip_ansi(out)
            m = re.search(r"(\d+) passed, (\d+) failed", out)
            clean = re.search(r"All (\d+) tests passed", out)
            if clean or (m and int(m.group(2)) == 0):
                survivors.append(fn)
        record("%s: mutation testing (%d functions)"
               % (t, len(MUTATIONS[t])), not survivors,
               "every break is caught" if not survivors
               else "TESTS MISS: %s" % ", ".join(survivors))
    finally:
        restore_stub(backup)


def check_syntax(root):
    """Every .py file must at least COMPILE.

    A SyntaxError prints no "Traceback" line, so a broken file can sail past a
    naive crash check. It happened. Never again.
    """
    bad, n = [], 0
    for dp, dns, fs in os.walk(root):
        dns[:] = [d for d in dns if d != "__pycache__"]
        for f in fs:
            if not f.endswith(".py"):
                continue
            n += 1
            p = os.path.join(dp, f)
            try:
                compile(open(p, encoding="utf-8").read(), p, "exec")
            except SyntaxError as e:
                bad.append("%s line %s" % (os.path.relpath(p, root), e.lineno))
            except Exception as e:                            # noqa: BLE001
                bad.append("%s: %s" % (os.path.relpath(p, root), e))
    record("every .py file compiles", not bad,
           "%d files OK" % n if not bad else "BROKEN: " + "; ".join(bad[:3]))
    return not bad


def check_python():
    v = sys.version_info
    ok = (v.major, v.minor) >= (3, 9)
    record("Python >= 3.9", ok, "found %d.%d.%d" % (v.major, v.minor, v.micro))
    return ok


# ─────────────────────────────────────────────────────────────── install

def stage_tutorial_4(dest):
    """Pre-build the GUIDEME variants and clean per-run data dirs, so students
    (and the instructor, live) skip the mkdir/cp/assemble terminal steps."""
    d = os.path.join(dest, "tutorial_4")
    if not os.path.isdir(d):
        return
    # (a) assemble every named variant into tutorial_4/
    built = []
    for variant in ("workflow", "gated", "synced", "scoped", "governed",
                    "execute", "propose"):
        out = os.path.join(d, "GUIDEME-%s.md" % variant)
        rc, _ = run([sys.executable, "assemble.py", variant, "--out", out], d)
        if rc == 0 and os.path.exists(out):
            built.append(variant)
    record("tutorial_4: pre-built GUIDEME variants",
           len(built) == 7, "%s" % ", ".join(built) if built else "none built")

    # (b) give each live run its own clean data dir (only the data, nothing else)
    rs = os.path.join(d, "refined_start")
    staged = []
    if os.path.isdir(rs):
        # Every run dir the guide sends a student to. Staging only three of
        # these left runs/workflow and runs/governed EMPTY while step 5 told
        # the student the installer had built a clean data dir there.
        for stage in ("shipped", "execute", "propose"):
            rundir = os.path.join(d, "runs", stage)
            os.makedirs(rundir, exist_ok=True)
            for f in os.listdir(rs):
                src = os.path.join(rs, f)
                if os.path.isfile(src):
                    shutil.copy2(src, os.path.join(rundir, f))
            staged.append(stage)
    record("tutorial_4: staged clean per-run data dirs",
           len(staged) == 3, "runs/%s" % ", runs/".join(staged) if staged else "none")


def install(dest, keep_runs=False):
    """Copy the tutorials to dest, replacing what is there.

    `keep_runs` preserves each tutorial's runs/ directory across the replace.
    That is where a student's own agent output lives — tutorial 4's
    runs/{shipped,execute,propose}/RUN_LOG.json is the thing the guide audits —
    and a plain re-install deletes it, because the copy starts with rmtree.
    Upgrading the code should not cost you the run you spent minutes producing.
    """
    dest = os.path.abspath(os.path.expanduser(dest))

    # Installing onto the tree we are copying FROM cannot deliver newer code —
    # src and dst are the same files. It used to be worse than pointless: the
    # copy began by deleting dst, so it destroyed the source and then failed.
    # Now it is neither. Say what happened, say what to run instead, and go on
    # to verify, which is what "update my install" wants when there is nothing
    # to copy.
    if os.path.realpath(dest) == os.path.realpath(HERE):
        say("\n%sSource and destination are the same tree.%s" % (Y, X))
        say("  install.py is running from %s," % HERE)
        say("  so there is no newer code here to copy in. Nothing deleted.")
        say("")
        say("  If you unpack each new package over this directory, that IS the")
        say("  update — tar overwrites the code and leaves runs/ alone:")
        say("      %star xzf <new package>.tgz -C %s%s" % (B, dest, X))
        say("      %spython3 install.py --verify-only%s" % (B, X))
        say("")
        say("  --keep-runs is for installing into a DIFFERENT directory:")
        say("      %scd <where you unpacked it> && python3 install.py "
            "--keep-runs ~/somewhere_else%s" % (B, X))
        say("")
        say("  Verifying what is here instead.")
        say("")
        return HERE

    say("%sInstalling to %s%s" % (B, dest, X))
    if keep_runs:
        say("%s  keeping any existing runs/ directories%s" % (C, X))
    os.makedirs(dest, exist_ok=True)
    for t in TUTORIALS:
        src = os.path.join(HERE, t)
        if not os.path.isdir(src):
            record("copy %s" % t, False, "not found in %s" % HERE)
            continue
        dst = os.path.join(dest, t)
        # Belt and braces: the same check per tutorial, in case dest and HERE
        # differ but a single tutorial resolves to the same place (a symlink).
        if os.path.exists(dst) and os.path.realpath(src) == os.path.realpath(dst):
            record("copy %s" % t, True,
                   "already in place — same directory, nothing to copy")
            continue
        saved = None
        if keep_runs and os.path.isdir(os.path.join(dst, "runs")):
            saved = tempfile.mkdtemp(prefix="runs_keep_")
            shutil.move(os.path.join(dst, "runs"), os.path.join(saved, "runs"))
        # Copy to a sibling first, then swap. If the copy fails for any reason
        # the existing directory is still there — deleting before copying is
        # what turns one bad argument into a lost tutorial.
        staging = dst + ".installing"
        if os.path.exists(staging):
            shutil.rmtree(staging, ignore_errors=True)
        shutil.copytree(src, staging,
                        ignore=shutil.ignore_patterns("__pycache__", "*.pyc",
                                                      ".DS_Store", "._*"))
        if os.path.exists(dst):
            shutil.rmtree(dst)
        os.rename(staging, dst)
        if saved:
            # merge the student's runs back over the fresh tree. The data files
            # each run dir needs are re-staged during verification, so putting
            # the old tree back cannot leave a run dir short of its inputs.
            old = os.path.join(saved, "runs")
            for dirpath, _dirnames, filenames in os.walk(old):
                rel = os.path.relpath(dirpath, old)
                target = os.path.join(dst, "runs", rel) if rel != "." \
                    else os.path.join(dst, "runs")
                os.makedirs(target, exist_ok=True)
                for fn in filenames:
                    shutil.copy2(os.path.join(dirpath, fn),
                                 os.path.join(target, fn))
            kept = sum(len(f) for _, _, f in os.walk(old))
            shutil.rmtree(saved, ignore_errors=True)
            record("keep %s/runs" % t, True, "%d file(s) preserved" % kept)
        n = sum(len(f) for _, _, f in os.walk(dst))
        record("copy %s" % t, True, "%d files" % n)
    readme = os.path.join(HERE, "README.md")
    if os.path.exists(readme):
        shutil.copy2(readme, os.path.join(dest, "README.md"))
        record("copy README.md", True, "start here")
    stage_tutorial_4(dest)
    return dest


# ─────────────────────────────────────────────────────────────── verify

def verify_code_lab(root, t):
    """Run the test suite against the reference solution, then restore the stub."""
    d = os.path.join(root, t)
    student, solution, tests, expected = CODE_LABS[t]
    sp = os.path.join(d, student)
    backup = sp + ".stub-backup"

    if not os.path.exists(os.path.join(d, solution)):
        record("%s: solution present" % t, False, solution + " missing")
        return
    # count stubs BEFORE we touch anything — students must get unsolved files
    stubs = open(sp).read().count("YOUR CODE HERE")
    record("%s: student stub intact" % t, stubs == 4,
           "%d 'YOUR CODE HERE' markers (want 4)" % stubs)

    backup = backup_stub(sp)
    try:
        shutil.copy2(os.path.join(d, solution), sp)
        rc, out = run([sys.executable, tests], d)
        out = strip_ansi(out)
        m = re.search(r"(\d+)\s+passed,\s+(\d+)\s+failed", out)
        if m:
            passed, failed = int(m.group(1)), int(m.group(2))
        else:
            passed = len(re.findall(r"^\s*PASS", out, re.M))
            failed = len(re.findall(r"^\s*FAIL", out, re.M))
        ok = (failed == 0 and passed >= expected and rc == 0)
        record("%s: %s" % (t, tests), ok,
               "%d passed, %d failed (want >=%d, 0)" % (passed, failed, expected))
    finally:
        restore_stub(backup)             # always restore the stub

    # the runner must not crash — and a SyntaxError prints no "Traceback",
    # so check the return code as well.
    rc, out = run([sys.executable, "run_agent.py"], d)
    ok = rc == 0 and "Traceback" not in out and "SyntaxError" not in out
    record("%s: run_agent.py runs" % t, ok,
           "clean exit" if ok else "FAILED (rc=%d)" % rc)


def verify_tutorial_3_live(root):
    d = os.path.join(root, "tutorial_3")
    rc, out = run([sys.executable, "test_live.py"], d)
    out = strip_ansi(out)
    m = re.search(r"(\d+)\s+passed,\s+(\d+)\s+failed", out)
    passed, failed = (int(m.group(1)), int(m.group(2))) if m else (0, 1)
    record("tutorial_3: test_live.py", failed == 0 and passed >= 18,
           "%d passed, %d failed" % (passed, failed))

    # --demo must work with NO api key at all
    env_backup = os.environ.pop("ANTHROPIC_API_KEY", None)
    try:
        rc, out = run([sys.executable, "run_agent.py", "--demo"], d)
        ok = "Traceback" not in out and rc == 0
        record("tutorial_3: --demo without API key", ok,
               "works offline" if ok else "FAILED")
    finally:
        if env_backup is not None:
            os.environ["ANTHROPIC_API_KEY"] = env_backup


def verify_tutorial_4_expert(root):
    d = os.path.join(root, "tutorial_4")

    # the assembler must build the whole named ladder
    for variant in ("workflow", "gated", "synced", "scoped", "governed"):
        rc, out = run([sys.executable, "assemble.py", variant], d)
        ok = rc == 0 and "WORKFLOW MODULE" in out   # workflow rides along in all
        if not ok:
            record("tutorial_4: assemble %s" % variant, False, "failed")
            return
    record("tutorial_4: assemble workflow..governed", True,
           "all five named variants build")

    # no GUIDEME_base identity should leak into any assembled variant
    rc, wf = run([sys.executable, "assemble.py", "workflow"], d)
    clean = "Principal Automation Scientist" not in wf   # base identity dropped
    record("tutorial_4: base identity is not supplied", clean,
           "assembly starts at the workflow module" if clean
           else "BASE IDENTITY LEAKING")

    # workflow variant = guidance + a run log, but NO governance teeth yet
    has_wf = "WORKFLOW MODULE" in wf and "Run Log" in wf
    no_teeth = "The Execution Gate" not in wf and "Stay in Scope" not in wf
    record("tutorial_4: workflow variant is guidance + log only",
           has_wf and no_teeth,
           "workflow + run_log, no gate/scope" if (has_wf and no_teeth)
           else "WRONG MODULE SET")

    # the shipped-baseline prompts must carry the data-safety floor
    import glob as _glob
    sp = _glob.glob(os.path.join(d, "shipped_prompt", "*.md"))
    floor_ok = bool(sp) and all(
        ("may not disregard" in open(f).read() or "harm to the data" in open(f).read())
        for f in sp)
    record("tutorial_4: shipped prompts keep the data-safety floor", floor_ok,
           "do-no-harm floor present in all shipped prompts" if floor_ok
           else "SHIPPED PROMPT MISSING FLOOR")

    # base_prompt.md must ship and carry the real base principles students read
    bp = os.path.join(d, "base_prompt.md")
    bp_ok = os.path.exists(bp) and all(
        k in open(bp).read() for k in
        ("Evidence over assertion", "Physical realism", "cross-validation"))
    record("tutorial_4: base_prompt.md ships with the real principles", bp_ok,
           "students can read the expert's shipped instructions" if bp_ok
           else "BASE PROMPT MISSING OR INCOMPLETE")

    # the checker must separate governed from ungoverned on the REAL logs
    fx = os.path.join(d, "fixtures")
    expect = "gate,coot_sync,scope,cross_validation,source_citation,closure"
    rc, out = run([sys.executable, "check_run.py",
                   os.path.join(fx, "RUN_LOG_E_real.json"),
                   "--expect", expect], d)
    record("tutorial_4: checker PASSes the governed run", "PASS" in strip_ansi(out),
           "real run E -> 7/7")

    rc, out = run([sys.executable, "check_run.py",
                   os.path.join(fx, "RUN_LOG_log_only.json"),
                   "--expect", expect], d)
    out = strip_ansi(out)
    record("tutorial_4: checker FAILs the control", "FAIL" in out,
           "log-only -> governance absent")

    rc, out = run([sys.executable, "check_run.py",
                   os.path.join(d, "no_such_RUN_LOG.json")], d)
    record("tutorial_4: missing log reported honestly",
           "no audit trail" in strip_ansi(out).lower(),
           "the shipped run leaves nothing to audit")

    # the governance modules must be OPERATIONAL — real production guidance, not
    # vague starters (the expert refuses to run on placeholders). Check the two
    # that were previously stubs now carry concrete, executable rules.
    eh = os.path.join(d, "addons", "error_handling.md")
    eh_txt = open(eh).read() if os.path.exists(eh) else ""
    eh_ok = ("STARTER" not in eh_txt
             and "two retries" in eh_txt.lower() or "at most **two**" in eh_txt
             or "retry is forbidden" in eh_txt.lower())
    record("tutorial_4: error_handling is operational", eh_ok,
           "bounded retries + technical/scientific split" if eh_ok
           else "STILL A STARTER")
    cv = os.path.join(d, "addons", "cross_validation.md")
    cv_txt = open(cv).read() if os.path.exists(cv) else ""
    cv_ok = ("STARTER" not in cv_txt and "cross_validation_decisions" in cv_txt
             and "revert" in cv_txt.lower()
             and ("gap widens" in cv_txt.lower() or "gap" in cv_txt.lower()))
    record("tutorial_4: cross_validation arbiter is operational", cv_ok,
           "measured test + auto-revert + logged decision" if cv_ok
           else "STILL A STARTER")

    # the workflow variant must be the REAL pipeline minus governance — all six
    # phases, the structured run log, and NONE of the governance teeth.
    rc, wf = run([sys.executable, "assemble.py", "workflow"], d)
    phases = sum(("Phase %d" % i) in wf for i in range(6))
    has_log = "RUN_LOG.json" in wf and "FINAL" in wf
    no_teeth = ("Execution Gate" not in wf and "Stay in Scope" not in wf
                and "Cross-Validation" not in wf and "Coot Synchronization" not in wf)
    wf_ok = phases == 6 and has_log and no_teeth and "STARTER" not in wf
    record("tutorial_4: workflow is the real pipeline minus governance", wf_ok,
           "6 phases + run log, no governance teeth" if wf_ok
           else "workflow variant is thin or leaks governance")

    # the refined_start data must ship intact: files present, MTZ valid,
    # and the model at the R-factors the whole tutorial cites.
    rs = os.path.join(d, "refined_start")
    files_ok = all(os.path.exists(os.path.join(rs, f))
                   for f in ("model.pdb", "data.mtz", "sequence.dat"))
    mtz_ok = False
    model_ok = False
    if files_ok:
        with open(os.path.join(rs, "data.mtz"), "rb") as fh:
            mtz_ok = fh.read(4) == b"MTZ "
        pdb = open(os.path.join(rs, "model.pdb")).read()
        model_ok = ("0.1975" in pdb and "0.2401" in pdb and "C 1 2 1" in pdb)
    record("tutorial_4: refined_start data ships intact",
           files_ok and mtz_ok and model_ok,
           "model+mtz+seq, valid MTZ, R-work 0.1975/R-free 0.2401"
           if (files_ok and mtz_ok and model_ok) else "MISSING OR CORRUPT")


def verify_shipped_policy(root):
    """The shipped GUIDEME must be LOOSE, or Exercise 4's punchline is spoiled."""
    for t in ("tutorial_3",):
        p = os.path.join(root, t, "GUIDEME.md")
        txt = open(p).read() if os.path.exists(p) else ""
        tol = re.search(r"^r_free_tolerance:\s*([\d.]+)", txt, re.M)
        gap = re.search(r"^max_gap:\s*([\d.]+)", txt, re.M)
        ok = bool(tol and gap and float(tol.group(1)) > 0.02
                  and float(gap.group(1)) > 0.10)
        record("%s: shipped GUIDEME is loose" % t, ok,
               "tol=%s max_gap=%s (overfit must slip through)"
               % (tol.group(1) if tol else "?", gap.group(1) if gap else "?"))


# ─────────────────────────────────────────────────────────────── main

def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("dest", nargs="?", help="where to install")
    ap.add_argument("--paranoid", action="store_true",
                    help="also mutation-test every student function (slower)")
    ap.add_argument("--check", action="store_true",
                    help="verify an existing install; copy nothing")
    ap.add_argument("--verify-only", action="store_true",
                    help="verify the tutorials right here, in place")
    ap.add_argument("--keep-runs", action="store_true",
                    help="update the code but preserve existing runs/ dirs "
                         "(your agent output and RUN_LOG.json files)")
    a = ap.parse_args()
    global PARANOID
    PARANOID = a.paranoid

    say("%s%s" % (B, "=" * 62))
    say("  Building AI Agents for Crystallography — installer")
    say("%s%s" % ("=" * 62, X))
    say()

    if not check_python():
        say("\n%sPython 3.9+ is required. Stopping.%s" % (R, X))
        sys.exit(1)

    if a.verify_only:
        root = HERE
        say("%sVerifying in place: %s%s\n" % (B, root, X))
    elif a.dest:
        root = a.dest if a.check else install(a.dest, keep_runs=a.keep_runs)
        root = os.path.abspath(os.path.expanduser(root))
        say()
    else:
        ap.error("give a destination, or use --verify-only")

    say("%sVerifying — running every test suite against the reference solutions%s"
        % (B, X))
    say()

    # A leftover .stub-backup means a previous run was killed mid-verification.
    # Put those stubs back BEFORE anything can back up a solved file over them.
    recover_stub_backups(root)

    check_syntax(root)

    for t in ("tutorial_1", "tutorial_2", "tutorial_3"):
        if os.path.isdir(os.path.join(root, t)):
            verify_code_lab(root, t)
            verify_guide(root, t)
            if PARANOID:
                verify_mutations(root, t)
    if os.path.isdir(os.path.join(root, "tutorial_3")):
        verify_tutorial_3_live(root)
    verify_shipped_policy(root)
    if os.path.isdir(os.path.join(root, "tutorial_4")):
        verify_tutorial_4_expert(root)
        verify_tutorial_4_modes(root)
        verify_tutorial_4_guide(root)

    # tidy up after ourselves: running the suites creates __pycache__
    for dp, dns, _ in os.walk(root):
        for dn in list(dns):
            if dn == "__pycache__":
                shutil.rmtree(os.path.join(dp, dn), ignore_errors=True)
                dns.remove(dn)

    # a .stub-backup left behind would mean a student gets a SOLVED file
    strays = [os.path.join(dp, f)
              for dp, _, fs in os.walk(root) for f in fs
              if f.endswith(".stub-backup")]
    record("student files restored (no solutions left behind)", not strays,
           "clean" if not strays else "%d files still solved!" % len(strays))

    say()
    passed = sum(1 for _, ok, _ in results if ok)
    failed = len(results) - passed
    say("%s%s" % (B, "=" * 62))
    if failed:
        say("%s  %d checks FAILED%s (%d passed)" % (R, failed, X, passed))
        say("%s" % ("=" * 62))
        say("\nFailures:")
        for n, ok, d in results:
            if not ok:
                say("  %s- %s: %s%s" % (R, n, d, X))
        sys.exit(1)

    say("%s  ALL %d CHECKS PASSED%s — the tutorials will work on this machine."
        % (G, passed, X))
    say("%s%s" % ("=" * 62, X))
    if not a.verify_only:
        say("\nStart here:  %s%s/README.md%s" % (C, root, X))
        say("Then:        cd %s/tutorial_1 && cat README.md" % root)


if __name__ == "__main__":
    main()
