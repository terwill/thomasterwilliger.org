"""
guide.py — Tutorial 1, guided walkthrough.

    python3 guide.py

Everything is pre-filled. You press Enter to advance, and twice you have to
commit to a prediction before the machine will move.

The code goes into decisions.py in full. The SCREEN shows only the lines that
carry the idea. Open decisions.py any time to read the rest.
"""

import os as _os
import sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
import safe_io  # noqa: F401  survive a non-UTF-8 terminal
import contextlib
import io
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from guide_engine import (Guide, main, fresh, run_exercise_tests,   # noqa: E402
                          run_filtered, said, GRN, RED, YEL, BOLD, RST, DIM)

HERE = os.path.dirname(os.path.abspath(__file__))

CFG = json.load(open(os.path.join(HERE, "programs.json")))
PROGS = CFG["programs"]

STATE0 = {"available_files": {"data.mtz", "sequence.fa"},
          "current_phase": "analyze", "program_defs": PROGS,
          "history": [], "metrics_history": []}

STATE_REF = {"available_files": {"data.mtz", "sequence.fa", "placed_model.pdb"},
             "current_phase": "refine", "program_defs": PROGS,
             "history": [{"program": "analyze_data"}, {"program": "phaser"},
                         {"program": "place_model"}],
             "metrics_history": [{"r_free": 0.34}]}


def quiet(fn, *a):
    """The functions print their own debug lines. Not on my screen they don't."""
    with contextlib.redirect_stdout(io.StringIO()):
        return fn(*a)


def decisions_of(g, mode):
    """The actual decisions an agent made: [(cycle, program, source), ...]."""
    import re as _re
    import subprocess
    from guide_engine import _utf8_env
    cmd = [sys.executable, "run_agent.py"] + ([mode] if mode else [])
    p = subprocess.run(cmd, cwd=g.cwd, capture_output=True, timeout=120,
                       env=_utf8_env())
    txt = _re.sub(r"\033\[[0-9;]*m", "",
                  (p.stdout + p.stderr).decode("utf-8", "replace"))
    out, cyc = [], 0
    for line in txt.splitlines():
        m = _re.match(r"\s*CYCLE (\d+)", line)
        if m:
            cyc = int(m.group(1))
        m = _re.search(r"Decision \[(\w+)\]: run '([^']*)'", line)
        if m:
            out.append((cyc, m.group(2), m.group(1)))
    return out


def _vis(t):
    """Visible width — ANSI escapes are bytes, not columns."""
    import re as _re
    return len(_re.sub(r"\033\[[0-9;]*m", "", t))


def columns(rows, ncol, width=17):
    """Lay decisions out as a PATH, not a log. Reads down the columns."""
    n = len(rows)
    per = (n + ncol - 1) // ncol
    lines = []
    for r in range(per):
        cells = []
        for c in range(ncol):
            i = c * per + r
            cell = rows[i] if i < n else ""
            pad = max(0, width - _vis(cell))
            cells.append(cell + " " * pad)
        lines.append("    " + "".join(cells).rstrip())
    return lines


# What each exercise's tests actually CHECK — "6/6 passed" means nothing to a
# student who did not write the code. Naming the edge cases does.
CHECKS = {
    1: "phase gating, missing inputs, nothing-is-valid",
    2: "fences, prose, invented names, bad JSON",
    3: "every field the LLM needs, and no more",
    4: "every phase, dead ends, the stop condition",
    5: "LLM accepted, LLM refused, fallback fires",
}


def _tests(g, n):
    p, f = run_exercise_tests(g.test_file, n, cwd=g.cwd)
    what = CHECKS.get(n, "")
    if f == 0 and p > 0:
        return "  %s✓ %d checks: %s%s" % (GRN, p, what, RST)
    return "  %s✗ %d passed, %d FAILED%s" % (RED, p, f, RST)


# ══════════════════════════════════════════════════════════════════ steps

def s2_body(g):
    hits = run_filtered(["run_agent.py", "--max=3"],
                        [r"Decision \[", r"Failed:"], cwd=g.cwd, limit=4)
    return ([
        "  The loop, the tools and the state all work already.",
        "  Only the DECISION is missing. Watch:",
        "",
    ] + ["    %s%s%s" % (DIM, h, RST) for h in hits[:4]] + [
        "",
        "  An agent with no decision-making is not an agent.",
        "  It is a for-loop with an error message.",
    ])


def s4_body(g):
    m = fresh("decisions")
    a = quiet(m.get_valid_programs, "analyze", PROGS)
    b = quiet(m.get_valid_programs, "refine", PROGS)
    return [
        "  There are 5 programs. At the START (phase = analyze):",
        "",
        "      → %s" % ", ".join(a),
        "",
        "  MID-RUN (phase = refine, a model has been placed):",
        "",
        "      → %s" % ", ".join(b),
        "",
        "  The LLM never chooses from all five. It only ever",
        "  sees what is legal right now.",
        "",
        _tests(g, 1),
    ]


REPLIES = [
    ('{"program": "refine", "reasoning": "R-free is still high."}',
     "clean JSON"),
    ('```json\n{"program": "validate", "reasoning": "R-free plateaued."}\n```',
     "wrapped in ``` fences"),
    ("Let me think... I'd suggest running find_model to locate\n"
     "a starting model, then refining.",
     "chatty prose + invented name"),
]


def s6_body(g):
    m = fresh("decisions")
    out = []
    for i, (raw, label) in enumerate(REPLIES, 1):
        r = quiet(m.parse_llm_response, raw)
        if r:
            verdict = "%s✓ ACCEPTED → %s%s" % (GRN, r["program"], RST)
        else:
            verdict = "%s✗ REFUSED (returns None)%s" % (YEL, RST)
        out += ["  %d. %-29s%s" % (i, label, verdict)]
    out += [
        "",
        "  Reply 3 in full — %sread what it says%s:" % (BOLD, RST),
        "",
    ] + said(REPLIES[2][0], 50, 2) + [
        "",
        "  It is %sperfectly reasonable prose%s. It is also not JSON," % (BOLD, RST),
        "  and %sfind_model is not a program%s — that is the phase" % (YEL, RST),
        "  name; the real one is %sphenix.phaser%s. The LLM made it" % (GRN, RST),
        "  up, and your code refused it instead of crashing.",
        "",
        _tests(g, 2),
    ]
    return out


def s8_body(g):
    m = fresh("decisions")
    ctx = quiet(m.build_context, STATE_REF)
    keys = ["current_phase", "available_files", "valid_programs",
            "recent_history", "latest_metrics"]
    rows = []
    for k in keys:
        v = ctx.get(k)
        if isinstance(v, list):
            v = ", ".join(str(x) for x in v)
        v = str(v)
        if len(v) > 34:                     # never cut a filename in half
            parts = [p.strip() for p in v.split(",")]
            kept, n = [], 0
            for p in parts:
                if n + len(p) + 2 > 30:
                    break
                kept.append(p)
                n += len(p) + 2
            v = ", ".join(kept) + (" +%d more" % (len(parts) - len(kept))
                                   if len(kept) < len(parts) else "")
        rows.append("    %s%-16s %s%s" % (DIM, k + ":", v, RST))
    return ([
        "  This — and ONLY this — is what the LLM sees:",
        "",
    ] + rows + [
        "",
        "  No memory. No file access. If it is not in there, the",
        "  LLM does not know it.",
        "",
        _tests(g, 3),
    ])


def s10_body(g):
    d = decisions_of(g, "--rules")
    rows = ["%2d  %s" % (c, p) for c, p, _ in d]
    hits = run_filtered(["run_agent.py", "--rules"],
                        [r"Result:", r"Final R-free:"], cwd=g.cwd, limit=2)
    return ([
        "  %sAGENT A — rules only.%s No LLM is called at all." % (BOLD, RST),
        "  Every decision came from the rules you wrote:",
        "",
    ] + columns(rows, 2) + [
        "",
    ] + ["    %s" % h for h in hits] + [
        "",
        "  It works. It is also rigid: %sthe same path, every time%s," % (BOLD, RST),
        "  forever. It cannot read a map, weigh a trade-off, or",
        "  notice that something is odd.",
        "",
        _tests(g, 4),
    ])


# ── moment A ─────────────────────────────────────────────────────
S11_Q = [
    "  %sAGENT B — LLM only.%s Agent A (rules) just finished in" % (BOLD, RST),
    "  8 cycles. Now we throw the rules away: whatever the LLM",
    "  says, we run. No whitelist check, no fallback, no net.",
    "",
    "  Before you press Enter — you have SEEN this LLM's output.",
    "  At step 7, of its three replies:",
    "",
    "      1  clean JSON               → usable",
    "      2  ``` fenced               → usable",
    "      3  invented find_model      → UNUSABLE",
    "",
    "  ~1 reply in 3 is unusable. The agent gets 12 cycles to",
    "  make 8 correct decisions, in the right order.",
    "",
    "  Does agent B finish the pipeline?",
]


def s11_reveal(g, answer):
    d = decisions_of(g, "--llm")
    rows = []
    for c, p, src in d:
        mark = " %s✗%s" % (RED, RST) if src == "FAILED" else ""
        rows.append("%2d %s%s" % (c, p[:13], mark))
    lead = ("  You said %s. %sRight — but not for the reason you think.%s"
            % (answer.upper(), GRN, RST) if answer == "n" else
            "  You said %s. %sIt does not finish — and look why.%s"
            % (answer.upper(), YEL, RST))
    return ([lead, ""] + columns(rows, 2, 26) + [
        "",
        "   c6  it invented %srefine_model%s (not a real program)" % (YEL, RST),
        "   c7  prose. No JSON at all.",
        "",
        "  %sNow look at 8 through 12.%s It never proposes validate." % (BOLD, RST),
        "  %sIt never stops%s — and knowing when to stop is a" % (YEL, RST),
        "  decision too.",
    ])


def s13_body(g):
    d = decisions_of(g, None)          # hybrid
    rows = []
    for c, p, src in d:
        if src == "RULES":
            rows.append("%2d %-13s %sRULES%s" % (c, p[:13], YEL, RST))
        else:
            rows.append("%2d %-13s %sLLM%s" % (c, p[:13], DIM, RST))
    hits = run_filtered(["run_agent.py", "--compare"],
                        [r"Rules only", r"LLM only", r"Hybrid"], cwd=g.cwd, limit=3)
    return ([
        "  %sAGENT C — the LLM proposes, your rules verify.%s" % (BOLD, RST),
    ] + columns(rows, 2, 26) + [
        "",
        "  %sCycles 6 and 7 are where agent B DIED.%s The rules" % (YEL, RST),
        "  quietly took over and the run kept going.",
        "",
        "  %-16s%-12s%-9s%s" % ("Strategy", "Completed?", "Cycles", "R-free"),
    ] + ["  %s" % h for h in hits] + [
        "",
        "  %sMostly ordinary code, around one bounded decision.%s" % (BOLD, RST),
        _tests(g, 5),
    ])


STEPS = [
    dict(n=1, kind="IDEA", title="OVERVIEW — what you are about to build", body=[
        "  THE JOB — solve a structure with no human picking",
        "  each step:",
        "",
        "    analyze → find_model → place_model → refine → validate",
        "",
        "  Something must choose the right program every cycle.",
        "  That is the agent. %sYou fill in decisions.py%s, in 15 steps." % (BOLD, RST),
        "",
        "  %sWHAT IS REAL HERE: nothing.%s The LLM replies are" % (YEL, RST),
        "  hand-written; the R-free values come from a mock. No",
        "  model is called and no data is refined.",
        "",
        "  They are written to be %sfaithful%s — every failure you" % (BOLD, RST),
        "  meet is one real LLMs really make — but ground truth",
        "  comes later: a real gene-5 agent run in Tutorial 3,",
        "  and real Phenix and Coot in Tutorial 4.",
    ], prompt="[Enter] to see the loop"),

    dict(n=2, kind="IDEA", title="a hole where the decision goes", body=[
        "  %sONE WORD FIRST.%s \"The LLM\" = the language model." % (BOLD, RST),
        "  \"The model\" = your ATOMIC model. Never the same",
        "  thing. I will always say LLM.",
        "",
        "  This is run_agent.py, stripped to its bones:",
        "",
        "      state = {phase: 'analyze', files: [data, seq]}",
        "",
        "      for cycle in range(12):",
        "          d = decide(state)          %s← decisions.py%s" % (YEL, RST),
        "          if d is None: break",
        "          result = run_program(d)    ← already works",
        "          state  = update(state, result)",
        "",
        "  Every line but decide() is ordinary code. decide() is",
        "  empty. Watch what an agent with no decision does.",
    ], prompt="[Enter] to run the broken agent"),

    dict(n=3, kind="RUN", title="the agent, broken", body=s2_body,
         prompt="[Enter] to fix it"),

    dict(n=4, kind="IDEA", title="get_valid_programs", fill="get_valid_programs", body=[
        "  THE GOAL",
        "    Which programs may we run RIGHT NOW, given the state",
        "    we are in? You cannot refine without an atomic model.",
        "",
        "  WHY IT MATTERS",
        "    Never ask the LLM an open question. Hand it a list",
        "    YOU built. Most \"hallucinations\" are just a question",
        "    that was too open.",
        "",
        "  THE IDEA                      full code → decisions.py",
        "",
        "      for name, defn in program_defs.items():",
        "          if phase in defn['valid_phases']:   ← legal now?",
        "              valid.append(name)",
        "",
        "  This is the whitelist the LLM must choose from.",
    ], prompt="[Enter] to see which programs are legal when"),

    dict(n=5, kind="RUN", title="the whitelist, live", body=s4_body),

    dict(n=6, kind="IDEA", title="parse_llm_response", fill="parse_llm_response", body=[
        "  THE GOAL",
        "    Turn whatever text the LLM sent back into a decision",
        "    we can act on — or refuse it.",
        "",
        "  Three replies, in the three shapes LLMs really send:",
        "",
        "    1  {\"program\": \"refine\", ...}          clean JSON",
        "    2  ```json { ... } ```                 fenced",
        "    3  \"Let me think... find_model\"        prose",
        "",
        "  THE IDEA                   full code → decisions.py",
        "",
        "      text = strip_fence(text)           ← handles 2",
        "      obj  = json.loads(find_json(text)) ← handles 3",
        "      if obj['program'] not in PROGRAMS:",
        "          return None                    ← refuse it",
    ], prompt="[Enter] to parse those three replies"),

    dict(n=7, kind="RUN", title="what it does", body=s6_body),

    dict(n=8, kind="IDEA", title="build_context", fill="build_context", body=[
        "  WHY",
        "    The LLM remembers NOTHING between cycles. Every",
        "    cycle you hand it the whole world, or it has none.",
        ""
        "",
        "  THE IDEA                      full code → decisions.py",
        "",
        "      phase, files, history, valid programs, metrics",
        "               ↓",
        "      one dict — the LLM's whole world, this cycle",
        "",
        "  Truth lives in your code. The context is just a VIEW",
        "  of it that you render, fresh, every cycle.",
    ], prompt="[Enter] to see exactly what the LLM sees"),

    dict(n=9, kind="RUN", title="the LLM's entire world", body=s8_body),

    dict(n=10, kind="IDEA", title="decide_by_rules", fill="decide_by_rules", body=[
        "  %sWE ARE ABOUT TO RUN AN EXPERIMENT.%s Three agents, same" % (BOLD, RST),
        "  data, same tools. The ONLY difference is who decides:",
        "",
        "      A.  rules only   — no LLM at all      (next)",
        "      B.  LLM only     — no rules at all    (step 12)",
        "      C.  both         — LLM proposes,      (step 14)",
        "                         rules verify",
        "",
        "  First, A. Build the thing that does not need an LLM.",
        "",
        "  THE IDEA                   full code → decisions.py",
        "",
        "      valid = get_valid_programs(...)",
        "      return valid[0]      ← first legal move, always",
        "",
        "  Deterministic. Boring. Correct. Never clever.",
    ], prompt="[Enter] to run agent A — rules only"),

    dict(n=11, kind="RUN", title="agent A — rules only, no LLM", body=s10_body),

    dict(n=12, kind="PREDICT", title="YOUR PREDICTION", body=S11_Q,
         options=["y", "n"], answer="n",
         reveal_title="the answer", reveal=s11_reveal,
         reveal_prompt="[Enter] for the fix"),

    dict(n=13, kind="IDEA", title="decide — propose, then verify", fill="decide", body=[
        "  WHY",
        "    The LLM is good at choosing. It is bad at being",
        "    trusted. So: let it propose, then CHECK it.",
        "",
        "  THE IDEA                      full code → decisions.py",
        "",
        "      d = parse_llm_response(...)      ← the LLM proposes",
        "",
        "      %sif d and d.program in valid:%s     ← THE CHECK" % (YEL, RST),
        "          return d, 'llm'",
        "",
        "      return decide_by_rules(...), 'rules'  ← else fall back",
        "",
        "  Look hard at the line marked THE CHECK. It is the",
        "  %sentire trust boundary of this agent%s. Remember it." % (BOLD, RST),
    ], prompt="[Enter] to compare all three"),

    dict(n=14, kind="RUN", title="all three, side by side", body=s13_body,
         prompt="[Enter] — one last thing"),

    dict(n=15, kind="IDEA", title="the hole you have NOT plugged", body=[
        "  Your whole trust boundary is one line:",
        "",
        "      %sif d.program in valid%s" % (YEL, RST),
        "",
        "  It checks the NAME. It checks nothing else. Watch:",
        "",
        "    you have:   data.mtz, sequence.fa, placed_model.pdb",
        "    LLM says:   refine  model=%sbest_model.pdb%s" % (RED, RST),
        "",
        "    program in valid?  %syes%s  →  decide() ACCEPTS it." % (GRN, RST),
        "",
        "  That file does not exist. Nothing looked. And nothing",
        "  is watching for refine → refine → refine either — the",
        "  loop that killed agent B at step 12.",
        "",
        "  %sOne line is not a trust boundary. Tutorial 2.%s" % (BOLD, RST),
    ], prompt="[Enter] to finish"),
]


if __name__ == "__main__":
    main(Guide(
        title="Tutorial 1 — From Rules to Reasoning",
        student_file="decisions.py",
        solution_file="solutions/decisions_complete.py",
        test_file="test_decisions.py",
        stub_file="solutions/decisions_stub.py",
        steps=STEPS,
        cwd=HERE,
        outro=[
            "  You did not type it, so go and LOOK at it:",
            "",
            "     %sless decisions.py%s        the 81 lines you now own." % (BOLD, RST),
            "                              Read parse_llm_response —",
            "                              the 26 lines I did not show",
            "                              you are the interesting ones.",
            "",
            "  Then break it, on purpose:",
            "",
            "     %spython3 run_agent.py%s     watch [LLM] and [RULES]" % (BOLD, RST),
            "                              alternate, cycle by cycle",
            "",
            "     %spython3 run_agent.py --llm%s   the LLM with no net" % (BOLD, RST),
            "",
            "  Now edit decisions.py and DELETE the whitelist check",
            "  in decide() — the `if d.program in valid` line.",
            "  Re-run. The agent executes a program that does not",
            "  exist. That one line is doing all the work.",
            "",
            "     %spython3 guide.py --reset%s   to put it back." % (BOLD, RST),
            "",
            "  %sBut one line is not a trust boundary.%s It never looks" % (YEL, RST),
            "  at the FILES, and it cannot see a LOOP.",
            "",
            "  %sThat is Tutorial 2.%s" % (BOLD, RST),
        ],
    ))
