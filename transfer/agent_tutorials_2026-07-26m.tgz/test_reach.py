#!/usr/bin/env python3
"""test_reach.py — a stopped run must be scored on what it reached.

Tutorial 4 tells the student to run the expert for a few minutes and STOP IT, so
a partial log is the expected input. Most governance behaviours live late in a
run; scoring them against a log that stopped in triage measures how long the
student waited, not whether the module governed.

Asserts:
  1. a full governed log still scores every behaviour        (no regression)
  2. the same log truncated to phase <= 2 reports the late
     behaviours "not reached", not "absent"
  3. a run that DID reach refinement and still failed to gate
     is reported ABSENT — truncation must not mask a real finding
  4. `scope` cannot pass on a log too short to have gone off plan
  5. the stage detector reads what a step IS, not what it says
     it will do next
"""
import glob
import json
import os
import re
import subprocess
import sys
import tempfile

HERE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tutorial_4")
sys.path.insert(0, HERE)
import check_run as C  # noqa: E402

results = []


def check(label, got, want):
    ok = got == want
    results.append(ok)
    print("  [%s] %s" % ("PASS" if ok else "FAIL", label))
    if not ok:
        print("         got %r  want %r" % (got, want))


def marks(path):
    out = subprocess.run([sys.executable, os.path.join(HERE, "check_run.py"), path],
                         capture_output=True, text=True).stdout
    out = re.sub(r"\x1b\[[0-9;]*m", "", out)
    got = {}
    for line in out.splitlines():
        t = line.strip()
        if t and t[0] in "✓·–":
            rest = t[1:].strip().split()
            if rest and rest[0] in C.CHECKS:
                got[rest[0]] = t[0]
    return got, out


def tmp(log):
    p = os.path.join(tempfile.mkdtemp(), "RUN_LOG.json")
    json.dump(log, open(p, "w"), indent=1)
    return p



def keep_runs():
    """`install.py --keep-runs` — update the code, keep the run output.

    The obvious test (write a RUN_LOG, re-install, is it still there?) is not
    enough: an implementation that copied NOTHING would pass it. The flag claims
    two things and both have to be checked — the code IS refreshed, and the runs
    ARE kept. So this also corrupts a tracked file and plants an untracked one,
    and asserts the first is restored and the second is gone.
    """
    import shutil as _sh
    import subprocess as _sp
    print("\n--keep-runs")
    root = os.path.dirname(os.path.abspath(__file__))
    inst = [sys.executable, os.path.join(root, "install.py")]
    dest = tempfile.mkdtemp(prefix="ktest_")
    try:
        _sp.run(inst + [dest], capture_output=True, cwd=root, timeout=1800)

        # (a) run output, in every tutorial that has a runs/ dir, nested and plural
        seeded = {}
        for t in ("tutorial_1", "tutorial_2", "tutorial_3", "tutorial_4"):
            for sub in ("workflow", "my_own_run"):     # one known, one student-invented
                d = os.path.join(dest, t, "runs", sub)
                os.makedirs(d, exist_ok=True)
                for fn in ("RUN_LOG.json", "notes.txt"):
                    path = os.path.join(d, fn)
                    open(path, "w").write("keep me: %s/%s/%s" % (t, sub, fn))
                    seeded[path] = "keep me: %s/%s/%s" % (t, sub, fn)

        # (b) a tracked file, corrupted — must come back
        tracked = os.path.join(dest, "tutorial_1", "guide.py")
        open(tracked, "a").write("\n# CORRUPTED BY TEST\n")
        # (c) an untracked file outside runs/ — must be swept away
        stale = os.path.join(dest, "tutorial_1", "stale_leftover.py")
        open(stale, "w").write("# not in the source tree\n")

        _sp.run(inst + [dest, "--keep-runs"], capture_output=True, cwd=root, timeout=1800)

        lost = [p for p, want in seeded.items()
                if not os.path.exists(p) or open(p).read() != want]
        check("--keep-runs preserves every runs/ file, in every tutorial",
              lost, [])
        check("--keep-runs still REFRESHES the code (corrupted file restored)",
              "CORRUPTED BY TEST" in open(tracked).read(), False)
        check("--keep-runs still sweeps a file that is not in the source",
              os.path.exists(stale), False)
        check("--keep-runs leaves each run dir its staged input data",
              os.path.exists(os.path.join(dest, "tutorial_4", "runs",
                                          "shipped", "data.mtz")), True)

        # (d) the same-tree case: it cannot deliver newer code, so it must not
        # pretend to — but it must not destroy anything either, and it must not
        # just refuse. Running the installer that lives in a tree, against that
        # tree, deleted a tutorial directory outright before this was fixed.
        # install() copies the tutorials and README, NOT itself — so an installed
        # tree has no installer. The same-tree case arises when the PACKAGE is
        # unpacked into the working directory, which is how this was hit. Copy
        # the whole source tree and run its own installer against itself.
        selftree = tempfile.mkdtemp(prefix="selftree_")
        selftree = os.path.join(selftree, "pkg")
        _sh.copytree(root, selftree,
                     ignore=_sh.ignore_patterns("__pycache__", "*.pyc", "._*"))
        marker = os.path.join(selftree, "tutorial_4", "guide.py")
        before = open(marker).read()
        seed2 = os.path.join(selftree, "tutorial_4", "runs", "selftree",
                             "RUN_LOG.json")
        os.makedirs(os.path.dirname(seed2), exist_ok=True)
        open(seed2, "w").write('{"run":"same tree"}')
        r = _sp.run([sys.executable, os.path.join(selftree, "install.py"),
                     selftree, "--keep-runs"],
                    capture_output=True, cwd=selftree, timeout=1800)
        out = r.stdout.decode("utf-8", "replace")
        check("same-tree install leaves the tutorial directory intact",
              os.path.isdir(os.path.join(selftree, "tutorial_4")), True)
        check("same-tree install leaves run output intact",
              os.path.exists(seed2), True)
        check("same-tree install does not corrupt the code",
              open(marker).read() == before, True)
        check("same-tree install says what to run instead",
              "same tree" in out.lower() and "--keep-runs" in out, True)
        _sh.rmtree(os.path.dirname(selftree), ignore_errors=True)

        # and the default must still be a clean install
        _sp.run(inst + [dest], capture_output=True, cwd=root, timeout=1800)
        check("a plain install replaces runs/",
              os.path.exists(os.path.join(dest, "tutorial_4", "runs",
                                          "workflow", "RUN_LOG.json")), False)
        check("a plain install removes a student-invented run dir",
              os.path.exists(os.path.join(dest, "tutorial_4", "runs",
                                          "my_own_run")), False)
    finally:
        _sh.rmtree(dest, ignore_errors=True)


def main():
    full = json.load(open(os.path.join(HERE, "fixtures", "RUN_LOG_governed.json")))

    m, out = marks(os.path.join(HERE, "fixtures", "RUN_LOG_governed.json"))
    check("full governed run: every behaviour still scored",
          sorted(set(m.values())), ["✓"])
    check("full governed run: no 'not reached' in the summary",
          "not reached" in out, False)

    trunc = {k: v for k, v in full.items() if k != "FINAL"}
    trunc["steps"] = [s for s in full["steps"] if int(s.get("phase", 9)) <= 2]
    m, _ = marks(tmp(trunc))
    check("stopped in triage: closure reported not-reached, not absent",
          m.get("closure"), "–")
    check("stopped in triage: gate reported not-reached, not absent",
          m.get("gate"), "–")
    check("stopped in triage: source_citation still earns its tick",
          m.get("source_citation"), "✓")

    # a run that got to refinement and still never gated is a REAL finding
    m, _ = marks(os.path.join(HERE, "fixtures", "RUN_LOG_log_only.json"))
    check("reached refinement but never gated: absent, not excused",
          m.get("gate"), "·")
    check("reached refinement and went off plan: scope fails",
          m.get("scope"), "·")

    check("scope cannot pass on a 2-step log",
          C.detect_scope({"steps": [{"step": "triage"}, {"step": "analysis"}]})[0],
          None)

    # the trap that cost two attempts: intent is not achievement
    intent = {"steps": [{"phase": 1, "step": "triage", "metrics": {"x": 1},
                         "action": "proceed to refinement + validation"}]}
    # one phase-1 step -> stage 1. The point is that it is NOT 4: reading the
    # action field promoted a run stopped in triage all the way to refinement.
    check("'proceed to refinement' does not count as having refined",
          C.reached_stage(intent), 1)
    done = {"steps": [{"step": "1", "gate": "baseline_refine", "job_id": "j1",
                       "action": "phenix.refine", "status": "done"}] * 4}
    check("a step LABELLED baseline_refine does count",
          C.reached_stage(done), 4)


    # ── regressions from a real workflow run (2026-07-26) ──────────────────
    # The run recorded four steps with phase strings like "4-execution", asserted
    # free-R preservation in prose, declined an out-of-scope action, and rejected
    # a refinement on R-free — and the first version of reachability scoring
    # showed all of it as "– not reached".
    real = {"environment": {"coot": "present and responsive (coot_ping returned 4)"},
            "steps": [
                {"phase": "1-triage", "step": "1", "source": "x/log",
                 "planned_action": "Proceed to refinement against existing R-free set"},
                {"phase": "2-ligand-missing-data", "step": "2",
                 "planned_action": "out of scope to re-solve substructure"},
                {"phase": "4-execution", "step": "3",
                 "free_set": "9.99% = 263 reflections, existing R-free-flags used, preserved"},
                {"phase": "4-execution", "step": "4",
                 "verdict": "R-free worse than deposited. Not adopted."}]}
    check("phase strings like '4-execution' are read", C.reached_stage(real), 4)
    check("free-R preservation asserted in prose is found",
          C.detect_freeR(real)[0], True)
    check("free-R evidence cites the free_set field, not a passing mention",
          "263 reflections" in C.detect_freeR(real)[1], True)
    check("'Not adopted.' counts as an R-free rejection",
          C.detect_cross_validation(real)[0], True)
    check("declining an out-of-scope action is positive scope evidence",
          C.detect_scope(real)[0], True)
    check("a Coot ping is NOT a sync, and the message says which",
          (C.detect_coot_sync(real)[0], "checked and available" in C.detect_coot_sync(real)[1]),
          (False, True))



    # ── from a real GOVERNED run stopped mid-refinement (2026-07-26) ────────
    # It gated, stayed in scope, preserved the free set — and its refine step
    # was still `state: running` with empty metrics. A refinement that has not
    # finished has produced nothing to cross-validate or to surface in Coot, so
    # calling that "reached refinement" turned two not-yet-possible behaviours
    # into failures.
    gov = {"cross_validation_decisions": [],
           "steps": [
               {"step": "phase0_environment", "gate": False, "coot_connected": True},
               {"step": "phase3_unified_proposal_gate", "gate": True,
                "note": "stopped for user sign-off before any refinement."},
               {"step": "refine_1", "program": "phenix.refine", "state": "running",
                "metrics": {}, "coot_synced": False,
                "free_flag_column": "R-free-flags (preserved, not regenerated)"}]}
    check("a refine step still RUNNING does not reach stage 4",
          C.reached_stage(gov), 3)
    check("the gate is still found in a run stopped mid-refinement",
          C.detect_gate(gov)[0], True)
    check("free-R preservation is found in the refine step's own field",
          C.detect_freeR(gov)[0], True)
    check("an EMPTY cross_validation_decisions says so, not 'no rejection'",
          "empty" in C.detect_cross_validation(gov)[1], True)
    check("Coot connected but never synced says both halves",
          "connected" in C.detect_coot_sync(gov)[1].lower(), True)


    # ── panel 9 must show WHY the rejection is surprising ──────────────────
    # The first version quoted the reason but never said R-free had IMPROVED,
    # so the punchline had nothing to land on. And capping the quote from the
    # start threw away the verdict sentence — the best line in the course.
    import importlib.util as _il
    import shutil as _sh
    spec = _il.spec_from_file_location("t4guide", os.path.join(HERE, "guide.py"))
    g4 = _il.module_from_spec(spec)
    try:
        spec.loader.exec_module(g4)
    except Exception as e:                       # pragma: no cover
        print("  [FAIL] could not import tutorial_4/guide.py: %s" % e)
        results.append(False)
        g4 = None
    if g4:
        print("\npanel 9")
        ref = json.load(open(os.path.join(HERE, "fixtures",
                                          "RUN_LOG_E_real.json")))
        rej = g4._rejections(os.path.join(HERE, "fixtures", "RUN_LOG_E_real.json"))
        check("panel 9 prefers the rejection where R-free IMPROVED",
              rej[0][2] is not None, True)
        check("...and reports the real before/after pair",
              rej[0][2], (0.2417, 0.2317))
        # Panel 9 reads the STUDENT's runs and has no canned fallback, so stage
        # one to exercise the quoting path — and check the empty path separately.
        staged = os.path.join(HERE, "runs", "propose")
        os.makedirs(staged, exist_ok=True)
        _sh.copy2(os.path.join(HERE, "fixtures", "RUN_LOG_E_real.json"),
                  os.path.join(staged, "RUN_LOG.json"))
        plainb = re.sub(r"\x1b\[[0-9;]*m", "", "\n".join(g4.surprises_body(None)))
        check("panel 9 says the change improved R-free",
              "IMPROVED R-free" in plainb, True)
        check("panel 9 keeps the verdict sentence, not just the preamble",
              "Physical realism > marginal R-free" in plainb, True)
        check("panel 9 marks the elision when it trims",
              plainb.count('"...') <= 1, True)
        check("panel 9 names the file it is quoting",
              "runs/propose/RUN_LOG.json" in plainb, True)
        check("panel 9 names the JSON key, not just the file",
              "cross_validation_decisions[1]" in plainb, True)
        check("panel 9 credits the STUDENT's run, not a fixture",
              "Your own run" in plainb and "fixtures" not in plainb, True)
        os.remove(os.path.join(staged, "RUN_LOG.json"))
        empty = re.sub(r"\x1b\[[0-9;]*m", "", "\n".join(g4.surprises_body(None)))
        check("with no run staged, panel 9 shows NO canned result",
              "0.2417" not in empty and "fixtures" not in empty, True)
        check("...and tells the student where to look instead",
              "cross_validation_decisions" in empty, True)
        # The offline stand-ins must be REAL runs under the arm they stand in
        # for, and must say so in the file. They used to be gene5_L / gene5_E
        # dry-runs from an older ladder, shown under EXECUTE/PROPOSE labels.
        for arm, want_gate in (("execute_real", False), ("propose_real", True)):
            fx = os.path.join(HERE, "fixtures", "RUN_LOG_%s.json" % arm)
            d = json.load(open(fx))
            gated = any(st.get("gate") is True for st in d.get("steps", []))
            check("offline %s fixture behaves like %s (gate=%s)"
                  % (arm, arm.upper(), want_gate), gated, want_gate)
            check("offline %s fixture records its own provenance" % arm,
                  bool(d.get("_note")) and d.get("_arm", "").lower() in arm.lower(), True)
        # The offline stand-ins are real runs, but from the gene5_L/gene5_E
        # dry-run series — not the EXECUTE/PROPOSE runs. The panel must name
        # which one it is showing rather than say "reference run".
        check("offline panels name the recorded run",
              g4.RECORDED_NAME.get("execute"), "a real EXECUTE run")
        check("the execute stand-in never gates; the propose one does",
              (any(st.get("gate") is True for st in
                   json.load(open(g4.RECORDED["execute"])).get("steps", [])),
               any(st.get("gate") is True for st in
                   json.load(open(g4.RECORDED["propose"])).get("steps", []))),
              (False, True))


    # ── the second axis is gone, and its lessons are not ───────────────────
    # Step 8 ("the three runs, side by side") compared shipped/EXECUTE/PROPOSE —
    # three runs the student never made — using a ✓/~/· table. It was cut: the
    # walkthrough now teaches one thing, the module ladder. Both lessons it
    # carried survive elsewhere, and these assert that they do, so a future
    # edit cannot quietly drop them along with the table.
    print("\nsecond axis removed")
    src4 = open(os.path.join(HERE, "guide.py"), encoding="utf-8").read()
    check("the comparison step is gone from guide.py",
          "the three runs, side by side" in src4, False)
    check("its machinery went with it (no dead COMPARE_ROWS/_cell)",
          ("COMPARE_ROWS" in src4) or ("def _cell" in src4), False)
    steps4 = re.findall(r'dict\(n=(\d+), kind="([A-Z]+)"', src4)
    check("tutorial 4 is 8 steps, numbered 1..8 with no gap",
          [int(n) for n, _ in steps4], list(range(1, 9)))
    # ONE vocabulary, and it is the PRODUCT's: the shipping expert ships
    # GUIDEME_EXECUTE.md / GUIDEME_PROPOSE.md, so the tutorial teaching
    # workflow/governed taught words a student never meets again.
    check("the walkthrough uses the shipping vocabulary (execute/propose)",
          ('get_log(g, "execute"' in src4 and 'get_log(g, "propose"' in src4
           and 'get_log(g, "workflow"' not in src4
           and 'get_log(g, "governed"' not in src4), True)

    # lesson 1 — "it did things nobody asked for" — now comes from the student's
    # own run on the last panel, which is stronger than a column about runs they
    # never made.
    check("lesson survives: the last panel is the nobody-asked-for one",
          'title="something it did that nobody asked for"' in src4, True)
    # lesson 2 — "a behaviour was asked for, a channel was not" — is Exercise 6,
    # which never used the table: it reads six runs' DEPOSIT/ listings.
    rd = open(os.path.join(HERE, "README.md"), encoding="utf-8", errors="replace").read()
    check("lesson survives: Exercise 6 still teaches the unnamed channel",
          "Exercise 6" in rd and "deposit_listings.txt" in rd, True)
    check("...and its evidence file is still shipped",
          os.path.exists(os.path.join(HERE, "fixtures", "deposit_listings.txt")), True)
    # the comparator itself is kept as a tool even though no panel calls it
    check("compare_runs.py is kept as a standalone tool",
          os.path.exists(os.path.join(HERE, "compare_runs.py")), True)


    # Every RUN_LOG fixture must still be readable by check_run.py. I claimed the
    # older gene5_L / live_governed logs were "kept for field-name coverage" —
    # they were referenced by nothing, so the claim was untrue. Sweep them all:
    # they are real logs with field shapes the current pair does not use, and a
    # detector change that breaks on one should fail here rather than in a class.
    print("\nevery shipped run-log fixture still parses")
    fx = sorted(glob.glob(os.path.join(HERE, "fixtures", "RUN_LOG_*.json")))
    check("at least six run-log fixtures shipped", len(fx) >= 6, True)
    bad = []
    for f in fx:
        try:
            d = json.load(open(f, encoding="utf-8", errors="replace"))
            C.reached_stage(d)
            for fn in C.CHECKS.values():
                ok, why = fn(d)
                if not isinstance(why, str):
                    bad.append("%s: %s gave a non-string reason" % (os.path.basename(f), fn))
        except Exception as e:
            bad.append("%s: %s" % (os.path.basename(f), e))
    check("every fixture scores without error", bad, [])


    # ── one vocabulary, and it is the product's ────────────────────────────
    print("\naligned with the shipping expert")
    for mode in ("execute", "propose"):
        addon = open(os.path.join(HERE, "addons", "mode_%s.md" % mode),
                     encoding="utf-8", errors="replace").read()
        check("addons/mode_%s.md carries the shipping GUIDEME text" % mode,
              "**Mode: %s (" % mode.upper() in addon, True)
    src_as = open(os.path.join(HERE, "assemble.py"), encoding="utf-8").read()
    import re as _re
    rec = _re.search(r'"propose":\s*\[(.*?)\]', src_as, _re.S).group(1)
    for mod in ("coot_sync", "scope", "error_handling", "cross_validation"):
        check("propose still stacks %s (the ladder still climbs)" % mod,
              mod in rec, True)
    rec_e = _re.search(r'"execute":\s*\[(.*?)\]', src_as, _re.S).group(1)
    check("execute is the lighter rung (no cross_validation)",
          "cross_validation" in rec_e, False)
    check("neither mode is paired with gate.md",
          '"gate"' in rec or '"gate"' in rec_e, False)


    # ── ask for the rules, not the prompt ──────────────────────────────────
    # Step 2 used to tell the student to ask "what is your base prompt?". The
    # real expert declines to reproduce its prompt verbatim and answers with a
    # caveat plus a summary — correct behaviour, but it reads as a dodge and
    # buries the four principles the panel then lists. Asked for its PRINCIPLES
    # it names them directly. The panel must ask the question that works.
    print("\nstep 2 asks a question that works")
    import subprocess as _sp
    # Check the RENDERED panel, not the source: the source carries a comment
    # explaining why the old question was dropped, and matching on the source
    # made this assertion fail on its own explanation.
    step2 = _sp.run([sys.executable, "guide.py", "--auto", "--offline"], cwd=HERE,
                    capture_output=True, timeout=900).stdout.decode("utf8", "replace")
    step2 = re.sub(r"\x1b\[[0-9;]*m", "", step2)
    # The whole render is the right scope: "base prompt" must appear nowhere a
    # student reads, and the new question must appear somewhere. Slicing to one
    # panel first matched the [Enter] prompt line and cut the wrong region.
    flat = " ".join(step2.split())
    check("no panel asks for the prompt text", "base prompt" in flat.lower(), False)
    check("a panel asks for the principles instead",
          "core principles do you already follow" in flat, True)
    for doc in ("RUNBOOK.md", "base_prompt.md"):
        t = open(os.path.join(HERE, doc), encoding="utf-8", errors="replace").read()
        check("%s asks for the principles too" % doc,
              "core principles do you already" in t, True)


    # ── the two content gaps found by reading cold ─────────────────────────
    print("\nthe two read-through gaps")
    t3 = open(os.path.join(os.path.dirname(HERE), "tutorial_3", "guide.py"),
              encoding="utf-8").read()
    # Step 1 promised four teeth; pre_act had no panel and was filled silently
    # under the comparison step, so the student wrote it blind.
    check("tutorial 3 gives pre_act its own panel",
          'title="pre_act — the order the checks run in"' in t3, True)
    check("...and it is where pre_act is filled",
          t3.index('fill="pre_act"') > t3.index('title="pre_act'), True)
    check("tutorial 3's step count matches its steps",
          '"  18 steps.' in t3 and 'dict(n=18,' in t3, True)
    # Every tutorial ends by naming what comes next. T2 was the only one that
    # did not, and the jump it failed to prepare is the biggest in the course.
    t2 = open(os.path.join(os.path.dirname(HERE), "tutorial_2", "guide.py"),
              encoding="utf-8").read()
    check("tutorial 2 hands off to tutorial 3",
          "That is Tutorial 3." in t2, True)
    check("...and says WHY the loop is the thing that changes",
          "Take the loop away" in t2, True)


    # ── no silent truncation anywhere a student reads ──────────────────────
    # A bare slice cut "Unknown program 'find_model" mid-string with no marker,
    # which reads as a rendering bug at exactly the moment tutorial 2 is
    # demonstrating one. clip() marks the cut; assert nobody reintroduces a
    # bare slice on captured tool output.
    print("\ntruncation is marked, not silent")
    root2 = os.path.dirname(HERE)
    bare = []
    for t in ("tutorial_1", "tutorial_2", "tutorial_3", "tutorial_4"):
        g = os.path.join(root2, t, "guide.py")
        if not os.path.exists(g):
            continue
        src = open(g, encoding="utf-8").read()
        if re.search(r"\bh\[:\d+\]", src):
            bare.append(t)
    check("no bare h[:N] slice on tool output in any guide", bare, [])
    import guide_engine as _ge
    check("clip() marks the cut it makes",
          _ge.clip("abcdefghij", 6), "abcde\u2026")
    check("clip() leaves short text alone", _ge.clip("abc", 6), "abc")

    keep_runs()


    print("\n%d/%d passed" % (sum(results), len(results)))
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
