# Tutorial 4: Governing the Real Expert with GUIDEME

> **Teaching this live?** Open **`RUNBOOK.md`** — it is the single script for a
> teacher-led, students-follow-along session (the 8-panel conductor, panel by
> panel, with what to run, what to expect, and how long to wait). This README is
> the deeper self-paced reference and the optional 5-exercise "write your own
> governance" path.


> **Short on time, or want a conductor?**  Run `python3 guide.py`.
> It walks the shipped → EXECUTE → PROPOSE ladder in ~20 minutes: it tells you what to assemble,
> what to paste, and — most importantly — **what to watch for**. When the agent
> stops, it audits your run log for you.
>
> It is **live by default**: you drive the real expert. If the agent stalls or you
> have no expert set up, press `[o]` at any prompt (or start with `--offline`) and
> it walks the same ladder against real run logs shipped with this tutorial.
>
> The walkthrough teaches one thing: what each governance module buys. The interaction
> modes (EXECUTE / PROPOSE) are addon material for the exercises, and `compare_runs.py`
> will still tabulate them from the transcripts in `fixtures/` if you want that aside.

---

## What You'll Do

In Tutorials 3 and 4 you governed an agent with *code*. Here you govern the
**real PHENIX expert** with *prose*. You'll hand the agent different
constitutions — a base plus governance modules — and watch the same model
behave differently because of what its instructions say. No Python to write:
your deliverable is the GUIDEME.

This is the lecture's thesis at full strength (slides 15, 20): the disciplines
you built as code in Tutorials 1–4 — gate, scope, guardrail, error handling —
are here just **paragraphs of English**, and editing them reprograms a real,
unpredictable agent.

**Time:** ~55 minutes
**You'll read and adapt:** `addons/error_handling.md` and `addons/cross_validation.md` (both operational)
**You won't supply:** the base identity — the expert already has it. The first module you add is the **workflow**.

> **Where this sits in the lecture.** The Self-directed agent (slides 4, 7, 22),
> governed entirely through its system prompt (slide 15). The Coot-sync module
> is the trust boundary made visible; the R-free arbiter is the silent-wrongness
> defence (slide 18).

---

## How a constitution is built

A runnable GUIDEME is the base plus zero or more **governance modules**:

```
addons/mode_execute.md      interaction mode: EXECUTE (a complete contract)
addons/mode_propose.md      interaction mode: PROPOSE (adds the plan gate)
compare_runs.py             compare several runs; shows what your constitution did NOT predict
fixtures/transcript_*.md    real shipped / EXECUTE / PROPOSE runs on gene-5
fixtures/deposit_listings.txt   the DEPOSIT/ contents of six later runs
addons/workflow.md          the structure-determination pipeline (guidance) —
                            DELIBERATELY UNGOVERNED (no run log at all)
addons/run_log.md           RUN_LOG.json + the auditability contract   [provided]
addons/gate.md              the execution gate (Phase 3 hard stop)     [provided]
addons/coot_sync.md         surface every new model/map in Coot        [provided]
addons/scope.md             stay in scope; no off-plan re-phasing      [provided]
addons/error_handling.md    retry vs. diverge (real, operational)
addons/cross_validation.md  the R-free arbiter (real, operational)
```

Build one with the assembler:

```
python3 assemble.py execute  --out GUIDEME-mine.md   # interaction mode: EXECUTE
python3 assemble.py propose  --out GUIDEME-mine.md   # interaction mode: PROPOSE
python3 assemble.py governed --out GUIDEME-mine.md   # workflow + all modules
python3 assemble.py gated --out GUIDEME-mine.md      # workflow + run log + gate
```

A pre-built ladder is in `variants/`: **A** (base — *no run log at all*) →
**L** (+run log only — the control) → **B** (+gate) → **C** (+Coot sync) →
**D** (+scope) → **E** (full ≈ the production GUIDEME).

> **A note on what's already in the LLM — read this before Exercise 5.**
> The expert's own base prompt already holds the *scientific* principles:
> evidence over assertion, verify by measurement (not by eye), preserve R-free,
> physical realism over a marginally better R-free or CC. Your GUIDEME does not
> restate them.
>
> So the unPROPOSE-governed agent is **not** a bad scientist. Run it and it will still
> cite its sources, and it will very likely still refuse an overfitting edit.
> What it will *not* do is gate, surface its work in Coot, stay in scope, or
> **leave any record**. The rejection happens in the chat and evaporates.
>
> **Ethics are shared; auditability is not.** Governance is not the judgement —
> it is the forcing function and the audit trail. That is why "avoid
> overfitting" as a GUIDEME line changes nothing (the LLM already believes
> it), and why a *procedure* plus a *logged decision* changes everything.
>
> Note where you look for each half: the **science** shows up in the chat
> transcript (it cites sources; it refuses the bad edit). The **governance**
> shows up in `RUN_LOG.json` — or doesn't. `check_run.py` reads the log, so it
> can only ever see the second half. That is the point, not a limitation.

---

## Background: the agent you are governing

Before you write a line of policy, you need to know what is already there — because
**almost all of it is, and that is the point.**

### What the PHENIX expert already is

The "expert" in these labs is a real, working crystallography agent: a large
language model given a set of tools and a job. Out of the box, before you touch it,
it can already:

* **Drive PHENIX** — it runs `phenix.xtriage`, `phenix.autosol`, `phenix.autobuild`,
  `phenix.refine`, MolProbity, through an MCP server that manages jobs and parameters.
* **Drive Coot** — it loads models and maps into a live Coot session over a network
  bridge, inspects density, fixes rotamers.
* **Do good science, unprompted.** This is the part that surprises people. In our
  test runs, with *no* governance at all, it cited the source file for every number
  it reported, preserved the R-free test set without being told to, refused to accept
  a falling R-work as evidence of improvement, and correctly diagnosed an overfit.

Read that last point again, because it sets up everything else:

> **The unPROPOSE-governed agent is not a bad scientist.**

It knows that overfitting is bad. It knows R-free is the honest metric. Those
principles are already in its base prompt, and they fire without any help from you.

### So what are we adding?

Not ethics. **Procedure, and a record.**

Here is what our ungoverned test runs actually did when they hit an overfit — and
what they *failed* to do:

| | unPROPOSE-governed agent | what we add |
|---|---|---|
| notice the overfit | ✅ every time | — |
| know R-free is the arbiter | ✅ | — |
| **stop before an expensive step** | ❌ charges straight in | an **approval gate** |
| **stay inside the agreed plan** | ❌ improvises | a **scope check** |
| **revert the bad change** | ❌ asks you what to do, leaves it in place | a **guardrail that decides** |
| **leave a record anyone can audit** | ❌ reasons in the chat; it evaporates | a **run log** |

That's the whole job. The agent has the judgement. What it lacks is a **forcing
function** — something that makes the judgement happen *reliably*, *before* damage
is done, and leaves a trail a reviewer can check six months later when you are not
in the room.

An unrecorded good decision is indistinguishable, later, from one that was never
made.

### Why this is a real problem and not a toy

A capable agent that quietly does the wrong thing is more dangerous than an
incapable one, because nothing announces the failure. In a real run on real data,
the agent drove R-work from 0.198 down to 0.150 — a number that looks like a big
win — while the held-out R-free stayed flat. The model had started fitting noise.
Every metric on the screen said "improving."

That is what you are building the guardrail for.

### What you are running against in *this* tutorial

The real thing. Live PHENIX, live Coot, real data, the actual expert — and **you
will not write any Python at all.**

Instead you write its **constitution** (`GUIDEME.md`): the system prompt it reads
before it starts. The gate, the scope check, the guardrail and the run log that you
built as *code* in Tutorials 3 and 4 are here just **paragraphs of English**. You
add them one at a time and watch a real agent's behaviour change.

This is the deep version of the lesson. In a self-directed agent, governance is not
a layer of code wrapped around the LLM — it is text the LLM reads. Which makes
it powerful (you reprogram the agent by editing English) and fragile (a vague
sentence governs nothing).

---

## Setup

You run the expert from the CLI, which opens the GUI. There you say:

> please read GUIDEME-execute.md and follow instructions

…and hit run. **Stop the run the moment the behaviour you're testing appears** —
it doesn't need to finish. Each exercise says what to watch for.

Every run writes `RUN_LOG.json` in the working directory. Afterwards, audit it:

```
python3 check_run.py <working_dir>/RUN_LOG.json
python3 check_run.py <working_dir>/RUN_LOG.json --expect gate,coot_sync,scope,cross_validation,closure
```

> The agent is unpredictable, so we don't grade its words — we read its run
> log and check its *behaviour*. Run a variant two or three times and tally.
> Prompts shift probabilities, not guarantees: that's a finding, not a bug.

---

## Step 0: See the Problem (5 min)

Load the ungoverned base:

> please read variants/GUIDEME-execute.md and follow instructions

Watch it work. It triages competently, it cites its source files — the science
is sound. But: it **starts phasing without ever pausing to ask you** (no gate),
nothing is surfaced in Coot *as each job finishes* (no sync obligation — it may
wander over to Coot later, on its own schedule, and record nothing), and when you
go looking for the audit trail:

```
python3 check_run.py <working_dir>/RUN_LOG.json
```

…there **is no `RUN_LOG.json`**. The agent left no record at all. That is the
finding, and it is the starkest one in the tutorial: a competent scientist you
cannot audit.

**Now look in the chat transcript instead.** You'll find the agent naming the
source file for every number it reports — and later, if you tempt it with an
overfitting edit, very likely refusing it on cross-validation grounds. It is
*not* a bad scientist. It simply leaves nothing behind.

Run the control to make that concrete — the base plus the run-log module and
**nothing else**:

```
python3 assemble.py workflow --out GUIDEME-log-only.md
python3 check_run.py <working_dir>/RUN_LOG.json
```

Now there's a log, and exactly one thing is green: `source_citation`. Every
governance behaviour — gate, Coot sync, scope, the recorded arbiter decision — is
absent. **Sound science, zero governance.** That's your baseline, and everything
you add from here is governance.

---

## Exercise 1: Read the Constitution (5 min)

Open the files in `addons/`. Notice the split: the workflow is guidance, the
base has the *machinery* (how to reach Phenix and Coot, how to keep the run log)
but none of the *governance*. Each module is one obligation in plain English.
That separation is the whole idea — governance is editable text, not buried code.

---

## Exercise 2: The Run Log and the Gate (8 min) — compose

```
python3 assemble.py gated --out GUIDEME-gate.md
```
> please read GUIDEME-gate.md and follow instructions

Two things change at once. The agent now reaches **Phase 3 — THE GATE**, lays
out a proposal, and stops: *"I will not execute phasing/refinement until you
respond."* And this time it is **writing `RUN_LOG.json`** as it goes. Stop at the
gate and audit it:

```
python3 check_run.py <working_dir>/RUN_LOG.json --expect gate,source_citation
```

Two paragraphs turned an agent that charged ahead and vanished into one that
asks first and keeps receipts.

---

## Exercise 3: Coot Synchronization (8 min) — compose

The most visible module in the course. Add it:

```
python3 assemble.py synced --out GUIDEME-coot.md
```

Run it, answer the gate, and **watch your Coot window** — and watch *when* things
appear.

> **What the module actually changes (measured).** An unPROPOSE-governed agent is not
> blind to Coot: it will often load a model eventually, when *it* decides it wants
> to look at density. What it does **not** do is treat syncing as part of
> *finishing a job* — so you get the numbers first and the picture later, if at
> all, and nothing is recorded. With this module, the model and map are loaded
> **before the metrics are reported**, every global step, with the `imol` /
> `imol_map` indices written to the log. The contrast is *when*, *always*, and
> *recorded* — not *never*.

Stop after the first global step:

```
python3 check_run.py <working_dir>/RUN_LOG.json --expect gate,coot_sync
```

This is a trust-boundary lesson: an agent whose work you cannot see is an agent
you cannot check.

---

## Exercise 4: Error Handling (10 min) — read, then adapt

Open `addons/error_handling.md` — the **real, operational** module the governed
run ships with. Notice what makes it govern where "try again until it works"
could not: it splits **technical failure** (a crash, a missing column → bounded
retries, each with a changed parameter, never the same command twice) from
**scientific divergence** (R-free climbing, geometry exploding → retry is
*forbidden*; revert, stop, diagnose). Retrying the second case is how you launder
an overfit into the record.

Now adapt it. Add one clause for a failure mode *your* pipeline hits — a phasing
retry cap, a resolution-cutoff bail-out, a twinning check — assemble, and run:

```
python3 assemble.py governed --out GUIDEME-mine.md
```

---

## Exercise 5: The Cross-Validation Arbiter (12 min) — read the centerpiece

This is the real moment from the production gene-5 run: a Coot rotamer fix looked
cleaner locally, but re-refinement pushed R-free **up** (0.240 → 0.252–0.258). The
PROPOSE-governed agent rejected the edit and kept the better model.

Here is the subtlety, and it is the best idea in the session: **the ungoverned
agent probably rejects the bad edit too.** Physical realism and verify-by-
measurement are already in its base prompt. So the arbiter's job is *not* to make
it care — it already cares. Its job is to turn a judgement made *in prose* into a
**procedure it executes** and a **record it leaves behind**.

Open `addons/cross_validation.md` — the **real** arbiter the PROPOSE run ships.
Read how it does exactly that:

- it compares R-work, R-free, and **the gap** before/after every step, each read
  from that step's own refine log and cited;
- it rejects on any of three measured trips — ΔR-free > +0.005, the **gap** widens
  by > +0.010, or geometry regresses — the gap test catching the overfit a lone
  R-free threshold misses (R-work `0.1975 → 0.1466` while R-free barely moves, but
  the gap screams `0.044 → 0.099`);
- on a trip it **reverts automatically** and records the decision, with source
  files, in `cross_validation_decisions` — it does not ask you and leave the
  overfit sitting there.

> **Tip for a fast demo.** Cross-validation only bites *after* refinement, so run
> this exercise from **`refined_start/`** — it already holds the near-converged
> gene-5 model (R-work 0.1975 / R-free 0.2401) and the data it was refined
> against. The agent reaches the Coot edit in ~2 minutes; stop right after the
> arbiter fires. Building that model yourself would cost ~13 min of autosol —
> never put a full solve on the clock (see `TIMING.md`).

```
python3 assemble.py governed --out GUIDEME-mine.md
python3 check_run.py <working_dir>/RUN_LOG.json --expect gate,coot_sync,scope,cross_validation,closure
```

The run log shows the agent rejecting an R-free-worsening edit **and recording
the before/after delta and the reason** — production behaviour from one paragraph
of English. Compare against the shipped run: same scientific call, no evidence it
was ever made. Then write an arbiter clause for *your* pathology (ligand
occupancy, twinning, a resolution cutoff) and run it on your own data.

> **Run it more than once.** The base has the *principle* but no forcing
> function, so an unPROPOSE-governed agent usually rejects the overfit — and occasionally
> keeps it. If you catch that, don't hide it: it's the sharpest argument in the
> course for why governance externalises the rule instead of trusting the LLM
> to remember it every time.


---

## Exercise 6: Find the next one (10 min) — the case is still open

Panel 9 showed a rule that was underspecified, fixed, and verified. **The same defect is
still present in the constitution you were given.** Find it.

**The evidence.** `fixtures/deposit_listings.txt` lists the `DEPOSIT/` directory of six
runs. Every one of them kept a model it had rejected or could not choose between. Look at
what those files are called:

```
superseded_models/            provenance_01_element_corrected_start.pdb
alt_conservative_model.pdb    model_rebuilt_core.pdb
recovered_model_alt.pdb       supplied_model_asis.pdb
```

Six runs, five different naming schemes, no two alike.

**The instruction that produced them.** From your assembled constitution:

- EXECUTE — *"Record each model you supersede and why."*
- PROPOSE — *"preserve both as distinct, versioned files rather than committing to one."*

**Your task.** The behaviour is not missing — it happened every time. Write the sentence
that would make it *findable by a script*. Two minutes.

**Then check yourself** against what was actually shipped:

```
python3 assemble.py execute --use-solutions | grep -A2 "Non-destructive versioning"
python3 assemble.py propose --use-solutions | grep -A4 "Preserve competing models"
```

**Argue with it.** The shipped fix names two directories and requires a one-line reason
per file. Is the reason file worth the friction? Would you have named the directories
differently? There is no graded answer — the point is that you can now *state* the
difference between a rule that is checkable and one that is not.

### Why this one is still open

The closing-record fix was written, shipped, and verified across six runs. This one has
been diagnosed and not yet shipped — which is why you can still see the raw evidence. When
it ships, this exercise becomes a second worked example, and the next unfixed instance
takes its place.

## Discussion

1. **You governed a real expert without touching its code.** Every behaviour
   change came from the constitution. That's what a system prompt *is*.

2. **Ethics are shared; auditability is not.** The LLM already "knows" not to
   overfit, and it proves it even ungoverned. What the arbiter module adds is a
   *procedure* (compare to what, when, with what threshold) and a *record*.
   Aspirational prose governs nothing; operational prose governs precisely — and
   an unrecorded good decision is indistinguishable, later, from one that was
   never made.

3. **Governance is modular.** Gate, Coot sync, scope, error handling, arbiter —
   independent paragraphs you can add, remove, and test in isolation. Same
   disciplines you wrote as code in Tutorials 1–4, relocated into prose.

4. **Prose is powerful and probabilistic.** The same GUIDEME may not behave
   identically every run. A good constitution produces the right behaviour
   *robustly* — which is why you check the log, and check it more than once.

---

## Files

```
README.md                   You're reading it
addons/workflow.md          Structure-determination pipeline (guidance)
refined_start/              Near-converged gene-5 model + its MTZ + sequence
                            (R-work 0.1975 / R-free 0.2401) — point the agent
                            here for a ~2-min path to the arbiter, no autosol

addons/run_log.md           RUN_LOG.json + audit contract      [provided]
addons/gate.md              Execution gate                     [provided]
addons/coot_sync.md         Coot synchronization               [provided]
addons/scope.md             Stay in scope                      [provided]
addons/error_handling.md    Retry vs diverge (operational)
addons/cross_validation.md  R-free arbiter (operational)

assemble.py                 Build a GUIDEME: workflow + chosen modules
variants/                   Pre-built ladder, workflow -> governed:
                              GUIDEME-execute.md   guidance + run log
                              GUIDEME-gated.md      + execution gate
                              GUIDEME-synced.md     + Coot synchronization
                              GUIDEME-scoped.md     + stay in scope
                              GUIDEME-propose.md   full (~= production)

check_run.py                Read RUN_LOG.json; report governance behaviours
fixtures/                   Run logs to check against:
                              RUN_LOG_E_real.json     REAL governed run  -> 7/7 PASS
                              RUN_LOG_L_real.json     REAL control run   -> 5/7
                              RUN_LOG_live_governed.json  REAL, blanket-authorized
                                                      (gate is "·" — an authorization
                                                      is not a gate)
                              RUN_LOG_governed.json   synthetic, all 7 green
                              RUN_LOG_log_only.json   synthetic control

DESIGN.md                   Why it is built this way
PRESENTER.md                Teaching notes
INSTRUCTOR_DRYRUN.md        Capture your own A/L/E logs
TIMING.md                   Measured timings; the two rules that fit the hour
```
