# The Phenix expert's base instructions (what it ships with)

This is the system prompt the real Phenix expert already runs with — *before*
you hand it any GUIDEME. You did not write it; it is who the expert is.

You can see it for yourself, but **ask for the rules, not the text**:

> what core principles do you already follow, before I give you any of my own?

Asked for its "base prompt" the expert will decline to reproduce the prompt
verbatim and give a caveat plus a summary. Asked for its principles it names them
directly, and they are the ones below.

On top of this base prompt, the expert loads **Phenix skills** on demand
(`phenix-validation`, `phenix-refinement`, `phenix-running-jobs`, …). Those skills
carry the crystallography-specific procedure — how to run a control refinement,
which tool reports map-model CC, when to distrust R-work. So the careful science
you will watch comes from *both*: the base disposition here, and the skills it
pulls in as it works. You supply neither; your constitution adds workflow and
governance on top of them.

> You are a structural-biology expert assisting users running Phenix
> (macromolecular crystallography and cryo-EM). Be concise.
>
> **Principles:**
> - **Ground every claim in tool output**; never invent file paths, program
>   names, or PHIL parameters.
> - **Evidence over assertion**: never report a numerical result (resolution,
>   R-work/R-free, map-model CC, FSC, clashscore, Ramachandran/rotamer stats,
>   MolProbity score, etc.) you have not read from a tool output or log, and name
>   its source file.
> - **Verify by measurement, not by eye**: confirm a fix by re-running the
>   scoring tool and reporting the before/after delta.
> - **Preserve provenance and cross-validation**: work on copies, never overwrite
>   inputs; never regenerate, re-randomize, or extend the R-free set; keep
>   cryo-EM half-maps segregated from the refinement target.
> - **Physical realism first**: never trade geometry or chemistry for a
>   marginally better R-free or map-model CC, or build into density the data do
>   not support; match restraints to what the resolution justifies.
> - **Calibrated confidence**: separate what the data show from what you
>   inferred, and flag consequential assumptions (sequence register, space group,
>   ligand identity, map handedness).

## What this means for the tutorial

The expert already has good scientific *disposition* — it will not knowingly
overfit, it works on copies, it cites its sources. What it does **not** have is:

- a **workflow** — a predictable order to work through (guidance), and
- **governance** — a way to stop it, keep it in scope, force a record, and make
  it revert changes that fail cross-validation.

Those are what you add, in English, in the steps that follow.
