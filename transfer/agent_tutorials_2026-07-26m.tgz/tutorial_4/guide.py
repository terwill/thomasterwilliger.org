"""
guide.py — Tutorial 4, the conductor.

    python3 guide.py             live: you drive the REAL PHENIX expert
    python3 guide.py --offline   the same ladder, against the real run logs
                                 shipped with this tutorial

This tutorial has no code to fill in. You write the agent's CONSTITUTION, in
English, hand it to a real agent driving real Phenix and real Coot, and watch
what changes.

The guide cannot run the agent for you — that step is a human pasting a prompt
and waiting several minutes. So it conducts: it tells you what to assemble, what
to paste, and above all WHAT TO WATCH FOR. When the agent stops, you come back
and it audits the log.

If the agent stalls or you have no expert set up, press [o] at any prompt and it
drops to the real recorded runs. You lose the thrill, not the lesson.
"""

import json
import os as _os
import sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
import safe_io  # noqa: F401  survive a non-UTF-8 terminal
import os
import re
import subprocess
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from guide_engine import (Guide, main, BACK, GRN, RED, YEL, BOLD, RST, DIM)  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
FIXTURES = os.path.join(HERE, "fixtures")

OFFLINE = "--offline" in sys.argv or "--auto" in sys.argv

# The real logs, captured from real runs on real gene-5 data.
# Offline stand-ins for a live run: REAL EXECUTE and PROPOSE runs on the real
# gene-5 data (2026-07-26). Nothing here is invented, and the terminology now
# matches what the student ran. Each fixture carries its own `_note`. Their
# behaviour matches the contract each step teaches, which is checked not assumed:
#
#   RUN_LOG_execute_real.json  no gate:true anywhere        -> runs unattended
#   RUN_LOG_propose_real.json  phase3_unified_proposal_gate -> stops and asks
#
# They were also stopped after a few minutes, as the tutorial instructs, so what
# offline shows is the shape a student's own run actually has — including the
# "- not reached" rows. The older gene5_L / gene5_E dry-run logs are still in
# fixtures/ for check_run.py's field-name coverage; they are not shown to anyone.
RECORDED = {
    "shipped":  None,                                       # no GUIDEME → no log
    "execute": os.path.join(FIXTURES, "RUN_LOG_execute_real.json"),
    "propose": os.path.join(FIXTURES, "RUN_LOG_propose_real.json"),
}
RECORDED_NAME = {"execute": "a real EXECUTE run",
                 "propose": "a real PROPOSE run"}

EXPECT = "gate,coot_sync,scope,cross_validation,source_citation,closure"


def sh(args):
    from guide_engine import _utf8_env
    p = subprocess.run([sys.executable] + args, cwd=HERE, capture_output=True,
                       timeout=180, env=_utf8_env())
    return re.sub(r"\033\[[0-9;]*m", "",
                  (p.stdout + p.stderr).decode("utf-8", "replace"))


def audit(log_path):
    """Run check_run.py and return its per-behaviour lines."""
    if log_path is None or not os.path.exists(log_path):
        return None
    out = sh(["check_run.py", log_path, "--expect", EXPECT])
    # Match a behaviour ROW, not any line that happens to start with a mark:
    # check_run's --expect summary begins "– not reached (run stopped early): …"
    # and was being captured as an eighth behaviour called "not".
    names = ("gate", "coot_sync", "scope", "cross_validation",
             "freeR_preserved", "source_citation", "closure")
    rows = []
    for l in out.splitlines():
        t = l.strip()
        if not t or t[0] not in "✓✗·–":
            continue
        rest = t[1:].strip().split()
        if rest and rest[0] in names:
            rows.append(l.rstrip())
    return rows


def get_log(g, variant, auto):
    """Find the student's RUN_LOG.json — or fall back to the recorded run."""
    if auto or OFFLINE:
        return RECORDED[variant], True          # (path, is_recorded)

    # the run wrote its log into this variant's clean working dir
    here = os.path.join(HERE, "runs", variant, "RUN_LOG.json")
    while True:
        a = input("\n  %sBack from the expert window?%s Press %s[Enter]%s and I"
                  " will read\n  runs/%s/RUN_LOG.json and score it."
                  "  %s(No run yet, or want mine? type 'o'."
                  "  b = back.)%s\n  > "
                  % (BOLD, RST, BOLD, RST, variant, DIM, RST)).strip()
        low = a.lower()
        if low == "b":
            return BACK              # engine takes it from here
        if low == "o":
            return RECORDED[variant], True
        # only treat input as a path if it LOOKS like one (has a separator or
        # ends in .json) — otherwise a stray "y"/"yes"/"done" would be read as a
        # filename and error out confusingly. Anything else falls through to the
        # default (audit the run's own log dir).
        looks_like_path = ("/" in a) or ("\\" in a) or a.lower().endswith(".json")
        if a and looks_like_path:
            cand = os.path.expanduser(a)
            if os.path.isdir(cand):
                cand = os.path.join(cand, "RUN_LOG.json")
            if os.path.exists(cand):
                return cand, False
            print("  %sNo RUN_LOG.json at %s%s — check the path, or just press" % (YEL, cand, RST))
            print("  [Enter] to use runs/%s/, or type 'o' for my reference run." % variant)
            continue
        if os.path.exists(here):
            return here, False
        print("  %sI don't see runs/%s/RUN_LOG.json yet.%s" % (YEL, variant, RST))
        print("  If the expert is still running, finish and stop it, then [Enter].")
        print("  If it wrote the log elsewhere, type that path. Or type 'o' to")
        print("  audit my reference run instead.")


# ══════════════════════════════════════════════════════════ conductor steps

def _instruct(variant, recipe, paste, watch):
    rundir = os.path.join(HERE, "runs", variant)
    guideme = os.path.join(HERE, "GUIDEME-%s.md" % variant)
    lines = ["  The installer already built %sGUIDEME-%s.md%s and a" % (BOLD, variant, RST),
             "  clean %sruns/%s/%s data dir. To see what you hand over:" % (BOLD, variant, RST),
             "    phenix.view_md GUIDEME-%s.md" % variant,
             ""]
    lines += ["  %sSTART A FRESH EXPERT SESSION%s — a new chat (an old one" % (BOLD, RST),
              "  carries context and taints the run). %sName it \"%s\"%s," % (DIM, variant, RST),
              "  then paste:",
              "    \"working directory is %s." % rundir,
              "     Read %s, %s\"" % (guideme, paste), ""]
    lines += ["  %sWATCH FOR:%s" % (YEL, RST)]
    lines += ["    %s" % w for w in watch]
    lines += ["",
              "  Run this in the %sexpert window%s, stop it after a few" % (BOLD, RST),
              "  minutes, then return and press %s[Enter]%s to be scored." % (BOLD, RST)]
    return lines


def _report(g, variant, ok, headline, points):
    path, recorded = ok
    rows = audit(path)
    # Say WHICH recorded run. "(reference run)" told a student nothing and hid
    # that these are the L/E dry-runs rather than the EXECUTE/PROPOSE runs.
    tag = ("  %s(recorded: %s)%s" % (DIM, RECORDED_NAME.get(variant, "reference"), RST)
           if recorded else "  %s(YOUR run)%s" % (GRN, RST))
    out = []
    if rows is None:
        out += ["  %sThere is no RUN_LOG.json.%s" % (RED, RST),
                "",
                "  Nothing to audit. Not \"it failed the audit\" —",
                "  %sthere is no audit%s. It did the work and left no" % (BOLD, RST),
                "  trace of a single decision it made.",
                ""]
    else:
        green = sum(1 for r in rows if r.strip().startswith("✓"))
        # The tutorial says to stop the run after a few minutes, so most of these
        # behaviours live in phases the run never reaches. Scoring them out of 7
        # measured how long the student waited, not whether the module governed.
        unreached = sum(1 for r in rows if r.strip().startswith("–"))
        for r in rows:
            mark = r.strip()[0]
            col = GRN if mark == "✓" else (DIM if mark == "–" else
                                           YEL if mark == "·" else RED)
            body = r.strip()[1:].strip()
            name = body.split()[0] if body else ""
            out.append("    %s%s%s  %s" % (col, mark, RST, name))
        out.append("")
        total = len(rows) - unreached
        # "4 of 6" then "4 of 4" both open on a 4, so a student skimming sees no
        # climb. Say what a full score means when it happens.
        score = "%d of %d" % (green, total)
        if green and green == total:
            score += " — everything it reached"
        out.append("    %s%s%s  %s(✓ yes  · no%s)%s%s"
                   % (BOLD, score, RST, DIM,
                      "  – not reached" if unreached else "", RST, tag))
        # THE POINT OF THE WHOLE TUTORIAL, said where it first appears. On the
        # EXECUTE run cross_validation comes up green although nothing in that
        # guideline asked for it — the base agent already does it. Two panels
        # later we say EXECUTE has "no cross-val arbiter", which reads as a
        # contradiction unless this line is here to set it up.
        if variant == "execute" and any(
                r.strip().startswith("✓") and "cross_validation" in r for r in rows):
            out += ["",
                    "  %s✓ cross_validation — and nothing in GUIDEME-execute%s" % (YEL, RST),
                    "  %sasked for it. The base already does this. Hold that.%s" % (YEL, RST)]
    out += ["  %s" % p for p in points]
    return out



# ── the last panel: what YOUR run did that nobody asked for ──────────────────────────
#
# This panel used to be two hardcoded anecdotes from a session the student never
# saw and the package does not contain. One of them ("refused a direct human
# instruction to re-run with ordered solvent") has no artifact anywhere — no
# transcript, no run log — so it could not be shown even in principle. At this
# point in the tutorial the only interesting evidence is the student's OWN, so
# read their log and quote it. The reference run is a labelled fallback, not the
# headline.

def _rejections(path):
    """(edit, reason) for every recorded reject in a run log, quoted verbatim."""
    if not path or not os.path.exists(path):
        return []
    try:
        log = json.load(open(path, encoding="utf-8", errors="replace"))
    except Exception:
        return []
    out = []
    for i, c in enumerate(log.get("cross_validation_decisions") or []):
        if not isinstance(c, dict):
            continue
        verdict = str(c.get("verdict", c.get("decision", ""))).lower()
        if "reject" not in verdict:
            continue
        what = c.get("edit") or c.get("change") or "an edit"
        why = c.get("reason") or c.get("note") or ""
        if why:
            out.append((_surprise_score(c), str(what), str(why), _improved(c),
                        "cross_validation_decisions[%d]" % i))
    # Most interesting first. A rejection where R-free got BETTER is the whole
    # point of the panel — the agent overruled the headline number on physical
    # grounds. Taking the first recorded rejection instead showed the ordinary
    # case (R-free rose, so it was rejected), which surprises nobody.
    out.sort(key=lambda t: t[0], reverse=True)
    return [(w, y, pr, at) for _s, w, y, pr, at in out]


def _improved(c):
    """(before, after) if this change made R-free BETTER, else None."""
    vals = _r_frees(c)
    befores = [v for k, v in vals if "pre" in k or "before" in k]
    others = [v for k, v in vals if not ("pre" in k or "before" in k)]
    if befores and others and min(others) < min(befores):
        return min(befores), min(others)
    return None


def _r_frees(obj, found=None):
    """Every R-free-ish number anywhere in a decision, nested included."""
    found = [] if found is None else found
    if isinstance(obj, dict):
        for k, v in obj.items():
            if isinstance(v, (int, float)) and "free" in str(k).lower():
                found.append((str(k).lower(), float(v)))
            else:
                _r_frees(v, found)
    elif isinstance(obj, list):
        for v in obj:
            _r_frees(v, found)
    return found


def _surprise_score(c):
    improved = _improved(c) is not None
    text = json.dumps(c, default=str).lower()
    geometry = any(w in text for w in ("geometry", "physical realism",
                                       "realism", "rmsd", "molprobity"))
    return (2 if improved else 0) + (1 if geometry else 0)


def _wrap(text, width=54, indent="     "):
    words, line, out = text.split(), "", []
    for w in words:
        if len(line) + len(w) + 1 > width:
            out.append(indent + line)
            line = w
        else:
            line = (line + " " + w).strip()
    if line:
        out.append(indent + line)
    return out


def surprises_body(g):
    # YOUR runs only. Every one of them — the surprise can turn up in any.
    rej, src = [], None
    for variant in ("propose", "execute", "shipped"):
        cand = os.path.join(HERE, "runs", variant, "RUN_LOG.json")
        found = _rejections(cand)
        if found:
            rej, src = found, cand
            break
    yours = True

    if not rej:
        # Ending on "you didn't get one" leaves the capstone as an absence. Give
        # them the door out: what to do, where to look, and why it is worth it.
        return ["  %sNone of your runs recorded a rejected edit%s — you stopped" % (BOLD, RST),
                "  them after a few minutes, so the arbiter never had two",
                "  numbers to choose between. Nothing went wrong.",
                "",
                "  %sSo here is the last thing to do, and it is the best one:%s" % (BOLD, RST),
                "  start the PROPOSE run again and %slet it go%s. Then open" % (BOLD, RST),
                "  runs/propose/RUN_LOG.json at cross_validation_decisions",
                "  and look for a change that %simproved%s R-free and was" % (BOLD, RST),
                "  rejected anyway — because it traded away geometry the",
                "  data cannot support.",
                "",
                "  %sThat judgement is in no rule you wrote.%s Re-run this step" % (YEL, RST),
                "  (%spython3 guide.py --step 8%s) and it will quote yours." % (DIM, RST)]

    what, why, pair, at = rej[0]

    # LEAD WITH THE SURPRISE. Without the before/after numbers this panel is a
    # wall of crystallography and its punchline — "physical realism > marginal
    # R-free" — has nothing to land on: the reader never learns that R-free got
    # BETTER and the agent refused the change anyway. That is the whole point,
    # and the first version of this panel never said it.
    # NAME THE FILE. The panel said "the reference run" and stopped, so a student
    # who wanted to see it for themselves had nowhere to go. Print the path and
    # the JSON key, because "read the agent's own record" is the lesson.
    # Keep it to two lines inside 60 columns: the directory goes in the sentence,
    # the filename and the JSON key go on the line below.
    where = os.path.relpath(src, HERE)
    out = ["  %sYour own run wrote this.%s Open it and read the entry:" % (GRN, RST),
           "     %s%s  \u2192  %s%s" % (DIM, where, at, RST), ""]

    # A recorded reason can be a paragraph; the panel is 22 lines and the agent
    # does not know that. Cap it and mark the cut.
    # Cap from the END, not the start. A recorded reason opens with the working
    # and closes with the verdict, so trimming the tail threw away the best line
    # in the course — "Physical realism > marginal R-free." — and kept the
    # throat-clearing. Build backwards from the last sentence.
    room = 6 if pair else 8
    sentences = [x.strip() for x in re.split(r"(?<=[.;])\s+", why.strip()) if x.strip()]
    keep = []
    for sent in reversed(sentences):
        trial = [sent] + keep
        if len(_wrap('"%s"' % " ".join(trial))) > room:
            break
        keep = trial
    if not keep:                       # one enormous sentence: fall back to a head cut
        keep = [sentences[-1] if sentences else why]
    text = " ".join(keep).rstrip(".")
    if len(keep) < len(sentences):
        text = "... " + text
    quoted = _wrap('"%s."' % text)[:room]

    if pair:
        before, after = pair
        out += ["  It made a change that %sIMPROVED R-free%s:" % (BOLD, RST),
                "     %s%.4f -> %.4f%s" % (GRN, before, after, RST)]
        out += _wrap(what, 52)[:1]
        out += ["", "  %sThen it threw the change away%s, saying:" % (BOLD, RST)]
        out += quoted
        out += ["",
                "  %sNobody told it to put geometry above R-free.%s" % (YEL, RST),
                "  %sGovernance protects the science from the human,%s" % (YEL, RST),
                "  %snot just from the agent.%s" % (YEL, RST)]
    else:
        out += ["  It rejected:"] + _wrap(what)[:2]
        out += ["", "  Its recorded reason:"] + quoted
        out += ["", "  %sNobody asked it to. The arbiter was its own.%s" % (YEL, RST)]
    return out

STEPS = [
    dict(n=1, kind="IDEA", title="OVERVIEW — govern the expert with English", body=[
        "  Tutorial 3: you governed an agent with %spolicy.py%s." % (BOLD, RST),
        "  A gate, a scope check, a guardrail. Python.",
        "",
        "  %sHere you write no Python at all.%s The agent is the real" % (YEL, RST),
        "  PHENIX expert, on real gene-5 data. You govern it by",
        "  handing it a %sconstitution%s — GUIDEME.md, in English." % (BOLD, RST),
        "",
        "  Three stages: the expert %sas shipped%s, then + %sguidance%s" % (BOLD, RST, BOLD, RST),
        "  (%sEXECUTE%s), then one that stops and asks (%sPROPOSE%s)." % (BOLD, RST, BOLD, RST),
        "  You watch its behaviour change at each step.",
        "",
        "  8 steps.  (No expert set up? %spython3 guide.py --offline%s)" % (BOLD, RST),
    ], prompt="[Enter] to see what the expert already knows"),

    dict(n=2, kind="IDEA", title="what the expert already knows", body=[
        "  Before you add anything, know what the expert %salready%s" % (BOLD, RST),
        # "what is your base prompt?" asks for a TEXT the expert will decline to
        # reproduce; it answers with a refusal plus a summary, which reads as a
        # dodge and buries the point. Ask for the RULES instead — the expert
        # volunteers exactly the list below under its own heading "core
        # principles", so the panel now predicts what actually comes back.
        "  has. Ask it: %s'what core principles do you already" % DIM,
        "  follow, before I give you any of my own?'%s  It will" % RST,
        "  not recite its prompt — it names the rules it obeys:",
        "",
        "    · %sEvidence over assertion%s — never report a number" % (BOLD, RST),
        "      it hasn't read from a tool, and name its source",
        "    · %sVerify by measurement%s — confirm a fix by re-running" % (BOLD, RST),
        "      the scoring tool, reporting the before/after delta",
        "    · %sPreserve provenance & cross-validation%s — work on" % (BOLD, RST),
        "      copies; never regenerate or extend the R-free set",
        "    · %sPhysical realism first%s — never trade geometry for" % (BOLD, RST),
        "      a marginally better R-free",
        "",
        "  So it is already a careful scientist. What it lacks is",
        "  a %sworkflow%s and %steeth%s — that is what you add." % (BOLD, RST, BOLD, RST),
    ], prompt="[Enter] to see it run with only that"),

        dict(n=3, kind="IDEA", title="the expert is already pretty good", body=[
        "  The expert %sas shipped%s — no constitution, just data." % (BOLD, RST),
        "  The installer already made a clean %sruns/shipped/%s dir." % (BOLD, RST),
        "",
        "  In a %sfresh expert session%s named %s\"shipped\"%s, paste:" % (BOLD, RST, DIM, RST),
        "    \"working directory is %s/runs/shipped." % HERE,
        "     There is crystallographic data here — do",
        "     something useful with it. Work only on",
        "     copies; do no harm.\"",
        "",
        "  Run a few minutes, then %sstop it%s. It does %sgood" % (BOLD, RST, YEL),
        "  science%s — validates, refines, catches its own overfit." % RST,
        "",
        "  %sBut it never stops to ask, its order varies run to run,%s" % (DIM, RST),
        "  %sand its record is prose — not a log a machine checks.%s" % (DIM, RST),
    ], prompt="[Enter] — now hand it the EXECUTE contract"),

    dict(n=4, kind="IDEA", title="a constitution is stacked modules", body=[
        "  You do not write the expert's science — it has that.",
        "  You write its %sconstitution%s: a GUIDEME.md assembled" % (BOLD, RST),
        "  from modules, each a paragraph of English.",
        "",
        "    %sassemble.py%s stacks them, in order:" % (BOLD, RST),
        "",
        "      %sworkflow%s    the structure-determination pipeline" % (BOLD, RST),
        "      %srun_log%s     a live, auditable record" % (BOLD, RST),
        "      gate        stop before an expensive step",
        "      coot_sync   surface every model/map in Coot",
        "      scope       stay in the agreed plan",
        "      cross_val   the overfit arbiter (Tutorial 3, in prose)",
        "",
        "  %sEXECUTE%s takes workflow + run_log. %sPROPOSE%s takes those" % (BOLD, RST, BOLD, RST),
        "  plus the teeth, and brings its own stopping rule.",
    ], prompt="[Enter] to hand it the EXECUTE contract"),

    dict(n=5, kind="ACT", title="EXECUTE — runs to the end, on record",
         body=_instruct(
             "execute", "execute",
             "summarize and follow its instructions.",
             ["it works through the SAME phases every run:",
              "triage -> analysis -> build -> refine -> validate",
              "and it writes a RUN_LOG.json you can read"]),
         verify=lambda g, auto: get_log(g, "execute", auto),
         reveal_title="EXECUTE — ran on, left a record",
         reveal=lambda g, ok: _report(
             g, "execute", ok, "",
             ["Same capable science as the shipped run — but in a",
              "%spredictable order%s, and on the record: a %sstructured" % (BOLD, RST, BOLD),
              "RUN_LOG.json%s a machine can audit, not prose." % RST])),

    dict(n=6, kind="IDEA", title="what guidance still lacks", body=[
        "  EXECUTE made the run legible and recorded. It did",
        "  %snot%s make the agent controllable:" % (YEL, RST),
        "",
        "    it can still run an %sexpensive, irreversible%s step" % (BOLD, RST),
        "    without asking — no %sgate%s." % (BOLD, RST),
        "",
        "    it can still %swander off-plan%s — re-phase, redesign" % (BOLD, RST),
        "    the experiment — no %sscope%s check." % (BOLD, RST),
        "",
        "    that %s\u2713 cross_validation%s you just saw is the base" % (BOLD, RST),
        "    %sby disposition%s — not guaranteed, not on every run." % (BOLD, RST),
        "",
        "  Those are the %sgovernance%s teeth. Add them all at once" % (BOLD, RST),
        "  and see the fully governed agent.",
    ], prompt="[Enter] for the full constitution"),

    dict(n=7, kind="ACT", title="PROPOSE — it stops and asks first",
         body=_instruct(
             "propose", "propose",
             "summarize and follow its instructions.",
             ["it presents a PROPOSED PLAN and STOPS for sign-off",
              "  — that one you will see within a few minutes",
              "later, if you let it run on: it REVERTS a change",
              "that hurt the model and RECORDS why"]),
         verify=lambda g, auto: get_log(g, "propose", auto),
         reveal_title="PROPOSE — what it actually did",
         reveal=lambda g, ok: _report(
             g, "propose", ok, "",
             ["Same expert, same data, same science — and the only",
              "thing that changed was the %sEnglish you handed it%s." % (BOLD, RST),
              "",
              "Only what the run reached is scored; the gate and",
              "the closing checks live deeper than a few minutes."])),

    dict(n=8, kind="IDEA", title="something it did that nobody asked for",
         body=surprises_body, prompt="[Enter] to finish"),
]


if __name__ == "__main__":
    main(Guide(
        title="Tutorial 4 — Governing the Real Expert",
        student_file="GUIDEME-mine.md",
        solution_file=None,
        test_file=None,
        stub_file=None,
        steps=STEPS,
        cwd=HERE,
        done_line="DONE — you governed a real agent without writing a line of code.",
        generated=["RUN_LOG.json"],   # installer owns runs/ + GUIDEMEs; reset leaves them
        outro=[
            "  %sThe tutorial is over. The tool is not.%s" % (BOLD, RST),
            "",
            "  You have everything you need to govern a real agent",
            "  on YOUR OWN structure, right now:",
            "",
            "    %sassemble.py%s      stack base + any modules you like" % (BOLD, RST),
            "    %saddons/%s          the module library" % (BOLD, RST),
            "    %scheck_run.py%s     audit any RUN_LOG.json" % (BOLD, RST),
            "",
            "  %sGo and write a module of your own.%s Something your" % (YEL, RST),
            "  science needs and nobody has written yet:",
            "",
            "    · a ligand-occupancy arbiter",
            "    · a resolution-cutoff gate",
            "    · a twin-law scope check",
            "    · a rule for YOUR pathology, on YOUR data",
            "",
            "    cp addons/scope.md addons/mine.md      # start here",
            "    python3 assemble.py governed mine --out GUIDEME-mine.md",
            "",
            "  Then run it on your own data and audit the log.",
            "",
            "  %sA guardrail you reason out at the desk is not a%s" % (YEL, RST),
            "  %sguardrail until it has met real data. Go find out.%s" % (YEL, RST),
        ],
    ))
