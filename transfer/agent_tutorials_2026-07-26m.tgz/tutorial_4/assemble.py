#!/usr/bin/env python3
"""
assemble.py — Build a runnable GUIDEME from the base + governance add-ons.

A GUIDEME you hand the agent is one or more governance add-on
modules appended. This lets you (and your students) turn governance
behaviours on one at a time.

Usage:
    python3 assemble.py workflow               # guidance + run log  -> stdout
    python3 assemble.py gated                  # + execution gate
    python3 assemble.py synced                 # + Coot synchronization
    python3 assemble.py scoped                 # + stay in scope
    python3 assemble.py governed               # full governance
    python3 assemble.py gate coot_sync         # an explicit module list
    python3 assemble.py governed --out GUIDEME-mine.md

re-run `python3 assemble.py governed --out GUIDEME-mine.md` and load the result.
"""

import os as _os
import sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
import safe_io  # noqa: F401  survive a non-UTF-8 terminal
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))

RECIPES = {
    # Descriptive names. workflow + run_log ride along in every governed variant.
    # (The "shipped" baseline is NO GUIDEME at all — you just run the expert and
    #  say "do something with the data"; there is nothing to assemble for it.)
    "workflow": ["workflow", "run_log"],                       # guidance + record
    "gated":    ["workflow", "run_log", "gate"],               # + execution gate
    "synced":   ["workflow", "run_log", "gate", "coot_sync"],  # + Coot sync
    "scoped":   ["workflow", "run_log", "gate", "coot_sync",   # + stay in scope
                 "scope"],
    "governed": ["workflow", "run_log", "gate", "coot_sync",   # full governance
                 "scope", "error_handling", "cross_validation"],

    # --- interaction modes -------------------------------------------------
    # A mode is a COMPLETE interaction contract, not an increment. Each is one
    # block; they are alternatives to each other, not rungs you stack. The
    # "shipped" baseline remains NO GUIDEME at all — nothing to assemble.
    # These two are the LIVE WALKTHROUGH rungs, and they carry the names the
    # shipping Phenix Expert uses (prompts/GUIDEME_EXECUTE.md, GUIDEME_PROPOSE.md)
    # so a student meets one vocabulary in the tutorial, the lecture and the
    # product. Each mode brings its own interaction contract; neither may be
    # paired with gate.md (see CONFLICTS) because EXECUTE forbids the pause and
    # PROPOSE already has one.
    "execute":  ["workflow", "run_log", "mode_execute"],
    "propose":  ["workflow", "run_log", "coot_sync", "scope",
                 "error_handling", "cross_validation", "mode_propose"],
}

ORDER = ["mode_execute", "mode_propose",                    # a mode leads, if present
         "workflow", "run_log", "gate", "coot_sync", "scope",
         "error_handling", "cross_validation"]

# Combinations that produce a self-contradictory constitution. The agent cannot
# obey both halves, and an incoherent GUIDEME fails silently — the worst outcome.
CONFLICTS = [
    ("mode_execute", "gate",
     "EXECUTE says \"run ... to a finished result without pausing for step-by-step\n"
     "  approval\"; gate.md says \"you are strictly forbidden from running any\n"
     "  structural-solution, phasing, or refinement operation ... until you have\n"
     "  received explicit user sign-off\". Pick one."),
    ("mode_propose", "gate",
     "PROPOSE already carries its own gate (`### PROPOSED PLAN`); gate.md duplicates\n"
     "  it with different wording and a different phase structure."),
    ("mode_execute", "mode_propose",
     "These are alternative interaction contracts, not rungs. Assemble one."),
]


def check_conflicts(addons):
    """Return a list of human-readable problems with this module combination."""
    found = []
    for a, b, why in CONFLICTS:
        if a in addons and b in addons:
            found.append("%s + %s\n  %s" % (a, b, why))
    return found


def read(path):
    with open(path) as f:
        return f.read().rstrip() + "\n"


def assemble(addons, use_solutions=False):
    # Variant Z: no base prompt, no modules — just a "forget everything" opener.
    # This is the true zero of the ladder: what the agent does with NO workflow
    # and NO governance, only the data. Everyone runs it, watches the chaos, and
    # we stop after a few minutes to compare what different students saw.
    parts = []
    # Keep a stable, sensible order regardless of how they were listed.
    ordered = [a for a in ORDER if a in addons]
    for name in ordered:
        src = os.path.join(HERE, "addons", name + ".md")
        if use_solutions:
            sol = os.path.join(HERE, "solutions", name + ".md")
            if os.path.exists(sol):
                src = sol
        if not os.path.exists(src):
            sys.stderr.write("warning: no add-on named '%s' — skipping\n" % name)
            continue
        parts.append("\n" + read(src))
    return "\n".join(parts)


def main():
    args = sys.argv[1:]
    if not args:
        print(__doc__)
        sys.exit(0)

    out = None
    use_solutions = False
    names = []
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--out":
            out = args[i + 1]; i += 2; continue
        if a == "--use-solutions":
            use_solutions = True; i += 1; continue
        names.append(a); i += 1

    addons = []
    for n in names:
        if n in RECIPES:
            addons += RECIPES[n]
        else:
            addons.append(n)
    # de-dup, preserve
    seen = set()
    addons = [a for a in addons if not (a in seen or seen.add(a))]

    problems = check_conflicts(addons)

    if problems:

        sys.stderr.write("\nrefusing to assemble a self-contradictory GUIDEME:\n\n")

        for pr in problems:

            sys.stderr.write("  " + pr + "\n\n")

        sys.stderr.write("(use --force to build it anyway and see what the agent does)\n")

        if "--force" not in sys.argv:

            sys.exit(2)


    text = assemble(addons, use_solutions=use_solutions)
    if out:
        with open(out, "w") as f:
            f.write(text)
        sys.stderr.write("wrote %s (%d add-ons: %s)\n"
                         % (out, len(addons), ", ".join(addons) or "none"))
    else:
        sys.stdout.write(text)


if __name__ == "__main__":
    main()
