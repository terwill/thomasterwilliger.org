"""
guide_engine.py — the shared driver for the guided walkthroughs.

The design contract, in one paragraph:

  The FILE gets the whole function — every defensive branch, real working code.
  The SCREEN gets only the important text: the few lines that carry the idea,
  with the rest named, not hidden. No panel may exceed PANEL_MAX lines, because
  a panel that scrolls is a panel nobody reads. install.py enforces that limit
  mechanically.

Step kinds:

  IDEA     why this exists + the important lines.        advances on Enter
  RUN      call the new function on real inputs, show    advances on Enter
           input -> output, run that exercise's tests
  PREDICT  ask a question the student can ANSWER FROM     requires an answer
           FACTS ON THE SCREEN, take a commitment, then
           reveal. Wrong answers are never penalised.
  ACT      the student edits one thing themselves;        requires the edit
           we verify it, then re-run and show the change
           An ACT step usually prompts for itself, so the engine cannot see a
           `b` typed there. Its verify(g, auto) may return guide_engine.BACK to
           mean "the student asked to go back"; the engine handles the rest.

Standard library only.
"""

import argparse
import ast
import importlib
import io
import os
import re
import subprocess
import sys
import contextlib

if sys.version_info < (3, 8):                       # noqa: E402
    sys.exit("This course needs Python 3.8 or newer. "
             "You are running %d.%d — try 'python3 guide.py'."
             % sys.version_info[:2])

PANEL_MAX = 22          # hard screen contract. See install.py.
BACK = "\x00BACK"       # ask() returns this when the student types b
WIDTH = 60

BOLD, DIM, RST = "\033[1m", "\033[2m", "\033[0m"
CYAN, YEL, GRN, RED = "\033[36m", "\033[33m", "\033[32m", "\033[31m"

if not sys.stdout.isatty():
    BOLD = DIM = RST = CYAN = YEL = GRN = RED = ""

RULE = "═" * WIDTH
THIN = "─" * WIDTH


# ───────────────────────────────────────────────── code insertion

def _func_source(path, name):
    """Exact source lines of a top-level function, by AST."""
    src = open(path, encoding="utf-8").read()
    lines = src.splitlines()
    for node in ast.parse(src).body:
        if isinstance(node, ast.FunctionDef) and node.name == name:
            return node.lineno, node.end_lineno, lines[node.lineno - 1:node.end_lineno]
    raise KeyError("%s not found in %s" % (name, path))


def fill_function(student_path, solution_path, name):
    """Replace ONE function in the student's file with the reference version.

    Generic (AST-based) rather than string-matching, so it works for every
    exercise in every tutorial — including the last one, which catchup.py's
    table does not cover.
    """
    lo, hi, _ = _func_source(student_path, name)
    _, _, new_body = _func_source(solution_path, name)
    lines = open(student_path, encoding="utf-8").read().splitlines()
    out = lines[:lo - 1] + new_body + lines[hi:]
    open(student_path, "w", encoding="utf-8").write("\n".join(out) + "\n")


def already_started(student_path):
    """How many stubs has the student already filled in by hand?"""
    txt = open(student_path, encoding="utf-8").read()
    return txt.count("YOUR CODE HERE")


# ───────────────────────────────────────────────── running things

def _utf8_env():
    """Subprocess output we PARSE must be UTF-8, regardless of the terminal the
    student happens to be on. Display degrades (safe_io); parsing must not."""
    import os as _o
    e = dict(_o.environ)
    e["PYTHONIOENCODING"] = "utf-8"
    return e


def run_exercise_tests(test_file, n, cwd="."):
    """Run one exercise's tests. Return (passed, failed) — never raise."""
    p = subprocess.run([sys.executable, test_file, str(n)], cwd=cwd,
                       capture_output=True, timeout=120, env=_utf8_env())
    out = re.sub(r"\033\[[0-9;]*m", "", (p.stdout + p.stderr).decode("utf-8", "replace"))
    m = re.search(r"(\d+) passed, (\d+) failed", out)
    if m:
        return int(m.group(1)), int(m.group(2))
    m = re.search(r"All (\d+) tests passed", out)
    if m:
        return int(m.group(1)), 0
    return 0, 0


def run_filtered(cmd, patterns, cwd=".", limit=8):
    """Run a command; return ONLY the lines that matter."""
    p = subprocess.run([sys.executable] + cmd, cwd=cwd, capture_output=True,
                       timeout=180, env=_utf8_env())
    out = re.sub(r"\033\[[0-9;]*m", "",
                 (p.stdout + p.stderr).decode("utf-8", "replace"))
    keep = []
    for line in out.splitlines():
        if any(re.search(pat, line) for pat in patterns):
            keep.append(line.strip())
        if len(keep) >= limit:
            break
    return keep


def said(text, width=50, max_lines=3, indent="    "):
    """Quote the LLM in its own words. This is the point: it always sounds
    reasonable. The student has to see that BEFORE seeing it blocked."""
    import textwrap
    text = " ".join(str(text).split())
    full = textwrap.wrap(text, width)
    wrapped = full[:max_lines]
    if not wrapped:
        return []
    truncated = len(full) > max_lines
    if truncated:
        # never leave a sentence hanging mid-clause — mark it as an excerpt
        wrapped[-1] = wrapped[-1].rstrip(" ,;:") + " ..."
    out = []
    for i, line in enumerate(wrapped):
        q = '"' if i == 0 else " "
        end = '"' if i == len(wrapped) - 1 else ""
        out.append("%s%s%s%s" % (indent, q, line, end))
    return out


def fresh(module_name):
    """Re-import the student's module so we see the code we just wrote."""
    if module_name in sys.modules:
        del sys.modules[module_name]
    return importlib.import_module(module_name)


# ───────────────────────────────────────────────── the panel

def render(step, total, body_lines):
    """Build a panel as a list of lines. Enforces the screen contract."""
    head = [
        RULE,
        "  %sSTEP %d of %d%s   ·   %s%s%s"
        % (BOLD, step["n"], total, RST, CYAN, step["title"], RST),
        RULE,
        "",
    ]
    panel = head + list(body_lines)
    plain = [re.sub(r"\033\[[0-9;]*m", "", l) for l in panel]
    if len(plain) > PANEL_MAX:
        raise AssertionError(
            "PANEL CONTRACT VIOLATED: step %d (%s) renders %d lines, max %d"
            % (step["n"], step["title"], len(plain), PANEL_MAX))
    return panel


def show(panel, clear=True):
    if clear and sys.stdout.isatty():
        sys.stdout.write("\033[2J\033[H")
    print("\n".join(panel))



def clip(text, width):
    """Trim to width, and SAY SO. A bare slice cuts mid-word with no marker —
    "Unknown program 'find_model" — which reads as a bug rather than a cut."""
    text = text.rstrip()
    return text if len(text) <= width else text[:width - 1].rstrip() + "\u2026"

def wait(prompt="  [Enter] to continue", auto=False):
    if auto:
        return ""
    try:
        return input("\n%s%s%s " % (DIM, prompt, RST))
    except (EOFError, KeyboardInterrupt):
        print("\n\n  Stopped. Resume with:  python3 guide.py --step N\n")
        sys.exit(0)


def ask(question, options, auto=False, auto_answer=None):
    """PREDICT/ACT gate: will NOT open on a blank Enter.

    A wrong answer is never penalised — the reveal runs in full either way.
    The education happens in the reveal, not the gate.
    """
    if auto:
        return auto_answer
    opts = " / ".join(options)
    while True:
        try:
            a = input("\n  %s[%s]%s > " % (BOLD, opts, RST)).strip().lower()
        except (EOFError, KeyboardInterrupt):
            print("\n\n  Stopped. Resume with:  python3 guide.py --step N\n")
            sys.exit(0)
        if a in [o.lower() for o in options]:
            return a
        # b is an escape, not an answer. Without this the gate below rejects it
        # with "a guess is required" and the student cannot leave the step.
        if a == "b" and "b" not in [o.lower() for o in options]:
            return BACK
        print("  %sA guess is required — that is the whole point."
              "  (b = back)%s" % (YEL, RST))


# ───────────────────────────────────────────────── state

def state_path(cwd):
    return os.path.join(cwd, ".guide_state")


def save_state(cwd, n):
    open(state_path(cwd), "w").write(str(n))


def load_state(cwd):
    p = state_path(cwd)
    if os.path.exists(p):
        try:
            return int(open(p).read().strip())
        except ValueError:
            pass
    return 1


def clear_state(cwd):
    if os.path.exists(state_path(cwd)):
        os.remove(state_path(cwd))


# ───────────────────────────────────────────────── the driver

class Guide(object):
    def __init__(self, title, student_file, solution_file, test_file,
                 steps, cwd=".", stub_file=None, outro=None, extra_files=None,
                 done_line=None, generated=None):
        self.generated = generated or []
        self.done_line = done_line
        self.outro = outro or []
        self.extra_files = extra_files or []
        self.title = title
        self.student = student_file
        self.solution = solution_file
        self.test_file = test_file
        self.steps = steps
        self.cwd = cwd
        self.stub = stub_file          # pristine copy, for --reset

    # -- launch: never silently destroy a student's work ------------
    def _launch_check(self, auto, reset):
        sp = os.path.join(self.cwd, self.student)
        if reset:
            self._reset()
            return 1
        # A conductor (no stubs to fill) has no student work to protect.
        if not self.stub:
            return 1 if auto else load_state(self.cwd)
        remaining = already_started(sp)
        n_ex = len([s for s in self.steps if s.get("fill")])
        started = remaining < 4
        resume = load_state(self.cwd)
        if auto:
            self._reset()
            return 1
        # The guard used to fire only on a FRESH start (resume == 1), which left
        # the two commonest ways in unprotected: resuming mid-course, and --step.
        # Both replay fills over whatever is on disk, so both can silently discard
        # a hand edit. Same warning, all three paths.
        if started and (resume == 1 or resume > 1):
            print(RULE)
            print("  %s%s already has code in it.%s" % (BOLD, self.student, RST))
            print(RULE)
            print()
            print("  It looks like you have worked on this by hand.")
            print("  The guide writes code into that file — I will not")
            print("  overwrite your work without asking.\n")
            print("    [c]  continue anyway — the guide takes over")
            print("    [r]  reset to a clean start")
            print("    [q]  quit\n")
            a = ask("choose", ["c", "r", "q"])
            if a == "q":
                sys.exit(0)
            if a == "r":
                self._reset()
                return 1
        return resume

    def _reset(self):
        import shutil
        if self.stub and os.path.exists(os.path.join(self.cwd, self.stub)):
            shutil.copy2(os.path.join(self.cwd, self.stub),
                         os.path.join(self.cwd, self.student))
        # ACT steps can edit other files (GUIDEME.md). Put those back too.
        for live, pristine in (self.extra_files or []):
            p = os.path.join(self.cwd, pristine)
            if os.path.exists(p):
                shutil.copy2(p, os.path.join(self.cwd, live))
        # And remove anything the guide generated (assembled constitutions).
        import shutil as _shutil
        for junk in (self.generated or []):
            j = os.path.join(self.cwd, junk)
            if os.path.isdir(j):
                _shutil.rmtree(j, ignore_errors=True)
            elif os.path.exists(j):
                os.remove(j)
        clear_state(self.cwd)

    # -- the loop ---------------------------------------------------
    # -- moving between steps ---------------------------------------
    #
    # Entering at step n — on a resume, on --step, or on a BACK move — has to put
    # the tree into the state step n describes. That is two things, not one:
    #
    #   * the student file, rebuilt by replaying every earlier fill IN ORDER.
    #     Order matters: tutorial 3 fills should_rollback twice on purpose (naive
    #     at step 11, the gap rule at 13), so policy.py is DELIBERATELY wrong in
    #     between and replaying out of order would leave a student with naive code
    #     under a screen saying it is fixed.
    #
    #   * the extra_files — GUIDEME.md and friends. These were NOT restored before,
    #     and that was a live bug: tutorial 3 step 15 rewrites GUIDEME.md, nothing
    #     put it back, so re-entering at step 14 ran the agent against the TIGHTENED
    #     policy while the panel still said the policy was too loose to catch
    #     anything. The screen contradicted the run it had just performed.
    #
    def _restore_extra(self):
        """Put GUIDEME.md and friends back to their pristine copies."""
        import shutil
        for live, pristine in (self.extra_files or []):
            p = os.path.join(self.cwd, pristine)
            if os.path.exists(p):
                shutil.copy2(p, os.path.join(self.cwd, live))

    def _apply_fill(self, step):
        if not step.get("fill"):
            return
        src = step.get("fill_from", self.solution)
        fill_function(os.path.join(self.cwd, self.student),
                      os.path.join(self.cwd, src), step["fill"])

    def _catch_up(self, n, cold):
        """Rebuild the tree as it stands on ARRIVAL at step n (before n's own fill).

        `cold` distinguishes the two ways of arriving, and they need opposite
        treatment for the extra_files:

          COLD  (resume, --step) — nothing is cached, so every body from here on
                will RUN. They must see the pristine GUIDEME.md, or step 14 asks
                the agent about a policy step 15 already tightened and the panel
                contradicts the run underneath it.

          WARM  (back, in-session) — the panels are cached, so those bodies will
                NOT run and will not re-apply their edits. Restoring here would
                strip step 15's edit with nothing to put it back, and step 16
                would then report the ungoverned result. Leave the tree alone;
                the cache is showing what the tree already produced.

        Fills are replayed either way: they are declarative, ordered, and cheap.
        """
        if cold:
            self._restore_extra()
        for s in self.steps:
            if s["n"] < n:
                self._apply_fill(s)

    @staticmethod
    def _prompt_line(step, text):
        hint = "" if step["n"] <= 1 else "   %sb = back%s" % (DIM, RST)
        return "  %s%s" % (text, hint)

    def _panels(self, step, total, auto):
        """The panels for one step, computed once and remembered for this session.

        Re-running a body is not free and not neutral: nine of them shell out to
        run_agent.py, and one edits GUIDEME.md. Backing up should show what the
        student SAW, not a fresh run whose numbers may have moved underneath the
        fixed text on the same panel. Cache is per-process only — .guide_state is
        a bare integer and load_state() falls back to 1 on a parse error, so
        persisting this would silently restart anyone mid-course.
        """
        cached = self._rendered.get(step["n"])
        if cached is not None:
            return cached
        kind = step["kind"]
        body = step["body"](self) if callable(step["body"]) else list(step["body"])
        if kind in ("IDEA", "RUN"):
            out = [("show", render(step, total, body + [
                "", self._prompt_line(step, step.get("prompt",
                                                     "[Enter] to continue"))]))]
        elif kind == "PREDICT":
            out = [("show", render(step, total, body)), ("ask", None)]
        else:                                    # ACT
            out = [("show", render(step, total, body)), ("verify", None)]
        self._rendered[step["n"]] = out
        return out

    def run(self, auto=False, start=None, reset=False):
        total = len(self.steps)
        # --step used to bypass _launch_check entirely, so it never warned before
        # replaying fills over a hand edit. Run the check either way; it returns
        # the resume point, which --step then overrides.
        checked = self._launch_check(auto, reset)
        n = start or checked
        if n > 1 and not auto and not start:
            print("\n  %sResuming at step %d of %d."
                  "  (python3 guide.py --reset to start over)%s\n"
                  % (DIM, n, total, RST))
            wait("  [Enter] to continue")

        self._rendered = {}
        self._reveals = {}
        idx = 0
        for i, s in enumerate(self.steps):
            if s["n"] >= n:
                idx = i
                break
        else:
            idx = len(self.steps)
        self._catch_up(n, cold=True)
        note = None

        while idx < len(self.steps):
            step = self.steps[idx]
            self._apply_fill(step)
            kind = step["kind"]
            panels = self._panels(step, total, auto)

            back = False
            for what, panel in panels:
                if what == "show":
                    if note:
                        panel = panel + ["", "  %s%s%s" % (DIM, note, RST)]
                        note = None
                    show(panel)
                    if kind in ("IDEA", "RUN"):
                        if wait("", auto=auto).strip().lower() == "b":
                            back = True
                elif what == "ask":
                    a = ask("", step["options"], auto=auto,
                            auto_answer=step["answer"])
                    if a == BACK:
                        back = True
                        break
                    # The reveal runs the agent too, so it needs the same
                    # treatment as the body — otherwise coming back to a PREDICT
                    # step re-runs it against a tree later steps have changed.
                    key = (step["n"], a)
                    reveal = self._reveals.get(key)
                    if reveal is None:
                        reveal = step["reveal"](self, a)
                        self._reveals[key] = reveal
                    show(render(dict(step, n=step["n"], title=step["reveal_title"]),
                                total, reveal + ["", self._prompt_line(
                                    step, step.get("reveal_prompt",
                                                   "[Enter] to continue"))]))
                    if wait("", auto=auto).strip().lower() == "b":
                        back = True
                elif what == "verify":
                    # An ACT step owns its own prompt (tutorial 4 reads a path
                    # from the student), so the engine cannot intercept `b` for
                    # it. The contract instead: verify() may RETURN BACK, and we
                    # act on it here — before reveal(), which expects a result.
                    ok = step["verify"](self, auto)
                    if ok is BACK:
                        back = True
                        break
                    key = (step["n"], ok)
                    reveal = self._reveals.get(key)
                    if reveal is None:
                        reveal = step["reveal"](self, ok)
                        self._reveals[key] = reveal
                    show(render(dict(step, title=step["reveal_title"]),
                                total, reveal + ["", self._prompt_line(
                                    step, "[Enter] to continue")]))
                    if wait("", auto=auto).strip().lower() == "b":
                        back = True
                if back:
                    break

            if back and idx > 0:
                idx -= 1
                target = self.steps[idx]["n"]
                self._catch_up(target, cold=self.steps[idx]["n"] not in self._rendered)
                note = "\u2190 back to step %d of %d." % (target, total)
                if any(s.get("fill") for s in self.steps if s["n"] >= target):
                    note += "  Files put back to this step."
                save_state(self.cwd, target)
                continue
            if back:
                note = "Already at the first step."
                continue

            save_state(self.cwd, step["n"] + 1)
            idx += 1

        clear_state(self.cwd)
        return True


def main(guide):
    ap = argparse.ArgumentParser()
    ap.add_argument("--auto", action="store_true",
                    help="run every step with no input (used by install.py)")
    # Tutorial 4 walks its ladder against real run logs when no live expert is set
    # up. That is a DIFFERENT thing from --auto: offline still steps interactively.
    # guide.py reads this off sys.argv, so it only needs declaring here to be legal.
    ap.add_argument("--offline", action="store_true",
                    help="tutorial 4: use the shipped run logs instead of a live expert")
    ap.add_argument("--step", type=int, help="jump to a step")
    ap.add_argument("--reset", action="store_true", help="start clean")

    # argparse's bare "unrecognized arguments: --live" sends people hunting. The
    # commonest miss is a flag that belongs to run_agent.py, not to the guide:
    # the guide POINTS AT `run_agent.py --live`, it does not accept --live itself.
    try:
        a = ap.parse_args()
    except SystemExit:
        import os as _os
        if _os.path.exists(_os.path.join(_os.getcwd(), "run_agent.py")):
            sys.stderr.write(
                "\nnote: --live and --demo belong to run_agent.py, not to the guide:\n"
                "        python3 run_agent.py --live     # or --demo, with no API key\n"
                "      the guide accepts: --auto  --offline  --step N  --reset\n\n")
        raise

    # --reset on its own means "put it back and stop", not "reset then run".
    if a.reset and not a.step and not a.auto:
        guide._reset()
        print("  Reset. %s is back to the starting stub." % guide.student)
        print("  Run:  python3 guide.py")
        return

    guide.run(auto=a.auto, start=a.step, reset=a.reset)
    if not a.auto:
        outro = getattr(guide, "outro", None)
        done = getattr(guide, "done_line", None) or (
            "DONE — and %s is now a working agent." % guide.student)
        print()
        print("%s%s%s" % (GRN, RULE, RST))
        print("%s  %s%s" % (GRN, done, RST))
        print("%s%s%s" % (GRN, RULE, RST))
        print()
        if outro:
            for line in outro:
                print(line)
        print()
