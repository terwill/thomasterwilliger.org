# Number traceback — DecisionAudit11.pptx

*Every figure on the deck, where it comes from, and the command that reproduces it. Run from the
directory holding `runs/<case>/A/run_1/`.*

---

## Slide 6 — "The decisions are mostly sound"

### Leads by method and severity

| method | leads | major | moderate | minor | unrated | multi-method |
|---|---|---|---|---|---|---|
| look-back self-critique | 38 | 9 | 24 | 5 | 0 | 14 of 38 |
| in-run self-flag | 41 | 17 | 21 | 2 | 1 | 22 of 41 |
| independent reviewer | 19 | 4 | 14 | 1 | 0 | 16 of 19 |

**Source:** the 11 `CANDIDATES/review_queue.md` files. Each lead has a severity in its `##` heading
and a `- flagged_by:` line. A lead flagged by two methods counts once **per method**, which is why
the leads column sums to 98 rather than 70.

```bash
python3 - <<'EOF'
import re, glob, collections
LEG = {"self_critique":"self-critique", "self":"in-run", "transcript_pass":"independent"}
per = collections.defaultdict(collections.Counter); tot = collections.Counter()
leads = multi = 0
for f in sorted(glob.glob("runs/*/A/run_1/CANDIDATES/review_queue.md")):
    for blk in re.split(r"(?=^## \d+\.)", open(f).read(), flags=re.M):
        h  = re.search(r"^## \d+\.\s*\[([^\]]+)\]", blk, re.M)
        fb = re.search(r"- flagged_by:\s*([^·\n]+)", blk)
        if not (h and fb): continue
        leads += 1
        legs = {LEG[p.strip()] for p in
                fb.group(1).replace("both", "self+transcript_pass").split("+")
                if p.strip() in LEG}
        if len(legs) > 1: multi += 1
        for g in legs: per[g][h.group(1).strip()] += 1; tot[g] += 1
print("distinct kept leads:", leads, " multi-method:", multi)
for g in ("self-critique","in-run","independent"):
    c = per[g]
    print(f"{g:22} leads {tot[g]:3}  major {c['major']:3}  moderate {c['moderate']:3} "
          f" minor {c['minor']:3}  unrated {c['unknown']:3}")
EOF
```

**Verified output:** `distinct kept leads: 70  multi-method: 24`, then the three rows above (the script's short keys map to: self-critique, in-run self-flag, independent reviewer).

**"multi-method" column** = leads for that method that at least one other method also flagged.
self-critique 14/38, in-run flags 22/41, independent reviewer 16/19 — derived from the same `flagged_by` parse (a lead is multi-method
when its `flagged_by` names more than one leg; `both` expands to `self+transcript_pass`).

### Decisions rated — the look-back self-critique only

| well-justified | weakly-justified | got-lucky | wrong | total |
|---|---|---|---|---|
| 75 (77%) | 13 (13%) | 3 (3%) | 4 (4%) | 97 |

**Source:** the `## Forward walk` section of each `artifacts/self_analysis.md`, where every decision
carries a `- classification:` line. Extracted by `decision_ledger.py`, which writes
`CANDIDATES/decision_ledger.jsonl` per case; the totals are the sum across cases, reported in
`cross_case_summary.md`.

**10 of 11 runs contribute ratings.** `CASP7-T0283-mr` timed out before its close, so it wrote no
`self_analysis.md` — it contributes **6 leads and 0 ratings**. This is why the rating table totals 97
decisions from 10 runs while the leads table covers all 11.

**The other two methods produce no ratings at all**, not by omission: neither method rates decisions. They
emit flagged candidates only. Only the self-critique walks every decision, so only it yields a denominator.

**Percentages:** 75/97 = 77.3%, 13/97 = 13.4%, 3/97 = 3.1%, 4/97 = 4.1%. Rounded as shown.

### Triage

**87 candidates dropped, 70 kept.** Source: `CANDIDATES/triaged.jsonl` (`triage.call` of
`keep`/`ambiguous`/`drop`) summarised in `cross_case_summary.md`. The 70 is independently confirmed
by the lead count in the script above.

---

## Slide 4 — "A worked example" (the Coot checkpoint)

All from `runs/gene-5-mad/A/run_1/`.

| element | exact source |
|---|---|
| *"a rotamer pass reported 4 residues FIXED and wrote a file byte-identical to its input"* | `artifacts/self_analysis.md`, entry **D16** |
| look-back-critique quote, rating **wrong (mechanism misuse)**, severity **critical for process integrity** | `artifacts/self_analysis.md`, D16 — `classification:` and `severity:` lines |
| in-run flag quote *"Still 12.16% — suspicious that it's identical…"* | `events.jsonl` event **#334**; the confirmation *"Zero coordinate differences… byte-identical to the input"* is **#347** |
| independent-reviewer quote *"restore_to_backup_checkpoint … is notoriously fragile and a common source of bugs"* | `CANDIDATES/review_queue.md`, lead 1 — the `AUDITOR:` half of the merged concern |
| *"flagged_by: self+transcript_pass"* on the verification lead | same file, lead 1 |
| *"molecule-wide … the first non-improving residue rolled back the entire pass"* | mechanism stated at `events.jsonl` **#413**; the single pass-level checkpoint is **#172** |

**The claim that the methods segment the decision differently** is read directly off the two leads:
the `self_critique` lead is titled *"Used `restore_to_backup_checkpoint` for revert logic in Coot"*
while the `self+transcript_pass` lead is titled *"Verify whether the Coot fixes reached the file."*

---

## Slide 5 — "Why three readers and not one"

All from `runs/gene-5-mad/A/run_1/CANDIDATES/review_queue.md`.

| element | source |
|---|---|
| the self-critique faulted only the resolution cutoff and defended `sites=2` (*"the sequence has exactly 2 Met"*) | `artifacts/self_analysis.md`, entry **D3** |
| the independent reviewer faulted `sites=2` itself as too strong a prior | `review_queue.md` lead 13, `flagged_by: transcript_pass` |
| *"three sites with occupancy > 0.5 were found, not the two it was told to expect"* | `review_queue.md` lead 5, `flagged_by: both` |
| *"19 leads, 16 of them corroborated by another method"* | the per-method script above |

---

## Slide 7 — "It catches its own errors — but by luck"

**Left card (refined_start) — checked its own work with the same faulty tool.**

| element | source |
|---|---|
| *"used a text search to delete four selenium atoms, then used the SAME search to confirm they were gone"* | `runs/refined_start/A/run_1/CANDIDATES/review_queue.md` — the lead titled *"Relied on a string-pattern grep to make and then verify the Se-removal edit"*, flagged by **in-run self-flag + look-back self-critique**, severity **major** |
| *"696 lines unchanged, 4 selenium still present"* | same lead, concern field: *"only an independent atom-count check (696 unchanged; candidate outputs still had 4 Se) exposed it"* |
| *"this is exactly the kind of silent mistake to catch"* | same file, the in-run lead *"Re-remove chain Z robustly via awk and confirm count drops by exactly 4"* |
| *"every refinement built on that model was invalid"* | same concern field: *"would have shipped Se-containing 'cleaned' models"* |

**Right card (nsf-d2-ligand) — claimed a ligand site before looking at the map.**
`runs/nsf-d2-ligand/A/run_1/artifacts/self_analysis.md`, entry **D1b** (the *"bona fide nucleotide
pocket"* claim, and the 0-of-31-atoms result from the ligand-blind map).

*Note: this slide previously reused the Coot checkpoint, which is already the worked example on
slide 4. It was replaced to avoid showing the same failure twice.*

---

## Slide 9 — "Believing a tool without checking it — what it looks like" (11 of 11)

Four forms of the same failure. Every row is a real incident from a named run.

| row | source |
|---|---|
| **gene-5-mad** — a tool reported four fixes and wrote nothing | `runs/gene-5-mad/A/run_1/CANDIDATES/review_queue.md`, the lead *"Used `restore_to_backup_checkpoint` for revert logic in Coot"*: *"a rotamer pass reported 4 residues 'FIXED' but wrote a file byte-identical to its input … caught only because the coordinates were diffed against the input"* |
| **CASP7-T0283-mr** — ran a job for a number, never read it | `runs/CASP7-T0283-mr/A/run_1/CANDIDATES/review_queue.md`: *"The entire purpose of the refinement check was to get a quick R/R-free value to cross-validate the MR solution before starting a long and computationally expensive AutoBuild run. The agent ran the job but then failed to check its output for the key result."* Raised by the **independent reviewer** |
| **AF_7mjs** — verified a repair, then lost it to a crash | `runs/AF_7mjs_H_PredictAndBuild/A/run_1/CANDIDATES/review_queue.md`: *"Coot crashed and never recovered; the verified Trp47 repair was not saved and is lost"* |
| **6 of 11 datasets** — two programs disagreed, never reconciled | `TABLE1.md`, tool-vs-tool section, from `table1.py`. No AI involved |

**"Two of these four were caught."** gene-5-mad (by chance, when a number looked wrong) and AF_7mjs
(caught and reported, but the work was already gone). CASP7 and the six-dataset disagreement were
not caught during the runs at all.

*Note: gene-5-mad's checkpoint incident is also the worked example on slide 4. It appears here as a
single line because it is the clearest instance of the first form; the detail is not repeated.*


---

## Slides 10–14 — one slide per remaining failure mode

Same format as slide 9: real incidents, each traceable to a named run's review file
(`runs/<case>/A/run_1/CANDIDATES/review_queue.md`) unless noted.

### Slide 10 — Ignoring advice that was right there (5 of 11)

| row | source quote |
|---|---|
| gene-5-mad — used the default cutoff instead of the 3.1 Å it was given | *"xtriage handed the exact parameter to set (3.1 Å cutoff) and it was ignored; AutoSol found 6 sites where 2 were expected, 3 carried into the model and 2 later deleted"* |
| nsf-d2-ligand — guessed settings instead of asking the program | *"Four job failures from guessed parameter names cost ~40 min wall clock; the pattern recurred with two different programs despite introspection tools being available"* |
| CASP7-T0283-mr — told the program to expect too good a search model | *"An overly optimistic (low) RMSD can cause the search to fail. For an ab initio model of unknown accuracy…"* — raised by the **independent reviewer** |
| gene-5-mad — never mentioned the two unused wavelengths | *"Two further wavelengths existed that would probably have produced a better substructure and phases; the user was never informed"* |

### Slide 11 — Reading more into a number than it can support (5 of 11)

| row | source quote |
|---|---|
| nsf-d2-ligand — ligand effect confounded with 158 waters | *"The ligand effect and the 158 added waters were confounded in the R-free improvement; the matched control was an afterthought, not part of the design."* Corrected effect −2.8 pp vs the −6.0 pp implied |
| beta-blip — occupancies refined in the first cycle | *"Refining occupancies at this early stage is highly problematic. The model contains significant errors, and the refinement algorithm can easily reduce occupancies…"* |
| porin-twin — 165 waters accepted on the overall score | *"With twinned data, maps carry more model bias, so a subset of waters may have been placed into biased density. Individual water validity was not independently…"* |
| beta-blip — "within noise" asserted, not tested | *"The 'within noise' claim was asserted qualitatively rather than tested with a paired-significance check (Hamilton)"* |

### Slide 12 — Stating something before checking it (3 of 11)

| row | source |
|---|---|
| nsf-d2-ligand — the "bona fide nucleotide pocket" claim | review file; the 0-of-31-atoms result is in `artifacts/self_analysis.md`, D1b |
| gene-5-mad — three selenium atoms called impossible | *"The neighbour search was ASU-only; symmetry mates are the first thing to check for an isolated atom."* The contradicting anomalous peak is in `self_analysis.md`, D7 |
| gene-5-mad — lone selenium identified by elimination | *"The identity rests on an elimination argument, not a positive test; a heavier ion from the crystallization buffer would also scatter anomalously"* |

### Slide 13 — Waiting on something that is not working (3 of 11)

| row | source quote |
|---|---|
| CASP7-T0283-mr — waited on a stalled build | *"R-free plateaued and overall_best not advancing … When an automated procedure is clearly stalled or thrashing, the expert response is to intervene, not to wait passively."* ~167 fragmented residues |
| beta-blip — polished instead of rebuilding | *"No deep/real rebuilding (autobuild, loop fitting, simulated annealing) was performed"*. The 50%-built figure is from `scores.json` (`coverage 0.501`), computed against the deposited structure |
| beta-blip — settled for a gentle side-chain pass | *"R-free genuinely plateaued … backbone perturbation previously damaged"* |

### Slide 14 — Forgetting it is looking at a crystal (2 of 11)

| row | source quote |
|---|---|
| gene-5-mad — searched one copy only | *"The neighbour search was ASU-only; symmetry mates are the first thing to check for an isolated atom."* Same incident as slide 12 row 2, shown here for the symmetry aspect |
| nsf-d2-ligand — slid the ligand one repeat distance | *"Acted on the untested assumption that contact implies adjacency in the ASU via the identity operator; the contact was actually via a rotation, so the shift…"* The 10.4 Å closest approach is from the same lead |

**On the gene-5-mad row (slide 10):** the causal link is the agent's own diagnosis, not an
established fact. Its review says an explicit 3.1 Å cutoff *"might have produced a cleaner
substructure with fewer spurious low-occupancy sites — precisely the sites that later caused
trouble."* The slide says "its own review names this as the likely reason" rather than asserting
cause. The counts (6 found, 2 expected, 3 into the model, 2 deleted) are facts from the run; the
link between them and the ignored cutoff is a hypothesis the agent raised about itself.

**On the slide 11 title:** the original name for this mode was *uncontrolled comparison / no
significance*, which fitted only two of its four examples — refining occupancies too early and
accepting 165 waters on an overall score are not comparisons at all. The mode is now named for what
all four share: a conclusion drawn from a number that cannot support it.

**One incident appears on two slides.** The gene-5-mad selenium call is both a *stated before checking*
and a *forgot the crystal* failure — it is the same decision seen from two angles, and each slide says
which aspect it is showing. No other incident is repeated across these five slides.


---

## Slide 16 — "The evaluation also invents leads"

| element | source |
|---|---|
| **Which reader raised it: the in-run self-flag** | `runs/porin-twin/A/run_1/CANDIDATES/review_queue.md` — the R3 lead carries `flagged_by: self`, severity **moderate** |
| the R3 / merohedral claim | same lead |
| *"the screening step kept it and repeated the claim"* | the same lead survived screening with its reason echoing the claim |
| the crystallography that refutes it | R3's point group is lower in symmetry than its own lattice, which is precisely the condition for merohedral twinning; R3 is a standard example |

---

## Slide 17 — "Can the Expert be fixed by what we found?"

| element | source |
|---|---|
| *"6 of the 11 datasets … reported different numbers for the same structure"* | `TABLE1.md`, tool-vs-tool section, produced by `table1.py` |
| the added instruction text | the cross-check clause of the Class-3 skill, as run in the treatment arm |
| *"ran the separate check 7 times where the control ran it twice"* | counted from `runs/refined_start/{A3,A3C}/run_1/session.jsonl` — executions of `phenix.rotalyze` / `ramalyze` / `cbetadev`, whether launched as a job or from the shell |
| *"agree to ≤0.0003 … R-work ≈ 0.181, R-free ≈ 0.237 is robust"* | the treatment run's own closing report |
| *"a different instrument than the refine log"* | the treatment run's reasoning, quoting the instruction back |
| *"on a twinned structure both arms already did it"* | porin-twin control and treatment both reported twin-corrected and conventional R-factors with sources |


---

## Figures used elsewhere in the deck

| figure | slide | source |
|---|---|---|
| 6 of 11 datasets show two programs disagreeing on the same number | 9 (row 4) | `TABLE1.md`, the "Tool-vs-tool discrepancies" section, produced by `table1.py` — a deterministic parse of refine logs vs standalone MolProbity output. No LLM involved |
| beta-blip: grade **major**, coverage **0.501**, Cα-RMSD **0.33 Å** | 10 | `scores.json` per run (`sci.grade`, `sci.metrics.coverage.coverage`, `sci.metrics.superpose.ca_rmsd_A`), computed by `pilot/science.py` against the deposited reference |
| nsf-d2-ligand: 0 of 31 ATP atoms above 3σ | 7 | `runs/nsf-d2-ligand/A/run_1/artifacts/self_analysis.md`, entry D1b |
| Failure-mode recurrence counts (11/11, 5/11, 5/11, 3/11, 3/11, 2/11) | 8, and the per-mode slides 9–14 | Hand-assigned in `interim_findings.md` §5 by mapping each case's queue onto the taxonomy. **This is the one figure on the deck that is a judgement, not a count** — the mapping is reproducible from the queues but not mechanical |
| (moved to the slide-12 section above) | 12 | `c3_test_result.md`; counted from `runs/refined_start/{A3,A3C}/run_1/session.jsonl` by counting `phenix_start_job` and Bash invocations of `phenix.rotalyze` / `ramalyze` / `cbetadev` |
| Channel rule 6/6 | 12 | `fixtures/deposit_listings.txt` — `grep -c "FINAL_REPORT.md present: yes"` |


### Why slide 9 says 6 of 11 while slide 8 says 11 of 11

These are **not the same claim**, and the deck now says so on the slide itself.

- **11 of 11** — *believing a tool without checking it*, as identified by the AI readers across every
  dataset. It covers every form: trusting a tool that reported success and wrote nothing, checking an
  edit with the tool that made it, running a job for a number and never reading it.
- **6 of 11** — the single form a script can detect unaided: two programs reporting the same
  quantity differently, with no reconciliation. A script can only see this when two programs happen
  to report the same quantity, so it is a **narrower question**, not a smaller count of the same one.

The 11/11 figure is a judgement (see the caveat at the end of this document). The 6/11 figure is
mechanical, from `table1.py`.

---

## The one figure that is not a count

**Failure-mode recurrence (slide 8).** Every other number here is produced by a script from a shipped
artifact. The assignment of each flagged decision to a failure mode is mine: I read each case's queue and judged which class each lead
belonged to. The evidence is reproducible — the leads are in the queue files — but two readers could
assign a borderline lead differently, and the 5/11 counts in particular would move by one either way.
If the audience presses on any number, this is the one to concede.
