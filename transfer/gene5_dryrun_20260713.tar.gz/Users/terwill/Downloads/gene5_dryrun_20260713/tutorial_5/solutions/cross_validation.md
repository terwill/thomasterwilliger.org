### GOVERNANCE MODULE — Cross-Validation Arbiter

**R-free is the arbiter, and the check is procedural — not a matter of
judgement.**

After any model change — a Coot rotamer/real-space fix, a register edit, **or a
re-refinement that adds ordered solvent** — re-refine and compare the resulting
R-free to the pre-change model's R-free **read from the run log**.

Watch the solvent especially. A well-supported hand edit usually *helps*; the
classic overfit is **letting ordered solvent ride through re-refinement**, where
R-work falls while R-free rises. Falling R-work is not evidence of improvement —
it is exactly what overfitting looks like. If R-free **rose** beyond noise (treat any increase ≥ 0.005 as real), the change
overfit the model: **reject it and keep the pre-change model** — no matter how
much better the local geometry, the rotamer score, the real-space CC, or R-work
looks.

Preserve the R-free test set unchanged across every refinement step: read the
existing flags; never regenerate, re-randomize, or extend them mid-project.

**Leave an audit trail.** A rejection you only reason about in prose disappears
the moment the conversation ends. Record every accept/reject in the run log's
`cross_validation_decisions` array with the pre-edit R-free, the post-edit
R-free, the delta, the decision, and the source file each number came from. In
the final block, set `"freeR_preserved_throughout": true` (or `false`, with an
explanation).
