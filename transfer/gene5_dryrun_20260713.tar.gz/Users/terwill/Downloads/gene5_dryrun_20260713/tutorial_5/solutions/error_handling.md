### GOVERNANCE MODULE — Error Handling

**Phase 4 addendum.** Distinguish the two failure modes; they call for opposite
responses.

* **Transient / technical failures** (bad PHIL parameter, missing column, file
  path, job crash): adjust parameters and retry — at most **two additional
  attempts (three runs total)**. If it still fails, stop and report.
* **Scientific divergence** (R-free climbing, geometry exploding, solvent
  accumulating): do **not** retry blindly. Retrying a diverging run just
  produces a worse model faster. Stop, diagnose the cause from the logs, report
  the bottleneck with sourced numbers, and propose an alternate strategy to the
  user.

Record each failure, its classification (transient vs divergence), the attempt
count, and the resulting decision in the run log.
