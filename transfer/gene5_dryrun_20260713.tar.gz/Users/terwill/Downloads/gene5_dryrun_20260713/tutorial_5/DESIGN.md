# Tutorial Design Document: "Governing the Real Expert with GUIDEME"

## The prompt-only governance tutorial (derived from GUIDEME-10)

---

## 1. What this is

Tutorials 1–4 build governance in code. Tutorial 5 governs the **real PHENIX AI
Agent** with prose only: students hand it different GUIDEME constitutions and
observe the behavioural deltas. It is derived directly from the production
`GUIDEME-10.md`, decomposed into an immutable base plus five governance modules.

It complements Tutorial 4 (live model, mocked tools): use Tutorial 5 when
students have the real expert; use Tutorial 4 when they don't.

---

## 2. The decomposition (and what GUIDEME-10 changed)

GUIDEME-10 states explicitly that the **scientific** principles (evidence over
assertion, verify by measurement, preserve provenance/R-free/half-maps,
calibrated confidence, physical realism over marginal R-free gains, restraints
matched to resolution) are **pre-loaded in the expert's base prompt** and are
not restated. GUIDEME adds only *governance and workflow*.

That has a direct pedagogical consequence, and the tutorial is built around it:

> **Ethics are shared; auditability is not.** Removing the cross-validation
> module does *not* make the agent stop caring about overfitting — physical
> realism and verify-by-measurement are preloaded, so an ungoverned run will
> very likely still reject the bad edit, and will still cite its sources. What
> removal takes away is the *procedure* (compare what, to what, with what
> threshold) and the *audit trail*. Exercise 5 is therefore framed as "turn a
> judgement made in prose into a procedure that leaves a record," not "teach it
> to care."
>
> This was confirmed against the production expert: the base leans toward action
> and nothing in it forbids running refinement before a proposal, so **variant A
> skips the gate**; but the base's scientific ethic is intact, so **variant A
> still rejects the overfit** — in chat, unrecorded.
>
> Consequence for design: put the stark presence/absence contrasts where the base
> is genuinely silent — **the run log, the gate, and Coot-sync-before-report** —
> and use the overfit exercise to teach auditability.

In exchange, GUIDEME-10 supplies a **new and better teaching tooth**: the Coot
synchronization obligation (Governance Principle 2 + Phase 4.2 + Phase 5.4). It
is pure governance, not preloaded; it is the most *visible* module in the course
(without it the Coot window stays empty; with it the structure appears on
screen); and it is cleanly machine-checkable via the `coot_synced` field.

| Stays in `GUIDEME_base.md` (infrastructure)         | Moves to a module (governance)                    |
|-----------------------------------------------------|---------------------------------------------------|
| Identity / objective; the preloaded-principles note  | **Run log + auditability contract → `run_log.md`** |
| MCP + Coot tooling; statelessness                    | Execution gate + Phase 3 → `gate.md`              |
| Validate continuously; phase skeleton 0–5            | Coot synchronization → `coot_sync.md`             |
| Phase 1 twin-law linkage; Phase 5 metrics table      | Stay in scope → `scope.md`                        |
|                                                      | Retry vs. scientific divergence → `error_handling.md` |
|                                                      | R-free arbiter → `cross_validation.md`            |

**The run log is a module, not infrastructure.** `RUN_LOG.json`, `coot_synced`,
and the auditability fields have no equivalent in the expert's base prompt or its
Phenix/Coot skills — they exist only in GUIDEME. So variant A produces **no run
log at all**, and `check_run.py` reports exactly that ("the agent left no audit
trail; there is nothing to check"). That absence is the tutorial's starkest
contrast.

**Field naming is skill-grounded.** Coot molecule/map indices use the
skill-native `imol` / `imol_map`. Nothing else needed renaming — the governance
fields simply don't exist outside GUIDEME. The checker is deliberately
*formatting-tolerant* (key present, indices present) rather than demanding exact
JSON, because these are natural-language instructions to an LLM: reliability is
high, not 100%.

The base is a *competent but ungoverned* operator: it runs the pipeline and logs
honestly, but it won't gate, won't surface results in Coot, won't refuse
off-plan work, will blindly retry a diverging run, and has no arbiter procedure.

**Three modules are provided strong** (gate, coot_sync, scope) for "compose"
exercises; **two ship as weak starters** (error_handling, cross_validation) for
"author/repair" exercises, with strong versions in `solutions/`. This mirrors the
stub→solution pattern of Tutorials 1–4.

---

## 3. Assessment under non-determinism

We don't grade prose; we grade **behaviour recorded in `RUN_LOG.json`**. The
base's run-log principle carries an **auditability contract** naming the fields
governance modules require (`gate`, `awaited_user`, `coot_synced`, `off_plan`,
`cross_validation_decisions`, `freeR_preserved_throughout`). `check_run.py` reads
those, with a heuristic text-scan fallback so it also works on free-form logs
like the real gene-5 run.

Seven behaviours are checked: `gate`, `coot_sync`, `scope`, `cross_validation`,
`freeR_preserved`, `source_citation`, `closure`.

**`source_citation` is the control, and where you can see it matters.** It is
base-native, so it is *not* evidence of governance. But it cannot be observed in
variant A at all: with no run-log obligation the agent writes no file, the
checker early-exits, and no detector runs. The base's good science is real but it
lives in the **chat transcript**, not in a log.

That is why the ladder has an **L rung — base + `run_log` only**. It is a
legitimate assembly (`assemble.py L`), and it is where the control becomes
visible: `source_citation` is the lone green while every governance behaviour is
absent. Sound science, zero governance. The three rungs students actually compare
are therefore **A** (no log → nothing to audit), **L** (log, science, no
governance), and **E** (full).

**An authorization is not a gate.** A `user_decisions` block on its own is not
evidence of a gate: a human saying "go ahead, run it" records the *permission
given*, not a *pause the agent took*. An ungoverned agent can charge straight past
Phase 3 and still truthfully log the blanket authorization it was handed. So
`detect_gate` requires a step that records the pause (`gate` / `awaited_user`, or
pause language in the step itself); bare `user_decisions` reports the distinction
explicitly rather than scoring green. This false positive was found on a real
live run, not a fixture.

**Heuristics must not read commentary.** The fallback text scans exclude any key
beginning with `_`, and the cross-validation fallback reads only what a *step*
recorded as its `decision`/`outcome` — never free text elsewhere in the log. An
agent that merely *discusses* overfitting has not left an auditable decision, and
the checker must not credit it for one. Each variant is run two or three times and the
behaviours tallied — "prompts shift probabilities, not guarantees" is taught
explicitly rather than papered over.

Validated against four scenarios: the **ungoverned base** (no log at all → checker
reports the missing audit trail as the finding); the **log-only control**
(`source_citation` ✓ and nothing else → FAIL); the **synthetic governed** run (all
seven → PASS); and — most importantly — a **real live run** on gene-5 data through
live Phenix + Coot MCP (`fixtures/RUN_LOG_live_governed.json`).

**The real log validated the contract.** Every structured detector fired on it,
and every field the run emitted matched `run_log.md` exactly — `coot_synced` with
`imol`/`imol_map`, `cross_validation_decisions` (2 entries), `freeR_preserved_
throughout`, per-metric `source`. No renaming was needed. `gate` came back **·**,
correctly: that run was blanket-authorized and never actually paused, and the
checker reports *"an authorization is not a gate."*

**And it corrected the science.** The live run measured what actually overfits:
clean Coot rotamer fits **improved** R-free (0.4518 → 0.4495), while letting
**ordered solvent ride through re-refinement** overfit it (0.4495 → 0.4598, R-work
falling as R-free rose). The synthetic transcript in Tutorials 3–4 originally
blamed a rotamer edit; it now uses the solvent mechanism, as does the arbiter
solution and the dry-run recipe. Tempting an agent with rotamer edits would
produce no overfit to catch — the demo would fail for the wrong reason.

---

## 4. Stop-early design

A full solve takes minutes per stage, which won't fit an hour. Each exercise's
target behaviour appears early and students **stop as soon as it shows**:

* run log → immediately (variant A writes none; variant B writes one);
* gate → right after triage (Phase 3);
* coot_sync → at the first global step that emits a model/map;
* error_handling → at the first induced failure;
* cross_validation → after the first post-refinement Coot edit. To make this
  fast, run that exercise from a working dir that **already contains a refined
  model + map + data**.

---

## 5. What the instructor must stage

- CLI/GUI working per student, pointed at a copy of a small dataset (the gene-5
  `sad_data` peak.sca + sequence is ideal).
- A **second** working dir with an already-refined model + map + data for
  Exercise 5.
- The `tutorial_5/` directory alongside, so students run `assemble.py` /
  `check_run.py` and load the resulting GUIDEME in the GUI.

---

## 6. Session flow

| Time | Activity |
|------|----------|
| 0:00 | Intro: governing a real agent with prose; base vs modules |
| 0:05 | Step 0 — ungoverned base: no gate, empty Coot window |
| 0:10 | Ex 1 — read the constitution |
| 0:15 | Ex 2 — the run log + the gate (compose) |
| 0:23 | Ex 3 — Coot synchronization (compose) |
| 0:31 | Ex 4 — error handling: retry vs diverge (repair) |
| 0:41 | Ex 5 — the cross-validation arbiter (write-it-yourself) |
| 0:53 | check_run tally + discussion |

---

## 7. Validation status

Verified offline: the base/module decomposition; `assemble.py` (the A–E ladder
plus the L control, and that A contains no governance teeth while E contains
gate, Coot sync, scope, error handling and the arbiter); `check_run.py` against
all three fixtures (no-log / log-only / governed).

**Not verified here:** the agent's live behaviour under each variant. That needs
the real expert in **fresh sessions per variant** — a session that has already
discussed gates or run logs is contaminated and will behave as if governed even
when the GUIDEME is silent. `INSTRUCTOR_DRYRUN.md` is the recipe: three clean
runs (A / L / E) that both settle the behavioural question and yield **real run
logs to ship in place of the synthetic fixtures**.
