# Tutorial 5: Governing the Real Expert with GUIDEME

## What You'll Do

In Tutorials 3 and 4 you governed an agent with *code*. Here you govern the
**real PHENIX expert** with *prose*. You'll hand the agent different
constitutions — a base plus governance modules — and watch the same model
behave differently because of what its instructions say. No Python to write:
your deliverable is the GUIDEME.

This is the lecture's thesis at full strength (slides 15, 20): the disciplines
you built as code in Tutorials 1–4 — gate, scope, guardrail, error handling —
are here just **paragraphs of English**, and editing them reprograms a real,
non-deterministic agent.

**Time:** ~55 minutes
**You'll edit:** `addons/error_handling.md` and `addons/cross_validation.md`
**You won't edit:** `GUIDEME_base.md` (the immutable scaffold)

> **Where this sits in the lecture.** The Self-directed agent (slides 4, 7, 22),
> governed entirely through its system prompt (slide 15). The Coot-sync module
> is the trust boundary made visible; the R-free arbiter is the silent-wrongness
> defence (slide 18).

---

## How a constitution is built

A runnable GUIDEME is the base plus zero or more **governance modules**:

```
GUIDEME_base.md             identity, MCP/Coot tooling, the phase skeleton —
                            DELIBERATELY UNGOVERNED (no run log at all)
addons/run_log.md           RUN_LOG.json + the auditability contract   [provided]
addons/gate.md              the execution gate (Phase 3 hard stop)     [provided]
addons/coot_sync.md         surface every new model/map in Coot        [provided]
addons/scope.md             stay in scope; no off-plan re-phasing      [provided]
addons/error_handling.md    retry vs. diverge         [STARTER — you repair it]
addons/cross_validation.md  the R-free arbiter        [STARTER — you write it]
```

Build one with the assembler:

```
python3 assemble.py E --out GUIDEME-mine.md   # base + all six modules
python3 assemble.py B --out GUIDEME-mine.md   # base + run log + gate
```

A pre-built ladder is in `variants/`: **A** (base — *no run log at all*) →
**L** (+run log only — the control) → **B** (+gate) → **C** (+Coot sync) →
**D** (+scope) → **E** (full ≈ the production GUIDEME).

> **A note on what's already in the model — read this before Exercise 5.**
> The expert's own base prompt already holds the *scientific* principles:
> evidence over assertion, verify by measurement (not by eye), preserve R-free,
> physical realism over a marginally better R-free or CC. Your GUIDEME does not
> restate them.
>
> So the ungoverned agent is **not** a bad scientist. Run it and it will still
> cite its sources, and it will very likely still refuse an overfitting edit.
> What it will *not* do is gate, surface its work in Coot, stay in scope, or
> **leave any record**. The rejection happens in the chat and evaporates.
>
> **Ethics are shared; auditability is not.** Governance is not the judgement —
> it is the forcing function and the audit trail. That is why "avoid
> overfitting" as a GUIDEME line changes nothing (the model already believes
> it), and why a *procedure* plus a *logged decision* changes everything.
>
> Note where you look for each half: the **science** shows up in the chat
> transcript (it cites sources; it refuses the bad edit). The **governance**
> shows up in `RUN_LOG.json` — or doesn't. `check_run.py` reads the log, so it
> can only ever see the second half. That is the point, not a limitation.

---

## Setup

You run the expert from the CLI, which opens the GUI. There you say:

> please read GUIDEME-A.md and follow instructions

…and hit run. **Stop the run the moment the behaviour you're testing appears** —
it doesn't need to finish. Each exercise says what to watch for.

Every run writes `RUN_LOG.json` in the working directory. Afterwards, audit it:

```
python3 check_run.py <working_dir>/RUN_LOG.json
python3 check_run.py <working_dir>/RUN_LOG.json --expect gate,coot_sync,scope,cross_validation,closure
```

> The agent is non-deterministic, so we don't grade its words — we read its run
> log and check its *behaviour*. Run a variant two or three times and tally.
> Prompts shift probabilities, not guarantees: that's a finding, not a bug.

---

## Step 0: See the Problem (5 min)

Load the ungoverned base:

> please read variants/GUIDEME-A.md and follow instructions

Watch it work. It triages competently, it cites its source files — the science
is sound. But: it **starts phasing without ever pausing to ask you** (no gate),
your **Coot window stays empty** while it works (no sync), and when you go
looking for the audit trail:

```
python3 check_run.py <working_dir>/RUN_LOG.json
```

…there **is no `RUN_LOG.json`**. The agent left no record at all. That is the
finding, and it is the starkest one in the tutorial: a competent scientist you
cannot audit.

**Now look in the chat transcript instead.** You'll find the agent naming the
source file for every number it reports — and later, if you tempt it with an
overfitting edit, very likely refusing it on cross-validation grounds. It is
*not* a bad scientist. It simply leaves nothing behind.

Run the control to make that concrete — the base plus the run-log module and
**nothing else**:

```
python3 assemble.py L --out GUIDEME-log-only.md
python3 check_run.py <working_dir>/RUN_LOG.json
```

Now there's a log, and exactly one thing is green: `source_citation`. Every
governance behaviour — gate, Coot sync, scope, the recorded arbiter decision — is
absent. **Sound science, zero governance.** That's your baseline, and everything
you add from here is governance.

---

## Exercise 1: Read the Constitution (5 min)

Open `GUIDEME_base.md` and the five files in `addons/`. Notice the split: the
base has the *machinery* (how to reach Phenix and Coot, how to keep the run log)
but none of the *governance*. Each module is one obligation in plain English.
That separation is the whole idea — governance is editable text, not buried code.

---

## Exercise 2: The Run Log and the Gate (8 min) — compose

```
python3 assemble.py B --out GUIDEME-gate.md
```
> please read GUIDEME-gate.md and follow instructions

Two things change at once. The agent now reaches **Phase 3 — THE GATE**, lays
out a proposal, and stops: *"I will not execute phasing/refinement until you
respond."* And this time it is **writing `RUN_LOG.json`** as it goes. Stop at the
gate and audit it:

```
python3 check_run.py <working_dir>/RUN_LOG.json --expect gate,source_citation
```

Two paragraphs turned an agent that charged ahead and vanished into one that
asks first and keeps receipts.

---

## Exercise 3: Coot Synchronization (8 min) — compose

The most visible module in the course. Add it:

```
python3 assemble.py C --out GUIDEME-coot.md
```

Run it, answer the gate, and **watch your Coot window**. Where the base ran the
pipeline silently server-side, the agent now loads each new model and map into
your live Coot session *as part of finishing the job*, before it reports the
numbers. The structure appears on your screen. Stop after the first global step:

```
python3 check_run.py <working_dir>/RUN_LOG.json --expect gate,coot_sync
```

This is a trust-boundary lesson: an agent whose work you cannot see is an agent
you cannot check.

---

## Exercise 4: Error Handling (10 min) — repair

Open `addons/error_handling.md`. It says "if something goes wrong, try again
until it works" — which is not just vague, it's *dangerous*: it tells the agent
to retry a run that is diverging scientifically, producing a worse model faster.

Rewrite it so the two cases are distinct and bounded:

- **transient/technical** failure (bad parameter, missing column, crash) → adjust
  and retry, with a hard cap on attempts;
- **scientific divergence** (R-free climbing, geometry exploding) → do *not*
  retry; stop, diagnose, report, propose an alternative.

Assemble and run:

```
python3 assemble.py E --out GUIDEME-mine.md    # uses YOUR edited module
```

(Reference: `solutions/error_handling.md`.)

---

## Exercise 5: The Cross-Validation Arbiter (12 min) — write this one yourself

The centerpiece. This is the real moment from the production gene-5 run: a Coot
rotamer fix looked cleaner locally, but re-refinement pushed R-free **up**
(0.240 → 0.252–0.258). The governed agent rejected the edit and kept the better
model.

Here is the subtlety, and it is the best idea in the session: **the ungoverned
agent probably rejects the bad edit too.** Physical realism and verify-by-
measurement are already in its base prompt. So do not write a module that tells
it to care — it already cares.

Open `addons/cross_validation.md`. The starter says "try to keep R-free low and
avoid overfitting," which the agent already believes; it changes nothing. Your
job is to turn a judgement it makes *in prose* into a **procedure it executes**
and a **record it leaves behind**:

- after a model edit, re-refine and compare R-free to the pre-edit model **read
  from the run log**;
- if R-free **rose** beyond noise, **reject** the edit and keep the pre-edit
  model — however good the geometry, rotamer score, or real-space CC looks;
- **record** the decision (both R-free values) in `cross_validation_decisions`.

> **Tip for a fast demo.** Cross-validation only bites *after* refinement, so
> start this exercise from the working directory that already contains a refined
> model + map + data, and ask the agent to improve it. It reaches a Coot edit in
> a minute or two; stop right after the arbiter fires.

```
python3 assemble.py E --out GUIDEME-mine.md
python3 check_run.py <working_dir>/RUN_LOG.json --expect gate,coot_sync,scope,cross_validation,closure
```

When the run log shows the agent rejecting an R-free-worsening edit **and
recording the before/after delta and the reason**, you've reproduced production
behaviour by writing one paragraph. Compare against the log-only run: same
scientific call, no evidence it was ever made.

> **Run it more than once.** The base has the *principle* but no forcing
> function, so an ungoverned agent usually rejects the overfit — and occasionally
> keeps it. If you catch that, don't hide it: it's the sharpest argument in the
> course for why governance externalises the rule instead of trusting the model
> to remember it every time.

(Reference: `solutions/cross_validation.md`.)

---

## Discussion

1. **You governed a real expert without touching its code.** Every behaviour
   change came from the constitution. That's what a system prompt *is*.

2. **Ethics are shared; auditability is not.** The model already "knows" not to
   overfit, and it proves it even ungoverned. What the arbiter module adds is a
   *procedure* (compare to what, when, with what threshold) and a *record*.
   Aspirational prose governs nothing; operational prose governs precisely — and
   an unrecorded good decision is indistinguishable, later, from one that was
   never made.

3. **Governance is modular.** Gate, Coot sync, scope, error handling, arbiter —
   independent paragraphs you can add, remove, and test in isolation. Same
   disciplines you wrote as code in Tutorials 1–4, relocated into prose.

4. **Prose is powerful and probabilistic.** The same GUIDEME may not behave
   identically every run. A good constitution produces the right behaviour
   *robustly* — which is why you check the log, and check it more than once.

---

## Files

```
README.md                   You're reading it
GUIDEME_base.md             Immutable base (you don't edit this)
addons/run_log.md           RUN_LOG.json + audit contract   [provided]
addons/gate.md              Execution gate                  [provided]
addons/coot_sync.md         Coot synchronization            [provided]
addons/scope.md             Stay in scope                   [provided]
addons/error_handling.md    Retry vs diverge  [STARTER — Exercise 4]
addons/cross_validation.md  R-free arbiter    [STARTER — Exercise 5]
assemble.py                 Build a GUIDEME: base + chosen modules
variants/GUIDEME-A..E.md    Pre-built ladder: A (no log) · L (log only, the
                            control) · B · C · D · E (full)
fixtures/                   Example run logs:
                              RUN_LOG_live_governed.json  ← REAL run, live Phenix
                                +Coot MCP on gene-5 data (gate · : it was blanket-
                                authorized and never paused — "an authorization is
                                not a gate")
                              RUN_LOG_governed.json       ← synthetic, all 7 green
                              RUN_LOG_log_only.json       ← the control
check_run.py                Read RUN_LOG.json; report governance behaviours
INSTRUCTOR_DRYRUN.md        Instructor: capture real logs; settle the A/B
fixtures/                   Example run logs:
                              RUN_LOG_live_governed.json  ← REAL run, live Phenix
                                +Coot MCP on gene-5 data (gate · : it was blanket-
                                authorized and never paused — "an authorization is
                                not a gate")
                              RUN_LOG_governed.json       ← synthetic, all 7 green
                              RUN_LOG_log_only.json       ← the control
solutions/                  Reference error_handling.md, cross_validation.md
```
