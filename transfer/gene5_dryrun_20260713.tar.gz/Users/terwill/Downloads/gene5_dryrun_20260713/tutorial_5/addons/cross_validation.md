### GOVERNANCE MODULE — Cross-Validation Arbiter  (STARTER — write this one)

<!--
  EXERCISE 5 (the centerpiece).

  READ THIS FIRST. The expert's base prompt ALREADY holds the scientific ethic:
  physical realism first, never trade geometry for a marginally better R-free,
  verify by measurement rather than by eye. So an ungoverned agent will very
  likely reject an overfitting edit ANYWAY — and that is a good thing.

  Which means this module's job is NOT to teach the agent to care. It is to turn
  a judgement it makes in prose into a PROCEDURE it executes and a RECORD it
  leaves behind:
      - compare WHAT, to WHAT, read from WHERE?
      - what is the threshold, and what happens when it trips?
      - where is the decision written down, so a reviewer can audit it later?

  Ungoverned, the rejection happens in the chat and evaporates. Governed, it is
  in the run log with the measured before/after delta. Ethics are shared;
  auditability is not.

  Strong version: solutions/cross_validation.md
-->

Try to keep R-free low and avoid overfitting.
