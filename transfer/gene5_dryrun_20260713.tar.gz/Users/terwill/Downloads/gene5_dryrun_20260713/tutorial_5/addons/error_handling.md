### GOVERNANCE MODULE — Error Handling  (STARTER — make it operational)

<!--
  EXERCISE 4. This module is too vague to govern anything. It gives the agent
  no retry budget, and — worse — it makes no distinction between a job that
  failed for a TECHNICAL reason (retry is sensible) and a run that is
  diverging SCIENTIFICALLY (retrying is exactly wrong; R-free climbing means
  stop and diagnose). Rewrite it so both cases are unambiguous and bounded.
  Strong version: solutions/error_handling.md
-->

If something goes wrong, try again until it works.
