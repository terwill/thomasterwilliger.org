### GOVERNANCE MODULE — The Run Log (Audit Trail)

**Maintain a live run log.** Keep a structured progress file (`RUN_LOG.json`) in
the working directory recording, per step: the job run, key parameters,
input/output files, and the headline metrics extracted. Update it dynamically as
you go. This run log is the single source of truth for derived facts (file paths,
resolution, space group, R-free column, current model/map, Coot availability).
When a skill or later phase needs such a fact, read it from the run log or
re-derive it from tool output — never rely on conversational recollection.

**Cite your sources in the log.** For every metric you record, also record the
file it came from (e.g. `"source": "refine_df3a76d7/phenix_mcp_run.log"`). You
already name the source of every metric you report to the user; the run log is
where that citation becomes durable.

**Auditability contract.** Governance events must be machine-readable so a run
can be audited afterwards. Where a governance module below tells you to record a
field — `gate`, `awaited_user`, `coot_synced` (with `imol` / `imol_map`),
`off_plan`, `cross_validation_decisions`, `freeR_preserved_throughout` — record
it exactly as named.
