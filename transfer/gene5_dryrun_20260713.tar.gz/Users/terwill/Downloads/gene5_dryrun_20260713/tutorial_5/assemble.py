#!/usr/bin/env python3
"""
assemble.py — Build a runnable GUIDEME from the base + governance add-ons.

A GUIDEME you hand the agent is GUIDEME_base.md with zero or more add-on
modules appended. This lets you (and your students) turn governance
behaviours on one at a time.

Usage:
    python3 assemble.py A                      # base only (no run log)  -> stdout
    python3 assemble.py L                      # + run log ONLY (the control)
    python3 assemble.py B                      # + execution gate
    python3 assemble.py C                      # + Coot synchronization
    python3 assemble.py D                      # + stay in scope
    python3 assemble.py E                      # full (~= GUIDEME-10)
    python3 assemble.py gate coot_sync         # an explicit module list
    python3 assemble.py E --out GUIDEME-mine.md
    python3 assemble.py E --use-solutions      # pull error_handling/cross_validation
                                               # from solutions/ instead of addons/

Students editing addons/error_handling.md and addons/cross_validation.md just
re-run `python3 assemble.py E --out GUIDEME-mine.md` and load the result.
"""

import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))

RECIPES = {
    "A": [],                                          # base only — no audit trail
    "L": ["run_log"],                                 # log only: sound science, zero governance
    "B": ["run_log", "gate"],                         # + run log + execution gate
    "C": ["run_log", "gate", "coot_sync"],            # + Coot synchronization
    "D": ["run_log", "gate", "coot_sync", "scope"],   # + stay in scope
    "E": ["run_log", "gate", "coot_sync", "scope",    # full ~= GUIDEME-10
          "error_handling", "cross_validation"],
}

ORDER = ["run_log", "gate", "coot_sync", "scope",
         "error_handling", "cross_validation"]


def read(path):
    with open(path) as f:
        return f.read().rstrip() + "\n"


def assemble(addons, use_solutions=False):
    parts = [read(os.path.join(HERE, "GUIDEME_base.md"))]
    # Keep a stable, sensible order regardless of how they were listed.
    ordered = [a for a in ORDER if a in addons]
    for name in ordered:
        src = os.path.join(HERE, "addons", name + ".md")
        if use_solutions:
            sol = os.path.join(HERE, "solutions", name + ".md")
            if os.path.exists(sol):
                src = sol
        if not os.path.exists(src):
            sys.stderr.write("warning: no add-on named '%s' — skipping\n" % name)
            continue
        parts.append("\n" + read(src))
    return "\n".join(parts)


def main():
    args = sys.argv[1:]
    if not args:
        print(__doc__)
        sys.exit(0)

    out = None
    use_solutions = False
    names = []
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--out":
            out = args[i + 1]; i += 2; continue
        if a == "--use-solutions":
            use_solutions = True; i += 1; continue
        names.append(a); i += 1

    addons = []
    for n in names:
        if n in RECIPES:
            addons += RECIPES[n]
        else:
            addons.append(n)
    # de-dup, preserve
    seen = set()
    addons = [a for a in addons if not (a in seen or seen.add(a))]

    text = assemble(addons, use_solutions=use_solutions)
    if out:
        with open(out, "w") as f:
            f.write(text)
        sys.stderr.write("wrote %s (%d add-ons: %s)\n"
                         % (out, len(addons), ", ".join(addons) or "none"))
    else:
        sys.stdout.write(text)


if __name__ == "__main__":
    main()
