# Presenter Notes — Tutorial 5: Governing the Real Expert with GUIDEME

Students govern the actual PHENIX agent with prose. No Python; the deliverable is
the constitution. Your job is to make the behavioural deltas land.

---

## Before the session (do a full dry run)

- Confirm the CLI → GUI flow on the student image, with a copy of a small dataset
  per student (gene-5 `sad_data`: peak.sca + sequence).
- Stage a **second** working dir with an already-refined model+map+data for
  Exercise 5, so the arbiter is reachable in a minute or two.
- Run variants **A** and **E** yourself end to end and save the `RUN_LOG.json`s.
  If a live run derails in class, walk the saved logs through `check_run.py`.
- Know the numbers: in gene-5 the arbiter rejected the Coot edits because
  re-refinement moved R-free 0.240 → 0.252–0.258. That's the Ex 5 story.

---

## Framing (3 min)

"You've built gate, guardrail, scope, and error handling as code. Today they're
five paragraphs of English, and the thing reading them is the real expert. Same
disciplines, no code."

Show the base/module split. Emphasize: the base can *operate* but won't *govern*.

**Say the honest part out loud** (it's the sharpest idea in the session):
the expert's base prompt already contains the scientific principles. Ungoverned,
it *still* cites its sources and *still* rejects an overfitting edit. It is not a
bad scientist. What it does not do is gate, show you its work in Coot, stay in
scope, or leave any record — the good decision happens in chat and evaporates.

**Ethics are shared; auditability is not.** Governance is not the judgement; it's
the forcing function and the audit trail. Put the stark contrasts on the run log,
the gate, and Coot-sync — where the base is genuinely silent — and use the overfit
exercise to teach auditability.

---

## Per-exercise beats

- **Step 0 (three rungs, in this order):** run **A** — competent, cites its
  sources in chat, science is fine — then ask the room for the run log. There
  isn't one. "A scientist you cannot audit." Then run **L** (base + run_log only):
  now there's a log, and exactly one green — `source_citation`. Every governance
  behaviour is absent. *Sound science, zero governance.* That's the baseline.
  Say plainly where each half is visible: science in the transcript, governance in
  the log. The checker only ever sees the log — by design.
- **Ex 2 (run log + gate):** cleanest demo of the day. Base charges into phasing and
  leaves no trace; add two modules and it stops to ask *and* keeps receipts. Run
  them back to back.
- **Ex 3 (Coot sync):** the most *visual* moment in the whole course. Put the Coot
  window on the projector. Base: it stays empty while the agent works. With the
  module: the model and map appear as each job finishes, before the agent even
  reports its numbers. Land it — "an agent whose work you can't see is one you
  can't check."
- **Ex 4 (error handling):** the lesson is retry-vs-diverge. Ask why "just try
  again" is actively dangerous when R-free is climbing. (Because you get a worse
  model, faster.)
- **Ex 5 (arbiter):** centerpiece and the gene-5 moment. Budget the most time.
  Expect the ungoverned agent to reject the overfit *too* — do not treat that as a
  failed demo, it IS the lesson. And run it a few times: the base has the
  principle but no forcing function, so it will occasionally *keep* the overfit.
  If that happens in class, seize it — it is the single best argument for why
  governance externalises the rule instead of trusting the model to remember. The delta to point at is the `RUN_LOG.json`:
  governed, the rejection is recorded with the measured before/after delta;
  ungoverned, there is no evidence the decision was ever made. Land it: "same
  scientific call — but only one of these runs can be audited six months from
  now."

---

## The non-determinism lesson (don't skip)

Have a student run the same variant twice. Trajectories differ. A good
constitution is one whose *behaviour* is robust across runs even when the model's
wording isn't — which is exactly why you grade the run log, and grade it more
than once.

---

## If the real expert is unavailable

Fall back to Tutorial 4 (`--demo`): same governance, mocked agent, no key and no
Phenix. Or walk the saved `RUN_LOG.json` fixtures through `check_run.py` to show
how grading works.
