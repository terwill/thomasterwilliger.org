# Presenter Script — Tutorial 1: From Rules to Reasoning

## Before the Session

**Setup checklist:**
- [ ] Projector connected, terminal visible at large font size
- [ ] Your own tutorial directory ready to demo
- [ ] Run `python3 run_agent.py --compare` once to confirm it works
- [ ] Slide or diagram of a generic agent loop (optional)

**Have open in tabs/windows:**
1. Terminal in the tutorial directory
2. `decisions.py` in an editor (for showing stubs)
3. `fake_llm.py` in an editor (for the reveal)

---

## 0:00 — Opening (8 min)

### Set the scene (3 min)

> Welcome. Today you're going to build a decision-making agent from
> scratch — the kind of system that looks at a scientific pipeline
> and chooses what to run next.
>
> The pipeline we'll use comes from crystallography, but the pattern
> is universal. You have a sequence of programs — analyze data, find
> a model, position it, refine it, validate it. At each step,
> something has to decide: what do we run next?
>
> You could hard-code the sequence. That works for the simple case.
> But real pipelines have branches, loops, and ambiguity. So people
> are starting to use LLMs to make these decisions. The LLM looks at
> the current state — what files exist, what phase we're in, what
> the metrics look like — and proposes the next step.
>
> The problem is: LLMs are unreliable. They hallucinate program names.
> They return JSON wrapped in markdown fences. Sometimes they don't
> return JSON at all — just a paragraph of confident text. And they
> never know when to stop.
>
> So today you'll build both approaches — a rules engine and an LLM
> integration — and then combine them into a hybrid that's more
> reliable than either alone.

### Show the domain (2 min)

On projector, run:

```
cat programs.json
```

> Five programs. Each one declares what phase it belongs to, what
> files it needs, and what files it produces. The pipeline goes
> analyze → find_model → place_model → refine → validate. Simple
> enough that you can hold it in your head.

### Show the broken agent (3 min)

Run:

```
python3 run_agent.py --max=4
```

> Right now the decision engine is stubbed out — every function
> returns nothing. So the agent fails every cycle. Your job over
> the next 45 minutes is to make those decisions work.
>
> Open `decisions.py` in your editor. That's the only file you'll
> change. Everything else is already built.

**Point students to README.md:**

> The README walks you through everything step by step. Start at
> Exercise 1. The tests tell you exactly what to type next.

---

## 0:08 — Exercise 1: Valid Programs (5 min)

**Say:**

> Exercise 1 is a warm-up. You're implementing `get_valid_programs` —
> given the current phase, return which programs are allowed to run.
> It's about 5 lines. When you're done: `python3 test_decisions.py 1`

**Circulate.** This should be fast. Common issues:
- Forgetting to check `defn.get("valid_phases", [])` (KeyError)
- Returning a dict instead of a list of names

**When most students have 6/6:** move on verbally.

---

## 0:13 — Exercise 2: Parse the LLM (10 min)

**Say:**

> This is the most interesting exercise. Open `fake_llm.py` and
> scroll through it. Look at what the "LLM" actually returns.

On projector, show a few responses from `fake_llm.py`:

> Cycle 1: clean JSON. Easy.
> Cycle 2: JSON wrapped in markdown code fences. Common.
> Cycle 5: A chatty paragraph, then JSON at the end.
> Cycle 7: Just text. No JSON at all.
>
> Your parser has to handle all of these. The docstring has a
> skeleton — follow the 5 steps. The key insight: find the first
> `{` and the last `}`, slice between them, and try `json.loads`.

**Circulate.** This is where students spend the most time. Common issues:
- Not handling markdown fences (the ` ```json ` prefix)
- Forgetting `json.JSONDecodeError` in the try/except
- Checking for `"program"` key in the result

**Hint if stuck:** "Split on triple backticks first, then look for
the part that starts with `{`."

**At 0:20, if anyone is still stuck:**

> If you're stuck on the parser, run `python3 catchup.py 3` — it
> fills in Exercises 1-2 so you can move on. You can come back to
> the parser later.

---

## 0:23 — Exercise 3: Build Context (10 min)

**Say:**

> Now you're building the information packet that gets sent to the
> LLM. In a real agent, this is where most of the iteration happens —
> deciding what the LLM needs to know.
>
> The docstring tells you exactly what keys to include. The important
> one: call your own `get_valid_programs` function to tell the LLM
> what's allowed. That's your first taste of composition — one
> function feeding into another.

**Circulate.** Common issues:
- Forgetting to sort `available_files` (it's a set, needs to become a sorted list)
- `metrics_history[-1]` on an empty list (check length first)
- Not slicing history to last 3 entries

---

## 0:33 — Exercise 4: Rules Engine (10 min)

**Say:**

> Now you're building a decision engine that doesn't use the LLM at
> all — just rules. Get valid programs, check `state["refine_count"]`,
> and apply two simple rules.
>
> This is maybe 5 lines of code. When it passes, try it for real:
>
> `python3 run_agent.py --rules`

**On projector when first student finishes**, run `--rules`:

> Look: the rules engine completes the pipeline. Every time. Same
> path, same number of cycles. It works — but it's completely rigid.
> It can't adapt to anything unexpected.

**If students finish early**, have them read through `fake_llm.py`
and predict which cycles will cause problems.

---

## 0:43 — Exercise 5: Compose the Hybrid (5 min)

**Say:**

> Scroll to the bottom of `decisions.py`. The `decide` function is
> already written — it calls both the LLM and the rules engine. But
> Block A runs rules first and Block B tries the LLM second. That
> means the rules always win and the LLM is never used.
>
> Run the test: `python3 test_decisions.py 5`
>
> You'll see one failure. Swap Block A and Block B so the LLM goes
> first. That's it — maybe 10 seconds of cut-and-paste.

**This should be fast.** The conceptual lesson (fallback ordering)
is big, the typing is tiny.

---

## 0:48 — The Reveal: Compare (5 min)

**On projector:**

```
python3 run_agent.py --compare
```

> Three strategies, one table. Rules: completes, always the same
> path. LLM only: fails — the hallucinated name and the unparseable
> response each cause a skipped cycle, and the agent never finishes.
> Hybrid: completes, using the LLM when it works and rules when it
> doesn't.

Then run the hybrid in verbose mode:

```
python3 run_agent.py
```

> Watch the labels: [LLM], [LLM], [LLM], [RULES], [LLM]... The
> agent is seamlessly switching strategies. When the LLM returns
> clean JSON with a valid program, we use it — it chose well. When
> it hallucinates `phenix.refine` or returns plain text, rules take
> over without missing a beat.

**Pause for effect:**

> Six of the eight decisions came from the LLM. Two came from rules.
> The pipeline completed. That's the hybrid pattern: LLM proposes,
> rules verify.

---

## 0:53 — Discussion (7 min)

### Key points to make:

**1. Parsing is unglamorous but essential.**

> Every production agent has a parser like the one you wrote. Some
> agents use structured output modes to avoid the problem, but even
> those can fail. Your parser is the first line of defense.

**2. Context assembly is prompt engineering in code.**

> Your `build_context` function decided what the LLM sees. In a real
> agent, that function is hundreds of lines — assembling state
> summaries, recent history, available actions, constraints. It's
> the most-iterated part of the system.

**3. The hybrid pattern scales.**

> What you built with 2 strategies (LLM + rules) is the same
> pattern used in production agents with 5-10 strategies:
> LLM → rules → heuristics → cached decisions → human escalation.
> Each fallback level is more reliable but less flexible.

### If doing both tutorials:

> What we built today is the decision brain. But did you notice the
> LLM hallucinated `phenix.refine` and our rules fallback just
> picked a different program? In Tutorial 3, you'll build the
> validation layer — the safety net that catches and *corrects*
> those errors instead of silently falling back. The brain decides;
> the validators verify.

### Suggested discussion questions:

- "Where in your own pipelines do you make decisions that could
  be automated this way?"
- "What would break if the LLM returned valid JSON but with a
  wrong program — one that exists but isn't right for this phase?"
  (Segue to Tutorial 3)
- "What happens when the rules engine and the LLM disagree about
  when to stop refining?"

---

## Timing Safety Valves

**If running behind at 0:25 (Exercise 2 taking too long):**
Announce catchup: "Run `python3 catchup.py 3` to skip ahead."

**If running behind at 0:40 (Exercise 4 taking too long):**
Announce catchup: "Run `python3 catchup.py 5` to get to the good part."
Then do Exercise 5 and the comparison together as a group on the projector.

**If running ahead:**
Have fast students explore `fake_llm.py`, predict which cycles
will fail in LLM-only mode, or try writing additional rules
(e.g., "if R-free < 0.25, stop refining").

---

## Common Student Questions

**"Why not just tell the LLM to always return JSON?"**
> You can — that's structured output mode. But even structured
> outputs occasionally fail, and not all LLM providers support them.
> A robust parser is always needed.

**"Is the fake LLM realistic?"**
> These responses are modeled on real LLM output from the PHENIX
> agent. The formatting chaos — fences, preambles, plain text —
> is exactly what you get from production APIs.

**"Why not use LangChain / LangGraph / CrewAI?"**
> Those are great frameworks. What you built today is the core
> pattern they all implement: perceive → decide → act → update.
> Understanding the pattern makes the frameworks easier to use.

**"Could the rules engine just be the whole thing?"**
> For this 5-program pipeline, yes. For 20+ programs with
> branching, conditional steps, and ambiguous situations, rules
> become unmaintainable. The LLM handles the long tail of
> edge cases that rules can't anticipate.
