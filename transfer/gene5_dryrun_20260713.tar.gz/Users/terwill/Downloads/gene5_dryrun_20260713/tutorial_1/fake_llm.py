"""
fake_llm.py — Pre-recorded LLM responses with realistic formatting.

A real LLM returns raw text.  Sometimes it's clean JSON.  Sometimes
it wraps the JSON in markdown fences.  Sometimes it adds a chatty
preamble before the JSON.  Sometimes it forgets to return JSON at all.
Sometimes it hallucinates program names.

This module simulates all of those behaviors using pre-recorded
responses keyed by the current workflow phase and cycle number.
The responses are modeled on real LLM output from the PHENIX agent.
"""

# Each response is a raw string exactly as an LLM might return it.
# The student's parser must handle every format variation.

_RESPONSES = {
    # ── Phase: analyze ──
    ("analyze", 1): (
        '{"program": "analyze_data", "files": {"data": "data.mtz"}, '
        '"reasoning": "We should start by assessing data quality — '
        'resolution, completeness, and any pathologies before proceeding.'
        '"}'
    ),

    # ── Phase: find_model ──
    # Markdown-fenced JSON (very common LLM behavior)
    ("find_model", 2): (
        "Based on the analysis, the data quality is acceptable. "
        "Here's my recommendation:\n\n"
        "```json\n"
        '{"program": "find_model", "files": {"sequence": "sequence.fa"}, '
        '"reasoning": "We need a starting model. I\'ll search for '
        'homologous structures using the sequence."}\n'
        "```"
    ),
    # Fallback for find_model at other cycles
    ("find_model", None): (
        '{"program": "find_model", "files": {"sequence": "sequence.fa"}, '
        '"reasoning": "Search for homologous structures."}'
    ),

    # ── Phase: place_model ──
    # Clean JSON
    ("place_model", 3): (
        '{"program": "place_model", '
        '"files": {"model": "predicted_model.pdb", "data": "data.mtz"}, '
        '"reasoning": "Position the predicted model in the unit cell '
        'by molecular replacement."}'
    ),
    ("place_model", None): (
        '{"program": "place_model", '
        '"files": {"model": "predicted_model.pdb", "data": "data.mtz"}, '
        '"reasoning": "Run molecular replacement."}'
    ),

    # ── Phase: refine ──
    # First refine: clean JSON
    ("refine", 4): (
        '{"program": "refine", '
        '"files": {"model": "placed_model.pdb", "data": "data.mtz"}, '
        '"reasoning": "Initial R-free of 0.48 is expected for a molecular '
        'replacement solution. Refinement should improve this significantly."}'
    ),
    # Second refine: chatty preamble then JSON
    ("refine", 5): (
        "Looking at the current metrics, R-free has dropped to 0.28 which "
        "is good progress. There's still room for improvement.\n\n"
        '{"program": "refine", '
        '"files": {"model": "refined_model.pdb", "data": "data.mtz"}, '
        '"reasoning": "Continue refinement to push R-free lower."}'
    ),
    # Third refine: HALLUCINATED program name
    ("refine", 6): (
        '{"program": "phenix.refine", '
        '"files": {"model": "refined_model.pdb", "data": "data.mtz"}, '
        '"reasoning": "R-free at 0.255, still improving. Running '
        'phenix.refine with tighter geometric restraints."}'
    ),
    # Fourth refine: plain text, no JSON at all
    ("refine", 7): (
        "The model is looking quite good now with an R-free of 0.24. "
        "I think we should continue refining — there might be some "
        "residual peaks in the electron density that could resolve "
        "with one more round of coordinate and B-factor refinement."
    ),
    # Fifth refine onward: always wants more refinement
    ("refine", 8): (
        '{"program": "refine", '
        '"files": {"model": "refined_model.pdb", "data": "data.mtz"}, '
        '"reasoning": "Almost converged. One more cycle to confirm stability."}'
    ),
    ("refine", None): (
        '{"program": "refine", '
        '"files": {"model": "refined_model.pdb", "data": "data.mtz"}, '
        '"reasoning": "Continue refinement."}'
    ),

    # ── Phase: validate ──
    ("validate", None): (
        '{"program": "validate", '
        '"files": {"model": "refined_model.pdb"}, '
        '"reasoning": "The model is ready for final quality assessment."}'
    ),
}


def query_llm(context):
    """
    Send context to the "LLM" and return its raw text response.

    In a real system this would call an API endpoint.  Here we return
    pre-recorded responses that exhibit realistic formatting variations.

    Args:
        context: dict with at least "current_phase" and "cycle"

    Returns:
        str: raw text response (may or may not be valid JSON)
    """
    phase = context.get("current_phase", "")
    cycle = context.get("cycle", 0)

    # Try exact (phase, cycle) match first, then (phase, None) fallback
    key = (phase, cycle)
    if key in _RESPONSES:
        return _RESPONSES[key]

    fallback_key = (phase, None)
    if fallback_key in _RESPONSES:
        return _RESPONSES[fallback_key]

    # Ultimate fallback
    return '{"program": "unknown", "reasoning": "I am not sure what to do next."}'
