#!/usr/bin/env python3
"""
test_decisions.py — Tests for each exercise in decisions.py

Run all:     python3 test_decisions.py
Run one:     python3 test_decisions.py N    (N = 1..5)
"""

import sys
import json

from decisions import (
    get_valid_programs,
    parse_llm_response,
    build_context,
    decide_by_rules,
    decide,
)

PASS = 0
FAIL = 0


def load_programs():
    with open("programs.json", "r") as f:
        data = json.load(f)
    return data["programs"]


def check(label, got, expected):
    global PASS, FAIL
    if got == expected:
        print("  \033[32mPASS\033[0m: %s" % label)
        PASS += 1
    else:
        print("  \033[31mFAIL\033[0m: %s" % label)
        print("        expected: %s" % repr(expected))
        print("             got: %s" % repr(got))
        FAIL += 1


# =================================================================
# EXERCISE 1 TESTS
# =================================================================

def test_exercise_1():
    print("\n--- Exercise 1: get_valid_programs ---")
    progs = load_programs()

    result = get_valid_programs("analyze", progs)
    check("analyze phase → analyze_data", result, ["analyze_data"])

    result = get_valid_programs("find_model", progs)
    check("find_model phase → find_model", result, ["find_model"])

    result = get_valid_programs("refine", progs)
    check("refine phase → refine AND validate",
          sorted(result), ["refine", "validate"])

    result = get_valid_programs("validate", progs)
    check("validate phase includes validate", "validate" in result, True)

    result = get_valid_programs("nonexistent", progs)
    check("unknown phase → empty list", result, [])

    result = get_valid_programs("place_model", progs)
    check("place_model phase → place_model", result, ["place_model"])


# =================================================================
# EXERCISE 2 TESTS
# =================================================================

def test_exercise_2():
    print("\n--- Exercise 2: parse_llm_response ---")

    # Clean JSON
    result = parse_llm_response('{"program": "refine", "reasoning": "test"}')
    check("clean JSON parses", result is not None and result["program"] == "refine", True)

    # Markdown fenced
    result = parse_llm_response('```json\n{"program": "find_model"}\n```')
    check("markdown-fenced JSON parses",
          result is not None and result["program"] == "find_model", True)

    # Chatty preamble then JSON
    text = 'I recommend the following:\n\n{"program": "validate", "reasoning": "done"}'
    result = parse_llm_response(text)
    check("preamble + JSON parses",
          result is not None and result["program"] == "validate", True)

    # Plain text, no JSON
    result = parse_llm_response("I think we should refine the model further.")
    check("plain text → None", result, None)

    # Empty string
    result = parse_llm_response("")
    check("empty string → None", result, None)

    # JSON with extra text after
    text = '{"program": "refine"}\n\nLet me know if you need anything else!'
    result = parse_llm_response(text)
    check("JSON + trailing text parses",
          result is not None and result["program"] == "refine", True)


# =================================================================
# EXERCISE 3 TESTS
# =================================================================

def test_exercise_3():
    print("\n--- Exercise 3: build_context ---")
    progs = load_programs()

    state = {
        "current_phase": "refine",
        "available_files": {"data.mtz", "placed_model.pdb", "refined_model.pdb"},
        "program_defs": progs,
        "history": [
            {"program": "analyze_data", "cycle": 1},
            {"program": "find_model", "cycle": 2},
            {"program": "place_model", "cycle": 3},
            {"program": "refine", "cycle": 4},
            {"program": "refine", "cycle": 5},
        ],
        "metrics_history": [{}, {}, {"r_free": 0.48}, {"r_free": 0.28},
                            {"r_free": 0.255}],
        "cycle": 6,
    }

    ctx = build_context(state)

    check("has current_phase", ctx.get("current_phase"), "refine")
    check("has cycle", ctx.get("cycle"), 6)
    check("available_files is sorted list",
          isinstance(ctx.get("available_files"), list)
          and ctx["available_files"] == sorted(ctx["available_files"]), True)
    check("valid_programs includes refine and validate",
          sorted(ctx.get("valid_programs", [])), ["refine", "validate"])
    check("latest_metrics has r_free",
          "r_free" in ctx.get("latest_metrics", {}), True)
    check("recent_history is last 3 programs",
          ctx.get("recent_history"), ["place_model", "refine", "refine"])


# =================================================================
# EXERCISE 4 TESTS
# =================================================================

def test_exercise_4():
    print("\n--- Exercise 4: decide_by_rules ---")
    progs = load_programs()

    # Analyze phase → analyze_data
    state = {
        "current_phase": "analyze",
        "available_files": {"data.mtz", "sequence.fa"},
        "program_defs": progs,
        "history": [],
        "metrics_history": [],
        "refine_count": 0,
    }
    d = decide_by_rules(state)
    check("analyze → analyze_data",
          d is not None and d["program"] == "analyze_data", True)

    # Refine phase, 2 refines → refine (not enough yet)
    state2 = {
        "current_phase": "refine",
        "available_files": {"data.mtz", "placed_model.pdb", "refined_model.pdb"},
        "program_defs": progs,
        "history": [
            {"program": "refine", "cycle": 1},
            {"program": "refine", "cycle": 2},
        ],
        "metrics_history": [{"r_free": 0.32}, {"r_free": 0.28}],
        "refine_count": 2,
    }
    d = decide_by_rules(state2)
    check("2 refines → still refine", d["program"] == "refine", True)

    # Refine phase, 3 refines → validate (enough!)
    state3 = {
        "current_phase": "refine",
        "available_files": {"data.mtz", "placed_model.pdb", "refined_model.pdb"},
        "program_defs": progs,
        "history": [
            {"program": "refine", "cycle": 1},
            {"program": "refine", "cycle": 2},
            {"program": "refine", "cycle": 3},
        ],
        "metrics_history": [{"r_free": 0.32}, {"r_free": 0.28}, {"r_free": 0.26}],
        "refine_count": 3,
    }
    d = decide_by_rules(state3)
    check("3 refines → validate", d["program"] == "validate", True)

    # Place_model phase → place_model
    state4 = {
        "current_phase": "place_model",
        "available_files": {"data.mtz", "predicted_model.pdb"},
        "program_defs": progs,
        "history": [{"program": "find_model", "cycle": 1}],
        "metrics_history": [{}],
        "refine_count": 0,
    }
    d = decide_by_rules(state4)
    check("place_model phase → place_model", d["program"] == "place_model", True)

    # Returns a dict with required keys
    check("decision has reasoning key", "reasoning" in d, True)


# =================================================================
# EXERCISE 5 TESTS
# =================================================================

def test_exercise_5():
    print("\n--- Exercise 5: decide (hybrid) ---")
    progs = load_programs()

    # Phase where LLM returns good JSON → should use LLM
    state = {
        "current_phase": "analyze",
        "available_files": {"data.mtz", "sequence.fa"},
        "program_defs": progs,
        "history": [],
        "metrics_history": [],
        "cycle": 1,
        "refine_count": 0,
    }
    d, source = decide(state)
    check("cycle 1: LLM returns clean JSON → uses LLM",
          source, "llm")

    # Phase where LLM returns plain text (no JSON) → should fall back to rules
    state2 = {
        "current_phase": "refine",
        "available_files": {"data.mtz", "placed_model.pdb", "refined_model.pdb"},
        "program_defs": progs,
        "history": [
            {"program": "refine", "cycle": 4},
            {"program": "refine", "cycle": 5},
        ],
        "metrics_history": [{"r_free": 0.28}, {"r_free": 0.255}],
        "cycle": 7,
        "refine_count": 2,
    }
    d, source = decide(state2)
    check("cycle 7: LLM returns plain text → falls back to rules",
          source, "rules")

    # Phase where LLM hallucinates program name → should fall back
    state3 = {
        "current_phase": "refine",
        "available_files": {"data.mtz", "placed_model.pdb", "refined_model.pdb"},
        "program_defs": progs,
        "history": [{"program": "refine", "cycle": 4}],
        "metrics_history": [{"r_free": 0.28}],
        "cycle": 6,
        "refine_count": 1,
    }
    d, source = decide(state3)
    check("cycle 6: LLM hallucinates 'phenix.refine' → falls back",
          source, "rules")

    # Regardless of source, decision has a valid program
    valid = sorted(["refine", "validate"])
    check("fallback decision is valid",
          d["program"] in valid, True)

    # Rules should be used when LLM produces plain text
    # This confirms the ORDER is correct: LLM first, rules fallback
    state4 = {
        "current_phase": "refine",
        "available_files": {"data.mtz", "placed_model.pdb", "refined_model.pdb"},
        "program_defs": progs,
        "history": [
            {"program": "refine", "cycle": 4},
            {"program": "refine", "cycle": 5},
            {"program": "refine", "cycle": 6},
        ],
        "metrics_history": [{"r_free": 0.28}, {"r_free": 0.255}, {"r_free": 0.24}],
        "cycle": 7,  # LLM returns plain text at cycle 7
        "refine_count": 3,
    }
    d, source = decide(state4)
    check("ORDERING: LLM fails → rules takes over",
          source, "rules")
    check("rules picks validate after 3 refines",
          d["program"], "validate")


# =================================================================
# SUMMARIES — What works now that didn't before
# =================================================================

EXERCISE_SUMMARIES = {
    1: """
\033[36m╔══════════════════════════════════════════════════════════╗
║  EXERCISE 1 COMPLETE: get_valid_programs                 ║
╠══════════════════════════════════════════════════════════╣
║                                                          ║
║  What you built:                                         ║
║    A function that filters programs by workflow phase.    ║
║                                                          ║
║  What works now:                                         ║
║    ✓ The agent can determine which programs are           ║
║      allowed to run at each pipeline step.               ║
║    ✓ "analyze" phase → only analyze_data                 ║
║    ✓ "refine"  phase → refine AND validate               ║
║    ✓ Unknown phases return an empty list (safe default)   ║
║                                                          ║
║  Before this exercise:                                   ║
║    ✗ The agent had no idea what programs were available   ║
║    ✗ Every decision attempt returned an empty list        ║
║                                                          ║
║  Next: python3 test_decisions.py 2                       ║
╚══════════════════════════════════════════════════════════╝\033[0m""",
    2: """
\033[36m╔══════════════════════════════════════════════════════════╗
║  EXERCISE 2 COMPLETE: parse_llm_response                 ║
╠══════════════════════════════════════════════════════════╣
║                                                          ║
║  What you built:                                         ║
║    A robust parser for unpredictable LLM text output.    ║
║                                                          ║
║  What works now:                                         ║
║    ✓ Clean JSON like {"program": "refine"} → parsed      ║
║    ✓ Markdown-fenced ```json ... ``` → parsed            ║
║    ✓ Chatty text + JSON at the end → parsed              ║
║    ✓ Plain text with no JSON → safely returns None       ║
║    ✓ Empty strings → safely returns None                 ║
║                                                          ║
║  Before this exercise:                                   ║
║    ✗ Every LLM response was ignored (parser returned     ║
║      None for everything, even clean JSON)               ║
║                                                          ║
║  Next: python3 test_decisions.py 3                       ║
╚══════════════════════════════════════════════════════════╝\033[0m""",
    3: """
\033[36m╔══════════════════════════════════════════════════════════╗
║  EXERCISE 3 COMPLETE: build_context                      ║
╠══════════════════════════════════════════════════════════╣
║                                                          ║
║  What you built:                                         ║
║    A context assembler that packages the agent's state    ║
║    into structured data the LLM can use.                 ║
║                                                          ║
║  What works now:                                         ║
║    ✓ LLM receives: phase, cycle, files, valid programs   ║
║    ✓ LLM receives: latest metrics (R-free, etc.)         ║
║    ✓ LLM receives: last 3 programs run (recent history)  ║
║    ✓ Your get_valid_programs feeds into the context       ║
║                                                          ║
║  Before this exercise:                                   ║
║    ✗ The LLM only received phase and cycle number        ║
║    ✗ It had no information about files, metrics, or      ║
║      what programs were allowed                          ║
║                                                          ║
║  Next: python3 test_decisions.py 4                       ║
╚══════════════════════════════════════════════════════════╝\033[0m""",
    4: """
\033[36m╔══════════════════════════════════════════════════════════╗
║  EXERCISE 4 COMPLETE: decide_by_rules                    ║
╠══════════════════════════════════════════════════════════╣
║                                                          ║
║  What you built:                                         ║
║    A rules-based decision engine — no LLM needed.        ║
║                                                          ║
║  What works now:                                         ║
║    ✓ Agent always picks a valid program for each phase   ║
║    ✓ After 3 refinements → switches to "validate"        ║
║    ✓ The pipeline completes reliably every time           ║
║                                                          ║
║  Try it: python3 run_agent.py --rules                    ║
║                                                          ║
║  Before this exercise:                                   ║
║    ✗ The rules engine returned None (no decision)        ║
║    ✗ The agent could not complete without an LLM          ║
║                                                          ║
║  The catch: Rules are rigid. Always the same path,       ║
║  always 3 refines. No adaptation to unexpected data.     ║
║                                                          ║
║  Next: python3 test_decisions.py 5                       ║
╚══════════════════════════════════════════════════════════╝\033[0m""",
    5: """
\033[36m╔══════════════════════════════════════════════════════════╗
║  EXERCISE 5 COMPLETE: decide (hybrid)                    ║
╠══════════════════════════════════════════════════════════╣
║                                                          ║
║  What you built:                                         ║
║    The hybrid decision engine — LLM proposes, rules      ║
║    verify. Best of both worlds.                          ║
║                                                          ║
║  What works now:                                         ║
║    ✓ LLM gets first chance at every decision             ║
║    ✓ When LLM returns valid JSON → LLM decides           ║
║    ✓ When LLM hallucinates or fails → rules take over    ║
║    ✓ Pipeline completes using BOTH strategies             ║
║                                                          ║
║  Before this fix:                                        ║
║    ✗ Rules always ran first, so the LLM was never used   ║
║    ✗ The agent worked but was purely rules-based          ║
║                                                          ║
║  ALL EXERCISES COMPLETE! Now compare all three:          ║
║    python3 run_agent.py --compare                        ║
║    python3 run_agent.py            (verbose hybrid mode)  ║
╚══════════════════════════════════════════════════════════╝\033[0m""",
}


# =================================================================
# MAIN
# =================================================================

if __name__ == "__main__":
    exercise = int(sys.argv[1]) if len(sys.argv) > 1 else 0

    if exercise == 0 or exercise == 1:
        test_exercise_1()
    if exercise == 0 or exercise == 2:
        test_exercise_2()
    if exercise == 0 or exercise == 3:
        test_exercise_3()
    if exercise == 0 or exercise == 4:
        test_exercise_4()
    if exercise == 0 or exercise == 5:
        test_exercise_5()

    print("\n" + "=" * 40)
    total = PASS + FAIL
    if FAIL == 0:
        print("\033[32mAll %d tests passed!\033[0m" % total)
        if exercise and exercise in EXERCISE_SUMMARIES:
            print(EXERCISE_SUMMARIES[exercise])
        elif exercise == 0:
            print(EXERCISE_SUMMARIES[5])
    else:
        print("\033[31m%d passed, %d failed\033[0m" % (PASS, FAIL))
        print("\nFix the failing tests in decisions.py, then re-run:")
        if exercise:
            print("  python3 test_decisions.py %d" % exercise)
        else:
            print("  python3 test_decisions.py")
    print("=" * 40)
