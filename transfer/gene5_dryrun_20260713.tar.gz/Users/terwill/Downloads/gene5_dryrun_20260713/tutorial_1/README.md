# Tutorial 1: From Rules to Reasoning — Building a Scientific Decision Agent

## What You'll Build

A scientific pipeline needs to decide what to run next at each step.
You'll build the decision engine — first with hand-written rules,
then with an LLM, then as a hybrid that uses both. By the end,
you'll see why real agents need both approaches.

> **Where this sits in the lecture.** You're building the **decide** step
> of the orchestrated agent's loop (slide 13) — the one bounded model
> decision per cycle (slide 6) — and the hybrid that makes it reliable:
> the model proposes, and trusted code falls back to rules (slides 9, 16).
> Tutorial 2 adds the validation layer; Tutorial 3 builds the *other*
> archetype, the self-directed agent.

**Time:** ~50 minutes hands-on
**Files you'll edit:** `decisions.py` (just this one file)
**Dependencies:** Python 3.9+ (standard library only, nothing to install)

---

## Setup

```
cd tutorial_1/
python3 run_agent.py --max=3
```

If you see output with "CYCLE 1", "CYCLE 2", etc. (and lots of
failures), you're ready.

**Falling behind?** At any point, run `python3 catchup.py N` to fill
in all exercises before N. For example, `python3 catchup.py 3` fills
in Exercises 1-2.

**Finished script:** If things go wrong and you need a reference,
a fully working version is in `solutions/decisions_complete.py`.

---

## The Domain (2 min)

```
cat programs.json
```

Five programs, a simple pipeline: analyze → find_model → place_model →
refine → validate. Each program declares which phases it's valid in,
what files it needs, and what files it produces.

The agent's job: look at the current state and choose which program
to run next. That's it. But doing it well turns out to be interesting.

---

## Exercise 1: What Can We Do Right Now? (5 min)

### Goal

Before the agent can decide what to run, it needs to know its options.
You'll write a function that filters the program list by the current
workflow phase. For example, in the "analyze" phase, only
`analyze_data` is valid. In the "refine" phase, both `refine` and
`validate` are valid.

### What to do

**Try this one yourself first.** It's the simplest function in the
tutorial — about five lines from the description above. Give it a go
before reading the reference. Short on time or stuck? The reference is
right below, and `catchup.py` / `solutions/` have it too.

Open `decisions.py` and find `get_valid_programs`. Here's a reference
implementation:

```python
def get_valid_programs(current_phase, program_defs):
    """Return the list of programs valid in the current phase."""
    valid = []
    for name, defn in program_defs.items():
        if current_phase in defn.get("valid_phases", []):
            valid.append(name)
    print("  [get_valid_programs] Phase '%s' → valid programs: %s" % (current_phase, valid))
    return valid
```

**What this does:** It loops over every program definition, checks if
the current phase appears in that program's `valid_phases` list, and
collects the matching program names. The print statement lets you see
exactly which programs are available at each step.

### Test it

```
python3 test_decisions.py 1
```

You should see 6/6 PASS. The tests confirm your function correctly
identifies valid programs for each phase — including returning an
empty list for unknown phases.

---

## Exercise 2: Parse the LLM's Messy Output (10 min)

### Goal

In a real agent, you call an LLM API and get back raw text. Sometimes
it's clean JSON. Sometimes it wraps the JSON in markdown code fences.
Sometimes it adds a chatty preamble before the JSON. Sometimes it
forgets to return JSON entirely. Your parser must handle **all** of
these cases.

Open `fake_llm.py` and scroll through it to see the different response
formats — this is what your parser needs to handle.

### What to do

Open `decisions.py` and find `parse_llm_response`. Replace the stub
with this code:

```python
def parse_llm_response(raw_text):
    """Parse a raw LLM text response into a decision dict."""
    if not raw_text or not raw_text.strip():
        print("  [parse_llm_response] Empty input → None")
        return None

    text = raw_text.strip()

    # Strip markdown fences if present
    if "```" in text:
        parts = text.split("```")
        for part in parts:
            cleaned = part.strip()
            if cleaned.startswith("json"):
                cleaned = cleaned[4:].strip()
            if cleaned.startswith("{"):
                text = cleaned
                break
        print("  [parse_llm_response] Stripped markdown fences")

    # Find the first { and last }
    start = text.find("{")
    end = text.rfind("}")
    if start == -1 or end == -1 or end <= start:
        print("  [parse_llm_response] No JSON found in text → None")
        return None

    json_str = text[start:end + 1]
    try:
        result = json.loads(json_str)
        if isinstance(result, dict) and "program" in result:
            print("  [parse_llm_response] Parsed OK → program='%s'" % result["program"])
            return result
        print("  [parse_llm_response] JSON found but no 'program' key → None")
        return None
    except json.JSONDecodeError:
        print("  [parse_llm_response] JSON decode failed → None")
        return None
```

**What this does:** The parser works in stages:
1. Rejects empty input
2. Strips markdown ` ```json ... ``` ` fences if present
3. Finds the first `{` and last `}` to extract JSON from chatty text
4. Tries `json.loads()` and checks for a `"program"` key
5. Returns `None` for anything that can't be parsed

### Test it

```
python3 test_decisions.py 2
```

You should see 6/6 PASS. The tests cover clean JSON, markdown-fenced
JSON, chatty preamble + JSON, plain text (no JSON), empty strings,
and JSON with trailing text.

---

## Exercise 3: Build the Context (10 min)

### Goal

The LLM can only make good decisions if you give it the right
information. You'll build a context dict that assembles the current
state into a structured package — what phase we're in, what files
exist, what programs are available, recent history, and the latest
metrics. This is prompt engineering in code form.

### What to do

Open `decisions.py` and find `build_context`. Replace the stub with
this code:

```python
def build_context(state):
    """Structure the agent's state into a context dict for the LLM."""
    # Latest metrics (last entry in metrics_history, or {} if empty)
    latest = {}
    if state.get("metrics_history"):
        latest = state["metrics_history"][-1] or {}

    # Recent history (program names from last 3 history entries)
    recent = [h["program"] for h in state.get("history", [])[-3:]]

    context = {
        "current_phase": state["current_phase"],
        "cycle": state.get("cycle", 0),
        "available_files": sorted(state["available_files"]),
        "valid_programs": get_valid_programs(
            state["current_phase"], state["program_defs"]),
        "latest_metrics": latest,
        "recent_history": recent,
    }

    print("  [build_context] Phase=%s, cycle=%d, %d files, programs=%s"
          % (context["current_phase"], context["cycle"],
             len(context["available_files"]), context["valid_programs"]))
    return context
```

**What this does:** It pulls together six pieces of information the
LLM needs to make a decision. Notice that it calls your
`get_valid_programs` function — your earlier work feeds into this.
The `recent_history` (last 3 programs) helps the LLM avoid repeating
the same action, and `latest_metrics` tells it how the pipeline is
progressing.

### Test it

```
python3 test_decisions.py 3
```

You should see 6/6 PASS. The tests verify every field is present
and correctly populated — that files are sorted, valid programs
are correct, metrics are extracted, and recent history is sliced.

---

## Exercise 4: Rules-Based Fallback (10 min)

### Goal

Now you'll build a decision engine that doesn't use the LLM at all —
just simple rules. This is the safety net: when the LLM fails to
produce a valid decision, these rules take over and keep the pipeline
moving.

The rules are:
1. Get the valid programs for the current phase
2. If `validate` is valid AND the model has been refined 3+ times,
   choose `validate` (we've refined enough, time to stop)
3. Otherwise, choose the first valid program

### What to do

Open `decisions.py` and find `decide_by_rules`. Replace the stub
with this code:

```python
def decide_by_rules(state):
    """Make a decision using hand-written rules (no LLM)."""
    valid = get_valid_programs(state["current_phase"], state["program_defs"])
    if not valid:
        print("  [decide_by_rules] No valid programs → None")
        return None

    refine_count = state.get("refine_count", 0)

    if refine_count >= 3 and "validate" in valid:
        print("  [decide_by_rules] Refined %d times → choosing 'validate'" % refine_count)
        return {"program": "validate", "files": {},
                "reasoning": "Refined %d times, moving to validation." % refine_count}

    print("  [decide_by_rules] Phase '%s' → choosing '%s'"
          % (state["current_phase"], valid[0]))
    return {"program": valid[0], "files": {},
            "reasoning": "Rules: first valid program for %s phase."
                         % state["current_phase"]}
```

**What this does:** The rules engine is simple but reliable. It
always picks a valid program. The key intelligence is knowing when
to stop refining — after 3 rounds, switch to `validate`. The agent
pre-computes `refine_count` for you each cycle.

### Test it

```
python3 test_decisions.py 4
```

You should see 5/5 PASS. Then try it for real:

```
python3 run_agent.py --rules
```

The rules engine completes the pipeline perfectly — for this simple
case. But the rules are rigid: always exactly 3 refinement cycles,
always the same path, no ability to adapt to unexpected situations.

---

## Exercise 5: LLM Proposes, Rules Verify (5 min)

### Goal

The `decide` function at the bottom of `decisions.py` calls both the
LLM and the rules engine. But the blocks are in the **wrong order** —
rules go first, so the LLM is never used. You need to swap them so
the LLM gets first chance, with rules as the fallback.

### What to do

Open `decisions.py` and scroll to the `decide` function at the bottom.
You'll see Block A (rules) and Block B (LLM). **Swap them** so Block B
runs first. The result should look like this:

```python
def decide(state):
    """Make a decision using the LLM with a rules-based fallback."""
    valid = get_valid_programs(state["current_phase"], state["program_defs"])

    # ── Block B: Try LLM first ──
    context = build_context(state)
    raw = query_llm(context)
    parsed = parse_llm_response(raw)
    if parsed and parsed.get("program") in valid:
        print("  [decide] LLM returned valid program '%s'" % parsed["program"])
        return parsed, "llm"

    # ── Block A: Fall back to rules ──
    rules_decision = decide_by_rules(state)
    if rules_decision:
        print("  [decide] LLM failed → falling back to rules: '%s'"
              % rules_decision["program"])
        return rules_decision, "rules"

    # ── Block C: Give up ──
    return {"program": valid[0] if valid else "unknown",
            "files": {}, "reasoning": "No decision available"}, "fallback"
```

### Test it

```
python3 test_decisions.py 5
```

You should see 6/6 PASS. The tests verify that the LLM is used when
it returns valid JSON, and rules take over when the LLM hallucinates
a program name or returns unparseable text.

---

## Compare All Three (5 min)

Now run all three strategies side by side:

```
python3 run_agent.py --compare
```

This runs the pipeline three ways and shows a comparison table:

- **Rules only:** Completes, but follows the same rigid path every time
- **LLM only:** Fails — the hallucinated name and the unparseable
  response cause skipped cycles, and the agent never finishes
- **Hybrid:** Completes — uses the LLM when it works, falls back to
  rules when it doesn't

Then run the hybrid in verbose mode:

```
python3 run_agent.py
```

Watch each cycle: some say `[LLM]`, others say `[RULES]`. The agent
is seamlessly switching between strategies based on whether the LLM
produced a valid, parseable decision.

---

## Discussion

Things to think about:

1. **Parsing is the first line of defense.** Before you can validate
   a decision, you have to extract it from raw text. In production,
   this parser handles dozens of LLM formatting quirks.

2. **Rules are the safety net.** The LLM is flexible but unreliable.
   The rules engine is rigid but always works. Composing them gives
   you both reliability and flexibility.

3. **Context is the prompt.** Your `build_context` function is doing
   the same job as prompt engineering — deciding what information the
   LLM needs to make a good choice. In a real agent, this is where
   most of the iteration happens.

4. **The LLM never says "I don't know."** It always returns
   *something* — clean JSON, fenced JSON, chatty text, hallucinated
   names. Your code must handle all of these gracefully. This is
   fundamentally different from a traditional API that returns errors.

---

## What the Real Agent Does

Your 5 functions have direct equivalents in the PHENIX AI agent
for automated crystallographic structure determination:

| Your exercise      | Real agent equivalent                           |
|--------------------|-------------------------------------------------|
| get_valid_programs | Workflow engine phase validation                |
| parse_llm_response | LLM response parser + JSON extraction           |
| build_context      | State summarizer → LLM prompt builder           |
| decide_by_rules    | Rules-based fallback engine (15+ rule types)    |
| decide (hybrid)    | LangGraph decision node: LLM → validate → fallback |

The real system also adds validation layers between the decision
and execution — checking for hallucinated names, wrong phases,
missing files, and convergence loops. (That's Tutorial #2.)

---

## Files

```
README.md              You're reading it
programs.json          The domain: 5 programs, their inputs/outputs/phases
decisions.py           YOUR CODE — the only file you edit
test_decisions.py      Tests (run: python3 test_decisions.py N)
run_agent.py           Agent loop (run: python3 run_agent.py --compare)
fake_llm.py            Pre-recorded LLM responses with formatting variations
mock_runner.py         Simulates program execution with fake metrics
catchup.py             Falling behind? python3 catchup.py N
solutions/             Fully working reference:
  decisions_complete.py    Copy this if you get stuck
```
