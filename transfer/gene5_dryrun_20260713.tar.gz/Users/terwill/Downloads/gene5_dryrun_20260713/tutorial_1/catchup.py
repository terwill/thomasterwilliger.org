#!/usr/bin/env python3
"""
catchup.py — Catch up to a specific exercise.

Usage:
    python3 catchup.py 3     Fill in Exercises 1-2, start fresh at 3
    python3 catchup.py 5     Fill in Exercises 1-4, start fresh at 5
"""

import sys

SOLUTIONS = {
    1: (
        '    # --- YOUR CODE HERE ---\n'
        '    return []  # Stub: no programs valid',
        '    # --- FILLED IN BY CATCHUP ---\n'
        '    valid = []\n'
        '    for name, defn in program_defs.items():\n'
        '        if current_phase in defn.get("valid_phases", []):\n'
        '            valid.append(name)\n'
        '    print("  [get_valid_programs] Phase \'%s\' → valid programs: %s" % (current_phase, valid))\n'
        '    return valid'
    ),
    2: (
        '    # --- YOUR CODE HERE ---\n'
        '    return None  # Stub: never parses anything',
        '    # --- FILLED IN BY CATCHUP ---\n'
        '    if not raw_text or not raw_text.strip():\n'
        '        print("  [parse_llm_response] Empty input → None")\n'
        '        return None\n'
        '    text = raw_text.strip()\n'
        '    if "```" in text:\n'
        '        parts = text.split("```")\n'
        '        for part in parts:\n'
        '            cleaned = part.strip()\n'
        '            if cleaned.startswith("json"):\n'
        '                cleaned = cleaned[4:].strip()\n'
        '            if cleaned.startswith("{"):\n'
        '                text = cleaned\n'
        '                break\n'
        '        print("  [parse_llm_response] Stripped markdown fences")\n'
        '    start = text.find("{")\n'
        '    end = text.rfind("}")\n'
        '    if start == -1 or end == -1 or end <= start:\n'
        '        print("  [parse_llm_response] No JSON found in text → None")\n'
        '        return None\n'
        '    try:\n'
        '        result = json.loads(text[start:end + 1])\n'
        '        if isinstance(result, dict) and "program" in result:\n'
        '            print("  [parse_llm_response] Parsed OK → program=\'%s\'" % result["program"])\n'
        '            return result\n'
        '        print("  [parse_llm_response] JSON found but no \'program\' key → None")\n'
        '        return None\n'
        '    except json.JSONDecodeError:\n'
        '        print("  [parse_llm_response] JSON decode failed → None")\n'
        '        return None'
    ),
    3: (
        '    # --- YOUR CODE HERE ---\n'
        '    return {"current_phase": state["current_phase"],\n'
        '            "cycle": state.get("cycle", 0)}  # Stub: minimal context',
        '    # --- FILLED IN BY CATCHUP ---\n'
        '    latest = {}\n'
        '    if state.get("metrics_history"):\n'
        '        latest = state["metrics_history"][-1] or {}\n'
        '    recent = [h["program"] for h in state.get("history", [])[-3:]]\n'
        '    context = {\n'
        '        "current_phase": state["current_phase"],\n'
        '        "cycle": state.get("cycle", 0),\n'
        '        "available_files": sorted(state["available_files"]),\n'
        '        "valid_programs": get_valid_programs(\n'
        '            state["current_phase"], state["program_defs"]),\n'
        '        "latest_metrics": latest,\n'
        '        "recent_history": recent,\n'
        '    }\n'
        '    print("  [build_context] Phase=%s, cycle=%d, %d files, programs=%s"\n'
        '          % (context["current_phase"], context["cycle"],\n'
        '             len(context["available_files"]), context["valid_programs"]))\n'
        '    return context'
    ),
    4: (
        '    # --- YOUR CODE HERE ---\n'
        '    return None  # Stub: no decision',
        '    # --- FILLED IN BY CATCHUP ---\n'
        '    valid = get_valid_programs(state["current_phase"], state["program_defs"])\n'
        '    if not valid:\n'
        '        print("  [decide_by_rules] No valid programs → None")\n'
        '        return None\n'
        '    refine_count = state.get("refine_count", 0)\n'
        '    if refine_count >= 3 and "validate" in valid:\n'
        '        print("  [decide_by_rules] Refined %d times → choosing \'validate\'" % refine_count)\n'
        '        return {"program": "validate", "files": {},\n'
        '                "reasoning": "Refined %d times, moving to validation." % refine_count}\n'
        '    print("  [decide_by_rules] Phase \'%s\' → choosing \'%s\'"\n'
        '          % (state["current_phase"], valid[0]))\n'
        '    return {"program": valid[0], "files": {},\n'
        '            "reasoning": "Rules: first valid program for %s phase."\n'
        '                         % state["current_phase"]}'
    ),
}


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in "2345":
        print("Usage: python3 catchup.py N")
        print("  Fills in Exercises 1 through N-1.")
        print("  N can be 2, 3, 4, or 5.")
        sys.exit(1)

    target = int(sys.argv[1])

    with open("decisions.py", "r") as f:
        content = f.read()

    for ex in range(1, target):
        old, new = SOLUTIONS[ex]
        if old in content:
            content = content.replace(old, new)

    with open("decisions.py", "w") as f:
        f.write(content)

    print("Filled in Exercises 1-%d. You're ready for Exercise %d." % (target - 1, target))
    print("Run: python3 test_decisions.py %d" % target)


if __name__ == "__main__":
    main()
