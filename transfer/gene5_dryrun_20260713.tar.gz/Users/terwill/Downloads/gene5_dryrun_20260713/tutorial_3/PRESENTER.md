# Presenter Notes — Tutorial 3: Steering an Autonomous Agent

**Goal in one sentence:** students govern a self-directed agent with
policy + gates + a guardrail, and feel that the disciplines from
Tutorials 1–2 still apply — just from a different place.

**Prereqs:** ideally run after Tutorials 1 and 2. If standalone, spend an
extra minute on "orchestrated vs self-directed" up front.

---

## The 8-minute intro

1. Recap the fork (lecture slide 4 / 7). Tutorials 1–2 built the
   **orchestrated** agent: *your* code drove the loop. Now the **model**
   drives. The question shifts from "what do I make it do?" to "what do
   I let it do?"
2. Make the thesis explicit (slide 20): the disciplines don't disappear,
   they move. Truth-in-code becomes a guardrail; the validation layer
   becomes a gate and a prompt principle.
3. Set expectations: "You will not write the agent's loop. You'll write
   four small functions and tune one prompt. That's the whole point —
   governing a capable model is mostly policy, not plumbing."

---

## Running Step 0 live

Run `python3 run_agent.py` on the projector with stub policy. Narrate the
three failures as they scroll by:

- Step 5 (off-plan re-phasing): "It's being *creative*. In a real run
  that could throw away hours and change the space group."
- Step 6 (expensive extension, no gate): "It just spent the compute
  budget without asking."
- Step 7 (overfit): "Watch R-free — 0.239 up to 0.256, while R-work *falls*.
  It's picking up waters and fitting the free set. It finishes and says
  'solved.' That's the dangerous one: confidently, plausibly wrong."

Land it: "Nothing here is the model's fault — there's no policy. Let's
add some."

---

## Per-exercise notes

- **Ex 1 (load_policy):** the only 'aha' is conceptual — the prompt is
  config the code reads. Don't dwell on the parsing.
- **Ex 2/3 (gate/scope):** quick. After Ex 3, have them run
  `catchup.py 5 && run_agent.py` to see the off-plan step get blocked.
  Visible payoff keeps energy up.
- **Ex 4 (write-it-yourself):** budget the most time here. Let them
  struggle for a minute — it's four lines, they can get it. **The key
  beat is the follow-up:** after the function passes its test, the
  overfit *still* slips in the live run because the prompt's tolerance is
  0.05. Pause here. Ask the room why. Then have them change one line in
  `GUIDEME.md` to 0.01 and re-run. The overfit gets rolled back. This is
  the moment the tutorial exists for — name it: "you just reprogrammed
  the agent by editing English."
- **Ex 5 (ordering):** same shape as Tutorial 2's Exercise 5. Scope
  before gate: never ask a human to approve something you should refuse.

---

## The reveal (last 10 minutes)

Run `--compare`. Put the table on screen: governed 0.239, ungoverned
0.256, overfit caught vs not. Same model, two outcomes.

Three takeaways to land:

1. **You govern the model; you don't fix it.** Every win came from policy
   wrapped around a fixed model.
2. **Policy is powerful and fragile.** One number caught (or missed) the
   overfit. Version and test prompts like code.
3. **Same disciplines, relocated.** Tie back to Tutorials 1–2 explicitly
   — this is the orchestrated-vs-self-directed trade, now felt from both
   sides.

If you have the PHENIX agent's real GUIDEME handy, show it: the same kind
of operating principles, just longer.

---

## Common stumbles

- **Ex 1:** forgetting to convert `r_free_tolerance` to `float` — it
  stays a string and the comparison in Ex 4 misbehaves. The test catches
  this.
- **Ex 4:** comparing the wrong direction (rolling back on *improvement*).
  Remind them: only a *rise* in R-free is bad.
- **"My run didn't change after Ex 4."** That's expected — they haven't
  tuned the prompt yet. It's the lesson, not a bug.
- **Forgetting `catchup.py 5` before a mid-tutorial run** — the harness
  needs the earlier functions wired to show the gate/scope effects.
