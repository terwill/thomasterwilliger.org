"""
test_policy.py — Test your policy implementations.

Run after each exercise:
    python3 test_policy.py        # all tests
    python3 test_policy.py 1      # exercise 1 only
    ...
"""

import sys
from policy import (
    load_policy,
    needs_approval,
    check_scope,
    should_rollback,
    pre_act,
)

POLICY = {
    "r_free_tolerance": 0.01,
    "max_iterations": 12,
    "gated_actions": ["extend_resolution", "deposit"],
    "in_scope_actions": ["refine", "coot_edit", "validate", "extend_resolution"],
}

SAMPLE_GUIDEME = """\
# GUIDEME
Some prose about principles that load_policy should ignore.

## OPERATING PARAMETERS
r_free_tolerance: 0.01
max_iterations: 12
gated_actions: extend_resolution, deposit
in_scope_actions: refine, coot_edit, validate, extend_resolution
"""

PASS = 0
FAIL = 0


def check(name, got, expected):
    global PASS, FAIL
    if got == expected:
        PASS += 1
        print("  \033[32mPASS\033[0m: %s" % name)
    else:
        FAIL += 1
        print("  \033[31mFAIL\033[0m: %s" % name)
        print("        expected: %s" % repr(expected))
        print("             got: %s" % repr(got))


# ---------------------------------------------------------------
def test_exercise_1():
    print("\n--- Exercise 1: load_policy ---")
    p = load_policy(SAMPLE_GUIDEME)
    check("r_free_tolerance parsed as float", p.get("r_free_tolerance"), 0.01)
    check("max_iterations parsed as int", p.get("max_iterations"), 12)
    check("gated_actions parsed as list",
          p.get("gated_actions"), ["extend_resolution", "deposit"])
    check("in_scope_actions parsed as list",
          p.get("in_scope_actions"),
          ["refine", "coot_edit", "validate", "extend_resolution"])
    check("ignores prose lines (no stray keys)",
          sorted(p.keys()),
          ["gated_actions", "in_scope_actions", "max_iterations", "r_free_tolerance"])


def test_exercise_2():
    print("\n--- Exercise 2: needs_approval ---")
    ok, _ = needs_approval({"kind": "extend_resolution", "expensive": True}, POLICY)
    check("extend_resolution is gated", ok, True)
    ok, _ = needs_approval({"kind": "deposit", "expensive": False}, POLICY)
    check("deposit is gated (by name)", ok, True)
    ok, _ = needs_approval({"kind": "coot_edit", "expensive": True}, POLICY)
    check("expensive flag forces a gate", ok, True)
    ok, _ = needs_approval({"kind": "refine", "expensive": False}, POLICY)
    check("plain refine is not gated", ok, False)


def test_exercise_3():
    print("\n--- Exercise 3: check_scope ---")
    ok, _ = check_scope({"kind": "refine"}, POLICY)
    check("refine is in scope", ok, True)
    ok, _ = check_scope({"kind": "coot_edit"}, POLICY)
    check("coot_edit is in scope", ok, True)
    ok, _ = check_scope({"kind": "new_experiment"}, POLICY)
    check("new_experiment is out of scope", ok, False)
    ok, _ = check_scope({"kind": "done"}, POLICY)
    check("done is always allowed", ok, True)


def test_exercise_4():
    print("\n--- Exercise 4: should_rollback ---")
    roll, _ = should_rollback({"r_free": 0.239}, {"r_free": 0.256}, POLICY)
    check("R-free 0.239→0.256 (rose 0.017) rolls back", roll, True)
    roll, _ = should_rollback({"r_free": 0.252}, {"r_free": 0.244}, POLICY)
    check("R-free improved → keep", roll, False)
    roll, _ = should_rollback({"r_free": 0.239}, {"r_free": 0.243}, POLICY)
    check("rise within tolerance (0.004) → keep", roll, False)
    roll, _ = should_rollback({"r_free": 0.239}, {"r_free": 0.239}, POLICY)
    check("no change → keep", roll, False)


def test_exercise_5():
    print("\n--- Exercise 5: pre_act ordering ---")
    v, _ = pre_act({"kind": "refine", "expensive": False}, {}, POLICY)
    check("in-scope, cheap → proceed", v, "proceed")
    v, _ = pre_act({"kind": "extend_resolution", "expensive": True}, {}, POLICY)
    check("in-scope, expensive → gate", v, "gate")
    # The ordering test: out of scope AND expensive must BLOCK, not gate.
    v, _ = pre_act({"kind": "new_experiment", "expensive": True}, {}, POLICY)
    check("out-of-scope + expensive → block (scope before gate!)", v, "block")
    v, _ = pre_act({"kind": "done"}, {}, POLICY)
    check("done → proceed", v, "proceed")


TESTS = {1: test_exercise_1, 2: test_exercise_2, 3: test_exercise_3,
         4: test_exercise_4, 5: test_exercise_5}


def main():
    if len(sys.argv) > 1 and sys.argv[1] in "12345":
        TESTS[int(sys.argv[1])]()
    else:
        for n in sorted(TESTS):
            TESTS[n]()
    print("\n" + "=" * 40)
    print("  %d passed, %d failed" % (PASS, FAIL))
    print("=" * 40)
    sys.exit(1 if FAIL else 0)


if __name__ == "__main__":
    main()
