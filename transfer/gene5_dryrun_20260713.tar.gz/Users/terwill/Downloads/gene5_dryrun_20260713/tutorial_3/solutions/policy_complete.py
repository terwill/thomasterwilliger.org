"""
policy_complete.py — Reference solution for Tutorial 3.

Copy this over policy.py if you get stuck.
"""


def load_policy(guideme_text):
    policy = {"r_free_tolerance": 999.0, "max_iterations": 12,
              "gated_actions": [], "in_scope_actions": []}
    list_keys = ("gated_actions", "in_scope_actions")
    for line in guideme_text.splitlines():
        if ":" not in line:
            continue
        key, _, value = line.partition(":")
        key = key.strip()
        value = value.strip()
        if key not in policy:
            continue
        if key in list_keys:
            policy[key] = [p.strip() for p in value.split(",") if p.strip()]
        elif key == "max_iterations":
            policy[key] = int(value)
        else:
            policy[key] = float(value)
    return policy


def needs_approval(action, policy):
    kind = action.get("kind", "")
    if kind in policy.get("gated_actions", []):
        print("  [needs_approval] '%s' is a gated action → GATE" % kind)
        return True, "'%s' requires sign-off" % kind
    if action.get("expensive"):
        print("  [needs_approval] '%s' is expensive → GATE" % kind)
        return True, "'%s' is expensive — needs sign-off" % kind
    print("  [needs_approval] '%s' → no gate" % kind)
    return False, None


def check_scope(action, policy):
    kind = action.get("kind", "")
    if kind == "done":
        return True, None
    if kind in policy.get("in_scope_actions", []):
        print("  [check_scope] '%s' is in scope → OK" % kind)
        return True, None
    print("  [check_scope] '%s' is OUT OF SCOPE → BLOCKED" % kind)
    return False, "'%s' is outside the approved plan" % kind


def should_rollback(before, after, policy):
    tol = policy.get("r_free_tolerance", 999.0)
    rise = after.get("r_free", 0) - before.get("r_free", 0)
    if rise > tol:
        print("  [should_rollback] R-free rose %.3f > tol %.3f → ROLL BACK"
              % (rise, tol))
        return True, "R-free rose %.3f (> tolerance %.3f)" % (rise, tol)
    print("  [should_rollback] R-free change %+.3f within tolerance → keep" % rise)
    return False, None


def pre_act(action, state, policy):
    if action.get("kind") == "done":
        return "proceed", None

    # ── Block S: refuse out-of-scope actions FIRST ──
    ok, reason = check_scope(action, policy)
    if not ok:
        return "block", reason

    # ── Block G: then gate expensive / listed actions ──
    gate, reason = needs_approval(action, policy)
    if gate:
        return "gate", reason

    return "proceed", None
