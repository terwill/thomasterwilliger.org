"""
mock_tools.py — Simulates the tools the self-directed agent calls.

The agent's real tools would be phenix.refine, Coot, etc.  Here we just
apply the scripted effect of each action to the running metrics, so the
run is fully deterministic and needs no PHENIX install.

Effects are stored as ABSOLUTE R-free values in transcript.py, so the
governed and ungoverned runs stay independent of each other.
"""


def apply_action(action, before):
    """Apply an action's effect to the current metrics.

    Returns a NEW metrics dict (does not mutate `before`).  Actions with
    no metric effect (validate, done, an off-plan action that produced
    nothing) return the metrics unchanged.
    """
    after = dict(before)
    effect = action.get("effect") or {}
    if "r_free" in effect:
        after["r_free"] = effect["r_free"]
        after["r_work"] = round(effect["r_free"] - 0.03, 3)
    return after


def tool_log(action, before, after):
    """Build a short, readable log line for an applied action."""
    tool = action.get("tool") or "—"
    parts = ["    tool: %s" % tool]
    if after.get("r_free") != before.get("r_free"):
        parts.append("    R-free: %.3f -> %.3f" % (before["r_free"], after["r_free"]))
    else:
        parts.append("    R-free: %.3f (unchanged)" % before["r_free"])
    return "\n".join(parts)
