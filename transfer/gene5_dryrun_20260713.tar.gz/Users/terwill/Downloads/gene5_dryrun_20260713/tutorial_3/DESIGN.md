# Tutorial Design Document: "Steering an Autonomous Agent"

## Policy, Gates, and Guardrails for a Self-Directed Agent

---

## 1. Requirements and Constraints

Same workshop, audience, and constraints as Tutorials 1 and 2:
graduate students who can write Python, may or may not know
crystallography, familiar with LLMs as users but new to building agents.
~1 hour, fully offline, standard-library Python only, deterministic
behavior for every student (no API, no network, no PHENIX install).

**Relationship to Tutorials 1 and 2.** Those two build the **orchestrated**
agent — a code-owned loop (Tutorial 1: the decide node) wrapped in a
code-owned validation layer (Tutorial 2: the trust boundary). This
tutorial builds the **self-directed** agent — the *model* owns the loop,
and the student writes the governing policy. Run order in the course:
1 → 2 → 3 (decide, then validate, then govern an autonomous run).

---

## 2. Goal

### Learning Objectives

By the end, students will:

1. **Distinguish the two archetypes by where control lives.** In
   Tutorials 1–2 the loop is code; here the loop is the model and the
   code is policy around it. Same disciplines, different home (the
   lecture's slide-20 thesis).

2. **Implement the three governance primitives** every self-directed
   agent needs: an approval gate (expensive/irreversible → human
   sign-off), a scope check (refuse off-plan actions), and a
   cross-validation guardrail (roll back edits that break a held-out
   metric).

3. **Feel that policy is configuration.** The system prompt is parsed
   into parameters the harness enforces. Changing one number
   (`r_free_tolerance`) flips whether an overfit is caught — leverage
   that must be versioned and tested like code.

4. **Recognize silent wrongness and design against it.** The ungoverned
   run finishes at a worse R-free and reports success. Students see why
   a confident, plausible, wrong result is the dangerous failure, and
   build the guardrail that catches it.

### Non-Goals

Not teaching crystallography, prompt engineering as a discipline, or a
specific agent framework. The R-free guardrail is the one domain detail
that carries weight, and it's explained in plain terms.

---

## 3. Materials

```
tutorial_3/
├── README.md              Walkthrough (the "textbook")
├── DESIGN.md              This document
├── PRESENTER.md           Instructor notes + timing
├── GUIDEME.md             System prompt — students tune its parameters
├── policy.py              Student work file — 5 exercises
├── test_policy.py         Test suite, per-exercise
├── run_agent.py           Harness: replays the run under student policy
├── transcript.py          Frozen self-directed run (the model's actions)
├── mock_tools.py          Applies action effects to metrics
├── catchup.py             Escape hatch (fills Ex 1–4)
└── solutions/
    ├── policy_complete.py
    └── GUIDEME_complete.md
```

Zero external dependencies.

---

## 4. Overall Strategy

### Narrative Arc

The same "see it fail, then fix it" arc as Tutorial 2, but the fixes are
*policy*, not validators:

0. **See the problem.** With stub policy, the agent goes off-plan, runs
   an expensive step unsupervised, and overfits — finishing at a
   confidently wrong 0.256.
1. **Read the policy from the prompt** (`load_policy`).
2. **Gate** expensive/irreversible actions (`needs_approval`).
3. **Scope** — refuse off-plan actions (`check_scope`).
4. **Guardrail** — roll back overfitting edits (`should_rollback`),
   *written by the student*. Then tighten the prompt's tolerance and
   watch the overfit finally get caught.
5. **Order** — scope before gate (`pre_act` re-order).

### Key "Aha" Moments

1. **Step 0:** "A capable model with no policy does real damage, and
   nothing announces it." The overfit finish is the hook.

2. **Exercise 4, the two-step:** implementing the guardrail changes
   *nothing* until the student edits one number in `GUIDEME.md`. The
   realization — "the prompt is part of the program" — is the point of
   the whole tutorial.

3. **`--compare`:** identical model, two outcomes (0.239 vs 0.256). The
   governed run is trustworthy; the ungoverned one is confidently wrong.

4. **Cross-reference to Tutorials 1–2:** the disciplines are the same
   (don't loop/overfit, stay in bounds, ask before big moves) but they
   moved from a code loop into a prompt plus a thin guardrail. That's
   the orchestrated-vs-self-directed trade, felt rather than told.

### Why a Frozen Replay

A live LLM is non-deterministic and needs network/keys — impossible in a
workshop. `transcript.py` is a forensic replay of a self-directed run on
a Se-Met SAD structure, so every student sees the same behavior and the
policy effects are reproducible. The model's proposals are fixed; only
the student's policy changes the outcome — which is exactly the lesson.

---

## 5. Exercise Details

| Ex | Function | Lines | Teaches |
|----|----------|-------|---------|
| 1 | `load_policy` | ~12 | Prompt-as-configuration (slide 15) |
| 2 | `needs_approval` | ~6 | The approval gate (slide 8) |
| 3 | `check_scope` | ~6 | Staying in scope (slide 8) |
| 4 | `should_rollback` | ~4 | Cross-validation guardrail / silent wrongness (slide 18) — **write-it-yourself** |
| 5 | `pre_act` re-order | reorder | Governance ordering (scope before gate) |

Exercise 4 is deliberately the one students write unaided: it is short,
it is the conceptual core, and the "tighten the prompt" follow-up turns
a 4-line function into the tutorial's thesis.

### Session Flow

| Time | Activity |
|------|----------|
| 0:00 | Intro: the two archetypes; this is the self-directed one |
| 0:05 | Step 0 — run the ungoverned agent, see it fail |
| 0:13 | Ex 1: load_policy |
| 0:21 | Ex 2: needs_approval |
| 0:29 | Ex 3: check_scope |
| 0:41 | Ex 4: should_rollback (write-it-yourself) + tune the prompt |
| 0:45 | Ex 5: pre_act ordering |
| 0:50 | `--compare`, discussion |
| 1:00 | End |

---

## 6. Distribution Checklist

- [ ] `policy.py` has all stubs (Ex 1–4) and wrong-order `pre_act` (Ex 5)
- [ ] `solutions/policy_complete.py` passes 21/21 tests
- [ ] `solutions/GUIDEME_complete.md` has `r_free_tolerance: 0.01`
- [ ] shipped `GUIDEME.md` has the loose `r_free_tolerance: 0.05`
- [ ] `catchup.py` tested for 2, 3, 4, 5
- [ ] `--compare` shows governed 0.239 / ungoverned 0.256
- [ ] no external dependencies; `__pycache__/` removed from tarball
