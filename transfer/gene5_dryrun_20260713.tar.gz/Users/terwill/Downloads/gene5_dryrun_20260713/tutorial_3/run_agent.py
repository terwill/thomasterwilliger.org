#!/usr/bin/env python3
"""
run_agent.py — Harness for a self-directed agent under your policy.

The model drives (transcript.py).  This harness replays its proposed
actions and runs YOUR policy (policy.py) on each one:

    pre_act  → block out-of-scope / gate expensive   (before acting)
    apply    → run the tool, get new metrics
    should_rollback → revert an edit that broke R-free (after acting)

Usage:
    python3 run_agent.py              # governed by your policy
    python3 run_agent.py --ungoverned # the raw model, no policy at all
    python3 run_agent.py --compare    # both, side by side
    python3 run_agent.py --max=6      # stop after 6 steps
"""

import sys
import io
import contextlib

from transcript import RUN, START_METRICS
from mock_tools import apply_action, tool_log
from policy import load_policy, pre_act, should_rollback

DIM = "\033[2m"; RED = "\033[31m"; GRN = "\033[32m"; YEL = "\033[33m"
CYN = "\033[36m"; BLD = "\033[1m"; RST = "\033[0m"


def read_guideme():
    try:
        with open("GUIDEME.md") as f:
            return f.read()
    except FileNotFoundError:
        return ""


def run(governed=True, max_steps=12, quiet=False):
    policy = load_policy(read_guideme())
    metrics = dict(START_METRICS)
    score = {"gated": 0, "blocked": 0, "rolled_back": 0, "applied": 0}
    completed = False
    best_r_free = metrics["r_free"]
    best_step = 0

    def out(s=""):
        if not quiet:
            print(s)

    out("\n" + "=" * 62)
    out("  SELF-DIRECTED AGENT — %s" % (
        BLD + "GOVERNED by your policy" + RST if governed
        else YEL + "UNGOVERNED (no policy)" + RST))
    out("=" * 62)
    out("  Start: R-free %.3f  (Se-Met SAD model, placed + built)\n"
        % metrics["r_free"])

    for action in RUN[:max_steps]:
        kind = action["kind"]
        if kind == "done":
            completed = True
            out("%s★ Run complete — model reported.%s" % (GRN, RST))
            break

        out("─" * 62)
        out("STEP %d  ·  model proposes: %s%s%s" % (action["step"], BLD, action["summary"], RST))
        if action.get("_tag"):
            out("  %s[%s — %s]%s" % (DIM, action["_tag"], action.get("_desc", ""), RST))

        # ── BEFORE acting: scope + gate ──
        if governed:
            verdict, reason = pre_act(action, {"metrics": metrics}, policy)
        else:
            verdict, reason = "proceed", None

        if verdict == "block":
            out("  %s✗ BLOCKED (out of scope): %s%s" % (RED, reason, RST))
            out("  %s→ escalated to the human; action not run%s" % (CYN, RST))
            score["blocked"] += 1
            continue
        if verdict == "gate":
            out("  %s⚑ GATE: %s%s" % (YEL, reason, RST))
            out("  %s→ human signs off, then it proceeds%s" % (CYN, RST))
            score["gated"] += 1

        # ── ACT ──
        before = dict(metrics)
        after = apply_action(action, before)
        out(tool_log(action, before, after))

        # ── AFTER acting: cross-validation guardrail ──
        if governed:
            rollback, rreason = should_rollback(before, after, policy)
        else:
            rollback, rreason = False, None

        if rollback:
            out("  %s↩ ROLLED BACK: %s%s" % (RED, rreason, RST))
            out("  %s→ kept the pre-edit model (overfit prevented)%s" % (CYN, RST))
            after = before
            score["rolled_back"] += 1
        else:
            score["applied"] += 1

        metrics = after
        if metrics["r_free"] < best_r_free - 1e-9:
            best_r_free = metrics["r_free"]
            best_step = action["step"]
    out("\n" + "=" * 62)
    out("  RESULT (%s)" % ("governed" if governed else "ungoverned"))
    out("=" * 62)
    out("  Final R-free:        %.3f" % metrics["r_free"])
    if metrics["r_free"] > best_r_free + 0.0005:
        out("  %s⚠ worse than the %.3f reached at step %d — an overfit slipped through%s"
            % (YEL, best_r_free, best_step, RST))
    out("  Completed:           %s" % ("yes" if completed else "no"))
    out("  Gated for sign-off:  %d" % score["gated"])
    out("  Blocked (off-plan):  %d" % score["blocked"])
    out("  Overfits caught:     %d" % score["rolled_back"])
    out("")
    return {"final_r_free": metrics["r_free"], "completed": completed, **score}


def compare():
    print("\nRunning both modes…")
    with contextlib.redirect_stdout(io.StringIO()):
        g = run(governed=True, quiet=True)
        u = run(governed=False, quiet=True)
    print("\n" + "=" * 62)
    print("  GOVERNED  vs  UNGOVERNED")
    print("=" * 62)
    rows = [
        ("Final R-free", "%.3f" % g["final_r_free"], "%.3f" % u["final_r_free"]),
        ("Off-plan action blocked", "yes" if g["blocked"] else "no",
         "yes" if u["blocked"] else "no"),
        ("Expensive step gated", "yes" if g["gated"] else "no",
         "yes" if u["gated"] else "no"),
        ("Overfit caught", "yes" if g["rolled_back"] else "no",
         "yes" if u["rolled_back"] else "no"),
    ]
    print("  %-26s %-12s %-12s" % ("", "governed", "ungoverned"))
    print("  " + "-" * 50)
    for label, a, b in rows:
        print("  %-26s %-12s %-12s" % (label, a, b))
    print()
    if u["final_r_free"] > g["final_r_free"]:
        print("  %sUngoverned finishes at a WORSE, overfit R-free (%.3f vs %.3f)%s"
              % (YEL, u["final_r_free"], g["final_r_free"], RST))
        print("  %sand nothing announces it — that is silent wrongness.%s\n" % (YEL, RST))


if __name__ == "__main__":
    max_steps = 12
    for arg in sys.argv[1:]:
        if arg.startswith("--max="):
            max_steps = int(arg.split("=")[1])
    if "--compare" in sys.argv:
        compare()
    else:
        run(governed="--ungoverned" not in sys.argv, max_steps=max_steps)
