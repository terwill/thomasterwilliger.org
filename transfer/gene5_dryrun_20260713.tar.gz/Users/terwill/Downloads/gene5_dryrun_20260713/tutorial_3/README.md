# Tutorial 3: Steering an Autonomous Agent — Policy, Gates, and Guardrails

## What You'll Build

Tutorials 1 and 2 built an **orchestrated** agent: your code owned the
loop and made one bounded decision per cycle. This is the other
archetype — a **self-directed** agent, where the *model* drives and
proposes its own sequence of tool calls.

You won't write the loop. You'll write the **policy** that governs it —
an approval gate, a scope check, and a cross-validation guardrail — and
you'll tune the agent's **system prompt**. By the end you'll have watched
the same disciplines from Tutorials 1–2 do their job from a completely
different place: out of a code loop, and into prose plus a thin guardrail.

**Time:** ~50 minutes hands-on
**Files you'll edit:** `policy.py` and `GUIDEME.md`
**Dependencies:** Python 3.9+ (standard library only)

> **Where this sits in the lecture.** This is the **Self-directed agent**
> from the spectrum (slide 4) and Case B (slide 22). You're building the
> policy that lives in the system prompt and the gates (slides 8, 15) and
> the cross-validation guardrail that catches *silent wrongness* (slide
> 18). The punchline is slide 20: the orchestrated agent put these
> disciplines in code; here they're **relocated** into policy.

---

## Setup

```
cd tutorial_3/
python3 run_agent.py
```

You'll see a self-directed agent rebuild a structure across several
steps. Right now `policy.py` is all stubs, so the agent is **ungoverned** —
watch what it gets away with. You're ready when you see the step-by-step
trace and a `RESULT` block at the bottom.

**Falling behind?** `python3 catchup.py N` fills in Exercises 1 through
N-1. **Stuck?** Reference solutions are in `solutions/`.

---

## Step 0: See the Problem (5 min)

Look at the run you just did. The model is capable — it refines, trims
unsupported residues, fixes rotamers — but with no policy in place, three
things go wrong and **nothing stops them**:

- **Step 5** — it goes *off-plan*, proposing to re-run experimental
  phasing in a different space group. That's not the job.
- **Step 6** — it launches an *expensive, hard-to-undo* resolution
  extension with no human sign-off.
- **Step 7** — it re-refines to "pick up waters," R-work drops, and **R-free
  climbs 0.239 to 0.256**. The overfit signature. The run finishes
  at an overfit 0.256 and reports success. That's *silent wrongness*.

Now look at the model's instructions:

```
cat GUIDEME.md
```

This is the agent's constitution — its principles, and an OPERATING
PARAMETERS block the harness reads. Your job: make the harness actually
enforce it.

Open `policy.py`. Five functions: the first four are permissive stubs,
the fifth is written but in the wrong order.

---

## Exercise 1: Read the Policy out of the Prompt (8 min)

### Goal

The system prompt *is* configuration. Four lines in `GUIDEME.md` look
like `key: value`. Your `load_policy` pulls them into a dict the harness
uses every cycle. This is slide 15 made literal: policy is prose your
code reads.

### What to do

Open `policy.py`, find `load_policy`, and replace the stub with:

```python
def load_policy(guideme_text):
    policy = {"r_free_tolerance": 999.0, "max_iterations": 12,
              "gated_actions": [], "in_scope_actions": []}
    list_keys = ("gated_actions", "in_scope_actions")
    for line in guideme_text.splitlines():
        if ":" not in line:
            continue
        key, _, value = line.partition(":")
        key = key.strip()
        value = value.strip()
        if key not in policy:
            continue
        if key in list_keys:
            policy[key] = [p.strip() for p in value.split(",") if p.strip()]
        elif key == "max_iterations":
            policy[key] = int(value)
        else:
            policy[key] = float(value)
    return policy
```

**What this does:** walks the prompt line by line, splits each `key:
value` once, converts the two list-valued keys to lists and the numeric
ones to `int`/`float`, and ignores every other line (the prose).

### Test it

```
python3 test_policy.py 1
```

5/5 PASS — including that it ignores the prose and keeps only the four
real keys.

---

## Exercise 2: The Approval Gate (8 min)

### Goal

Some actions are too expensive or irreversible to run unsupervised —
they need a human to sign off first (slide 8). Your gate flags them.

### What to do

Find `needs_approval` and replace the stub with:

```python
def needs_approval(action, policy):
    kind = action.get("kind", "")
    if kind in policy.get("gated_actions", []):
        print("  [needs_approval] '%s' is a gated action → GATE" % kind)
        return True, "'%s' requires sign-off" % kind
    if action.get("expensive"):
        print("  [needs_approval] '%s' is expensive → GATE" % kind)
        return True, "'%s' is expensive — needs sign-off" % kind
    print("  [needs_approval] '%s' → no gate" % kind)
    return False, None
```

**What this does:** gates an action if its `kind` is in the prompt's
`gated_actions` list *or* it's flagged `expensive`. Everything else
proceeds untouched — the art is gating only what needs it.

### Test it

```
python3 test_policy.py 2
```

4/4 PASS.

---

## Exercise 3: Stay in Scope (8 min)

### Goal

A self-directed model is creative, and creativity off-plan is a
liability — re-phasing, a new experiment, changing the space group. An
action is allowed only if its `kind` is in the approved `in_scope_actions`
list; anything else is blocked and escalated (slide 8, "stay in scope").

### What to do

Find `check_scope` and replace the stub with:

```python
def check_scope(action, policy):
    kind = action.get("kind", "")
    if kind == "done":
        return True, None
    if kind in policy.get("in_scope_actions", []):
        print("  [check_scope] '%s' is in scope → OK" % kind)
        return True, None
    print("  [check_scope] '%s' is OUT OF SCOPE → BLOCKED" % kind)
    return False, "'%s' is outside the approved plan" % kind
```

### Test it

```
python3 test_policy.py 3
```

4/4 PASS. Now run the agent again:

```
python3 catchup.py 5      # fill in Ex 1–4 so the harness is wired
python3 run_agent.py
```

The off-plan re-phasing at Step 5 is now **blocked** — but the overfit
at Step 7 still sails through. That's next.

---

## Exercise 4: The Cross-Validation Guardrail (12 min) — write this one yourself

### Goal

This is the heart of the tutorial. After an edit is applied, compare
R-free before and after. If R-free **rose** by more than the prompt's
`r_free_tolerance`, the edit overfit the model — roll it back, no matter
how good the geometry looks. Only R-free matters; it's the held-out
check (slide 18).

### What to do

Find `should_rollback` and implement it yourself — don't peek. The whole
function is about four lines:

- compute the rise in R-free (`after` minus `before`)
- if that rise is greater than `policy["r_free_tolerance"]`, return
  `(True, "<some reason>")`
- otherwise return `(False, None)`

Signature and exact expected values are in the docstring. When you think
it's right:

```
python3 test_policy.py 4
```

If you get stuck, `python3 catchup.py 5` fills it in, or see
`solutions/policy_complete.py`.

### Now tune the prompt

Implementing the guardrail isn't enough. Run the agent:

```
python3 run_agent.py
```

The overfit at Step 7 **still slips through** — because `GUIDEME.md`
ships with `r_free_tolerance: 0.05`, and the overfit only raised R-free
by 0.017. Your code is correct; the *policy* is too loose.

Open `GUIDEME.md` and change one line:

```
r_free_tolerance: 0.01
```

Run again. Now Step 7 is **rolled back** and the run ends at 0.239. You
just changed the agent's behavior by editing one number in its prompt —
that's slide 15, live: policy steers, and it's powerful *and* fragile.

---

## Exercise 5: Put the Gate and Scope Check in the Right Order (4 min)

### Goal

`pre_act` runs before every action and returns `proceed`, `gate`, or
`block`. It's written — but the gate block runs before the scope block.
Run the test to see why that's wrong:

```
python3 test_policy.py 5
```

You'll see one failure: an action that's **out of scope AND expensive**
gets a `gate` verdict (asking a human to approve something off-plan)
instead of a `block`. Asking for sign-off on something you should refuse
outright wastes the human's attention — and invites a rubber-stamp.

### What to do

In `pre_act`, swap the two blocks so **scope is checked before the gate**:

```python
    # ── Block S: refuse out-of-scope actions FIRST ──
    ok, reason = check_scope(action, policy)
    if not ok:
        return "block", reason

    # ── Block G: then gate expensive / listed actions ──
    gate, reason = needs_approval(action, policy)
    if gate:
        return "gate", reason

    return "proceed", None
```

### Test it

```
python3 test_policy.py 5
```

4/4 PASS.

---

## Compare: Governed vs. Ungoverned (5 min)

```
python3 run_agent.py --compare
```

|                          | governed | ungoverned |
|--------------------------|----------|------------|
| Final R-free             | 0.239    | 0.256      |
| Off-plan action blocked  | yes      | no         |
| Expensive step gated     | yes      | no         |
| Overfit caught           | yes      | no         |

Same model, same proposals. The ungoverned run finishes at a **worse,
overfit R-free and reports success** — nothing announces it. Your policy
is the difference between a trustworthy run and a confidently wrong one.

---

## Discussion

1. **The model never changed.** Every behavior you fixed came from
   policy and a guardrail wrapped *around* a fixed model. You don't fix
   the model; you govern it.

2. **Policy is powerful and fragile.** One number in the prompt
   (`r_free_tolerance`) decided whether an overfit was caught. That's
   leverage — and a reason to version, review, and test your prompts
   like code.

3. **Same disciplines, different home.** Tutorial 2 caught hallucinations
   and loops with validators *in code*. Here the same kind of
   discipline — don't overfit, stay in scope, ask before expensive
   steps — lives in a prompt and three small functions. That's the
   orchestrated-vs-self-directed trade made concrete.

4. **The gate only works if the human engages.** Gating the resolution
   extension is worthless if the human rubber-stamps it. Keep gates rare
   so each one gets real attention.

---

## What the Real Agent Does

Your policy has direct equivalents in the self-directed PHENIX agent
(the one steered by a GUIDEME system prompt and crystallography skills):

| Your exercise    | Real agent equivalent                                  |
|------------------|--------------------------------------------------------|
| load_policy      | GUIDEME / skill parameters read into the harness       |
| needs_approval   | Approval gate before expensive/irreversible tools      |
| check_scope      | "Stay in scope" principle + plan enforcement           |
| should_rollback  | R-free cross-validation guardrail + automatic rollback |
| pre_act ordering | Pre-flight governance order in the run loop            |

In the real system these live in the system prompt's operating
principles and a thin enforcement layer — not in a hand-written decision
loop. Same disciplines as Tutorials 1–2, relocated.

---

## Files

```
README.md              You're reading it
GUIDEME.md             The agent's system prompt — YOU TUNE its parameters
policy.py              YOUR CODE — the only code file you edit (5 exercises)
test_policy.py         Tests (run: python3 test_policy.py N)
run_agent.py           Harness: replays the run under your policy
transcript.py          The model's proposed actions (a frozen replay)
mock_tools.py          Simulates the tools' effect on metrics
catchup.py             Falling behind? python3 catchup.py N
solutions/             Reference: policy_complete.py, GUIDEME_complete.md
```
