"""
mock_tools.py — Simulates the tools the self-directed agent calls.

The agent's *reasoning* is real in live mode, but its *tools* are still
mocked here so the tutorial runs in seconds with no PHENIX install. (In
production you'd swap this for a real PHENIX MCP server or CLI.)

Two ways an action gets its effect:

  * SIMULATED mode replays transcript.py, where each action carries an
    explicit absolute `effect` (e.g. {"r_free": 0.239}). Used as-is.

  * LIVE / --demo mode lets the model propose arbitrary actions, so we
    compute a plausible effect from the action kind and current metrics.
    The world has a simple, deterministic "physics":
        refine            - drops R-free with diminishing returns WHILE the
                            model is still poor; but once you are near
                            convergence, further re-refinement lets ordered
                            solvent ride in and OVERFITS the free set
                            (R-work falls, R-free rises) — this is what your
                            guardrail must catch
        coot_edit         - a well-supported edit; helps, or is neutral. (Real
                            measurement on gene-5: clean rotamer fits moved
                            R-free 0.4518 -> 0.4495. Good edits don't overfit;
                            accumulating solvent does.)
        extend_resolution - small improvement
        new_experiment    - no real progress (and off-plan)
        validate / done   - no metric change
"""

REFINE_FLOOR = 0.205        # refinement can't push R-free below this
CONVERGED = 0.26            # at or below this, further refinement overfits
                            # (ordered solvent rides in and fits the free set)


def apply_action(action, before):
    """Apply an action's effect to the metrics. Returns a NEW dict."""
    after = dict(before)

    # Transcript path: explicit absolute effect.
    effect = action.get("effect")
    if effect and "r_free" in effect:
        after["r_free"] = effect["r_free"]
        after["r_work"] = round(effect["r_free"] - 0.03, 3)
        return after
    if effect == {}:
        return after  # transcript no-op (off-plan / validate / done)

    # Live path: rule-based effect from the action kind.
    kind = action.get("kind") or action.get("action")
    r = before["r_free"]
    new = r
    if kind == "refine":
        if r <= CONVERGED:
            new = r + 0.015          # solvent accumulation → overfits the free set
        else:
            new = r - max(0.004, (r - REFINE_FLOOR) * 0.35)
    elif kind == "coot_edit":
        new = r - 0.006              # a well-supported edit helps
    elif kind == "extend_resolution":
        new = r - 0.004
    # new_experiment / validate / done / unknown -> no change

    new = round(max(new, 0.0), 3)
    after["r_free"] = new
    after["r_work"] = round(new - 0.03, 3)
    return after


def tool_log(action, before, after):
    """Build a short, readable log line for an applied action."""
    tool = action.get("tool") or {
        "refine": "phenix.refine", "coot_edit": "coot",
        "extend_resolution": "phenix.refine", "validate": "phenix.validation",
    }.get(action.get("kind"), "—")
    parts = ["    tool: %s" % tool]
    if after.get("r_free") != before.get("r_free"):
        parts.append("    R-free: %.3f -> %.3f" % (before["r_free"], after["r_free"]))
    else:
        parts.append("    R-free: %.3f (unchanged)" % before["r_free"])
    return "\n".join(parts)
