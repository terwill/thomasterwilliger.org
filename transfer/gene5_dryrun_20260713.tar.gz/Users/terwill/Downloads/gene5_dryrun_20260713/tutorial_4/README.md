# Tutorial 4: Steering an Autonomous Agent — with a Live Model

This is the **live sibling of Tutorial 3**. The exercises you complete in
`policy.py` are identical; the difference is *who proposes the actions*. In
Tutorial 3 the proposals came from a frozen transcript. Here they come from
a **real model** — the crystallography "expert" — reasoning live, governed
by the policy you write.

That makes the central lesson sharper. In Tutorial 3 the agent was
predictable. Here it genuinely isn't: it will phrase things its own way,
sometimes go off-plan, and sometimes keep "improving" a converged model.
Your gate, scope check, and cross-validation guardrail are what stand
between a capable-but-unpredictable model and a confidently wrong result.

> **Honest scope.** The model's *reasoning* is real. The *tools* (refine,
> Coot, validation) are still mocked, so the tutorial runs in seconds with
> no PHENIX install and no risk. Swapping the mock for a real PHENIX MCP
> server or CLI is the production step — and the governance you write here
> is exactly what you'd keep.

**Time:** ~50 minutes hands-on
**Files you'll edit:** `policy.py` and `GUIDEME.md` (same as Tutorial 3)
**Dependencies:** Python 3.9+ standard library only (the API client uses
`urllib` — nothing to install)

---

## Setup

### Live mode (with an API key)

```
export ANTHROPIC_API_KEY="sk-ant-..."      # the key your instructor provides
export ANTHROPIC_MODEL="claude-sonnet-4-6" # optional; a default is used otherwise
cd tutorial_4/
python3 run_agent.py
```

Each run makes a handful of small calls (a few hundred tokens each), so
cost is a few cents at most. The loop is hard-capped by `max_iterations`
in `GUIDEME.md`, so it can't run away.

### No key? You're not stuck.

- `python3 run_agent.py --demo` runs the **live code path** with a
  scripted stand-in model — same behaviour, no key, fully offline.
- `python3 run_agent.py --simulated` replays the frozen Tutorial 3 run.
- Plain `python3 run_agent.py` auto-detects: live if a key is present,
  simulated if not.

**Falling behind?** `python3 catchup.py N` fills Exercises 1 through N-1.
**Stuck?** Reference solutions are in `solutions/`.

---

## Step 0: See the Problem (5 min)

Run the agent with the stub policy (live, `--demo`, or simulated — all show
the same lesson):

```
python3 run_agent.py --demo
```

The model is capable — it refines, trims residues, fixes rotamers — but
with no policy in place it does three things nothing stops:

- it goes **off-plan**, proposing to re-run phasing in a new space group;
- it runs an **expensive** resolution extension with no sign-off;
- near convergence it keeps re-refining, letting ordered solvent ride in and
  **raise R-free** — overfitting — and the run still reports success. That's *silent
  wrongness*, and the harness flags it: `⚠ worse than … an overfit
  slipped through`.

Now look at the agent's instructions:

```
cat GUIDEME.md
```

This file is both the agent's **system prompt** (sent to the live model)
and the source of the operating parameters your code enforces. Your job:
make the harness enforce it, and tune it.

Open `policy.py`: five functions, the first four permissive stubs, the
fifth written in the wrong order.

---

## Exercise 1: Read the Policy out of the Prompt (8 min)

The system prompt *is* configuration. Four lines in `GUIDEME.md` look like
`key: value`. Your `load_policy` pulls them into a dict the harness uses.

Find `load_policy` in `policy.py` and replace the stub with:

```python
def load_policy(guideme_text):
    policy = {"r_free_tolerance": 999.0, "max_iterations": 12,
              "gated_actions": [], "in_scope_actions": []}
    list_keys = ("gated_actions", "in_scope_actions")
    for line in guideme_text.splitlines():
        if ":" not in line:
            continue
        key, _, value = line.partition(":")
        key = key.strip()
        value = value.strip()
        if key not in policy:
            continue
        if key in list_keys:
            policy[key] = [p.strip() for p in value.split(",") if p.strip()]
        elif key == "max_iterations":
            policy[key] = int(value)
        else:
            policy[key] = float(value)
    return policy
```

Test: `python3 test_policy.py 1` → 5/5 PASS.

---

## Exercise 2: The Approval Gate (8 min)

Some actions are too expensive or irreversible to run unsupervised. Find
`needs_approval` and replace the stub with:

```python
def needs_approval(action, policy):
    kind = action.get("kind", "")
    if kind in policy.get("gated_actions", []):
        print("  [needs_approval] '%s' is a gated action → GATE" % kind)
        return True, "'%s' requires sign-off" % kind
    if action.get("expensive"):
        print("  [needs_approval] '%s' is expensive → GATE" % kind)
        return True, "'%s' is expensive — needs sign-off" % kind
    print("  [needs_approval] '%s' → no gate" % kind)
    return False, None
```

Test: `python3 test_policy.py 2` → 4/4 PASS.

---

## Exercise 3: Stay in Scope (8 min)

A live model is creative, and creativity off-plan is a liability. An action
is allowed only if its `kind` is in `in_scope_actions`. Find `check_scope`
and replace the stub with:

```python
def check_scope(action, policy):
    kind = action.get("kind", "")
    if kind == "done":
        return True, None
    if kind in policy.get("in_scope_actions", []):
        print("  [check_scope] '%s' is in scope → OK" % kind)
        return True, None
    print("  [check_scope] '%s' is OUT OF SCOPE → BLOCKED" % kind)
    return False, "'%s' is outside the approved plan" % kind
```

Test: `python3 test_policy.py 3` → 4/4 PASS. Then:

```
python3 catchup.py 5      # wire up Ex 1–4
python3 run_agent.py --demo
```

The off-plan re-phasing is now **blocked** — but the overfit near the end
still slips through. That's next.

---

## Exercise 4: The Cross-Validation Guardrail (12 min) — write this one yourself

The heart of the tutorial. After an edit is applied, compare R-free before
and after. If R-free **rose** by more than `r_free_tolerance`, the edit
overfit — roll it back, however good the geometry looks. Only R-free
matters; it's the held-out check.

Find `should_rollback` and implement it yourself (about four lines):

- compute the rise in R-free (`after` minus `before`)
- if that rise exceeds `policy["r_free_tolerance"]`, return `(True, "<reason>")`
- otherwise return `(False, None)`

Test: `python3 test_policy.py 4`. (Stuck? `catchup.py 5` or `solutions/`.)

### Then tune the prompt

Run the agent again. The overfit **still slips through** — `GUIDEME.md`
ships with `r_free_tolerance: 0.05`, and the overfitting edits only raise
R-free by ~0.015. Your code is right; the *policy* is too loose.

Open `GUIDEME.md` and tighten one line:

```
r_free_tolerance: 0.01
```

Run again — now the overfit is **rolled back**. You changed the agent's
behaviour by editing one number in its prompt.

---

## Exercise 5: Put the Gate and Scope Check in the Right Order (4 min)

`pre_act` runs before every action and returns `proceed`, `gate`, or
`block` — but the gate block runs before the scope block. Run
`python3 test_policy.py 5` to see the failure: an action that's out of
scope **and** expensive gets gated (asking a human to approve something
off-plan) instead of blocked.

In `pre_act`, swap the blocks so **scope is checked before the gate**:

```python
    # ── Block S: refuse out-of-scope actions FIRST ──
    ok, reason = check_scope(action, policy)
    if not ok:
        return "block", reason

    # ── Block G: then gate expensive / listed actions ──
    gate, reason = needs_approval(action, policy)
    if gate:
        return "gate", reason

    return "proceed", None
```

Test: `python3 test_policy.py 5` → 4/4 PASS.

---

## Run It for Real (5 min)

With a key set, run the live agent and watch a real model drive:

```
python3 run_agent.py            # live
```

Two things to try that are unique to the live version:

1. **Edit a principle in `GUIDEME.md`** — for example, strengthen "stay in
   scope" or change the tolerance — and run again. Because `GUIDEME.md` is
   the model's system prompt, you are reprogramming the *live* model. Watch
   its proposals shift.

2. **Run it twice.** The model is non-deterministic. Your policy has to
   hold regardless of how the run unfolds — that's the point of governing
   a model instead of scripting it.

For a clean, reproducible side-by-side, use the simulated comparison:

```
python3 run_agent.py --compare
```

|                          | governed | ungoverned |
|--------------------------|----------|------------|
| Final R-free             | 0.239    | 0.256      |
| Off-plan action blocked  | yes      | no         |
| Expensive step gated     | yes      | no         |
| Overfit caught           | yes      | no         |

---

## Discussion

1. **You govern the model; you don't fix it.** Every behaviour you
   shaped came from policy wrapped around a model you don't control — and
   in live mode, one you genuinely can't predict.

2. **Policy is powerful and fragile.** One number in the prompt decided
   whether an overfit was caught. Version, review, and test prompts like
   code.

3. **The live run varies; the guardrails don't have to.** A good policy
   produces a trustworthy result across many different model trajectories.
   That robustness is the deliverable.

4. **The gate only works if the human engages.** Keep gates rare so each
   one gets real attention rather than a rubber stamp.

---

## What the Real Agent Does

Your policy has direct equivalents in the self-directed PHENIX agent:

| Your exercise    | Real agent equivalent                                  |
|------------------|--------------------------------------------------------|
| load_policy      | GUIDEME / skill parameters read into the harness       |
| needs_approval   | Approval gate before expensive/irreversible tools      |
| check_scope      | "Stay in scope" principle + plan enforcement           |
| should_rollback  | R-free cross-validation guardrail + automatic rollback |
| pre_act ordering | Pre-flight governance order in the run loop            |

The real system sends a GUIDEME-style system prompt to the model and calls
PHENIX through an MCP server. Here you've built the same governance against
a real model with mocked tools — change the tools, keep the policy.

---

## Files

```
README.md              You're reading it
GUIDEME.md             System prompt — YOU TUNE its parameters (also sent to the model)
policy.py              YOUR CODE — five exercises (identical to Tutorial 3)
test_policy.py         Policy tests (python3 test_policy.py N)
test_live.py           Tests for the live machinery (no key needed)
run_agent.py           Harness: live / --demo / --simulated / --compare
llm_client.py          Tiny std-lib Anthropic API client
live_agent.py          Builds the prompt, parses the model's proposed action
transcript.py          Frozen run used by --simulated (the Tutorial 3 replay)
mock_tools.py          Simulates the tools' effect on metrics
catchup.py             Falling behind? python3 catchup.py N
solutions/             Reference: policy_complete.py, GUIDEME_complete.md
```
