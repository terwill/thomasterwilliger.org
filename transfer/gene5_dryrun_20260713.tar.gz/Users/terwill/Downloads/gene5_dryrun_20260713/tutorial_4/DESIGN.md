# Tutorial Design Document: "Steering an Autonomous Agent — Live"

## The live counterpart of Tutorial 3

---

## 1. Relationship to Tutorial 3

Tutorials 3 and 4 are interchangeable halves of the same lesson. The
student-facing exercises (`policy.py`: load_policy, needs_approval,
check_scope, should_rollback, pre_act) and `GUIDEME.md` are **identical**.
Pick one to teach based on logistics:

- **Tutorial 3** (frozen transcript): fully deterministic, no key, no
  network. Best when you want every student to see the same trace, or have
  no API budget.
- **Tutorial 4** (live model): a real model proposes the actions. Best
  when you have keys to hand out and want students to feel governance over
  a genuinely unpredictable agent.

Tutorial 4 degrades gracefully: with no key it auto-falls back to simulated
mode, and `--demo` runs the live *code path* with a scripted stand-in model
so the live machinery is exercised offline.

---

## 2. What changes from Tutorial 3

Only the action *source* and its plumbing:

| Added/changed file | Purpose |
|--------------------|---------|
| `llm_client.py`    | ~50-line std-lib (`urllib`) Anthropic client; reads `ANTHROPIC_API_KEY` |
| `live_agent.py`    | Builds the prompt from state + GUIDEME, parses the model's JSON action; includes a scripted stand-in for `--demo`/tests |
| `mock_tools.py`    | Adds rule-based metric effects so *arbitrary* model-proposed actions get plausible results (the transcript path is unchanged) |
| `run_agent.py`     | Mode selection (live / demo / simulated / auto) over the **same** governance loop |
| `test_live.py`     | Tests the live machinery without a key |

Unchanged: `policy.py`, `test_policy.py`, `catchup.py`, `solutions/`,
`transcript.py`, `GUIDEME.md`.

---

## 3. Design decisions

**The model's system prompt is GUIDEME.md.** Editing GUIDEME reprograms the
live model, not just the code that reads it. This turns the slide-15 lesson
("policy steers") into something the student can feel directly: change a
principle, watch the proposals shift.

**Real brain, mocked hands.** The tutorial does not run PHENIX. Tools are
simulated so runs are fast, free, and safe; the README is explicit about
this so a scientist audience isn't misled. The governance layer is exactly
what transfers to a real PHENIX MCP/CLI backend.

**A deterministic "physics" for live tools.** Because a live model can
propose anything, `mock_tools` computes effects from the action kind and
current R-free: refinement improves with diminishing returns; resolution
extension helps a little; **hand edits near convergence overfit** (R-free
rises). That last rule guarantees the cross-validation guardrail has
something to catch even when the model's wording varies run to run.

**Robustness over reproducibility for the live run; reproducibility for the
table.** Live runs vary — that's the lesson. `--compare` deliberately uses
the simulated transcript so the governed-vs-ungoverned table is clean and
identical every time.

**Safety rails for a classroom:** small `max_tokens`, low temperature, a
hard `max_iterations` cap from policy, graceful handling of a missing key,
a malformed reply (robust JSON parse), or a network error.

---

## 4. Cost and operations

A full run is ≈ 8–10 calls of a few hundred tokens each — cents at most.
Set `ANTHROPIC_MODEL` to trade cost for capability (a smaller model is
cheaper but returns slightly messier JSON, which the parser tolerates). If
the model string ever 404s, update `ANTHROPIC_MODEL`; the client surfaces
the API error verbatim.

---

## 5. Learning objectives

Identical to Tutorial 3, plus two the live version adds:

6. **Governance must hold under non-determinism.** A good policy yields a
   trustworthy result across many different model trajectories.
7. **The prompt is part of the program.** Editing the system prompt visibly
   changes a real model's behaviour, not just a simulated one.

---

## 6. Session flow

Same as Tutorial 3 (Step 0 → Ex 1–5 → compare/discussion, ~50 min), with a
5-minute "Run it for real" beat after Exercise 5: students set the key, run
live, edit a GUIDEME principle, and run again to watch the live model
respond.

---

## 7. Distribution checklist

- [ ] `policy.py` / `test_policy.py` / `catchup.py` / `solutions/` identical to Tutorial 3
- [ ] `python3 test_policy.py` → 21/21 with the solution
- [ ] `python3 test_live.py` → all pass (no key needed)
- [ ] `--simulated` reproduces the Tutorial 3 result (governed 0.239)
- [ ] `--demo` shows block + gate + rollback with the solution
- [ ] `--live` errors cleanly when no key is set
- [ ] no external dependencies; `__pycache__/` removed from tarball
