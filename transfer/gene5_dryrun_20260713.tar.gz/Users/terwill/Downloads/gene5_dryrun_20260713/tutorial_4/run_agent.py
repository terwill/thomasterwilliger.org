#!/usr/bin/env python3
"""
run_agent.py — Harness for a self-directed agent under your policy.

Same governance loop as Tutorial 3, but the agent's proposals can come
from a REAL model instead of a frozen transcript.

Modes (the governance you write in policy.py is identical in all of them):
    (default)         live if ANTHROPIC_API_KEY is set, else simulated
    --simulated       replay the frozen transcript (deterministic; == Tut 3)
    --demo            live code path with a scripted stand-in model (no key)
    --live            force real API calls (errors if no key)
    --ungoverned      run with no policy at all
    --compare         governed vs ungoverned (uses simulated for a clean table)
    --max=N           cap the number of cycles

Setup for live mode:
    export ANTHROPIC_API_KEY="sk-ant-..."
    export ANTHROPIC_MODEL="claude-sonnet-4-6"   # optional
"""

import sys
import io
import contextlib

from transcript import RUN, START_METRICS
from mock_tools import apply_action, tool_log
from policy import load_policy, pre_act, should_rollback
from llm_client import have_key, call_anthropic, NoAPIKey
from live_agent import propose_action, scripted_responder

DIM = "\033[2m"; RED = "\033[31m"; GRN = "\033[32m"; YEL = "\033[33m"
CYN = "\033[36m"; BLD = "\033[1m"; RST = "\033[0m"


def read_guideme():
    try:
        with open("GUIDEME.md") as f:
            return f.read()
    except FileNotFoundError:
        return ""


def resolve_source(source):
    """Map the requested source to (is_live, responder, label)."""
    if source == "simulated":
        return False, None, "SIMULATED (frozen transcript)"
    if source == "demo":
        return True, scripted_responder(), "DEMO (scripted stand-in model)"
    if source == "live":
        if not have_key():
            raise NoAPIKey("ANTHROPIC_API_KEY is not set — cannot run --live")
        return True, (lambda s, u: call_anthropic(s, u)), "LIVE (real model)"
    # auto
    if have_key():
        return True, (lambda s, u: call_anthropic(s, u)), "LIVE (real model)"
    return False, None, "SIMULATED (no API key found — falling back)"


def run(governed=True, max_steps=12, quiet=False, source="auto", responder=None):
    guideme = read_guideme()
    policy = load_policy(guideme)
    metrics = dict(START_METRICS)
    score = {"gated": 0, "blocked": 0, "rolled_back": 0, "applied": 0}
    completed = False
    best_r_free = metrics["r_free"]
    best_step = 0

    is_live, auto_responder, label = resolve_source(source)
    if responder is None:
        responder = auto_responder
    effective_max = min(max_steps, policy.get("max_iterations", max_steps))

    def out(s=""):
        if not quiet:
            print(s)

    out("\n" + "=" * 62)
    out("  SELF-DIRECTED AGENT — %s" % (
        BLD + "GOVERNED by your policy" + RST if governed
        else YEL + "UNGOVERNED (no policy)" + RST))
    out("  source: %s" % label)
    out("=" * 62)
    out("  Start: R-free %.3f  (Se-Met SAD model, placed + built)\n"
        % metrics["r_free"])

    history = []
    step = 0
    while step < effective_max:
        step += 1

        # ── Get the next proposed action ──
        if is_live:
            try:
                action, raw = propose_action(metrics, history, guideme, responder)
            except NoAPIKey as e:
                out("  %s[%s]%s" % (RED, e, RST))
                break
            except RuntimeError as e:
                out("  %s[model call failed: %s]%s" % (RED, e, RST))
                break
            if action is None:
                out("  %s[no parseable action from the model — stopping]%s" % (YEL, RST))
                break
        else:
            if step - 1 >= len(RUN):
                break
            action = RUN[step - 1]

        kind = action.get("kind")
        if kind == "done":
            completed = True
            out("%s★ Run complete — model reported.%s" % (GRN, RST))
            break

        out("─" * 62)
        out("STEP %d  ·  model proposes: %s%s%s"
            % (step, BLD, action.get("summary", kind), RST))
        if action.get("_tag"):
            out("  %s[%s — %s]%s" % (DIM, action["_tag"], action.get("_desc", ""), RST))
        elif action.get("reasoning"):
            out("  %s%s%s" % (DIM, action["reasoning"], RST))

        # ── BEFORE acting: scope + gate ──
        verdict, reason = pre_act(action, {"metrics": metrics}, policy) if governed \
            else ("proceed", None)

        if verdict == "block":
            out("  %s✗ BLOCKED (out of scope): %s%s" % (RED, reason, RST))
            out("  %s→ escalated to the human; action not run%s" % (CYN, RST))
            score["blocked"] += 1
            history.append({"step": step, "summary": action.get("summary", kind),
                            "rfree": metrics["r_free"], "status": "blocked"})
            continue
        if verdict == "gate":
            out("  %s⚑ GATE: %s%s" % (YEL, reason, RST))
            out("  %s→ human signs off, then it proceeds%s" % (CYN, RST))
            score["gated"] += 1

        # ── ACT ──
        before = dict(metrics)
        after = apply_action(action, before)
        out(tool_log(action, before, after))

        # ── AFTER acting: cross-validation guardrail ──
        rollback, rreason = should_rollback(before, after, policy) if governed \
            else (False, None)

        if rollback:
            out("  %s↩ ROLLED BACK: %s%s" % (RED, rreason, RST))
            out("  %s→ kept the pre-edit model (overfit prevented)%s" % (CYN, RST))
            after = before
            score["rolled_back"] += 1
            status = "rolled back"
        else:
            score["applied"] += 1
            status = "applied"

        metrics = after
        if metrics["r_free"] < best_r_free - 1e-9:
            best_r_free = metrics["r_free"]
            best_step = step
        history.append({"step": step, "summary": action.get("summary", kind),
                        "rfree": metrics["r_free"], "status": status})

    out("\n" + "=" * 62)
    out("  RESULT (%s)" % ("governed" if governed else "ungoverned"))
    out("=" * 62)
    out("  Final R-free:        %.3f" % metrics["r_free"])
    if metrics["r_free"] > best_r_free + 0.0005:
        out("  %s⚠ worse than the %.3f reached at step %d — an overfit slipped through%s"
            % (YEL, best_r_free, best_step, RST))
    out("  Completed:           %s" % ("yes" if completed else "no"))
    out("  Gated for sign-off:  %d" % score["gated"])
    out("  Blocked (off-plan):  %d" % score["blocked"])
    out("  Overfits caught:     %d" % score["rolled_back"])
    out("")
    return {"final_r_free": metrics["r_free"], "completed": completed, **score}


def compare():
    print("\nRunning both modes (simulated, for a clean deterministic table)…")
    with contextlib.redirect_stdout(io.StringIO()):
        g = run(governed=True, quiet=True, source="simulated")
        u = run(governed=False, quiet=True, source="simulated")
    print("\n" + "=" * 62)
    print("  GOVERNED  vs  UNGOVERNED")
    print("=" * 62)
    rows = [
        ("Final R-free", "%.3f" % g["final_r_free"], "%.3f" % u["final_r_free"]),
        ("Off-plan action blocked", "yes" if g["blocked"] else "no",
         "yes" if u["blocked"] else "no"),
        ("Expensive step gated", "yes" if g["gated"] else "no",
         "yes" if u["gated"] else "no"),
        ("Overfit caught", "yes" if g["rolled_back"] else "no",
         "yes" if u["rolled_back"] else "no"),
    ]
    print("  %-26s %-12s %-12s" % ("", "governed", "ungoverned"))
    print("  " + "-" * 50)
    for label, a, b in rows:
        print("  %-26s %-12s %-12s" % (label, a, b))
    print()
    if u["final_r_free"] > g["final_r_free"]:
        print("  %sUngoverned finishes at a WORSE, overfit R-free (%.3f vs %.3f)%s"
              % (YEL, u["final_r_free"], g["final_r_free"], RST))
        print("  %sand nothing announces it — that is silent wrongness.%s\n" % (YEL, RST))


if __name__ == "__main__":
    max_steps = 12
    for arg in sys.argv[1:]:
        if arg.startswith("--max="):
            max_steps = int(arg.split("=")[1])

    if "--compare" in sys.argv:
        compare()
    else:
        source = "auto"
        if "--simulated" in sys.argv:
            source = "simulated"
        elif "--demo" in sys.argv:
            source = "demo"
        elif "--live" in sys.argv:
            source = "live"
        try:
            run(governed="--ungoverned" not in sys.argv,
                max_steps=max_steps, source=source)
        except NoAPIKey as e:
            print("\n%s  %s" % (RED, e))
            print("  Set a key, or run with --simulated or --demo.%s\n" % RST)
