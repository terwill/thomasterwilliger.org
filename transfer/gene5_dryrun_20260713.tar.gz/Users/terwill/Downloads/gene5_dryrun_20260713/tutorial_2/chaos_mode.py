"""
chaos_mode.py — Forensic replay of real LLM failure modes.

These are not random errors.  They are scripted reproductions of the
kinds of mistakes a real LLM makes when orchestrating a scientific
pipeline: hallucinated program names, temporal confusion about which
files exist, failure to track workflow state, and inability to
recognize convergence.

We freeze these failures in place so every student sees the same
behavior and can build validators to catch them deterministically.

When chaos_mode is off, the agent uses scripted "perfect" decisions
that still exhibit one realistic flaw: the LLM never voluntarily
stops refining.  It always wants one more cycle.
"""

# Each entry: cycle_number -> bad decision that replaces the scripted one.
# The reasoning strings are modeled on real LLM outputs — verbose,
# confident, and wrong.
INJECTED_FAILURES = {
    2: {
        # Exercise 1: Hallucinated program name
        "program": "phenix.find_model",
        "files": {"sequence": "sequence.fa"},
        "reasoning": (
            "The data quality looks good based on the analysis report. "
            "The next step is molecular replacement to find a starting model. "
            "I'll run phenix.find_model with the sequence file to search for "
            "homologous structures in the PDB."
        ),
        "_chaos_tag": "HALLUCINATED_NAME",
        "_chaos_desc": "LLM added 'phenix.' prefix — not in our program list",
    },
    5: {
        # Exercise 3: Workflow order violation
        "program": "analyze_data",
        "files": {"data": "data.mtz"},
        "reasoning": (
            "Before continuing with refinement, I want to revisit the data "
            "quality assessment. The R-free is still high, which could indicate "
            "issues with the input data rather than the model. Let me re-run "
            "the analysis to check for twinning or anisotropy."
        ),
        "_chaos_tag": "WRONG_PHASE",
        "_chaos_desc": "LLM tried to go back to analyze during refine phase",
    },
    7: {
        # Exercise 2: Referencing a file that doesn't exist
        "program": "refine",
        "files": {"model": "best_model.pdb", "data": "data.mtz"},
        "reasoning": (
            "The refinement is converging well. I'll continue with "
            "best_model.pdb which should have the lowest R-free from our "
            "previous rounds of refinement."
        ),
        "_chaos_tag": "MISSING_FILE",
        "_chaos_desc": "LLM referenced best_model.pdb — this file doesn't exist",
    },
}


# Scripted decisions for non-chaos cycles and for --no-chaos mode.
# The LLM always wants to refine more — it never suggests validate
# on its own.  This is realistic: LLMs are optimistic about iterative
# improvement and don't track convergence.
SCRIPTED_DECISIONS = [
    # Cycle 1: analyze
    {"program": "analyze_data", "files": {"data": "data.mtz"},
     "reasoning": (
         "We have diffraction data (data.mtz) and a sequence file. The first "
         "step should be to assess data quality — resolution, completeness, "
         "and any potential pathologies before we proceed."
     )},
    # Cycle 2: find model (replaced by chaos in chaos mode)
    {"program": "find_model", "files": {"sequence": "sequence.fa"},
     "reasoning": (
         "Data quality is acceptable. Now we need a starting model. I'll "
         "search for homologous structures using the provided sequence."
     )},
    # Cycle 3: place model
    {"program": "place_model",
     "files": {"model": "predicted_model.pdb", "data": "data.mtz"},
     "reasoning": (
         "We have a predicted model. The next step is molecular replacement "
         "to position it in the unit cell against the experimental data."
     )},
    # Cycle 4: first refine
    {"program": "refine",
     "files": {"model": "placed_model.pdb", "data": "data.mtz"},
     "reasoning": (
         "The model is placed with an initial R-free of 0.48, which is "
         "expected for a molecular replacement solution. Refinement should "
         "bring this down significantly."
     )},
    # Cycles 5+: keep refining (each with increasingly optimistic reasoning)
    {"program": "refine",
     "files": {"model": "refined_model.pdb", "data": "data.mtz"},
     "reasoning": (
         "R-free dropped to 0.28 — good progress. There's still significant "
         "room for improvement. Another round of refinement with updated "
         "weights should help."
     )},
    {"program": "refine",
     "files": {"model": "refined_model.pdb", "data": "data.mtz"},
     "reasoning": (
         "R-free is now 0.255. The model is improving steadily. One more "
         "cycle should push us below 0.25, which would be a strong result "
         "at this resolution."
     )},
    {"program": "refine",
     "files": {"model": "refined_model.pdb", "data": "data.mtz"},
     "reasoning": (
         "R-free at 0.24. We're close to convergence but I think there's "
         "still a bit more to gain. The geometry looks good, so another "
         "refinement cycle with tighter restraints could help."
     )},
    {"program": "refine",
     "files": {"model": "refined_model.pdb", "data": "data.mtz"},
     "reasoning": (
         "R-free holding at 0.24. The electron density maps show some "
         "residual peaks that might resolve with additional refinement. "
         "Let me try one more cycle with adjusted B-factor weights."
     )},
    {"program": "refine",
     "files": {"model": "refined_model.pdb", "data": "data.mtz"},
     "reasoning": (
         "The model statistics are stable. However, I notice some Ramachandran "
         "outliers that might improve with further refinement. One more cycle "
         "should clean those up."
     )},
    {"program": "refine",
     "files": {"model": "refined_model.pdb", "data": "data.mtz"},
     "reasoning": (
         "Almost there. The R-free gap is reasonable and the geometry is "
         "mostly good. Just one more round to make sure we've fully converged."
     )},
    {"program": "refine",
     "files": {"model": "refined_model.pdb", "data": "data.mtz"},
     "reasoning": (
         "Refinement is essentially converged, but it can't hurt to run one "
         "final cycle to confirm stability of the current model."
     )},
]


def get_decision(cycle, chaos_enabled=True):
    """
    Get the LLM decision for a given cycle.

    If chaos_enabled and this cycle has an injection, return the bad decision.
    Otherwise return the scripted decision.
    """
    if chaos_enabled and cycle in INJECTED_FAILURES:
        decision = INJECTED_FAILURES[cycle].copy()
        return decision

    idx = min(cycle - 1, len(SCRIPTED_DECISIONS) - 1)
    return SCRIPTED_DECISIONS[idx].copy()
