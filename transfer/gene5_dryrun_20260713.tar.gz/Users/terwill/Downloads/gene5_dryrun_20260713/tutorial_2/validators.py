"""
validators.py — YOUR CODE GOES HERE

Implement the five validation functions below.  Each one catches a
different failure mode of the LLM agent.  The scaffolding in run_agent.py
calls validate_decision() every cycle — once you implement these functions,
the agent will catch and correct the LLM's mistakes.

Run the tests after each exercise:
    python3 test_validators.py

Run the full agent to see your validators in action:
    python3 run_agent.py
"""


# =====================================================================
# EXERCISE 1: Is this even a real program?
# =====================================================================

def validate_program_name(decision, known_programs):
    """
    Check if the LLM chose a program that actually exists in our system.

    LLMs frequently hallucinate plausible-sounding program names, or add
    prefixes they've seen in documentation (like "phenix.refine" instead
    of just "refine").

    Args:
        decision:       dict with at least {"program": "..."}
        known_programs: dict of program_name -> definition from programs.json

    Returns:
        tuple: (is_valid: bool, error: str or None)

    Examples:
        ("refine", ...) → (True, None)
        ("phenix.refine", ...) → (False, "Unknown program 'phenix.refine'")
        ("", ...) → (False, "No program specified")
    """
    # --- YOUR CODE HERE ---
    return True, None  # Stub: accepts everything


# =====================================================================
# EXERCISE 2: Do the input files exist?
# =====================================================================

def validate_files_exist(decision, available_files):
    """
    Check if every file the LLM referenced is actually available.

    LLMs often reference files that will exist in the future (after a
    program runs) but don't exist yet, or invent plausible filenames.

    Args:
        decision:        dict with "files": {"slot": "filename", ...}
        available_files: set of filenames that currently exist

    Returns:
        tuple: (is_valid: bool, missing: list of filenames)

    Examples:
        files={"model": "placed_model.pdb"}, available={"placed_model.pdb"}
            → (True, [])
        files={"model": "refined_model.pdb"}, available={"placed_model.pdb"}
            → (False, ["refined_model.pdb"])
    """
    # --- YOUR CODE HERE ---
    return True, []  # Stub: accepts everything


# =====================================================================
# EXERCISE 3: Is this allowed right now?
# =====================================================================

def validate_workflow_order(decision, current_phase, program_defs):
    """
    Check if the chosen program is valid in the current workflow phase.

    The pipeline must proceed in order:
        analyze → find_model → place_model → refine → validate → done

    A program is valid only if current_phase is in its valid_phases list.

    Args:
        decision:      dict with "program": "..."
        current_phase: str, e.g. "find_model"
        program_defs:  dict from programs.json

    Returns:
        tuple: (is_valid: bool, error: str or None, suggestion: str or None)

    Examples:
        ("analyze_data", "analyze", ...)    → (True, None, None)
        ("refine", "find_model", ...)       → (False, "refine not valid in ...", "find_model")

    Hint: To suggest a correction, find any program whose valid_phases
          includes the current phase.
    """
    # --- YOUR CODE HERE ---
    return True, None, None  # Stub: accepts everything


# =====================================================================
# EXERCISE 4: Are we going in circles?
# =====================================================================

def validate_no_loop(decision, history, metrics_history):
    """
    Detect if the agent is stuck in a loop.

    Two loop patterns to catch:

    1. REPETITION: Same program 3+ times consecutively in history
       (and the decision would make it 4+).

    2. PLATEAU: The last 2 runs of the same program showed
       R-free improvement < 0.005 between them.

    Args:
        decision:        dict with "program": "..."
        history:         list of dicts, each with "program" and "cycle" keys
        metrics_history: list of dicts, each with optional "r_free" key
                         (aligned with history — same index = same cycle)

    Returns:
        tuple: (is_looping: bool, reason: str or None)

    Examples:
        history=["analyze", "refine"], decision="refine"
            → (False, None)  — not 3 consecutive yet
        history=["refine", "refine", "refine"], decision="refine"
            → (True, "refine has run 3 times consecutively")
        metrics=[..., {r_free: 0.262}, {r_free: 0.259}], decision="refine"
            → (True, "R-free plateau: ...")
    """
    # --- YOUR CODE HERE ---
    return False, None  # Stub: never detects loops


# =====================================================================
# EXERCISE 5: Put them in the right order
# =====================================================================

def validate_decision(decision, state):
    """
    Run all validators and return the first failure.

    The four blocks below are ALREADY WRITTEN — but they're in the
    WRONG ORDER.  Run the tests to see what breaks:

        python3 test_validators.py 5

    Then rearrange the blocks so the tests pass. Think about:
      - If the program is wrong for this phase, are the file
        references even meaningful?
      - Which validators can suggest corrections? Which can only
        say "no"?

    Returns:
        tuple: (is_valid: bool, error: str or None, corrected: dict or None)
    """
    progs = state["program_defs"]

    # ── Block A: check program name ──
    ok, err = validate_program_name(decision, progs)
    if not ok:
        return False, err, None

    # ── Block B: check files exist ──
    ok, missing = validate_files_exist(decision, state["available_files"])
    if not ok:
        return False, "Missing files: %s" % ", ".join(missing), None

    # ── Block C: check workflow order ──
    ok, err, suggestion = validate_workflow_order(
        decision, state["current_phase"], progs)
    if not ok:
        corrected = None
        if suggestion:
            corrected = {"program": suggestion, "files": {},
                         "reasoning": "Corrected: " + err}
        return False, err, corrected

    # ── Block D: check for loops ──
    is_looping, reason = validate_no_loop(
        decision, state["history"], state["metrics_history"])
    if is_looping:
        corrected = {"program": "validate", "files": {},
                     "reasoning": "Loop detected: " + reason}
        return False, reason, corrected

    return True, None, None
