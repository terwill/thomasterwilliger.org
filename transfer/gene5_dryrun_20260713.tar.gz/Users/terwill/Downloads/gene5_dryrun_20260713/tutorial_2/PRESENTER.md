# Presenter Script — Tutorial 3: Trust But Verify

## Before the Session

**Setup checklist:**
- [ ] Projector connected, terminal visible at large font size
- [ ] Your own tutorial directory ready to demo
- [ ] Run `python3 run_agent.py` with solved validators to confirm ★ Pipeline complete! ★
- [ ] Optionally: PHENIX agent architecture slide for the reveal

**Have open in tabs/windows:**
1. Terminal in the tutorial directory
2. `validators.py` in an editor (for showing stubs)
3. `chaos_mode.py` in an editor (for the reveal)

---

## 0:00 — Opening (8 min)

### Set the scene (3 min)

> Welcome. Today you're going to build the safety net for an
> AI agent — the validation layer that catches an LLM's mistakes
> before they cause damage.
>
> Here's the situation. You have a scientific pipeline — analyze
> data, find a model, refine it, validate it. An LLM looks at the
> current state and decides what to run next. The LLM is pretty
> good — it gets it right maybe a third of the time. The other
> two thirds, it hallucinates program names, references files that
> don't exist, tries to run things out of order, or gets stuck in
> infinite loops.
>
> You're not going to fix the LLM. You can't — that's someone
> else's problem. You're going to build the validators that catch
> its mistakes and, when possible, correct them automatically.

### The frozen-in-amber framing (2 min)

> A quick note on what you're about to see. Live LLMs are
> non-deterministic — every run is different, which makes debugging
> impossible in a workshop. So what you're looking at is a forensic
> replay. We took real patterns of LLM failures — the hallucinated
> names, the temporal confusion, the confident wrong reasoning —
> and froze them in `chaos_mode.py` so everyone sees the same thing.
>
> When you read the LLM's reasoning text, you'll recognize it. It
> sounds exactly like ChatGPT explaining why it's doing something
> wrong.

### Show the disaster (3 min)

On projector, run:

```
python3 run_agent.py
```

**Let it run all the way through.** The terminal will fill with
red ✗ marks and execution failures. Let the students read the
output.

> Look at the scorecard. LLM correct: 2 out of 9. Execution
> failed: almost everything. The LLM sounds confident every single
> cycle, and it's wrong most of the time.
>
> Now look at cycle 2. Read the reasoning. [Read it aloud:]
> "I'll run phenix.find_model with the sequence file to search for
> homologous structures in the PDB." Sounds great — except
> `phenix.find_model` isn't a program in our system. The LLM saw
> the prefix in documentation and hallucinated it.
>
> Cycle 7: "I'll continue with best_model.pdb which should have the
> lowest R-free from our previous rounds." That file doesn't exist.
> The LLM assumed it would be there because it *should* be there.

**Point students to the README and validators.py:**

> Open `validators.py`. That's the only file you'll touch. Five
> functions — the first four are stubs, the fifth is pre-written
> but in the wrong order. Your job: implement the validators that
> turn that 2/9 into a completed pipeline.

---

## 0:08 — Step 0: Students Run the Agent (5 min)

**Say:**

> Before you start coding, run it yourself:
>
> `python3 run_agent.py`
>
> Read the output. Find the hallucinated name. Find the missing
> file. Notice how confident the reasoning sounds every time.
> Then look at `programs.json` — that's the whole domain, five
> programs.

**Let them explore for 2-3 minutes.** Then:

> Now start Exercise 1. The README tells you exactly what to do.

---

## 0:13 — Exercise 1: Program Name (5 min)

**Say:**

> Exercise 1: does this program even exist? The LLM said
> `phenix.find_model` — is that in `programs.json`? Your validator
> checks. About 5 lines. When you're done:
> `python3 test_validators.py 1`

**Circulate.** This is fast. Common issues:
- Not handling empty string (`decision.get("program", "")`)
- Using `in` on a list instead of dict keys (both work, but
  students sometimes try `if program in known_programs.values()`)

---

## 0:18 — Exercise 2: Files Exist (5 min)

**Say:**

> Exercise 2: do the input files exist? The LLM referenced
> `best_model.pdb` — does that file actually exist right now?
> Iterate over the file references, check each one against the
> set of available files.

**Circulate.** Common issues:
- Iterating over keys instead of values in `decision["files"]`
- Forgetting that `available_files` is a set

---

## 0:23 — Exercise 3: Workflow Order (10 min)

**Say:**

> Exercise 3 is where it gets interesting. The LLM tried to go
> back to `analyze_data` during the refine phase. Your validator
> doesn't just say "no" — it suggests the right program.
>
> Check if the current phase is in the program's `valid_phases`.
> If not, find a program that IS valid for this phase and return it
> as a suggestion.
>
> This is the key difference. Exercises 1 and 2 could only reject.
> Exercise 3 can correct. That's the difference between a guard
> rail and a co-pilot.

**Circulate.** This takes longer. Common issues:
- Not returning three values (`is_valid, error, suggestion`)
- Finding the suggestion: iterate `program_defs`, find one where
  `current_phase in defn["valid_phases"]`
- Returning `None` for the suggestion when no match is found

**At 0:30, announce catchup:**

> If you're still working on Exercise 3, that's fine — take your
> time. If you want to jump ahead, `python3 catchup.py 4` fills
> in Exercises 1-3 for you.

---

## 0:33 — Exercise 4: Loop Detection (10 min)

**First, show the problem.** On projector:

```
python3 run_agent.py --no-chaos --max=10
```

> This is the "perfect" LLM — no hallucinations, no wrong phases.
> Watch the R-free values: 0.28, 0.255, 0.24, 0.24, 0.24...
>
> The LLM keeps saying "one more cycle." Read the reasoning at
> each step — it's always optimistic. "Still room for improvement."
> "One more cycle should push us below 0.25." "It can't hurt to
> run one final cycle."
>
> The metrics have stopped improving but the LLM doesn't know that.
> It can't see convergence. That's your Exercise 4.

**Say:**

> Two checks. First: has the same program run 3 or more times
> consecutively? Second: has R-free improvement dropped below 0.005
> between the last two runs? Either one means we're stuck.

**Circulate.** This is the hardest exercise. Common issues:
- Off-by-one on "3 consecutive": check the last 3 in *history*
  (the current decision would make it 4)
- Iterating backwards through `metrics_history` to find the last
  two R-free values for the same program
- Using `abs()` on the improvement (R-free can go up slightly)

**At 0:40, announce catchup:**

> If you need to catch up: `python3 catchup.py 5`

---

## 0:43 — Exercise 5: Ordering (5 min)

**Say:**

> Scroll to the bottom of `validators.py`. The `validate_decision`
> function is already written — four blocks, A through D. But
> they're in the wrong order.
>
> Run the test: `python3 test_validators.py 5`
>
> One failure: "ORDERING: correction suggested (workflow before
> files?)". Here's what happened: a decision came in with the
> wrong phase AND a missing file. Block B (files) ran first, caught
> the missing file, and rejected it — no correction possible.
> But if Block C (workflow) had run first, it would have caught the
> wrong phase and suggested the right program. The correction was
> lost because of ordering.
>
> Swap blocks B and C. That's it.

**This should take 1-2 minutes.** The conceptual weight is large,
the typing is trivial.

---

## 0:48 — The Final Run (2 min)

**On projector, or have everyone run simultaneously:**

```
python3 test_validators.py
```

> 29 tests, all green.

```
python3 run_agent.py
```

**Wait for ★ Pipeline complete! ★ to appear.**

> Look at the scorecard. LLM correct: 2. Validator corrected: 5.
> Validator blocked: 2. Zero execution failures.
>
> You wrote maybe 40 lines of Python. Those 40 lines took a system
> that failed 7 out of 9 cycles and turned it into one that
> completes successfully every time.

---

## 0:50 — The Reveal (5 min)

**Show the real architecture:**

> Let me show you what the real PHENIX agent looks like.

Either show a slide/diagram, or just describe:

> Your four validators have direct equivalents:
>
> - `validate_program_name` → the real agent has a program registry
>   with fuzzy matching and alias resolution.
> - `validate_files_exist` → the real CommandBuilder checks file
>   existence, file types, and even file contents.
> - `validate_workflow_order` → phase validation with a state
>   machine that handles branching and user overrides.
> - `validate_no_loop` → consecutive program caps plus metrics
>   trend analysis with configurable thresholds.
>
> And then there are about 15 more: parameter blacklisting, crystal
> symmetry injection, ligand file guards, error recovery detection,
> resolution-dependent thresholds...
>
> Each one exists because of a specific failure in production. The
> agent ran, something went wrong, someone wrote a validator. That's
> how these systems grow.

**The key line:**

> You built 4 validators and caught every failure in this tutorial.
> The real system has 15 and still discovers new edge cases after
> months of production use. Validation is never "done."

---

## 0:55 — Discussion (5 min)

### Key points to make:

**1. Validation is architecture, not afterthought.**

> You discovered in Exercise 5 that the ORDER of validators matters.
> That's not a bug — it's a fundamental property. Validators that
> can suggest corrections must run before validators that can only
> reject. In the real system, reordering validators is a design
> decision that gets discussed in code reviews.

**2. Correction vs. rejection.**

> Exercises 1-2 could only say "no." Exercise 3 said "try this
> instead." That's the difference between a system that's safe-but-
> stuck and one that's safe-and-useful. In the real agent, about
> half the validators can suggest corrections.

**3. The LLM doesn't know it's being corrected.**

> The LLM never sees the validator output. It proposes, the
> validators accept or correct, the corrected decision runs.
> Next cycle, the LLM sees the results of the corrected action
> and continues as if nothing happened. This is intentional —
> correction is invisible to the LLM.

### If doing both tutorials:

> In Tutorial 1, you built the decision brain — the part that
> proposes what to do next. When the LLM failed, you fell back
> to rules. That's one strategy. Today you built a different
> strategy: let the LLM propose, then validate and correct. The
> real PHENIX agent does both — hybrid decision-making with
> validation layers on top.

### Suggested discussion questions:

- "In your own work, what's the equivalent of 'the LLM doesn't
  know when to stop'? Where does convergence detection matter?"
- "If you could only build one of your four validators, which one
  would prevent the most damage?" (Usually workflow order, because
  it can correct.)
- "What happens when two validators disagree — one wants to correct
  to program A, another to program B?" (Great segue to priority
  and ordering.)

---

## Timing Safety Valves

**If running behind at 0:30 (Exercise 3 taking too long):**
Announce catchup: "Run `python3 catchup.py 4` to skip ahead."

**If running behind at 0:42 (Exercise 4 taking too long):**
Announce catchup: "Run `python3 catchup.py 5` and let's do Exercise
5 together." Do the block swap on the projector as a group exercise.

**If running very behind (0:45 and not at Exercise 5):**
Have everyone run `python3 catchup.py 5`, do Exercise 5 on
projector, then run the final agent together. The ★ Pipeline
complete! ★ moment is more important than any individual exercise.

**If running ahead:**
Have fast students open `chaos_mode.py` and read the injection
schedule. Ask them: "Can you predict which validator will catch
each injected failure?" Or have them try modifying the refine
count threshold in their loop detector and re-running.

---

## Common Student Questions

**"Why not just fix the LLM's prompt?"**
> You should do that too. Better prompts reduce error rates. But
> they never eliminate errors. Validators catch the remaining
> failures — especially the ones you haven't seen yet.

**"Is the chaos mode realistic?"**
> These are forensic replays of real failure patterns. The
> hallucinated `phenix.` prefix, the temporal file confusion, the
> inability to stop refining — all observed in production.

**"Why four validators and not one big function?"**
> Separation of concerns. Each validator is independently testable,
> independently orderable, and independently useful. When the real
> agent adds a new failure mode, we add one new validator — we don't
> modify existing ones.

**"What if the validator's correction is also wrong?"**
> Great question. In the real system, corrected decisions go through
> the remaining validators too. And if no correction is available,
> the decision is blocked and the agent asks the LLM to try again.
> Defense in depth.

**"Could you have the LLM validate its own output?"**
> You could — that's the "LLM-as-judge" pattern. It works sometimes.
> But it adds latency, cost, and a new source of unreliability.
> Deterministic validators are faster, cheaper, and predictable.
> Use LLM-as-judge for the ambiguous cases that rules can't handle.
