# Tutorial 2: Trust But Verify — Validation Layers for LLM Agents

## What You'll Build

An LLM agent runs a scientific pipeline — but it hallucinates, skips
steps, references files that don't exist, and gets stuck in loops.
You won't fix the LLM. You'll build the safety net around it.

> **Where this sits in the lecture.** You're building the **validate**
> step — the trust boundary where the model proposes and trusted code
> checks before it acts (slide 9) — catching the failure catalog (slide
> 17) and the silent-wrongness overfit via the R-free plateau (slides 14,
> 18). Tutorial 1 built the decide step; Tutorial 3 governs a
> self-directed agent.

**Time:** ~50 minutes hands-on
**Files you'll edit:** `validators.py` (just this one file)
**Dependencies:** Python 3.9+ (standard library only, nothing to install)

---

## Setup

```
cd tutorial_2/
python3 run_agent.py --max=3
```

If you see output with "CYCLE 1", "CYCLE 2", etc., you're ready.

**Falling behind?** At any point, run `python3 catchup.py N` to fill
in all exercises before N, so you can jump ahead. For example,
`python3 catchup.py 4` fills in Exercises 1-3.

**Finished script:** If things go wrong and you need a reference,
a fully working version is in `solutions/validators_complete.py`.

---

## Step 0: See the Problem (5 min)

**A note on what you're looking at.** Live LLMs are non-deterministic,
which makes debugging impossible in a workshop. What you're about to
see is a forensic replay — real patterns of an LLM confidently making
mistakes while running a crystallography pipeline. We froze its bad
decisions in `chaos_mode.py` so you can build the guardrails to catch
them.

Run the agent:

```
python3 run_agent.py
```

Watch it fail. The "LLM" makes decisions each cycle — some are good,
most are bad. Without validators, bad decisions go straight to
execution and crash. Look at the scorecard at the bottom.

**Notice:**
- Cycle 2: the LLM explains why it's running `phenix.find_model` —
  a plausible name that doesn't exist in our system
- Cycle 7: the LLM references `best_model.pdb` — a file it assumes
  exists because it *should* exist at this point
- The reasoning always sounds confident, even when it's wrong

Now look at the domain:

```
cat programs.json
```

Five programs, a simple pipeline: analyze → find_model → place_model →
refine → validate. Each program lists what files it needs and what
phase it belongs to. Simple enough — but the LLM still gets it wrong.

---

## Step 1: Open validators.py

Open `validators.py` in your editor. This is the only file you'll
change. It has 5 functions — the first four are stubs that accept
everything. The fifth is pre-written but in the wrong order.

---

## Exercise 1: Is This a Real Program? (5 min)

### Goal

The LLM sometimes invents program names like `phenix.refine` or
`optimize_structure`. These look plausible but aren't in our system.
Your validator checks whether the program name actually exists.

### What to do

**Try this one yourself first.** It's the simplest validator — about six
lines from the description above. Give it a go before reading the
reference. Short on time or stuck? The reference is right below, and
`catchup.py` / `solutions/` have it too.

Open `validators.py` and find `validate_program_name`. Here's a reference
implementation:

```python
def validate_program_name(decision, known_programs):
    """Check if the LLM chose a program that actually exists."""
    program = decision.get("program", "")
    if not program:
        print("  [validate_program_name] No program specified → BLOCKED")
        return False, "No program specified"
    if program not in known_programs:
        print("  [validate_program_name] '%s' not in system → BLOCKED" % program)
        return False, "Unknown program '%s'" % program
    print("  [validate_program_name] '%s' exists → OK" % program)
    return True, None
```

**What this does:** It extracts the program name from the LLM's
decision, checks if it's empty (missing key or blank string), then
checks if it exists in the `known_programs` dict. If the name is
`phenix.refine` but the system only has `refine`, the validator
catches it.

### Test it

```
python3 test_validators.py 1
```

You should see 6/6 PASS. The tests cover valid programs, hallucinated
prefixes (`phenix.refine`), made-up names (`optimize_structure`),
empty strings, and missing keys.

---

## Exercise 2: Do the Files Exist? (5 min)

### Goal

The LLM references files that will exist *later* (after a program
runs) or invents filenames entirely. For example, it might reference
`best_model.pdb` — a plausible name that doesn't actually exist.
Your validator checks every file the LLM claims to need.

### What to do

Open `validators.py` and find `validate_files_exist`. Replace the
stub with this code:

```python
def validate_files_exist(decision, available_files):
    """Check if every file the LLM referenced is actually available."""
    files = decision.get("files", {})
    missing = []
    for slot, filename in files.items():
        if filename not in available_files:
            missing.append(filename)
    if missing:
        print("  [validate_files_exist] Missing files: %s → BLOCKED" % missing)
        return False, missing
    print("  [validate_files_exist] All %d files present → OK" % len(files))
    return True, []
```

**What this does:** It iterates over every file reference in the
LLM's decision (`decision["files"]` is a dict like
`{"model": "refined_model.pdb", "data": "data.mtz"}`), checks each
filename against the set of files that actually exist, and collects
any missing ones.

### Test it

```
python3 test_validators.py 2
```

You should see 6/6 PASS. The tests cover all-present files, single
missing files, multiple missing files, and the edge case of an
empty files dict.

---

## Exercise 3: Is This Allowed Right Now? (10 min)

### Goal

The LLM doesn't track workflow state. It sees that `analyze_data`
exists and tries to run it during the refine phase — going backwards
in the pipeline. Your validator checks if the chosen program is
valid for the current phase. But unlike Exercises 1-2, when it finds
a problem, it **suggests a correction** instead of just saying "no."

This is the key difference: Exercises 1-2 can only reject. Exercise 3
can correct. That shift — from guard rail to co-pilot — is what makes
a validation layer useful rather than just safe.

### What to do

Open `validators.py` and find `validate_workflow_order`. Replace the
stub with this code:

```python
def validate_workflow_order(decision, current_phase, program_defs):
    """Check if the chosen program is valid in the current workflow phase."""
    program = decision.get("program", "")
    defn = program_defs.get(program)
    if defn is None:
        print("  [validate_workflow_order] '%s' not found → BLOCKED" % program)
        return False, "Unknown program '%s'" % program, None

    if current_phase not in defn["valid_phases"]:
        # Find a program that IS valid for the current phase
        suggestion = None
        for name, d in program_defs.items():
            if current_phase in d["valid_phases"]:
                suggestion = name
                break
        print("  [validate_workflow_order] '%s' not valid in '%s' → CORRECTED to '%s'"
              % (program, current_phase, suggestion))
        return (False,
                "'%s' not valid in '%s' phase" % (program, current_phase),
                suggestion)

    print("  [validate_workflow_order] '%s' valid in '%s' phase → OK"
          % (program, current_phase))
    return True, None, None
```

**What this does:** It looks up the chosen program's definition and
checks if `current_phase` is in its `valid_phases` list. If not, it
searches through all programs to find one that IS valid for the
current phase and returns it as a suggestion. This lets the agent
self-correct instead of getting stuck.

### Test it

```
python3 test_validators.py 3
```

You should see 5/5 PASS. The tests verify that valid combinations
pass, invalid ones are caught, and a correction is suggested.

---

## Exercise 4: Are We Going in Circles? (10 min)

### Goal

First, see the problem. Turn off the injected failures and watch what
the LLM does on its own:

```
python3 run_agent.py --no-chaos --max=10
```

Watch the R-free values: 0.28 → 0.255 → 0.24 → 0.24 → 0.24...

The LLM keeps saying "one more refinement cycle" even after the
metrics have stopped improving. It doesn't know when to stop. Your
validator detects two kinds of loops:

1. **Repetition:** Same program 3+ times in a row
2. **Plateau:** R-free improvement drops below 0.005

### What to do

Open `validators.py` and find `validate_no_loop`. Replace the stub
with this code:

```python
def validate_no_loop(decision, history, metrics_history):
    """Detect if the agent is stuck in a loop."""
    program = decision.get("program", "")

    # Check 1: Repetition — same program 3+ times consecutively
    if len(history) >= 3:
        last_three = [h["program"] for h in history[-3:]]
        if all(p == program for p in last_three):
            print("  [validate_no_loop] '%s' ran 3 times consecutively → LOOP" % program)
            return True, "%s has run 3 times consecutively" % program

    # Check 2: Plateau — R-free barely improving
    if len(history) >= 2 and len(metrics_history) >= 2:
        # Find last two R-free values for the same program
        recent_rfree = []
        for i in range(len(history) - 1, -1, -1):
            if history[i]["program"] == program:
                m = metrics_history[i] if i < len(metrics_history) else {}
                if "r_free" in m:
                    recent_rfree.append(m["r_free"])
            if len(recent_rfree) >= 2:
                break

        if len(recent_rfree) >= 2:
            improvement = recent_rfree[1] - recent_rfree[0]
            if abs(improvement) < 0.005:
                print("  [validate_no_loop] R-free plateau (%.4f < 0.005) → LOOP"
                      % abs(improvement))
                return True, "R-free plateau: improvement %.4f < 0.005" % abs(improvement)

    print("  [validate_no_loop] No loop detected → OK")
    return False, None
```

**What this does:** Two checks. First, it looks at the last 3 history
entries — if they're all the same program and the LLM wants to run it
again, that's a repetition loop. Second, it finds the last two R-free
values for the same program and checks if the improvement is less than
0.005, which means the metrics have plateaued and further refinement
is pointless.

### Test it

```
python3 test_validators.py 4
```

You should see 5/5 PASS. The tests cover non-loops, repetition loops,
R-free plateaus, active improvement, and non-consecutive runs.

---

## Exercise 5: Put Them in the Right Order (5 min)

### Goal

Scroll to the bottom of `validators.py`. The function
`validate_decision` is already written — it calls all four of your
validators. But the blocks are in the **wrong order**.

### What to do

First, run the test to see what breaks:

```
python3 test_validators.py 5
```

You'll see one failure: `ORDERING: correction suggested (workflow
before files?)`. Here's what happened: a decision came in with the
wrong phase AND a missing file. Block B (files) ran first, caught
the missing file, and rejected it — no correction possible. But if
Block C (workflow) had run first, it would have caught the wrong
phase and suggested the right program.

**Fix it** by swapping Block B and Block C. The result should look
like this:

```python
def validate_decision(decision, state):
    """Run all validators and return the first failure."""
    progs = state["program_defs"]

    # ── Block A: check program name ──
    ok, err = validate_program_name(decision, progs)
    if not ok:
        return False, err, None

    # ── Block C: check workflow order ──  (BEFORE files!)
    ok, err, suggestion = validate_workflow_order(
        decision, state["current_phase"], progs)
    if not ok:
        corrected = None
        if suggestion:
            corrected = {"program": suggestion, "files": {},
                         "reasoning": "Corrected: " + err}
        return False, err, corrected

    # ── Block B: check files exist ──
    ok, missing = validate_files_exist(decision, state["available_files"])
    if not ok:
        return False, "Missing files: %s" % ", ".join(missing), None

    # ── Block D: check for loops ──
    is_looping, reason = validate_no_loop(
        decision, state["history"], state["metrics_history"])
    if is_looping:
        corrected = {"program": "validate", "files": {},
                     "reasoning": "Loop detected: " + reason}
        return False, reason, corrected

    return True, None, None
```

**Why this order matters:** Validators that can suggest corrections
(workflow, loops) should run before validators that can only reject
(files). If you check files first, the correction opportunity is lost.

### Test it

```
python3 test_validators.py 5
```

You should see 6/6 PASS.

---

## Final Run (2 min)

Run the full test suite:

```
python3 test_validators.py
```

And run the agent with all validators and all failures:

```
python3 run_agent.py
```

You should see `★ Pipeline complete! ★` and a scorecard showing how
many cycles the LLM got right vs. how many your validators caught.

---

## Discussion

Things to think about:

1. **Validator ordering matters.** You discovered this in Exercise 5.
   In production agents, the validator pipeline has 15+ stages, and
   their ordering was tuned through months of real failures.

2. **The LLM was right very few times** in chaos mode. Most cycles
   were caught or corrected by your validators. Is the LLM even
   necessary? (Yes — with 20+ programs and complex branching, rules
   can't fully determine the best choice. The LLM adds value in
   ambiguous cases. But validators catch its mistakes in clear ones.)

3. **Validation isn't rejection — it's correction.** Exercises 1-2
   could only say "no." Exercise 3 said "try this instead." That
   shift — from guard rail to co-pilot — is what makes a validation
   layer useful rather than just safe.

---

## What the Real Agent Does

Your 4 validators have direct equivalents in the PHENIX AI agent
for automated crystallographic structure determination:

| Your exercise          | Real agent equivalent                              |
|------------------------|-------------------------------------------------------|
| validate_program_name  | Program registry lookup + command validation        |
| validate_files_exist   | CommandBuilder file checks + content-based guards   |
| validate_workflow_order| Phase validation + USER_REQUEST_INVALID event       |
| validate_no_loop       | Consecutive program cap + metrics trend analysis    |

The real system has ~15 additional layers — parameter blacklisting,
crystal symmetry injection, ligand file guards, error recovery
injection, and more. Each one exists because of a specific failure
in production.

---

## Files

```
README.md              You're reading it
programs.json          The domain: 5 programs, their inputs/outputs/phases
validators.py          YOUR CODE — the only file you edit
test_validators.py     Tests (run: python3 test_validators.py N)
run_agent.py           Agent scaffold — calls your validators each cycle
mock_runner.py         Simulates program execution with fake metrics
chaos_mode.py          Forensic replay of real LLM failure patterns
catchup.py             Falling behind? python3 catchup.py N
solutions/             Fully working reference:
  validators_complete.py   Copy this if you get stuck
```
