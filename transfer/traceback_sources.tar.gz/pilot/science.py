"""Automatic scientific grading of a run's final model against the DEPOSITED reference.

This is what the 50-60 examples with deposited models buy you: an objective
serious-failure endpoint, computed by Phenix rather than a human. The logic:

  * find the run's final model (from final_report.json -> current_best_model),
  * superpose it on the deposited reference           -> CA-RMSD, matched fraction,
  * compute R-free of the run's model against the data (compare to deposited),
  * grade CRITICAL / MAJOR / none by prespecified thresholds (config).

A grossly wrong placement (the AlphaFold-type premature-commitment failure) shows
up as a low matched fraction / high RMSD and grades CRITICAL automatically.

Program names and output parsing vary by Phenix version -- they are configurable and
the parsers are defensive. Verify against your build before trusting the numbers.
"""
from __future__ import annotations
import re
import shutil
import subprocess
from pathlib import Path
from typing import Any

from . import report as R
from .model import Case, RunOutputs


def _run(cmd: list[str], cwd: Path, timeout: int = 1800) -> tuple[int, str]:
    try:
        p = subprocess.run(cmd, cwd=str(cwd), capture_output=True, text=True, timeout=timeout)
        return p.returncode, (p.stdout or "") + "\n" + (p.stderr or "")
    except FileNotFoundError:
        return 127, "program-not-found"
    except subprocess.TimeoutExpired:
        return 124, "timeout"


def _resolve_final_model(case: Case, out: RunOutputs) -> Path | None:
    rep = R.load_report(out.artifacts_dir) if out.artifacts_dir else None
    refs: list[str] = []
    if rep:
        for m in rep.get("current_best_model", []) or []:
            if isinstance(m, dict) and m.get("artifact_ref"):
                refs.append(str(m["artifact_ref"]))
    # Don't grade the deposited reference or a declared input if they sit in the run dir.
    exclude = set()
    if case.reference_model:
        exclude.add(Path(case.reference_model).name)
    for v in (case.inputs or {}).values():
        exclude.add(Path(v).name)
    # Look under artifacts/ first (clean convention), then the run dir (forgiving fallback).
    search: list[Path] = []
    if out.artifacts_dir:
        search.append(Path(out.artifacts_dir))
    if out.run_dir:
        search.append(Path(out.run_dir))
    # Never grade a structure-factor / map / non-coordinate file, a heavy-atom substructure
    # (Se/HA sites are not the protein model), or a *_fitted.pdb that superpose itself wrote.
    bad = ("structure_factor", "_sf.", ".sf.", "map_coeff", "_maps", "map.", "reflection", "data.",
           "substructure", "_ha.", "_sites", "heavy_atom", "hyss", "anom_sites", "_fitted", "fitted.")
    def is_model(p: Path) -> bool:
        if p.name in exclude:
            return False
        return not any(b in p.name.lower() for b in bad)
    for d in search:
        if not d.exists():
            continue
        cands = [p for p in (list(d.rglob("*.pdb")) + list(d.rglob("*.cif"))) if is_model(p)]
        for ref in refs:  # prefer an artifact the run cited as current best
            for c in cands:
                if ref in c.name or c.name in ref:
                    return c
        if cands:
            # Prefer the model with the MOST protein residues (a substructure or stub has ~0),
            # then .pdb over .cif (superpose prefers PDB), then newest. This robustly skips
            # heavy-atom substructures and partial stubs even when names don't flag them.
            def key(p: Path):
                return (len(_ca_residues(p)), p.suffix.lower() == ".pdb", p.stat().st_mtime)
            return max(cands, key=key)
    return None


# --- model header R-free (what the run's refinement REPORTED / claims), distinct from the
# model_vs_data RECOMPUTED value. Reporting both distinguishes near-tied models and gives a
# claimed-vs-verified consistency check. PDB value line has "FREE R VALUE   : x" (whitespace
# then colon); the "FREE R VALUE TEST SET ..." lines have text before the colon and won't match.
_HDR_RFREE_PDB = re.compile(r"FREE R VALUE\s+:\s*([0-9]*\.[0-9]+)")
_HDR_RFREE_CIF = re.compile(r"_refine\.ls_R_factor_R_free\s+([0-9]*\.[0-9]+)", re.I)


def _read_header_rfree(model: Path) -> float | None:
    try:
        txt = model.read_text(errors="ignore")[:200_000]
    except Exception:
        return None
    m = _HDR_RFREE_PDB.search(txt) or _HDR_RFREE_CIF.search(txt)
    if m:
        v = float(m.group(1))
        return v if 0.0 < v < 1.0 else None
    return None


# --- superpose_pdbs: VERIFIED against a successful run.
# Use the backbone LS-fit RMSD (structure agreement after optimal superposition) as the
# discriminator -- NOT "RMSD (all matching atoms)", which is inflated by side-chain / added
# atoms. matched_fraction = (atoms actually LS-fit) / (deposited backbone atoms selected):
# 1.0 = fully matched the deposited; low = partial or wrong model.
_SUP_RMSD_FINAL = re.compile(r"RMSD between fixed and moving atoms \(final\):\s*([0-9.]+)", re.I)
_SUP_NFIT = re.compile(r"Number of atoms for LS fitting\s*=\s*([0-9]+)", re.I)
_SUP_NSEL_FIXED = re.compile(r"Selected number of atoms in fixed set:\s*([0-9]+)", re.I)
_SUP_RMSD_ALL = re.compile(r"RMSD \(all matching atoms\) \(final\):\s*([0-9.]+)", re.I)

# --- model_vs_data: VERIFIED against the sample log. The computed values are on lines
# like "  r_free: 0.2417" (colon immediately after the name); the PDB-header echo uses
# "r_free          : 0.2401" (spaces before the colon) and must NOT be matched.
_MVD_RFREE = re.compile(r"^\s*r_free:\s*([0-9.]+)", re.M)
_MVD_RWORK = re.compile(r"^\s*r_work:\s*([0-9.]+)", re.M)


def _superpose(cfg_cmd: str, ref: Path, model: Path, cwd: Path) -> dict[str, Any]:
    # ref is the FIXED (deposited) model, model is MOVING (the run's output).
    rc, log = _run([cfg_cmd, str(ref), str(model)], cwd)
    res: dict[str, Any] = {"ok": rc == 0, "format_verified": True, "log_tail": log[-500:]}
    m = _SUP_RMSD_FINAL.search(log)
    res["ca_rmsd_A"] = float(m.group(1)) if m else None
    nf = _SUP_NFIT.search(log)
    nsf = _SUP_NSEL_FIXED.search(log)
    n_fit = int(nf.group(1)) if nf else None
    n_sel_fixed = int(nsf.group(1)) if nsf else None
    res["n_fit"] = n_fit
    res["n_selected_fixed"] = n_sel_fixed
    res["matched_fraction"] = (n_fit / n_sel_fixed) if (n_fit and n_sel_fixed) else None
    ma = _SUP_RMSD_ALL.search(log)
    res["rmsd_all_atoms_A"] = float(ma.group(1)) if ma else None   # reported, not used for grading
    return res


_STD_AA = {
    "ALA", "ARG", "ASN", "ASP", "CYS", "GLN", "GLU", "GLY", "HIS", "ILE",
    "LEU", "LYS", "MET", "PHE", "PRO", "SER", "THR", "TRP", "TYR", "VAL",
    "MSE",  # selenomethionine — counts as a modeled residue
}


def _read_maybe_gzip(path: Path) -> str:
    """Read a model file as text, transparently decompressing .gz."""
    try:
        raw = path.read_bytes()
    except OSError:
        return ""
    if raw[:2] == b"\x1f\x8b":
        import gzip
        try:
            raw = gzip.decompress(raw)
        except OSError:
            return ""
    return raw.decode("utf-8", errors="ignore")


def _ca_residues_from_cif(text: str) -> set[tuple[str, int]]:
    """Extract (chain, resno) for CA of standard residues from an mmCIF _atom_site loop.
    Uses author numbering (auth_asym_id / auth_seq_id) so it matches PDB author numbering."""
    out: set[tuple[str, int]] = set()
    lines = text.splitlines()
    i, n = 0, len(lines)
    while i < n:
        if lines[i].strip() == "loop_":
            cols: list[str] = []
            j = i + 1
            while j < n and lines[j].strip().startswith("_"):
                cols.append(lines[j].strip())
                j += 1
            if any(c.startswith("_atom_site.") for c in cols):
                idx = {c: k for k, c in enumerate(cols)}

                def col(*names: str) -> int | None:
                    for nm in names:
                        k = idx.get("_atom_site." + nm)
                        if k is not None:
                            return k
                    return None

                a_atom = col("label_atom_id", "auth_atom_id")
                a_comp = col("label_comp_id", "auth_comp_id")
                a_asym = col("auth_asym_id", "label_asym_id")
                a_seq = col("auth_seq_id", "label_seq_id")
                if None not in (a_atom, a_comp, a_asym, a_seq):
                    ncol = len(cols)
                    while j < n:
                        row = lines[j].strip()
                        if not row or row.startswith(("_", "#", "loop_", "data_")):
                            break
                        f = row.split()
                        if len(f) >= ncol:
                            atom = f[a_atom].strip('"\'')
                            comp = f[a_comp].strip('"\'')
                            if atom == "CA" and comp in _STD_AA:
                                chain = f[a_asym].strip('"\'') or "_"
                                try:
                                    out.add((chain, int(f[a_seq])))
                                except ValueError:
                                    pass
                        j += 1
                i = j
                continue
        i += 1
    return out


def _ca_residues(pdb: Path) -> set[tuple[str, int]]:
    """Set of (chain, resno) for every CA of a standard amino acid, from a PDB or mmCIF file
    (optionally gzipped). Waters/ligands (no CA) are naturally excluded, so this is a
    residue-level footprint of the modeled protein."""
    text = _read_maybe_gzip(pdb)
    if not text:
        return set()
    # mmCIF? (atom_site loop present) -> use the CIF parser; else fixed-column PDB.
    if "_atom_site." in text:
        return _ca_residues_from_cif(text)
    out: set[tuple[str, int]] = set()
    for line in text.splitlines():
        if line[:6] not in ("ATOM  ", "HETATM"):
            continue
        if line[12:16].strip() != "CA":
            continue
        if line[17:20].strip() not in _STD_AA:
            continue
        chain = line[21].strip() or "_"
        try:
            resno = int(line[22:26])
        except ValueError:
            continue
        out.add((chain, resno))
    return out


def _compress(residues: set[tuple[str, int]]) -> str:
    """Compress a set of (chain, resno) into human ranges, e.g. 'A/18-24, A/40, B/5-7'."""
    if not residues:
        return ""
    parts: list[str] = []
    by_chain: dict[str, list[int]] = {}
    for ch, rn in residues:
        by_chain.setdefault(ch, []).append(rn)
    for ch in sorted(by_chain):
        nums = sorted(by_chain[ch])
        start = prev = nums[0]
        for n in nums[1:] + [None]:
            if n == prev + 1:
                prev = n
                continue
            parts.append(f"{ch}/{start}" if start == prev else f"{ch}/{start}-{prev}")
            if n is not None:
                start = prev = n
    return ", ".join(parts)


def _coverage(ref: Path, model: Path) -> dict[str, Any]:
    """Residue-level completeness of the run's model vs the deposited reference, keyed on
    (chain, resno). Pure PDB parsing (no Phenix needed). `missing` names the reference
    residues absent from the run — assumes shared numbering, so cross-check against the
    superposition's matched_fraction before treating a low value as a real gap."""
    R = _ca_residues(ref)
    M = _ca_residues(model)
    if not R:
        return {"n_ref": 0, "n_run": None, "coverage": None, "missing": ""}
    built = R & M
    missing = R - M
    return {"n_ref": len(R), "n_run": len(built),
            "coverage": round(len(built) / len(R), 3),
            "missing": _compress(missing)}


def _model_vs_data(cfg_cmd: str, model: Path, data: Path, cwd: Path) -> dict[str, Any]:
    rc, log = _run([cfg_cmd, str(model), str(data)], cwd)
    mf = _MVD_RFREE.search(log)
    mw = _MVD_RWORK.search(log)
    return {"ok": rc == 0, "format_verified": True,
            "r_free": float(mf.group(1)) if mf else None,
            "r_work": float(mw.group(1)) if mw else None,
            "log_tail": log[-500:]}


def grade(case: Case, out: RunOutputs, cfg) -> dict[str, Any]:
    th = cfg.get("science_thresholds")
    res: dict[str, Any] = {"grade": "unknown", "reason": "", "metrics": {}}

    if not cfg.get("phenix.enabled", True):
        res.update(grade="skipped", reason="phenix disabled in config")
        return res
    if not case.reference_model:
        res.update(grade="no-reference", reason="case has no deposited reference model")
        return res

    model = _resolve_final_model(case, out)
    if model is None:
        # No final model. If the run legitimately stopped/failed, that is not a science failure.
        rep = R.load_report(out.artifacts_dir) if out.artifacts_dir else None
        status = (rep or {}).get("status")
        if status in ("stopped", "failed", "partial"):
            res.update(grade="no-model-ok", reason=f"no final model; status={status}")
        else:
            res.update(grade="major", reason="claimed a result but produced no locatable final model")
        return res

    ref = Path(case.reference_model)
    workdir = Path(out.run_dir)
    res["metrics"]["model_file"] = model.name   # which file was graded (auditable)
    res["metrics"]["deposited_rfree"] = case.deposited_rfree
    res["metrics"]["r_free_reported"] = _read_header_rfree(model)   # what the run claims
    sup = _superpose(cfg.get("phenix.superpose_cmd"), ref, model, workdir)
    res["metrics"]["superpose"] = sup

    # Residue-level completeness vs the deposited reference (pure PDB parse; names the gaps).
    cov = _coverage(ref, model)
    res["metrics"]["coverage"] = cov

    data_path = case.inputs.get("data") or case.inputs.get("mtz")
    if data_path:
        mvd = _model_vs_data(cfg.get("phenix.model_vs_data_cmd"), model, Path(data_path), workdir)
        res["metrics"]["model_vs_data"] = mvd

    # Grade.
    mf = sup.get("matched_fraction")
    rmsd = sup.get("ca_rmsd_A")
    mvd = res["metrics"].get("model_vs_data", {})
    rfree = mvd.get("r_free")
    dep_rfree = case.deposited_rfree

    # Placement check (needs superpose): gross disagreement -> CRITICAL.
    if (mf is not None and mf < th["matched_fraction_critical"]) or \
       (rmsd is not None and rmsd > th["ca_rmsd_critical_A"]):
        res.update(grade="critical", reason=f"model disagrees grossly with deposited "
                   f"(matched_fraction={mf}, ca_rmsd={rmsd})")
        return res

    major_reasons = []
    if mf is not None and mf < th["matched_fraction_major"]:
        major_reasons.append(f"partial agreement (matched_fraction={mf})")
    # Completeness: run is missing residues the deposited reference modeled. Only treat as a real
    # gap when the residue coverage is low AND the superposition agrees it's not a numbering
    # mismatch (matched_fraction not high). Names the missing residues so it's actionable.
    cov_frac = cov.get("coverage")
    cov_thresh = th.get("coverage_major", 0.95)
    if cov_frac is not None and cov_frac < cov_thresh and (mf is None or mf < 0.98):
        gap = f"incomplete vs deposited: built {cov['n_run']}/{cov['n_ref']} modeled residues"
        if cov["missing"]:
            gap += f" (missing {cov['missing']})"
        major_reasons.append(gap)
    if rfree is not None and dep_rfree is not None and (rfree - dep_rfree) > th["rfree_major_delta"]:
        major_reasons.append(f"R-free {rfree} worse than deposited {dep_rfree} by > {th['rfree_major_delta']}")
    if major_reasons:
        res.update(grade="major", reason="; ".join(major_reasons))
        return res

    # No critical/major. Decide 'none' vs 'uncomputed' by what we could actually measure.
    if mf is not None or rmsd is not None:
        cstr = f", coverage={cov.get('coverage')} ({cov.get('n_run')}/{cov.get('n_ref')})" if cov.get("coverage") is not None else ""
        res.update(grade="none", reason=f"agrees with deposited (matched_fraction={mf}, "
                   f"ca_rmsd={rmsd}, r_free={rfree} vs deposited {dep_rfree}{cstr})")
    elif rfree is not None:
        # superpose unavailable/unparsed, but the R-free comparison is clean (verified metric)
        res.update(grade="none-rfree-only", reason=f"R-free {rfree} consistent with deposited "
                   f"{dep_rfree}; placement not verified (no superposition)")
    else:
        res.update(grade="uncomputed", reason="could not parse superposition or R-free; check program/version")
    return res


def phenix_available(cfg) -> bool:
    return shutil.which(cfg.get("phenix.superpose_cmd")) is not None
