# Self-analysis — AF_7mjs_H_PredictAndBuild

## Framing
Self-critique, not independent audit. Candidate weaknesses for expert review, not verdicts.
No causal claims. Decisions judged against data/maps, not against the deposited model.

## Plan divergence
- intended: predict_and_build -> RSR -> Coot interface-loop pass -> validate -> deposit.
- actual: as planned through validation, but the Coot pass crashed the interpreter after the
  Trp47 pepflip; the pepflip fix (verified prob 0.0004->0.092) was never saved and Coot did not
  recover within the 15-min retry window. why: a run_python_multiline verification call triggered
  "Failed to get __main__ module"; the in-memory fixed model (imol 50) was lost. Consequence: the
  primary deposited model carries a Trp47 Ramachandran outlier that I had already fixed but could
  not persist. Mitigation: preserved the clean-backbone alternate (Model A) as a versioned file.

## Forward walk

### D1 — Working resolution = 2.9 A
- basis (decision-time): mtriage half-map FSC(0.143)=2.88 A masked / 3.00 unmasked; d99 3.21.
- available-but-not-consulted: none identified (used the gold-standard pair directly).
- alternatives / distinguishing evidence: use 3.0 or 3.2; distinguished by the FSC curve itself.
- judged against: half-map FSC log (independent of model). Map-model FSC=0.143 later came out 2.92 A,
  consistent -> resolution choice corroborated by data, not by the model.
- classification: well-justified | severity: minor | candidate: no.

### D2 — carry_on with provided AF predictions instead of the AlphaFold server
- basis: Demo_7mjs_H_CarryOn supplied predicted PDB/PAE/MSA; deterministic, no internet dependency.
- available-but-not-consulted: none (server run would be nondeterministic and slower).
- alternatives: prediction_server=PhenixServer. Distinguishing evidence: pLDDT of the supplied
  prediction (mean 96.4) confirmed it is a high-quality prediction of this exact sequence.
- judged against: process_predicted_model log (pLDDT 96.4, VRMS ~0.8) — independent of final model.
- classification: well-justified | severity: minor | candidate: no.

### D3 — Maps via input_files.map_model.full_map + two half_map entries
- basis: bare DataManager real_map_files were ignored by the build logic ("need a cryo-EM map");
  the pipeline reads full_map/half_map specifically. Learned from three failed launches.
- available-but-not-consulted: README (deliberately skipped per instructions) may have shown the
  canonical invocation and saved the trial-and-error.
- judged against: run proceeded to dock/build only after this change (log), so it is verified correct.
- classification: well-justified | severity: minor | candidate: no.

### D4 — Full map as build target; half-maps for FSC/density-mod
- basis: full.ccp4 is the reconstruction; model and full map share the same cell (44.82/43.99/65.57).
- alternatives: build against a sharpened/density-modified map. Distinguishing evidence: CC_mask
  already reached 0.85 on the provided full map, so extra sharpening was not needed.
- judged against: real_space_refine CC_mask 0.85 and map-model FSC — independent of the model's internal consistency.
- classification: well-justified | severity: minor | candidate: no.

### D5 — Dedicated real_space_refine with rama + secondary-structure + rotamer restraints at 2.9 A
- basis: predict_and_build internal refine left CC ~0.68; at ~3 A these restraints are standard.
- judged against: CC_mask 0.68->0.85, Rama 100% favored, bonds/angles within tolerance (log) — data-based.
- classification: well-justified | severity: minor | candidate: no.

### D6 — Coot rotamer pass on CDR/framework outliers, keep-if-CC-not-worse
- basis (decision-time): 12 rotamer outliers <2%, several in CDR loops (Tyr50 0.05%, Asp62 1.79%).
- available-but-not-consulted: per-atom density (density_at_point) for each side chain before deciding —
  I used per-residue CC + auto_fit's own density scoring, which is coarser.
- alternatives: leave rotamers to Phenix RSR only. Distinguishing evidence: Tyr50/Asp62 CC jumped
  markedly (0.75->0.91, 0.58->0.68) -> density genuinely supported the new rotamers.
- judged against: per-residue map-model CC before/after (independent of geometry idealization).
- classification: well-justified (for the kept CDR fixes) | severity: minor | candidate: no.

### D7 — Accepting the Glu46 rotamer fix (which re-refined 45-47)
- basis: Glu46 CC 0.653->0.712, rotamer 0.71%->0.00% — looked like a clean win at decision time.
- available-but-not-consulted: I did not check the Ramachandran of the *neighbour* Trp47 immediately
  after refining 45-47. That local refine pushed Trp47 into a Rama outlier (only caught later by MolProbity).
- alternatives: refine only residue 46 side chain, or refine 45-47 and re-check neighbour backbone.
- judged against: post-refine MolProbity (independent) revealed the Trp47 outlier that the CC gain hid.
- classification: got-lucky-turned-wrong (the individual fix was fine; its side effect was not checked) |
  severity: moderate | candidate: YES — a rotamer fix was accepted on CC/rotamer alone without
  auditing the backbone of the residue whose phi it changed.

### D8 — Primary = post-Coot model despite the Trp47 outlier
- basis: better composite MolProbity (1.78 vs 1.81), CC (0.848 vs 0.844), clash (8.07 vs 8.57), and
  correct CDR-H2 interface rotamers (the task's explicit requirement); Trp47 fix verified but lost.
- available-but-not-consulted: a non-interactive way to reproduce the pepflip in Phenix (none reliably
  available via MCP) — so I could not clear the outlier before deposit.
- alternatives: make the clean-backbone Model A primary. Distinguishing evidence: whether reviewers
  weight one framework backbone outlier over CDR side-chain correctness — genuinely a judgement call.
- judged against: both models' MolProbity + map-model FSC (data-based), not against a presumed answer.
- classification: weakly-justified | severity: moderate | candidate: YES — reasonable people could
  prefer the 0-outlier alternate; I preserved both rather than force the call.

### D9 — Skipped README per user instruction
- basis: explicit instruction to skip README.
- available-but-not-consulted: README almost certainly contained the exact carry_on + map invocation
  that would have avoided the four failed launches (D3).
- judged against: n/a (process, not model). classification: well-justified (followed instruction) |
  severity: minor | candidate: no.

## Backward trace
- Trp47 Ramachandran outlier in PRIMARY -> originating decision D7 (accepted Glu46 fix, re-refined
  45-47, did not re-check Trp47 backbone). Compounded by the Coot crash (D-plan-divergence) losing the
  verified pepflip repair. Newly implicated: D7 -> add to candidates.
- 3 residual rotamer outliers (2.83%) and reverted CDR rotamers (Tyr30/Lys43/Thr69/Leu103) -> density
  at 2.9 A does not distinguish alternatives; largely resolution-limited, not a decision error.
- Interface faces (light-chain / antigen contacts) not directly validatable -> the provided map is a
  single-chain (H) map; partner-chain density absent. Not a decision error, a data-scope limit worth flagging.

## Candidate weaknesses (for expert review)
- D7 · moderate · Accepted the Glu46 rotamer fix on CC/rotamer alone without auditing the backbone of
  the neighbouring Trp47 whose phi it altered; this created the only Ramachandran outlier in the primary.
- D8 · moderate · Chose the post-Coot model as primary despite one framework backbone outlier; the
  clean-backbone alternate is a defensible alternative primary. Both preserved, but the call is a judgement.
- (plan divergence) · moderate · Coot crash lost an already-verified Trp47 repair; no periodic
  save-checkpoint-to-disk during the interactive pass meant the fix could not be recovered.
