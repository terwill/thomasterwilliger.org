# Self-analysis — nsf-d2-ligand (arm A, run 1)

## Framing
Self-critique, not independent audit. Candidate weaknesses for expert review, not verdicts.
No causal claims. Decisions judged against data/maps, not against the deposited model.

## Plan divergence

- **intended:** (from `### PROPOSED PLAN`) generate R-free → refine apo baseline → inspect
  mFo−DFc at the site → *refine* the supplied ATP → polder → validate → DEPOSIT.
- **actual:** the "refine the supplied ATP" step was replaced wholesale by "reject the supplied
  pose and fit de novo with `phenix.ligandfit`", and an extra apo+solvent control refinement was
  added late.
- **why:** the plan assumed `atp.pdb` was a *placed* ligand. It is not — it is an unfitted
  conformer in the wrong pocket. My PROPOSED PLAN stated the supplied pose put ATP in "a genuine
  nucleotide site"; that assertion was wrong when I wrote it (see D1/D8 below). The plan was
  built on an unverified premise and had to be rebuilt mid-run.

## Forward walk

### D1 — Adopt `nsf-d2_noligand.pdb` as the protein scaffold
- basis (decision-time): `atp.pdb` is 31 atoms with no protein and no CRYST1; a lone ligand
  cannot be meaningfully refined against a 24 488-reflection protein dataset. The apo protein
  model sat in the same directory with matching P6 symmetry.
- available-but-not-consulted: `README.txt` (user instructed me to skip it). Also — and this is
  the real omission — I did not check whether the user's file list was deliberate. I inferred it
  was an oversight.
- alternatives / distinguishing evidence: refine `atp.pdb` alone (would have produced R ≈ 0.5 and
  a meaningless map — self-evidently wrong); ask the user (pre-authorised away).
- judged against: symmetry-aware contact search showed the two files are geometrically matched
  (ATP in van der Waals contact with the protein under P6). Independent of any model I built.
- classification: **well-justified**
- severity: **minor**
- candidate: **no** — the alternative was self-evidently unusable and the pairing was verified
  geometrically. But see D1b.

### D1b — Asserting the supplied ATP sat in "a bona fide nucleotide pocket"
- basis (decision-time): a contact list (CYS568–ILE574, PHE589, ASP590/591, TYR593, LEU608,
  VAL628, LYS632, ALA633) produced by my own script. I labelled `CSPDKMI` a "P-loop".
- available-but-not-consulted: **the sequence.** I had the hierarchy loaded in the same script
  that produced the contact list. One extra line would have printed the residue types and shown
  that no Walker-A motif is present at 568–574 — and would have found `GPPHSGKT` at 543–550. I
  also had the apo difference map available before I wrote this claim into the plan.
- alternatives / distinguishing evidence: extract the sequence; or probe the difference map at
  the ligand atoms *before* asserting the site. Either would have refuted it immediately.
- judged against: model sequence (543–550 = GPPHSGKT, a Walker-A motif; 568–574 = CSPDKMI, not
  one) and the ligand-blind apo mFo−DFc map (0/31 atoms above 3 σ at the supplied pose). Both
  independent of the deposited model.
- classification: **wrong**
- severity: **major** — this was a stated site assignment, in the user-facing plan, that was
  false. Had the density check not been part of the plan for independent reasons, this would
  have propagated into a deposited model with ATP in the wrong pocket.
- candidate: **yes** — a confident structural claim made from pattern-matching a contact list,
  with the refuting evidence already in hand and unexamined.

### D2 — Lattice-shift the ATP by −1 in **a**
- basis (decision-time): computed fractional centroid (1.237, 0.237, 0.090).
- available-but-not-consulted: whether the ligand-protein contact was via the identity operator
  or a rotation. I checked this only *after* the shift, and it turned out to be a rotation — so
  the shifted ligand still did not sit beside chain A directly (closest direct approach 10.4 Å).
- alternatives / distinguishing evidence: apply the actual symmetry operator relating ATP to
  chain A, which would have put it adjacent to the protein in the ASU.
- judged against: per-atom displacement min == max == 116.097 Å, exactly the **a** vector, so the
  operation was provably a pure lattice translation that changed no geometry. Independent of any
  refinement.
- classification: **weakly-justified** — harmless and provably geometry-preserving, but it did
  not achieve its stated goal (putting the ligand next to its protein).
- severity: **minor** — rendered moot because the pose was discarded at D7.
- candidate: **yes** — low consequence, but it shows I acted on an assumption (contact ⇒ adjacent
  in the ASU) I had not tested.

### D3 — Generate a new 10 % R-free set
- basis (decision-time): `phenix.mtz.dump` showed exactly H K L F SIGF; no flag column exists.
- available-but-not-consulted: none — no free set exists in any supplied file. I did not attempt
  to reconstruct the original set (e.g. by testing whether some reflection subset shows anomalously
  high R against the supplied model), which in principle could have recovered it.
- alternatives / distinguishing evidence: no cross-validation at all (worse); 5 % (noisier).
- judged against: nothing model-independent can validate this choice. **I flagged at decision
  time, and repeat here, that this cannot be verified:** the protein has almost certainly seen
  these reflections, so protein R-free is biased low by an unknown amount. I cannot quantify it.
- classification: **well-justified** (forced move, and the bias was flagged in-run rather than
  discovered afterward)
- severity: **moderate** — it permanently limits what the headline R-free means.
- candidate: **yes** — not because the decision was avoidable, but because the *magnitude* of the
  resulting bias is unknown and a reader could over-trust R-free = 0.2282.

### D4 — Run an apo, ligand-blind baseline
- basis (decision-time): a difference map from a refinement that never contained the ligand is
  the least biased evidence obtainable for "is the ligand really there".
- available-but-not-consulted: none identified.
- alternatives / distinguishing evidence: rely on polder alone (weaker — polder starts from a
  model that already contains the ligand).
- judged against: it did the job — it is the map that refuted the supplied pose and located the
  true site. Independent of any ligand-containing model by construction.
- classification: **well-justified**
- severity: **minor**
- candidate: **no** — this is the decision that caught D1b.

### D5 — Use library restraints for ATP, no custom CIF
- basis (decision-time): ATP is a standard CCD component in the Phenix monomer library.
- available-but-not-consulted: none identified.
- alternatives / distinguishing evidence: `phenix.elbow` (would shadow the curated entry).
- judged against: `validate_ligands` reports 0 bond outliers of 33, 0 angle of 52, 0 dihedral of
  34, rmsz 0.92/0.63/1.25. Restraints behaved. This is a geometry check against the library, not
  against the data, so it is only partly model-independent — but it is the correct check here.
- classification: **well-justified**
- severity: **minor**
- candidate: **no**

### D6 — Defer `ordered_solvent` until the ligand question was settled
- basis (decision-time): the `phenix-ligands` skill's explicit warning that water picking masks
  ligand density — which would have destroyed the D4 evidence specifically.
- available-but-not-consulted: none identified.
- alternatives / distinguishing evidence: solvent from the start (would have filled the P-loop
  peaks with waters).
- judged against: the apo map retained a clean 17.4 σ peak cluster at the P-loop, unmasked.
- classification: **well-justified**
- severity: **minor**
- candidate: **no**

### D7 — Reject the supplied pose; fit de novo
- basis (decision-time): three independent lines — R got worse on adding the ligand
  (0.2620/0.3020 vs 0.2513/0.2881, and the *starting* R rose too); 0/31 atoms above 3 σ in the
  ligand-blind difference map; the dominant 17.4/14.8/14.5 σ peak cluster is elsewhere.
- available-but-not-consulted: none identified — this was the best-evidenced call in the run.
- alternatives / distinguishing evidence: rigid-body or occupancy refinement from the supplied
  pose. Refuted in advance: the true site is a *different pocket*, and refinement relocates
  < ~1 Å.
- judged against: the ligand-blind apo mFo−DFc map, which by construction never contained ATP.
- classification: **well-justified**
- severity: **minor**
- candidate: **no**

### D8 — Run two ligandfit jobs concurrently with different map inputs
- basis (decision-time): honestly, this started as a hedge against a third argument-syntax
  failure, not as a designed control. Two prior ligandfit invocations had failed on `input_labels`.
- available-but-not-consulted: I could have read `phenix.ligandfit`'s PHIL/help *once* instead of
  failing twice on argument syntax and then brute-forcing two variants. That cost ~40 min of wall
  clock on a 4-core box, with the two jobs contending for cores.
- alternatives / distinguishing evidence: read the help first; run one job.
- judged against: it turned into the single strongest independent check in the run — two fits from
  different map inputs converging to 0.76 Å RMSD. But that was luck, not design.
- classification: **got-lucky** (outcome excellent, basis was "try both and see what sticks")
- severity: **minor**
- candidate: **yes** — the value obtained was accidental; I should not present it as a designed
  cross-validation, and the run log should not imply it was.

### D9 — Choose fitA over fitB as primary
- basis (decision-time): R-free 0.2282 vs 0.2288; minimum per-atom 2mFo−DFc 3.49 σ vs 3.40 σ.
- available-but-not-consulted: nothing further would separate them; I did not compute a formal
  real-space CC difference or an F-test.
- alternatives / distinguishing evidence: none of the available metrics separate these at any
  meaningful significance. The 0.0006 R-free difference is noise.
- judged against: both poses' 2mFo−DFc and residual density — statistically indistinguishable.
- classification: **weakly-justified** — I picked on differences smaller than the noise.
- severity: **minor** — mitigated by retaining both in `DEPOSIT/alternate/`, per the
  preserve-competing-models rule.
- candidate: **yes** — the selection criterion is not defensible; only the *retention of both* is.

### D10 — Add `ordered_solvent=True` to the holo refinements but (initially) not to a matched control
- basis (decision-time): the ligand was placed, so solvent picking was now appropriate.
- available-but-not-consulted: at the moment I launched them, I had no matched control, so the
  apparent R-free improvement (0.2881 → 0.2282) confounded *ligand* with *158 added waters*. I
  noticed this myself and ran the apo+solvent control afterwards, which corrected the comparison
  to 0.2563 → 0.2282.
- alternatives / distinguishing evidence: launch the matched control at the same time.
- judged against: the corrected, protocol-matched comparison (ΔR-free = −2.8 pp), which is the
  number reported. The uncorrected −6.0 pp figure would have been misleading.
- classification: **weakly-justified** — caught in-run, but only after I had the confounded
  number in hand and could have reported it.
- severity: **moderate** — had I not run the control, the headline ligand evidence would have
  been inflated by roughly a factor of two.
- candidate: **yes** — a near-miss on reporting a confounded improvement as a ligand effect.

### D11 — Kept space group P6 without further testing
- basis (decision-time): xtriage's absence table scores P61/P65 and P62/P64 *above* P6, but those
  scores count systematic-absence violations (8 and 6 strong 00l reflections respectively violate
  them), so low = good and P6 is the consistent choice. The supplied model is P6.
- available-but-not-consulted: I did not refine in a screw-axis setting to confirm. Given 8 strong
  00l violations of P61/P65 (I/σ up to 48), this seems unnecessary.
- alternatives / distinguishing evidence: a test refinement in P61/P65.
- judged against: the systematic-absence table in the xtriage log (data only, no model).
- classification: **well-justified**
- severity: **minor**
- candidate: **no**

## Backward trace

- **R-free = 0.2282 cannot be taken at face value** → D3. The free set is not naive with respect
  to the protein. Nothing in the final state can tell me how much this flatters the number, and
  the deposited model cannot be used to check it. Flagged in `DEPOSIT/README.md`.
- **The run nearly deposited ATP in the wrong pocket** → D1b, and secondarily D2. The saving check
  (D4) was planned for a different reason (general ligand-verification hygiene), not because I
  doubted D1b. So the recovery was structural luck in my workflow, not vigilance about that
  specific claim.
- **~40 min of wall clock lost to argument-syntax failures** → D8 and the two failed ligandfit
  invocations before it, plus two failed `phenix.refine` invocations on
  `refinement.output.prefix`. In both cases I guessed PHIL parameter names rather than querying
  them, despite `phenix_get_phil` / `--show-defaults` being available. Newly implicated: this is a
  process weakness that recurred twice with different programs.
- **`alternate/` holds two models I cannot separate** → D9. This is honest preservation, but it
  means the deposit ships an unresolved 0.76 Å ambiguity in the ligand pose. At 1.9 Å with RSCC
  0.97 this is a small ambiguity, but it is real and not resolved by anything I ran.
- **2 ligand "clashes" reported by validate_ligands vs 0 overlaps found by Coot** → these two tools
  disagree on the ligand's contacts. I did not reconcile them; I reported the Coot number in the
  narrative and the validate_ligands table stands in the log. Newly implicated as an unexamined
  inconsistency.

## Candidate weaknesses (for expert review)

- **D1b** · **major** · Declared the supplied ATP to be in a "bona fide nucleotide pocket" by
  pattern-matching a contact list; the sequence and the difference map, both already available,
  refute it.
- **D3** · **moderate** · Regenerated R-free set is not naive to the protein; the reported R-free
  is biased low by an unquantifiable amount.
- **D10** · **moderate** · Ligand and 158 new waters were initially confounded in the R-free
  improvement; the matched control was an afterthought, not part of the design.
- **D8** · **minor** · The strongest independent check in the run (two converging ligandfits) was
  a by-product of flailing on argument syntax, not a designed control.
- **D9** · **minor** · Primary/alternate fit chosen on a 0.0006 R-free and 0.09 σ difference —
  both within noise. Only the retention of both is defensible.
- **D2** · **minor** · Lattice shift was applied on the untested assumption that the ligand-protein
  contact was via the identity operator; it was not.
- **process** · **minor** · Four job failures from guessed PHIL parameter names across two
  different programs, with introspection tools available and unused.
- **unreconciled** · **minor** · `validate_ligands` reports 2 ligand clashes; Coot reports 0 atom
  overlaps involving chain B. Not investigated.
