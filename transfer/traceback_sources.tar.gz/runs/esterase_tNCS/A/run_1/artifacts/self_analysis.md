# Self-analysis — esterase_tNCS

## Framing
Self-critique, not independent audit. Candidate weaknesses for expert review, not verdicts.
No causal claims. Decisions judged against data/maps, not against the deposited model.

## Plan divergence
- intended: MR (AF model) → refine → validate → **Coot rebuild of outliers** → final refine → DEPOSIT.
- actual: MR → refine1 → validate → (Coot unavailable) → assessed outliers via density instead → ran two extra
  refine variants (refine2, refine_final) to test solvent/weight → selected refine1 as deposited → DEPOSIT.
- why: Coot's Python interpreter returned "Failed to get __main__ module" on every call for the whole run
  (`coot_info` static text worked; `run_python`/`run_python_multiline`/`coot_ping` all failed). Per instruction
  I retried ~30-60 s cadence for >15 min, then proceeded without the hands-on rebuild, documenting it.

## Forward walk

### D1 — Accept data as-is; SG P2(1)2(1)2(1), 1.60 A, existing FreeR (test=0)
- basis (decision-time): xtriage — 98% complete, <I/sigma> 15.1, Wilson B 12.2, no twinning, mild anisotropy.
- available-but-not-consulted: I verified FreeR distribution intent (CCP4 0-19, test=0) by reasoning, not by a
  per-value count (my cctbx-python one-liner failed on system python; I did not retry with the phenix python).
- alternatives / distinguishing evidence: test_flag_value could be nonzero; a wrong choice would corrupt Rfree.
- judged against: refinement log showed 2734 free reflections (~5.1%) — consistent with flag 0 = 5% test set.
- classification: well-justified · severity: minor · candidate: **yes** — did not independently confirm the
  free-flag value with a direct count; relied on convention + the ~5% cross-check.

### D2 — Space group left as input P2(1)2(1)2(1)
- basis: file SG; xtriage systematic-absence table scored the 2(1) screw axes highest; MR succeeded in it.
- available-but-not-consulted: enantiomorph is self (P2(1)2(1)2(1)); Phaser hand default. Not an issue here.
- judged against: Phaser single solution, TFZ 10.6 in this SG; refinement R-free 0.209. Consistent.
- classification: well-justified · severity: minor · candidate: no.

### D3 — Use provided AF model (residues 42-233) as search model rather than predicting from sequence
- basis: prompt named only mtz+seq as inputs, but the folder provides AF-Q54413; domain seq matches AF 42-233
  exactly (192 res). Standing instruction = "use your recommendation if safe."
- available-but-not-consulted: a fresh phenix.predict_and_build prediction (network) would be strictly
  "sequence-only"; I did not run it. The provided AF model's provenance/version I took at face value.
- alternatives / distinguishing evidence: predicted vs provided model would both be AF of the same UniProt; a
  divergence would show as poor MR — it did not.
- judged against: MR LLG 11880, VRMS 0.11; refinement R-free 0.209 — the model was correct.
- classification: well-justified (got-lucky on the input-constraint interpretation) · severity: minor ·
  candidate: **yes** — the literal "files to use = mtz, seq" was satisfied via a provided model, not de novo
  prediction; an expert may want that flagged.

### D4 — process_predicted_model with pLDDT cutoff 70, no compact-region split
- basis: single CE4 domain; pLDDT high (kept 190/192). Split unnecessary for one domain.
- judged against: Phaser placed it cleanly; density fit excellent post-refine (overall map CC 0.868).
- classification: well-justified · severity: minor · candidate: no.

### D5 — Phaser search 2 copies, tNCS correction ON (default), model_identity=95
- basis: Matthews 2 copies; xtriage tNCS. model_identity=95 because crystal ~ same protein as AF.
- available-but-not-consulted: I did not run a control with tNCS off to quantify its contribution (would have
  isolated the tNCS effect empirically rather than by inference).
- alternatives: 1 or 3 copies (Matthews P 0.10 / 0.02) — rejected; tNCS off — not tested.
- judged against: Phaser tNCS vector == xtriage vector; single solution TFZ 10.6; 2 mols pack.
- classification: well-justified · severity: minor · candidate: **yes** — the tNCS-off control that would have
  directly demonstrated the correction's value was available and not run (assessment relies on the `+TNCS` flag
  and literature, not a head-to-head).

### D6 — refine1: XYZ+ADP+occ, ordered solvent, optimize xyz/adp weights, 3 macrocycles
- basis: 1.60 A → individual ADP appropriate; ordered solvent standard; NCS restraints off at <2.5 A.
- judged against: R 0.326→0.1795/0.2086, MolProbity 1.41, clashscore 4.30, bonds 0.017 — all healthy.
- classification: well-justified · severity: minor · candidate: no.

### D7 — Interpreted the 3 Ramachandran outliers as real; did NOT restrain/flip them
- basis: per-residue RSCC 0.95-0.97, occ 1.0, low B; Ile123 outlier in BOTH NCS copies identically.
- available-but-not-consulted: direct visual inspection in Coot (unavailable); an OMIT/polder map at these
  residues would have been a stronger, bias-reduced confirmation than the 2mFo-DFc RSCC I used.
- alternatives: force-favored via ramachandran restraints or pepflip — rejected as fighting the density.
- judged against: RSCC from the refined 2mFo-DFc map (model-biased, but strong and NCS-consistent).
- classification: well-justified · severity: moderate · candidate: **yes** — the retention rests on
  model-biased RSCC + NCS consistency, not on an independent OMIT map or hands-on inspection.

### D8 — Selected refine1 over refine2 (lower R-free) as the deposited model
- basis: refine2 R-free 0.2050 vs refine1 0.2086 (0.0036), but refine2 clashscore 4.3→6.8, rotamer 0→0.68%,
  MolProbity 1.41→1.60; the gain came from ~140 extra waters at 5-9 sigma peaks (over-picking).
- available-but-not-consulted: a properly tuned single round (moderate weight + conservative solvent from
  refine1) might have captured the real waters without the geometry cost; I approximated this with
  refine_final (default weights from refine2) which instead raised R to 0.2112 — a suboptimal path.
- judged against: MolProbity/clash/rotamer (geometry) vs the tiny R-free delta.
- classification: well-justified (physical-realism principle) · severity: minor · candidate: no
  (both models preserved; choice documented).

### D9 — No catalytic metal / ligand built
- basis: find_peaks_holes max mFo-DFc 9.4 sigma near Arg/Gly/waters; no dominant peak; CE4 metal site not
  obviously occupied.
- available-but-not-consulted: I did not examine whether the conserved CE4 metal-binding triad (Asp/His/His)
  has a coordinated peak specifically; I reasoned from the global peak list, not the active-site geometry.
  Buffer chemistry (README skipped by instruction) could have identified a likely anion (e.g. sulfate).
- alternatives: model a metal or anion at the 9 sigma sites — deferred pending Coot/OMIT inspection.
- judged against: peak heights/positions in the difference map (independent of the protein model).
- classification: weakly-justified · severity: moderate · candidate: **yes** — "apo, no ligand" was inferred
  from the global peak list without an active-site-specific check or an OMIT map; a real metal/anion could be
  under-modeled.

### D10 — Coot rebuild not performed
- basis: Coot Python unresponsive the whole run; retried >15 min per instruction.
- judged against: N/A (tool unavailable). Mitigated by D7/D9 density checks.
- classification: not-a-modeling-decision (environmental) · severity: moderate · candidate: **yes** —
  the requested rebuild step did not execute; reported honestly, but coverage of any subtle rebuildable
  errors is therefore weaker than a normal run.

## Backward trace
- R-free gap 0.209 vs R-work 0.179 (0.030) is normal for 1.60 A → no over-fitting concern in refine1.
- Rama outliers 0.80% (above the <0.5% goal) → D7: retained as real; unverified by OMIT/Coot → candidate.
- Residual 9 sigma difference peaks unmodeled → D9: possible under-modeled solvent/anion/metal → candidate.
- Rebuild not done → D10: environmental; the outlier/peak assessment substitutes for, but does not equal,
  hands-on inspection.

## Candidate weaknesses (for expert review)
- D9 · moderate · "apo / no ligand" inferred from global peak list, not an active-site-specific or OMIT check; 9σ peaks unmodeled.
- D7 · moderate · 3 Rama outliers retained on model-biased RSCC + NCS consistency, not an independent OMIT map.
- D10 · moderate · requested Coot rebuild never executed (tool down); subtle rebuildable errors uncovered.
- D5 · minor · tNCS-off control not run; correction's value argued from the +TNCS flag + literature, not measured.
- D3 · minor · input constraint (mtz+seq) satisfied via a provided AF model rather than de novo prediction.
- D1 · minor · free-flag value (0) confirmed by convention + ~5% cross-check, not a direct per-value count.
