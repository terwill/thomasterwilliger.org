# Self-analysis — p9-sad

## Framing
Self-critique, not independent audit. Candidate weaknesses for expert review, not verdicts.
No causal claims. Decisions judged against data/maps, not against the deposited model.

## Plan divergence
- intended: PROPOSED PLAN = xtriage on p9.sca → AutoSol SAD → validate map vs perfect.mtz →
  refine/validate → DEPOSIT. | actual: followed exactly, plus 3 AutoSol restarts to fix
  command-line PHIL ambiguity (data=/atom_type=/space_group/nproc scoping). | why: phenix.autosol
  shortcut params are ambiguous unless fully qualified (autosol.*, general.nproc); space_group and
  nproc live in nested scopes. No scientific change; only invocation syntax.

## Forward walk

### D1 — Substitute p9.sca (anomalous) for the user-named perfect.mtz as the phasing dataset
- basis (decision-time): iotbx.mtz.dump of perfect.mtz showed only FP,SIGFP(=1),PHIC,FOM(=1) — no
  anomalous columns; history "From solve 2002". p9.sca header showed I+/sig/I-/sig anomalous pairs.
  xtriage on p9.sca: anomalous measurability 0.198, signal to ~2.1 A. SAD is impossible without
  anomalous differences.
- available-but-not-consulted: README.txt (user asked to skip); p9_se_w2.sca full contents (only its
  header inspected). Either might have named the "canonical" file; I chose p9.sca on merged-anomalous
  format grounds.
- alternatives / distinguishing evidence: (a) attempt SAD on perfect.mtz — ruled out by absence of
  anomalous data; (b) use p9_se_w2.sca instead of p9.sca — both are the same Se dataset; p9.sca is
  already merged/anomalous and xtriage read it cleanly. Distinguishing evidence would be the README or
  run.com's exact file; run.com invokes the wizard on the sav/ dir, not a named file.
- judged against (independent of final model): xtriage anomalous-signal table (0.198 measurability),
  and — post hoc but model-independent — map CC 0.833 vs perfect.mtz ground truth. Both confirm the
  chosen data carried real, phasable signal.
- classification: well-justified
- severity: major (it overrides an explicit user file selection)
- candidate: yes — overriding a user-named input is inherently high-stakes; an expert should confirm
  that p9.sca (vs p9_se_w2.sca) is the intended dataset and that substitution was acceptable rather
  than halting for the user.

### D2 — Accept p9.sca as-is; no reprocessing / no resolution cut for substructure
- basis (decision-time): xtriage — completeness 0.99, anomalous completeness 0.98, <I/sigma> 10.3, no
  twinning, no ice-ring/anisotropy flags surfaced in the summary I read.
- available-but-not-consulted: full xtriage anisotropy/ice sections (I read summary lines, not the
  entire log); per-shell CC-anom.
- alternatives / distinguishing evidence: cap substructure resolution ~2.1 A; AutoSol does this
  internally (it phased at 1.7 but scores substructure on anomalous shells), so manual capping was
  unnecessary.
- judged against: AutoSol found 4/4 expected sites with 0 special-position artifacts and clean hand
  discrimination — consistent with adequate, correctly-weighted data.
- classification: well-justified
- severity: minor
- candidate: no — well-justified + minor.

### D3 — AutoSol params: atom_type=Se, sites=4, SG from data, defaults otherwise
- basis (decision-time): 4 Met in seq.dat; Matthews best-guess 1 copy/ASU; SG I4 in data and xtriage;
  check.xyz has 4 reference sites (not used as input, only noted).
- available-but-not-consulted: explicit f'/f'' for Se peak (left to AutoSol estimate); did not raise
  thoroughness.
- alternatives / distinguishing evidence: provide f''/wavelength for stronger substructure weighting —
  would matter only if the default search had failed; it did not.
- judged against: HySS found exactly 4 sites; BAYES-CC 0.539 and map CC 0.833 vs truth — defaults were
  sufficient.
- classification: well-justified
- severity: minor
- candidate: no.

### D4 — Report "4 Se sites" while the refined HA file lists 5 Se
- basis (decision-time): autosol.log scoring line "with 4 sites" (HySS substructure); the output
  overall_best_ha_pdb.pdb lists 5 Se with occupancies 1.80/1.31/1.62 (ordered) and 0.29/0.35 (weak).
- available-but-not-consulted: an anomalous difference-Fourier peak-height check on each of the 5 Se
  to confirm which are real (not yet run).
- alternatives / distinguishing evidence: report 5 (raw HA file) vs 4 (HySS) vs 3 (strongly ordered).
  A peak-height/occupancy table would settle it.
- judged against: occupancies themselves (2 sites < 0.4) and the 4-Met expectation.
- classification: well-justified (I reported the HySS number as headline and disclosed the 5/3 split)
- severity: minor
- candidate: yes — the exact site count is a reported deliverable; the 2 weak Se are unverified against
  an anomalous map and should be confirmed before deposition.

### D5 — Stop at the AutoSol initial model; no manual Coot rebuild, no extra autobuild/refine
- basis (decision-time): task asked for an "initial model"; MolProbity showed 0 Rama/rotamer/Cbeta
  outliers, clashscore 4.81, R/Rfree 0.231/0.246 — already clean. No Coot-requiring step was reached.
- available-but-not-consulted: whether the 14 unbuilt residues sit in clear density (would justify more
  building); a difference map inspection.
- alternatives / distinguishing evidence: run phenix.autobuild to completion or Coot loop-building; a
  difference map would show whether unbuilt density is interpretable.
- judged against: map–model CC 0.85 and clean geometry — the built portion is sound; the unbuilt
  portion is untested.
- classification: well-justified for the stated scope ("initial model")
- severity: moderate (14/138 residues unbuilt; Rfree 0.246 could improve)
- candidate: yes — completeness was bounded by scope, not by data; an expert may want the model pushed
  further before calling it final.

## Backward trace
- Rfree 0.246 and 14 unbuilt residues → D5 (stopped at initial model) and D2 (no attempt to squeeze
  low-completeness outer shells). Recoverable with more building/refinement; not a validation-integrity
  issue.
- 5 Se in HA file vs 4 expected → D4; the 2 weak sites are unverified independently of the phasing that
  placed them — flag for anomalous-map confirmation (guardrail: cannot be validated by the model alone).
- Free-R provenance: AutoSol generated its own FreeR set for the built model; there is no pre-existing
  cross-validation set to preserve, and perfect.mtz (no FreeR) was not used for refinement — so no
  cross-validation contamination. Noted for completeness.

## Candidate weaknesses (for expert review)
- D1 · major · Overrode a user-named input (perfect.mtz → p9.sca); confirm intended dataset and that
  substitution (vs halting) was acceptable; p9_se_w2.sca not compared directly.
- D4 · minor · 2 weak Se (occ 0.29/0.35) reported but not confirmed against an anomalous difference map.
- D5 · moderate · Model stopped at 124/138 residues (Rfree 0.246); completeness bounded by scope, not
  data — may warrant further autobuild/Coot before final.
