# FINAL REPORT — gene-5 (gene-V) protein refinement

**Case:** `refined_start` — gene-5 / gene-V DNA-binding protein. Space group C 1 2 1,
unit cell 76.08 / 27.97 / 42.36 Å, β = 103.2°. Resolution 21.33–2.59 Å, 2634 reflections,
93.6% complete. SAD-derived data (AutoSol provenance in MTZ), which is why the model
carries 4 partial-occupancy Se substructure sites (chain Z) plus one selenomethionine (MSE 77).

## Headline result

| Metric | Baseline (input model.pdb) | Final (DEPOSIT/gene5_final.pdb) | Source |
|---|---|---|---|
| R-work | 0.1975 | **0.1813** | refine log `refine_final.log` (Final R line) |
| R-free | 0.2401 | **0.2368** | refine log `refine_final.log` (Final R line) |
| R-work (independent) | — | 0.1814 | `molprobity_final.log` (phenix.molprobity) |
| R-free (independent) | — | 0.2365 | `molprobity_final.log` (phenix.molprobity) |
| R-work − R-free gap | 0.044 | 0.055 | — |

Baseline R-work/R-free are from the input `model_vs_data.log` and the PDB header, which agree.
The refinement-log and the standalone-MolProbity R-factors agree to within 0.0003, so the
reported values are robust: **R-work ≈ 0.181, R-free ≈ 0.237.**

## Geometry / validation (final model)

| Metric | Value | Source |
|---|---|---|
| Bond RMSD | 0.005 Å (refine) / 0.0020 Å (MolProbity) | `refine_final.log` / `molprobity_final.log` |
| Angle RMSD | 0.72° (refine) / 0.54° (MolProbity) | `refine_final.log` / `molprobity_final.log` |
| Clashscore | 1.51 | `molprobity_final.log` |
| MolProbity score | 1.47 | `molprobity_final.log` |
| Ramachandran outliers | 0.00% | `molprobity_final.log` |
| Ramachandran favored | 97.56% | `refine_final.log` |
| Rama-Z (whole) | 1.21 (good, \|Z\|<2) | `molprobity_final.log` |
| Rotamer outliers | 2.74% (2 residues) | `molprobity_final.log` + `phenix.rotalyze` |
| Cβ deviations | 0 | `molprobity_final.log` |
| cis / twisted peptides | 0 | `refine_final.log` |

The two RMSD numbers differ because phenix.refine and standalone MolProbity use different
restraint libraries; both indicate excellent geometry, well within limits.

## Where it stands

The model is **at a genuine improvement over the provided baseline**, cross-validated:
R-free fell 0.2401 → 0.2368 while R-work fell 0.1975 → 0.1813, with the R−Rfree gap staying
healthy (0.055) — i.e. no overfitting. Geometry is excellent (MolProbity 1.47, clashscore 1.51,
0 Ramachandran/Cβ outliers). This is a small (84-residue) protein at moderate resolution and the
result is deposition-quality.

**Remaining rotamer outliers (2):** A/53 GLN and A/84 VAL. Both were examined in density and
are **data-supported** — forcing them to library-favored rotamers *worsened* the side-chain
map correlation (A/84: 0.646 → 0.525; the SER/VAL/GLN side chains sit in real 1.4–1.8 σ density).
Per the physical-realism principle, they were kept in their density-consistent conformations
rather than trading map fit for a nicer rotamer name. This is the main residual uncertainty and
is flagged for expert visual review.

## What was done (evidence-based, iterative)

1. **Rejected an over-aggressive first pass.** Weight-optimization + ordered-solvent flooding
   (36→48 waters) dropped R-work to 0.183 but raised R-free to 0.248 — overfitting. Not committed.
2. **Diagnosed a low-data regime.** Default auto-weight refinement drove R-work to 0.144 with
   R-free 0.245 (0.10 gap) — classic overfitting at 2.59 Å / 2634 reflections. Adopted
   `optimize_xyz_weight`/`optimize_adp_weight` (which target R-free) for all subsequent runs.
3. **Coot rebuild of density-improving rotamers only.** Fixed A/45 VAL and A/53 GLN (side-chain
   map-CC up, e.g. A/53 0.582 → 0.640); kept A/20 SER and A/84 VAL as data-supported outliers.
   No missing residues built (0 difference-map blobs > 3σ; termini M1/A86/K87 disordered).
   Restored 2 waters that Coot silently dropped on write, so no atoms were lost (696 atoms retained).
4. **Final refinement** (optimize weights, occupancies on, no solvent flooding) → R 0.181 / 0.237.
   The rebuild's incremental value: identical-weighting refinement without the Coot edits gave
   0.1901 / 0.2399, so the edits lowered R-free by 0.0031.

## Cross-validation integrity

The original R-free flag set (column `R-free-flags`, free value = 1) was used unchanged for
every refinement. It was **never** regenerated or extended — R-free remains a valid cross-validation.

## File inventory (DEPOSIT/)

- `gene5_final.pdb` — final refined model (656 protein atoms, 4 Se, 36 waters, MSE 77).
- `gene5_final_mmcif.cif` — same model in mmCIF (696 atoms, matches PDB).
- `gene5_final.mtz` — data + refined map coefficients (2FOFCWT, FOFCWT).
- `refine_final.log` — final phenix.refine log (R-factors, geometry).
- `molprobity_final.log` — independent phenix.molprobity validation.
- `refine_final_params.eff` — exact refinement parameters used.
- `RUN_LOG.json` — full decision log with decision-time bases and sources.
- `FINAL_REPORT.md` — this file.

## Next steps / remaining uncertainties

- Expert visual check of A/53 GLN and A/84 VAL rotamers in density (data-supported outliers).
- The 4 Se sites (occ 0.22–0.58) are legitimate SAD substructure; Z/1 and Z/5 showed mild
  negative difference density pre-refinement, settled by occupancy refinement — worth a glance.
- Termini (M1, A86–K87) left unbuilt (no density) — correct at this resolution.
