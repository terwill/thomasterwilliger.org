# Self-analysis — refined_start (A)

## Framing
Self-critique, not independent audit. Candidate weaknesses for expert review, not verdicts.
No causal claims. Decisions judged against data/maps, not against the deposited model.

## Plan divergence
- intended: refine (default -> +TLS) then Coot rebuild (rotamers/register/waters) then re-refine.
  actual: 6 refinement variants tested; ALL degraded R-free/geometry vs baseline, so the
  deposit preserves baseline coordinates with only the 4 free Se removed. Coot rebuild never
  ran (Coot down ~15 min). why: (a) model was already reciprocal-space converged, so refinement
  overfit; (b) Coot MCP returned "Failed to get __main__ module" continuously.

## Forward walk

### D0 — Preserve existing R-free set (generate=False intent)
- basis (decision-time): data.mtz contains R-free-flags (model_vs_data "flag value: 1").
- available-but-not-consulted: none.
- alternatives: regenerate (would destroy cross-validation provenance) — rejected.
- judged against: log confirmed phenix.refine reused the existing flags (263 test refl throughout).
- classification: well-justified · severity: minor · candidate: no.

### D1 — First refine used optimize_xyz_weight/adp + ordered_solvent, 5 cycles
- basis: standard "best-shot" polish; had not yet seen that model was converged.
- available-but-not-consulted: I could have run model_vs_data / molprobity on the baseline FIRST
  to learn it was already converged before choosing an aggressive protocol.
- alternatives: conservative low-weight refine; distinguished by the per-stage R-free table.
- judged against: stage table showed 3_xyzrec drove R-free 0.2284->0.2529 while R-work fell —
  clear overfit, independent of any final model.
- classification: weakly-justified (over-aggressive first choice) · severity: moderate ·
  candidate: yes — should have characterized the baseline before refining.

### D2 — Diagnosed overfit, reverted to original model, dropped weight optimization
- basis: per-stage table + data:param ratio (~4 obs/atom).
- judged against: refine2/refine3 stage tables (independent of final model) — confirmed every
  xyz step raised R-free.
- classification: well-justified · severity: minor · candidate: no.

### D3 — Remove 4 free Se (chain Z)
- basis: not bonded (34–74 A from protein); 2mFo-DFc only 1.6–2.0 sigma with mFo-DFc ~0/neg;
  refined B up to 92; no anomalous data; only 2 Met in sequence.
- available-but-not-consulted: anomalous/original SAD data (NOT in data.mtz — genuinely
  unavailable here). A polder/omit map around each Se would have been a stronger independent test
  than the model-biased 2mFo-DFc sampling I used.
- alternatives: keep as Se; remodel as water/ion. Distinguisher: anomalous difference map (absent)
  or omit-map density.
- judged against: map sampling at Se sites + the fact that removal raised R-work but left R-free
  unchanged (they lowered R-work without helping cross-validation = overfit). Independent of final model.
- classification: well-justified · severity: moderate (identity call on a heteroatom) · candidate:
  yes — map evidence was model-biased 2mFo-DFc; an omit/anomalous map would harden it.

### D4 — Did NOT force rotamer fixes in reciprocal space
- basis: candidate A (gentle refine) fixed only 1/4 rotamers and raised clashscore 0.75->4.5.
- judged against: molprobity of candidate A vs baseline (independent geometry check).
- classification: well-justified (avoids trading geometry for nothing) · severity: minor ·
  candidate: no — but the underlying rotamer outliers remain UNRESOLVED (see backward trace).

### D5 — Deposit = baseline coords + Se removed via 0-macrocycle (scaling-only) refine
- basis: all coordinate-moving refinements were equal/worse on R-free and worse on geometry.
- judged against: molprobity/table_one of the 0-cycle model = baseline geometry (1.55/0.76/0.0038)
  with R-free 0.2417; independent of any model I built.
- classification: well-justified · severity: minor · candidate: no.

### D6 (silent, caught) — First Se-removal grep silently failed
- basis: pattern spacing mismatch; verification grep used the same bad pattern so both read "0".
- judged against: atom-count check (696 unchanged; candidate outputs still had 4 Se) exposed it.
- classification: got-lucky-that-I-checked / would-have-been-wrong · severity: moderate (nearly
  shipped Se-containing "cleaned" models) · candidate: yes — verify edits by element/atom count,
  not by the same string pattern used to make the edit.

## Backward trace
- Stubborn R-free ~0.242 floor -> originating: the provided model was already converged (not a
  decision of mine). No refinement lever moved R-free below baseline; honest floor at 2.59 A.
- 4 residual rotamer outliers (A20/A45/A53/A84) -> originating: Coot unavailability (D4). These
  are the clearest unfinished business; they need real-space rotamer fitting + local refine that
  does not add clashes. NOT verifiable/ fixable without Coot in this run.
- MSE77 side chain truncated at CB (missing CG/SE/CE) -> not rebuilt (needs Coot + density check).
  Add to candidates: whether density supports completing MSE77 was not tested with an omit map.
- Se identity (D3) rests on model-biased 2mFo-DFc + absence of anomalous data -> flagged: cannot
  be independently confirmed here; an omit/anomalous map is the missing check.

## Candidate weaknesses (for expert review)
- D1 · moderate · aggressive first-refine protocol before characterizing an already-converged model.
- D3 · moderate · Se removal justified but on model-biased density + no anomalous map (omit map not run).
- D6 · moderate · first model edit silently failed; only an atom-count check caught it.
- Backward/rotamers · major-ish · 4 rotamer outliers left unresolved because Coot was down (rebuild not completed).
- Backward/MSE77 · minor-moderate · truncated selenomethionine side chain not completed or omit-tested.
