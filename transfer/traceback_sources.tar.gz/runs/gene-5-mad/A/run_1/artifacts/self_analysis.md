# Self-analysis — gene-5-mad (bacteriophage f1 Gene V protein, Se-Met SAD)

## Framing
Self-critique, not independent audit. Candidate weaknesses for expert review, not verdicts.
No causal claims. Decisions judged against data/maps, not against the deposited model.

## Plan divergence

- **intended:** xtriage → AutoSol → AutoBuild → refine → MolProbity → Coot pass → DEPOSIT.
  **actual:** matched, except that the Coot pass expanded into an extended
  Se-triage + rotamer investigation that consumed most of the run, and required
  three additional refinement variants plus a targeted single-residue refinement.
  **why:** AutoBuild's output carried three free Se atoms that were not chemically
  interpretable at face value; resolving them changed the model materially.
- **intended:** treat the case as MAD (directory name `gene-5-mad`).
  **actual:** treated as SAD. **why:** only `peak.sca` was supplied. Stated up front.
- **intended:** use secondary-structure restraints in final refinement.
  **actual:** dropped after two PHIL failures. **why:** this build exposes no
  `main.secondary_structure_restraints` toggle and I chose not to thrash further.

## Forward walk

### D1 — Treated the case as SAD, not MAD
- basis (decision-time): only one reflection file named in the prompt; `peak.sca` is a single wavelength.
- available-but-not-consulted: `high.sca` and `infl.sca` sit in the source directory. I did **not** use them because the user specified which files to use — but I also never told the user that using all three would have given a genuinely stronger MAD experiment.
- alternatives / distinguishing evidence: running 3-wavelength MAD would likely have produced a better substructure and phases.
- judged against: xtriage anomalous measurability (0.367 max, signal to 3.1 Å) showed SAD alone was viable; DM FOM reached 0.73.
- classification: well-justified (as instructed) but under-communicated
- severity: moderate
- candidate: **yes** — I followed the file list without flagging that two additional wavelengths were available and would probably have improved phasing.

### D2 — Did not read `sites.xyz` / `Facts.list`
- basis: they are answer-key-like; using them would invalidate the exercise.
- available-but-not-consulted: deliberately so.
- alternatives: reading `sites.xyz` would have immediately settled the Se-site question that later cost most of the run.
- judged against: n/a — a process decision, not a data one.
- classification: well-justified
- severity: minor
- candidate: no — deliberate and disclosed.

### D3 — AutoSol run with `sites=2`, `thoroughness=thorough`, defaults elsewhere
- basis: sequence has exactly 2 Met; 87 residues; Vm indicated 1 copy.
- available-but-not-consulted: I did not set an explicit `res_hyss` substructure-search resolution even though xtriage explicitly said the anomalous signal extends to ~3.1 Å and that this "can be used as a guideline to decide where to cut the resolution for phenix.hyss". I let HySS use defaults.
- alternatives / distinguishing evidence: an explicit 3.1 Å HySS cutoff might have produced a cleaner substructure with fewer spurious low-occupancy sites — precisely the sites that later caused trouble.
- judged against: AutoSol found 6 sites where 2 were expected, 3 of which were carried into the model and 2 of which I later had to delete. That is direct evidence the substructure was noisier than necessary.
- classification: weakly-justified
- severity: moderate
- candidate: **yes** — xtriage handed me the exact parameter to set and I ignored it; the downstream Se confusion traces back here.

### D4 — Accepted AutoSol's best solution (BAYES-CC 48.3) without re-running
- basis: clean hand separation (44–48 vs 14), DM FOM 0.73, DM R 0.298, interpretable map.
- available-but-not-consulted: none material.
- judged against: the DM map's CC_mask against the eventual model is 0.813, and AutoBuild reached R-free 0.22 from these phases — the map was genuinely good, independent of the final model's own refinement.
- classification: well-justified
- severity: minor
- candidate: no.

### D5 — Ran AutoBuild with `rebuild_in_place=False`
- basis: AutoSol's model was 68/87 residues in 8 fragments — needed extension, not polishing.
- judged against: residue count went 68 → 84 and R-free 0.46 → 0.22 across cycles; sequence register then matched the target exactly at every position 2–85.
- classification: well-justified
- severity: minor
- candidate: no.

### D6 — Reused AutoSol's R-free flag set throughout
- basis: cross-validation integrity; the flags live in `overall_best_refine_data.mtz`.
- judged against: verified `FreeR_flag` present and used in every refinement (264 reflections, 10.03 %); never regenerated.
- classification: well-justified
- severity: minor (but critical had it gone the other way)
- candidate: no.

### D7 — Initial claim that the 3 free Se atoms were chemically impossible artifacts
- basis (decision-time): all three had **no neighbours within 6 Å** in the asymmetric unit, and Se in a Se-Met crystal exists only covalently in selenomethionine.
- available-but-not-consulted: **crystallographic symmetry.** I searched only the ASU. That was a plain analysis error — symmetry mates are the first thing to check for an isolated atom.
- alternatives / distinguishing evidence: the symmetry-aware search (which I ran next) immediately overturned the conclusion.
- judged against: `mmtbx.refine_anomalous_substructure` showed Z/4 at 22.45 σ — a *stronger* anomalous peak than the real Met77 Se. My hypothesis was flatly contradicted by the data.
- classification: **wrong**
- severity: moderate (caught before it touched the model)
- candidate: **yes** — I asserted a chemical impossibility argument from an incomplete search. It was corrected only because I happened to run an anomalous check; had I acted on the chemistry argument alone I would have deleted a real Met77-related peak and kept a mis-built side chain.

### D8 — Rebuilt the Met77 side chain in Coot
- basis: CE sat in 0.09 σ density, SE had B = 178 Å² with +2.81 σ Fo-Fc, CG at 1.05 σ with −1.90 σ Fo-Fc.
- judged against (independent of final model): after the rebuild, the anomalous peak on MSE77's Se rose 10.48 σ → **20.69 σ** while Z/4's collapsed 22.45 σ → 5.90 σ. The anomalous map is computed from the experimental Bijvoet differences, so this is data-side evidence, not model self-confirmation.
- classification: well-justified
- severity: major (in the sense that it was a materially wrong side chain, now corrected)
- candidate: no — but worth expert confirmation that the new rotamer is right, since the 2Fo-Fc map used to judge it was model-phased.

### D9 — Deleted SE Z/4
- basis: after the Met77 rebuild, `.geo` showed SE(MSE77) ↔ SE(Z/4) at **0.523 Å** across symmetry op `-x+1/2,y+1/2,-z+2` — physically impossible.
- judged against: geometry file, independent of R-factors.
- classification: well-justified
- severity: minor
- candidate: no.

### D10 — Rejected variant v1 despite it having the best R-free
- basis: v1 R-free 0.2185 vs v3 0.2280, but v1 contained the 0.523 Å Se–Se contact.
- judged against: the 0.52 Å contact is a hard physical violation; the R-free advantage came from two Se effectively modelling one heavy atom.
- classification: well-justified (physical realism over R-free, per stated principle)
- severity: minor
- candidate: no — but I note the deposited model has a *worse* R-free than a rejected alternative, and that should be visible to a reviewer.

### D11 — Converted SE Z/5 to a water (deleted, re-placed by ordered_solvent)
- basis: **no anomalous signal at all**, Fo-Fc −2.21 σ on a Se, 2.91 Å H-bond to Ile2 N.
- judged against: anomalous map + difference density, both data-side.
- classification: well-justified
- severity: minor
- candidate: no.

### D12 — Kept SE Z/2 and assigned it as the Met1 selenium
- basis: 5.98 σ anomalous peak; 5.50 Å from Ile2 N; no clashes; both sequence Met otherwise accounted for.
- available-but-not-consulted: I did not attempt to build the Met1 backbone, nor test an alternative identity (a partially-ordered ion from the crystallization buffer) — I have **no crystallization recipe**, so I cannot exclude an ion. Se is the only anomalous scatterer I can positively identify at this wavelength, but a heavier ion would also scatter anomalously.
- alternatives / distinguishing evidence: a polder/OMIT map around the site, or occupancy-vs-B behaviour for different element assignments, would discriminate better than what I did.
- judged against: anomalous peak height and distance geometry — both independent of the refined model. But the *identity* rests on an elimination argument, not a positive test.
- classification: weakly-justified
- severity: **major** — it is a modelled atom with an asserted chemical identity resting on inference.
- candidate: **yes** — flagged in the DEPOSIT README, but a reviewer should independently confirm. This is the single least-verified claim in the deposited model.

### D13 — Set occupancy 0 on distal atoms of Arg21 and Lys24
- basis: 2Fo-Fc 0.39–0.65 σ with negative Fo-Fc on those atoms.
- available-but-not-consulted: I did not check whether zero-occupancy atoms still count in MolProbity's rotamer statistics — they do, so this did not help the metric it might have been expected to help.
- alternatives: truncate the side chains, or leave at full occupancy with high B.
- judged against: per-atom density probe (data-side).
- classification: well-justified as chemistry; the effect on validation stats was misjudged
- severity: minor
- candidate: **yes** (low priority) — arguably an inconsistent policy: I zeroed Arg21/Lys24 but left Gln12 fully modelled despite its CG sitting at −0.02 σ. That inconsistency is not principled.

### D14 — Left Gln12 fully modelled
- basis: its OE1 has 2.12 σ density while CG has −0.02 σ — an incoherent pattern I could not resolve; a 180° amide flip did not improve it.
- available-but-not-consulted: whether the 2.12 σ at OE1 is actually a water; I never tested that.
- classification: weakly-justified
- severity: moderate
- candidate: **yes** — inconsistent with D13, and the untested water hypothesis is cheap to check.

### D15 — Used plain ML rather than MLHL for final refinement
- basis: wanted R-free to be an honest cross-validation statistic not propped up by experimental phase restraints.
- available-but-not-consulted: I never ran the MLHL comparison, so I don't actually know the size of the difference.
- classification: well-justified (conservative)
- severity: minor
- candidate: no.

### D16 — Used `restore_to_backup_checkpoint` for revert logic in Coot
- basis: the Coot skill documents checkpoints as the backtracking mechanism.
- judged against: **it silently failed.** A whole rotamer pass reported 4 residues "FIXED" and wrote a file that was byte-identical to its input. I caught it only because I diffed the coordinates against the input.
- classification: **wrong** (mechanism misuse)
- severity: **critical for process integrity** — had I not diffed, I would have reported four rotamer fixes that did not exist, and the reported outlier count would have been wrong.
- candidate: **yes** — this is the most alarming event in the run. Any tool-reported "success" that is not verified against the artifact on disk is untrustworthy.

### D17 — Final geometry strategy: fix rotamers in Coot, then refine B-factors/occupancies only
- basis: three prior rounds showed `phenix.refine` coordinate refinement re-breaking rotamers (no rotamer restraints in reciprocal-space refinement).
- available-but-not-consulted: `phenix.real_space_refine` with `rotamers.restraints.enabled=True`, or AQuaRef, either of which might have fixed rotamers *and* allowed coordinate refinement against the data.
- alternatives: the coordinates in the deposited model were last optimized against the map in Coot, not against structure factors (except residue 77).
- judged against: R-free moved 0.2194 → 0.2180 across the change, i.e. the rotamer fixes cost nothing in cross-validation.
- classification: weakly-justified
- severity: moderate
- candidate: **yes** — an unusual endgame; a reviewer may object that final coordinates were not refined against the data in reciprocal space.

### D18 — Targeted single-residue coordinate refinement of residue 77
- basis: my own rotamer fix introduced a 0.279 Å Cβ deviation at MSE77.
- judged against: `phenix.cbetadev` on the output → 0 deviations; R-free 0.2187 → 0.2179.
- classification: well-justified
- severity: minor
- candidate: no.

### D19 — Retained 14 "poorly ordered" waters
- basis: their CC values (0.69–0.93) are mostly reasonable.
- available-but-not-consulted: I did not test removing them and re-refining.
- classification: weakly-justified
- severity: minor
- candidate: **yes** (low priority) — untested; 14 of 50 waters is a meaningful fraction.

## Backward trace

- **Rotamer outliers stuck at 6.76 % (target < 1 %)** → D17, D3, D8. Partly irreducible
  (disordered surface side chains at 2.6 Å), but the fix-then-drift cycle consumed the
  budget that a `real_space_refine`-with-rotamer-restraints approach might have solved
  directly. Newly implicated: **D17**.
- **R-work/R-free gap 8.1 %, wider than typical for 2.6 Å** → D17 and the strategy choice.
  I added TLS to address over-parameterization but never tested `group_adp`, and I never
  went back to check whether the gap narrowed. Newly implicated: **D17**.
- **A deposited model whose R-free (0.2180) is worse than a rejected variant's (0.2185)**
  → D10. Defensible, but a reviewer must be told, and the README does say so.
- **The chain Z Se identity remains an inference** → D12, D3. If the substructure search
  had been run at the anomalous-signal resolution (D3), there might have been fewer
  ambiguous sites to adjudicate at all.
- **Four phantom "fixes"** → D16. Caught by diffing, but this is a general process
  weakness: I trusted tool return values in several other places without verifying the
  artifact (e.g. I did not diff after the *successful* passes either — only after the
  metric looked suspicious).
- **Two failed refinement launches on PHIL names** (`main.secondary_structure_restraints`,
  `secondary_structure.enabled`) → I guessed parameter paths instead of querying
  `phenix_get_phil` first, which I had already used successfully for AutoSol/AutoBuild.
  Minor, but it cost the secondary-structure restraints entirely.

## Candidate weaknesses (for expert review)

- **D16** · critical (process) · Coot checkpoint-revert silently discarded 4 reported fixes; any unverified tool "success" in this run should be re-checked against the file on disk.
- **D12** · major · Chain Z Se assigned to Met1 by elimination, not by a positive test; no crystallization recipe was available to exclude an ion.
- **D7** · moderate · Declared free Se atoms chemically impossible from an ASU-only neighbour search; contradicted by the anomalous data.
- **D3** · moderate · Ignored xtriage's explicit 3.1 Å guidance for the HySS substructure cutoff; substructure was noisier than expected (6 sites for 2 Met).
- **D17** · moderate · Final coordinates optimized in real space (Coot), not reciprocal space; R-gap and rotamer outliers both left unresolved.
- **D14** · moderate · Gln12 left fully modelled with CG at −0.02 σ; the "OE1 density is a water" hypothesis was never tested.
- **D1** · moderate · Two further wavelengths (`high.sca`, `infl.sca`) existed; I never told the user MAD was possible.
- **D13** · minor · Zero-occupancy policy applied inconsistently (Arg21/Lys24 but not Gln12).
- **D19** · minor · 14 poorly-ordered waters retained without testing their removal.
