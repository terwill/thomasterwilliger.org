# Self-analysis — porin-twin

## Framing
Self-critique, not independent audit. Candidate weaknesses for expert review, not verdicts.
No causal claims. Decisions judged against data/maps (xtriage statistics, per-residue density
correlation, MolProbity), not against the deposited model. The deposited model cannot be evidence
that the decisions producing it were right; anything not verifiable independently of that model is
flagged below.

## Plan divergence
- intended: xtriage -> baseline -> twin refine -> validate -> Coot fixes -> iterate -> DEPOSIT.
- actual: followed the plan. One unplanned detour: first twin refine failed on an ambiguous
  `twin_law=` shortcut; re-run with `data_manager.fmodel.xray_data.twin_law`. No scientific impact.
- The user pre-authorized "defaults/recommendation" at gates, so the PROPOSE-mode plan was emitted
  but not ratified before running; all forks resolved by recommendation.

## Forward walk

### D1 — Twin law = h,-h-k,-l
- basis (decision-time): xtriage — only merohedral (type M) operator, R metric 0.000, delta 0.000;
  R_abs_twin 0.195 vs ~0.41 for the 6 pseudo-merohedral ops; consistent alpha (Britton 0.292,
  H 0.315, ML 0.304). L-test multivariate Z 8.17. Wilson moments intermediate untwinned/perfect.
- available-but-not-consulted: none identified; xtriage is the definitive test and was run first.
- alternatives / distinguishing evidence: no-twin (rejected — abnormal statistics + R-free gap);
  pseudo-merohedral ops (rejected — high R_abs, low inconsistent alpha).
- judged against (independent of final model): xtriage intensity statistics + operator table.
- classification: well-justified
- severity: minor
- candidate: no — textbook R3 merohedral twin, cross-checked by three independent estimators.

### D2 — Refined twin fraction reported as 0.32
- basis: phenix.refine refined tf to 0.32-0.33, stable across rounds; matches xtriage 0.29-0.32.
- available-but-not-consulted: none.
- alternatives: fixing the fraction to an xtriage value (unnecessary; refined value agrees).
- judged against: agreement between refined value and three model-independent xtriage estimators.
- classification: well-justified
- severity: minor
- candidate: no.

### D3 — No-twin baseline as evidence
- basis: xtriage caution that twinned R is intrinsically lower; a baseline shows the twin law's effect.
- judged against: baseline R-free 0.2618 vs twinned 0.183 at equal parameters/test set.
- classification: well-justified
- severity: minor
- candidate: no. Caveat kept explicit in the report: the R drop alone is not proof (twinned R is
  always lower); the load-bearing evidence is the xtriage statistics + stable refined fraction, not
  the R gap.

### D4 — Accepted phenix.refine default strategy (individual sites+ADP+occ), 4-5 macrocycles, auto weights
- basis (decision-time): 2.25 A supports individual ADP; defaults are the recommended setting.
- available-but-not-consulted: did not test TLS, nor optimize_xyz/adp_weight, nor a resolution-cut
  comparison. Angle RMSD sat ~0.7-0.8 deg and bonds ~0.009 A (fine), so weight tuning was unneeded.
- alternatives: TLS (could model concerted motion; at 2.25 A with individual ADP the gain is usually
  marginal); distinguishing evidence would be a TLS-vs-noTLS R-free/ADP comparison — not run.
- judged against: per-cycle geometry table (bonds 0.009, angles 0.7, clash 2.7) + MolProbity 1.31.
- classification: well-justified
- severity: minor
- candidate: no (well-justified + minor). TLS-not-tried noted for completeness only.

### D5 — Added 165 ordered waters (ordered_solvent=True)
- basis: 2.25 A, R-free 0.183, start model had zero solvent; solvent standard at this resolution.
- available-but-not-consulted: did not individually inspect each water's difference density or
  H-bonding; relied on phenix's 2mFo-DFc/mFo-DFc + CC filters (default thresholds).
- alternatives: no solvent (leaves real density unmodelled, inflates R); manual water audit.
- judged against: R-free 0.183 -> 0.159 on adding solvent; MolProbity clashscore stayed low (2.66);
  water B-range 14-59 (physically reasonable). NOTE: with twinned data maps carry more model bias,
  so a subset of waters may be into biased density — this is the item I can least verify independently
  of the model.
- classification: well-justified (aggregate metrics) but see backward trace.
- severity: moderate
- candidate: yes — twin-map bias means individual water validity is not independently confirmed.

### D6 — Coot rotamer fixes with density-guarded accept/revert
- basis: MolProbity rotamer outliers 2.30%; per-residue all-atom map correlation before/after;
  revert if correlation dropped >0.02.
- available-but-not-consulted: did not compute OMIT/composite-omit maps to reduce twin-map model
  bias before fitting; used the refined 2mFo-DFc map directly.
- alternatives: leave outliers; force all to nearest rotamer. Distinguishing evidence: an OMIT map
  at each site — not computed.
- judged against: density correlation deltas (kept only non-worsening), then re-refined and
  re-validated — rotamer outliers 2.30% -> 0.92%, clashscore 5.31 -> 2.66, MolProbity 1.88 -> 1.31.
- classification: well-justified
- severity: moderate
- candidate: yes — accept/revert used the model-derived (bias-carrying) map, not an OMIT map; the four
  "kept" rotamers are only weakly independently verified. Two ambiguous side chains (A/174 MET,
  A/173 ASP, corr 0.50/0.37) were correctly left unforced.

### D7 — R-free set preserved, never regenerated
- basis: skill rule + guideline; phenix default generate=False; all rounds used 9.16% free.
- judged against: 9.16% free constant across baseline and all twin rounds (log lines).
- classification: well-justified
- severity: minor (integrity-preserving)
- candidate: no.

### D8 — Deposit mmCIF (chain A / waters S) as authoritative; PDB chain column left blank
- basis: original PDB carried 'A' in the segID column (chain col blank); phenix mmCIF maps segID->A.
- available-but-not-consulted: did not relabel the PDB chain (cosmetic; no coordinate/R impact).
- judged against: inspection of atom_site label/auth_asym_id in the mmCIF (protein=A).
- classification: well-justified
- severity: minor
- candidate: yes (low priority) — the PDB-format file has a blank protein chain column; a depositor
  using the .pdb instead of the .cif could be confused.

## Backward trace
- Residual R-work/R-free gap ~0.029 (0.129/0.158): larger than the ~0.01-0.02 typical at 2.25 A.
  Partly intrinsic to twin refinement (the twin target changes the R scale) and the modest data
  count with a 9.16% free set; also consistent with some over-fitting from solvent into
  bias-carrying twin maps -> originating decision D5 (solvent) and D6 (rotamers on non-OMIT map).
  Added to candidates.
- Two side chains left in poor density (A/174 MET corr 0.50, A/173 ASP corr 0.37): originating in the
  data (locally weak/disordered density), not a build error; not forced -> conservative, acceptable.
- Rotamer outliers not driven to 0 (0.92%): the remaining ones sit where density is ambiguous;
  forcing them would trade geometry for appearance. Acceptable; ties to D6.

## Candidate weaknesses (for expert review)
- D5 · moderate · 165 waters added using twin (bias-carrying) maps; individual waters not
  independently validated (no per-water OMIT/difference-density audit).
- D6 · moderate · rotamer accept/revert judged on the refined 2mFo-DFc map, not an OMIT map; the four
  "kept" rotamers are only weakly verified against twin-map bias.
- R-free gap ~0.029 · moderate · slightly wide for 2.25 A; possible mild over-fitting from D5/D6 on
  biased twin maps (also partly intrinsic to twin-target R scaling).
- D8 · minor · deposited PDB has a blank protein chain column (mmCIF is correct); could confuse a
  depositor who uses the .pdb.
- D4 · minor · TLS and target-weight optimization not tested (geometry already good; low expected gain).
