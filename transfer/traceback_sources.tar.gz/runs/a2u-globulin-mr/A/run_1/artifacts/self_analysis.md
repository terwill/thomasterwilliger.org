# Self-analysis — a2u-globulin-mr

## Framing
Self-critique, not independent audit. Candidate weaknesses for expert review, not verdicts.
No causal claims. Decisions judged against data/maps, not against the deposited model.

## Plan divergence
- intended: predict → process → Phaser(4) → refine → Coot rebuild → validate → deposit.
- actual: followed exactly, plus an unplanned extra rebuild+refine cycle (a2u_005) that I then rejected in favor of a2u_004.
- why: a2u_004 still had 0.87% rotamer outliers; I attempted one more Coot+refine pass, but it improved rotamers only at the cost of R-free/clash/Rama, so I reverted the selection to a2u_004.

## Forward walk

### D1 — Generate search model from sequence (AlphaFold), not the MUP homolog in the dir
- basis (decision-time): user restricted inputs to scale.mtz + sequence.dat; mup_search.pdb explicitly excluded.
- available-but-not-consulted: mup_search.pdb (deliberately not used, per instruction).
- alternatives / distinguishing evidence: distant-homolog MR; would be distinguished by TFZ — moot since AF worked.
- judged against (independent of final model): Phaser TFZ 54.5 / LLG 4961 and interpretable 2mFo-DFc density → model is correct independent of its origin.
- classification: well-justified
- severity: minor
- candidate: no — instruction-mandated and cross-validated by MR signal.

### D2 — 4 copies in ASU (Matthews)
- basis: mmtbx.matthews P(4)=0.50, P(3)=0.29.
- available-but-not-consulted: none needed (Phaser settled it).
- alternatives: 3 copies; distinguished by Phaser copy count / packing / R-free with the 4th copy.
- judged against: Phaser placed 4 copies all with high TFZ (20.6–54.5) and no packing rejections → 4 is correct, not just probable.
- classification: well-justified
- severity: minor
- candidate: no.

### D3 — Accept space group P2₁2₁2₁ as given
- basis: xtriage absences consistent; no twinning; no tNCS. P2₁2₁2₁ is self-enantiomorphic so no hand ambiguity.
- available-but-not-consulted: none.
- judged against: systematic-absence scores + successful MR in this SG.
- classification: well-justified; severity: minor; candidate: no.

### D4 — Generate R-free set fresh and freeze it (no column supplied)
- basis: input MTZ had no test-set column; a2u_data.mtz (from round-1 refine) holds FOBS + R-free; reused thereafter.
- available-but-not-consulted: none (there was no pre-existing/deposited free set to match — a real limitation for cross-project comparability, but unavoidable given inputs).
- alternatives: none valid; regenerating each round would invalidate R-free.
- judged against: confirmed R-free-flags column persisted in a2u_data.mtz; used same file every round.
- classification: well-justified; severity: moderate (a freshly generated free set means R-free is internally valid but not tied to any external standard); candidate: **yes** — worth an expert noting that the free set is self-generated (7.2%), with possible model/test-set memory from the AF model being similar across all reflections.

### D5 — TLS (one group per chain) + ordered solvent from round 2 on
- basis: 4 chains, 2.38 Å, moderate B-variation; TLS is standard here.
- available-but-not-consulted: TLSMD-style group search (used naive one-group-per-chain instead).
- alternatives: no TLS; per-domain TLS. Distinguished by R-free.
- judged against: R-free improved and geometry stayed tight (bonds 0.003) → TLS choice not harmful.
- classification: well-justified; severity: minor; candidate: no.

### D6 — Coot rebuild: fixed rotamer outliers; kept TYR116 positive-φ
- basis: rotalyze/ramalyze outlier lists; NCS consensus (all 4 copies share TYR116 positive-φ); local refine vs 2mFo-DFc does not move it.
- available-but-not-consulted: an explicit OMIT/polder map at TYR116 to independently confirm the positive-φ backbone (I relied on the refined 2mFo-DFc + NCS agreement, not a bias-reduced map).
- alternatives: force TYR116 into favored region — would contradict density and the other 3 copies.
- judged against: density holds it (unchanged by local refine) and 3/4 copies agree → real, not misbuild.
- classification: well-justified; severity: minor; candidate: **yes (low)** — the positive-φ call rests on the refined map + NCS, not a bias-reduced OMIT map; cheap to verify and worth an expert glance.

### D7 — Gentle optimize-weights over default auto-weight
- basis: default-weight run (a2u_003) gave MolProbity 1.93 / 2.62% rotamers for ~0.002 lower R-free; gentle run (a2u_004) gave 1.31 / 0.87%.
- judged against: side-by-side molprobity + rotalyze on a2u_003 vs a2u_004 (independent of R alone).
- classification: well-justified; severity: moderate (weight choice materially affects geometry); candidate: no.

### D8 — Final model = a2u_004 (not a2u_005)
- basis: a2u_004 better on R-free (0.2429 vs 0.2446), MolProbity (1.31), clashscore (3.95 vs 4.34), Rama (0.00% vs 0.16%); a2u_005 only better on rotamers.
- judged against: full validation of both; R-free from the frozen test set.
- classification: well-justified; severity: moderate; candidate: **yes (low)** — reasonable people might prefer a2u_005’s lower rotamer count; the two are close and an expert could legitimately pick differently.

## Backward trace
- **Residual 0.87% rotamer outliers (6) in the final model** → originating decisions D7/D8 (weight choice + model selection) and the intrinsic refine↔rebuild ping-pong. Density-driven; not a register error. Candidate: yes (low).
- **R-free/R-work gap ~0.04 and modest overall completeness (88.9%, outer shell 22.8%)** → data limitation, not a decision; noted so it isn’t mistaken for overfitting. Not a candidate.
- **Self-generated 7.2% R-free set** → D4. The AF search model is globally similar to the true structure, so there is no independent guard against subtle model-bias in the test set beyond the standard held-out flags. Candidate: yes.
- **No ions/ligands examined** → I did not mine mFo-DFc for ordered ions (a2u globulin is a lipocalin that can bind small hydrophobic ligands; none were required by the task, but difference density was not audited for them). Candidate: yes (low) — an expert may want to check the barrel cavity for unmodeled density.

## Candidate weaknesses (for expert review)
- D4 · moderate · R-free set is self-generated (7.2%); no external/standard free set exists for this data, and the AF-similar model offers no independent bias guard.
- D8 · moderate · Final = a2u_004 vs a2u_005 is a close call; a2u_005 has fewer rotamer outliers.
- BackTrace/ligands · low · mFo-DFc not audited for ions or a cavity-bound ligand in the lipocalin barrel.
- D6 · low · TYR116 positive-φ accepted on refined-map + NCS evidence, not a bias-reduced OMIT map.
- BackTrace/rotamers · low · 0.87% rotamer outliers remain (density-driven; within acceptable at 2.38 Å).
