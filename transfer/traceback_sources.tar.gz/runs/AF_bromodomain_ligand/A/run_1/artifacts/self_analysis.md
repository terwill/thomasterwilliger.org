# Self-analysis — AF_bromodomain_ligand (7QZ0, BAZ2A bromodomain + GQX)

## Framing
Self-critique, not independent audit. Candidate weaknesses for expert review, not verdicts.
No causal claims. Decisions judged against data/maps, not against the deposited model I produced.

## Plan divergence
- intended: predict_and_build (AF→MR→build→refine) → ligandfit → refine → Coot → validate → DEPOSIT.
- actual: matched the plan. Extra unplanned steps: (a) one bare-protein `phenix.refine` before ligand fitting
  to get a clean Fo-Fc; (b) three failed restraint-generation attempts (eLBOW from coords, eLBOW
  --chemical_component --opt) before falling back to the curated geostd GQX.cif; (c) two arg-parse
  retries on predict_and_build (`data=`/`nproc=` ambiguous → `input_files.xray_data_file=`/`control.nproc=`).
- why: eLBOW could not perceive bonding from coordinates and its --opt step produced a spurious bond;
  geostd already had a curated restraint, which is strictly better.

## Forward walk

### D1 — Accept data as-is at 2.10 Å (no resolution cut)
- basis (decision-time): xtriage — completeness 99.1%, ⟨I/σ⟩=22.0, outer shell strong.
- available-but-not-consulted: per-shell CC½ (single merged MTZ; not separately tabulated here).
- alternatives: cut to ~2.2 Å — no motivation given strong outer data.
- judged against: xtriage completeness/I-sigma tables (independent of model). Clean.
- classification: well-justified · severity: minor · candidate: no.

### D2 — Search 1 copy in ASU
- basis: xtriage Matthews "best guess 1 copy".
- alternatives: 2 copies (lower probability). Distinguishing evidence: MR would fail/partial for wrong N.
- judged against: Phaser found exactly one strong solution (LLG 1188), no room/signal for a 2nd → confirms 1.
- classification: well-justified · minor · candidate: no.

### D3 — Space group hand (P3₁2₁ vs P3₂2₁)
- basis: point group P321 leaves screw-axis hand ambiguous; let Phaser decide.
- alternatives: trust MTZ label blindly.
- judged against (independent): predict_and_build ran Phaser with `space_group_alternatives=HAND`;
  single solution in P3₁2₁, LLG 1188. Enantiomorph tested and not selected.
- classification: well-justified · moderate (would be critical if mis-set) · candidate: no.

### D4 — Reuse predict_and_build-generated FreeR set, frozen thereafter
- basis: input MTZ had no FreeR column; pipeline made one.
- available-but-not-consulted: none — required behavior.
- judged against: every subsequent refine read the same R-free-flags column (verified in mtz dumps);
  never regenerated. Cross-validation integrity preserved.
- classification: well-justified · minor · candidate: no.

### D5 — Accept the predict_and_build model as protein starting point
- basis: MR LLG 1188 decisive; build gave R/Rfree 0.26/0.29; 100/104 residues placed.
- alternatives: manual Phaser + autobuild. Distinguishing evidence: none needed — automated result clean.
- judged against: MolProbity later 100% Rama favored, 0 outliers → backbone geometry sound.
- classification: well-justified · minor · candidate: no.

### D6 — One bare-protein phenix.refine before ligand fitting; R-free rose 0.287→0.314
- basis (decision-time): wanted a clean protein-phased Fo-Fc for ligand fitting; no solvent so ligand blob stays visible.
- available-but-not-consulted: I did not first check whether the predict_and_build map coeffs were already adequate for ligandfit (they were).
- alternatives: fit ligand directly into predict_and_build's Fo-Fc without this extra refine.
- judged against: the R-free rise was reversed once the real ligand+waters were added (0.293→0.259→0.257);
  the rise reflected an incomplete model + default individual-ADP, not a modeling error I carried forward.
- classification: got-lucky/weakly-justified (harmless, but the extra refine was not strictly needed and briefly
  worsened R-free) · moderate · candidate: yes — was the default target weight appropriate on the incomplete model?

### D7 — GQX restraints from curated geostd data_GQX.cif
- basis: eLBOW bond perception failed from coords; eLBOW --chemical_component --opt hit a spurious 4.58 Å bond;
  geostd cif has correct SMILES matching the ligand and sane geometry.
- available-but-not-consulted: I inspected geostd bonds/angles briefly but did not diff its ideal geometry
  against the CCD atom-by-atom.
- judged against (independent): validate_ligands geometry rmsZ bonds 0.31 / angles 0.37 / dihedral 0.71, 0 outliers.
- classification: well-justified · minor · candidate: no.

### D8 — Place GQX by ligandfit into Fo-Fc rather than copying deposited coordinates
- basis: MR applied an origin shift (log: "Shifted Chain A by 94.627,0,33.008"); deposited ligand coords are in a
  different frame. Fit into density is frame-independent.
- judged against: fitted pose ~(55,38,12) vs deposited ~(−40,43,−3) — confirms frames differ; 5/5 ligandfit poses
  converged (CC 0.72–0.78), final RSCC 0.87. Independent of the deposited file.
- classification: well-justified · major (copying coords would have mis-placed the ligand) · candidate: no.

### D9 — Model ONE GQX copy (deposited file has two)
- basis (decision-time): post-refine mFo-DFc peak search — max 6.84σ, all peaks water-sized and next to
  existing atoms; no ligand-shaped cluster for a 2nd site.
- available-but-not-consulted: I did not run a polder/OMIT map specifically at the deposited 2nd-copy location
  (I worked in my own frame and did not transform the deposited 2nd copy in to test its density).
- alternatives: add 2nd GQX at high B. Distinguishing evidence: a polder map at the putative 2nd site.
- judged against (independent of my model): difference-map peak heights and the absence of a ligand-sized blob.
- classification: well-justified on available maps · moderate · candidate: yes — a targeted polder at the
  symmetry-mapped 2nd-copy position would make the "absent" call airtight.

### D10 — Do NOT model the Mg ion (deposited entry has one)
- basis: no octahedral water cluster / short (≈2.1 Å) coordination peak in mFo-DFc; residual peaks 5–6.8σ sit on
  side chains/waters; deposited Mg–O LINK is 2.48 Å (long/loose).
- available-but-not-consulted: I did not run phenix.refine `ordered_solvent` with elemental-ion picking enabled to
  let Phenix propose Mg, nor check coordination geometry of the two waters nearest the strongest peak.
- alternatives: place Mg and test with the anomalous-free coordination + B/occupancy behavior.
- judged against: difference-peak geometry (independent of model).
- classification: weakly-justified · moderate · candidate: yes — explicitly the weakest evidence-based call in the run.

### D11 — Keep Arg56/Arg100 in density-supported but low-probability rotamers
- basis: auto_fit chose best-density rotamer; still flagged 0% by library, but CC good.
- judged against: final MolProbity rotamer outliers 0% (phenix post-min rotamer correction resolved them) and
  side-chain CC improved (Arg56 0.43→ok). Density-supported.
- classification: well-justified · minor · candidate: no.

### D12 — Stop refinement at R-free 0.257 rather than pushing lower
- basis: geometry pristine (MolProbity 1.03); further weight-pushing risks overfitting an AF-derived model.
- available-but-not-consulted: TLS groups; a resolution-dependent wxc_scale scan; adding riding H.
- alternatives: TLS + H could shave R-free a little.
- judged against: R-Rfree gap 5.3% is normal for 2.1 Å; no pathology.
- classification: well-justified · minor-moderate · candidate: yes (low priority) — TLS/H were not tried.

## Backward trace
- **R-free 0.257 higher than typical for 2.1 Å** → D5 (AF-derived model with genuine surface flexibility),
  D12 (no TLS/H, no weight scan). Not obviously a build error; MolProbity is excellent. Add D12 to candidates.
- **Guanidine tail of GQX weak (RSCC 0.58)** → intrinsic ligand mobility, consistent with high B. Not traceable to a
  decision; would not improve by rebuilding. Note only.
- **Mg absent vs deposited** → D10. Weakest evidence call; flagged.
- **2nd GQX absent vs deposited** → D9. Defensible on peak heights; a polder at the mapped site would close it.

## Candidate weaknesses (for expert review)
- D10 · moderate · Mg omitted on difference-peak geometry alone; never let Phenix ion-picking or coordination
  geometry weigh in.
- D9 · moderate · single GQX copy; "absent 2nd copy" not confirmed with a targeted polder/OMIT at the
  symmetry-mapped deposited position.
- D6 · moderate · extra bare-protein refine transiently raised R-free (0.287→0.314) with default weights on an
  incomplete model; not strictly necessary.
- D12 · minor-moderate · refinement stopped at R-free 0.257 without trying TLS, riding H, or a target-weight scan.
