# Self-analysis — beta-blip (beta-lactamase / BLIP complex)

## Framing
Self-critique, not independent audit. Candidate weaknesses for expert review, not verdicts.
No causal claims. Decisions judged against data/maps and cross-validation, not against the
deposited model. The final model is partly a product of these decisions and cannot be its own
justification.

## Plan divergence
- intended: xtriage → Phaser → refine → Coot rebuild → validate → DEPOSIT (single refine +
  single Coot pass implied).
- actual: same skeleton, but refinement took **6 rounds** plus **two Coot passes** because the
  first Coot pass (aggressive per-residue local refinement) distorted the backbone (Rama favored
  95.5%→90.6%, outliers 0.24%→1.89%). I diagnosed this, reverted strategy, and used a
  gentler side-chain-only Coot pass instead.
- why: I did not anticipate that refining 3-residue windows in Coot would strain phi/psi. Once
  seen in the validation numbers, I isolated protocol from rebuild and corrected.

## Forward walk

### D1 — Include BLIP (blip.pdb + blip.seq) though prompt named only beta.seq
- basis (decision-time): README states ASU = 1 BETA + 1 BLIP, BETA = 62% of cell; Matthews on
  beta-only gave 1 copy. Complex cannot be solved without BLIP.
- available-but-not-consulted: none.
- alternatives / distinguishing evidence: beta-only search — would leave ~38% cell unmodeled and
  misstate solvent content; Phaser LLG/TFZ would be far weaker.
- judged against: Phaser log — SINGLE solution, BLIP TFZ=30.2, LLG=1053, clean packing;
  independent of the final refined model.
- classification: well-justified
- severity: minor (deviates from literal prompt but scientifically necessary)
- candidate: no — well-justified; but flagged for reviewer awareness since it deviates from the
  literal file list.

### D2 — Ensemble identity = 1.0 for both search models
- basis: beta.pdb/blip.pdb are the actual component proteins (different crystal form), essentially
  identical sequence.
- available-but-not-consulted: exact sequence identity of the PDB search models vs beta.seq/blip.seq
  (did not align them explicitly).
- alternatives: let Phaser estimate from RMSD; use sculptor to trim. Distinguishing evidence:
  VRMS Phaser reported (beta 0.62, blip 1.04) — reasonable, so identity=1.0 did not hurt the search.
- judged against: Phaser VRMS/TFZ in log — strong solution.
- classification: well-justified
- severity: minor
- candidate: no.

### D3 — Generate fresh 10% R-free set, freeze it
- basis: mtz.dump showed no free-R column; 8830 reflections → 10% ≈ 881 test reflections.
- available-but-not-consulted: none.
- alternatives: 5% (too few test reflections at 3.0 Å). 
- judged against: consistent 9.98–9.99% free fraction and identical n_refl across all 6 rounds
  (log) — cross-validation integrity preserved.
- classification: well-justified
- severity: minor
- candidate: no.

### D4 — Refinement strategy: group ADP + 2 TLS groups (chain A/B) at 3.0 Å
- basis: 3.0 Å is too low for individual ADP; skill guidance = group_adp + TLS at >3 Å.
- available-but-not-consulted: TLSMD-style optimal TLS group partitioning (I used one group per
  chain, the simplest reasonable choice).
- alternatives: individual ADP (too many params: ~4 params/atom vs 8830 obs); more TLS groups.
- judged against: bond/angle RMSD converged to ideal (0.009/1.11), B-factor distribution
  physically reasonable — independent of R-free.
- classification: well-justified
- severity: minor
- candidate: no.

### D5 — First Coot rebuild pass: per-residue auto-fit + local (3-residue) real-space refine
- basis (decision-time): 9.6% rotamer outliers after refine1; coot-model-building skill recommends
  refining neighbours for context.
- available-but-not-consulted: I could have checked Ramachandran BEFORE committing the whole sweep
  (I checked rotamers only mid-sweep).
- alternatives: side-chain-only auto-fit (what I eventually used). Distinguishing evidence:
  post-pass Ramachandran (favored dropped 95.5→90.6%, outliers 0.24→1.89%) — visible in refine2
  validation.
- judged against: MolProbity/refine validation of refine2 vs refine1 — Rama regressed; this is a
  real degradation seen in the numbers, not the model-as-its-own-evidence.
- classification: weakly-justified (defensible method, but the 3-residue window strained backbone)
- severity: moderate (recoverable — I did recover with D7)
- candidate: yes — over-aggressive local refinement perturbed backbone; a reviewer should confirm
  the final backbone is not carrying residual strain from this.

### D6 — Added Ramachandran + secondary-structure restraints (refine3/4/6)
- basis: recover the Rama regression from D5.
- available-but-not-consulted: none.
- alternatives: simulated annealing to escape MR/rebuild bias (not tried — see backward trace).
- judged against: Rama outliers fell (1.89→0.47→0.00%); R-free essentially flat — independent check.
- classification: well-justified
- severity: minor
- candidate: no.

### D7 — Second Coot pass: side-chain-ONLY auto-fit (no backbone), then final refine with local RSR
- basis: rotamer outliers still high; side-chain-only motion cannot harm phi/psi.
- available-but-not-consulted: none.
- alternatives: phenix.refine rotamer_restraints; autobuild.
- judged against: MolProbity of refine6 (rotamer 0.29%, Rama 0 outliers, score 2.10) vs refine2/4
  (2.82/2.85) — a genuine, tool-consistent improvement, and the map (2mFo-DFc) was the fitting target.
- classification: well-justified
- severity: minor
- candidate: no.

### D8 — Final model selection = refine6 over lower-R-free refine2
- basis (decision-time): apples-to-apples MolProbity: refine6 score 2.10 vs refine2 2.82; R-free
  0.3141 vs 0.3067 (+0.007, within noise for 881 test reflections).
- available-but-not-consulted: paired-model R-free significance test (Hamilton) was not run;
  I argued "within noise" qualitatively.
- alternatives: pick refine2 for lowest R-free. Distinguishing evidence: MolProbity composite +
  rotamer outliers strongly favor refine6; guideline says do not chase marginal R-free at the cost
  of geometry.
- judged against: independent MolProbity runs on both models (consistent tool), not the model itself.
- classification: well-justified
- severity: moderate (a real fork; both preserved)
- candidate: yes — the R-free vs MolProbity trade is a legitimate judgement call a reviewer should
  confirm; both models preserved in DEPOSIT to avoid silently committing.

## Backward trace
- **R-free stuck at ~0.31 (higher than ideal for 3.0 Å)** → originating decisions: no deep rebuild
  (autobuild/loop fitting) was ever run (D5/D7 only touched rotamers), and search models were used
  untrimmed (D2). Candidate: the residual is plausibly real model error in weak-density loops/long
  side chains that a targeted rebuild — not more refinement — would address.
- **Ramachandran favored capped ~91–93% (not >95%)** → originating decision D5 (backbone strain
  from aggressive local refinement). Even after D6 restraints, favored did not return to the
  refine1 value. Candidate: reviewer should check whether the final backbone is optimal or carries
  residual D5 strain. NOTE: the refine1 "95.5% favored" coexisted with bond RMSD 0.026 and Cβ 13.4%,
  i.e. loosely-restrained geometry, so it is not a clean gold standard either.
- **Clashscore ~12 (not <10)** → the side-chain rotamer fits (D7) trade against packing at 3.0 Å;
  final round with local RSR settled it to 12 but not below. Minor.

## Candidate weaknesses (for expert review)
- D5 · moderate · First Coot pass used 3-residue local refinement that strained the backbone
  (Rama favored 95.5→90.6%); recovered later but final favored (~91.5%) may still reflect it.
- D8 · moderate · Final selection favored MolProbity (2.10) over 0.007-lower R-free (refine2);
  "within noise" asserted, not tested with a paired-significance check. Both models preserved.
- D1 · minor · Deviated from the literal prompt file list (added BLIP) — scientifically required,
  but flagged because it changes inputs.
- Backward-trace · major-if-confirmed · R-free ~0.31 was never reduced by real rebuilding
  (autobuild/loop fitting not run); whether the fold/register in weak-density regions is fully
  correct is not independently established beyond the strong MR signal + map fit.
