# Table 1 - per-run summary

_Numbers are **as reported by each run's own tools** unless marked independent. Every value carries a source marker (legend below), because validators disagree - a recurring finding of this project. Rows are not comparable across cases (different resolutions, methods, data types): this is a per-run report card, not a leaderboard. **Caveat:** a "discrepancy" below is only a true tool disagreement if both numbers describe the SAME model; control/intermediate refinements are excluded by name, but verify the sources before citing one._

| metric | AF_7mjs_H_PredictAndBuild | AF_bromodomain_ligand | CASP7-T0283-mr | a2u-globulin-mr | beta-blip | esterase_tNCS | gene-5-mad | nsf-d2-ligand | p9-sad | porin-twin | refined_start |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Resolution | 2.9 ^a | 2.1 ^b | — | 2.38 ^b | 3 ^b | 1.6 ^b | 21.33 – 2.59 Å ^c | 1.9 ^c | 1.74 ^b | 2.25 ^b | 2.59 ^d |
| Space group | — | — | — | — | — | ANALYSIS ^e | C 1 2 1 ^c | P 6 ^c | identification---------- ^f | identification---------- ^g | — |
| R-work (run-declared) | — | — | — | 0.2037 ^h | 0.2318 ^i | — | 0.1366 ^c | 0.1963 ^c | 0.231 ^j | 0.1288 ^k | 0.2036 ^l |
| R-free (run-declared) | — | — | — | 0.243 ^h | 0.3137 ^i | — | 0.218 ^c | 0.2282 ^c | 0.2462 ^j | 0.158 ^k | 0.2417 ^l |
| R-work (refine log) | — | 0.2045 ^m | — | 0.2037 ^h | 0.2318 ^i | 0.1833 ^n | 0.1364 ^o | 0.1963 ^p | 0.231 ^j | 0.1288 ^k | 0.2036 ^l |
| R-free (refine log) | — | 0.2555 ^m | — | 0.243 ^h | 0.3137 ^i | 0.2112 ^n | 0.2179 ^o | 0.2282 ^p | 0.2462 ^j | 0.158 ^k | 0.2417 ^l |
| R-work (MolProbity) | — | 0.2045 ^b | — | 0.1846 ^b | 0.2371 ^b | 0.1716 ^b | 0.1366 ^b | 0.1963 ^b | 0.231 ^b | 0.2286 ^b | 0.1553 ^d |
| R-free (MolProbity) | — | 0.2573 ^b | — | 0.2425 ^b | 0.3094 ^b | 0.205 ^b | 0.218 ^b | 0.2282 ^b | 0.2462 ^b | 0.2489 ^b | 0.2475 ^d |
| R-free (recomputed, independent) | — | — | 0.5574 ^q | — | — | 0.2068 ^q | — | — | — | — | 0.2417 ^q |
| R-free (deposited) | — | 0.204 ^q | 0.238 ^q | — | 0.205 ^q | 0.188 ^q | 0.2 ^q | 0.244 ^q | 0.236 ^q | — | — |
| MolProbity score | 1.78 ^b | 1.03 ^b | — | 1.93 ^b | 2.85 ^b | 1.6 ^b | 1.82 ^c | 0.95 ^c | 1.25 ^b | 1.88 ^b | 1.95 ^d |
| Clashscore | 8.07 ^b | 2.44 ^b | — | 6.65 ^b | 11.91 ^b | 6.81 ^b | 3.05 ^b | 1.82 ^b | 4.81 ^b | 5.31 ^b | 6.79 ^d |
| Ramachandran favored % | 99.22 ^b | 100 ^b | — | 96.38 ^b | 93.4 ^b | 96.54 ^b | 97.56 ^b | 97.96 ^b | 99.11 ^b | 95.47 ^b | 96.34 ^d |
| Ramachandran outliers % | 0.78 ^b | 0 ^b | — | 0.16 ^b | 0 ^b | 0.8 ^b | 0 ^b | 0 ^b | 0 ^b | 0.35 ^b | 0 ^d |
| Rotamer outliers % (MolProbity) | 2.83 ^b | 0 ^b | — | 2.62 ^b | 12.24 ^b | 0.68 ^b | 6.76 ^b | 0 ^b | 0 ^b | 2.3 ^b | 2.74 ^d |
| Rotamer outliers % (refine log) | 3.77 ^r | 2.25 ^m | — | 0 ^h | 6.71 ^i | 0.68 ^n | 6.76 ^o | 0.46 ^p | 0 ^j | 1.84 ^k | 5.48 ^l |
| C-beta deviations (count, MolProbity) | 0 ^b | 0 ^b | — | 0 ^b | 0 ^b | 0 ^b | 0 ^b | 0 ^b | 0 ^b | 0 ^b | 0 ^d |
| C-beta deviations (%, refine log) | 0 ^r | 0 ^m | — | 0 ^h | 0 ^i | 0 ^n | 1.3 ^o | 0 ^p | 0 ^j | 0 ^k | 0 ^l |
| RMS bonds | 0.0024 ^b | 0.0069 ^b | — | 0.0088 ^b | 0.0094 ^b | 0.0184 ^b | 0.0105 ^b | 0.0085 ^b | 0.0074 ^b | 0.0087 ^b | 0.0079 ^d |
| RMS angles | 0.5 ^b | 0.82 ^b | — | 0.96 ^b | 1.14 ^b | 1.58 ^b | 1.18 ^b | 0.95 ^b | 1.04 ^b | 0.81 ^b | 0.95 ^d |
| FOM (after DM) | — | — | — | — | — | — | 0.73 ^c | — | 0.72 ^f | — | — |
| Map-model CC_mask | 0.847 ^r | — | — | — | — | — | 0.813 ^c | — | — | — | — |
| Twin fraction | — | — | — | — | — | — | — | 0.04 ^s | 0.03 ^f | 0.32 ^a | — |
| Science grade (vs deposited) | no-reference ^q | major ^q | critical ^q | no-reference ^q | major ^q | none ^q | none ^q | none ^q | major ^q | no-reference ^q | none ^q |
| CA-RMSD vs deposited (A) | — | 0.14 ^q | 15.83 ^q | — | 0.33 ^q | 0.1 ^q | 0.19 ^q | 0.11 ^q | 0.25 ^q | — | 0.21 ^q |
| Matched fraction | — | 0.93 ^q | 0.03 ^q | — | 0.94 ^q | 0.97 ^q | 0.94 ^q | 1 ^q | 0.82 ^q | — | 0.94 ^q |
| Coverage | — | 0 ^q | 0 ^q | — | 0.501 ^q | 0.99 ^q | 0.977 ^q | 1 ^q | 0.824 ^q | — | 0.977 ^q |

**Sources:** ^a self_analysis · ^b molprobity.out · ^c DEPOSIT · ^d molprobity.log · ^e refine-log:DEPOSIT/MR_phaser.log · ^f refine-log:DEPOSIT/autosol.log · ^g refine-log:DEPOSIT/xtriage.log · ^h refine-log:DEPOSIT/a2u_globulin_final_refine.log · ^i refine-log:DEPOSIT/beta_blip_final_refine.log · ^j refine-log:DEPOSIT/molprobity.log · ^k refine-log:DEPOSIT/refine_final.log · ^l refine-log:refine_25d1e773/final_deposit_001.log · ^m refine-log:refine_23102cb5/final_001.log · ^n refine-log:refine_c8bd3dd4/esterase_final_001.log · ^o refine-log:logs/04_final_refine.log · ^p refine-log:logs/refine_final.log · ^q scores.json · ^r refine-log:validation/real_space_refine_primary.log · ^s refine-log:logs/xtriage.log

## Tool-vs-tool discrepancies (the Class-3 diagnostic)

- **AF_7mjs_H_PredictAndBuild**
  - rotamer outliers %: 3.77 (refine-log:validation/real_space_refine_primary.log) vs 2.83 (molprobity.out)
- **AF_bromodomain_ligand**
  - rotamer outliers %: 2.25 (refine-log:refine_23102cb5/final_001.log) vs 0 (molprobity.out)
- **a2u-globulin-mr**
  - R-work: 0.2037 (refine-log:DEPOSIT/a2u_globulin_final_refine.log) vs 0.1846 (molprobity.out)
  - rotamer outliers %: 0 (refine-log:DEPOSIT/a2u_globulin_final_refine.log) vs 2.62 (molprobity.out)
- **beta-blip**
  - R-work: 0.2318 (refine-log:DEPOSIT/beta_blip_final_refine.log) vs 0.2371 (molprobity.out)
  - rotamer outliers %: 6.71 (refine-log:DEPOSIT/beta_blip_final_refine.log) vs 12.24 (molprobity.out)
- **esterase_tNCS**
  - R-work: 0.1833 (refine-log:refine_c8bd3dd4/esterase_final_001.log) vs 0.1716 (molprobity.out)
  - R-free: 0.2112 (refine-log:refine_c8bd3dd4/esterase_final_001.log) vs 0.205 (molprobity.out)
- **gene-5-mad**
  - C-beta reported in different units - 0 count (molprobity.out) vs 1.3% (refine-log:logs/04_final_refine.log); not directly comparable
- **porin-twin**
  - R-work: 0.1288 (refine-log:DEPOSIT/refine_final.log) vs 0.2286 (molprobity.out)
  - R-free: 0.158 (refine-log:DEPOSIT/refine_final.log) vs 0.2489 (molprobity.out)
  - R-free (run-declared vs MolProbity): 0.158 (refine-log:DEPOSIT/refine_final.log) vs 0.2489 (molprobity.out)
- **refined_start**
  - R-work: 0.2036 (refine-log:refine_25d1e773/final_deposit_001.log) vs 0.1553 (molprobity.log)
  - R-free: 0.2417 (refine-log:refine_25d1e773/final_deposit_001.log) vs 0.2475 (molprobity.log)
  - R-free (run-declared vs MolProbity): 0.2417 (refine-log:refine_25d1e773/final_deposit_001.log) vs 0.2475 (molprobity.log)
  - rotamer outliers %: 5.48 (refine-log:refine_25d1e773/final_deposit_001.log) vs 2.74 (molprobity.log)
