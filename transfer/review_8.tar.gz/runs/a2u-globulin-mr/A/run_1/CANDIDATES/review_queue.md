# Candidate review queue — a2u-globulin-mr (arm A)

3 distinct leads for expert review (ranked by severity, then cross-vantage agreement).

## 1. [moderate] Reject the hard-weight final refinement and redo from Coot-rebuilt model with gentle geometry-preserving weights
- flagged_by: both   ·   2 vantages   ·   triage: keep   ·   Rejecting a hard-weight refinement that pushed 16 side chains into rotamer outliers for a negligible 0.002 R-free gain is a reasonable geometry-first call worth expert confirmation.
- at decision, knew: MolProbity on a2u_003: rotamer outliers 2.62%, MolProbity 1.93, clashscore 6.65; comparison to round-2 MolProbity 1.38
- concern: Hard refinement weight degraded geometry for negligible R-free gain || AUDITOR: TLS refinement was added without any evidence suggesting it was appropriate. Defining one TLS group per chain is a common but often physically questionable choice, especially for a compact globular protein. This can be a form of overfitting, as the 80 new TLS parameters (20 per group) can absorb genuine local disorder, flattening the B-factor landscape and artificially improving R-factors without a corresponding improvement in the model's accuracy.
- alternative: A better approach is to first refine without TLS, then inspect the atomic B-factors for patterns of correlated motion that suggest rigid domains. The `phenix.find_tls_groups` tool can also be used to find data-driven groupings. The decision to use TLS, and the definition of groups, should be justified by the data.
- provenance: #245

## 2. [moderate] Do one final targeted Coot cleanup of the 6 rotamers, then short gentle refine, and keep whichever validates best
- flagged_by: both   ·   2 vantages   ·   triage: keep   ·   The agent claims the 6 outliers are density-driven yet plans to overwrite them with a rotamer-fitting cleanup and select by validation score, which risks fitting geometry over experimental density.
- at decision, knew: MolProbity a2u_004: 1.31, clashscore 3.95, Rama 0.00%, rotamer outliers 0.87% (6 residues)
- concern: Remaining rotamer outliers described as density-driven; hedged that best-validating model will be kept || AUDITOR: The agent's reasoning is contradictory and reflects poor practice. If an outlier conformation is truly supported by electron density, it should be kept. If it is not, it should be fixed. The agent claims the former but does the latter, using an automated tool that ignores the electron density map. This prioritizes achieving a good geometry score over fitting the model to the experimental data, which is the primary goal.
- alternative: The correct procedure is to visually inspect each rotamer outlier in Coot, looking at both the 2mFo-DFc and mFo-DFc maps. If the map density clearly supports the outlier conformation, it should be retained. If the density is weak, ambiguous, or supports the library conformation, then it should be changed manually.
- provenance: #280

## 3. [minor] Did not mine mFo-DFc difference density for ordered ions or a barrel-cavity ligand.
- flagged_by: self_critique   ·   triage: keep   ·   Failing to audit mFo-DFc difference density in the lipocalin barrel cavity risks missing an unmodeled ordered ligand or ion, a routine completeness check regardless of task requirements.
- at decision, knew: a2u globulin is a lipocalin that can bind small hydrophobic ligands; none were required by the task; mFo-DFc difference density was not audited for ordered ions or cavity-bound ligand.
- concern: Difference density in the lipocalin barrel cavity was not audited; unmodeled ordered ions or a cavity-bound ligand could be present and missed.
- alternative: Inspect mFo-DFc for the barrel cavity and ion sites; distinguishing evidence would be positive difference density peaks in the cavity or at plausible ion positions.
- provenance: Backward trace — No ions/ligands examined
