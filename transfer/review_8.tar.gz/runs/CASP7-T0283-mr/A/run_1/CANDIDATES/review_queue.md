# Candidate review queue — CASP7-T0283-mr (arm A)

6 distinct leads for expert review (ranked by severity, then cross-vantage agreement).

## 1. [major] Re-run the quick check with allow_polymer_cross_special_position=True to get an R-free reading.
- flagged_by: both   ·   2 vantages   ·   triage: keep   ·   Relaxing the special-position guard to obtain an R-free reading is a legitimate diagnostic move, but the value of doing so depends entirely on actually reading the resulting R-factors, which the decision does not confirm doing.
- at decision, knew: phenix.refine failed with "Sorry: Polymer crosses special position element".
- concern: A copy sits near a special position / symmetry axis (relaxing the refinement guard). || AUDITOR: The entire purpose of the refinement check was to get a quick R/R-free value to cross-validate the MR solution before starting a long and computationally expensive AutoBuild run. The agent ran the job but then failed to check its output for the key result (the R-factors). It jumped to the next step based on an assumption that AutoBuild would work, completely skipping the confirmation step it had correctly identified as necessary.
- alternative: The correct action would be to parse the log file of the second refinement job (`refine_fa875369`) for the final R-work and R-free values. A significant drop in R-free (e.g., to below 0.50) would provide strong validation for the MR hit. If R-free remained high, it would indicate a problem with the solution.
- provenance: #446

## 2. [moderate] Plan to check once more for advancement, then take control with a consolidating refinement if it hasn't progressed.
- flagged_by: both   ·   2 vantages   ·   triage: keep   ·   The agent plans to wait one more cycle on a demonstrably stalled AutoBuild job (R-free plateaued at 0.41, best model unchanged, ~167 fragmented residues) rather than intervening now, which risks wasting resources on a diagnosed-as-failing automated build.
- at decision, knew: AutoBuild overall_best.pdb unchanged since 17:28, R-free plateaued at 0.41, thrashing on cycle 3; ~167 residues fragmented across chains.
- concern: Automated build not completing efficiently; R-free plateaued and overall_best not advancing. || AUDITOR: When an automated procedure is clearly stalled or 'thrashing', the expert response is to intervene, not to wait passively. The agent correctly diagnosed that the solution was right but the build was failing. Continuing to wait wastes significant time and resources and risks getting a poor result. This is the point to stop the automated job and try a different strategy.
- alternative: An expert would stop the AutoBuild job and intervene. Alternatives include: 1) Taking the current best model (`overall_best.pdb`) and its associated maps into Coot for manual rebuilding to fix the problematic regions. 2) Running a different tool, such as `phenix.morph_model`, on the current best model to try to connect fragments. 3) Starting a new refinement of the current best model with different options (e.g., NCS restraints, secondary structure restraints) to consolidate it before another attempt at building.
- provenance: #519

## 3. [moderate] Let AutoBuild run more cycles rather than intervene.
- flagged_by: self   ·   triage: keep   ·   R-free flat at 0.45 while R-work drops is a classic overfitting/model-bias warning that warrants monitoring, but deferring at cycle 2 is a defensible early-stage choice.
- at decision, knew: AutoBuild cycle 2: R/Rfree = 0.41/0.45, 108 residues built; R-work dropping but R-free flat at 0.45.
- concern: R-free flat at 0.45 — "still marginal."
- alternative: 
- provenance: #471

## 4. [moderate] Set the expected RMSD between the model and the true structure to 1.5 Å (`phaser.model_rmsd = 1.5`).
- flagged_by: transcript_pass   ·   triage: keep   ·   Using an optimistic 1.5 Å RMSD for an ab initio prediction of unverified quality without preprocessing or justification is a plausibly consequential MR parameter choice worth expert review.
- at decision, knew: The input files (MTZ data, sequence file, and a prepped PDB of an *ab initio* CASP prediction model). The agent did not have prior knowledge of the model's accuracy other than the README mentioning it was 'exceptionally good'.
- concern: The choice of expected RMSD is a critical parameter for Phaser. An overly optimistic (low) RMSD can cause the search to fail. For an *ab initio* model of unknown quality, 1.5 Å is a confident, potentially optimistic guess. A more conservative value (e.g., 2.0-2.5 Å) or preprocessing the model to isolate only the highest-confidence core might have been a more robust starting point. The decision was made without explicit justification.
- alternative: An alternative would be to use a larger RMSD value, such as 2.0 Å or 2.5 Å, to allow Phaser a broader search. Another alternative would be to use a tool like `phenix.process_predicted_model` to trim low-confidence regions first. If the MR run had failed, increasing the RMSD would have been a key troubleshooting step.
- provenance: 69 71

## 5. [minor] Abandoned the absolute-threshold trimming; switched to keeping a lowest-spread relative fraction of residues.
- flagged_by: both   ·   2 vantages   ·   triage: keep   ·   Switching from a failed absolute cutoff to relative-spread ranking is sound, but the specific fraction chosen lacks justification and could produce a poorly-sized search model.
- at decision, knew: trim_model3.py output: absolute 2.0 Å threshold across 5 aligned models kept 0 residues; all 112 residues diverge >2 Å.
- concern: The 5 CASP predictions differ globally (different overall conformations), making absolute cutoffs useless. || AUDITOR: The rationale to keep the best-agreeing core is excellent, but the choice of keeping exactly 65% of the residues is arbitrary and presented without justification. This specific percentage could have produced a search model that was too small to yield a signal or still too large to resolve packing issues. A choice based on the distribution of spread values (e.g., using the median spread of ~4.2 Å as a cutoff) would have been more motivated.
- alternative: Alternatives include choosing a cutoff based on the statistics of the spread (e.g., the median value of 4.15 Å), or trying several different percentages (e.g., 50%, 75%) to generate multiple search models. Success would be measured by which model yielded the clearest MR solution.
- provenance: #420

## 6. [unknown] Skip the quick refinement check and go straight to AutoBuild on the MR solution.
- flagged_by: self   ·   triage: ambiguous   ·   triage error: HTTP 529 <none>: {"type":"error","error":{"type":"overloaded_error","message":"Overloaded"},"request_id":"req_011CdJDQved45LLsAB7m7LXu"}
- at decision, knew: Second refine still reports atom at special position; guard trips rigid-body refinement.
- concern: Special-position atom trips refinement guards; relying on AutoBuild to handle it internally instead of an independent R-free confirmation.
- alternative: 
- provenance: #453
