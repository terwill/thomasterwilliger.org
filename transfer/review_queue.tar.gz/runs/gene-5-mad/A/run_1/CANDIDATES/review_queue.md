# Candidate review queue — gene-5-mad (arm A)

17 leads for expert review (ranked by severity, then detector agreement).

## 1. [major] Used `restore_to_backup_checkpoint` for revert logic in Coot as the backtracking mechanism
- flagged_by: self_critique   ·   triage: keep   ·   A tool reporting 4 residues 'FIXED' while writing a byte-identical file indicates a silent failure that would propagate false fixes and wrong outlier counts unless artifacts are verified on disk.
- at decision, knew: Coot skill documentation lists checkpoints as the backtracking mechanism; a rotamer pass reported 4 residues 'FIXED'; the written file was byte-identical to its input, discovered only by diffing coordinates against the input.
- concern: The mechanism silently failed: a whole rotamer pass reported 4 residues 'FIXED' but wrote a file byte-identical to its input. Had the coordinates not been diffed, four nonexistent rotamer fixes would have been reported and the outlier count would have been wrong. More broadly, tool return values wer
- alternative: Verify every tool-reported 'success' against the artifact on disk (diff coordinates after each pass, not only when metrics look suspicious); a diff showing byte-identical output distinguishes a real f
- provenance: D16

## 2. [major] Kept SE Z/2 and assigned it as the Met1 selenium.
- flagged_by: self_critique   ·   triage: keep   ·   Both sequence Met are otherwise accounted for, so a third anomalous peak assigned to Met1 rests on elimination rather than a positive Se test, and an ordered buffer ion cannot be excluded without a recipe or alternative-element test.
- at decision, knew: SE Z/2 had a 5.98 σ anomalous peak; 5.50 Å from Ile2 N; no clashes; both sequence Met otherwise accounted for. No crystallization recipe available. Se is the only anomalous scatterer positively identifiable at this wavelength, but a heavier ion would also scatter anomalously.
- concern: The identity rests on an elimination argument, not a positive test. Without a crystallization recipe a partially-ordered buffer ion cannot be excluded; the Met1 backbone was not built and no alternative element identity was tested. This is the single least-verified claim in the deposited model.
- alternative: Run a polder/OMIT map around the site or examine occupancy-vs-B behaviour for different element assignments; these would discriminate Se from an ion or confirm connectivity to a Met1 backbone.
- provenance: D12

## 3. [major] Initially claimed the 3 free Se atoms were chemically impossible artifacts.
- flagged_by: self_critique   ·   triage: keep   ·   Asserting chemical impossibility from an ASU-only neighbour search without checking symmetry mates or the anomalous substructure is a methodological error that would have deleted a real Se peak.
- at decision, knew: At decision time, all three free Se atoms had no neighbours within 6 Å in the asymmetric unit; Se in a Se-Met crystal exists only covalently in selenomethionine. Crystallographic symmetry was not searched.
- concern: The conclusion came from an ASU-only neighbour search, ignoring crystallographic symmetry mates — the first thing to check for an isolated atom. It was flatly contradicted by the data: `mmtbx.refine_anomalous_substructure` showed Z/4 at 22.45 σ, stronger than the real Met77 Se. Acting on the chemist
- alternative: Run a symmetry-aware neighbour search and an anomalous substructure check before asserting chemical impossibility; the symmetry-aware search immediately overturned the conclusion.
- provenance: D7

## 4. [major] Conclude the Coot fixes never persisted; attribute cause to checkpoint restore
- flagged_by: self   ·   triage: keep   ·   Concluding fixes never persisted and attributing to a molecule-wide checkpoint restore rollback is a plausible but unverified causal claim that would invalidate manual corrections if wrong.
- at decision, knew: rotalyze on coot_edited_v4.pdb showing chi angles identical to input
- concern: restore_to_backup_checkpoint indices not stable across repeated restores — the fixes were rolled back
- alternative: 
- provenance: #337

## 5. [moderate] Treat only 3 sites with occ≥0.5 as likely real; declare hand unambiguous
- flagged_by: both   ·   triage: keep   ·   Two Met predict 2 Se sites but three strong sites were found, an unexplained excess (possibly oxidized Cys or ion) that was rationalized away rather than investigated.
- at decision, knew: AutoSol summary: 6 sites found, occupancies 1.00/0.56/0.52/0.22/0.21/0.14; BAYES-CC 44-48 correct hand vs 14 inverse; sequence has 2 Met + 1 Cys
- concern: Low-occupancy peaks may not be genuine Se sites || AUDITOR: The rationale dismisses the three low-occupancy sites but fails to address the more significant contradiction: the program found *three* sites with occupancy > 0.5, not the two it was told to find. This is a direct contradiction between the
- alternative: Before proceeding with building, inspect the anomalous difference Fourier map in Coot at the locations of all reported sites. This would provide direct visual evidence of whether the peaks are real. T
- provenance: #102

## 6. [moderate] Investigate whether the Coot fixes actually reached the file
- flagged_by: both   ·   triage: keep   ·   Investigating whether Coot fixes reached the file is a reasonable, evidence-driven diagnostic step prompted by suspiciously identical outlier percentages.
- at decision, knew: B-only refinement result identical rotamer outliers 12.16%, R-work 0.1336/R-free 0.2201
- concern: Suspicion that the Coot rotamer fixes were not written to disk || AUDITOR: The decision to refine occupancies and add TLS refinement was not justified by any evidence. Refining occupancies is risky as they are highly correlated with B-factors and can be used to fit noise. Adding a single TLS group f
- alternative: A more conservative approach would be to refine only ADPs (B-factors). Then, analyze the results. If B-factors show clear signs of libration/translation, introduce TLS. If specific atoms show weak den
- provenance: #334

## 7. [moderate] Interpret the 1.30% in the log as the input model's statistic, not the output
- flagged_by: both   ·   triage: keep   ·   The agent's interpretation that the 1.30% log value reflects the input model is plausible but unverified, and the flagged 6.76% rotamer outlier rate is far above the <1% target, indicating premature stopping worth expert review.
- at decision, knew: Targeted refine FIN2_001: R-work 0.1364/R-free 0.2179, cbetadev reports 0 deviations, but log block shows 1.30%
- concern: Discrepancy between the log-reported Cβ value and the direct cbetadev check on the output || AUDITOR: 6.76% is a very high percentage of rotamer outliers for a final model at this resolution; the target is typically < 1%. After a great deal of effort to fix some rotamers and one C-beta deviation, th
- alternative: Return to Coot one last time to examine the remaining 5 rotamer outliers identified by MolProbity. Attempt to fix them. If the density does not support a better conformation, they can be left as-is wi
- provenance: #381

## 8. [moderate] Ran AutoSol with sites=2, thoroughness=thorough, defaults elsewhere; did not set an explic
- flagged_by: self_critique   ·   triage: keep   ·   xtriage explicitly provided a 3.1 Å anomalous-signal cutoff to guide HySS, but it was not applied, and using AutoSol defaults for substructure search when specific guidance existed is a reasonable-but-suboptimal choice worth expert review.
- at decision, knew: Sequence has exactly 2 Met, 87 residues, Vm indicated 1 copy. xtriage explicitly stated anomalous signal extends to ~3.1 Å and that this could guide the phenix.hyss resolution cutoff.
- concern: xtriage handed the exact parameter to set (3.1 Å HySS cutoff) and it was ignored. AutoSol found 6 sites where 2 were expected, 3 carried into the model and 2 later deleted — direct evidence the substructure was noisier than necessary, and the downstream Se confusion traces back here.
- alternative: Set an explicit 3.1 Å HySS substructure-search resolution per xtriage guidance; this might have produced a cleaner substructure with fewer spurious low-occupancy sites and fewer ambiguous sites to adj
- provenance: D3

## 9. [moderate] Final geometry strategy: fix rotamers in Coot, then refine B-factors/occupancies only (no 
- flagged_by: self_critique   ·   triage: keep   ·   Abandoning reciprocal-space coordinate refinement for the final model while leaving an 8.1% R-gap and 6.76% rotamer outliers, without trying available rotamer-restrained refinement, is a defensible but questionable endgame worth expert review.
- at decision, knew: Three prior rounds showed phenix.refine coordinate refinement re-breaking rotamers (no rotamer restraints in reciprocal-space refinement). R-free moved 0.2194 → 0.2180 across the change. Alternatives (phenix.real_space_refine with rotamer restraints, or AQuaRef) not consulted.
- concern: The deposited coordinates were last optimized against the map in Coot, not against structure factors — an unusual endgame. The R-work/R-free gap (8.1 %) and rotamer outliers (6.76 %) were both left unresolved, and the fix-then-drift cycle consumed budget. A reviewer may object to final coordinates n
- alternative: Use phenix.real_space_refine with rotamers.restraints.enabled=True, or AQuaRef, which might fix rotamers and allow coordinate refinement against the data simultaneously; comparing R-gap and outlier co
- provenance: D17

## 10. [moderate] Left Gln12 fully modelled.
- flagged_by: self_critique   ·   triage: keep   ·   The incoherent density (strong OE1, absent CG) with an untested cheap water hypothesis suggests possible solvent mis-assignment worth expert review.
- at decision, knew: Gln12 OE1 has 2.12 σ density while CG has −0.02 σ — an incoherent pattern; a 180° amide flip did not improve it. Whether the 2.12 σ at OE1 is actually a water was never tested.
- concern: Inconsistent with D13 (Arg21/Lys24 distal atoms were zeroed for similar weak density), and the cheap-to-check hypothesis that the 2.12 σ OE1 density is actually a water was never tested.
- alternative: Test whether the OE1 density is a water (place a water and re-refine, or examine geometry/H-bonding); this would distinguish a genuine Gln side chain from a mis-assigned solvent peak.
- provenance: D14

## 11. [moderate] Treated the case as SAD, not MAD, using only peak.sca.
- flagged_by: self_critique   ·   triage: keep   ·   SAD phasing succeeded with reasonable FOM, but two additional wavelength files were present and unused, and the user was never informed that MAD could have improved phasing.
- at decision, knew: Only peak.sca (single wavelength) was named in the prompt; high.sca and infl.sca sat in the source directory but were not used. xtriage anomalous measurability 0.367 max, signal to 3.1 Å; DM FOM reached 0.73.
- concern: Two additional wavelengths existed and 3-wavelength MAD would likely have produced a better substructure and phases, but the user was never told MAD was possible — following the file list without flagging the stronger available experiment.
- alternative: Inform the user that high.sca and infl.sca were available and that a 3-wavelength MAD experiment would probably have improved phasing; the presence of the extra wavelength files is the distinguishing 
- provenance: D1

## 12. [moderate] Set occupancy 0 on distal atoms of Arg21 and Lys24.
- flagged_by: self_critique   ·   triage: keep   ·   Zeroing occupancy on distal atoms with weak/negative density is defensible, but the unaddressed fact that zero-occupancy atoms still enter MolProbity rotamer statistics means the validation impact was misjudged and warrants review.
- at decision, knew: Arg21 and Lys24 distal atoms had 2Fo-Fc 0.39–0.65 σ with negative Fo-Fc; per-atom density probe (data-side). Not checked whether zero-occupancy atoms still count in MolProbity rotamer statistics — they do.
- concern: The zero-occupancy policy was applied inconsistently — Arg21/Lys24 were zeroed while Gln12's CG at −0.02 σ was left fully modelled, an unprincipled inconsistency. The effect on validation stats was also misjudged since zero-occupancy atoms still count in MolProbity rotamer statistics.
- alternative: Apply a consistent policy across weak side chains (either zero, truncate, or leave at high B for all), and account for the fact that zeroed atoms still enter rotamer statistics; consistent density-bas
- provenance: D13

## 13. [moderate] Ran phenix.autosol with the explicit instruction `sites=2`.
- flagged_by: transcript_pass   ·   triage: keep   ·   Specifying sites=2 while the agent itself noted the N-terminal Met is often disordered is an internally inconsistent prior that could push the substructure search toward a noise peak or mask additional sites.
- at decision, knew: The sequence contains two methionine residues (potential selenium sites). The N-terminal methionine is often disordered.
- concern: This is a strong, potentially incorrect prior. If only one Se site is ordered, forcing the program to find two can lead it to pick a noise peak, degrading the phases. If more than two sites exist (e.g., an oxidized cysteine), this would prevent their discovery. The agent's plan acknowledged the N-te
- alternative: Omit the `sites` parameter and let the program determine the number of sites automatically. The program would report solutions for different numbers of sites, and the best one could be chosen based on
- provenance: 38-38

## 14. [minor] Retained 14 poorly-ordered waters.
- flagged_by: self_critique   ·   triage: keep   ·   Retaining waters with CC 0.69–0.93 is defensible, but the untested nature and meaningful fraction (14/50) make a quick verification worthwhile.
- at decision, knew: 14 'poorly ordered' waters had CC values 0.69–0.93, mostly reasonable. Removing them and re-refining was not tested. 14 of 50 waters is a meaningful fraction.
- concern: The retention was untested — removing them and re-refining was never tried, and 14 of 50 waters is a meaningful fraction of the solvent model.
- alternative: Remove the poorly-ordered waters and re-refine to compare R-free and difference density; a drop in R-free or negative Fo-Fc at those sites would indicate they should be removed.
- provenance: D19

## 15. [minor] Locate and address the newly introduced Cβ outlier
- flagged_by: self   ·   triage: keep   ·   A single newly introduced Cβ outlier from the model's own rotamer refitting is a real, localized geometry regression worth a quick check, though minor given negligible R-free change.
- at decision, knew: FINAL refinement R-free 0.2187 vs 0.2194; Cβ deviations 0.00%→1.30% (one residue)
- concern: Its own rotamer refitting introduced a Cβ deviation
- alternative: 
- provenance: #361

## 16. [minor] Check whether the Cβ deviation predates the refinement
- flagged_by: self   ·   triage: keep   ·   A 0.279 Å Cβ deviation is only marginally above the 0.25 Å threshold and the causal attribution to the rotamer fix is asserted without checking the pre-refinement state.
- at decision, knew: cbetadev output showing MSE A/77 at 0.279 Å
- concern: Uncertain whether the deviation was caused by its own fix vs pre-existing
- alternative: 
- provenance: #364

## 17. [minor] Proceeded to run phenix.autosol using the full 2.59 Å dataset.
- flagged_by: transcript_pass   ·   triage: keep   ·   Running AutoSol on full 2.59 Å data without restricting the substructure search to the anomalous limit (3.1 Å) is a legitimate but minor best-practice consideration worth expert glance.
- at decision, knew: phenix.xtriage reported an overall resolution of 2.59 Å, but that the anomalous signal extends to only 3.1 Å.
- concern: The SAD substructure determination relies exclusively on the anomalous signal. Using data from 3.1 to 2.59 Å, which contains little to no signal, can add noise and potentially complicate the search for the selenium sites. While AutoSol often handles this internally, it's a potential pitfall to not e
- alternative: Explicitly set the resolution for substructure determination to 3.1 Å within the AutoSol run, while allowing the full resolution data to be used for density modification and model building. The succes
- provenance: 37-38
