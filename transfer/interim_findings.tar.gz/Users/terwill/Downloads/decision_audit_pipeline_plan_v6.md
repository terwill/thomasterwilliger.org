# Decision-Audit Candidate-Finder — Plan v6

*Updated after running the pipeline end-to-end on **all 11 datasets** (10 completed; CASP7-T0283-mr timed out). This revision folds in what the runs taught us and re-centers the plan on the endpoint we now want: **classes of problems and the skills that fix them**, not a queue of individual decisions. The honest framing from v5 is preserved.*

---

## 1. What this is, and is not

This is a **candidate-finding pipeline**: several LLM-based detectors and judges produce a *lower-bound catalogue of candidate weaknesses* in the Phenix Expert's decisions, for expert review. It is **not** a validated measurement pipeline and makes **no problem-rate claim**. "Lower-bound" is deliberate — there is no complete decision denominator, the detectors miss things, and single runs are variance-dominated.

Three questions are kept strictly separate, because conflating them was the central flaw earlier reviews caught:

1. **Ex-ante soundness** — was the decision justified on the information the Expert had *at that moment*? (This is what the pipeline primarily surfaces.)
2. **Ex-post consequence** — did the decision actually harm the final model? (A separate question the pipeline does *not* claim to answer.)
3. **Recurrence** — does the decision recur across independent runs/datasets? (The evidence that a candidate is structural rather than a one-off.)

A flagged decision is a **lead, not a verdict**, until it recurs and a human confirms it.

---

## 2. Goal (updated)

The per-run review queues are raw material. The **deliverable is a taxonomy of problem *classes*, each with a concrete *skill* intervention** for the Expert.

- A **class** earns its place by **recurring across independent datasets** — recurrence is the evidence it's structural, not incidental.
- A **skill** targets a class. The highest-value skills don't merely prevent the slip; they **convert a lucky self-catch into a guaranteed check** — because the runs show the Expert already recovers from most of its own errors, often by luck, so hardening the *recovery* directly targets the dangerous case: the error it would otherwise *miss*.

End state: per-case queues → cross-case rollup → ranked class taxonomy → draft `SKILL.md` text per load-bearing class → (eventually) re-run with the skills installed to see whether that class's incidence drops.

---

## 3. Architecture (as built)

**Run side.** The Expert runs under the existing pilot harness as arm **"A"**, whose prompt is the base operating guide plus a **G0 retrospective self-critique block** that writes `artifacts/self_analysis.md` (forward walk over every decision + backward trace from late problems to their originating decision, under an anti-rubber-stamp guardrail: judge decisions against the data and maps, never against the model they produced). The harness auto-proceeds through gates and normalizes the session into an **event record** (`events.jsonl`) preserving tool calls, parameters, and artifacts.

**Finder side (`run_finder.py`, per run).** Three detector legs, then two reducers:

- **G0 — `self_critique`**: ingest the Expert's own `self_analysis.md`.
- **G1a — `self`**: extract in-run self-flags from the event digest.
- **G1b — `transcript_pass`**: an independent pass over the event digest by a **different-family** model (Gemini).
- **dedup**: cluster candidates **by decision** (one judge call), conservative and **lossless** — every leg's wording is kept under `also_flagged`, so a merge can never hide a cross-leg disagreement.
- **triage**: a neutral-packet-first adjudicator (judge decisions on the evidence available *at the decision*, before seeing the detector's concern), emitting keep/drop + severity.
- Output: `review_queue.md` (ranked by severity, then corroboration) plus `candidates.jsonl` (full pre-dedup audit trail).

**Rollup.** `summarize_queues.py` aggregates all per-case queues into a severity table, a vantage-coverage matrix (which legs carry each case), and a corroboration-ranked "look here first" list.

**The three-vantage frame** is the conceptual core: the in-run flag (knew *at* the decision), the self-critique (knew *by the end*, having lived the whole chain), and the independent audit (an outsider with no stake) have different blind spots. **Their disagreements are the measurement** — a lead only the self-critique caught is a late-consequence catch; a lead only the independent pass caught is a self-confirming blind spot.

**Model families.** Expert = Claude Opus; independent detector (G1b) = Gemini; the judge/triage leg *should* be a **third** family. It is currently Anthropic as a stopgap (OpenAI auth issue), which makes triage same-family as the Expert — the one place that most undermines independence. Restoring a cross-family judge is an open item (§6).

---

## 4. What the three runs taught us

**Validated:**

- **The G0 self-critique is both substantive and accurate.** On the clean gene-5-mad run it did not rubber-stamp (the anti-rubber-stamp guardrail visibly separates data-side evidence from model-phased evidence), and cross-checking its `self_analysis.md` against the 414-event record showed every load-bearing claim corroborated with matching numbers — **no confabulation**.
- **The three-vantage design works.** On run #1 the G0∩G1b disagreement fired: the independent pass flagged a substructure decision (`sites=2` as too strong a prior) that the self-critique had *defended* — exactly the self-confirming-blind-spot signal the design targets, and it was scientifically live (the sequence has a Cys the fixed count could mask).
- **Real dynamic range on tool-driven runs.** nsf-d2-ligand surfaced a genuine **confident error** — the Expert asserted, in its user-facing plan, that ATP sat in "a bona fide nucleotide pocket" (misreading a motif) while the refuting apo difference map sat unexamined. This is the class of error the prose screens and the clean run could never produce. (The run then caught and corrected it via its own planned density check; the final model is good.)
- **Corroboration concentrates signal.** Multi-vantage leads (2- and 3-vantage) rise to the top; dedup merges cross-leg duplicates of the same decision correctly; triage filters by content (dropped ~half the leads on clean gene-5-mad, kept all on the messier cases).
- **The independent leg earns its slot every case** — Gemini reliably surfaces refinement-*protocol* and discipline concerns the self-legs miss (parallel launch preempting a planned check; occupancy refinement on a raw model).

**Cautions the runs exposed:**

- **Nondeterminism is real; themes are stable.** The specific leads shift run-to-run, but the *themes* (checkpoint bug, substructure/site-count, endgame refinement) recur. This vindicates the recurrence design and reinforces "one run is a lead, not a verdict."
- **G0 completeness varies by case.** gene-5-mad's thorough 19-decision self-analysis dominates its queue; the messier ligand/MR runs lean more on G1a/G1b. Watch whether G0 stays thin on the harder cases — that would be a signal about the self-critique step, not the pipeline.
- **Triage precision is untested at scale**, and is currently same-family with the Expert.
- **Recall is unproven.** Every clear error so far was self-caught and corrected; no self-*missed* error is yet known to have reached a final model. That is what the failure-prone regimes are for.

**A cross-case finding worth acting on independently of the taxonomy:** a **tool-vs-tool metric discrepancy** recurs in all three cases (refine-log vs standalone MolProbity/Coot/cbetadev — e.g. a 23× rotamer-count gap in beta-blip). This points at inconsistent metric definitions in the Expert's own reporting, worth fixing regardless of the audit.

---

## 5. Current class taxonomy (provisional, 3 cases) → skill directions

Tagged with how many of the three cases each recurs in; a class earns a skill when it holds across the fuller set.

1. **Symmetry blindness** *(2 cases)* — reasons inside the asymmetric unit and forgets the crystal (declared an Se atom "impossible" from an ASU-only neighbour search; tried to relocate a ligand with a lattice shift instead of the symmetry operator).
   → *Skill:* symmetry-first checklist — symmetry-expanded neighbour search before any isolated-atom/contact conclusion; relate molecules by operator, never by lattice translation.

2. **Assert before verify** *(2 cases)* — commits to a conclusion, often in user-facing text, while the refuting evidence is one cheap step away and unread (the ATP-pocket claim; identity by elimination with no positive test; proceeding past a self-scheduled check).
   → *Skill:* ground-the-claim-first — run the ligand-blind difference map / positive test and verify motifs against the printed sequence *before* asserting; never pass a check you yourself planned.

3. **Unverified tool output** *(3 cases — recurs everywhere)* — trusts a tool's "success" or metric without checking the artifact, and doesn't reconcile disagreeing tools (Coot reported 4 residues FIXED but wrote a byte-identical file; validate_ligands vs Coot; refine-log vs MolProbity).
   → *Skill:* trust-but-verify — diff the artifact on disk after any op that reports success; reconcile which validator is authoritative before reporting a number. Implies two concrete fixes: repair the Coot `restore_to_backup_checkpoint` pattern (it is molecule-wide; use checkpoint-per-residue or save-to-new-file), and document metric provenance.

4. **Uncontrolled comparison / no significance** *(2 cases)* — draws a quantitative conclusion from a confounded comparison or calls a difference "within noise"/"better" without a test (attributed an R-free drop to the ligand while 158 waters were added in the same step; occupancy refinement on a raw model; within-noise model selections).
   → *Skill:* controls & significance — change one variable at a time or run the matched control; stage refinement targets by model maturity; use a paired test or retain both when calling models indistinguishable.

5. **Ignoring available guidance / wrong method for the regime** *(3 cases — recurs everywhere)* — guesses parameters, ignores explicit program guidance, under-uses stronger methods (PHIL-name guessing when introspection was available; ignoring xtriage's stated HySS cutoff; no deep rebuilding at 3.0 Å with R-free stuck).
   → *Skill:* query `phenix_get_phil`/`--show-defaults` before invoking; honor stated program cutoffs; a method-by-regime table (high R-free at low resolution → escalate to autobuild/SA, not rotamer-only polishing).

**Strongest classes: 3 and 5** (both recur in all three cases). The taxonomy is explicitly provisional; the twinning/tNCS/MR/marginal-anomalous and cryo-EM cases may promote borderline classes and may surface a **sixth** class the three benign-ish crystallographic cases couldn't.

---

## 6. Status and next steps

**Cases — all 11 run.** 97 rated decisions across the 10 completed runs: 75 well-justified (77%),
13 weakly, 3 got-lucky, 4 wrong. 70 kept leads, 87 dropped by triage. CASP7-T0283-mr timed out, so it
has no `self_analysis.md` and no ledger row — but it still yielded 6 leads from the two transcript
legs, showing a truncated run remains auditable at two-thirds strength.

**The recall test did NOT land.** The failure-prone regimes (twinning, tNCS, distant MR, marginal
anomalous) produced leads but **no confirmed self-missed error reaching a final model**. Every clear
error was self-caught. Reaching that result needs a **planted error subtle enough to survive** —
a sub-Å displacement, a one-residue register slip in a poorly-ordered loop, or a water where a weak
ion belongs — run under **arm A** so the G0 leg is present and G1b can be scored against known
ground truth. This is the single most important open result, and the only cases in the corpus with
controllable ground truth are the ones we plant.

**Two results worth carrying forward:**

- **The outcome axis now confirms the decision axis.** With `reference_model` populated, the
  independent science grade agrees with the queue where it matters: beta-blip's leads said
  *"no deep rebuilding, R-free stuck ~0.31"*, and the independent grade returns **major** with
  **coverage 0.501** against the deposited model. A decision-level prediction, confirmed by an
  independent measurement.
- **A sixth class emerged — passive persistence with a failing approach** (3/11: CASP7 waited on a
  stalled AutoBuild; beta-blip polished rotamers at R-free 0.31; esterase_tNCS skipped its planned
  rebuild after a tool failure). CASP7 also supplies the corpus's **first observed thrash** —
  AutoBuild plateaued at R-free 0.41 with the best model unchanged for cycles, and the agent chose to
  wait rather than intervene. This settles the earlier question about dropping the anti-thrash
  guidance: **keep it.** Note it is *not* the 3-strike retry cap (nothing failed three times) — that
  cap remains specified and unexercised.

**Guide (arm A) refinements to fold in:**
- Reword "no causal claims" → "causal hypotheses for expert review, not established causation" (the backward trace *is* causal; the current wording is internally inconsistent).
- Split the severity field into *stakes-if-uncaught* plus a separate *caught_in_run* flag (the runs showed severity was carrying both at once).
- Point the G0 ingest at the self-analysis's own severity-labeled "Candidate weaknesses" section (the guide now enforces that structure).

**Pipeline work:**
- Restore a **cross-family triage** judge once OpenAI auth is sorted (the shim already supports base-url/org/project overrides).
- Ship the **Coot checkpoint fix** (the `restore_to_backup_checkpoint` molecule-wide bug is real and reproducible).
- Check `normalize.py`'s `consequential` heuristic — it was all-zero across 414 events, so any scorer keying on it is inert.
- Optional: a second, **topic-level** dedup pass if the reviewer wants "one problem → one lead." The current dedup is deliberately *decision-level*, so one underlying issue that spans several decisions (e.g. the checkpoint bug) legitimately appears as multiple leads.

**Toward the endpoint:** as the remaining eight cases land, map each queue onto the five classes, promote the classes that recur, watch for a sixth, then draft the actual `SKILL.md` text for the load-bearing classes — prioritizing skills that harden a self-catch. The final validation is a re-run with the skills installed, checking whether the targeted class's incidence falls.

---

## 7. Limitations (kept explicit)

- A **lower-bound catalogue, not a rate.** No decision denominator; no problem-rate or detector miss-rate is claimed.
- **G0 is correlated self-critique**, not an independent vantage — it shares the Expert's blind spots and must never count as corroboration of its own causal claim.
- **Single runs are variance-dominated** — recurrence across runs/datasets is required before a lead becomes a finding.
- The **LLM judges and detectors are themselves unvalidated at scale**; the human expert is the arbiter, and the pipeline's job is to make that review efficient, not to replace it.
- **Recall is unproven** until a genuine self-missed failure is caught — the single most important open result.
