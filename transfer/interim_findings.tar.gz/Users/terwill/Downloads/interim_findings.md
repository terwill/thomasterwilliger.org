# Decision-Audit Candidate-Finder — Interim Findings (all 11 cases)

*Complete set: gene-5-mad (Se-SAD), nsf-d2-ligand (ATP ligand), beta-blip (MR), AF_7mjs (cryo-EM),
AF_bromodomain_ligand (ligand/MR), porin-twin (twinning), refined_start (refinement),
esterase_tNCS (tNCS), p9-sad (marginal anomalous), a2u-globulin-mr and CASP7-T0283-mr (distant MR).
Ten runs completed; CASP7 timed out.*

---

## 1. The headline

**The Expert is mostly excellent, errs rarely, and usually catches its own errors.** Across
**97 rated decisions in ten completed runs: 75 well-justified (77%), 13 weakly-justified,
3 got-lucky, 4 wrong (4%)** — and every one of the four wrong calls was caught and corrected within
its run.

The queues (70 kept leads, 87 dropped by triage — a 55% drop rate) must be read against that
denominator. Most kept leads are *defensible-but-questionable* calls worth a reviewer's glance, not
errors.

*Caveat, kept attached: these ratings are the Expert grading itself — correlated self-critique, not
independent verification — and the forward walk under-enumerates silent defaults, so the count is a
lower bound. Context, not a validated rate. §4 shows the ledger is systematically optimistic.*

---

## 2. New in this round

### 2a. A timed-out run is still auditable — but only by the transcript legs

CASP7 hit its timeout again, so it wrote no `self_analysis.md` and contributes **no ledger row and
zero G0 leads**. Yet it produced **6 kept leads** from G1a (5) and G1b (4), 3 of them multi-vantage.

**Operationally useful:** a run that dies can still be audited at two-thirds strength. The G0 leg is
the one that needs a clean finish, because the self-critique is written after the FINAL REPORT.

### 2b. Thrashing has now been observed — which settles the "pull the guidelines?" question

CASP7 lead 2 (both vantages, moderate) is the first genuine instance in the corpus:

> *"AutoBuild `overall_best.pdb` unchanged since 17:28, R-free plateaued at 0.41, thrashing on
> cycle 3; ~167 residues fragmented across chains."* → the agent's decision was to **wait one more
> cycle** rather than intervene.

The auditor's verdict is the teaching point: *"When an automated procedure is clearly stalled or
'thrashing', the expert response is to intervene, not to wait passively… This is the point to stop
the automated job and try a different strategy."*

**Do not pull the anti-thrash guidance.** Note carefully, though, that this is *not* the 3-strike
retry cap — nothing failed three times. It is **passive persistence with a demonstrably stalled
procedure**, which needs its own rule (see class C6 in §5). The retry cap remains specified and
unexercised.

### 2c. Class 3 recurs again, in its purest form

CASP7 lead 1 (both vantages, **major**): the agent ran a refinement specifically to obtain an R-free
value to cross-validate the MR solution before committing to a long AutoBuild — then **never read
the R-factors**, and proceeded on the assumption it had worked.

> *"The agent ran the job but then failed to check its output for the key result… completely
> skipping the confirmation step it had correctly identified as necessary."*

That is "ran the tool, didn't check the output" with no ambiguity, and it is the same class as the
Coot checkpoint failure and the grep-verified-with-the-same-grep incident.

### 2d. a2u-globulin-mr completed cleanly

8 decisions, **8 well-justified (100%), 0 wrong** — and 3 kept leads with 12 dropped, the highest
drop ratio in the set. Both multi-vantage leads concern the same theme: choosing geometry scores
over density evidence (auto-fitting rotamers the agent had itself described as density-driven).

---

## 3. The outcome axis now has teeth

`reference_model` entries have populated the independent science grade for 8 cases — this is
**verification against the deposited structure**, not self-report:

| case | grade | Cα-RMSD (Å) | coverage |
|---|---|---|---|
| esterase_tNCS, gene-5-mad, nsf-d2-ligand, refined_start | **none** (no science failure) | 0.10–0.21 | 0.98–1.00 |
| AF_bromodomain_ligand | major | 0.14 | 0 ⚠ |
| beta-blip | major | 0.33 | **0.501** |
| p9-sad | major | 0.25 | 0.824 |
| CASP7-T0283-mr | **critical** | **15.83** | 0 |

**The two axes agree where it matters most.** beta-blip's decision queue said *"no deep rebuilding —
no autobuild, loop fitting or SA; only rotamer-level polishing; R-free stuck ~0.31"*, and the
independent grade confirms **only 50% coverage** against the deposited model. The decision audit
predicted the outcome, and an independent measurement confirmed it. That is the strongest validation
the pipeline has produced.

**CASP7's "critical" is not a fair scientific judgment** — the run was cut off mid-build, so a
15.8 Å Cα-RMSD reflects an unfinished structure, not a bad decision. Exclude it from any
quality claim.

⚠ **AF_bromodomain's `coverage 0` is a confirmed bug.** It reports `matched fraction 0.93` with
`coverage 0` — internally contradictory. The control case is CASP7, which reports `matched 0.03 /
coverage 0` and is self-consistent. So `coverage` specifically is broken for AF_bromodomain;
**matched fraction is the number to trust.** Its `major` grade is nonetheless correct and
independently explained by its own queue — *"modeled only ONE GQX copy though the deposited file has
two"* — so the verdict stands even though one metric feeding it does not. Check `science.py`'s
coverage calculation (likely a chain-ID or numbering mismatch) before quoting that number.

---

## 4. The ledger is systematically optimistic — three cases now confirm it

| case | ledger | queue |
|---|---|---|
| porin-twin | 8/8 well-justified, 0 wrong | 6 leads |
| p9-sad | 5/5, 0 wrong | 4 leads |
| a2u-globulin-mr | 8/8, 0 wrong | 3 leads (2 multi-vantage) |

A 100% self-assessment means **"the Expert found nothing wrong in its own forward walk"**, not
"nothing was wrong." The denominator is real and useful context, but it is not a verdict — which is
exactly why the caveat travels with it in the report text.

---

## 5. Problem classes (11 cases)

| Class | Recurs in | Shape |
|---|---|---|
| **3. Unverified / unpersisted tool output** | **~11 / 11** | Trusts a tool's "success" or metric without checking the artifact; doesn't reconcile disagreeing validators |
| **5. Ignoring available guidance / wrong method for regime** | 5 / 11 | Guesses parameters, ignores explicit program guidance, under-uses stronger methods |
| **4. Uncontrolled comparison / no significance** | 5 / 11 | Concludes from a confounded comparison, an aggregate metric, or an unjustified threshold instead of the discriminating test |
| **2. Assert before verify** | 3 / 11 | Commits to a conclusion — often user-facing — while refuting evidence sits one cheap step away |
| **1. Symmetry blindness** | 2 / 11 | Reasons inside the asymmetric unit and forgets the crystal |
| **6. Passive persistence with a failing approach** *(new)* | 3 / 11 | Keeps waiting on, or polishing with, a method the evidence shows is not working |

**Class 3 remains universal and is the one to fix first.** It now spans: a Coot pass reporting four
residues "FIXED" while writing a byte-identical file (gene-5-mad); a verified pepflip lost to a crash
because nothing was saved (AF_7mjs); an edit verified with the same flawed grep that made it
(refined_start); and a diagnostic refinement whose output was never read (CASP7). Plus the
mechanical tool-vs-tool discrepancies in §6.

**Class 6 is new and earns its place on recurrence:** CASP7 (waited on a stalled AutoBuild),
beta-blip (rotamer polishing while R-free sat at 0.31, coverage 0.501), esterase_tNCS (proceeded
without the planned Coot rebuild after a tool failure). It is distinct from Class 5 — that is
choosing the wrong method *up front*; this is **failing to change course when the evidence says the
current course is not working**. The skill is a stall-detection rule: *if a procedure has not
improved the target metric across N cycles, stop and change strategy rather than waiting.*

---

## 6. Mechanical tool-vs-tool discrepancies (independent of the LLM detectors)

`table1.py` finds disagreements in **8 of 11** cases, every value carrying its source file.

**The most diagnostic pattern is an R-work/R-free asymmetry.** R-free between the refine log and
standalone MolProbity agrees almost everywhere — gene-5-mad 0.2179/0.218, nsf 0.2282/0.2282, p9-sad
0.2462/0.2462, a2u 0.243/0.2425 — while **R-work diverges**:

| case | R-work (refine log vs MolProbity) | other |
|---|---|---|
| **porin-twin** | **0.1288 vs 0.2286** (R-free 0.158 vs 0.2489) | twin-corrected vs conventional |
| **refined_start** | **0.2036 vs 0.1553** | R-free 0.2417 vs 0.2475; rotamer 5.48% vs 2.74% |
| **a2u-globulin-mr** | 0.2037 vs 0.1846 | rotamer 0% vs 2.62% |
| esterase_tNCS | 0.1833 vs 0.1716 | R-free 0.2112 vs 0.205 |
| beta-blip | 0.2318 vs 0.2371 | rotamer 6.71% vs 12.24% |
| AF_7mjs / AF_bromodomain | — | rotamer 3.77 vs 2.83; 2.25 vs 0 |
| gene-5-mad | — | Cβ reported as a count (0) vs a percentage (1.3%) — different units |

Same model and same test set, but a different working-set R, points at **differing bulk-solvent and
scaling treatment between the two calculations** rather than a model discrepancy. That is a sharper
diagnosis than "the tools disagree," and it is exactly what the metric-provenance skill should
document.

**Where the independent recomputation exists, it arbitrates.** For refined_start the recomputed
R-free (0.2417) matches the refine log **exactly**, making MolProbity's 0.2475 the outlier. That
column is populated for only three cases (CASP7 0.5574 — consistent with its failed run; esterase
0.2068; refined_start 0.2417); filling it for the rest would settle several of these outright.

**porin-twin's is the most consequential for reporting** and is now confirmed from the data: space
group `R 3 :H`, refined twin fraction 0.32. Publishing R-free 0.158 without the twin-corrected
qualifier would badly overstate the model.

**Also settled by the table:** `R 3 :H` (point group 3, rhombohedral) independently confirms that
the Expert's *"R3 → merohedral-twinning candidate"* reasoning was correct and the detector lead
contradicting it was a false positive — the corpus's one confirmed detector FP.

## 7. Pipeline health

**Working:** triage drops 55% of candidates; dedup merges cross-leg duplicates; per-leg isolation
kept CASP7 productive despite a missing G0; a triage HTTP 529 was caught and the lead retained as
`ambiguous` rather than crashing the run.

**Two issues to watch:**

1. **Possible inflated corroboration.** a2u lead 1 carries `flagged_by: both`, but its two concerns
   are different topics joined by `||` — G1a flagged a hard refinement weight, G1b flagged TLS
   groups. That is span-overlap merging in `merge_candidates` conflating *adjacent* concerns as
   *agreement*. If it is common, the multi-vantage count — our main corroboration signal — is
   inflated. Worth auditing a sample of `both` leads for topic identity.
2. **`table1.py` fixes since the last round** (all now verified in the current output): a source-class
   collision made any refine log living under `DEPOSIT/` count as a *run-declared* report, so that
   row silently duplicated the refine-log row and porin-twin double-reported the same discrepancy
   under two labels; the space-group pattern captured prose (`identification----------`); and the Cβ
   units note fired on all-zero pairs. Space group is now populated for all 11 cases with real
   Hermann-Mauguin symbols, and the run-declared row is honestly limited to the two runs that wrote
   one.

3. **Only 2 of 11 runs wrote a `DEPOSIT/README.md`** (gene-5-mad, nsf-d2-ligand). This is not a
   tooling gap — arm A's guideline requires a `### FINAL REPORT` block *"as well as prose"* but never
   names a deposit README, so nine runs reasonably didn't write one. It is the **same channel
   ambiguity** found in the S/E/P comparison, and the fix is the same: name the channel explicitly
   (block in the response **and** `DEPOSIT/FINAL_REPORT.md`), or cross-run tooling can rely on
   neither.

4. **Two Table-1-only observations** the decision queues never raised. `esterase_tNCS` has the
   loosest geometry in the set at the highest resolution — RMS bonds 0.0184 Å and angles 1.58° at
   1.6 Å, where ~0.005–0.010 is expected — suggesting a geometry weight that was never tightened.
   And the twin-fraction row shows 0.04 (nsf) and 0.03 (p9-sad), which come from xtriage/AutoSol
   estimates for candidate twin laws in untwinned crystals: parser noise, not findings. Only
   porin-twin's 0.32 is real.

---

## 8. Where this stands

**Recall is still unproven.** No self-*missed* error has been shown to reach a final model. Every
clear error was self-caught; the failure-prone regimes (twinning, tNCS, distant MR, marginal
anomalous) added leads but no confirmed miss. This is the one result eleven cases have not produced,
and it needs a **planted error subtle enough to survive** — a sub-Å displacement, a one-residue
register slip in a poor loop, or a water where a weak ion belongs — run under arm A so the G0 leg is
present and G1b can be measured against known ground truth.

**Ready to build now:** the Class 3 skill (verify-and-persist), which is universal, has three
concrete sub-fixes already identified — the Coot `restore_to_backup_checkpoint` pattern, metric
provenance between refine logs and standalone validators, and verification with a *different
instrument* than the one that made the edit.
