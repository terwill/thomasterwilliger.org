# Decision-Audit Candidate-Finder — Interim Findings

*Status after six of eleven datasets: gene-5-mad (Se-SAD), nsf-d2-ligand (ATP ligand), beta-blip (MR), AF_7mjs_H_PredictAndBuild (cryo-EM), AF_bromodomain_ligand (ligand/MR), porin-twin (merohedral twinning). Five failure-prone cases remain.*

---

## 1. The headline

**The Expert is mostly excellent, errs rarely, and usually catches its own errors.** Across 68 rated decisions in six runs: **50 well-justified (73%), 11 weakly-justified, 2 got-lucky, 4 wrong (6%)** — and every one of the four wrong calls was caught and corrected within the run.

The review queues (43 kept leads, 52 dropped by triage) must be read against that denominator. Most kept leads are *defensible-but-questionable* calls worth a reviewer's glance, not errors. Without the denominator a queue of leads reads as an indictment; with it, the picture is a strong performer with a handful of recurring habits worth hardening.

*(Caveat, kept attached: the ratings are the Expert grading itself — correlated self-critique, not independent verification — and the forward walk under-enumerates silent defaults, so the count is a lower bound. This is context, not a validated rate.)*

---

## 2. What the pipeline proved about itself

**The three-vantage design works.** G0 (retrospective self-critique), G1a (in-run self-flags), and G1b (independent different-family pass) have genuinely different blind spots, and their *disagreements* carry the signal:

- **G0 is substantive and faithful.** On gene-5-mad it produced a 19-decision forward walk that did not rubber-stamp, and cross-checking it against the 414-event record showed every load-bearing claim corroborated with exact matching numbers — no confabulation.
- **The independent leg earns its slot in every case**, reliably surfacing refinement-*protocol* and discipline concerns the self-legs miss (occupancy refinement on a raw MR model; launching a refinement that preempts the agent's own planned check).
- **Corroboration concentrates signal.** Multi-vantage leads (2–3 vantages) are consistently the substantial ones; dedup merges cross-leg duplicates losslessly.
- **Triage now filters by content** — roughly half of all candidates are dropped, versus the keep-everything behavior of the first run.

**And it produced its first confirmed false positive** — the single most important calibration datum so far. On porin-twin a detector asserted "R3 is not a merohedral-twinning space group." That is wrong: R3 has point group 3, a proper subgroup of the rhombohedral holohedry $\bar{3}m$, leaving 2-folds perpendicular to $c$ available as twin laws — R3 is a classic merohedral-twinning group. (R32 is where rotational merohedral twinning is excluded.) The Expert's reasoning was correct; the *detector* was wrong, **triage kept it and echoed the false claim**, and it took domain expertise to catch.

That yields a rule worth encoding:

> **Leads that assert a crystallographic *fact* need domain verification before they feed a class or a skill. Leads that flag *method* have held up uniformly.**

Across six cases, every methodological lead has survived scrutiny; the one factual assertion was wrong. That asymmetry should shape how the skills are drafted — and it prevents a false positive from quietly propagating into a skill recommendation.

---

## 3. The problem classes (provisional)

Recurrence across independent datasets is the evidence a class is structural rather than incidental.

| Class | Recurs in | Shape |
|---|---|---|
| **3. Unverified / unpersisted tool output** | **6 / 6** | Trusts a tool's "success" or metric without checking the artifact; doesn't reconcile disagreeing validators |
| **5. Ignoring available guidance / wrong method for regime** | 3 / 6 | Guesses parameters, ignores explicit program guidance, under-uses stronger methods |
| **4. Uncontrolled comparison / no significance** | 3 / 6 | Concludes from a confounded comparison or an aggregate metric instead of the discriminating test |
| **2. Assert before verify** | 2 / 6 | Commits to a conclusion — often user-facing — while the refuting evidence sits one cheap step away |
| **1. Symmetry blindness** | 2 / 6 | Reasons inside the asymmetric unit and forgets the crystal |

**Class 3 is universal (6/6) and is the one to fix first.** It appears as a metric discrepancy in every single case — refine-log vs standalone MolProbity/Coot/cbetadev (a 23× rotamer-count gap in beta-blip; twinned vs untwinned R in porin-twin) — and, in both Coot-heavy cases, as *lost work*: a rotamer pass that reported four residues "FIXED" while writing a byte-identical file (gene-5-mad), and a verified Trp47 pepflip lost to an interpreter crash because nothing was saved to disk (AF_7mjs). The class is therefore **verify *and persist* against the artifact on disk**.

**Class 4 extends naturally to bias-aware validation.** porin-twin's coherent cluster — 165 waters accepted on aggregate R-free alone, rotamer accept/revert judged on the model-derived (bias-carrying) 2mFo-DFc map rather than OMIT maps, and a wider-than-typical R-free gap the Expert itself traced back to both — is the same "aggregate metric ≠ discriminating evidence" shape, sharpened by twinning.

The classes also behave *regime-appropriately*: no symmetry or program-guidance leads fired on the cryo-EM case, exactly as they shouldn't. They track the science rather than firing spuriously.

---

## 4. The other half of the picture: what the Expert does well

The good-decision ledger surfaced the Expert performing the **correct version of the very classes it sometimes flubs** — which means these are **consistency gaps, not capability gaps**:

- **nsf-d2-ligand** — ran a *ligand-blind apo baseline*; that map is what refuted the supplied ATP pose. (The exact check that caught its own worst error.)
- **nsf-d2-ligand** — adopted the protein scaffold after a *symmetry-aware contact search* confirmed the files were geometrically matched. (Class 1, done right.)
- **porin-twin** — established a *no-twin baseline as evidence* (R-free 0.2618 vs twinned 0.183 at equal parameters and test set), and corroborated the refined twin fraction of 0.32 against three model-independent xtriage estimators. (Textbook controlled comparison.)
- **beta-blip** — supplied BLIP as a second search component though the prompt named only beta.seq; froze a single R-free set across all six refinement rounds.
- **gene-5-mad** — declined to read the answer-key files (`sites.xyz`, `Facts.list`) that would have trivially resolved a question that later cost most of the run.

A skill built on any of these has a demonstrated positive template inside the Expert's own behavior to point at.

---

## 5. Where this is going

**Endpoint: classes → skills.** Each load-bearing class gets a concrete `SKILL.md` intervention. The design principle the runs suggest: **convert a lucky self-catch into a guaranteed check.** Most errors were self-caught, but often by luck — the checkpoint failure was noticed only because a metric looked suspicious. Hardening the *recovery* targets the dangerous case (an error that would otherwise be missed), not merely the slip.

**Immediate next steps**

1. **Finish the five remaining failure-prone cases** — esterase_tNCS, CASP7-T0283-mr, a2u-globulin-mr, p9-sad, refined_start. These are the recall test: *does a wrong decision that is **not** self-caught reach a final model?* Six cases have not produced one.
2. **Draft skills for the load-bearing classes**, beginning with Class 3 (verify-and-persist), which is universal and has two concrete sub-fixes already identified: repair the Coot `restore_to_backup_checkpoint` pattern (it is molecule-wide — use checkpoint-per-residue or save-to-new-file), and document metric provenance so refine-log and standalone-validator numbers are never silently compared.
3. **Restore a cross-family triage judge.** It is currently same-family with the Expert, and the porin-twin false positive showed triage endorsing a bad lead.
4. **Track false positives explicitly** as a precision measure, alongside the true positives.
5. **Validate the skills** by re-running with them installed and checking whether the targeted class's incidence falls.

**What remains honest and unproven**

- This is a **lower-bound catalogue for expert review**, not a measurement pipeline — no problem-rate is claimed.
- **Recall is unproven.** No self-missed error has yet been shown to reach a final model.
- Single runs are variance-dominated: specific leads shift between runs while the *themes* stay stable — which is precisely the argument for judging classes by recurrence rather than by any one queue.
