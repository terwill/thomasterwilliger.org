# The C3 skill test — result

*Six runs: `porin-twin`, `refined_start`, `a2u-globulin-mr`, each under **A3** (control) and **A3C**
(treatment). The arms differ in exactly one thing: A3C carries the "Verify and persist" block, A3
does not. Both carry arm A's guideline plus the v3 channel rule. Predictions were registered before
the runs.*

**Verdict: not validated. One clear win, one tie where both arms did the right thing, one tie where
neither did.** At n=1 per cell that is suggestive, not demonstrated — and it is a markedly weaker
result than the channel rule, which was 6 for 6.

---

## 1. A measurement error of mine, first

My initial pass reported `both values present = no` in all six runs, which read as a flat null.
**That was wrong.** The check searched for the *original* corpus values (porin-twin 0.158 / 0.2489,
etc.) inside *new* runs that had refined their own models and produced their own numbers. The
discrepancies were present; my script was looking for the wrong digits.

The C3 plan's own §5e says to verify the checker against a case whose answer you already know before
trusting it. I wrote that section and then did not do it. The corrected analysis below is structural
— does the report contain two values for one quantity, each attributed to a tool, with a statement
about their relationship — rather than value-matching.

A second, subtler problem: my `sourced/total` metric **disagrees with the qualitative reading**. On
`refined_start` it scores A3 higher (8/12) than A3C (4/9), yet A3C is the arm that actually performs
the cross-check. Counting lines that carry a filename does not measure whether two instruments were
compared. Treat that column as uninformative.

---

## 2. Results, case by case

### `refined_start` — the skill demonstrably fired

| | A3 (control) | A3C (treatment) |
|---|---|---|
| standalone validators executed | 2 | **7** |
| independent cross-check reported | no | **yes** |

A3C ran a second instrument and stated the comparison:

> `| R-work / R-free (independent) | — | 0.1814 / 0.2365 | DEPOSIT/molprobity_final.log |`
>
> *"The refine log and standalone MolProbity **agree to ≤0.0003** → R-work ≈ 0.181, R-free ≈ 0.237
> is robust."*

And it echoed the instruction's own logic in its reasoning:

> *"Let me **independently confirm** R-free and get full validation with `phenix.molprobity`
> (**different instrument than the refine log**)"*

The skill text reads *"Verify with a different instrument than the one that made the change."* The
phrase is the agent's, and it is doing what the sentence asks. It also caught a validator
disagreement on its own: *"`rotamer_graphs` and Phenix `rotalyze` disagree on A/20 (continuous vs
discrete library)."*

A3 cited two files on one line (`refine_final.log; model_vs_data.log`) but never stated whether they
agreed. Its four "agreement"-flavoured statements are incidental (*"b_ave matches the Wilson B"*),
not instrument cross-checks.

**This is the one case where treatment and control clearly differ, and the difference is traceable to
the text.**

### `porin-twin` — both arms reconcile; the control is arguably better

Both reported twin-target *and* conventional R-factors with source files, and adjudicated.

A3C:
> `R-work / R-free (twin-target, twin law applied): 0.1211 / 0.1503 [refine_twin_final.log] <- authoritative`
> `R-work / R-free (conventional, untwinned):       0.2189 / 0.2395 [molprobity_final.log]`

A3 did the same **and added a caveat A3C lacks**:
> *"R-free rests on the pre-existing (preserved, un-regenerated) free set, which is not
> twin-mate-independent — the small gap (0.026) reflects this, so the twin-target R-free is slightly
> optimistic. **Do not compare twin-target R to untwinned.**"*

The case forces the behaviour: a twinned structure has two legitimate R-factors, so any competent
report must explain which is which. The skill had nothing to add.

### `a2u-globulin-mr` — neither arm does it

Sourcing is poor in both (1 of 15 and 2 of 13 numeric lines carry a source), and **A3C ran fewer
validators than the control** (1 vs 5). These were also the longest runs (172 and 140 tool calls).
The skill did not take here at all, and if anything the treatment arm was worse.

---

## 3. Against the predictions registered in advance

| # | prediction | outcome |
|---|---|---|
| **P1** | A3C's source attribution substantially higher | **not supported** — lower in two of three |
| **P2** | A3C identifies the discrepancy in ≥2 of 3; A3 in ≤1 | **unmeasurable as designed** (my error); structurally: both on porin-twin, A3C only on refined_start, neither on a2u |
| **P3** | A3C adjudicates wherever it identifies | **holds where it applies** — both porin-twin arms adjudicate, A3C adjudicates on refined_start |
| **P4** | A3C runs more standalone validators | **2 of 3 in the predicted direction** (3 vs 1, 7 vs 2), strongly reversed on a2u (1 vs 5) |
| **P5** | porin-twin separates the arms most, a2u least | **wrong** — porin-twin tied; refined_start separated most |

Registering the predictions was worth it: P5 was confidently wrong, and without it written down I
would have narrated the result as though refined_start had been the expected case all along.

---

## 4. Why half the skill could not have worked

The C3 block's provenance clause reads: *"Every numeric result you report must name its source
file."*

The Expert's **base prompt already says**:

> *"**Evidence over assertion**: never report a numerical result (resolution, R-work/R-free,
> map-model CC, FSC, clashscore, Ramachandran/rotamer stats, MolProbity score, etc.) you have not
> read from a tool output or log, **and name its source file**."*

So that clause restates existing policy, and both arms source their numbers because both were already
told to. No effect was possible. This is the same pattern the interaction-mode work kept finding: the
base agent is already doing the thing, and the module demanding it buys nothing but length.

**The instructive contrast with the channel rule.** That rule succeeded (6/6) because it specified
something genuinely absent — *where the artifact goes*. C3's provenance clause specified something
already required. **A rule only changes behaviour if the behaviour is not already policy** — which is
the same test the tutorial's comparator applies to a matrix cell.

---

## 5. What to do

**Cut the skill to the clause that worked.** Drop the provenance sentence; keep the cross-check:

> *Verify with a different instrument than the one that produced the number. When two tools report
> the same quantity, run both and state whether they agree — and if they do not, say which is
> authoritative for this model and why.*

That is the sentence `refined_start`'s A3C quoted back and acted on.

**Then test it properly**, because this test could not settle it:

- **n = 1 per cell.** One win, two ties is not an effect.
- **Two of three cases could not discriminate.** porin-twin forces the behaviour regardless;
  a2u produced it in neither arm. Choose cases where a second instrument is *available and not
  obligatory*.
- **Use a mechanical outcome measure.** Count executed validators and the presence of an explicit
  agreement statement — not lines carrying a filename, which measured the wrong thing.

**And record the a2u reversal as unexplained.** The treatment arm ran one validator where the control
ran five, on the longest pair of runs in the set. Either the skill can suppress validation under some
conditions, or run-to-run variance dominates at this sample size. Both are worth knowing, and neither
is established.

---

## 6. Limits

- Three cases, one run per cell. Variance across repeats of one arm has been large throughout this
  project.
- The measurement was corrected mid-analysis; the structural read is a manual inspection of six
  reports, not a script that could be re-run unchanged.
- `adjudicates` remains a keyword match and is the softest column; treat a hit as a pointer to read
  the passage.
- No claim is made about the artifact-verification or persistence halves of C3. Neither is exercised
  by these cases — they need a tool that silently fails and a crash, respectively.
