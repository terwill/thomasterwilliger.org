#!/usr/bin/env python3
"""
assemble.py — Build a runnable GUIDEME from the base + governance add-ons.

A GUIDEME you hand the agent is one or more governance add-on
modules appended. This lets you (and your students) turn governance
behaviours on one at a time.

Usage:
    python3 assemble.py workflow               # guidance + run log  -> stdout
    python3 assemble.py gated                  # + execution gate
    python3 assemble.py synced                 # + Coot synchronization
    python3 assemble.py scoped                 # + stay in scope
    python3 assemble.py governed               # full governance
    python3 assemble.py gate coot_sync         # an explicit module list
    python3 assemble.py governed --out GUIDEME-mine.md

re-run `python3 assemble.py governed --out GUIDEME-mine.md` and load the result.
"""

import os as _os
import sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
import safe_io  # noqa: F401  survive a non-UTF-8 terminal
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))

RECIPES = {
    # Descriptive names. workflow + run_log ride along in every governed variant.
    # (The "shipped" baseline is NO GUIDEME at all — you just run the expert and
    #  say "do something with the data"; there is nothing to assemble for it.)
    "workflow": ["workflow", "run_log"],                       # guidance + record
    "gated":    ["workflow", "run_log", "gate"],               # + execution gate
    "synced":   ["workflow", "run_log", "gate", "coot_sync"],  # + Coot sync
    "scoped":   ["workflow", "run_log", "gate", "coot_sync",   # + stay in scope
                 "scope"],
    "governed": ["workflow", "run_log", "gate", "coot_sync",   # full governance
                 "scope", "error_handling", "cross_validation"],
}

ORDER = ["workflow", "run_log", "gate", "coot_sync", "scope",
         "error_handling", "cross_validation"]


def read(path):
    with open(path) as f:
        return f.read().rstrip() + "\n"


def assemble(addons, use_solutions=False):
    # Variant Z: no base prompt, no modules — just a "forget everything" opener.
    # This is the true zero of the ladder: what the agent does with NO workflow
    # and NO governance, only the data. Everyone runs it, watches the chaos, and
    # we stop after a few minutes to compare what different students saw.
    parts = []
    # Keep a stable, sensible order regardless of how they were listed.
    ordered = [a for a in ORDER if a in addons]
    for name in ordered:
        src = os.path.join(HERE, "addons", name + ".md")
        if use_solutions:
            sol = os.path.join(HERE, "solutions", name + ".md")
            if os.path.exists(sol):
                src = sol
        if not os.path.exists(src):
            sys.stderr.write("warning: no add-on named '%s' — skipping\n" % name)
            continue
        parts.append("\n" + read(src))
    return "\n".join(parts)


def main():
    args = sys.argv[1:]
    if not args:
        print(__doc__)
        sys.exit(0)

    out = None
    use_solutions = False
    names = []
    i = 0
    while i < len(args):
        a = args[i]
        if a == "--out":
            out = args[i + 1]; i += 2; continue
        if a == "--use-solutions":
            use_solutions = True; i += 1; continue
        names.append(a); i += 1

    addons = []
    for n in names:
        if n in RECIPES:
            addons += RECIPES[n]
        else:
            addons.append(n)
    # de-dup, preserve
    seen = set()
    addons = [a for a in addons if not (a in seen or seen.add(a))]

    text = assemble(addons, use_solutions=use_solutions)
    if out:
        with open(out, "w") as f:
            f.write(text)
        sys.stderr.write("wrote %s (%d add-ons: %s)\n"
                         % (out, len(addons), ", ".join(addons) or "none"))
    else:
        sys.stdout.write(text)


if __name__ == "__main__":
    main()
