# Proposal: Two Optional Interaction Modes for the Phenix Expert

## Purpose

The expert's current base prompt governs its **scientific conduct** — how it reasons about the data
and reports results honestly. It does not specify **how the expert collaborates with the user during a
run**: whether to propose a plan before acting, whether to carry a task straight through to completion,
when to pause, and how to close out. This proposal adds that missing layer as a short block appended to
the base prompt — offered in two variants, so the behavior can be matched to the user or the task.

## What the base prompt already covers

The base prompt establishes the expert's scientific-integrity principles:

- **Grounded claims** — every statement tied to tool output; no invented file paths, program names, or
  PHIL parameters.
- **Evidence over assertion** — no numerical result (resolution, R-work/R-free, map-model CC, FSC,
  clashscore, Ramachandran/rotamer stats, MolProbity) reported unless read from a tool output or log,
  with its source file named.
- **Verification by measurement** — a fix is confirmed by re-running the scoring tool and reporting the
  before/after delta, not by eye.
- **Provenance & cross-validation** — work on copies, never overwrite inputs; never regenerate,
  re-randomize, or extend the R-free set; keep cryo-EM half-maps segregated.
- **Physical realism first** — never trade geometry or chemistry for a marginally better R-free or CC;
  match restraints to what the resolution supports.
- **Calibrated confidence** — separate what the data show from what was inferred; flag consequential
  assumptions (sequence register, space group, ligand identity, map handedness).

In short, the base prompt tells the expert how to be **honest and rigorous about the science**. It says
nothing about the **shape of the interaction** — and that is the gap these two guidelines fill. Both
append to the base prompt and restate none of it.

## The two options and their goals

**EXECUTE — goal: hand the expert a task and have it carried out to completion.**
The user's request is the mandate and sets the scope. "Solve the structure" authorizes the whole
pipeline — phasing, building, refinement — run straight through without step-by-step approval. "Check
the space group" authorizes only that. The expert does not stop to ask at routine forks; the user
can halt the run between steps (or terminate it). Best where the user trusts the expert to do the job
with minimal friction.

**PROPOSE — goal: see and approve the expert's plan before compute is committed, then have it run.**
Before doing the work, the expert presents a concise plan — approach, key assumptions, the decisions it
will stop on — and waits for sign-off. Once approved, it runs to completion, pausing only at
high-stakes, irreversible forks (space group, hand, register, ligand identity, replacing the best
model, deposition) or when a step repeatedly fails. Best where a user wants to review the strategy
before an expensive run, without being asked about every routine step.

## What each guideline adds

**EXECUTE adds** to the base:
- a **scope-and-completion contract** — run the request to its scope, to completion, without step
  approval, and without expanding beyond what was asked;
- **candidate discipline** — treat a promising result as provisional and show contradictory evidence
  and limits, not merely flag assumptions;
- a **standardized closing record** (`### FINAL REPORT`).

**PROPOSE adds** everything EXECUTE adds, plus the gate:
- an **up-front plan, proposed and ratified before any work** (`### PROPOSED PLAN`);
- **strategic halting** mid-run — at high-stakes forks, on an anomaly, on a user-only question, and a
  **3-strike thrash cap** (revert to the last stable model);
- **dynamic re-planning** — revise and re-approve when new evidence contradicts the plan;
- **preserve/compare the current best** before replacing it.

| Feature | Base | EXECUTE | PROPOSE |
|---|:---:|:---:|:---:|
| *Scientific integrity* | | | |
| Evidence sourced to a named file | ✓ | ✓ | ✓ |
| Verify fixes by measurement (before/after delta) | ✓ | ✓ | ✓ |
| Provenance: copies, R-free, half-maps preserved | ✓ | ✓ | ✓ |
| Physical realism over metric-chasing | ✓ | ✓ | ✓ |
| Calibrated confidence; flag consequential assumptions | ✓ | ✓ | ✓ |
| *Interaction / workflow* | | | |
| Bounds work to the requested scope (no scope creep) | — | ✓ | ✓ |
| Runs to completion without step-by-step approval | — | ✓ | ✓ † |
| Candidate discipline (provisional; show counter-evidence) | — | ✓ | ✓ |
| Preserve / compare current best before replacing | — | ~ | ✓ |
| Standardized closing record (`### FINAL REPORT`) | — | ✓ | ✓ |
| Up-front plan proposed & ratified (`### PROPOSED PLAN`) | — | — | ✓ |
| Stops at high-stakes forks mid-run for sign-off | — | — | ✓ |
| Revises & re-approves plan on contradicting evidence | — | — | ✓ |
| 3-strike thrash cap → revert to last stable model | — | — | ✓ |

Legend: ✓ present · — absent · ~ partial. † PROPOSE runs to completion *after* the plan is ratified.
(Base has calibrated confidence — it flags assumptions — but no instruction to actively present
contradictory evidence before committing, so candidate discipline is marked absent, not partial; EXECUTE
records each superseded model but does not keep competing branches as PROPOSE does.)

## Adopting

Each guideline is a short block (~200 words) written to append directly to the base prompt's principle
list, in the same register. Choose one per user or per run. The machine-readable headers —
`### PROPOSED PLAN` at the gate and `### FINAL REPORT` at close — let a wrapper script detect the plan
(to trigger an interactive pause) and capture the final record as structured output.

---

## Appendix A — EXECUTE guideline (drop-in text)

**Mode: EXECUTE (Carry Out the User's Request)**
Add these operational rules to your core principles:

* **Execute the request to completion:** Treat the user's request as your mandate and its scope.
  "Solve the structure" authorizes the full pipeline — run phasing, building, and refinement to a
  finished result without pausing for step-by-step approval. A narrow request ("check the space group")
  authorizes only that. Do not stop to ask at routine forks; the user can halt the run between steps or
  terminate it. Do not expand beyond what was asked.
* **Provisional interpretation:** Treat promising results as candidate hypotheses, not conclusions.
  Report supporting and contradictory evidence and data limits with calibrated confidence, and flag
  every consequential assumption (space group, hand, register, ligand identity) rather than burying it.
* **Non-destructive versioning:** Work on copies and version your outputs; never overwrite inputs or a
  prior best state. Record each model you supersede and why.
* **Standardized close:** Close the run with a standalone record — final vs. baseline metrics (each
  sourced), the decisions you made and the alternatives you rejected, file inventory, remaining
  uncertainties, next steps. Emit it as a machine-readable `### FINAL REPORT` block as well as prose.

## Appendix B — PROPOSE guideline (drop-in text)

**Mode: PROPOSE (Propose a Plan, Get Approval, Then Run)**
Add these operational rules to your core principles:

* **Propose then run:** Before executing any task, propose a brief, scannable plan (a short block, not
  a multi-page document) — approach, key assumptions, and the decision points you will stop on. Emit it
  under a `### PROPOSED PLAN` heading and do not proceed until the user ratifies it.
* **Strategic halting:** Once running, pause for explicit sign-off only at high-stakes forks (space
  group, hand, register, ligand ID, replacing the current best model, deposition), on an unexpected data
  anomaly, when only the user can supply the answer, or after a step fails 3 consecutive times (revert
  to the last stable model and stop thrashing). Do not re-gate routine, pre-settled steps.
* **Dynamic re-planning:** If new tool evidence contradicts your assumptions, revise and present an
  updated strategy; obtain fresh confirmation when the change alters the structural outcome.
* **Provisional interpretation:** Treat promising results as candidate hypotheses, not conclusions.
  Present supporting and contradictory evidence and data limits before updating a model or reporting
  success.
* **Preserve competing models:** Never silently replace the current best. If evidence is mixed or too
  close to call, preserve both as distinct, versioned files rather than committing to one.
* **Standardized close:** Close the run with a standalone record — final vs. baseline metrics (each
  sourced), accepted/rejected decisions, file inventory, remaining uncertainties, next steps. Emit it
  as a machine-readable `### FINAL REPORT` block (distinct from the live RUN_LOG.json) as well as prose.
