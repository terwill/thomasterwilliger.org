# EXECUTE / PROPOSE interaction guidelines — live test on gene-5-mad
### Slide source document (facts, examples, and file pointers for building the deck)

This is written to become slides. Each numbered section maps roughly to one slide or a small
group. Concrete numbers, verbatim quotes, and the file each came from are included so you can pull
any example directly into a slide. Where a quote is marked *(verbatim)*, it is copied from the
run's own report.

---

## 0. One-line takeaway (title slide)

**Two interaction guidelines — EXECUTE and PROPOSE — were run live on a real Se-SAD structure.
Each behaved exactly to its contract, and both produced deposit-quality science. PROPOSE's own
final report shows the agent discovering and correcting a real error in the automated phasing.**

---

## 1. What EXECUTE and PROPOSE are (setup slide)

Two operating guidelines layered on the same base Phenix Expert. They differ in *how the agent
runs*, not in the science it knows.

- **EXECUTE** — carry out the user's request to completion. No plan-gate, no mid-run stops; the
  user halts between steps if they want to. Closes with a final report.
- **PROPOSE** — emit a brief plan under `### PROPOSED PLAN`, get sign-off, then run; halt only at
  high-stakes forks. Closes with `### FINAL REPORT`.

Both inherit the same base principles (evidence over assertion, verify by measurement, preserve
cross-validation, physical realism, calibrated confidence).

**Slide note:** the point of E/P is the *interaction contract*, not scientific ability. The test
below checks two things: (a) did each contract actually behave as designed, and (b) did the
science stay sound under both.

---

## 2. The test case (setup slide)

- **Structure:** Gene V protein (bacteriophage f1), Se-SAD.
- **Data given:** `peak.sca` + `sequence.dat` (peak wavelength only → SAD, not the 3-wavelength
  MAD the example describes).
- **Deposited reference:** 1vqb — 87 residues, deposited R-free 0.20, resolution ~2.6 Å.
- **Runs:** one EXECUTE run, one PROPOSE run (n=1 per mode — see caveat slide).
- **Run locations on disk:**
  - EXECUTE: `runs/gene-5-mad/E/run_1/`
  - PROPOSE: `runs/gene-5-mad/P/run_1/`

---

## 3. Result 1 — each contract behaved exactly as designed (headline slide)

Verified directly from the transcripts (grep of the run trees):

| fingerprint (transcript + run tree) | EXECUTE | PROPOSE | meaning |
|---|---|---|---|
| `PROPOSED PLAN` present | **no** | **yes** | only PROPOSE gates on a plan |
| closing record — where it landed | block **in the response** | file **on disk** (`DEPOSIT/FINAL_REPORT.md`) | both close; neither guideline named the channel |
| ran straight through to deposit | yes | yes (after plan sign-off) | both completed |

**How this was checked (put in speaker notes, not on the slide):**
```
grep -rl "PROPOSED PLAN" runs/gene-5-mad/P/   → hits (session.jsonl, messages.json)
grep -rl "PROPOSED PLAN" runs/gene-5-mad/E/   → NONE
# NOTE: `grep -rl` over the whole tree finds the string in P's transcript AND in the
# file P wrote, so it cannot tell WHERE the record was emitted. Check assistant turns only:
#   "### FINAL REPORT" in assistant output   → E: 2   P: 0
#   test -f DEPOSIT/FINAL_REPORT.md          → E: no  P: yes
```

**Slide line:** "The plan-gate appears in PROPOSE's transcript and is absent from EXECUTE's, as
designed. But both were told only to *close with a standardized record* — neither guideline said
WHERE it goes, so each picked a different channel."

**Follow-up worth a slide:** the guideline was rewritten to require **both** channels (block in the
response *and* `DEPOSIT/FINAL_REPORT.md`). Six later runs across three refinement cases then produced
both — **6 for 6**. It is the only place in this work where a policy edit was written, measured, and
confirmed.

---

## 4. Result 2 — both produced deposit-quality science (headline slide)

Side-by-side final models. Deposited reference R-free = 0.20 (1vqb).

| metric | EXECUTE | PROPOSE | deposited |
|---|---|---|---|
| residues built | 84 / 87 (A2–A85) | 84 / 87 (A2–A85) | 87 |
| unmodelled | 1, 86, 87 (disordered) | 1, 86, 87 (disordered) | — |
| **R-work** | **0.1472** | **0.1606** | — |
| **R-free** | **0.2385** | **0.2154** | 0.20 |
| reflections in refinement | 2633 (9.99% free) | 4956 (10.07% free) | — |
| MolProbity | 1.49 | 1.60 | — |
| clashscore | 3.76 | 3.00 | — |
| Rama favored / outliers | 98.78% / 0.00% | (favored, 1 outlier A/20) | — |
| R-free set integrity | own set, unchanged through pipeline | own set, **verified byte-identical**, unchanged | — |
| R-free set identity | **independent** (separate AutoSol draw) | **independent** (separate AutoSol draw) | — |

**Sources (authoritative — from the refine logs, not the prose summaries):**
- EXECUTE R-values: `runs/gene-5-mad/E/run_1/DEPOSIT/logs/05_refine_FINAL.log`
  → "Final R-work = 0.1472, R-free = 0.2385" (n_refl = 2633, 9.99% free)
- PROPOSE R-values: `runs/gene-5-mad/P/run_1/DEPOSIT/logs/4_refine_final_v5.log`
  → "Final R-work = 0.1606, R-free = 0.2154" (n_refl = 4956, 10.07% free)
- Full summaries: `E/.../README_RUN_SUMMARY.txt`, `P/.../FINAL_REPORT.md`

**IMPORTANT — the two R-free values are NOT comparable, for a basic reason: E and P have
different free-R test sets.** E and P are separate AutoSol runs, and AutoSol generates a fresh
random ~10% R-free set each time. So each run drew its **own independent test set** over the same
reflections — the held-out reflections themselves differ between E and P. R-free 0.2154 (P) and
0.2385 (E) are therefore computed against **different samples of the data** and cannot be ranked.

(An earlier draft of this note claimed the sets were "the same, just expanded" — that was wrong;
the free selections are independent. The reflection count also differs because P refined anomalous
data with I(+)/I(−) mates separate while E refined merged amplitudes, but the free-set difference
alone is already sufficient reason not to compare the two R-free values.)

Each run is internally consistent on cross-validation: **P verified its own AutoSol-inherited
R-free set byte-identical through its pipeline** (never regenerated/extended), and E likewise
carried its set unchanged — that discipline holds *within* each run; it is not a claim that E and P
share a set (they don't).

**At n=1 with independently-generated test sets, the honest statement is:** both landed near the
deposited R-free of 0.20 with clean geometry — not that one out-performed the other.

**Slide line:** "Both deposit-ready, both near the deposited R-free of 0.20 with clean geometry.
The choice of interaction guideline did not cost scientific quality." *(Do not rank them on R-free —
E and P used different, independently generated free-R sets.)*

---

## 5. Result 3 — the live run confirms what the paper screens could only suggest (the money slide)

Three earlier "prose" evaluation screens (~65 described decision scenarios, graded by a
three-model panel) found the Expert's crystallographic reasoning sound and its calibration robust.
But every prose screen carried the same caveat: *it can't show the agent discovering a problem in a
real map or executing the tools.* **The PROPOSE run's own report closes that gap.** Four concrete
behaviors, all from `runs/gene-5-mad/P/run_1/DEPOSIT/FINAL_REPORT.md`:

### 5a. It discovered and corrected an error in the automated phasing *(verbatim)*
> "I corrected AutoSol's substructure. It refined 4 Se sites, but a model-independent clustering
> of the anomalous difference map shows only **two** real sites: one at 27.6 σ (Met77) and one at
> ~7.8 σ (Met1), against a Cα control max of 1.90 σ. Z/1, Z/3 and Z/4 are over-split fragments of a
> single selenium. Two Se per ASU is exactly what the sequence predicts."

**Why it matters (slide bullet):** AutoSol reported 4 selenium sites; the agent independently
re-derived the anomalous map, found only 2 real ones, explained the other 3 as fragmentation, and
cross-checked against the sequence's expected 2 Se. This is discovery from real data, not a
described scenario.

### 5b. It reported its own failed attempts honestly *(verbatim)*
> "I'll note I got this wrong twice before getting it right: my first hand-rolled anomalous Fourier
> was buggy (gave ~0 σ at all Se), and I then floated a 'four sites = two Met × two alt conformers'
> hypothesis that the peak search disproved. The reported conclusion rests on the direct grid
> clustering, which is internally consistent with the per-atom sigma values."

**Why it matters (slide bullet):** transparent self-correction — it surfaced two wrong turns and
grounded the final claim in the method that actually worked, rather than presenting a clean story.

### 5c. It refused to over-fit — twice *(verbatim)*
> "one earlier refinement dropped R-work to 0.1418 while R-free *rose* to 0.2458 — I discarded that
> as over-fitting rather than reporting the lower R-work."

and, on a genuinely ambiguous residue:
> "The primary model has better R-free... but one Ramachandran outlier at A/20 SER; the alternative
> has zero Rama outliers but clashscore 5.26 and R-free 0.2210. A Coot pepflip fixed A/20, but
> phenix.refine reverts it — the data prefer the strained conformation, and the density in residues
> 19–21 is too weak (Arg21 side chain 0.2–0.5 σ) to discriminate. I did not force a choice."

**Why it matters (slide bullet):** it preserved cross-validation over a better-looking headline
number, and held two competing models rather than forcing a choice the data couldn't support —
calibrated uncertainty on real evidence.

### 5d. It named the real scientific ceiling *(verbatim)*
> "The clearest path to a better structure is the one thing the instructions ruled out: infl.sca
> and high.sca are sitting unused, and full MAD phasing would improve substantially on the 46°
> experimental phase error."

**Why it matters (slide bullet):** honest about the limit of what it was allowed to do — it used
peak-only SAD as instructed and flagged that the withheld wavelengths would have done better.

---

## 6. What the E/P guidelines accomplish (summary slide)

- **A real choice of working style with no science penalty.** EXECUTE for hands-off completion;
  PROPOSE for a review-before-run workflow. Both delivered the same deposit-quality model.
- **The contract is enforced and visible.** PROPOSE actually proposes (plan-gate in the
  transcript); EXECUTE actually runs through. Confirmed, not asserted.
- **The base scientific discipline holds under both.** Cross-validation preserved (P verified the
  R-free set byte-identical), over-fitting rejected, disordered residues honestly omitted, and the
  agent stayed calibrated on genuinely ambiguous evidence.
- **Live behavior matches the prose-screen findings.** What ~65 described scenarios suggested about
  reasoning and calibration showed up in actual tool-driven work on a real map.

---

## 7. Honest caveats (the slide that makes it credible)

- **n = 1 per mode for E and P; SHIPPED is now n = 4.** Single runs are variance-dominated, and the
  shipped repeats show how much: MolProbity **1.71 / 1.70 / 1.10 / 1.89** and residues
  **84 / 76 / 84 / 79** on the same case. No trend — scatter dominates.
- **Harness fairness, tested directly.** E and P carried a wrapper prefix (*"proceed as if I said
  'use defaults or your recommendation'"*) that the original S did not. S was re-run three times
  with it: the prefix does **not** suppress rigor (the best model of all four came from a prefixed
  run), and it **converts an escalation into a caveat** — *"One thing needs your call"* (asks)
  becomes *"One honest caveat (A24 LYS): …"* (states and proceeds). The harness governs whether the
  agent halts, not whether it notices, so the comparison is robust to it. This shows each mode **can** produce excellent science on-contract;
  it does **not** rank EXECUTE vs PROPOSE, and no R-free difference of a few thousandths between
  them is meaningful at n=1.
- **"Regression vs baseline" flags on EXECUTE's interaction items should be ignored** — EXECUTE
  scoring "no" on propose-and-wait behaviors is by design, not a regression.
- **Still a single case.** One structure, one data type (Se-SAD). Breadth (more cases) and
  replication (more reps) are the honest next step if a *ranking* or a regression gate is wanted.
- **The report is the agent's own account.** The numbers (R-free, MolProbity, residue count) are
  from tool logs and are trustworthy; the narrative of self-correction is the agent's telling of
  its own process — believable and internally consistent, but it is a self-report.

---

## 8. Where to pull more examples (appendix / speaker-notes pointers)

- **EXECUTE full summary:** `runs/gene-5-mad/E/run_1/DEPOSIT/README_RUN_SUMMARY.txt`
  (pipeline steps, final model stats, experimental map CC progression 0.541 → 0.705 → 0.946,
  R-free provenance statement).
- **PROPOSE full report:** `runs/gene-5-mad/P/run_1/DEPOSIT/FINAL_REPORT.md`
  (all four 5a–5d examples; phasing detail; the two-model preservation).
- **PROPOSE alternative model kept on purpose:**
  `runs/gene-5-mad/P/run_1/DEPOSIT/alternative_model/gene5_alt_v3.pdb`
- **Per-run logs (both):** `.../DEPOSIT/logs/` (xtriage, autosol, autobuild, refine, molprobity).
- **Superseded/rejected branches (EXECUTE):** `runs/gene-5-mad/E/run_1/DEPOSIT/superseded/`
  (rejected alternatives with reasons in the filenames — good for a "what it chose not to do" slide).
- **Contract fingerprint evidence:** the `grep` commands in section 3, run against
  `runs/gene-5-mad/{E,P}/run_1/session.jsonl`.

---

## 9. Experimental map quality (optional detail slide — from EXECUTE README)

Shows the phasing actually worked, measured against the final model rather than asserted:

| stage | CC_mask vs final model | note |
|---|---|---|
| raw SAD phases (Phaser) | 0.541 | FOM 0.435 |
| after RESOLVE density modification | 0.705 | AutoSol BAYES-CC 0.44 |
| final refined 2mFo-DFc | 0.946 | — |

PROPOSE's report gives the phase-error version of the same story: mean phase error 51.1° →
46.2° after density modification (random = 90°), experimental DM map-model CC 0.766 — "marginal but
genuinely interpretable," which correctly predicted that AutoSol's direct build gave only 45
fragmented residues while iterative AutoBuild reached 84.

---

## 10. How E/P differ from shipped (S) — the contrast that says what the guidelines add

**Why S is here, and why it's NOT in the E-vs-P tables.** S is the shipped agent with **no
interaction guideline** layered on. The E-vs-P comparison answers "do the interaction guidelines
work?" — S is a *different variable* (no contract at all), so it does not belong in the
deposit-quality table (section 4), where three non-comparable R-frees would invite a science
ranking at n=1. S belongs in a **contrast** role: it's the baseline that shows what E and P *add*.

**The honest framing: S already does the science; E/P add a defined interaction contract.** On
gene-5-mad, S ran to completion and produced a deposit-quality model — so the difference is not
"E/P build better structures." The difference is that S's *interaction behavior is undefined*,
while E and P make it an explicit, verifiable contract.

### 10a. What S does (from a real shipped run, `shipped_5.md`)
- Runs and reaches deposit quality: **84 residues, R-work 0.1877 / R-free 0.2363** (Table 1).
- Closes with a **substantial free-form prose report** — a sourced evidence chain, a metrics table
  with a Source column, an explicit R-free provenance statement, and honest omissions. Verified in a
  second shipped run: the string `Table 1` **never appears**. The contrast is *format and
  auditability*, not quality.
- **No `### PROPOSED PLAN`, no `### FINAL REPORT`** — verified by the same greps used on E/P:
  `grep -in "proposed plan" shipped_5.md` → none; `grep -in "final report" shipped_5.md` → none.
- So its interaction is uncontracted: no plan-gate, no structured report narrative.

### 10a-bis. What S does UNPROMPTED — the evidence for "S already does the science"

Four behaviours from a shipped run with no interaction guideline. **No contract asked for any of
them** — this is the strongest support for §10's framing and belongs on its own slide.

*Precision worth keeping in the speaker notes:* two of the four go beyond anything in the base
prompt (the circularity guard, the escalation). The other two are the base prompt's own principles
being honoured without a contract — it does require *"never regenerate, re-randomize, or extend the
R-free set"* and evidence sourcing. The point stands either way: **no interaction guideline asked for
any of it**, and E and P did less of it.

> **Guarded against circular reasoning.** *"The final model correlates with that map at CC = 0.729 …
> That map's phases don't derive from the deposited model, **so this is not circular**."*
>
> **Escalated an ambiguous call, unprompted.** *"## One thing needs your call … Refining with rotamer
> restraints removes all of them but costs R-free: 0.208 → 0.230. I tried four routes; every
> restrained one lands at ≈0.230 … those 4 side chains score within 0.02 CC either way, so the
> density at 2.6 Å genuinely can't distinguish them."*
>
> **Stated its cross-validation provenance.** *"The R-free set was made once by AutoSol and never
> regenerated."*
>
> **Tied its evidence to density, not to the model.** *"Completing the side chain in Coot put SE into
> 3.85σ density."*

It also ran **more Phenix jobs and more standalone validation than either contracted mode** —
verified by counting executions, not mentions:

| | phenix jobs | standalone validator runs |
|---|---|---|
| SHIPPED (no guideline) | **20** | **7** |
| EXECUTE | 14 | 3 |
| PROPOSE | 18 | 1 |

and it attempted `phenix.fit_loops`, which EXECUTE never did.

**Slide line:** "The guidelines do not add scientific care. They make existing care contracted,
uniform and machine-checkable."

### 10b. Three-way interaction table (behavior axis — NOT a science ranking)

| interaction behavior | SHIPPED (S) | EXECUTE | PROPOSE |
|---|---|---|---|
| Plan-gate before running | none | none (by design) | yes |
| Runs to completion unattended | yes | yes | after sign-off |
| Closing record — where | prose only | block in response | file on disk |
| Rejected work retained | discussed in prose | **recorded** (`superseded/` + reasons) | **branch kept** (competing models) |
| Interaction is contracted | no | yes | yes |

**Slide line:** "All three reach deposit quality on gene-5-mad. What E/P add over shipped is a
predictable interaction contract — not a better structure. S runs and deposits, but you can't
predict or audit how it will interact; E and P make that behavior a contract."

**Caveat to keep honest:** the S cells are grep-verified for *this* shipped run (no PROPOSED PLAN,
no FINAL REPORT; closed with Table 1). "none/no" means **not contracted by a guideline**, confirmed
absent in this run — not that S is incapable of those behaviors. The "runs unattended: yes" cell
rests on this single run and on design intent; a couple more shipped runs would firm it if it
becomes a load-bearing claim about S in general.

**Source:** `shipped_5.md` (the shipped run); R-values from its Table 1
(R-work 0.1877, R-free 0.2363, 84 residues, 2633 refl).
