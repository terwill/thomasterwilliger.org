# Building complete provenance for a deck

*A method, written from doing it once properly. The worked example was a 20-slide presentation on
an AI agent's crystallographic decisions, backed by ~200 files of run artifacts. Everything here
was learned by getting it wrong first; the traps section is the part worth reading twice.*

---

## 1. The standard

A deck has **complete provenance** when both of these hold:

1. **Every figure and every quoted string resolves to a named file and a locatable entry** — not
   "from the run logs" but `runs/gene-5-mad/A/run_1/artifacts/self_analysis.md`, entry D16.
2. **A script re-derives it from that file**, and the script runs against a clean extract of the
   archive with no access to anything else.

The second condition is what makes it provenance rather than a bibliography. A document that
*names* sources is a claim; a script that *reproduces* the numbers from them is a check. Until you
run the check, you don't know which of your claims are true — and in our case four of them weren't.

A useful third condition, which costs almost nothing once you have the first two:

3. **The archive states what it cannot verify**, explicitly, so nobody can mistake silence for
   confirmation.

---

## 2. What you build

| artifact | what it is |
|---|---|
| **traceback.md** | the authority: every figure and quotation on every slide, its file, its entry, and the command that reproduces it |
| **checkers** | scripts that re-derive the numbers and match the quotations against the tree |
| **the archive** | deck + traceback + all source data + the scripts + a reproduction guide, packed so it verifies from a clean extract |
| **findings/** | the audit trail — what was checked, what was wrong, what changed and why |

The findings directory matters more than it looks. When a number moves — and one of ours moved four
times — the record of *why* is what stops it moving back.

---

## 3. The procedure

### Step 1 — Inventory mechanically, not by reading

Extract every numeric token and every quoted span straight from the `.pptx`, per slide. Do not
work from your memory of the deck or from the source markdown; work from the shipped file.

```python
# slides in presentation order, with their text
z = zipfile.ZipFile(pptx)
rel = dict(re.findall(r'Id="([^"]+)"[^>]*Target="(slides/slide\d+\.xml)"',
           z.read('ppt/_rels/presentation.xml.rels').decode()))
order = re.findall(r'<p:sldId[^>]*r:id="([^"]+)"',
           z.read('ppt/presentation.xml').decode())
text = ' '.join(re.findall(r'<a:t>(.*?)</a:t>', z.read('ppt/' + rel[rid]).decode(), re.S))
```

Then **separate figures from labels**. Card numbers, step numbers, page numbers and list ordinals
are not claims. Everything else is. Expect the inventory to be larger than you think — ours was 116
numeric tokens and 15 quotations across 20 slides.

### Step 2 — Write the traceback before verifying anything

One section per slide. For each figure: what it claims, which file, which entry, and the command.
Write it even where you are sure. The sections you skip because "that one's obvious" are where the
gaps turn out to be — ours were the constant repeated in every footer, and a whole slide whose
figures came from a different body of work than the rest of the deck.

Include a **constants** section for anything that appears throughout (the dataset count, the date
range). It will otherwise belong to no slide and get audited by nobody.

### Step 3 — State the quotation convention explicitly

A quotation mark is a claim that the words are verbatim. Write down exactly what may change:

> Quotation marks mean verbatim from the named artifact, with three things allowed to change:
> elision (always marked with …), formatting (markdown emphasis, line wrapping), and enclosing
> quote style. Anything in our own words is not in quotation marks.

Then add a fourth allowance only if you must, and make the checker *report* it rather than hide it.
We allow terminal punctuation on a fragment quoted as a sentence, and the checker prints `OK(p)`.

If your deck has tables that paraphrase, say so: *"the tables on slides 10–15 are paraphrase; the
source sentence for each row is quoted in this document instead."* Otherwise a reader will assume
the rows are quotations and be right to complain.

### Step 4 — Build the checkers

Three, in increasing specificity:

**`check_quotations.py`** — extract every quoted span, normalise, and search the whole tree.
Normalisation is where this gets subtle; see trap 4.

**`check_numbers.py`** — recompute the aggregates **from the primary artifacts, not from the
roll-up file**. If the deck says 97 decisions in a 75/13/3/4 split, sum the per-case ledgers
yourself. That makes the check independent of the summary, so it catches errors in the summary too.

**`check_details.py`** — every individual figure, checked **in context**. See trap 1; this is the
one people skip and it is the one that finds things.

Wire them into one driver that exits non-zero if anything fails.

### Step 5 — Run them and fix what breaks

Expect failures. Ours found: a quotation that existed in no file, two more that had been reworded
inside quotation marks, a count that was wrong, and — on the final clean-room pass — a claim about
the data that was the opposite of true.

When a check fails, **do not adjust the check until you have established which side is wrong.**
Twice I "fixed" a checker that was correctly reporting a real problem.

### Step 6 — Pack, and verify from a clean extract

```
archive/
  deck/            the pptx
  provenance/      traceback.md + findings/
  data/            every source file, in its original tree structure
  scripts/         the checkers, plus helpers
  README.md        entry point
  REPRODUCE.md     how to reproduce each figure, written for whoever reads it next
```

Then extract it somewhere fresh and run the driver **using nothing else**. Not your working
directory, not the files still open in your editor. This is not ceremony: our clean-room pass is
what surfaced the last and worst error, because it forced every claim through the archive.

### Step 7 — Write down what you could not verify

Ours ended with exactly one: a crystallographic fact from a reference work, which no archive of run
artifacts could ever contain. Saying so plainly is stronger than leaving it unmentioned — it tells
the reader that everything else *was* checked.

---

## 4. The traps

Every one of these cost us a wrong answer.

### Trap 1 — A bare number match is not verification

We tried to verify 116 numeric tokens by searching the data for each number. The digit `4` appeared
in 154 of 160 files; `11` in 112. The sweep "passed" everything and proved nothing.

**Bind every figure to the words that give it meaning**, in the file the traceback names:

```python
find(11, "3.1 A cutoff handed over and ignored", review_queue('gene-5-mad'),
     '3.1', 'ignored', 'xtriage')          # all three within 400 characters
```

### Trap 2 — Identifiers that look stable but aren't

This is the deep one. It bit us three times in three disguises:

- **Lead numbers.** A slide cited "flagged decisions 5 and 13" from a queue that was later
  regenerated; it now has 12 leads and no such critique. **Cite by content, never by position.**
- **Random-hex directories.** A report sorted `molprobity_<hash>/` directories *by path*, which is
  sorting by a random hash, and reported whichever came first alphabetically. It happened to be a
  model the run had explicitly rejected.
- **Filenames that change on copy.** Models are renamed on the way into a deposit directory
  (`beta_blip_006.pdb` → `beta_blip_final.pdb`), and the copy may use a shell variable
  (`cp $R/... $DEP/...`) so a search for the literal destination path misses it entirely.

**Bind to something durable**: the content, the entry text, the copy command — not the ordinal, the
hash, or the current filename.

### Trap 3 — Two numbers only disagree if they describe the same object

Our worked example's central bug. A report compared metric X from tool A against metric X from tool
B and called every difference a disagreement — without checking that both described the same model.
Some pairs were an input model against a final one; a 0.05 gap there is refinement working, not
validators disagreeing.

**Whenever you compare two measurements, verify they describe the same object, and print what each
one describes.** Make the tool refuse to assert a disagreement it cannot substantiate:

```
[DIFFERENT MODELS - MolProbity ran on beta_blip_002.pdb ... NOT a tool disagreement]
[MODEL UNVERIFIED - the two numbers may describe different structures]
```

Nothing disappears silently and nothing is silently wrong.

### Trap 4 — Escaped text will not match

Event and session records are usually JSON with `ensure_ascii=True`, so an em dash is stored as the
seven characters `\u2014` — sometimes double-escaped. Without decoding, **every quotation containing
a typographic character silently fails to match**, and you conclude the deck is wrong when it isn't.

Decode `\uXXXX` (one *or more* backslashes), then `\n`, `\t`, `\"`, then strip residual backslashes,
then normalise markdown emphasis, quote style and whitespace. In that order.

### Trap 5 — Degenerate search terms

One comparison was "0 versus 0.87". Searching for the literal `"0"` matched nearly every line and
returned the opposite of the truth. **When one side of a comparison is zero — or any very common
token — search the field name, not the value.**

### Trap 6 — Looking in one place

We tested "did the run ever reconcile these two numbers?" by searching its *closing report*. It
hadn't. The reconciliation was sitting mid-transcript, with the cause diagnosed and the authority
declared. The deck carried a false claim for several rounds because the test was narrow.

**Search the whole record, then read the surrounding sentence.** Pattern-matching a number tells you
where it is; only the sentence tells you what it means.

### Trap 7 — Completing a truncated quotation by inference

A roll-up truncated a sentence at `only rotamer-l…`. Fixing the slide, I completed it as
"polishing". The real word was "Coot passes". **Fixing a fabricated quotation by inferring the rest
is the same error in a smaller coat.** Quote only as far as the source you have, and mark the
elision.

### Trap 8 — Working documents go stale inside the archive

Our project's own interim report contains a figure that a later fix reduced by half. It sits in the
archive as primary material — and a future reader, human or model, will find a confident number in
a project document and use it.

**Put a `READ_THIS_FIRST.md` in front of any working documents you include**, naming each superseded
figure and its correction. Do not silently delete them; the record is worth keeping and the warning
is what makes it safe.

### Trap 9 — Reporting a summary instead of the thing

An early roll-up collapsed several distinct concerns into one and made two adjacent items look like
independent corroboration. Where your deck leans on *agreement between sources*, verify the sources
are actually independent and actually about the same thing.

---

## 5. Grade your evidence

Not all sources are equally strong, and a good traceback says which is which. Ours, in descending
order:

1. **Deterministic scripts with no model in the loop.** Reproducible exactly.
2. **The event record** — what was actually done and said, in order.
3. **Self-report** — an agent grading its own work, correlated with the work.
4. **Hand assignment** — a taxonomy someone applied by reading. A judgement, not a count.

State the ranking in the traceback, and say on the slide itself when a figure is category 4. Ours
does, and it means the one soft number in the deck is the one we volunteer rather than defend.

---

## 6. Expect claims to move, and version them

One figure in our deck went **6 → 7 → withdrawn → 4 → "4 confirmed, at most 6"**. That is not a
failure of the process; it is the process working. What matters:

- **Never silently change a number.** Each move got a dated findings document saying what changed
  and why.
- **When a claim becomes unsafe, pull it rather than soften it.** We removed the count entirely for
  two rounds rather than show a number we could not defend.
- **Don't re-assert from a prediction.** When the evidence pointed at a corrected value, we waited
  for the regenerated file before putting it back on the slide.
- **A number that moved is more trustworthy than one that never did** — provided the movement is
  documented. The final figure is the only version anyone can check.

---

## 7. A useful side effect

Verifying a deck about tools produces findings about your own tools. Ours turned up a real bug in
the report generator, and the bug was *precisely* the failure the deck accuses its subject of:
reporting a tool's output without checking what it described. The generator's own docstring stated
the rule for the analogous case and had not applied it here.

Budget for this. The provenance pass is not only a check on the slides — it is often the most
rigorous review the underlying pipeline has ever had.

---

## 8. Checklist

- [ ] Every figure and quotation extracted mechanically from the shipped `.pptx`
- [ ] Labels separated from claims
- [ ] Traceback written, one section per slide, plus a constants section
- [ ] Quotation convention stated, including what may change
- [ ] Paraphrase declared where tables restate rather than quote
- [ ] `check_quotations.py` — with escape decoding
- [ ] `check_numbers.py` — recomputed from primaries, not from roll-ups
- [ ] `check_details.py` — every figure bound to its context
- [ ] One driver, non-zero exit on any failure
- [ ] Every comparison verified to describe the same object
- [ ] Evidence graded, and category-4 figures flagged on the slide
- [ ] Archive packed with data in its original tree structure
- [ ] **Verified from a clean extract, using nothing else**
- [ ] Superseded figures in included working documents flagged in a `READ_THIS_FIRST`
- [ ] What could not be verified, stated plainly
- [ ] `REPRODUCE.md` written for whoever reads it next — including a model
