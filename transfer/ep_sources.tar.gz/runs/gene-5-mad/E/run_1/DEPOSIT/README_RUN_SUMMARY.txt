Gene V protein (bacteriophage f1) — Se-SAD structure solution
=============================================================
Run date: 2026-07-20
Inputs used (as specified): peak.sca, sequence.dat
NOTE: only the peak wavelength was used -> this is SAD, not the 3-wavelength
MAD the shipped example .eff file describes. high.sca / infl.sca were NOT used.

PIPELINE
  1. phenix.xtriage        data assessment          logs/01_xtriage.log
  2. phenix.autosol        Se-SAD phasing (HySS -> Phaser -> RESOLVE DM)
                                                    logs/02_autosol_sad.log
  3. phenix.autobuild      iterative build + DM     logs/04_autobuild.log
  4. Coot                  side-chain completion (TYR41, MET77), rotamer/geometry review
  5. phenix.refine         final refinement         logs/05_refine_FINAL.log
  6. phenix.molprobity     validation               logs/06_molprobity_FINAL.log

FINAL MODEL: gene5_final.pdb / gene5_final.cif
  Space group C2, cell 76.08 27.97 42.36 90 103.2 90, 1 molecule/ASU
  Resolution 21.33 - 2.59 A
  84 residues modelled (A2-A85), 100% sequence agreement, 34 waters, MSE77
  Not modelled: residues 1, 86, 87 (disordered - see report)
  R-work 0.1472 / R-free 0.2385  (test set 10.02%, 264 reflections, frozen from AutoSol)
  MolProbity 1.49; clashscore 3.76; Rama 98.78% favored / 0.00% outliers
  rotamer outliers 2.70% (LEU32, GLU40 - both density-supported, non-rotameric)
  RMS bonds 0.0100 A, angles 1.10 deg; C-beta deviations 0

EXPERIMENTAL MAP QUALITY (CC_mask vs final model)
  raw SAD phases (Phaser)          0.541   (FOM 0.435)
  after RESOLVE density mod        0.705   (AutoSol BAYES-CC 0.44)
  final refined 2mFo-DFc           0.946

FILES
  gene5_final.pdb/.cif             final model
  gene5_final_map_coeffs.mtz       final 2mFo-DFc + mFo-DFc
  gene5_data_phases_freeR.mtz      Fobs + experimental HL phases + FreeR_flag
  gene5_structure_factors.cif      structure factors (mmCIF)
  experimental_sad_phases.mtz      raw experimental SAD phases
  experimental_denmod_map_coeffs.mtz  density-modified experimental map
  se_substructure_autosol.pdb      AutoSol Se substructure (4 sites; only site 1 is real)
  superseded/                      rejected alternatives, with reasons in filenames
  logs/                            all run logs, including rejected branches

R-FREE PROVENANCE: the test set was generated once by AutoSol and carried
unchanged through AutoBuild and all refinements. It was never regenerated
or extended.
