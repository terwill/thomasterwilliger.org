# Bacteriophage f1 Gene V protein — Se-Met SAD structure solution

Run date: 2026-07-20. Inputs: `peak.sca`, `sequence.dat` (87 residues).
Method: single-wavelength anomalous diffraction (SAD) from the peak dataset only.

---

## 1. Data quality  (source: `logs/1_xtriage.log`)

| Quantity | Value |
|---|---|
| Space group | C 1 2 1 |
| Unit cell | 76.08, 27.97, 42.36 Å; 90, 103.2, 90° |
| Resolution range | 21.33 – 2.594 Å |
| Overall <I/σI> | 29.9 |
| Wilson B | 25.74 Å² |
| Matthews coeff. / solvent | 2.24 Å³/Da / 45.2 %, **1 copy per ASU** (P = 1.000) |
| Twinning | None detected (L-test normal; no merohedral twin laws) |
| Pseudotranslation | None (largest off-origin Patterson peak 12.6 % of origin) |
| Anomalous measurability (max) | 0.367 |
| Anomalous signal extends to | ~3.1 Å (optimistic 2.9 Å) |

Data are strong and clean; anomalous signal is well above the SAD threshold.

## 2. Selenium substructure and experimental phasing  (source: `logs/2_autosol.log`, `phasing/AutoSol_summary.dat`)

`phenix.autosol`, SAD mode, Se, f' = −3, f" = 4.

- Best solution (#5): **BAYES-CC 44.2 ± 24.1**, **FOM 0.43**, 4 Se sites placed.
- **Hand determination** — two independent metrics agree and are decisive in relative terms:
  - Density-modification R-factor: **0.311** (solutions 2/3/5/6) vs **0.345** (inverse hand, 1/4/7/8)
  - BAYES-CC: **~0.44** vs **~0.15**
- AutoSol's own build was thin: 45 residues, 7 chains, map-model CC 0.593, R/R-free 0.40/0.48.

### Anomalous difference Fourier — independent verification (this work)

An anomalous difference map was computed from the refined model (ANOM/PANOM coefficients).
Direct, symmetry-aware clustering of all grid points > 8 σ gives:

| Site | Peak height | Assignment |
|---|---|---|
| 1 | **27.6 σ** | Met77 selenium (0.66 Å from the built MSE77 SE) |
| 2 | **~7.8 σ** | Met1 selenium — N-terminal Met, disordered, not traced |

Control: protein Cα atoms max 1.90 σ; Cys33 SG 3.1 σ (intrinsic S signal).

**Correction to AutoSol's substructure:** the four Se sites AutoSol refined
(occ 0.76 / 0.47 / 0.30 / 0.68) are an over-split representation. Sites Z/1, Z/3 and
Z/4 are fragments of the *single* Met77 selenium (they lie 1.2–3.6 Å apart around one
27.6 σ peak); Z/2 corresponds to the weaker Met1 site. Two Se per ASU is exactly what
the sequence predicts (2 Met, 1 copy/ASU). The redundant sites were removed and Met77
was rebuilt as MSE with its SE on the anomalous peak.

### Experimental map quality (measured against the final model)

| Metric | Value |
|---|---|
| Mean figure of merit (AutoSol) | 0.432 |
| Mean phase error, SAD phases before DM | 62.9° (unweighted); **51.1° (FOM-weighted)** |
| Mean phase error, after density modification | **46.2°** |
| Map-model CC, experimental DM map vs final model | **0.766** |
| Map-model CC, final refined 2mFo-DFc map | 0.950 (model-phased, partly circular) |

Interpretation: the experimental map was **marginal but genuinely interpretable**.
Density modification improved the mean phase error by ~17° (62.9° → 46.2°; random = 90°).
A ~46° phase error is exactly the regime that yields a partial initial trace requiring
iterative build/density-modification cycles — which is what was observed.

## 3. Model building  (source: `logs/3_autobuild.log`)

`phenix.autobuild` starting from the AutoSol solution, iterating build ↔ DM ↔ refine:

| Cycle | R / R-free | Residues built | Sequence-placed | Map-model CC |
|---|---|---|---|---|
| 2 | 0.22 / 0.30 | 74 | 65 | 0.76 |
| 3 | 0.18 / 0.26 | 81 | 72 | 0.80 |
| **4 (best)** | **0.15 / 0.24** | **84** | **84** | **0.81** |
| 5 | 0.16 / 0.24 | 84 | 84 | — |

## 4. Rebuilding (Coot) and final refinement

Interactive rebuilding in Coot, each change accepted only on measured improvement:

1. **Met77 side chain built** (was truncated at CB). The new SD landed on 24.6 σ
   anomalous density — better placed than AutoSol's own Se site (10.8 σ). Converted
   MET → **MSE** (Se replaces S; correct for a Se-Met protein and a large scattering difference).
2. **Redundant Se removed** (Z/1, Z/3, Z/4) — all fragments of the single Met77 selenium.
   Z/2 retained as a partial-occupancy Se marking the disordered Met1.
3. **Rotamer repairs**: A/6 ILE, A/32 LEU, A/51 GLU, A/22 GLN. Changes to A/12, A/21,
   A/24, A/72, A/75 were **reverted** because side-chain density fit worsened.
4. **Water audit**: 5 of 35 waters removed (density < 1.0 σ).
5. **Pepflip at A/19** fixed the A/20 SER Ramachandran outlier
   (probability 1.2×10⁻⁵ → 0.028) while also improving local CC (0.723 → 0.732).
   *Note: subsequent `phenix.refine` pulled A/20 back to the outlier conformation.*

Final refinement used `refinement.main.rotamer_restraints=True`; without it, refinement
degraded rotamer outliers from 1.37 % to 5.41 %.

**The R-free set was never regenerated or extended.** It was inherited from AutoSol and
verified identical (2634/2634 flags matching, 264 free reflections) between the AutoBuild
and anomalous MTZs before any refinement.

## 5. Final statistics

Two models are preserved because the evidence is genuinely mixed (see §6).

| Metric | AutoBuild baseline (unrefined) | **PRIMARY: `gene5_final.pdb`** | ALTERNATIVE: `gene5_alt_v3.pdb` |
|---|---|---|---|
| R-work | 0.15 | **0.1606** | 0.1619 |
| R-free | 0.24 | **0.2154** | 0.2210 |
| R − R-free gap | 0.09 | 0.055 | 0.059 |
| Ramachandran outliers | 0.00 % | 1.22 % (1 residue) | **0.00 %** |
| Ramachandran favored | 95.12 % | 93.90 % | **95.12 %** |
| Rotamer outliers | 1.37 % | 1.35 % | 1.35 % |
| Cβ deviations | 0 | **0** | **0** |
| Clashscore | 1.51 | **3.00** | 5.26 |
| RMS bonds (Å) | 0.0119 | **0.0079** | 0.0079 |
| RMS angles (°) | 1.42 | 1.06 | **0.99** |
| MolProbity score | 1.33 | **1.60** | 1.72 |

Sources: `logs/4_refine_final_v5.log`, `logs/5_molprobity_final_v5.log`,
`logs/6_refine_alt_v3.log`, `logs/7_molprobity_alt_v3.log`,
`logs/0_molprobity_autobuild_baseline.log`.

**Model contents (both):** chain A residues **2–85** (84 of 87 residues), including
MSE 77; 1 partial-occupancy free Se (disordered Met1); waters — 30 (primary) / 35 (alternative).
Not modelled: Met1, Ala86, Lys87 (disordered termini).

## 6. Accepted / rejected decisions

**Accepted**
- SAD (peak only) rather than MAD, per instruction — succeeded.
- Space group C2 from the `.sca` header; 1 copy/ASU confirmed by Matthews (P = 1.000).
- Hand chosen on two agreeing metrics (DM R 0.311 vs 0.345; BAYES-CC 0.44 vs 0.15).
- Met77 rebuilt as MSE with Se on the 27.6 σ anomalous peak.
- Three redundant Se sites deleted as over-split fragments of one selenium.
- `rotamer_restraints=True` in final refinement.

**Rejected / reverted**
- Auto-fitted rotamers for A/12, A/21, A/24, A/72, A/75 — improved rotamer scores but
  worsened density fit; reverted.
- Deleting Pro85 to fix clashes — rejected: its atoms sit in 1.9–3.1 σ density (CC 0.764),
  so it is real and well-ordered despite being the chain terminus.
- An earlier refinement (R-work 0.1418 / R-free 0.2458) was discarded: R-free rose while
  R-work fell (gap 0.104) — over-fitting.
- My initial hypothesis of "four Se = two Met × two alternate conformations" was
  **disproved** by the model-independent peak search and abandoned.

## 7. Remaining uncertainties

1. **A/20 SER Ramachandran outlier** (primary model). A Coot pepflip fixed it, but
   refinement against the data reverts it — the diffraction data prefer the strained
   conformation. Density in residues 19–21 is weak and equivalent between the two models
   (mean 1.25–1.35 σ; Arg21 side chain only 0.2–0.5 σ), so density **cannot** discriminate.
   This is why both models are preserved.
2. **Met1 selenium (~7.8 σ) is unassigned.** Modelled as a free partial-occupancy Se rather
   than a built residue, because residue 1 could not be traced. Honest but non-standard;
   a depositor may prefer to delete it or build Met1 with alt confs.
3. **Three residues unmodelled** (Met1, Ala86, Lys87) — disordered termini.
4. Several surface side chains (Lys24, Arg21, Gln22, Gln12) have side-chain CC < 0.5 and
   are essentially unconstrained by density; their conformations should not be interpreted.
5. Waters were pruned at a 1.0 σ threshold; the 30 retained have not been individually
   validated for H-bonding chemistry.

## 8. Suggested next steps

- Run `phenix.refine` with TLS, and test occupancy refinement for the partial Se.
- Attempt to build Met1 as MSE with alternate conformations against the 7.8 σ site,
  which would remove the free-Se placeholder.
- Consider composite-omit maps around residues 19–22 to settle the A/20 backbone.
- The two extra datasets (`infl.sca`, `high.sca`) were deliberately unused. Full **MAD**
  phasing would give substantially better experimental phases than the 46° obtained here
  and would likely resolve the disordered termini.

## 9. File inventory

```
gene5_final.pdb / .cif          PRIMARY refined model (R-free 0.2154, MolProbity 1.60)
gene5_final_map_coeffs.mtz      2mFo-DFc, mFo-DFc and ANOM/PANOM coefficients
gene5_data_with_anom_and_freeR.mtz  FP/SIGFP, I(+/-), HL, FreeR_flag (free set preserved)
peak.sca, sequence.dat          unmodified inputs (copies)

alternative_model/
  gene5_alt_v3.pdb              ALTERNATIVE model: 0 % Rama outliers, R-free 0.2210
  gene5_alt_v3_map_coeffs.mtz

phasing/
  se_substructure_autosol.pdb   AutoSol Se substructure (4 over-split sites, as found)
  experimental_phases_freeR.mtz SAD experimental phases + FOM + free flags
  experimental_denmod_map_coeffs.mtz  density-modified experimental map (CC 0.766 vs final)
  autobuild_initial_model.pdb   AutoBuild output before Coot rebuilding
  AutoSol_summary.dat

logs/                           0_ baseline → 7_, one per program run
```
