#!/usr/bin/env python3
"""test_back.py — does backing up change anything it should not?

Two walks per tutorial:

  STRAIGHT   forward through every step.
  ZIGZAG     forward 1, back 1, forward 2, back 1, forward 2 ... to the end.
             Every step after the first is therefore visited at least twice,
             once arrived-at forwards and once arrived-at from ahead.

Then assert:

  1. every panel the zigzag shows for step N is IDENTICAL to the panel the
     straight walk showed for step N;
  2. the student file is byte-identical at the end of both walks;
  3. the extra_files (GUIDEME.md) are byte-identical at the end of both walks.

Panels are matched by their step header, not by position, because the zigzag
naturally shows some of them more than once.

Usage:  python3 test_back.py [tutorial_1 ...]
"""
import hashlib
import os
import re
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ANSI = re.compile(r"\x1b\[[0-9;]*[A-Za-z]")
# the render() header line carries "STEP n/total" — that is the panel's identity
# A PREDICT step emits TWO panels under the same number — the question and the
# reveal — so the panel's identity is (step, title), not the step alone.
STEPLINE = re.compile(r"^\s*STEP\s+(\d+)\s+of\s+(\d+)\s+·\s+(.*)$", re.M)

# what each tutorial's steps need as input, in order, for a straight walk.
# PREDICT steps take an answer then an Enter for the reveal; everything else
# takes a single Enter. Built from the step table itself so it cannot drift.
def step_kinds(tut):
    src = open(os.path.join(HERE, tut, "guide.py"), encoding="utf-8").read()
    return re.findall(r'dict\(n=(\d+),\s*kind="([A-Z]+)"', src)


def answers(tut):
    """{step number: answer} — keyed by STEP, not by order.

    A running index breaks the moment a step is revisited: the second visit to a
    PREDICT step would be fed the NEXT step's answer, the guide would reject it,
    and the walk would stall in a way that looks like a bug in back.
    """
    src = open(os.path.join(HERE, tut, "guide.py"), encoding="utf-8").read()
    out = {}
    blocks = re.split(r"(?=dict\(n=\d+,)", src)
    for b in blocks:
        m = re.match(r"dict\(n=(\d+),", b)
        a = re.search(r'answer="([^"]+)"', b)
        if m and a:
            out[int(m.group(1))] = a.group(1)
    return out


def inputs_for(tut, plan):
    """plan is a list of 'f' (forward) / 'b' (back). Produce the keystrokes."""
    kinds = dict((int(n), k) for n, k in step_kinds(tut))
    ans = answers(tut)
    out = []
    cur = 1
    for move in plan:
        k = kinds.get(cur, "IDEA")
        if move == "b":
            out.append("b")           # answered at the FIRST prompt of the step
            cur = max(1, cur - 1)
            continue
        if k == "PREDICT":
            out.append(ans.get(cur, "n"))
            out.append("")            # the reveal's Enter
        else:
            out.append("")
        cur += 1
    return "\n".join(out) + "\n"


def walk(tut, plan, timeout=1800):
    d = os.path.join(HERE, tut)
    subprocess.run([sys.executable, "guide.py", "--reset"], cwd=d,
                   capture_output=True)
    argv = ["guide.py"] + (["--offline"] if tut == "tutorial_4" else [])
    p = subprocess.run([sys.executable] + argv, cwd=d,
                       input=inputs_for(tut, plan).encode(),
                       capture_output=True, timeout=timeout)
    return ANSI.sub("", (p.stdout + p.stderr).decode("utf-8", "replace"))


def panels(out):
    """{step number: [panel text, ...]} — a step may appear more than once.

    Split on the STEP header itself. Splitting on the rule line does not work:
    render() emits it twice per panel, so the step number and the body land in
    different fragments.
    """
    got = {}
    marks = [(m.start(), (int(m.group(1)), m.group(3).strip()))
             for m in STEPLINE.finditer(out)]
    for i, (pos, n) in enumerate(marks):
        end = marks[i + 1][0] if i + 1 < len(marks) else len(out)
        body = [ln.rstrip() for ln in out[pos:end].splitlines()]
        # the prompt line and the back-note legitimately differ between a first
        # visit and a return visit; everything else must match exactly
        # Prompts are written without a trailing newline, so with stdin piped the
        # next panel's rule line lands on the same captured line as the prompt.
        # That is an artefact of capturing, not a difference in what was shown.
        cleaned = []
        for ln in body:
            ln = re.sub(r"\[[^\]]*\]\s*>.*$", "", ln)      # ask() prompt echo
            ln = re.sub(r"═{4,}", "", ln).rstrip()           # merged rule line
            if ("b = back" in ln or "\u2190 back to step" in ln
                    or "Already at the first step" in ln):
                continue
            cleaned.append(ln)
        # The last panel of a completed walk has no following STEP header, so the
        # DONE banner and the outro fall inside it. Bound it there — that text is
        # not part of the panel.
        for j, ln in enumerate(cleaned):
            if ln.strip().startswith("DONE"):
                cleaned = cleaned[:j]
                break
        body = cleaned
        while body and not body[-1].strip():
            body.pop()
        got.setdefault(n, []).append("\n".join(body).strip())
    return got


def digest(path):
    if not os.path.exists(path):
        return None
    return hashlib.sha256(open(path, "rb").read()).hexdigest()[:12]


def guide_attr(tut, name):
    src = open(os.path.join(HERE, tut, "guide.py"), encoding="utf-8").read()
    m = re.search(r'%s="([^"]+)"' % name, src)
    return m.group(1) if m else None


def extra_files(tut):
    src = open(os.path.join(HERE, tut, "guide.py"), encoding="utf-8").read()
    m = re.search(r"extra_files=\[(.*?)\]", src, re.S)
    return re.findall(r'\("([^"]+)"', m.group(1)) if m else []


def zigzag_plan(nsteps):
    """f, b, ff, b, ff ... — every step revisited from ahead."""
    plan, cur = ["f"], 1
    while cur < nsteps:
        plan.append("b")
        plan += ["f", "f"]
        cur += 1
    return plan


def check(tut):
    n = len(step_kinds(tut))
    print("\n%s  (%d steps)" % (tut, n))

    straight = walk(tut, ["f"] * (n * 3))
    s_panels = panels(straight)
    student = guide_attr(tut, "student_file")
    d = os.path.join(HERE, tut)
    s_files = {}
    if student:
        s_files[student] = digest(os.path.join(d, student))
    for f in extra_files(tut):
        s_files[f] = digest(os.path.join(d, f))

    zig = walk(tut, zigzag_plan(n) + ["f"] * (n * 2))
    z_panels = panels(zig)
    z_files = {}
    if student:
        z_files[student] = digest(os.path.join(d, student))
    for f in extra_files(tut):
        z_files[f] = digest(os.path.join(d, f))

    ok = True

    seen = sorted(set(k[0] for k in s_panels))
    if len(seen) < n:
        ok = False
        print("  FAIL  straight walk reached steps %s of %d — the walk or the "
              "parser is broken, not the guide" % (seen, n))
        return False

    missing = sorted(set(s_panels) - set(z_panels))
    if missing:
        ok = False
        print("  FAIL  zigzag never reached steps %s" % missing)

    差 = []
    for k in sorted(set(s_panels) & set(z_panels)):
        want = s_panels[k][0]
        for i, got in enumerate(z_panels[k]):
            if got != want:
                差.append((k, i))
    if 差:
        ok = False
        print("  FAIL  %d panel(s) differ from the straight walk: %s"
              % (len(差), 差[:6]))
        k, i = 差[0]
        print("        panel %s" % (k,))
        w, g = s_panels[k][0].splitlines(), z_panels[k][i].splitlines()
        for a, b in zip(w, g):
            if a != b:
                print("        first difference:")
                print("          straight: %r" % a[:70])
                print("          zigzag  : %r" % b[:70])
                break
    else:
        print("  PASS  %d distinct panels, all identical to the straight walk"
              % len(set(s_panels) & set(z_panels)))

    for f, h in sorted(s_files.items()):
        if z_files.get(f) != h:
            ok = False
            print("  FAIL  %s differs: straight %s, zigzag %s"
                  % (f, h, z_files.get(f)))
        else:
            print("  PASS  %s byte-identical (%s)" % (f, h))
    return ok


def act_back():
    """Tutorial 4's ACT steps prompt for themselves, so the engine cannot see a
    `b` typed there — their verify() returns BACK instead. The zigzag walk runs
    tutorial 4 --offline, which skips those prompts entirely, so that path needs
    driving on its own or it is never exercised."""
    print("\ntutorial_4 ACT prompts")
    ok = True
    d = os.path.join(HERE, "tutorial_4")
    for label, argv, keys in (
            ("get_log (step 5)", ["guide.py"], b"\n\n\n\nb\n" + b"\n" * 4),
            ("compare rows (step 8)", ["guide.py", "--offline"], b"\n" * 9 + b"b\n" + b"\n" * 6)):
        subprocess.run([sys.executable, "guide.py", "--reset"], cwd=d, capture_output=True)
        p = subprocess.run([sys.executable] + argv, cwd=d, input=keys,
                           capture_output=True, timeout=900)
        out = ANSI.sub("", (p.stdout + p.stderr).decode("utf-8", "replace"))
        went_back = "\u2190 back to step" in out
        offered = "b = back" in out
        results = went_back and offered
        ok = ok and results
        print("  %s  %s: b offered=%s, went back=%s"
              % ("PASS" if results else "FAIL", label, offered, went_back))
    subprocess.run([sys.executable, "guide.py", "--reset"], cwd=d, capture_output=True)
    return ok


def main():
    tuts = sys.argv[1:] or ["tutorial_1", "tutorial_2", "tutorial_3", "tutorial_4"]
    results = [check(t) for t in tuts]
    if "tutorial_4" in tuts:
        results.append(act_back())
    print("\n%s" % ("ALL PASSED" if all(results) else "FAILURES — see above"))
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
