"""
guide.py — Tutorial 3, guided walkthrough.

    python3 guide.py

This one has the two moments that matter:
  * moment B — the obvious guardrail is the WRONG KIND of rule, and real
    gene-5 data proves it.
  * moment C — your code is right, the overfit still slips, and the fix is
    two numbers in a PROMPT, not a line of Python.
"""

import os as _os
import sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))
_sys.path.insert(0, _os.path.dirname(_os.path.dirname(_os.path.abspath(__file__))))
import safe_io  # noqa: F401  survive a non-UTF-8 terminal
import contextlib
import io
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from guide_engine import (Guide, main, fresh, run_exercise_tests,   # noqa: E402
                          run_filtered, ask, said, GRN, RED, YEL, BOLD, RST, DIM)

HERE = os.path.dirname(os.path.abspath(__file__))
GUIDEME = os.path.join(HERE, "GUIDEME.md")

sys.path.insert(0, HERE)
from transcript import RUN  # noqa: E402   the agent's own words


def step(n):
    for r in RUN:
        if r["step"] == n:
            return r
    return {}


def quiet(fn, *a):
    with contextlib.redirect_stdout(io.StringIO()):
        return fn(*a)


CHECKS = {
    1: "parses the prose; ignores what isn't a setting",
    2: "gated by name, gated by cost, not gated",
    3: "in scope, out of scope, always-allowed",
    4: "the real gene-5 overfits",
    5: "scope before gate — the order matters",
}


def _tests(g, n):
    p, f = run_exercise_tests(g.test_file, n, cwd=g.cwd)
    if f == 0 and p > 0:
        return "  %s✓ %d checks: %s%s" % (GRN, p, CHECKS.get(n, ""), RST)
    return "  %s✗ %d passed, %d FAILED%s" % (RED, p, f, RST)


def _fit(items, width):
    """Never cut an action name in half."""
    kept, n = [], 0
    for it in items:
        if n + len(it) + 2 > width:
            break
        kept.append(it)
        n += len(it) + 2
    extra = len(items) - len(kept)
    return ", ".join(kept) + (" +%d more" % extra if extra else "")


def _guideme_params():
    txt = open(GUIDEME).read()
    tol = re.search(r"^r_free_tolerance:\s*([\d.]+)", txt, re.M)
    gap = re.search(r"^max_gap:\s*([\d.]+)", txt, re.M)
    return (tol.group(1) if tol else "?"), (gap.group(1) if gap else "?")


# ══════════════════════════════════════════════════════════ RUN bodies

def s3_body(g):
    hits = run_filtered(["run_agent.py", "--ungoverned"],
                        [r"Final R-free", r"R-work/R-free gap", r"Overfits caught"],
                        cwd=g.cwd, limit=3)
    return ([
        "  Here is that same run with %sthe arbiter taken out%s —" % (YEL, RST),
        "  the version you have to defend against:",
        "",
    ] + ["    %s" % h for h in hits] + [
        "",
        "  With no arbiter it goes off-plan, spends on an",
        "  expensive step nobody approved, and %skeeps%s the overfit" % (RED, RST),
        "  instead of reverting it. Then it reports success.",
        "",
        "  Look at R-free: 0.258 — the gap is 0.086. %sThat is" % YEL,
        "  the real overfit%s — R-work fell to 0.173, R-free rose." % RST,
        "  Same event, same numbers your code is about to catch.",
    ])


def s5_body(g):
    m = fresh("policy")
    p = quiet(m.load_policy, open(GUIDEME).read())
    return [
        "  GUIDEME.md is prose. Your code reads settings out of it:",
        "",
        "    r_free_tolerance   %s" % p.get("r_free_tolerance"),
        "    max_gap            %s" % p.get("max_gap"),
        "    gated_actions      %s" % ", ".join(p.get("gated_actions", [])),
        "    in_scope_actions   %s" % _fit(p.get("in_scope_actions", []), 30),
        "",
        "  %sThose numbers are deliberately loose.%s The overfit" % (YEL, RST),
        "  will walk straight through them. We fix that at step 15",
        "  — by editing the PROSE, not the code.",
        "",
        _tests(g, 1),
    ]


def s6_body(g):
    """What the checks are actually HANDED.

    Every value is pulled from the REAL objects at render time — the policy
    from load_policy(), the action straight out of RUN. Never typed as a
    literal, or it drifts the moment the code changes.
    """
    m = fresh("policy")
    pol = quiet(m.load_policy, open(GUIDEME).read())
    act = step(6)                   # exactly what run_agent.py passes: RUN[5]
    other = [k for k in act if k not in ("kind", "expensive")]
    return [
        "  Both arguments are plain %sdicts%s. Here they are, for" % (BOLD, RST),
        "  real, at step 6 of the run:",
        "",
        "  %saction%s = RUN[step - 1]  %s← it IS the transcript entry%s"
        % (BOLD, RST, DIM, RST),
        "",
        "    {'kind': %s'%s'%s,   %s← your gate reads this%s"
        % (YEL, act.get("kind"), RST, DIM, RST),
        "     'expensive': %s%s%s,             %s← and this%s"
        % (YEL, act.get("expensive"), RST, DIM, RST),
        "     %s+%d more keys (%s ...) — for the log%s"
        % (DIM, len(other), ", ".join(other[:3]), RST),
        "",
        "  %spolicy%s = load_policy(GUIDEME.md)  %s← from the prose%s"
        % (BOLD, RST, DIM, RST),
        "",
        "    {'gated_actions': %s," % (pol.get("gated_actions"),),
        "     'r_free_tolerance': %s, 'max_gap': %s, ...}"
        % (pol.get("r_free_tolerance"), pol.get("max_gap")),
        "",
        "  %s%d keys in the action. Your policy touches TWO.%s"
        % (BOLD, len(act), RST),
    ]


def _gate(m, kind, pol):
    """needs_approval returns (bool, reason). A non-empty tuple is ALWAYS
    truthy — unpack it, or the panel reports 'GATE' for everything."""
    res = quiet(m.needs_approval, {"kind": kind}, pol)
    if isinstance(res, tuple):
        return bool(res[0]), (res[1] or "")
    return bool(res), ""


def s7_body(g):
    m = fresh("policy")
    p = quiet(m.load_policy, open(GUIDEME).read())
    r = step(6)
    gated, why = _gate(m, "extend_resolution", p)
    r_gated, _ = _gate(m, "refine", p)
    verdict = ("    %s✋ GATE — %s%s" % (YEL, why, RST) if gated
               else "    %s✓ proceeds without asking%s" % (GRN, RST))
    contrast = ("    %srefine → %s%s"
                % (DIM, "gated" if r_gated else "proceeds, no gate", RST))
    return ([
        "  %sStep 6. The agent says:%s" % (BOLD, RST),
        "",
    ] + said(r.get("reasoning", ""), 50, 3) + [
        "",
        "    → %sextend_resolution%s" % (YEL, RST),
        "",
        verdict,
        contrast,
        "",
        "  It is right — the data probably DO go further. But it",
        "  costs hours and touches the R-free test set. If that is",
        "  wrong, your only honest metric is contaminated.",
        "",
        _tests(g, 2),
    ])


def s9_body(g):
    m = fresh("policy")
    p = quiet(m.load_policy, open(GUIDEME).read())
    r = step(5)
    res = quiet(m.check_scope, {"kind": "new_experiment"}, p)
    res = res[0] if isinstance(res, tuple) else res
    return ([
        "  %sStep 5. The agent says:%s" % (BOLD, RST),
        "",
    ] + said(r.get("reasoning", ""), 50, 3) + [
        "",
        "    → %snew_experiment%s  (phenix.autosol)" % (YEL, RST),
        "",
        "    %s✗ OUT OF SCOPE — not in the agreed plan%s" % (YEL, RST)
        if not res else "    %s✓ in scope%s" % (GRN, RST),
        "",
        "  %sRead that reasoning again. It is good science.%s" % (BOLD, RST),
        "  It might even be right. But nobody asked it to redesign",
        "  the experiment — and an agent that quietly widens its",
        "  own remit is one you cannot reason about.",
        "",
        _tests(g, 3),
    ])


# ── MOMENT B ─────────────────────────────────────────────────────
S10_Q = [
    "  The guardrail almost everyone writes — it is already",
    "  sitting in your policy.py:",
    "",
    "      roll back if R-free rose by more than %s0.01%s" % (BOLD, RST),
    "",
    "  Three real overfits from a gene-5 refinement:",
    "",
    "            R-work          R-free          gap",
    "    1   0.198 → 0.173   0.242 → 0.254   .044 → .081",
    "    2   0.198 → 0.147   0.242 → 0.245   .044 → .099",
    "    3   0.192 → 0.137   0.239 → 0.239   .047 → .102",
    "",
    "  All three ARE overfitting: R-work is being driven down",
    "  while R-free refuses to follow it.",
    "",
    "  How many does %s'R-free rose > 0.01'%s catch?" % (BOLD, RST),
]


def s10_reveal(g, answer):
    """The naive rule is REALLY in policy.py. Run the REAL tests on it."""
    p, f = run_exercise_tests(g.test_file, 4, cwd=g.cwd)
    lead = ("  You said 1. %sRight.%s" % (GRN, RST) if answer == "1"
            else "  You said %s. %sThe answer is 1.%s" % (answer, YEL, RST))
    return [
        lead,
        "",
        "  test_policy.py runs your rule against those three",
        "  overfits, plus two healthy steps it must NOT touch:",
        "    %sPASS%s  overfit 1   R-free +0.012  → caught" % (GRN, RST),
        "    %sFAIL%s  overfit 2   R-free +0.004  → %sMISSED%s" % (RED, RST, RED, RST),
        "    %sFAIL%s  overfit 3   R-free  0.000  → %sMISSED%s" % (RED, RST, RED, RST),
        "    %sPASS%s  2 healthy    correctly left alone" % (GRN, RST),
        "",
        "    %s%d passed, %d FAILED%s" % (BOLD, p, f, RST),
        "",
        "  %sFAIL = your rule did the wrong thing.%s It let two" % (BOLD, RST),
        "  genuine overfits through untouched.",
        "",
        "  0.01 is not too small — in overfit 3 R-free did not",
        "  move %sat all%s. No threshold on R-free sees that." % (YEL, RST),
    ]


def s12_body(g):
    return [
        "  %sTHE IDEA%s                     full code → policy.py" % (BOLD, RST),
        "",
        "      gap = r_free - r_work",
        "",
        "      roll back if  R-free rose > tolerance",
        "               OR   %sthe gap WIDENED past max_gap%s" % (GRN, RST),
        "",
        "  Healthy gap at 2.6 A: 0.04 - 0.06.   Overfit: > 0.08.",
        "",
        "  When a model starts fitting noise, R-work falls and",
        "  the held-out R-free does not follow. The gap opens.",
        "  That is the signature — and it is visible even when",
        "  R-free does not move.",
        "",
        _tests(g, 4),
    ]


# ── MOMENT C ─────────────────────────────────────────────────────
def s13_q(g):
    tol, gap = _guideme_params()
    r = step(7)
    return ([
        "  Your guardrail is correct — all 23 tests pass.",
        "",
        "  %sStep 7. The agent says:%s" % (BOLD, RST),
        "",
    ] + said(r.get("reasoning", ""), 50, 2) + [
        "",
        "    → refine     R-free 0.242 → 0.258   (rose 0.016)",
        "                 gap    0.044 → %s0.086%s" % (YEL, RST),
        "",
        "  But GUIDEME.md — the agent's PROMPT — still says:",
        "",
        "      r_free_tolerance: %s%s%s      max_gap: %s%s%s"
        % (YEL, tol, RST, YEL, gap, RST),
        "",
        "  Does your guardrail fire?",
    ])


def s13_reveal(g, answer):
    _tol, _gap = _guideme_params()
    hits = run_filtered(["run_agent.py"],
                        [r"Overfits caught", r"R-work/R-free gap"],
                        cwd=g.cwd, limit=2)
    lead = ("  You said N. %sRight.%s" % (GRN, RST) if answer == "n"
            else "  You said Y. %sIt does not.%s" % (YEL, RST))
    return ([lead, ""] + ["    %s" % h for h in hits] + [
        "",
        # Read the policy out of the file rather than hardcoding it. The numbers
        # here USED to be literals, and step 15 rewrites GUIDEME.md — so re-entering
        # at this step after finishing showed a live run that caught the overfit
        # sitting three lines above fixed text saying the policy was too loose to
        # catch anything. Derived from the file, the panel cannot contradict the run.
        "  0.016 is inside a tolerance of %s." % _tol,
        "  0.086 is inside a max_gap of %s." % _gap,
        "",
        "  %sNothing is wrong with your code.%s The code is right." % (BOLD, RST),
        "  The POLICY is loose — and the policy is English, in a",
        "  file, that the agent reads.",
        "",
        "  So we fix the policy — %swithout touching the code%s." % (BOLD, RST),
    ])


def s14_body(g):
    """The fix is not code. It is two numbers in an English document.

    The guide makes the edit and narrates it — the student watches a running
    agent change behaviour without a line of Python being touched.
    """
    before_tol, before_gap = _guideme_params()
    txt = open(GUIDEME).read()
    txt = re.sub(r"^r_free_tolerance:.*$", "r_free_tolerance: 0.01",
                 txt, flags=re.M)
    txt = re.sub(r"^max_gap:.*$", "max_gap: 0.06", txt, flags=re.M)
    open(GUIDEME, "w").write(txt)
    after_tol, after_gap = _guideme_params()

    hits = run_filtered(["run_agent.py"],
                        [r"ROLLED BACK", r"Overfits caught", r"Final R-free"],
                        cwd=g.cwd, limit=3)
    return ([
        "  policy.py is finished and correct. Do not touch it.",
        "  We change the %sonly other thing there is%s — the prompt." % (BOLD, RST),
        "",
        "  %sGUIDEME.md, two lines, edited for you:%s" % (YEL, RST),
        "      r_free_tolerance:   %s  →  %s%s%s" % (before_tol, GRN, after_tol, RST),
        "      max_gap:            %s  →  %s%s%s" % (before_gap, GRN, after_gap, RST),
        "",
        "  Re-running the agent. %sNo code has changed.%s" % (BOLD, RST),
        "",
    ] + ["    %s" % h[:54] for h in hits] + [
        "",
        "  Loud overfit: R-free rose 0.016 AND gap hit 0.086, so",
        "  both halves fire. %sThe quiet ones (step 11) are why the%s" % (BOLD, RST),
        "  %sgap half must exist.%s" % (BOLD, RST),
    ])


def s15_body(g):
    hits = run_filtered(["run_agent.py", "--compare"],
                        [r"Final R-free", r"R-work/R-free gap",
                         r"Off-plan", r"Expensive", r"Overfit caught"],
                        cwd=g.cwd, limit=5)
    return ([
        "                          governed   ungoverned",
        "  " + "-" * 46,
    ] + ["  %s" % h[:58] for h in hits] + [
        "",
        "  Same agent. Same data. R-free barely differs — and",
        "  that is the point. The gap says everything.",
        "",
        _tests(g, 5),
    ])


# ══════════════════════════════════════════════════════════════ steps

STEPS = [
    dict(n=1, kind="IDEA", title="OVERVIEW — governing an agent that drives itself",
         body=[
        "  In 1 and 2, %syour%s code owned the loop and called the" % (BOLD, RST),
        "  LLM once per step. You checked every move.",
        "",
        "  %sNot any more.%s The agent owns the loop now: it decides," % (YEL, RST),
        "  acts, reads the result, decides again. You are not in",
        "  the loop. So how do you control it?",
        "",
        "  %sWith a policy it reads.%s  Four teeth, in policy.py:" % (BOLD, RST),
        "",
        "     gate       stop before an expensive step",
        "     scope      stay inside the agreed plan",
        "     guardrail  catch a change that breaks the science",
        "     order      run those checks in the right sequence",
        "",
        "  17 steps. Frozen transcript by default; at the end you",
        "  re-run it against a %sreal live model%s." % (YEL, RST),
    ], prompt="[Enter] to watch it run with no policy at all"),

    dict(n=2, kind="IDEA", title="the run you are about to govern", body=[
        "  Modelled on a %sreal run%s: the PHENIX expert on a gene-V" % (YEL, RST),
        "  protein at 2.59 A (C2). It re-refined the model —",
        "  %sR-work 0.198 → 0.173, but R-free 0.242 → 0.258%s (rose)," % (YEL, RST),
        "  gap 0.044 → 0.086 — and %sreverted the change%s." % (GRN, RST),
        "",
        "  It did not invent that judgement. It was %sfollowing a%s" % (BOLD, RST),
        "  %srule someone wrote%s — a Cross-Validation Arbiter module" % (BOLD, RST),
        "  in the GUIDEME it was handed: if the gap widens past",
        "  ~0.08, reject and revert. English, in a prompt.",
        "",
        "  %sThat rule is what you are about to build.%s Here we" % (BOLD, RST),
        "  replay the run with it %sremoved%s, and you write it back —" % (YEL, RST),
        "  gate, scope check, cross-validation rule. Same nine",
        "  steps every student, so the only variable is your code.",
    ], prompt="[Enter] to see the run with no rule in place"),

    dict(n=3, kind="RUN", title="ungoverned", body=s3_body,
         prompt="[Enter] to start building the policy"),

    dict(n=4, kind="IDEA", title="load_policy — the prompt IS the config",
         fill="load_policy", body=[
        "  THE GOAL",
        "    Read the agent's instructions — which are PROSE, in",
        "    GUIDEME.md — and pull the settings out of them.",
        "",
        "  This is the strange part of governing an LLM agent:",
        "  %sits configuration is a document it reads.%s Change the" % (BOLD, RST),
        "  document, change the behaviour. No redeploy.",
        "",
        "  THE IDEA                        full code → policy.py",
        "",
        "      for line in guideme.splitlines():",
        "          key, _, value = line.partition(':')",
        "          if key.strip() in policy:   ← only known keys",
        "              policy[key] = parse(value)",
    ], prompt="[Enter] to read GUIDEME.md"),

    dict(n=5, kind="RUN", title="what the policy says right now", body=s5_body,
         prompt="[Enter] to see what your checks are HANDED"),

    dict(n=6, kind="RUN", title="the two things every check is given",
         body=s6_body, prompt="[Enter] to build the gate"),

    dict(n=7, kind="IDEA", title="needs_approval — the gate", fill="needs_approval",
         body=[
        "  THE GOAL",
        "    Which actions must STOP and ask a human first?",
        "",
        "  Step 6 wants extend_resolution: hours of compute, and",
        "  it touches the R-free test set. If that is wrong, you",
        "  have contaminated your only honest metric.",
        "",
        "  THE IDEA                        full code → policy.py",
        "",
        "      if action['kind'] in policy['gated_actions']:",
        "          return True                ← named in the prompt",
        "      if action.get('expensive'):",
        "          return True                ← or just costly",
    ], prompt="[Enter] to try the gate"),

    dict(n=8, kind="RUN", title="the gate", body=s7_body),

    dict(n=9, kind="IDEA", title="check_scope — stay in the plan",
         fill="check_scope", body=[
        "  THE GOAL",
        "    Is this action even in the agreed plan?",
        "",
        "  At step 5 the agent decides to re-phase the data with",
        "  autosol. It was asked to refine a model.",
        "",
        "  THE IDEA                        full code → policy.py",
        "",
        "      if action['kind'] == 'done':  return True",
        "      return action['kind'] in policy['in_scope_actions']",
        "",
        "  Three lines. It is the difference between an assistant",
        "  and something that redesigns your experiment at 2am.",
    ], prompt="[Enter] to try it"),

    dict(n=10, kind="RUN", title="scope", body=s9_body,
         prompt="[Enter] for the hard one"),

    dict(n=11, kind="PREDICT", title="THE GUARDRAIL — your prediction",
         fill="should_rollback", fill_from="solutions/policy_naive.py",
         body=S10_Q,
         options=["0", "1", "2", "3"], answer="1",
         reveal_title="the answer", reveal=s10_reveal,
         reveal_prompt="[Enter] for a rule of a different kind"),

    dict(n=12, kind="IDEA", title="what actually catches all three", body=[
        "  R-work is fitted. R-free is held out. That is the",
        "  whole point of a free set.",
        "",
        "  When a model starts fitting %snoise%s, R-work keeps" % (YEL, RST),
        "  falling — it always can — but R-free stops following.",
        "",
        "  So the SIGNAL is not R-free's absolute move.",
        "  It is the two of them %spulling apart%s." % (BOLD, RST),
        "",
        "      overfit 3:   R-work  0.192 → 0.137   (falls hard)",
        "                   R-free  0.239 → 0.239   (does not move)",
        "                   gap     0.047 → 0.102   %s← THERE it is%s" % (GRN, RST),
        "",
        "  Watch the gap, not the threshold.",
    ], prompt="[Enter] to install the gap rule"),

    dict(n=13, kind="RUN", title="the gap rule", fill="should_rollback",
         body=s12_body,
         prompt="[Enter] to run the agent with your guardrail"),

    dict(n=14, kind="PREDICT", title="YOUR PREDICTION", body=s13_q,
         options=["y", "n"], answer="n",
         reveal_title="correct code, loose policy", reveal=s13_reveal,
         reveal_prompt="[Enter] to see the fix"),

    dict(n=15, kind="RUN", title="the fix is two numbers, in English",
         body=s14_body, prompt="[Enter] to compare governed vs ungoverned"),

    dict(n=16, kind="RUN", title="governed vs ungoverned", fill="pre_act",
         body=s15_body, prompt="[Enter] — one last thing"),

    dict(n=17, kind="IDEA", title="now do it against a live LLM", body=[
        "  Everything you just governed was a frozen transcript.",
        "  Same nine steps, every time. That was on purpose — so",
        "  the only thing that changed was %syour policy%s." % (BOLD, RST),
        "",
        "  But a policy that only works against a script is not a",
        "  policy. So try it against a model that cannot be",
        "  predicted — %safter the guide exits%s, run:" % (BOLD, RST),
        "",
        "      %sexport ANTHROPIC_API_KEY=...%s" % (BOLD, RST),
        "      %spython3 run_agent.py --live%s" % (BOLD, RST),
        "",
        "  (No key? %spython3 run_agent.py --demo%s does the same.)" % (BOLD, RST),
        "",
        "  Your gate, your scope check and your gap rule do not",
        "  care where the proposal came from. %sThat is what makes%s" % (YEL, RST),
        "  %sthem a policy and not a special case.%s" % (YEL, RST),
    ], prompt="[Enter] to finish"),
]


if __name__ == "__main__":
    main(Guide(
        title="Tutorial 3 — Steering an Autonomous Agent",
        student_file="policy.py",
        solution_file="solutions/policy_complete.py",
        test_file="test_policy.py",
        stub_file="solutions/policy_stub.py",
        extra_files=[("GUIDEME.md", "solutions/GUIDEME_shipped.md")],
        steps=STEPS,
        cwd=HERE,
        outro=[
            "  Two things happened here, and only one was code.",
            "",
            "    %spolicy.py%s     67 lines. The mechanism." % (BOLD, RST),
            "    %sGUIDEME.md%s    two numbers. The behaviour." % (BOLD, RST),
            "",
            "  %sNow do it yourself — that is where this gets real.%s" % (YEL, RST),
            "",
            "    Open %sGUIDEME.md%s in an editor. Loosen max_gap back" % (BOLD, RST),
            "    to 0.20 and re-run:  %spython3 run_agent.py%s" % (BOLD, RST),
            "    The overfit sails through again.",
            "",
            "    Then remove 'extend_resolution' from gated_actions.",
            "    The agent runs an irreversible, hours-long step",
            "    without asking you first.",
            "",
            "    You are reprogramming a running agent with a text",
            "    editor. %sNo Python was harmed.%s" % (BOLD, RST),
            "",
            "    %spython3 guide.py --reset%s   to put it all back." % (BOLD, RST),
            "",
            "  Then try it against a live model:",
            "",
            "     %sexport ANTHROPIC_API_KEY=...%s" % (BOLD, RST),
            "     %spython3 run_agent.py --live%s" % (BOLD, RST),
            "",
            "  Your policy has never seen that model's output.",
            "  It will hold anyway — that is what a policy IS.",
            "",
            "  Then %sTutorial 4%s: the same four teeth, in %sEnglish%s," % (BOLD, RST, BOLD, RST),
            "  for the real PHENIX expert — real Phenix, real Coot,",
            "  real data. %sNo Python at all.%s" % (BOLD, RST),
        ],
    ))
