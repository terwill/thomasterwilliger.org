Geometry restraints
Bond | covalent geometry | restraints: 670
Sorted by residual:
bond pdb=" CA  ARG A  21 "
     pdb=" C   ARG A  21 "
  ideal  model  delta    sigma   weight residual
  1.524  1.479  0.044 1.27e-02 6.20e+03 1.22e+01
bond pdb=" N   ARG A  21 "
     pdb=" CA  ARG A  21 "
  ideal  model  delta    sigma   weight residual
  1.459  1.426  0.033 1.19e-02 7.06e+03 7.81e+00
bond pdb=" C   LYS A  46 "
     pdb=" O   LYS A  46 "
  ideal  model  delta    sigma   weight residual
  1.235  1.202  0.032 1.18e-02 7.18e+03 7.42e+00
bond pdb=" CA  LYS A  24 "
     pdb=" C   LYS A  24 "
  ideal  model  delta    sigma   weight residual
  1.528  1.498  0.029 1.08e-02 8.57e+03 7.41e+00
bond pdb=" C   LEU A  44 "
     pdb=" O   LEU A  44 "
  ideal  model  delta    sigma   weight residual
  1.236  1.204  0.032 1.21e-02 6.83e+03 6.80e+00
bond pdb=" C   VAL A  19 "
     pdb=" O   VAL A  19 "
  ideal  model  delta    sigma   weight residual
  1.236  1.211  0.025 9.90e-03 1.02e+04 6.47e+00
bond pdb=" C   LEU A  28 "
     pdb=" O   LEU A  28 "
  ideal  model  delta    sigma   weight residual
  1.236  1.205  0.030 1.20e-02 6.94e+03 6.44e+00
bond pdb=" CA  VAL A  45 "
     pdb=" CB  VAL A  45 "
  ideal  model  delta    sigma   weight residual
  1.544  1.574 -0.031 1.32e-02 5.74e+03 5.38e+00
bond pdb=" C   ARG A  21 "
     pdb=" N   GLN A  22 "
  ideal  model  delta    sigma   weight residual
  1.333  1.304  0.029 1.36e-02 5.41e+03 4.42e+00
bond pdb=" C   VAL A  45 "
     pdb=" O   VAL A  45 "
  ideal  model  delta    sigma   weight residual
  1.236  1.216  0.020 1.02e-02 9.61e+03 3.98e+00
bond pdb=" C   SER A  27 "
     pdb=" O   SER A  27 "
  ideal  model  delta    sigma   weight residual
  1.234  1.213  0.022 1.11e-02 8.12e+03 3.84e+00
bond pdb=" CA  SER A  20 "
     pdb=" C   SER A  20 "
  ideal  model  delta    sigma   weight residual
  1.528  1.503  0.025 1.33e-02 5.65e+03 3.45e+00
bond pdb=" CA  LYS A  46 "
     pdb=" CB  LYS A  46 "
  ideal  model  delta    sigma   weight residual
  1.530  1.502  0.029 1.55e-02 4.16e+03 3.39e+00
bond pdb=" CD  LYS A   7 "
     pdb=" CE  LYS A   7 "
  ideal  model  delta    sigma   weight residual
  1.520  1.465  0.055 3.00e-02 1.11e+03 3.36e+00
bond pdb=" C   LYS A  24 "
     pdb=" O   LYS A  24 "
  ideal  model  delta    sigma   weight residual
  1.235  1.212  0.023 1.35e-02 5.49e+03 2.97e+00
bond pdb=" C   ARG A  21 "
     pdb=" O   ARG A  21 "
  ideal  model  delta    sigma   weight residual
  1.236  1.218  0.018 1.15e-02 7.56e+03 2.52e+00
bond pdb=" C   TYR A  26 "
     pdb=" O   TYR A  26 "
  ideal  model  delta    sigma   weight residual
  1.234  1.214  0.020 1.26e-02 6.30e+03 2.51e+00
bond pdb=" C   VAL A  19 "
     pdb=" N   SER A  20 "
  ideal  model  delta    sigma   weight residual
  1.330  1.309  0.022 1.37e-02 5.33e+03 2.50e+00
bond pdb=" N   VAL A  45 "
     pdb=" CA  VAL A  45 "
  ideal  model  delta    sigma   weight residual
  1.458  1.440  0.018 1.14e-02 7.69e+03 2.43e+00
bond pdb=" CA  ARG A  21 "
     pdb=" CB  ARG A  21 "
  ideal  model  delta    sigma   weight residual
  1.529  1.505  0.024 1.55e-02 4.16e+03 2.41e+00
bond pdb=" C   LYS A  46 "
     pdb=" N   ILE A  47 "
  ideal  model  delta    sigma   weight residual
  1.331  1.309  0.021 1.40e-02 5.10e+03 2.27e+00
bond pdb=" C   PRO A  25 "
     pdb=" O   PRO A  25 "
  ideal  model  delta    sigma   weight residual
  1.233  1.217  0.017 1.12e-02 7.97e+03 2.22e+00
bond pdb=" C   SER A  20 "
     pdb=" N   ARG A  21 "
  ideal  model  delta    sigma   weight residual
  1.334  1.316  0.018 1.27e-02 6.20e+03 2.00e+00
bond pdb=" C   GLY A  23 "
     pdb=" O   GLY A  23 "
  ideal  model  delta    sigma   weight residual
  1.237  1.216  0.021 1.49e-02 4.50e+03 1.99e+00
bond pdb=" CA  LYS A  24 "
     pdb=" CB  LYS A  24 "
  ideal  model  delta    sigma   weight residual
  1.528  1.505  0.024 1.75e-02 3.27e+03 1.85e+00
bond pdb=" C   TYR A  26 "
     pdb=" N   SER A  27 "
  ideal  model  delta    sigma   weight residual
  1.331  1.314  0.018 1.33e-02 5.65e+03 1.80e+00
bond pdb=" N   LYS A  24 "
     pdb=" CA  LYS A  24 "
  ideal  model  delta    sigma   weight residual
  1.454  1.435  0.019 1.45e-02 4.76e+03 1.70e+00
bond pdb=" CA  LEU A  28 "
     pdb=" C   LEU A  28 "
  ideal  model  delta    sigma   weight residual
  1.521  1.506  0.015 1.19e-02 7.06e+03 1.59e+00
bond pdb=" CA  LYS A  46 "
     pdb=" C   LYS A  46 "
  ideal  model  delta    sigma   weight residual
  1.523  1.508  0.015 1.24e-02 6.50e+03 1.48e+00
bond pdb=" C   GLY A  23 "
     pdb=" N   LYS A  24 "
  ideal  model  delta    sigma   weight residual
  1.329  1.310  0.019 1.60e-02 3.91e+03 1.37e+00
bond pdb=" C   VAL A  43 "
     pdb=" N   LEU A  44 "
  ideal  model  delta    sigma   weight residual
  1.331  1.315  0.016 1.42e-02 4.96e+03 1.26e+00
bond pdb=" CA  GLY A  23 "
     pdb=" C   GLY A  23 "
  ideal  model  delta    sigma   weight residual
  1.515  1.501  0.014 1.32e-02 5.74e+03 1.15e+00
bond pdb=" CA  LEU A  44 "
     pdb=" C   LEU A  44 "
  ideal  model  delta    sigma   weight residual
  1.524  1.511  0.013 1.30e-02 5.92e+03 9.81e-01
bond pdb=" C   LEU A  44 "
     pdb=" N   VAL A  45 "
  ideal  model  delta    sigma   weight residual
  1.331  1.317  0.014 1.40e-02 5.10e+03 9.30e-01
bond pdb=" CA  LEU A  28 "
     pdb=" CB  LEU A  28 "
  ideal  model  delta    sigma   weight residual
  1.532  1.515  0.017 1.82e-02 3.02e+03 8.75e-01
bond pdb=" N   TYR A  26 "
     pdb=" CA  TYR A  26 "
  ideal  model  delta    sigma   weight residual
  1.454  1.466 -0.012 1.29e-02 6.01e+03 8.19e-01
bond pdb=" N   SER A  27 "
     pdb=" CA  SER A  27 "
  ideal  model  delta    sigma   weight residual
  1.457  1.446  0.011 1.26e-02 6.30e+03 7.04e-01
bond pdb=" C   LYS A  24 "
     pdb=" N   PRO A  25 "
  ideal  model  delta    sigma   weight residual
  1.329  1.320  0.010 1.25e-02 6.40e+03 6.27e-01
bond pdb=" N   SER A  20 "
     pdb=" CA  SER A  20 "
  ideal  model  delta    sigma   weight residual
  1.453  1.443  0.010 1.27e-02 6.20e+03 6.09e-01
bond pdb=" C   VAL A  45 "
     pdb=" N   LYS A  46 "
  ideal  model  delta    sigma   weight residual
  1.329  1.319  0.011 1.43e-02 4.89e+03 5.57e-01
bond pdb=" C   SER A  20 "
     pdb=" O   SER A  20 "
  ideal  model  delta    sigma   weight residual
  1.234  1.225  0.010 1.31e-02 5.83e+03 5.29e-01
bond pdb=" N   LEU A  28 "
     pdb=" CA  LEU A  28 "
  ideal  model  delta    sigma   weight residual
  1.456  1.448  0.009 1.21e-02 6.83e+03 5.10e-01
bond pdb=" CB  TYR A  41 "
     pdb=" CG  TYR A  41 "
  ideal  model  delta    sigma   weight residual
  1.512  1.497  0.015 2.20e-02 2.07e+03 4.93e-01
bond pdb=" C   LEU A  28 "
     pdb=" N   ASN A  29 "
  ideal  model  delta    sigma   weight residual
  1.330  1.320  0.010 1.39e-02 5.18e+03 4.72e-01
bond pdb=" N   VAL A  19 "
     pdb=" CA  VAL A  19 "
  ideal  model  delta    sigma   weight residual
  1.458  1.465 -0.008 1.18e-02 7.18e+03 4.36e-01
bond pdb=" CB  LEU A  28 "
     pdb=" CG  LEU A  28 "
  ideal  model  delta    sigma   weight residual
  1.530  1.517  0.013 2.00e-02 2.50e+03 4.32e-01
bond pdb=" C   SER A  27 "
     pdb=" N   LEU A  28 "
  ideal  model  delta    sigma   weight residual
  1.331  1.322  0.008 1.34e-02 5.57e+03 3.61e-01
bond pdb=" CA  PRO A  25 "
     pdb=" CB  PRO A  25 "
  ideal  model  delta    sigma   weight residual
  1.534  1.526  0.007 1.23e-02 6.61e+03 3.60e-01
bond pdb=" N   GLY A  23 "
     pdb=" CA  GLY A  23 "
  ideal  model  delta    sigma   weight residual
  1.444  1.453 -0.009 1.60e-02 3.91e+03 3.45e-01
bond pdb=" CZ  TYR A  41 "
     pdb=" OH  TYR A  41 "
  ideal  model  delta    sigma   weight residual
  1.376  1.364  0.012 2.10e-02 2.27e+03 3.03e-01
bond pdb=" N   LYS A  46 "
     pdb=" CA  LYS A  46 "
  ideal  model  delta    sigma   weight residual
  1.455  1.449  0.007 1.22e-02 6.72e+03 3.01e-01
bond pdb=" CB  SER A  27 "
     pdb=" OG  SER A  27 "
  ideal  model  delta    sigma   weight residual
  1.417  1.407  0.010 2.00e-02 2.50e+03 2.45e-01
bond pdb=" CZ  TYR A  26 "
     pdb=" OH  TYR A  26 "
  ideal  model  delta    sigma   weight residual
  1.376  1.366  0.010 2.10e-02 2.27e+03 2.40e-01
bond pdb=" CB  LEU A  44 "
     pdb=" CG  LEU A  44 "
  ideal  model  delta    sigma   weight residual
  1.530  1.521  0.009 2.00e-02 2.50e+03 2.19e-01
bond pdb=" N   LEU A  44 "
     pdb=" CA  LEU A  44 "
  ideal  model  delta    sigma   weight residual
  1.458  1.452  0.006 1.24e-02 6.50e+03 2.15e-01
bond pdb=" CG  PRO A  25 "
     pdb=" CD  PRO A  25 "
  ideal  model  delta    sigma   weight residual
  1.503  1.487  0.016 3.40e-02 8.65e+02 2.08e-01
bond pdb=" CA  ILE A   2 "
     pdb=" CB  ILE A   2 "
  ideal  model  delta    sigma   weight residual
  1.540  1.552 -0.012 2.70e-02 1.37e+03 2.06e-01
bond pdb=" C   PRO A  42 "
     pdb=" N   VAL A  43 "
  ideal  model  delta    sigma   weight residual
  1.330  1.323  0.007 1.57e-02 4.06e+03 2.04e-01
bond pdb=" CA  SER A  27 "
     pdb=" C   SER A  27 "
  ideal  model  delta    sigma   weight residual
  1.520  1.525 -0.005 1.20e-02 6.94e+03 2.03e-01
bond pdb=" CD2 TYR A  41 "
     pdb=" CE2 TYR A  41 "
  ideal  model  delta    sigma   weight residual
  1.382  1.369  0.013 3.00e-02 1.11e+03 1.92e-01
bond pdb=" CG  GLN A  22 "
     pdb=" CD  GLN A  22 "
  ideal  model  delta    sigma   weight residual
  1.516  1.527 -0.011 2.50e-02 1.60e+03 1.91e-01
bond pdb=" C   GLY A  18 "
     pdb=" N   VAL A  19 "
  ideal  model  delta    sigma   weight residual
  1.331  1.324  0.006 1.43e-02 4.89e+03 1.89e-01
bond pdb=" CG  PRO A  42 "
     pdb=" CD  PRO A  42 "
  ideal  model  delta    sigma   weight residual
  1.503  1.489  0.014 3.40e-02 8.65e+02 1.80e-01
bond pdb=" N   PRO A  25 "
     pdb=" CD  PRO A  25 "
  ideal  model  delta    sigma   weight residual
  1.473  1.467  0.006 1.40e-02 5.10e+03 1.80e-01
bond pdb=" CA  VAL A  70 "
     pdb=" CB  VAL A  70 "
  ideal  model  delta    sigma   weight residual
  1.536  1.531  0.005 1.17e-02 7.31e+03 1.78e-01
bond pdb=" CA  ILE A   2 "
     pdb=" C   ILE A   2 "
  ideal  model  delta    sigma   weight residual
  1.525  1.534 -0.009 2.10e-02 2.27e+03 1.77e-01
bond pdb=" CB  PRO A  42 "
     pdb=" CG  PRO A  42 "
  ideal  model  delta    sigma   weight residual
  1.492  1.471  0.021 5.00e-02 4.00e+02 1.77e-01
bond pdb=" N   VAL A  43 "
     pdb=" CA  VAL A  43 "
  ideal  model  delta    sigma   weight residual
  1.457  1.452  0.005 1.22e-02 6.72e+03 1.73e-01
bond pdb=" CA  ASN A  39 "
     pdb=" C   ASN A  39 "
  ideal  model  delta    sigma   weight residual
  1.528  1.523  0.005 1.28e-02 6.10e+03 1.65e-01
bond pdb=" CB  GLN A  22 "
     pdb=" CG  GLN A  22 "
  ideal  model  delta    sigma   weight residual
  1.520  1.532 -0.012 3.00e-02 1.11e+03 1.56e-01
bond pdb=" N   ASN A  39 "
     pdb=" CA  ASN A  39 "
  ideal  model  delta    sigma   weight residual
  1.454  1.458 -0.005 1.17e-02 7.31e+03 1.52e-01
bond pdb=" CB  VAL A  45 "
     pdb=" CG1 VAL A  45 "
  ideal  model  delta    sigma   weight residual
  1.521  1.508  0.013 3.30e-02 9.18e+02 1.50e-01
bond pdb=" N   PRO A  25 "
     pdb=" CA  PRO A  25 "
  ideal  model  delta    sigma   weight residual
  1.465  1.460  0.004 1.15e-02 7.56e+03 1.46e-01
bond pdb=" CA  TYR A  26 "
     pdb=" C   TYR A  26 "
  ideal  model  delta    sigma   weight residual
  1.522  1.518  0.005 1.23e-02 6.61e+03 1.44e-01
bond pdb=" CB  VAL A  70 "
     pdb=" CG2 VAL A  70 "
  ideal  model  delta    sigma   weight residual
  1.521  1.509  0.012 3.30e-02 9.18e+02 1.41e-01
bond pdb=" C   VAL A  84 "
     pdb=" N   PRO A  85 "
  ideal  model  delta    sigma   weight residual
  1.341  1.347 -0.006 1.60e-02 3.91e+03 1.40e-01
bond pdb=" N   PRO A  85 "
     pdb=" CA  PRO A  85 "
  ideal  model  delta    sigma   weight residual
  1.466  1.471 -0.005 1.50e-02 4.44e+03 1.16e-01
bond pdb=" CB  VAL A  19 "
     pdb=" CG1 VAL A  19 "
  ideal  model  delta    sigma   weight residual
  1.521  1.510  0.011 3.30e-02 9.18e+02 1.15e-01
bond pdb=" CB  ILE A   2 "
     pdb=" CG2 ILE A   2 "
  ideal  model  delta    sigma   weight residual
  1.521  1.510  0.011 3.30e-02 9.18e+02 1.12e-01
bond pdb=" CA  VAL A  70 "
     pdb=" C   VAL A  70 "
  ideal  model  delta    sigma   weight residual
  1.524  1.520  0.004 1.23e-02 6.61e+03 1.11e-01
bond pdb=" CG  LYS A  46 "
     pdb=" CD  LYS A  46 "
  ideal  model  delta    sigma   weight residual
  1.520  1.510  0.010 3.00e-02 1.11e+03 1.06e-01
bond pdb=" CB  LYS A   3 "
     pdb=" CG  LYS A   3 "
  ideal  model  delta    sigma   weight residual
  1.520  1.510  0.010 3.00e-02 1.11e+03 1.02e-01
bond pdb=" C   TYR A  56 "
     pdb=" N   ALA A  57 "
  ideal  model  delta    sigma   weight residual
  1.331  1.326  0.005 1.48e-02 4.57e+03 1.01e-01
bond pdb=" C   PRO A  25 "
     pdb=" N   TYR A  26 "
  ideal  model  delta    sigma   weight residual
  1.331  1.326  0.004 1.41e-02 5.03e+03 1.00e-01
bond pdb=" CB  LYS A   7 "
     pdb=" CG  LYS A   7 "
  ideal  model  delta    sigma   weight residual
  1.520  1.511  0.009 3.00e-02 1.11e+03 9.94e-02
bond pdb=" CD1 TYR A  26 "
     pdb=" CE1 TYR A  26 "
  ideal  model  delta    sigma   weight residual
  1.382  1.373  0.009 3.00e-02 1.11e+03 9.69e-02
bond pdb=" CA  VAL A  19 "
     pdb=" C   VAL A  19 "
  ideal  model  delta    sigma   weight residual
  1.522  1.526 -0.004 1.22e-02 6.72e+03 9.47e-02
bond pdb=" N   ALA A  55 "
     pdb=" CA  ALA A  55 "
  ideal  model  delta    sigma   weight residual
  1.456  1.452  0.004 1.22e-02 6.72e+03 9.16e-02
bond pdb=" N   PRO A  42 "
     pdb=" CD  PRO A  42 "
  ideal  model  delta    sigma   weight residual
  1.473  1.469  0.004 1.40e-02 5.10e+03 8.86e-02
bond pdb=" CB  ASP A  50 "
     pdb=" CG  ASP A  50 "
  ideal  model  delta    sigma   weight residual
  1.516  1.509  0.007 2.50e-02 1.60e+03 8.52e-02
bond pdb=" CG  LEU A  28 "
     pdb=" CD1 LEU A  28 "
  ideal  model  delta    sigma   weight residual
  1.521  1.511  0.010 3.30e-02 9.18e+02 8.42e-02
bond pdb=" CG  TYR A  26 "
     pdb=" CD2 TYR A  26 "
  ideal  model  delta    sigma   weight residual
  1.389  1.383  0.006 2.10e-02 2.27e+03 8.28e-02
bond pdb=" CB  VAL A  45 "
     pdb=" CG2 VAL A  45 "
  ideal  model  delta    sigma   weight residual
  1.521  1.512  0.009 3.30e-02 9.18e+02 8.26e-02
bond pdb=" CB  VAL A  43 "
     pdb=" CG1 VAL A  43 "
  ideal  model  delta    sigma   weight residual
  1.521  1.530 -0.009 3.30e-02 9.18e+02 8.00e-02
bond pdb=" CG  LEU A  44 "
     pdb=" CD1 LEU A  44 "
  ideal  model  delta    sigma   weight residual
  1.521  1.512  0.009 3.30e-02 9.18e+02 7.98e-02
bond pdb=" CE1 TYR A  26 "
     pdb=" CZ  TYR A  26 "
  ideal  model  delta    sigma   weight residual
  1.378  1.371  0.007 2.40e-02 1.74e+03 7.86e-02
bond pdb=" CG  ARG A  82 "
     pdb=" CD  ARG A  82 "
  ideal  model  delta    sigma   weight residual
  1.520  1.512  0.008 3.00e-02 1.11e+03 7.85e-02
bond pdb=" CD  LYS A  24 "
     pdb=" CE  LYS A  24 "
  ideal  model  delta    sigma   weight residual
  1.520  1.512  0.008 3.00e-02 1.11e+03 7.71e-02
bond pdb=" CG  LEU A  28 "
     pdb=" CD2 LEU A  28 "
  ideal  model  delta    sigma   weight residual
  1.521  1.512  0.009 3.30e-02 9.18e+02 7.52e-02
bond pdb=" CB  PHE A  13 "
     pdb=" CG  PHE A  13 "
  ideal  model  delta    sigma   weight residual
  1.502  1.508 -0.006 2.30e-02 1.89e+03 7.48e-02
bond pdb=" C   PHE A  13 "
     pdb=" N   THR A  14 "
  ideal  model  delta    sigma   weight residual
  1.329  1.326  0.004 1.38e-02 5.25e+03 6.88e-02
bond pdb=" CA  PRO A  25 "
     pdb=" C   PRO A  25 "
  ideal  model  delta    sigma   weight residual
  1.520  1.516  0.003 1.24e-02 6.50e+03 6.84e-02
bond pdb=" CE  LYS A   3 "
     pdb=" NZ  LYS A   3 "
  ideal  model  delta    sigma   weight residual
  1.489  1.481  0.008 3.00e-02 1.11e+03 6.61e-02
bond pdb=" CA  TYR A  56 "
     pdb=" C   TYR A  56 "
  ideal  model  delta    sigma   weight residual
  1.524  1.520  0.003 1.26e-02 6.30e+03 6.37e-02
bond pdb=" N   TYR A  61 "
     pdb=" CA  TYR A  61 "
  ideal  model  delta    sigma   weight residual
  1.454  1.451  0.003 1.33e-02 5.65e+03 6.24e-02
bond pdb=" CG  LYS A   3 "
     pdb=" CD  LYS A   3 "
  ideal  model  delta    sigma   weight residual
  1.520  1.513  0.007 3.00e-02 1.11e+03 6.01e-02
bond pdb=" CB  LYS A  24 "
     pdb=" CG  LYS A  24 "
  ideal  model  delta    sigma   weight residual
  1.520  1.513  0.007 3.00e-02 1.11e+03 5.89e-02
bond pdb=" N   LEU A  37 "
     pdb=" CA  LEU A  37 "
  ideal  model  delta    sigma   weight residual
  1.456  1.459 -0.003 1.18e-02 7.18e+03 5.76e-02
bond pdb=" C   GLU A  40 "
     pdb=" N   TYR A  41 "
  ideal  model  delta    sigma   weight residual
  1.329  1.332 -0.003 1.35e-02 5.49e+03 5.67e-02
bond pdb=" C   GLN A  22 "
     pdb=" N   GLY A  23 "
  ideal  model  delta    sigma   weight residual
  1.332  1.336 -0.004 1.70e-02 3.46e+03 5.55e-02
bond pdb=" CA  PHE A  13 "
     pdb=" CB  PHE A  13 "
  ideal  model  delta    sigma   weight residual
  1.534  1.540 -0.005 2.33e-02 1.84e+03 5.41e-02
bond pdb=" CE  LYS A  69 "
     pdb=" NZ  LYS A  69 "
  ideal  model  delta    sigma   weight residual
  1.489  1.496 -0.007 3.00e-02 1.11e+03 5.40e-02
bond pdb=" N   ARG A  16 "
     pdb=" CA  ARG A  16 "
  ideal  model  delta    sigma   weight residual
  1.456  1.454  0.003 1.23e-02 6.61e+03 5.36e-02
bond pdb=" CB  GLU A  40 "
     pdb=" CG  GLU A  40 "
  ideal  model  delta    sigma   weight residual
  1.520  1.527 -0.007 3.00e-02 1.11e+03 5.26e-02
bond pdb=" CG1 ILE A   2 "
     pdb=" CD1 ILE A   2 "
  ideal  model  delta    sigma   weight residual
  1.513  1.522 -0.009 3.90e-02 6.57e+02 5.24e-02
bond pdb=" CA  ASP A  50 "
     pdb=" C   ASP A  50 "
  ideal  model  delta    sigma   weight residual
  1.527  1.524  0.003 1.35e-02 5.49e+03 5.22e-02
bond pdb=" CD1 TYR A  41 "
     pdb=" CE1 TYR A  41 "
  ideal  model  delta    sigma   weight residual
  1.382  1.375  0.007 3.00e-02 1.11e+03 5.17e-02
bond pdb=" CA  TYR A  26 "
     pdb=" CB  TYR A  26 "
  ideal  model  delta    sigma   weight residual
  1.536  1.531  0.005 2.08e-02 2.31e+03 5.11e-02
bond pdb=" CA  GLN A  22 "
     pdb=" C   GLN A  22 "
  ideal  model  delta    sigma   weight residual
  1.524  1.528 -0.004 1.66e-02 3.63e+03 5.10e-02
bond pdb=" CE  LYS A  24 "
     pdb=" NZ  LYS A  24 "
  ideal  model  delta    sigma   weight residual
  1.489  1.482  0.007 3.00e-02 1.11e+03 4.94e-02
bond pdb=" CZ  ARG A  21 "
     pdb=" NH2 ARG A  21 "
  ideal  model  delta    sigma   weight residual
  1.330  1.327  0.003 1.30e-02 5.92e+03 4.92e-02
bond pdb=" CA  TYR A  41 "
     pdb=" CB  TYR A  41 "
  ideal  model  delta    sigma   weight residual
  1.536  1.533  0.003 1.46e-02 4.69e+03 4.91e-02
bond pdb=" C   VAL A  63 "
     pdb=" N   HIS A  64 "
  ideal  model  delta    sigma   weight residual
  1.329  1.333 -0.003 1.36e-02 5.41e+03 4.89e-02
bond pdb=" CE2 TYR A  41 "
     pdb=" CZ  TYR A  41 "
  ideal  model  delta    sigma   weight residual
  1.378  1.373  0.005 2.40e-02 1.74e+03 4.89e-02
bond pdb=" CB  ILE A  47 "
     pdb=" CG1 ILE A  47 "
  ideal  model  delta    sigma   weight residual
  1.530  1.526  0.004 2.00e-02 2.50e+03 4.76e-02
bond pdb=" CA  VAL A  45 "
     pdb=" C   VAL A  45 "
  ideal  model  delta    sigma   weight residual
  1.522  1.519  0.003 1.18e-02 7.18e+03 4.63e-02
bond pdb=" CG  GLN A  53 "
     pdb=" CD  GLN A  53 "
  ideal  model  delta    sigma   weight residual
  1.516  1.521 -0.005 2.50e-02 1.60e+03 4.62e-02
bond pdb=" CD2 TYR A  26 "
     pdb=" CE2 TYR A  26 "
  ideal  model  delta    sigma   weight residual
  1.382  1.376  0.006 3.00e-02 1.11e+03 4.61e-02
bond pdb=" CA  ASN A  39 "
     pdb=" CB  ASN A  39 "
  ideal  model  delta    sigma   weight residual
  1.527  1.530 -0.003 1.49e-02 4.50e+03 4.53e-02
bond pdb=" C   SER A  67 "
     pdb=" O   SER A  67 "
  ideal  model  delta    sigma   weight residual
  1.236  1.233  0.003 1.29e-02 6.01e+03 4.50e-02
bond pdb=" CB  ARG A  80 "
     pdb=" CG  ARG A  80 "
  ideal  model  delta    sigma   weight residual
  1.520  1.514  0.006 3.00e-02 1.11e+03 4.49e-02
bond pdb=" C   ILE A  47 "
     pdb=" O   ILE A  47 "
  ideal  model  delta    sigma   weight residual
  1.236  1.234  0.002 1.02e-02 9.61e+03 4.46e-02
bond pdb=" CA  THR A  14 "
     pdb=" C   THR A  14 "
  ideal  model  delta    sigma   weight residual
  1.523  1.521  0.002 1.18e-02 7.18e+03 4.44e-02
bond pdb=" CA  ARG A  82 "
     pdb=" C   ARG A  82 "
  ideal  model  delta    sigma   weight residual
  1.523  1.520  0.003 1.23e-02 6.61e+03 4.23e-02
bond pdb=" N   ILE A   6 "
     pdb=" CA  ILE A   6 "
  ideal  model  delta    sigma   weight residual
  1.459  1.456  0.002 1.19e-02 7.06e+03 4.17e-02
bond pdb=" CA  GLN A  12 "
     pdb=" C   GLN A  12 "
  ideal  model  delta    sigma   weight residual
  1.524  1.521  0.003 1.23e-02 6.61e+03 4.15e-02
bond pdb=" CB  VAL A   4 "
     pdb=" CG2 VAL A   4 "
  ideal  model  delta    sigma   weight residual
  1.521  1.528 -0.007 3.30e-02 9.18e+02 4.09e-02
bond pdb=" C   LYS A  69 "
     pdb=" N   VAL A  70 "
  ideal  model  delta    sigma   weight residual
  1.329  1.326  0.003 1.32e-02 5.74e+03 4.07e-02
bond pdb=" CG  LEU A  32 "
     pdb=" CD1 LEU A  32 "
  ideal  model  delta    sigma   weight residual
  1.521  1.528 -0.007 3.30e-02 9.18e+02 4.05e-02
bond pdb=" CG  LYS A  24 "
     pdb=" CD  LYS A  24 "
  ideal  model  delta    sigma   weight residual
  1.520  1.514  0.006 3.00e-02 1.11e+03 4.05e-02
bond pdb=" N   VAL A  70 "
     pdb=" CA  VAL A  70 "
  ideal  model  delta    sigma   weight residual
  1.459  1.457  0.002 1.19e-02 7.06e+03 4.04e-02
bond pdb=" CB  GLU A   5 "
     pdb=" CG  GLU A   5 "
  ideal  model  delta    sigma   weight residual
  1.520  1.526 -0.006 3.00e-02 1.11e+03 4.04e-02
bond pdb=" CG  ARG A  80 "
     pdb=" CD  ARG A  80 "
  ideal  model  delta    sigma   weight residual
  1.520  1.514  0.006 3.00e-02 1.11e+03 3.91e-02
bond pdb=" N   ILE A   2 "
     pdb=" CA  ILE A   2 "
  ideal  model  delta    sigma   weight residual
  1.458  1.462 -0.004 1.90e-02 2.77e+03 3.76e-02
bond pdb=" N   LYS A  69 "
     pdb=" CA  LYS A  69 "
  ideal  model  delta    sigma   weight residual
  1.455  1.452  0.002 1.25e-02 6.40e+03 3.76e-02
bond pdb=" N   THR A  62 "
     pdb=" CA  THR A  62 "
  ideal  model  delta    sigma   weight residual
  1.454  1.452  0.003 1.33e-02 5.65e+03 3.67e-02
bond pdb=" N   GLU A  30 "
     pdb=" CA  GLU A  30 "
  ideal  model  delta    sigma   weight residual
  1.455  1.458 -0.002 1.23e-02 6.61e+03 3.62e-02
bond pdb=" CD  LYS A   3 "
     pdb=" CE  LYS A   3 "
  ideal  model  delta    sigma   weight residual
  1.520  1.514  0.006 3.00e-02 1.11e+03 3.61e-02
bond pdb=" C   ARG A  82 "
     pdb=" O   ARG A  82 "
  ideal  model  delta    sigma   weight residual
  1.236  1.234  0.002 1.19e-02 7.06e+03 3.61e-02
bond pdb=" CG  TYR A  41 "
     pdb=" CD2 TYR A  41 "
  ideal  model  delta    sigma   weight residual
  1.389  1.385  0.004 2.10e-02 2.27e+03 3.60e-02
bond pdb=" CZ  ARG A  21 "
     pdb=" NH1 ARG A  21 "
  ideal  model  delta    sigma   weight residual
  1.323  1.326 -0.003 1.40e-02 5.10e+03 3.59e-02
bond pdb=" CA  SER A  17 "
     pdb=" C   SER A  17 "
  ideal  model  delta    sigma   weight residual
  1.523  1.521  0.002 1.19e-02 7.06e+03 3.58e-02
bond pdb=" CG  LEU A  60 "
     pdb=" CD2 LEU A  60 "
  ideal  model  delta    sigma   weight residual
  1.521  1.515  0.006 3.30e-02 9.18e+02 3.54e-02
bond pdb=" N   LEU A  81 "
     pdb=" CA  LEU A  81 "
  ideal  model  delta    sigma   weight residual
  1.460  1.457  0.002 1.28e-02 6.10e+03 3.54e-02
bond pdb=" CA  PRO A   8 "
     pdb=" C   PRO A   8 "
  ideal  model  delta    sigma   weight residual
  1.516  1.520 -0.003 1.72e-02 3.38e+03 3.48e-02
bond pdb=" CA  GLN A  72 "
     pdb=" C   GLN A  72 "
  ideal  model  delta    sigma   weight residual
  1.522  1.525 -0.003 1.38e-02 5.25e+03 3.47e-02
bond pdb=" N   PRO A  58 "
     pdb=" CA  PRO A  58 "
  ideal  model  delta    sigma   weight residual
  1.467  1.469 -0.002 1.21e-02 6.83e+03 3.46e-02
bond pdb=" CB  ILE A  78 "
     pdb=" CG1 ILE A  78 "
  ideal  model  delta    sigma   weight residual
  1.530  1.526  0.004 2.00e-02 2.50e+03 3.39e-02
bond pdb=" C   ASN A  39 "
     pdb=" O   ASN A  39 "
  ideal  model  delta    sigma   weight residual
  1.234  1.236 -0.002 1.16e-02 7.43e+03 3.37e-02
bond pdb=" CG  LEU A  81 "
     pdb=" CD2 LEU A  81 "
  ideal  model  delta    sigma   weight residual
  1.521  1.515  0.006 3.30e-02 9.18e+02 3.36e-02
bond pdb=" N   GLY A  71 "
     pdb=" CA  GLY A  71 "
  ideal  model  delta    sigma   weight residual
  1.446  1.443  0.003 1.39e-02 5.18e+03 3.33e-02
bond pdb=" CA  VAL A  43 "
     pdb=" C   VAL A  43 "
  ideal  model  delta    sigma   weight residual
  1.522  1.524 -0.002 1.27e-02 6.20e+03 3.32e-02
bond pdb=" C   LEU A  32 "
     pdb=" N   CYS A  33 "
  ideal  model  delta    sigma   weight residual
  1.330  1.332 -0.002 1.26e-02 6.30e+03 3.26e-02
bond pdb=" CB  ASP A  36 "
     pdb=" CG  ASP A  36 "
  ideal  model  delta    sigma   weight residual
  1.516  1.521 -0.005 2.50e-02 1.60e+03 3.26e-02
bond pdb=" CB  LEU A  65 "
     pdb=" CG  LEU A  65 "
  ideal  model  delta    sigma   weight residual
  1.530  1.526  0.004 2.00e-02 2.50e+03 3.26e-02
bond pdb=" N   LEU A  32 "
     pdb=" CA  LEU A  32 "
  ideal  model  delta    sigma   weight residual
  1.454  1.456 -0.002 1.15e-02 7.56e+03 3.23e-02
bond pdb=" C   GLY A  38 "
     pdb=" N   ASN A  39 "
  ideal  model  delta    sigma   weight residual
  1.330  1.332 -0.003 1.60e-02 3.91e+03 3.22e-02
bond pdb=" CA  VAL A  43 "
     pdb=" CB  VAL A  43 "
  ideal  model  delta    sigma   weight residual
  1.544  1.546 -0.002 1.39e-02 5.18e+03 3.21e-02
bond pdb=" CB  LYS A  46 "
     pdb=" CG  LYS A  46 "
  ideal  model  delta    sigma   weight residual
  1.520  1.515  0.005 3.00e-02 1.11e+03 3.20e-02
bond pdb=" C   LEU A  83 "
     pdb=" N   VAL A  84 "
  ideal  model  delta    sigma   weight residual
  1.329  1.327  0.002 1.13e-02 7.83e+03 3.13e-02
bond pdb=" CA  VAL A  84 "
     pdb=" C   VAL A  84 "
  ideal  model  delta    sigma   weight residual
  1.524  1.526 -0.002 1.05e-02 9.07e+03 3.11e-02
bond pdb=" C   ARG A  80 "
     pdb=" N   LEU A  81 "
  ideal  model  delta    sigma   weight residual
  1.331  1.328  0.003 1.42e-02 4.96e+03 3.11e-02
bond pdb=" CB  GLN A  31 "
     pdb=" CG  GLN A  31 "
  ideal  model  delta    sigma   weight residual
  1.520  1.515  0.005 3.00e-02 1.11e+03 3.06e-02
bond pdb=" CB  VAL A  19 "
     pdb=" CG2 VAL A  19 "
  ideal  model  delta    sigma   weight residual
  1.521  1.515  0.006 3.30e-02 9.18e+02 3.03e-02
bond pdb=" CG  LEU A  44 "
     pdb=" CD2 LEU A  44 "
  ideal  model  delta    sigma   weight residual
  1.521  1.515  0.006 3.30e-02 9.18e+02 2.97e-02
bond pdb=" N   SER A  66 "
     pdb=" CA  SER A  66 "
  ideal  model  delta    sigma   weight residual
  1.458  1.460 -0.002 1.42e-02 4.96e+03 2.96e-02
bond pdb=" CA  PHE A  13 "
     pdb=" C   PHE A  13 "
  ideal  model  delta    sigma   weight residual
  1.522  1.520  0.002 1.20e-02 6.94e+03 2.87e-02
bond pdb=" CA  HIS A  64 "
     pdb=" C   HIS A  64 "
  ideal  model  delta    sigma   weight residual
  1.524  1.526 -0.002 1.31e-02 5.83e+03 2.78e-02
bond pdb=" C   ARG A  16 "
     pdb=" N   SER A  17 "
  ideal  model  delta    sigma   weight residual
  1.329  1.327  0.002 1.36e-02 5.41e+03 2.76e-02
bond pdb=" CA  GLN A  53 "
     pdb=" C   GLN A  53 "
  ideal  model  delta    sigma   weight residual
  1.525  1.523  0.002 1.14e-02 7.69e+03 2.75e-02
bond pdb=" CA  PRO A  42 "
     pdb=" CB  PRO A  42 "
  ideal  model  delta    sigma   weight residual
  1.533  1.535 -0.002 1.47e-02 4.63e+03 2.70e-02
bond pdb=" C   VAL A  43 "
     pdb=" O   VAL A  43 "
  ideal  model  delta    sigma   weight residual
  1.236  1.235  0.002 1.20e-02 6.94e+03 2.68e-02
bond pdb=" C   LEU A  81 "
     pdb=" N   ARG A  82 "
  ideal  model  delta    sigma   weight residual
  1.330  1.328  0.002 1.40e-02 5.10e+03 2.67e-02
bond pdb=" CA  SER A  67 "
     pdb=" C   SER A  67 "
  ideal  model  delta    sigma   weight residual
  1.522  1.520  0.002 1.40e-02 5.10e+03 2.66e-02
bond pdb=" CA  ILE A  47 "
     pdb=" C   ILE A  47 "
  ideal  model  delta    sigma   weight residual
  1.522  1.524 -0.002 1.18e-02 7.18e+03 2.63e-02
bond pdb=" CB  PRO A  85 "
     pdb=" CG  PRO A  85 "
  ideal  model  delta    sigma   weight residual
  1.492  1.484  0.008 5.00e-02 4.00e+02 2.60e-02
bond pdb=" CG  GLU A  40 "
     pdb=" CD  GLU A  40 "
  ideal  model  delta    sigma   weight residual
  1.516  1.520 -0.004 2.50e-02 1.60e+03 2.59e-02
bond pdb=" CD  GLU A   5 "
     pdb=" OE2 GLU A   5 "
  ideal  model  delta    sigma   weight residual
  1.249  1.246  0.003 1.90e-02 2.77e+03 2.58e-02
bond pdb=" CA  VAL A  19 "
     pdb=" CB  VAL A  19 "
  ideal  model  delta    sigma   weight residual
  1.544  1.542  0.002 1.42e-02 4.96e+03 2.51e-02
bond pdb=" CB  ILE A   2 "
     pdb=" CG1 ILE A   2 "
  ideal  model  delta    sigma   weight residual
  1.530  1.533 -0.003 2.00e-02 2.50e+03 2.48e-02
bond pdb=" CA  GLY A  59 "
     pdb=" C   GLY A  59 "
  ideal  model  delta    sigma   weight residual
  1.516  1.518 -0.002 1.03e-02 9.43e+03 2.43e-02
bond pdb=" CA  LYS A   7 "
     pdb=" C   LYS A   7 "
  ideal  model  delta    sigma   weight residual
  1.527  1.525  0.002 1.32e-02 5.74e+03 2.43e-02
bond pdb=" C   VAL A   4 "
     pdb=" O   VAL A   4 "
  ideal  model  delta    sigma   weight residual
  1.236  1.234  0.002 1.02e-02 9.61e+03 2.37e-02
bond pdb=" CE1 PHE A  13 "
     pdb=" CZ  PHE A  13 "
  ideal  model  delta    sigma   weight residual
  1.382  1.377  0.005 3.00e-02 1.11e+03 2.36e-02
bond pdb=" CB  LYS A  69 "
     pdb=" CG  LYS A  69 "
  ideal  model  delta    sigma   weight residual
  1.520  1.525 -0.005 3.00e-02 1.11e+03 2.29e-02
bond pdb=" CA  GLU A  40 "
     pdb=" C   GLU A  40 "
  ideal  model  delta    sigma   weight residual
  1.523  1.525 -0.002 1.30e-02 5.92e+03 2.27e-02
bond pdb=" CE2 TYR A  34 "
     pdb=" CZ  TYR A  34 "
  ideal  model  delta    sigma   weight residual
  1.378  1.382 -0.004 2.40e-02 1.74e+03 2.25e-02
bond pdb=" N   GLU A  51 "
     pdb=" CA  GLU A  51 "
  ideal  model  delta    sigma   weight residual
  1.456  1.454  0.002 1.22e-02 6.72e+03 2.22e-02
bond pdb=" C   THR A  48 "
     pdb=" N   LEU A  49 "
  ideal  model  delta    sigma   weight residual
  1.330  1.328  0.002 1.31e-02 5.83e+03 2.22e-02
bond pdb=" CB  TYR A  61 "
     pdb=" CG  TYR A  61 "
  ideal  model  delta    sigma   weight residual
  1.512  1.509  0.003 2.20e-02 2.07e+03 2.17e-02
bond pdb=" N   GLN A  22 "
     pdb=" CA  GLN A  22 "
  ideal  model  delta    sigma   weight residual
  1.455  1.457 -0.002 1.25e-02 6.40e+03 2.13e-02
bond pdb=" CA  PRO A  42 "
     pdb=" C   PRO A  42 "
  ideal  model  delta    sigma   weight residual
  1.521  1.519  0.002 1.19e-02 7.06e+03 2.12e-02
bond pdb=" CB  ARG A  82 "
     pdb=" CG  ARG A  82 "
  ideal  model  delta    sigma   weight residual
  1.520  1.516  0.004 3.00e-02 1.11e+03 2.12e-02
bond pdb=" N   ILE A  78 "
     pdb=" CA  ILE A  78 "
  ideal  model  delta    sigma   weight residual
  1.459  1.457  0.002 1.24e-02 6.50e+03 2.11e-02
bond pdb=" CG1 ILE A  47 "
     pdb=" CD1 ILE A  47 "
  ideal  model  delta    sigma   weight residual
  1.513  1.507  0.006 3.90e-02 6.57e+02 2.09e-02
bond pdb=" CA  ARG A  82 "
     pdb=" CB  ARG A  82 "
  ideal  model  delta    sigma   weight residual
  1.529  1.527  0.002 1.38e-02 5.25e+03 2.07e-02
bond pdb=" CA  LYS A  69 "
     pdb=" C   LYS A  69 "
  ideal  model  delta    sigma   weight residual
  1.522  1.520  0.002 1.24e-02 6.50e+03 2.07e-02
bond pdb=" C   THR A  14 "
     pdb=" N   THR A  15 "
  ideal  model  delta    sigma   weight residual
  1.330  1.328  0.002 1.40e-02 5.10e+03 2.06e-02
bond pdb=" N   GLY A  18 "
     pdb=" CA  GLY A  18 "
  ideal  model  delta    sigma   weight residual
  1.451  1.449  0.002 1.13e-02 7.83e+03 2.06e-02
bond pdb=" CD  LYS A  46 "
     pdb=" CE  LYS A  46 "
  ideal  model  delta    sigma   weight residual
  1.520  1.516  0.004 3.00e-02 1.11e+03 2.06e-02
bond pdb=" CA  GLN A  72 "
     pdb=" CB  GLN A  72 "
  ideal  model  delta    sigma   weight residual
  1.529  1.532 -0.003 1.78e-02 3.16e+03 2.06e-02
bond pdb=" CG  ARG A  16 "
     pdb=" CD  ARG A  16 "
  ideal  model  delta    sigma   weight residual
  1.520  1.524 -0.004 3.00e-02 1.11e+03 1.99e-02
bond pdb=" CG  GLN A  12 "
     pdb=" CD  GLN A  12 "
  ideal  model  delta    sigma   weight residual
  1.516  1.520 -0.004 2.50e-02 1.60e+03 1.98e-02
bond pdb=" C   ALA A  57 "
     pdb=" N   PRO A  58 "
  ideal  model  delta    sigma   weight residual
  1.332  1.333 -0.002 1.30e-02 5.92e+03 1.97e-02
bond pdb=" CA  ASN A  29 "
     pdb=" C   ASN A  29 "
  ideal  model  delta    sigma   weight residual
  1.523  1.525 -0.002 1.23e-02 6.61e+03 1.96e-02
bond pdb=" N   THR A  48 "
     pdb=" CA  THR A  48 "
  ideal  model  delta    sigma   weight residual
  1.459  1.457  0.002 1.27e-02 6.20e+03 1.96e-02
bond pdb=" C   ILE A   6 "
     pdb=" N   LYS A   7 "
  ideal  model  delta    sigma   weight residual
  1.331  1.329  0.002 1.48e-02 4.57e+03 1.95e-02
bond pdb=" CB  LEU A  60 "
     pdb=" CG  LEU A  60 "
  ideal  model  delta    sigma   weight residual
  1.530  1.527  0.003 2.00e-02 2.50e+03 1.94e-02
bond pdb=" CA  LEU A  65 "
     pdb=" C   LEU A  65 "
  ideal  model  delta    sigma   weight residual
  1.522  1.524 -0.002 1.36e-02 5.41e+03 1.93e-02
bond pdb=" C   LYS A   7 "
     pdb=" O   LYS A   7 "
  ideal  model  delta    sigma   weight residual
  1.233  1.232  0.002 1.26e-02 6.30e+03 1.92e-02
bond pdb=" C   ILE A   2 "
     pdb=" O   ILE A   2 "
  ideal  model  delta    sigma   weight residual
  1.231  1.234 -0.003 2.00e-02 2.50e+03 1.91e-02
bond pdb=" CA  THR A  48 "
     pdb=" C   THR A  48 "
  ideal  model  delta    sigma   weight residual
  1.525  1.523  0.002 1.28e-02 6.10e+03 1.89e-02
bond pdb=" CG  PRO A   8 "
     pdb=" CD  PRO A   8 "
  ideal  model  delta    sigma   weight residual
  1.503  1.498  0.005 3.40e-02 8.65e+02 1.79e-02
bond pdb=" CB  SER A  75 "
     pdb=" OG  SER A  75 "
  ideal  model  delta    sigma   weight residual
  1.417  1.414  0.003 2.00e-02 2.50e+03 1.76e-02
bond pdb=" C   GLY A  52 "
     pdb=" N   GLN A  53 "
  ideal  model  delta    sigma   weight residual
  1.327  1.330 -0.003 2.31e-02 1.87e+03 1.74e-02
bond pdb=" CD  LYS A  69 "
     pdb=" CE  LYS A  69 "
  ideal  model  delta    sigma   weight residual
  1.520  1.524 -0.004 3.00e-02 1.11e+03 1.73e-02
bond pdb=" N   TYR A  34 "
     pdb=" CA  TYR A  34 "
  ideal  model  delta    sigma   weight residual
  1.458  1.456  0.002 1.19e-02 7.06e+03 1.69e-02
bond pdb=" CA  THR A  62 "
     pdb=" C   THR A  62 "
  ideal  model  delta    sigma   weight residual
  1.523  1.524 -0.002 1.25e-02 6.40e+03 1.64e-02
bond pdb=" N   SER A  75 "
     pdb=" CA  SER A  75 "
  ideal  model  delta    sigma   weight residual
  1.454  1.455 -0.002 1.21e-02 6.83e+03 1.63e-02
bond pdb=" N   PRO A  85 "
     pdb=" CD  PRO A  85 "
  ideal  model  delta    sigma   weight residual
  1.473  1.475 -0.002 1.40e-02 5.10e+03 1.62e-02
bond pdb=" CE2 PHE A  73 "
     pdb=" CZ  PHE A  73 "
  ideal  model  delta    sigma   weight residual
  1.382  1.378  0.004 3.00e-02 1.11e+03 1.61e-02
bond pdb=" CA  LEU A  32 "
     pdb=" C   LEU A  32 "
  ideal  model  delta    sigma   weight residual
  1.524  1.526 -0.002 1.31e-02 5.83e+03 1.59e-02
bond pdb=" CB  PRO A  25 "
     pdb=" CG  PRO A  25 "
  ideal  model  delta    sigma   weight residual
  1.492  1.486  0.006 5.00e-02 4.00e+02 1.58e-02
bond pdb=" C   VAL A  70 "
     pdb=" N   GLY A  71 "
  ideal  model  delta    sigma   weight residual
  1.328  1.327  0.002 1.34e-02 5.57e+03 1.58e-02
bond pdb=" C   GLN A  31 "
     pdb=" N   LEU A  32 "
  ideal  model  delta    sigma   weight residual
  1.328  1.330 -0.002 1.42e-02 4.96e+03 1.54e-02
bond pdb=" CG  TYR A  26 "
     pdb=" CD1 TYR A  26 "
  ideal  model  delta    sigma   weight residual
  1.389  1.392 -0.003 2.10e-02 2.27e+03 1.54e-02
bond pdb=" CA  PHE A  73 "
     pdb=" C   PHE A  73 "
  ideal  model  delta    sigma   weight residual
  1.523  1.521  0.002 1.34e-02 5.57e+03 1.54e-02
bond pdb=" C   ASP A  50 "
     pdb=" N   GLU A  51 "
  ideal  model  delta    sigma   weight residual
  1.330  1.328  0.002 1.32e-02 5.74e+03 1.52e-02
bond pdb=" CA  THR A  14 "
     pdb=" CB  THR A  14 "
  ideal  model  delta    sigma   weight residual
  1.532  1.530  0.002 1.74e-02 3.30e+03 1.51e-02
bond pdb=" CB  PRO A  58 "
     pdb=" CG  PRO A  58 "
  ideal  model  delta    sigma   weight residual
  1.492  1.486  0.006 5.00e-02 4.00e+02 1.49e-02
bond pdb=" CB  VAL A  63 "
     pdb=" CG1 VAL A  63 "
  ideal  model  delta    sigma   weight residual
  1.521  1.517  0.004 3.30e-02 9.18e+02 1.49e-02
bond pdb=" C   TYR A  41 "
     pdb=" N   PRO A  42 "
  ideal  model  delta    sigma   weight residual
  1.332  1.330  0.002 1.26e-02 6.30e+03 1.48e-02
bond pdb=" CG  ASP A  79 "
     pdb=" OD1 ASP A  79 "
  ideal  model  delta    sigma   weight residual
  1.249  1.251 -0.002 1.90e-02 2.77e+03 1.48e-02
bond pdb=" CA  GLN A  31 "
     pdb=" C   GLN A  31 "
  ideal  model  delta    sigma   weight residual
  1.522  1.523 -0.001 1.21e-02 6.83e+03 1.48e-02
bond pdb=" N   VAL A  84 "
     pdb=" CA  VAL A  84 "
  ideal  model  delta    sigma   weight residual
  1.461  1.460  0.001 1.23e-02 6.61e+03 1.47e-02
bond pdb=" N   GLY A  59 "
     pdb=" CA  GLY A  59 "
  ideal  model  delta    sigma   weight residual
  1.447  1.446  0.001 9.20e-03 1.18e+04 1.47e-02
bond pdb=" CA  THR A  15 "
     pdb=" C   THR A  15 "
  ideal  model  delta    sigma   weight residual
  1.523  1.521  0.001 1.23e-02 6.61e+03 1.46e-02
bond pdb=" C   ILE A  78 "
     pdb=" N   ASP A  79 "
  ideal  model  delta    sigma   weight residual
  1.332  1.331  0.002 1.40e-02 5.10e+03 1.44e-02
bond pdb=" CA  GLU A  51 "
     pdb=" C   GLU A  51 "
  ideal  model  delta    sigma   weight residual
  1.524  1.525 -0.002 1.30e-02 5.92e+03 1.41e-02
bond pdb=" CE2 TYR A  56 "
     pdb=" CZ  TYR A  56 "
  ideal  model  delta    sigma   weight residual
  1.378  1.381 -0.003 2.40e-02 1.74e+03 1.41e-02
bond pdb=" C   ASN A  29 "
     pdb=" O   ASN A  29 "
  ideal  model  delta    sigma   weight residual
  1.236  1.234  0.001 1.21e-02 6.83e+03 1.41e-02
bond pdb=" CG  ARG A  21 "
     pdb=" CD  ARG A  21 "
  ideal  model  delta    sigma   weight residual
  1.520  1.516  0.004 3.00e-02 1.11e+03 1.40e-02
bond pdb=" CA  LYS A   3 "
     pdb=" CB  LYS A   3 "
  ideal  model  delta    sigma   weight residual
  1.530  1.528  0.002 1.43e-02 4.89e+03 1.39e-02
bond pdb=" C   GLU A  30 "
     pdb=" N   GLN A  31 "
  ideal  model  delta    sigma   weight residual
  1.331  1.333 -0.002 1.51e-02 4.39e+03 1.38e-02
bond pdb=" CA  SER A  20 "
     pdb=" CB  SER A  20 "
  ideal  model  delta    sigma   weight residual
  1.527  1.529 -0.002 1.44e-02 4.82e+03 1.37e-02
bond pdb=" CB  THR A  62 "
     pdb=" CG2 THR A  62 "
  ideal  model  delta    sigma   weight residual
  1.521  1.517  0.004 3.30e-02 9.18e+02 1.37e-02
bond pdb=" C   ASN A  29 "
     pdb=" N   GLU A  30 "
  ideal  model  delta    sigma   weight residual
  1.330  1.332 -0.002 1.44e-02 4.82e+03 1.34e-02
bond pdb=" CB  LEU A  81 "
     pdb=" CG  LEU A  81 "
  ideal  model  delta    sigma   weight residual
  1.530  1.528  0.002 2.00e-02 2.50e+03 1.30e-02
bond pdb=" CB  PHE A  68 "
     pdb=" CG  PHE A  68 "
  ideal  model  delta    sigma   weight residual
  1.502  1.499  0.003 2.30e-02 1.89e+03 1.29e-02
bond pdb=" CA  SER A   9 "
     pdb=" CB  SER A   9 "
  ideal  model  delta    sigma   weight residual
  1.531  1.529  0.002 1.72e-02 3.38e+03 1.28e-02
bond pdb=" C   PRO A  58 "
     pdb=" N   GLY A  59 "
  ideal  model  delta    sigma   weight residual
  1.325  1.326 -0.001 1.06e-02 8.90e+03 1.28e-02
bond pdb=" CE2 PHE A  68 "
     pdb=" CZ  PHE A  68 "
  ideal  model  delta    sigma   weight residual
  1.382  1.379  0.003 3.00e-02 1.11e+03 1.26e-02
bond pdb=" CD2 PHE A  13 "
     pdb=" CE2 PHE A  13 "
  ideal  model  delta    sigma   weight residual
  1.382  1.385 -0.003 3.00e-02 1.11e+03 1.25e-02
bond pdb=" N   PHE A  13 "
     pdb=" CA  PHE A  13 "
  ideal  model  delta    sigma   weight residual
  1.454  1.453  0.001 1.23e-02 6.61e+03 1.25e-02
bond pdb=" C   ILE A  47 "
     pdb=" N   THR A  48 "
  ideal  model  delta    sigma   weight residual
  1.331  1.329  0.002 1.65e-02 3.67e+03 1.24e-02
bond pdb=" N   GLN A  12 "
     pdb=" CA  GLN A  12 "
  ideal  model  delta    sigma   weight residual
  1.455  1.456 -0.001 1.25e-02 6.40e+03 1.24e-02
bond pdb=" CA  TYR A  61 "
     pdb=" CB  TYR A  61 "
  ideal  model  delta    sigma   weight residual
  1.535  1.537 -0.002 1.71e-02 3.42e+03 1.23e-02
bond pdb=" CE2 TYR A  26 "
     pdb=" CZ  TYR A  26 "
  ideal  model  delta    sigma   weight residual
  1.378  1.375  0.003 2.40e-02 1.74e+03 1.23e-02
bond pdb=" NE  ARG A  21 "
     pdb=" CZ  ARG A  21 "
  ideal  model  delta    sigma   weight residual
  1.326  1.327 -0.001 1.10e-02 8.26e+03 1.22e-02
bond pdb=" CA  GLY A  71 "
     pdb=" C   GLY A  71 "
  ideal  model  delta    sigma   weight residual
  1.518  1.516  0.002 1.66e-02 3.63e+03 1.22e-02
bond pdb=" CG  PHE A  13 "
     pdb=" CD1 PHE A  13 "
  ideal  model  delta    sigma   weight residual
  1.384  1.386 -0.002 2.10e-02 2.27e+03 1.22e-02
bond pdb=" CZ  ARG A  16 "
     pdb=" NH2 ARG A  16 "
  ideal  model  delta    sigma   weight residual
  1.330  1.331 -0.001 1.30e-02 5.92e+03 1.21e-02
bond pdb=" CA  GLU A  51 "
     pdb=" CB  GLU A  51 "
  ideal  model  delta    sigma   weight residual
  1.528  1.527  0.002 1.66e-02 3.63e+03 1.21e-02
bond pdb=" CA  ILE A   6 "
     pdb=" CB  ILE A   6 "
  ideal  model  delta    sigma   weight residual
  1.535  1.533  0.001 1.18e-02 7.18e+03 1.20e-02
bond pdb=" C   LYS A   7 "
     pdb=" N   PRO A   8 "
  ideal  model  delta    sigma   weight residual
  1.333  1.335 -0.002 1.44e-02 4.82e+03 1.19e-02
bond pdb=" CB  LEU A  32 "
     pdb=" CG  LEU A  32 "
  ideal  model  delta    sigma   weight residual
  1.530  1.532 -0.002 2.00e-02 2.50e+03 1.19e-02
bond pdb=" CA  ARG A  16 "
     pdb=" CB  ARG A  16 "
  ideal  model  delta    sigma   weight residual
  1.530  1.531 -0.002 1.43e-02 4.89e+03 1.18e-02
bond pdb=" CA  TYR A  61 "
     pdb=" C   TYR A  61 "
  ideal  model  delta    sigma   weight residual
  1.523  1.521  0.001 1.25e-02 6.40e+03 1.18e-02
bond pdb=" N   SER A  17 "
     pdb=" CA  SER A  17 "
  ideal  model  delta    sigma   weight residual
  1.454  1.453  0.001 1.18e-02 7.18e+03 1.17e-02
bond pdb=" C   VAL A  35 "
     pdb=" N   ASP A  36 "
  ideal  model  delta    sigma   weight residual
  1.331  1.329  0.002 1.43e-02 4.89e+03 1.17e-02
bond pdb=" CB  VAL A  63 "
     pdb=" CG2 VAL A  63 "
  ideal  model  delta    sigma   weight residual
  1.521  1.517  0.004 3.30e-02 9.18e+02 1.16e-02
bond pdb=" CB  LEU A  76 "
     pdb=" CG  LEU A  76 "
  ideal  model  delta    sigma   weight residual
  1.530  1.528  0.002 2.00e-02 2.50e+03 1.16e-02
bond pdb=" N   LEU A  65 "
     pdb=" CA  LEU A  65 "
  ideal  model  delta    sigma   weight residual
  1.459  1.460 -0.001 1.25e-02 6.40e+03 1.16e-02
bond pdb=" C   THR A  15 "
     pdb=" N   ARG A  16 "
  ideal  model  delta    sigma   weight residual
  1.330  1.328  0.001 1.39e-02 5.18e+03 1.10e-02
bond pdb=" C   ASP A  79 "
     pdb=" O   ASP A  79 "
  ideal  model  delta    sigma   weight residual
  1.235  1.234  0.001 1.26e-02 6.30e+03 1.07e-02
bond pdb=" CD  GLU A  40 "
     pdb=" OE1 GLU A  40 "
  ideal  model  delta    sigma   weight residual
  1.249  1.251 -0.002 1.90e-02 2.77e+03 1.07e-02
bond pdb=" N   TYR A  56 "
     pdb=" CA  TYR A  56 "
  ideal  model  delta    sigma   weight residual
  1.456  1.455  0.001 1.23e-02 6.61e+03 1.05e-02
bond pdb=" C   PHE A  68 "
     pdb=" N   LYS A  69 "
  ideal  model  delta    sigma   weight residual
  1.331  1.330  0.001 1.28e-02 6.10e+03 1.05e-02
bond pdb=" N   ASP A  79 "
     pdb=" CA  ASP A  79 "
  ideal  model  delta    sigma   weight residual
  1.457  1.456  0.001 1.29e-02 6.01e+03 1.05e-02
bond pdb=" CA  PRO A  54 "
     pdb=" C   PRO A  54 "
  ideal  model  delta    sigma   weight residual
  1.521  1.520  0.001 1.20e-02 6.94e+03 1.05e-02
bond pdb=" CA  ASP A  79 "
     pdb=" CB  ASP A  79 "
  ideal  model  delta    sigma   weight residual
  1.530  1.532 -0.002 1.69e-02 3.50e+03 1.04e-02
bond pdb=" CB  GLU A  51 "
     pdb=" CG  GLU A  51 "
  ideal  model  delta    sigma   weight residual
  1.520  1.517  0.003 3.00e-02 1.11e+03 1.01e-02
bond pdb=" N   GLN A  31 "
     pdb=" CA  GLN A  31 "
  ideal  model  delta    sigma   weight residual
  1.454  1.456 -0.001 1.27e-02 6.20e+03 1.00e-02
bond pdb=" CD  GLN A  12 "
     pdb=" OE1 GLN A  12 "
  ideal  model  delta    sigma   weight residual
  1.231  1.233 -0.002 1.90e-02 2.77e+03 9.89e-03
bond pdb=" CG  GLN A  72 "
     pdb=" CD  GLN A  72 "
  ideal  model  delta    sigma   weight residual
  1.516  1.518 -0.002 2.50e-02 1.60e+03 9.87e-03
bond pdb=" CB  VAL A  84 "
     pdb=" CG2 VAL A  84 "
  ideal  model  delta    sigma   weight residual
  1.521  1.524 -0.003 3.30e-02 9.18e+02 9.82e-03
bond pdb=" CG  ASP A  50 "
     pdb=" OD1 ASP A  50 "
  ideal  model  delta    sigma   weight residual
  1.249  1.251 -0.002 1.90e-02 2.77e+03 9.77e-03
bond pdb=" CG  TYR A  61 "
     pdb=" CD1 TYR A  61 "
  ideal  model  delta    sigma   weight residual
  1.389  1.387  0.002 2.10e-02 2.27e+03 9.62e-03
bond pdb=" C   SER A  75 "
     pdb=" N   LEU A  76 "
  ideal  model  delta    sigma   weight residual
  1.330  1.331 -0.001 1.32e-02 5.74e+03 9.60e-03
bond pdb=" N   PRO A   8 "
     pdb=" CD  PRO A   8 "
  ideal  model  delta    sigma   weight residual
  1.473  1.474 -0.001 1.40e-02 5.10e+03 9.51e-03
bond pdb=" CD  GLN A  12 "
     pdb=" NE2 GLN A  12 "
  ideal  model  delta    sigma   weight residual
  1.328  1.330 -0.002 2.10e-02 2.27e+03 9.36e-03
bond pdb=" CD  GLU A   5 "
     pdb=" OE1 GLU A   5 "
  ideal  model  delta    sigma   weight residual
  1.249  1.247  0.002 1.90e-02 2.77e+03 9.27e-03
bond pdb=" CB  CYS A  33 "
     pdb=" SG  CYS A  33 "
  ideal  model  delta    sigma   weight residual
  1.808  1.805  0.003 3.30e-02 9.18e+02 9.24e-03
bond pdb=" CA  LEU A  81 "
     pdb=" C   LEU A  81 "
  ideal  model  delta    sigma   weight residual
  1.524  1.525 -0.001 1.29e-02 6.01e+03 9.22e-03
bond pdb=" CG  LEU A  37 "
     pdb=" CD2 LEU A  37 "
  ideal  model  delta    sigma   weight residual
  1.521  1.524 -0.003 3.30e-02 9.18e+02 9.07e-03
bond pdb=" C   GLU A  30 "
     pdb=" O   GLU A  30 "
  ideal  model  delta    sigma   weight residual
  1.235  1.234  0.001 1.28e-02 6.10e+03 9.04e-03
bond pdb=" CB  GLN A  53 "
     pdb=" CG  GLN A  53 "
  ideal  model  delta    sigma   weight residual
  1.520  1.523 -0.003 3.00e-02 1.11e+03 8.98e-03
bond pdb=" CA  THR A  15 "
     pdb=" CB  THR A  15 "
  ideal  model  delta    sigma   weight residual
  1.529  1.528  0.001 1.38e-02 5.25e+03 8.90e-03
bond pdb=" C   TYR A  34 "
     pdb=" O   TYR A  34 "
  ideal  model  delta    sigma   weight residual
  1.236  1.235  0.001 1.14e-02 7.69e+03 8.80e-03
bond pdb=" CD  GLN A  53 "
     pdb=" OE1 GLN A  53 "
  ideal  model  delta    sigma   weight residual
  1.231  1.229  0.002 1.90e-02 2.77e+03 8.74e-03
bond pdb=" N   THR A  14 "
     pdb=" CA  THR A  14 "
  ideal  model  delta    sigma   weight residual
  1.454  1.453  0.001 1.19e-02 7.06e+03 8.68e-03
bond pdb=" CA  ASP A  36 "
     pdb=" C   ASP A  36 "
  ideal  model  delta    sigma   weight residual
  1.525  1.526 -0.001 1.25e-02 6.40e+03 8.67e-03
bond pdb=" C   GLY A  74 "
     pdb=" O   GLY A  74 "
  ideal  model  delta    sigma   weight residual
  1.238  1.237  0.001 1.45e-02 4.76e+03 8.63e-03
bond pdb=" CA  SER A  27 "
     pdb=" CB  SER A  27 "
  ideal  model  delta    sigma   weight residual
  1.534  1.532  0.002 1.72e-02 3.38e+03 8.61e-03
bond pdb=" NE  ARG A  82 "
     pdb=" CZ  ARG A  82 "
  ideal  model  delta    sigma   weight residual
  1.326  1.325  0.001 1.10e-02 8.26e+03 8.51e-03
bond pdb=" CD2 PHE A  68 "
     pdb=" CE2 PHE A  68 "
  ideal  model  delta    sigma   weight residual
  1.382  1.385 -0.003 3.00e-02 1.11e+03 8.48e-03
bond pdb=" CE  LYS A   7 "
     pdb=" NZ  LYS A   7 "
  ideal  model  delta    sigma   weight residual
  1.489  1.486  0.003 3.00e-02 1.11e+03 8.45e-03
bond pdb=" CA  VAL A  84 "
     pdb=" CB  VAL A  84 "
  ideal  model  delta    sigma   weight residual
  1.537  1.538 -0.001 1.29e-02 6.01e+03 8.45e-03
bond pdb=" CA  LYS A   7 "
     pdb=" CB  LYS A   7 "
  ideal  model  delta    sigma   weight residual
  1.526  1.525  0.001 1.53e-02 4.27e+03 8.44e-03
bond pdb=" C   GLN A  31 "
     pdb=" O   GLN A  31 "
  ideal  model  delta    sigma   weight residual
  1.234  1.233  0.001 1.26e-02 6.30e+03 8.33e-03
bond pdb=" CB  SER A  20 "
     pdb=" OG  SER A  20 "
  ideal  model  delta    sigma   weight residual
  1.417  1.415  0.002 2.00e-02 2.50e+03 8.31e-03
bond pdb=" C   ALA A  11 "
     pdb=" O   ALA A  11 "
  ideal  model  delta    sigma   weight residual
  1.236  1.235  0.001 1.35e-02 5.49e+03 8.21e-03
bond pdb=" CB  GLU A  30 "
     pdb=" CG  GLU A  30 "
  ideal  model  delta    sigma   weight residual
  1.520  1.517  0.003 3.00e-02 1.11e+03 8.19e-03
bond pdb=" N   PRO A   8 "
     pdb=" CA  PRO A   8 "
  ideal  model  delta    sigma   weight residual
  1.471  1.472 -0.001 1.32e-02 5.74e+03 8.08e-03
bond pdb=" CZ  TYR A  56 "
     pdb=" OH  TYR A  56 "
  ideal  model  delta    sigma   weight residual
  1.376  1.374  0.002 2.10e-02 2.27e+03 8.04e-03
bond pdb=" CA  VAL A   4 "
     pdb=" CB  VAL A   4 "
  ideal  model  delta    sigma   weight residual
  1.544  1.545 -0.001 1.32e-02 5.74e+03 7.63e-03
bond pdb=" C   ALA A  55 "
     pdb=" N   TYR A  56 "
  ideal  model  delta    sigma   weight residual
  1.331  1.330  0.001 1.33e-02 5.65e+03 7.62e-03
bond pdb=" CG  PHE A  68 "
     pdb=" CD2 PHE A  68 "
  ideal  model  delta    sigma   weight residual
  1.384  1.386 -0.002 2.10e-02 2.27e+03 7.47e-03
bond pdb=" N   ALA A  57 "
     pdb=" CA  ALA A  57 "
  ideal  model  delta    sigma   weight residual
  1.451  1.449  0.001 1.60e-02 3.91e+03 7.44e-03
bond pdb=" CA  LEU A  32 "
     pdb=" CB  LEU A  32 "
  ideal  model  delta    sigma   weight residual
  1.531  1.533 -0.001 1.58e-02 4.01e+03 7.37e-03
bond pdb=" C   GLY A  71 "
     pdb=" N   GLN A  72 "
  ideal  model  delta    sigma   weight residual
  1.334  1.333  0.001 1.38e-02 5.25e+03 7.32e-03
bond pdb=" N   TYR A  41 "
     pdb=" CA  TYR A  41 "
  ideal  model  delta    sigma   weight residual
  1.453  1.454 -0.001 1.18e-02 7.18e+03 7.19e-03
bond pdb=" C   TYR A  34 "
     pdb=" N   VAL A  35 "
  ideal  model  delta    sigma   weight residual
  1.330  1.329  0.001 1.26e-02 6.30e+03 7.18e-03
bond pdb=" N   SER A  67 "
     pdb=" CA  SER A  67 "
  ideal  model  delta    sigma   weight residual
  1.458  1.456  0.001 1.33e-02 5.65e+03 7.06e-03
bond pdb=" C   GLU A   5 "
     pdb=" O   GLU A   5 "
  ideal  model  delta    sigma   weight residual
  1.235  1.236 -0.001 1.22e-02 6.72e+03 6.95e-03
bond pdb=" CA  LEU A  83 "
     pdb=" CB  LEU A  83 "
  ideal  model  delta    sigma   weight residual
  1.530  1.529  0.001 1.58e-02 4.01e+03 6.88e-03
bond pdb=" C   ILE A  78 "
     pdb=" O   ILE A  78 "
  ideal  model  delta    sigma   weight residual
  1.238  1.237  0.001 1.09e-02 8.42e+03 6.87e-03
bond pdb=" N   THR A  15 "
     pdb=" CA  THR A  15 "
  ideal  model  delta    sigma   weight residual
  1.458  1.457  0.001 1.22e-02 6.72e+03 6.84e-03
bond pdb=" CA  SER A  67 "
     pdb=" CB  SER A  67 "
  ideal  model  delta    sigma   weight residual
  1.529  1.531 -0.001 1.74e-02 3.30e+03 6.84e-03
bond pdb=" C   PRO A  54 "
     pdb=" N   ALA A  55 "
  ideal  model  delta    sigma   weight residual
  1.330  1.329  0.001 1.32e-02 5.74e+03 6.71e-03
bond pdb=" C   PRO A  85 "
     pdb=" O   PRO A  85 "
  ideal  model  delta    sigma   weight residual
  1.231  1.229  0.002 2.00e-02 2.50e+03 6.67e-03
bond pdb=" CD  ARG A  21 "
     pdb=" NE  ARG A  21 "
  ideal  model  delta    sigma   weight residual
  1.458  1.457  0.001 1.40e-02 5.10e+03 6.65e-03
bond pdb=" C   ASP A  36 "
     pdb=" O   ASP A  36 "
  ideal  model  delta    sigma   weight residual
  1.235  1.234  0.001 1.23e-02 6.61e+03 6.58e-03
bond pdb=" CB  ILE A   6 "
     pdb=" CG1 ILE A   6 "
  ideal  model  delta    sigma   weight residual
  1.530  1.532 -0.002 2.00e-02 2.50e+03 6.50e-03
bond pdb=" CD1 PHE A  13 "
     pdb=" CE1 PHE A  13 "
  ideal  model  delta    sigma   weight residual
  1.382  1.384 -0.002 3.00e-02 1.11e+03 6.40e-03
bond pdb=" C   VAL A  35 "
     pdb=" O   VAL A  35 "
  ideal  model  delta    sigma   weight residual
  1.237  1.238 -0.001 1.11e-02 8.12e+03 6.31e-03
bond pdb=" CG  PRO A  58 "
     pdb=" CD  PRO A  58 "
  ideal  model  delta    sigma   weight residual
  1.503  1.500  0.003 3.40e-02 8.65e+02 6.07e-03
bond pdb=" CA  LEU A  60 "
     pdb=" C   LEU A  60 "
  ideal  model  delta    sigma   weight residual
  1.522  1.523 -0.001 1.20e-02 6.94e+03 5.95e-03
bond pdb=" CA  ALA A  55 "
     pdb=" CB  ALA A  55 "
  ideal  model  delta    sigma   weight residual
  1.528  1.527  0.001 1.66e-02 3.63e+03 5.90e-03
bond pdb=" C   PHE A  13 "
     pdb=" O   PHE A  13 "
  ideal  model  delta    sigma   weight residual
  1.235  1.234  0.001 1.30e-02 5.92e+03 5.86e-03
bond pdb=" C   LEU A  49 "
     pdb=" N   ASP A  50 "
  ideal  model  delta    sigma   weight residual
  1.330  1.329  0.001 1.31e-02 5.83e+03 5.81e-03
bond pdb=" CG  LEU A  76 "
     pdb=" CD2 LEU A  76 "
  ideal  model  delta    sigma   weight residual
  1.521  1.524 -0.003 3.30e-02 9.18e+02 5.81e-03
bond pdb=" CA  TYR A  34 "
     pdb=" C   TYR A  34 "
  ideal  model  delta    sigma   weight residual
  1.521  1.521  0.001 1.17e-02 7.31e+03 5.76e-03
bond pdb=" C   TYR A  56 "
     pdb=" O   TYR A  56 "
  ideal  model  delta    sigma   weight residual
  1.234  1.233  0.001 1.19e-02 7.06e+03 5.76e-03
bond pdb=" N   VAL A  63 "
     pdb=" CA  VAL A  63 "
  ideal  model  delta    sigma   weight residual
  1.459  1.460 -0.001 1.24e-02 6.50e+03 5.70e-03
bond pdb=" CA  LEU A  60 "
     pdb=" CB  LEU A  60 "
  ideal  model  delta    sigma   weight residual
  1.531  1.529  0.001 1.52e-02 4.33e+03 5.58e-03
bond pdb=" CE1 TYR A  56 "
     pdb=" CZ  TYR A  56 "
  ideal  model  delta    sigma   weight residual
  1.378  1.376  0.002 2.40e-02 1.74e+03 5.57e-03
bond pdb=" CG  ASN A  29 "
     pdb=" ND2 ASN A  29 "
  ideal  model  delta    sigma   weight residual
  1.328  1.330 -0.002 2.10e-02 2.27e+03 5.53e-03
bond pdb=" C   LEU A  37 "
     pdb=" N   GLY A  38 "
  ideal  model  delta    sigma   weight residual
  1.331  1.330  0.001 1.40e-02 5.10e+03 5.52e-03
bond pdb=" N   HIS A  64 "
     pdb=" CA  HIS A  64 "
  ideal  model  delta    sigma   weight residual
  1.454  1.455 -0.001 1.31e-02 5.83e+03 5.49e-03
bond pdb=" N   LYS A   7 "
     pdb=" CA  LYS A   7 "
  ideal  model  delta    sigma   weight residual
  1.451  1.452 -0.001 1.60e-02 3.91e+03 5.46e-03
bond pdb=" C   LEU A  49 "
     pdb=" O   LEU A  49 "
  ideal  model  delta    sigma   weight residual
  1.234  1.233  0.001 1.27e-02 6.20e+03 5.44e-03
bond pdb=" CA  LYS A   3 "
     pdb=" C   LYS A   3 "
  ideal  model  delta    sigma   weight residual
  1.523  1.524 -0.001 1.23e-02 6.61e+03 5.42e-03
bond pdb=" CD  ARG A  82 "
     pdb=" NE  ARG A  82 "
  ideal  model  delta    sigma   weight residual
  1.458  1.457  0.001 1.40e-02 5.10e+03 5.39e-03
bond pdb=" CA  ALA A  57 "
     pdb=" CB  ALA A  57 "
  ideal  model  delta    sigma   weight residual
  1.526  1.525  0.001 1.53e-02 4.27e+03 5.32e-03
bond pdb=" C   HIS A  64 "
     pdb=" N   LEU A  65 "
  ideal  model  delta    sigma   weight residual
  1.335  1.336 -0.001 1.34e-02 5.57e+03 5.30e-03
bond pdb=" N   GLU A   5 "
     pdb=" CA  GLU A   5 "
  ideal  model  delta    sigma   weight residual
  1.455  1.456 -0.001 1.25e-02 6.40e+03 5.29e-03
bond pdb=" CD  GLN A  31 "
     pdb=" OE1 GLN A  31 "
  ideal  model  delta    sigma   weight residual
  1.231  1.232 -0.001 1.90e-02 2.77e+03 5.18e-03
bond pdb=" C   ARG A  16 "
     pdb=" O   ARG A  16 "
  ideal  model  delta    sigma   weight residual
  1.236  1.236 -0.001 1.21e-02 6.83e+03 5.17e-03
bond pdb=" C   LYS A   3 "
     pdb=" N   VAL A   4 "
  ideal  model  delta    sigma   weight residual
  1.331  1.329  0.001 1.40e-02 5.10e+03 5.16e-03
bond pdb=" N   LEU A  49 "
     pdb=" CA  LEU A  49 "
  ideal  model  delta    sigma   weight residual
  1.455  1.454  0.001 1.27e-02 6.20e+03 5.16e-03
bond pdb=" CA  SER A  17 "
     pdb=" CB  SER A  17 "
  ideal  model  delta    sigma   weight residual
  1.533  1.532  0.001 1.60e-02 3.91e+03 5.11e-03
bond pdb=" C   TYR A  61 "
     pdb=" N   THR A  62 "
  ideal  model  delta    sigma   weight residual
  1.331  1.330  0.001 1.38e-02 5.25e+03 5.10e-03
bond pdb=" CG  LYS A  69 "
     pdb=" CD  LYS A  69 "
  ideal  model  delta    sigma   weight residual
  1.520  1.522 -0.002 3.00e-02 1.11e+03 5.08e-03
bond pdb=" CG1 ILE A  78 "
     pdb=" CD1 ILE A  78 "
  ideal  model  delta    sigma   weight residual
  1.513  1.510  0.003 3.90e-02 6.57e+02 5.05e-03
bond pdb=" CE2 PHE A  13 "
     pdb=" CZ  PHE A  13 "
  ideal  model  delta    sigma   weight residual
  1.382  1.380  0.002 3.00e-02 1.11e+03 5.04e-03
bond pdb=" CG  ASN A  39 "
     pdb=" OD1 ASN A  39 "
  ideal  model  delta    sigma   weight residual
  1.231  1.232 -0.001 1.90e-02 2.77e+03 5.01e-03
bond pdb=" CA  SER A  66 "
     pdb=" CB  SER A  66 "
  ideal  model  delta    sigma   weight residual
  1.530  1.528  0.001 1.69e-02 3.50e+03 5.00e-03
bond pdb=" CE1 PHE A  73 "
     pdb=" CZ  PHE A  73 "
  ideal  model  delta    sigma   weight residual
  1.382  1.380  0.002 3.00e-02 1.11e+03 4.85e-03
bond pdb=" CA  ASN A  29 "
     pdb=" CB  ASN A  29 "
  ideal  model  delta    sigma   weight residual
  1.530  1.529  0.001 1.43e-02 4.89e+03 4.84e-03
bond pdb=" C   SER A  66 "
     pdb=" O   SER A  66 "
  ideal  model  delta    sigma   weight residual
  1.236  1.237 -0.001 1.47e-02 4.63e+03 4.77e-03
bond pdb=" CG1 ILE A   6 "
     pdb=" CD1 ILE A   6 "
  ideal  model  delta    sigma   weight residual
  1.513  1.510  0.003 3.90e-02 6.57e+02 4.76e-03
bond pdb=" CA  PRO A  85 "
     pdb=" C   PRO A  85 "
  ideal  model  delta    sigma   weight residual
  1.525  1.526 -0.001 2.10e-02 2.27e+03 4.73e-03
bond pdb=" CA  MSE A  77 "
     pdb=" CB  MSE A  77 "
  ideal  model  delta    sigma   weight residual
  1.534  1.533  0.001 1.77e-02 3.19e+03 4.69e-03
bond pdb=" CA  THR A  48 "
     pdb=" CB  THR A  48 "
  ideal  model  delta    sigma   weight residual
  1.527  1.526  0.001 1.30e-02 5.92e+03 4.67e-03
bond pdb=" C   SER A   9 "
     pdb=" N   GLN A  10 "
  ideal  model  delta    sigma   weight residual
  1.334  1.333  0.001 1.30e-02 5.92e+03 4.66e-03
bond pdb=" C   MSE A  77 "
     pdb=" O   MSE A  77 "
  ideal  model  delta    sigma   weight residual
  1.234  1.233  0.001 1.29e-02 6.01e+03 4.65e-03
bond pdb=" CA  LYS A  69 "
     pdb=" CB  LYS A  69 "
  ideal  model  delta    sigma   weight residual
  1.533  1.534 -0.001 1.82e-02 3.02e+03 4.58e-03
bond pdb=" CD1 TYR A  61 "
     pdb=" CE1 TYR A  61 "
  ideal  model  delta    sigma   weight residual
  1.382  1.380  0.002 3.00e-02 1.11e+03 4.56e-03
bond pdb=" CD  GLN A  53 "
     pdb=" NE2 GLN A  53 "
  ideal  model  delta    sigma   weight residual
  1.328  1.329 -0.001 2.10e-02 2.27e+03 4.55e-03
bond pdb=" C   PHE A  73 "
     pdb=" N   GLY A  74 "
  ideal  model  delta    sigma   weight residual
  1.333  1.332  0.001 1.57e-02 4.06e+03 4.55e-03
bond pdb=" CA  MSE A  77 "
     pdb=" C   MSE A  77 "
  ideal  model  delta    sigma   weight residual
  1.522  1.521  0.001 1.27e-02 6.20e+03 4.53e-03
bond pdb=" C   LEU A  76 "
     pdb=" O   LEU A  76 "
  ideal  model  delta    sigma   weight residual
  1.234  1.235 -0.001 1.22e-02 6.72e+03 4.52e-03
bond pdb=" CG  GLN A  31 "
     pdb=" CD  GLN A  31 "
  ideal  model  delta    sigma   weight residual
  1.516  1.518 -0.002 2.50e-02 1.60e+03 4.50e-03
bond pdb=" C   SER A   9 "
     pdb=" O   SER A   9 "
  ideal  model  delta    sigma   weight residual
  1.236  1.237 -0.001 1.35e-02 5.49e+03 4.48e-03
bond pdb=" N   PRO A  54 "
     pdb=" CA  PRO A  54 "
  ideal  model  delta    sigma   weight residual
  1.466  1.466  0.001 1.21e-02 6.83e+03 4.46e-03
bond pdb=" CB  THR A  48 "
     pdb=" CG2 THR A  48 "
  ideal  model  delta    sigma   weight residual
  1.521  1.519  0.002 3.30e-02 9.18e+02 4.42e-03
bond pdb=" CA  ALA A  11 "
     pdb=" CB  ALA A  11 "
  ideal  model  delta    sigma   weight residual
  1.531  1.530  0.001 1.72e-02 3.38e+03 4.40e-03
bond pdb=" CA  ALA A  57 "
     pdb=" C   ALA A  57 "
  ideal  model  delta    sigma   weight residual
  1.527  1.528 -0.001 1.32e-02 5.74e+03 4.38e-03
bond pdb=" CG  ASN A  39 "
     pdb=" ND2 ASN A  39 "
  ideal  model  delta    sigma   weight residual
  1.328  1.329 -0.001 2.10e-02 2.27e+03 4.37e-03
bond pdb=" N   CYS A  33 "
     pdb=" CA  CYS A  33 "
  ideal  model  delta    sigma   weight residual
  1.456  1.457 -0.001 1.16e-02 7.43e+03 4.36e-03
bond pdb=" CD2 TYR A  61 "
     pdb=" CE2 TYR A  61 "
  ideal  model  delta    sigma   weight residual
  1.382  1.380  0.002 3.00e-02 1.11e+03 4.08e-03
bond pdb=" CG  HIS A  64 "
     pdb=" ND1 HIS A  64 "
  ideal  model  delta    sigma   weight residual
  1.378  1.379 -0.001 1.10e-02 8.26e+03 3.93e-03
bond pdb=" CG  TYR A  56 "
     pdb=" CD1 TYR A  56 "
  ideal  model  delta    sigma   weight residual
  1.389  1.390 -0.001 2.10e-02 2.27e+03 3.93e-03
bond pdb=" CG  LEU A  49 "
     pdb=" CD2 LEU A  49 "
  ideal  model  delta    sigma   weight residual
  1.521  1.519  0.002 3.30e-02 9.18e+02 3.92e-03
bond pdb=" C   ARG A  82 "
     pdb=" N   LEU A  83 "
  ideal  model  delta    sigma   weight residual
  1.329  1.328  0.001 1.44e-02 4.82e+03 3.92e-03
bond pdb=" CE  LYS A  46 "
     pdb=" NZ  LYS A  46 "
  ideal  model  delta    sigma   weight residual
  1.489  1.487  0.002 3.00e-02 1.11e+03 3.92e-03
bond pdb=" CB  THR A  14 "
     pdb=" OG1 THR A  14 "
  ideal  model  delta    sigma   weight residual
  1.433  1.432  0.001 1.60e-02 3.91e+03 3.88e-03
bond pdb=" C   CYS A  33 "
     pdb=" N   TYR A  34 "
  ideal  model  delta    sigma   weight residual
  1.331  1.332 -0.001 1.32e-02 5.74e+03 3.87e-03
bond pdb=" C   SER A  17 "
     pdb=" N   GLY A  18 "
  ideal  model  delta    sigma   weight residual
  1.327  1.328 -0.001 1.15e-02 7.56e+03 3.87e-03
bond pdb=" C   TYR A  41 "
     pdb=" O   TYR A  41 "
  ideal  model  delta    sigma   weight residual
  1.235  1.235  0.001 1.29e-02 6.01e+03 3.78e-03
bond pdb=" CG  PHE A  13 "
     pdb=" CD2 PHE A  13 "
  ideal  model  delta    sigma   weight residual
  1.384  1.383  0.001 2.10e-02 2.27e+03 3.78e-03
bond pdb=" CB  TYR A  34 "
     pdb=" CG  TYR A  34 "
  ideal  model  delta    sigma   weight residual
  1.512  1.511  0.001 2.20e-02 2.07e+03 3.78e-03
bond pdb=" CG  ASN A  29 "
     pdb=" OD1 ASN A  29 "
  ideal  model  delta    sigma   weight residual
  1.231  1.230  0.001 1.90e-02 2.77e+03 3.74e-03
bond pdb=" C   ASP A  50 "
     pdb=" O   ASP A  50 "
  ideal  model  delta    sigma   weight residual
  1.234  1.235 -0.001 1.36e-02 5.41e+03 3.70e-03
bond pdb=" N   PHE A  73 "
     pdb=" CA  PHE A  73 "
  ideal  model  delta    sigma   weight residual
  1.456  1.457 -0.001 1.22e-02 6.72e+03 3.67e-03
bond pdb=" CA  VAL A  35 "
     pdb=" CB  VAL A  35 "
  ideal  model  delta    sigma   weight residual
  1.539  1.540 -0.001 1.18e-02 7.18e+03 3.65e-03
bond pdb=" N   LYS A   3 "
     pdb=" CA  LYS A   3 "
  ideal  model  delta    sigma   weight residual
  1.456  1.457 -0.001 1.23e-02 6.61e+03 3.65e-03
bond pdb=" N   ARG A  82 "
     pdb=" CA  ARG A  82 "
  ideal  model  delta    sigma   weight residual
  1.458  1.457  0.001 1.22e-02 6.72e+03 3.64e-03
bond pdb=" C   GLY A  38 "
     pdb=" O   GLY A  38 "
  ideal  model  delta    sigma   weight residual
  1.236  1.236  0.001 1.30e-02 5.92e+03 3.62e-03
bond pdb=" ND1 HIS A  64 "
     pdb=" CE1 HIS A  64 "
  ideal  model  delta    sigma   weight residual
  1.321  1.320  0.001 1.00e-02 1.00e+04 3.59e-03
bond pdb=" C   ALA A  11 "
     pdb=" N   GLN A  12 "
  ideal  model  delta    sigma   weight residual
  1.328  1.329 -0.001 1.37e-02 5.33e+03 3.59e-03
bond pdb=" CB  THR A  48 "
     pdb=" OG1 THR A  48 "
  ideal  model  delta    sigma   weight residual
  1.433  1.432  0.001 1.60e-02 3.91e+03 3.56e-03
bond pdb=" CG  ASP A  79 "
     pdb=" OD2 ASP A  79 "
  ideal  model  delta    sigma   weight residual
  1.249  1.250 -0.001 1.90e-02 2.77e+03 3.54e-03
bond pdb=" CA  TYR A  34 "
     pdb=" CB  TYR A  34 "
  ideal  model  delta    sigma   weight residual
  1.530  1.530  0.001 1.50e-02 4.44e+03 3.46e-03
bond pdb=" CD2 TYR A  34 "
     pdb=" CE2 TYR A  34 "
  ideal  model  delta    sigma   weight residual
  1.382  1.380  0.002 3.00e-02 1.11e+03 3.41e-03
bond pdb=" CA  GLN A  31 "
     pdb=" CB  GLN A  31 "
  ideal  model  delta    sigma   weight residual
  1.536  1.537 -0.001 2.53e-02 1.56e+03 3.40e-03
bond pdb=" N   GLN A  10 "
     pdb=" CA  GLN A  10 "
  ideal  model  delta    sigma   weight residual
  1.457  1.456  0.001 1.16e-02 7.43e+03 3.39e-03
bond pdb=" CB  ASP A  79 "
     pdb=" CG  ASP A  79 "
  ideal  model  delta    sigma   weight residual
  1.516  1.517 -0.001 2.50e-02 1.60e+03 3.34e-03
bond pdb=" N   LEU A  60 "
     pdb=" CA  LEU A  60 "
  ideal  model  delta    sigma   weight residual
  1.456  1.457 -0.001 1.21e-02 6.83e+03 3.26e-03
bond pdb=" CD  GLU A  30 "
     pdb=" OE2 GLU A  30 "
  ideal  model  delta    sigma   weight residual
  1.249  1.250 -0.001 1.90e-02 2.77e+03 3.26e-03
bond pdb=" CB  VAL A   4 "
     pdb=" CG1 VAL A   4 "
  ideal  model  delta    sigma   weight residual
  1.521  1.519  0.002 3.30e-02 9.18e+02 3.25e-03
bond pdb=" CB  PHE A  73 "
     pdb=" CG  PHE A  73 "
  ideal  model  delta    sigma   weight residual
  1.502  1.501  0.001 2.30e-02 1.89e+03 3.22e-03
bond pdb=" C   ASP A  79 "
     pdb=" N   ARG A  80 "
  ideal  model  delta    sigma   weight residual
  1.331  1.330  0.001 1.29e-02 6.01e+03 3.18e-03
bond pdb=" CB  GLN A  10 "
     pdb=" CG  GLN A  10 "
  ideal  model  delta    sigma   weight residual
  1.520  1.518  0.002 3.00e-02 1.11e+03 3.16e-03
bond pdb=" C   ILE A   2 "
     pdb=" N   LYS A   3 "
  ideal  model  delta    sigma   weight residual
  1.330  1.330 -0.001 1.39e-02 5.18e+03 3.14e-03
bond pdb=" CA  ARG A  80 "
     pdb=" C   ARG A  80 "
  ideal  model  delta    sigma   weight residual
  1.521  1.520  0.001 1.26e-02 6.30e+03 3.10e-03
bond pdb=" C   CYS A  33 "
     pdb=" O   CYS A  33 "
  ideal  model  delta    sigma   weight residual
  1.233  1.234 -0.001 1.17e-02 7.31e+03 3.09e-03
bond pdb=" CA  ALA A  11 "
     pdb=" C   ALA A  11 "
  ideal  model  delta    sigma   weight residual
  1.523  1.522  0.001 1.41e-02 5.03e+03 3.09e-03
bond pdb=" CB  THR A  62 "
     pdb=" OG1 THR A  62 "
  ideal  model  delta    sigma   weight residual
  1.433  1.432  0.001 1.60e-02 3.91e+03 3.01e-03
bond pdb=" CB  THR A  14 "
     pdb=" CG2 THR A  14 "
  ideal  model  delta    sigma   weight residual
  1.521  1.523 -0.002 3.30e-02 9.18e+02 2.99e-03
bond pdb=" CA  GLY A  74 "
     pdb=" C   GLY A  74 "
  ideal  model  delta    sigma   weight residual
  1.513  1.514 -0.001 1.45e-02 4.76e+03 2.99e-03
bond pdb=" C   GLN A  12 "
     pdb=" O   GLN A  12 "
  ideal  model  delta    sigma   weight residual
  1.234  1.233  0.001 1.34e-02 5.57e+03 2.95e-03
bond pdb=" CA  PRO A  85 "
     pdb=" CB  PRO A  85 "
  ideal  model  delta    sigma   weight residual
  1.530  1.529  0.001 2.00e-02 2.50e+03 2.91e-03
bond pdb=" C   SER A  67 "
     pdb=" N   PHE A  68 "
  ideal  model  delta    sigma   weight residual
  1.329  1.329  0.001 1.38e-02 5.25e+03 2.89e-03
bond pdb=" CB  VAL A  35 "
     pdb=" CG1 VAL A  35 "
  ideal  model  delta    sigma   weight residual
  1.521  1.523 -0.002 3.30e-02 9.18e+02 2.86e-03
bond pdb=" N   GLY A  52 "
     pdb=" CA  GLY A  52 "
  ideal  model  delta    sigma   weight residual
  1.444  1.445 -0.001 1.81e-02 3.05e+03 2.86e-03
bond pdb=" CA  TYR A  56 "
     pdb=" CB  TYR A  56 "
  ideal  model  delta    sigma   weight residual
  1.529  1.528  0.001 1.69e-02 3.50e+03 2.84e-03
bond pdb=" N   VAL A   4 "
     pdb=" CA  VAL A   4 "
  ideal  model  delta    sigma   weight residual
  1.458  1.457  0.001 1.14e-02 7.69e+03 2.79e-03
bond pdb=" CD  GLU A  40 "
     pdb=" OE2 GLU A  40 "
  ideal  model  delta    sigma   weight residual
  1.249  1.250 -0.001 1.90e-02 2.77e+03 2.79e-03
bond pdb=" N   PHE A  68 "
     pdb=" CA  PHE A  68 "
  ideal  model  delta    sigma   weight residual
  1.454  1.453  0.001 1.19e-02 7.06e+03 2.69e-03
bond pdb=" CA  LEU A  49 "
     pdb=" CB  LEU A  49 "
  ideal  model  delta    sigma   weight residual
  1.529  1.528  0.001 1.66e-02 3.63e+03 2.66e-03
bond pdb=" CD  GLN A  72 "
     pdb=" OE1 GLN A  72 "
  ideal  model  delta    sigma   weight residual
  1.231  1.232 -0.001 1.90e-02 2.77e+03 2.64e-03
bond pdb=" CG  GLU A   5 "
     pdb=" CD  GLU A   5 "
  ideal  model  delta    sigma   weight residual
  1.516  1.517 -0.001 2.50e-02 1.60e+03 2.63e-03
bond pdb=" N   SER A   9 "
     pdb=" CA  SER A   9 "
  ideal  model  delta    sigma   weight residual
  1.457  1.457 -0.001 1.32e-02 5.74e+03 2.62e-03
bond pdb=" CG  LYS A   7 "
     pdb=" CD  LYS A   7 "
  ideal  model  delta    sigma   weight residual
  1.520  1.518  0.002 3.00e-02 1.11e+03 2.60e-03
bond pdb=" CA  VAL A   4 "
     pdb=" C   VAL A   4 "
  ideal  model  delta    sigma   weight residual
  1.522  1.522 -0.001 1.18e-02 7.18e+03 2.58e-03
bond pdb=" CB  GLN A  72 "
     pdb=" CG  GLN A  72 "
  ideal  model  delta    sigma   weight residual
  1.520  1.522 -0.002 3.00e-02 1.11e+03 2.57e-03
bond pdb=" CA  SER A  75 "
     pdb=" C   SER A  75 "
  ideal  model  delta    sigma   weight residual
  1.526  1.526 -0.001 1.42e-02 4.96e+03 2.54e-03
bond pdb=" CB  GLN A  12 "
     pdb=" CG  GLN A  12 "
  ideal  model  delta    sigma   weight residual
  1.520  1.519  0.001 3.00e-02 1.11e+03 2.45e-03
bond pdb=" CA  GLY A  52 "
     pdb=" C   GLY A  52 "
  ideal  model  delta    sigma   weight residual
  1.516  1.517 -0.001 1.29e-02 6.01e+03 2.36e-03
bond pdb=" CZ  TYR A  61 "
     pdb=" OH  TYR A  61 "
  ideal  model  delta    sigma   weight residual
  1.376  1.375  0.001 2.10e-02 2.27e+03 2.35e-03
bond pdb=" CB  VAL A  84 "
     pdb=" CG1 VAL A  84 "
  ideal  model  delta    sigma   weight residual
  1.521  1.519  0.002 3.30e-02 9.18e+02 2.35e-03
bond pdb=" CA  HIS A  64 "
     pdb=" CB  HIS A  64 "
  ideal  model  delta    sigma   weight residual
  1.529  1.530 -0.001 1.58e-02 4.01e+03 2.32e-03
bond pdb=" C   SER A  66 "
     pdb=" N   SER A  67 "
  ideal  model  delta    sigma   weight residual
  1.335  1.334  0.001 1.38e-02 5.25e+03 2.32e-03
bond pdb=" N   ILE A  47 "
     pdb=" CA  ILE A  47 "
  ideal  model  delta    sigma   weight residual
  1.458  1.457  0.001 1.14e-02 7.69e+03 2.30e-03
bond pdb=" C   LEU A  37 "
     pdb=" O   LEU A  37 "
  ideal  model  delta    sigma   weight residual
  1.236  1.236 -0.001 1.28e-02 6.10e+03 2.28e-03
bond pdb=" C   SER A  75 "
     pdb=" O   SER A  75 "
  ideal  model  delta    sigma   weight residual
  1.233  1.233  0.001 1.28e-02 6.10e+03 2.23e-03
bond pdb=" C   HIS A  64 "
     pdb=" O   HIS A  64 "
  ideal  model  delta    sigma   weight residual
  1.234  1.234  0.001 1.27e-02 6.20e+03 2.23e-03
bond pdb=" CA  SER A  75 "
     pdb=" CB  SER A  75 "
  ideal  model  delta    sigma   weight residual
  1.529  1.529  0.001 1.64e-02 3.72e+03 2.22e-03
bond pdb=" CD  GLN A  22 "
     pdb=" NE2 GLN A  22 "
  ideal  model  delta    sigma   weight residual
  1.328  1.329 -0.001 2.10e-02 2.27e+03 2.17e-03
bond pdb=" CG  TYR A  61 "
     pdb=" CD2 TYR A  61 "
  ideal  model  delta    sigma   weight residual
  1.389  1.388  0.001 2.10e-02 2.27e+03 2.17e-03
bond pdb=" CA  ARG A  80 "
     pdb=" CB  ARG A  80 "
  ideal  model  delta    sigma   weight residual
  1.533  1.534 -0.001 1.72e-02 3.38e+03 2.15e-03
bond pdb=" CG  PRO A  85 "
     pdb=" CD  PRO A  85 "
  ideal  model  delta    sigma   weight residual
  1.503  1.501  0.002 3.40e-02 8.65e+02 2.15e-03
bond pdb=" CD  GLU A  51 "
     pdb=" OE2 GLU A  51 "
  ideal  model  delta    sigma   weight residual
  1.249  1.250 -0.001 1.90e-02 2.77e+03 2.15e-03
bond pdb=" CA  PHE A  68 "
     pdb=" CB  PHE A  68 "
  ideal  model  delta    sigma   weight residual
  1.532  1.531  0.001 1.74e-02 3.30e+03 2.14e-03
bond pdb=" N   ALA A  11 "
     pdb=" CA  ALA A  11 "
  ideal  model  delta    sigma   weight residual
  1.457  1.457 -0.001 1.32e-02 5.74e+03 2.14e-03
bond pdb=" CG  TYR A  34 "
     pdb=" CD1 TYR A  34 "
  ideal  model  delta    sigma   weight residual
  1.389  1.390 -0.001 2.10e-02 2.27e+03 2.13e-03
bond pdb=" C   THR A  14 "
     pdb=" O   THR A  14 "
  ideal  model  delta    sigma   weight residual
  1.234  1.234  0.001 1.22e-02 6.72e+03 2.10e-03
bond pdb=" CD2 PHE A  73 "
     pdb=" CE2 PHE A  73 "
  ideal  model  delta    sigma   weight residual
  1.382  1.383 -0.001 3.00e-02 1.11e+03 2.10e-03
bond pdb=" N   GLU A  40 "
     pdb=" CA  GLU A  40 "
  ideal  model  delta    sigma   weight residual
  1.459  1.460 -0.001 1.21e-02 6.83e+03 2.09e-03
bond pdb=" CA  GLU A  40 "
     pdb=" CB  GLU A  40 "
  ideal  model  delta    sigma   weight residual
  1.528  1.529 -0.001 1.56e-02 4.11e+03 2.09e-03
bond pdb=" CA  TYR A  41 "
     pdb=" C   TYR A  41 "
  ideal  model  delta    sigma   weight residual
  1.520  1.520  0.000 9.90e-03 1.02e+04 2.05e-03
bond pdb=" C   LYS A   3 "
     pdb=" O   LYS A   3 "
  ideal  model  delta    sigma   weight residual
  1.236  1.235  0.001 1.21e-02 6.83e+03 2.05e-03
bond pdb=" N   PRO A  58 "
     pdb=" CD  PRO A  58 "
  ideal  model  delta    sigma   weight residual
  1.473  1.474 -0.001 1.40e-02 5.10e+03 2.02e-03
bond pdb=" CA  ILE A   6 "
     pdb=" C   ILE A   6 "
  ideal  model  delta    sigma   weight residual
  1.524  1.523  0.001 1.26e-02 6.30e+03 1.99e-03
bond pdb=" CA  LEU A  37 "
     pdb=" C   LEU A  37 "
  ideal  model  delta    sigma   weight residual
  1.524  1.525 -0.001 1.48e-02 4.57e+03 1.98e-03
bond pdb=" CZ  ARG A  82 "
     pdb=" NH1 ARG A  82 "
  ideal  model  delta    sigma   weight residual
  1.323  1.322  0.001 1.40e-02 5.10e+03 1.97e-03
bond pdb=" CD1 TYR A  34 "
     pdb=" CE1 TYR A  34 "
  ideal  model  delta    sigma   weight residual
  1.382  1.381  0.001 3.00e-02 1.11e+03 1.97e-03
bond pdb=" CG  LEU A  32 "
     pdb=" CD2 LEU A  32 "
  ideal  model  delta    sigma   weight residual
  1.521  1.522 -0.001 3.30e-02 9.18e+02 1.91e-03
bond pdb=" CG  LEU A  83 "
     pdb=" CD2 LEU A  83 "
  ideal  model  delta    sigma   weight residual
  1.521  1.522 -0.001 3.30e-02 9.18e+02 1.88e-03
bond pdb=" CD  GLU A  30 "
     pdb=" OE1 GLU A  30 "
  ideal  model  delta    sigma   weight residual
  1.249  1.250 -0.001 1.90e-02 2.77e+03 1.85e-03
bond pdb=" CG  LEU A  49 "
     pdb=" CD1 LEU A  49 "
  ideal  model  delta    sigma   weight residual
  1.521  1.520  0.001 3.30e-02 9.18e+02 1.85e-03
bond pdb=" CD  GLN A  72 "
     pdb=" NE2 GLN A  72 "
  ideal  model  delta    sigma   weight residual
  1.328  1.329 -0.001 2.10e-02 2.27e+03 1.84e-03
bond pdb=" N   LEU A  76 "
     pdb=" CA  LEU A  76 "
  ideal  model  delta    sigma   weight residual
  1.456  1.456 -0.001 1.22e-02 6.72e+03 1.83e-03
bond pdb=" CD  GLN A  31 "
     pdb=" NE2 GLN A  31 "
  ideal  model  delta    sigma   weight residual
  1.328  1.327  0.001 2.10e-02 2.27e+03 1.80e-03
bond pdb=" C   THR A  48 "
     pdb=" O   THR A  48 "
  ideal  model  delta    sigma   weight residual
  1.235  1.236 -0.001 1.19e-02 7.06e+03 1.79e-03
bond pdb=" C   SER A  17 "
     pdb=" O   SER A  17 "
  ideal  model  delta    sigma   weight residual
  1.234  1.235 -0.001 1.28e-02 6.10e+03 1.77e-03
bond pdb=" CA  GLU A  30 "
     pdb=" CB  GLU A  30 "
  ideal  model  delta    sigma   weight residual
  1.533  1.532  0.001 2.29e-02 1.91e+03 1.77e-03
bond pdb=" N   PRO A  54 "
     pdb=" CD  PRO A  54 "
  ideal  model  delta    sigma   weight residual
  1.473  1.472  0.001 1.40e-02 5.10e+03 1.76e-03
bond pdb=" N   ASP A  50 "
     pdb=" CA  ASP A  50 "
  ideal  model  delta    sigma   weight residual
  1.454  1.454 -0.001 1.34e-02 5.57e+03 1.73e-03
bond pdb=" CD2 HIS A  64 "
     pdb=" NE2 HIS A  64 "
  ideal  model  delta    sigma   weight residual
  1.374  1.374  0.000 1.10e-02 8.26e+03 1.71e-03
bond pdb=" C   GLY A  18 "
     pdb=" O   GLY A  18 "
  ideal  model  delta    sigma   weight residual
  1.236  1.236 -0.001 1.23e-02 6.61e+03 1.69e-03
bond pdb=" CB  TYR A  56 "
     pdb=" CG  TYR A  56 "
  ideal  model  delta    sigma   weight residual
  1.512  1.511  0.001 2.20e-02 2.07e+03 1.69e-03
bond pdb=" CG  PRO A  54 "
     pdb=" CD  PRO A  54 "
  ideal  model  delta    sigma   weight residual
  1.503  1.504 -0.001 3.40e-02 8.65e+02 1.67e-03
bond pdb=" CA  ILE A  47 "
     pdb=" CB  ILE A  47 "
  ideal  model  delta    sigma   weight residual
  1.544  1.544 -0.001 1.32e-02 5.74e+03 1.60e-03
bond pdb=" C   GLN A  22 "
     pdb=" O   GLN A  22 "
  ideal  model  delta    sigma   weight residual
  1.236  1.236  0.001 1.33e-02 5.65e+03 1.59e-03
bond pdb=" C   LEU A  81 "
     pdb=" O   LEU A  81 "
  ideal  model  delta    sigma   weight residual
  1.235  1.235  0.000 1.15e-02 7.56e+03 1.55e-03
bond pdb=" C   THR A  62 "
     pdb=" O   THR A  62 "
  ideal  model  delta    sigma   weight residual
  1.234  1.235 -0.001 1.28e-02 6.10e+03 1.53e-03
bond pdb=" C   GLN A  53 "
     pdb=" N   PRO A  54 "
  ideal  model  delta    sigma   weight residual
  1.330  1.330 -0.000 1.25e-02 6.40e+03 1.52e-03
bond pdb=" C   LEU A  60 "
     pdb=" N   TYR A  61 "
  ideal  model  delta    sigma   weight residual
  1.331  1.330  0.001 1.38e-02 5.25e+03 1.52e-03
bond pdb=" C   ARG A  80 "
     pdb=" O   ARG A  80 "
  ideal  model  delta    sigma   weight residual
  1.234  1.233  0.000 1.22e-02 6.72e+03 1.50e-03
bond pdb=" CG  ASP A  50 "
     pdb=" OD2 ASP A  50 "
  ideal  model  delta    sigma   weight residual
  1.249  1.248  0.001 1.90e-02 2.77e+03 1.49e-03
bond pdb=" N   ASN A  29 "
     pdb=" CA  ASN A  29 "
  ideal  model  delta    sigma   weight residual
  1.456  1.456  0.000 1.23e-02 6.61e+03 1.47e-03
bond pdb=" C   GLY A  59 "
     pdb=" O   GLY A  59 "
  ideal  model  delta    sigma   weight residual
  1.231  1.231 -0.001 1.38e-02 5.25e+03 1.45e-03
bond pdb=" C   MSE A  77 "
     pdb=" N   ILE A  78 "
  ideal  model  delta    sigma   weight residual
  1.330  1.330  0.000 1.25e-02 6.40e+03 1.43e-03
bond pdb=" C   GLU A  40 "
     pdb=" O   GLU A  40 "
  ideal  model  delta    sigma   weight residual
  1.237  1.237 -0.000 1.17e-02 7.31e+03 1.40e-03
bond pdb=" CG  TYR A  56 "
     pdb=" CD2 TYR A  56 "
  ideal  model  delta    sigma   weight residual
  1.389  1.388  0.001 2.10e-02 2.27e+03 1.39e-03
bond pdb=" C   VAL A   4 "
     pdb=" N   GLU A   5 "
  ideal  model  delta    sigma   weight residual
  1.331  1.330  0.001 1.55e-02 4.16e+03 1.37e-03
bond pdb=" CE1 TYR A  41 "
     pdb=" CZ  TYR A  41 "
  ideal  model  delta    sigma   weight residual
  1.378  1.377  0.001 2.40e-02 1.74e+03 1.35e-03
bond pdb=" CD  GLN A  10 "
     pdb=" OE1 GLN A  10 "
  ideal  model  delta    sigma   weight residual
  1.231  1.230  0.001 1.90e-02 2.77e+03 1.34e-03
bond pdb=" CD1 PHE A  68 "
     pdb=" CE1 PHE A  68 "
  ideal  model  delta    sigma   weight residual
  1.382  1.383 -0.001 3.00e-02 1.11e+03 1.34e-03
bond pdb=" C   ILE A   6 "
     pdb=" O   ILE A   6 "
  ideal  model  delta    sigma   weight residual
  1.236  1.235  0.000 1.12e-02 7.97e+03 1.30e-03
bond pdb=" CG  LEU A  83 "
     pdb=" CD1 LEU A  83 "
  ideal  model  delta    sigma   weight residual
  1.521  1.522 -0.001 3.30e-02 9.18e+02 1.29e-03
bond pdb=" CZ  ARG A  16 "
     pdb=" NH1 ARG A  16 "
  ideal  model  delta    sigma   weight residual
  1.323  1.323 -0.000 1.40e-02 5.10e+03 1.21e-03
bond pdb=" CG  LEU A  37 "
     pdb=" CD1 LEU A  37 "
  ideal  model  delta    sigma   weight residual
  1.521  1.520  0.001 3.30e-02 9.18e+02 1.21e-03
bond pdb=" C   GLN A  72 "
     pdb=" N   PHE A  73 "
  ideal  model  delta    sigma   weight residual
  1.332  1.333 -0.000 1.29e-02 6.01e+03 1.12e-03
bond pdb=" NE  ARG A  80 "
     pdb=" CZ  ARG A  80 "
  ideal  model  delta    sigma   weight residual
  1.326  1.326  0.000 1.10e-02 8.26e+03 1.11e-03
bond pdb=" CD  ARG A  16 "
     pdb=" NE  ARG A  16 "
  ideal  model  delta    sigma   weight residual
  1.458  1.458 -0.000 1.40e-02 5.10e+03 1.10e-03
bond pdb=" CD  ARG A  80 "
     pdb=" NE  ARG A  80 "
  ideal  model  delta    sigma   weight residual
  1.458  1.458 -0.000 1.40e-02 5.10e+03 1.09e-03
bond pdb=" CG  LEU A  60 "
     pdb=" CD1 LEU A  60 "
  ideal  model  delta    sigma   weight residual
  1.521  1.520  0.001 3.30e-02 9.18e+02 1.07e-03
bond pdb=" CA  ILE A  78 "
     pdb=" C   ILE A  78 "
  ideal  model  delta    sigma   weight residual
  1.523  1.523 -0.000 1.28e-02 6.10e+03 1.06e-03
bond pdb=" CA  LEU A  83 "
     pdb=" C   LEU A  83 "
  ideal  model  delta    sigma   weight residual
  1.524  1.523  0.000 1.25e-02 6.40e+03 1.05e-03
bond pdb=" CA  VAL A  63 "
     pdb=" CB  VAL A  63 "
  ideal  model  delta    sigma   weight residual
  1.538  1.538  0.000 1.24e-02 6.50e+03 1.03e-03
bond pdb=" C   LEU A  76 "
     pdb=" N   MSE A  77 "
  ideal  model  delta    sigma   weight residual
  1.331  1.331  0.000 1.33e-02 5.65e+03 1.02e-03
bond pdb=" CA  GLN A  10 "
     pdb=" C   GLN A  10 "
  ideal  model  delta    sigma   weight residual
  1.525  1.524  0.000 1.35e-02 5.49e+03 1.02e-03
bond pdb=" CG  PHE A  73 "
     pdb=" CD1 PHE A  73 "
  ideal  model  delta    sigma   weight residual
  1.384  1.383  0.001 2.10e-02 2.27e+03 1.02e-03
bond pdb=" CB  ARG A  16 "
     pdb=" CG  ARG A  16 "
  ideal  model  delta    sigma   weight residual
  1.520  1.521 -0.001 3.00e-02 1.11e+03 1.01e-03
bond pdb=" CA  LEU A  44 "
     pdb=" CB  LEU A  44 "
  ideal  model  delta    sigma   weight residual
  1.527  1.527  0.000 1.38e-02 5.25e+03 1.01e-03
bond pdb=" CB  SER A  67 "
     pdb=" OG  SER A  67 "
  ideal  model  delta    sigma   weight residual
  1.417  1.416  0.001 2.00e-02 2.50e+03 1.00e-03
bond pdb=" N   ASP A  36 "
     pdb=" CA  ASP A  36 "
  ideal  model  delta    sigma   weight residual
  1.459  1.460 -0.000 1.23e-02 6.61e+03 1.00e-03
bond pdb=" CA  GLU A  30 "
     pdb=" C   GLU A  30 "
  ideal  model  delta    sigma   weight residual
  1.522  1.521  0.000 1.22e-02 6.72e+03 9.90e-04
bond pdb=" C   GLY A  74 "
     pdb=" N   SER A  75 "
  ideal  model  delta    sigma   weight residual
  1.328  1.329 -0.000 1.44e-02 4.82e+03 9.29e-04
bond pdb=" CA  LEU A  49 "
     pdb=" C   LEU A  49 "
  ideal  model  delta    sigma   weight residual
  1.525  1.525 -0.000 1.32e-02 5.74e+03 8.97e-04
bond pdb=" CA  LEU A  76 "
     pdb=" CB  LEU A  76 "
  ideal  model  delta    sigma   weight residual
  1.528  1.528  0.000 1.66e-02 3.63e+03 8.75e-04
bond pdb=" CB  SER A  17 "
     pdb=" OG  SER A  17 "
  ideal  model  delta    sigma   weight residual
  1.417  1.416  0.001 2.00e-02 2.50e+03 8.66e-04
bond pdb=" CB  PRO A  54 "
     pdb=" CG  PRO A  54 "
  ideal  model  delta    sigma   weight residual
  1.492  1.491  0.001 5.00e-02 4.00e+02 8.65e-04
bond pdb=" CG  GLN A  10 "
     pdb=" CD  GLN A  10 "
  ideal  model  delta    sigma   weight residual
  1.516  1.515  0.001 2.50e-02 1.60e+03 8.63e-04
bond pdb=" CG  LEU A  81 "
     pdb=" CD1 LEU A  81 "
  ideal  model  delta    sigma   weight residual
  1.521  1.520  0.001 3.30e-02 9.18e+02 8.58e-04
bond pdb=" CB  ILE A  78 "
     pdb=" CG2 ILE A  78 "
  ideal  model  delta    sigma   weight residual
  1.521  1.520  0.001 3.30e-02 9.18e+02 8.55e-04
bond pdb=" CB  THR A  15 "
     pdb=" OG1 THR A  15 "
  ideal  model  delta    sigma   weight residual
  1.433  1.433  0.000 1.60e-02 3.91e+03 8.53e-04
bond pdb=" N   MSE A  77 "
     pdb=" CA  MSE A  77 "
  ideal  model  delta    sigma   weight residual
  1.455  1.455 -0.000 1.32e-02 5.74e+03 8.40e-04
bond pdb=" CB  TYR A  26 "
     pdb=" CG  TYR A  26 "
  ideal  model  delta    sigma   weight residual
  1.512  1.511  0.001 2.20e-02 2.07e+03 8.21e-04
bond pdb=" CA  PHE A  73 "
     pdb=" CB  PHE A  73 "
  ideal  model  delta    sigma   weight residual
  1.530  1.530  0.000 1.54e-02 4.22e+03 7.92e-04
bond pdb=" CZ  ARG A  80 "
     pdb=" NH2 ARG A  80 "
  ideal  model  delta    sigma   weight residual
  1.330  1.330  0.000 1.30e-02 5.92e+03 7.89e-04
bond pdb=" CD1 TYR A  56 "
     pdb=" CE1 TYR A  56 "
  ideal  model  delta    sigma   weight residual
  1.382  1.381  0.001 3.00e-02 1.11e+03 7.66e-04
bond pdb=" CA  SER A  66 "
     pdb=" C   SER A  66 "
  ideal  model  delta    sigma   weight residual
  1.522  1.521  0.000 1.72e-02 3.38e+03 7.59e-04
bond pdb=" NE  ARG A  16 "
     pdb=" CZ  ARG A  16 "
  ideal  model  delta    sigma   weight residual
  1.326  1.326 -0.000 1.10e-02 8.26e+03 7.48e-04
bond pdb=" CZ  ARG A  82 "
     pdb=" NH2 ARG A  82 "
  ideal  model  delta    sigma   weight residual
  1.330  1.330 -0.000 1.30e-02 5.92e+03 7.43e-04
bond pdb=" C   ALA A  57 "
     pdb=" O   ALA A  57 "
  ideal  model  delta    sigma   weight residual
  1.233  1.234 -0.000 1.26e-02 6.30e+03 7.41e-04
bond pdb=" CB  ARG A  21 "
     pdb=" CG  ARG A  21 "
  ideal  model  delta    sigma   weight residual
  1.520  1.521 -0.001 3.00e-02 1.11e+03 7.14e-04
bond pdb=" CA  CYS A  33 "
     pdb=" C   CYS A  33 "
  ideal  model  delta    sigma   weight residual
  1.522  1.522 -0.000 1.20e-02 6.94e+03 7.05e-04
bond pdb=" CA  LEU A  76 "
     pdb=" C   LEU A  76 "
  ideal  model  delta    sigma   weight residual
  1.524  1.523  0.000 1.30e-02 5.92e+03 7.04e-04
bond pdb=" CA  ALA A  55 "
     pdb=" C   ALA A  55 "
  ideal  model  delta    sigma   weight residual
  1.524  1.524 -0.000 1.30e-02 5.92e+03 7.04e-04
bond pdb=" CD1 PHE A  73 "
     pdb=" CE1 PHE A  73 "
  ideal  model  delta    sigma   weight residual
  1.382  1.383 -0.001 3.00e-02 1.11e+03 6.97e-04
bond pdb=" C   LEU A  83 "
     pdb=" O   LEU A  83 "
  ideal  model  delta    sigma   weight residual
  1.234  1.233  0.000 1.17e-02 7.31e+03 6.93e-04
bond pdb=" CG  LEU A  65 "
     pdb=" CD2 LEU A  65 "
  ideal  model  delta    sigma   weight residual
  1.521  1.520  0.001 3.30e-02 9.18e+02 6.90e-04
bond pdb=" CG  ASP A  36 "
     pdb=" OD1 ASP A  36 "
  ideal  model  delta    sigma   weight residual
  1.249  1.249 -0.000 1.90e-02 2.77e+03 6.87e-04
bond pdb=" C   GLY A  59 "
     pdb=" N   LEU A  60 "
  ideal  model  delta    sigma   weight residual
  1.330  1.329  0.000 1.32e-02 5.74e+03 6.84e-04
bond pdb=" CD2 TYR A  56 "
     pdb=" CE2 TYR A  56 "
  ideal  model  delta    sigma   weight residual
  1.382  1.381  0.001 3.00e-02 1.11e+03 6.68e-04
bond pdb=" CA  ILE A  78 "
     pdb=" CB  ILE A  78 "
  ideal  model  delta    sigma   weight residual
  1.537  1.536  0.000 1.21e-02 6.83e+03 6.64e-04
bond pdb=" CA  GLU A   5 "
     pdb=" C   GLU A   5 "
  ideal  model  delta    sigma   weight residual
  1.521  1.521 -0.000 1.24e-02 6.50e+03 6.11e-04
bond pdb=" CG  LEU A  76 "
     pdb=" CD1 LEU A  76 "
  ideal  model  delta    sigma   weight residual
  1.521  1.520  0.001 3.30e-02 9.18e+02 5.87e-04
bond pdb=" C   TYR A  61 "
     pdb=" O   TYR A  61 "
  ideal  model  delta    sigma   weight residual
  1.234  1.234 -0.000 1.28e-02 6.10e+03 5.76e-04
bond pdb=" C   PRO A   8 "
     pdb=" O   PRO A   8 "
  ideal  model  delta    sigma   weight residual
  1.238  1.238 -0.000 1.33e-02 5.65e+03 5.75e-04
bond pdb=" CA  ASP A  50 "
     pdb=" CB  ASP A  50 "
  ideal  model  delta    sigma   weight residual
  1.529  1.529  0.000 1.61e-02 3.86e+03 5.75e-04
bond pdb=" C   PRO A   8 "
     pdb=" N   SER A   9 "
  ideal  model  delta    sigma   weight residual
  1.332  1.332 -0.000 1.52e-02 4.33e+03 5.71e-04
bond pdb=" CA  GLN A  12 "
     pdb=" CB  GLN A  12 "
  ideal  model  delta    sigma   weight residual
  1.533  1.533  0.000 1.51e-02 4.39e+03 5.62e-04
bond pdb=" C   VAL A  63 "
     pdb=" O   VAL A  63 "
  ideal  model  delta    sigma   weight residual
  1.237  1.237 -0.000 1.20e-02 6.94e+03 5.28e-04
bond pdb=" CZ  ARG A  80 "
     pdb=" NH1 ARG A  80 "
  ideal  model  delta    sigma   weight residual
  1.323  1.323 -0.000 1.40e-02 5.10e+03 4.96e-04
bond pdb=" CA  PRO A  58 "
     pdb=" CB  PRO A  58 "
  ideal  model  delta    sigma   weight residual
  1.532  1.532 -0.000 1.34e-02 5.57e+03 4.94e-04
bond pdb=" CE1 HIS A  64 "
     pdb=" NE2 HIS A  64 "
  ideal  model  delta    sigma   weight residual
  1.321  1.321 -0.000 1.00e-02 1.00e+04 4.90e-04
bond pdb=" C   ASP A  36 "
     pdb=" N   LEU A  37 "
  ideal  model  delta    sigma   weight residual
  1.333  1.333 -0.000 1.27e-02 6.20e+03 4.90e-04
bond pdb=" C   ALA A  55 "
     pdb=" O   ALA A  55 "
  ideal  model  delta    sigma   weight residual
  1.234  1.234 -0.000 1.22e-02 6.72e+03 4.85e-04
bond pdb=" C   GLU A  51 "
     pdb=" N   GLY A  52 "
  ideal  model  delta    sigma   weight residual
  1.333  1.332  0.000 1.36e-02 5.41e+03 4.72e-04
bond pdb=" C   GLN A  10 "
     pdb=" O   GLN A  10 "
  ideal  model  delta    sigma   weight residual
  1.235  1.235  0.000 1.32e-02 5.74e+03 4.65e-04
bond pdb=" CB  LEU A  37 "
     pdb=" CG  LEU A  37 "
  ideal  model  delta    sigma   weight residual
  1.530  1.530  0.000 2.00e-02 2.50e+03 4.57e-04
bond pdb=" C   GLN A  12 "
     pdb=" N   PHE A  13 "
  ideal  model  delta    sigma   weight residual
  1.330  1.330  0.000 1.45e-02 4.76e+03 4.48e-04
bond pdb=" CA  GLN A  22 "
     pdb=" CB  GLN A  22 "
  ideal  model  delta    sigma   weight residual
  1.530  1.530 -0.000 1.51e-02 4.39e+03 4.47e-04
bond pdb=" N   ARG A  80 "
     pdb=" CA  ARG A  80 "
  ideal  model  delta    sigma   weight residual
  1.455  1.455  0.000 1.21e-02 6.83e+03 4.32e-04
bond pdb=" CB  VAL A  35 "
     pdb=" CG2 VAL A  35 "
  ideal  model  delta    sigma   weight residual
  1.521  1.522 -0.001 3.30e-02 9.18e+02 4.31e-04
bond pdb=" C   LYS A  69 "
     pdb=" O   LYS A  69 "
  ideal  model  delta    sigma   weight residual
  1.234  1.233  0.000 1.25e-02 6.40e+03 4.24e-04
bond pdb=" C   PRO A  58 "
     pdb=" O   PRO A  58 "
  ideal  model  delta    sigma   weight residual
  1.233  1.233  0.000 1.16e-02 7.43e+03 4.21e-04
bond pdb=" CG  PHE A  73 "
     pdb=" CD2 PHE A  73 "
  ideal  model  delta    sigma   weight residual
  1.384  1.384 -0.000 2.10e-02 2.27e+03 4.19e-04
bond pdb=" CB  VAL A  70 "
     pdb=" CG1 VAL A  70 "
  ideal  model  delta    sigma   weight residual
  1.521  1.520  0.001 3.30e-02 9.18e+02 4.18e-04
bond pdb=" CA  PRO A  54 "
     pdb=" CB  PRO A  54 "
  ideal  model  delta    sigma   weight residual
  1.531  1.531 -0.000 1.49e-02 4.50e+03 3.98e-04
bond pdb=" CA  GLY A  38 "
     pdb=" C   GLY A  38 "
  ideal  model  delta    sigma   weight residual
  1.511  1.511 -0.000 1.34e-02 5.57e+03 3.85e-04
bond pdb=" CG  PHE A  68 "
     pdb=" CD1 PHE A  68 "
  ideal  model  delta    sigma   weight residual
  1.384  1.384  0.000 2.10e-02 2.27e+03 3.80e-04
bond pdb=" CE2 TYR A  61 "
     pdb=" CZ  TYR A  61 "
  ideal  model  delta    sigma   weight residual
  1.378  1.378  0.000 2.40e-02 1.74e+03 3.71e-04
bond pdb=" CG  GLU A  30 "
     pdb=" CD  GLU A  30 "
  ideal  model  delta    sigma   weight residual
  1.516  1.516 -0.000 2.50e-02 1.60e+03 3.60e-04
bond pdb=" C   LEU A  60 "
     pdb=" O   LEU A  60 "
  ideal  model  delta    sigma   weight residual
  1.236  1.236 -0.000 1.21e-02 6.83e+03 3.44e-04
bond pdb=" N   GLN A  53 "
     pdb=" CA  GLN A  53 "
  ideal  model  delta    sigma   weight residual
  1.458  1.459 -0.000 1.60e-02 3.91e+03 3.36e-04
bond pdb=" CA  GLU A   5 "
     pdb=" CB  GLU A   5 "
  ideal  model  delta    sigma   weight residual
  1.534  1.535 -0.000 2.47e-02 1.64e+03 3.10e-04
bond pdb=" CA  SER A   9 "
     pdb=" C   SER A   9 "
  ideal  model  delta    sigma   weight residual
  1.523  1.522  0.000 1.41e-02 5.03e+03 3.05e-04
bond pdb=" C   PRO A  42 "
     pdb=" O   PRO A  42 "
  ideal  model  delta    sigma   weight residual
  1.233  1.233 -0.000 1.21e-02 6.83e+03 3.04e-04
bond pdb=" N   PRO A  42 "
     pdb=" CA  PRO A  42 "
  ideal  model  delta    sigma   weight residual
  1.466  1.465  0.000 1.21e-02 6.83e+03 2.92e-04
bond pdb=" C   PRO A  54 "
     pdb=" O   PRO A  54 "
  ideal  model  delta    sigma   weight residual
  1.232  1.232  0.000 1.27e-02 6.20e+03 2.92e-04
bond pdb=" CG  HIS A  64 "
     pdb=" CD2 HIS A  64 "
  ideal  model  delta    sigma   weight residual
  1.354  1.354  0.000 1.10e-02 8.26e+03 2.85e-04
bond pdb=" N   VAL A  35 "
     pdb=" CA  VAL A  35 "
  ideal  model  delta    sigma   weight residual
  1.459  1.459  0.000 1.20e-02 6.94e+03 2.82e-04
bond pdb=" C   GLN A  10 "
     pdb=" N   ALA A  11 "
  ideal  model  delta    sigma   weight residual
  1.332  1.332  0.000 1.52e-02 4.33e+03 2.77e-04
bond pdb=" C   GLN A  72 "
     pdb=" O   GLN A  72 "
  ideal  model  delta    sigma   weight residual
  1.236  1.235  0.000 1.29e-02 6.01e+03 2.72e-04
bond pdb=" CA  LEU A  65 "
     pdb=" CB  LEU A  65 "
  ideal  model  delta    sigma   weight residual
  1.529  1.528  0.000 1.64e-02 3.72e+03 2.69e-04
bond pdb=" CG  ASP A  36 "
     pdb=" OD2 ASP A  36 "
  ideal  model  delta    sigma   weight residual
  1.249  1.249 -0.000 1.90e-02 2.77e+03 2.65e-04
bond pdb=" C   LEU A  65 "
     pdb=" O   LEU A  65 "
  ideal  model  delta    sigma   weight residual
  1.236  1.237 -0.000 1.25e-02 6.40e+03 2.39e-04
bond pdb=" CB  VAL A  43 "
     pdb=" CG2 VAL A  43 "
  ideal  model  delta    sigma   weight residual
  1.521  1.520  0.001 3.30e-02 9.18e+02 2.35e-04
bond pdb=" CG  TYR A  41 "
     pdb=" CD1 TYR A  41 "
  ideal  model  delta    sigma   weight residual
  1.389  1.389 -0.000 2.10e-02 2.27e+03 2.27e-04
bond pdb=" CD  GLU A  51 "
     pdb=" OE1 GLU A  51 "
  ideal  model  delta    sigma   weight residual
  1.249  1.249 -0.000 1.90e-02 2.77e+03 2.12e-04
bond pdb=" C   GLY A  52 "
     pdb=" O   GLY A  52 "
  ideal  model  delta    sigma   weight residual
  1.235  1.236 -0.000 1.45e-02 4.76e+03 2.08e-04
bond pdb=" CZ  TYR A  34 "
     pdb=" OH  TYR A  34 "
  ideal  model  delta    sigma   weight residual
  1.376  1.376  0.000 2.10e-02 2.27e+03 2.07e-04
bond pdb=" CE1 PHE A  68 "
     pdb=" CZ  PHE A  68 "
  ideal  model  delta    sigma   weight residual
  1.382  1.382  0.000 3.00e-02 1.11e+03 1.94e-04
bond pdb=" N   GLY A  74 "
     pdb=" CA  GLY A  74 "
  ideal  model  delta    sigma   weight residual
  1.446  1.446 -0.000 1.53e-02 4.27e+03 1.91e-04
bond pdb=" CB  LEU A  83 "
     pdb=" CG  LEU A  83 "
  ideal  model  delta    sigma   weight residual
  1.530  1.530  0.000 2.00e-02 2.50e+03 1.88e-04
bond pdb=" CG  GLU A  51 "
     pdb=" CD  GLU A  51 "
  ideal  model  delta    sigma   weight residual
  1.516  1.516 -0.000 2.50e-02 1.60e+03 1.87e-04
bond pdb=" CB  THR A  15 "
     pdb=" CG2 THR A  15 "
  ideal  model  delta    sigma   weight residual
  1.521  1.521 -0.000 3.30e-02 9.18e+02 1.84e-04
bond pdb=" C   GLU A  51 "
     pdb=" O   GLU A  51 "
  ideal  model  delta    sigma   weight residual
  1.234  1.234  0.000 1.22e-02 6.72e+03 1.84e-04
bond pdb=" C   LEU A  65 "
     pdb=" N   SER A  66 "
  ideal  model  delta    sigma   weight residual
  1.333  1.334 -0.000 1.56e-02 4.11e+03 1.82e-04
bond pdb=" CA  PRO A  58 "
     pdb=" C   PRO A  58 "
  ideal  model  delta    sigma   weight residual
  1.521  1.521 -0.000 1.27e-02 6.20e+03 1.82e-04
bond pdb=" C   THR A  62 "
     pdb=" N   VAL A  63 "
  ideal  model  delta    sigma   weight residual
  1.329  1.329  0.000 1.69e-02 3.50e+03 1.67e-04
bond pdb=" CA  VAL A  35 "
     pdb=" C   VAL A  35 "
  ideal  model  delta    sigma   weight residual
  1.522  1.522 -0.000 1.19e-02 7.06e+03 1.64e-04
bond pdb=" CE1 TYR A  61 "
     pdb=" CZ  TYR A  61 "
  ideal  model  delta    sigma   weight residual
  1.378  1.378  0.000 2.40e-02 1.74e+03 1.49e-04
bond pdb=" C   GLU A   5 "
     pdb=" N   ILE A   6 "
  ideal  model  delta    sigma   weight residual
  1.329  1.329 -0.000 1.31e-02 5.83e+03 1.46e-04
bond pdb=" CA  ARG A  16 "
     pdb=" C   ARG A  16 "
  ideal  model  delta    sigma   weight residual
  1.523  1.523 -0.000 1.23e-02 6.61e+03 1.44e-04
bond pdb=" CB  ASN A  29 "
     pdb=" CG  ASN A  29 "
  ideal  model  delta    sigma   weight residual
  1.516  1.516  0.000 2.50e-02 1.60e+03 1.37e-04
bond pdb=" CA  VAL A  63 "
     pdb=" C   VAL A  63 "
  ideal  model  delta    sigma   weight residual
  1.523  1.523 -0.000 1.23e-02 6.61e+03 1.34e-04
bond pdb=" CA  PRO A   8 "
     pdb=" CB  PRO A   8 "
  ideal  model  delta    sigma   weight residual
  1.534  1.533  0.000 1.43e-02 4.89e+03 1.32e-04
bond pdb=" C   THR A  15 "
     pdb=" O   THR A  15 "
  ideal  model  delta    sigma   weight residual
  1.236  1.236 -0.000 1.19e-02 7.06e+03 1.16e-04
bond pdb=" CA  LEU A  81 "
     pdb=" CB  LEU A  81 "
  ideal  model  delta    sigma   weight residual
  1.526  1.526 -0.000 1.25e-02 6.40e+03 1.10e-04
bond pdb=" CB  PRO A   8 "
     pdb=" CG  PRO A   8 "
  ideal  model  delta    sigma   weight residual
  1.492  1.492  0.000 5.00e-02 4.00e+02 9.50e-05
bond pdb=" CA  GLN A  10 "
     pdb=" CB  GLN A  10 "
  ideal  model  delta    sigma   weight residual
  1.529  1.529 -0.000 1.40e-02 5.10e+03 8.93e-05
bond pdb=" CB  HIS A  64 "
     pdb=" CG  HIS A  64 "
  ideal  model  delta    sigma   weight residual
  1.497  1.497 -0.000 1.40e-02 5.10e+03 8.61e-05
bond pdb=" C   VAL A  70 "
     pdb=" O   VAL A  70 "
  ideal  model  delta    sigma   weight residual
  1.236  1.236 -0.000 1.09e-02 8.42e+03 8.21e-05
bond pdb=" CA  GLY A  18 "
     pdb=" C   GLY A  18 "
  ideal  model  delta    sigma   weight residual
  1.512  1.512  0.000 1.24e-02 6.50e+03 8.12e-05
bond pdb=" CA  PHE A  68 "
     pdb=" C   PHE A  68 "
  ideal  model  delta    sigma   weight residual
  1.523  1.523  0.000 1.18e-02 7.18e+03 6.47e-05
bond pdb=" CB  LEU A  49 "
     pdb=" CG  LEU A  49 "
  ideal  model  delta    sigma   weight residual
  1.530  1.530 -0.000 2.00e-02 2.50e+03 5.77e-05
bond pdb=" CA  CYS A  33 "
     pdb=" CB  CYS A  33 "
  ideal  model  delta    sigma   weight residual
  1.532  1.532 -0.000 1.68e-02 3.54e+03 5.47e-05
bond pdb=" C   GLN A  53 "
     pdb=" O   GLN A  53 "
  ideal  model  delta    sigma   weight residual
  1.235  1.235 -0.000 1.28e-02 6.10e+03 5.20e-05
bond pdb=" N   GLN A  72 "
     pdb=" CA  GLN A  72 "
  ideal  model  delta    sigma   weight residual
  1.457  1.457  0.000 1.35e-02 5.49e+03 4.90e-05
bond pdb=" CB  SER A  66 "
     pdb=" OG  SER A  66 "
  ideal  model  delta    sigma   weight residual
  1.417  1.417  0.000 2.00e-02 2.50e+03 4.50e-05
bond pdb=" C   LEU A  32 "
     pdb=" O   LEU A  32 "
  ideal  model  delta    sigma   weight residual
  1.234  1.233  0.000 1.25e-02 6.40e+03 4.26e-05
bond pdb=" N   GLY A  38 "
     pdb=" CA  GLY A  38 "
  ideal  model  delta    sigma   weight residual
  1.448  1.448 -0.000 1.51e-02 4.39e+03 3.96e-05
bond pdb=" CD  GLN A  22 "
     pdb=" OE1 GLN A  22 "
  ideal  model  delta    sigma   weight residual
  1.231  1.231 -0.000 1.90e-02 2.77e+03 3.21e-05
bond pdb=" C   ASN A  39 "
     pdb=" N   GLU A  40 "
  ideal  model  delta    sigma   weight residual
  1.335  1.335 -0.000 1.31e-02 5.83e+03 2.74e-05
bond pdb=" C   PHE A  73 "
     pdb=" O   PHE A  73 "
  ideal  model  delta    sigma   weight residual
  1.236  1.236  0.000 1.38e-02 5.25e+03 2.58e-05
bond pdb=" CA  ASP A  36 "
     pdb=" CB  ASP A  36 "
  ideal  model  delta    sigma   weight residual
  1.527  1.527  0.000 1.27e-02 6.20e+03 1.82e-05
bond pdb=" C   PHE A  68 "
     pdb=" O   PHE A  68 "
  ideal  model  delta    sigma   weight residual
  1.234  1.234 -0.000 1.22e-02 6.72e+03 9.06e-06
bond pdb=" CE1 TYR A  34 "
     pdb=" CZ  TYR A  34 "
  ideal  model  delta    sigma   weight residual
  1.378  1.378  0.000 2.40e-02 1.74e+03 8.25e-06
bond pdb=" C   VAL A  84 "
     pdb=" O   VAL A  84 "
  ideal  model  delta    sigma   weight residual
  1.240  1.240 -0.000 1.26e-02 6.30e+03 5.75e-06
bond pdb=" C   GLY A  71 "
     pdb=" O   GLY A  71 "
  ideal  model  delta    sigma   weight residual
  1.232  1.232  0.000 1.07e-02 8.73e+03 5.11e-06
bond pdb=" CB  ILE A   6 "
     pdb=" CG2 ILE A   6 "
  ideal  model  delta    sigma   weight residual
  1.521  1.521 -0.000 3.30e-02 9.18e+02 4.33e-06
bond pdb=" CB  ILE A  47 "
     pdb=" CG2 ILE A  47 "
  ideal  model  delta    sigma   weight residual
  1.521  1.521  0.000 3.30e-02 9.18e+02 2.38e-06
bond pdb=" CA  GLN A  53 "
     pdb=" CB  GLN A  53 "
  ideal  model  delta    sigma   weight residual
  1.526  1.526 -0.000 1.98e-02 2.55e+03 1.74e-06
bond pdb=" CB  SER A   9 "
     pdb=" OG  SER A   9 "
  ideal  model  delta    sigma   weight residual
  1.417  1.417 -0.000 2.00e-02 2.50e+03 1.32e-06
bond pdb=" CB  ASN A  39 "
     pdb=" CG  ASN A  39 "
  ideal  model  delta    sigma   weight residual
  1.516  1.516  0.000 2.50e-02 1.60e+03 1.17e-06
bond pdb=" N   LEU A  83 "
     pdb=" CA  LEU A  83 "
  ideal  model  delta    sigma   weight residual
  1.454  1.454  0.000 1.17e-02 7.31e+03 1.03e-06
bond pdb=" CA  THR A  62 "
     pdb=" CB  THR A  62 "
  ideal  model  delta    sigma   weight residual
  1.535  1.535  0.000 1.71e-02 3.42e+03 9.10e-07
bond pdb=" CD  GLN A  10 "
     pdb=" NE2 GLN A  10 "
  ideal  model  delta    sigma   weight residual
  1.328  1.328  0.000 2.10e-02 2.27e+03 8.04e-07
bond pdb=" CG  TYR A  34 "
     pdb=" CD2 TYR A  34 "
  ideal  model  delta    sigma   weight residual
  1.389  1.389 -0.000 2.10e-02 2.27e+03 5.95e-07
bond pdb=" CG  LEU A  65 "
     pdb=" CD1 LEU A  65 "
  ideal  model  delta    sigma   weight residual
  1.521  1.521  0.000 3.30e-02 9.18e+02 1.59e-07
bond pdb=" CA  LEU A  37 "
     pdb=" CB  LEU A  37 "
  ideal  model  delta    sigma   weight residual
  1.529  1.529 -0.000 1.46e-02 4.69e+03 8.48e-08
bond pdb=" CA  ASP A  79 "
     pdb=" C   ASP A  79 "
  ideal  model  delta    sigma   weight residual
  1.523  1.523 -0.000 1.34e-02 5.57e+03 3.61e-08

Bond angle | covalent geometry | restraints: 909
Sorted by residual:
angle pdb=" N   GLY A  23 "
      pdb=" CA  GLY A  23 "
      pdb=" C   GLY A  23 "
    ideal   model   delta    sigma   weight residual
   114.69  120.22   -5.53 1.19e+00 7.06e-01 2.16e+01
angle pdb=" C   ARG A  21 "
      pdb=" N   GLN A  22 "
      pdb=" CA  GLN A  22 "
    ideal   model   delta    sigma   weight residual
   122.65  115.17    7.48 1.66e+00 3.63e-01 2.03e+01
angle pdb=" N   LYS A  24 "
      pdb=" CA  LYS A  24 "
      pdb=" C   LYS A  24 "
    ideal   model   delta    sigma   weight residual
   109.83  115.34   -5.51 1.27e+00 6.20e-01 1.88e+01
angle pdb=" N   LEU A  44 "
      pdb=" CA  LEU A  44 "
      pdb=" C   LEU A  44 "
    ideal   model   delta    sigma   weight residual
   109.25  115.47   -6.22 1.53e+00 4.27e-01 1.65e+01
angle pdb=" N   SER A  20 "
      pdb=" CA  SER A  20 "
      pdb=" C   SER A  20 "
    ideal   model   delta    sigma   weight residual
   110.35  115.71   -5.36 1.38e+00 5.25e-01 1.51e+01
angle pdb=" C   ARG A  21 "
      pdb=" CA  ARG A  21 "
      pdb=" CB  ARG A  21 "
    ideal   model   delta    sigma   weight residual
   110.88  107.05    3.83 1.57e+00 4.06e-01 5.94e+00
angle pdb=" N   LEU A  28 "
      pdb=" CA  LEU A  28 "
      pdb=" C   LEU A  28 "
    ideal   model   delta    sigma   weight residual
   108.90  112.85   -3.95 1.63e+00 3.76e-01 5.87e+00
angle pdb=" N   VAL A  45 "
      pdb=" CA  VAL A  45 "
      pdb=" C   VAL A  45 "
    ideal   model   delta    sigma   weight residual
   108.48  111.92   -3.44 1.44e+00 4.82e-01 5.71e+00
angle pdb=" CA  LYS A  24 "
      pdb=" C   LYS A  24 "
      pdb=" N   PRO A  25 "
    ideal   model   delta    sigma   weight residual
   118.23  116.30    1.93 9.20e-01 1.18e+00 4.41e+00
angle pdb=" C   SER A  20 "
      pdb=" CA  SER A  20 "
      pdb=" CB  SER A  20 "
    ideal   model   delta    sigma   weight residual
   111.71  107.17    4.54 2.23e+00 2.01e-01 4.14e+00
angle pdb=" C   SER A  27 "
      pdb=" CA  SER A  27 "
      pdb=" CB  SER A  27 "
    ideal   model   delta    sigma   weight residual
   109.65  113.21   -3.56 1.75e+00 3.27e-01 4.14e+00
angle pdb=" CA  VAL A  45 "
      pdb=" CB  VAL A  45 "
      pdb=" CG1 VAL A  45 "
    ideal   model   delta    sigma   weight residual
   110.40  113.70   -3.30 1.70e+00 3.46e-01 3.78e+00
angle pdb=" N   LYS A  24 "
      pdb=" CA  LYS A  24 "
      pdb=" CB  LYS A  24 "
    ideal   model   delta    sigma   weight residual
   110.02  107.23    2.79 1.58e+00 4.01e-01 3.13e+00
angle pdb=" NE  ARG A  21 "
      pdb=" CZ  ARG A  21 "
      pdb=" NH1 ARG A  21 "
    ideal   model   delta    sigma   weight residual
   121.50  120.05    1.45 1.00e+00 1.00e+00 2.10e+00
angle pdb=" C   VAL A  45 "
      pdb=" N   LYS A  46 "
      pdb=" CA  LYS A  46 "
    ideal   model   delta    sigma   weight residual
   122.65  120.51    2.14 1.49e+00 4.50e-01 2.07e+00
angle pdb=" C   VAL A  43 "
      pdb=" CA  VAL A  43 "
      pdb=" CB  VAL A  43 "
    ideal   model   delta    sigma   weight residual
   110.95  113.16   -2.21 1.61e+00 3.86e-01 1.88e+00
angle pdb=" CA  TYR A  26 "
      pdb=" CB  TYR A  26 "
      pdb=" CG  TYR A  26 "
    ideal   model   delta    sigma   weight residual
   113.90  116.16   -2.26 1.80e+00 3.09e-01 1.58e+00
angle pdb=" C   LEU A  44 "
      pdb=" N   VAL A  45 "
      pdb=" CA  VAL A  45 "
    ideal   model   delta    sigma   weight residual
   123.06  121.33    1.73 1.38e+00 5.25e-01 1.57e+00
angle pdb=" C   SER A  27 "
      pdb=" N   LEU A  28 "
      pdb=" CA  LEU A  28 "
    ideal   model   delta    sigma   weight residual
   122.99  121.30    1.69 1.41e+00 5.03e-01 1.43e+00
angle pdb=" C   LYS A  24 "
      pdb=" CA  LYS A  24 "
      pdb=" CB  LYS A  24 "
    ideal   model   delta    sigma   weight residual
   109.42  107.57    1.85 1.57e+00 4.06e-01 1.40e+00
angle pdb=" N   ARG A  21 "
      pdb=" CA  ARG A  21 "
      pdb=" C   ARG A  21 "
    ideal   model   delta    sigma   weight residual
   111.07  112.33   -1.26 1.07e+00 8.73e-01 1.39e+00
angle pdb=" C   ASN A  39 "
      pdb=" CA  ASN A  39 "
      pdb=" CB  ASN A  39 "
    ideal   model   delta    sigma   weight residual
   113.15  110.47    2.68 2.38e+00 1.77e-01 1.27e+00
angle pdb=" C   LYS A  46 "
      pdb=" N   ILE A  47 "
      pdb=" CA  ILE A  47 "
    ideal   model   delta    sigma   weight residual
   123.06  121.53    1.53 1.38e+00 5.25e-01 1.24e+00
angle pdb=" N   PRO A  85 "
      pdb=" CA  PRO A  85 "
      pdb=" C   PRO A  85 "
    ideal   model   delta    sigma   weight residual
   112.10  114.79   -2.69 2.50e+00 1.60e-01 1.16e+00
angle pdb=" CA  GLY A  23 "
      pdb=" C   GLY A  23 "
      pdb=" O   GLY A  23 "
    ideal   model   delta    sigma   weight residual
   119.27  120.42   -1.15 1.07e+00 8.73e-01 1.15e+00
angle pdb=" N   THR A  62 "
      pdb=" CA  THR A  62 "
      pdb=" C   THR A  62 "
    ideal   model   delta    sigma   weight residual
   109.41  107.80    1.61 1.52e+00 4.33e-01 1.12e+00
angle pdb=" C   GLN A  22 "
      pdb=" N   GLY A  23 "
      pdb=" CA  GLY A  23 "
    ideal   model   delta    sigma   weight residual
   122.86  121.32    1.54 1.46e+00 4.69e-01 1.12e+00
angle pdb=" C   TYR A  26 "
      pdb=" N   SER A  27 "
      pdb=" CA  SER A  27 "
    ideal   model   delta    sigma   weight residual
   122.33  120.56    1.77 1.68e+00 3.54e-01 1.12e+00
angle pdb=" O   VAL A  19 "
      pdb=" C   VAL A  19 "
      pdb=" N   SER A  20 "
    ideal   model   delta    sigma   weight residual
   123.10  121.98    1.12 1.07e+00 8.73e-01 1.10e+00
angle pdb=" CG1 VAL A  43 "
      pdb=" CB  VAL A  43 "
      pdb=" CG2 VAL A  43 "
    ideal   model   delta    sigma   weight residual
   110.80  113.11   -2.31 2.20e+00 2.07e-01 1.10e+00
angle pdb=" N   TYR A  26 "
      pdb=" CA  TYR A  26 "
      pdb=" C   TYR A  26 "
    ideal   model   delta    sigma   weight residual
   109.52  111.13   -1.61 1.55e+00 4.16e-01 1.08e+00
angle pdb=" N   VAL A  43 "
      pdb=" CA  VAL A  43 "
      pdb=" CB  VAL A  43 "
    ideal   model   delta    sigma   weight residual
   111.81  109.38    2.43 2.36e+00 1.80e-01 1.06e+00
angle pdb=" CA  PRO A  25 "
      pdb=" C   PRO A  25 "
      pdb=" O   PRO A  25 "
    ideal   model   delta    sigma   weight residual
   121.86  120.61    1.25 1.22e+00 6.72e-01 1.04e+00
angle pdb=" O   LYS A  24 "
      pdb=" C   LYS A  24 "
      pdb=" N   PRO A  25 "
    ideal   model   delta    sigma   weight residual
   121.43  122.53   -1.10 1.12e+00 7.97e-01 9.67e-01
angle pdb=" C   VAL A  45 "
      pdb=" CA  VAL A  45 "
      pdb=" CB  VAL A  45 "
    ideal   model   delta    sigma   weight residual
   110.62  112.06   -1.44 1.49e+00 4.50e-01 9.36e-01
angle pdb=" CA  ARG A  82 "
      pdb=" CB  ARG A  82 "
      pdb=" CG  ARG A  82 "
    ideal   model   delta    sigma   weight residual
   114.10  112.19    1.91 2.00e+00 2.50e-01 9.12e-01
angle pdb=" CA  VAL A  70 "
      pdb=" CB  VAL A  70 "
      pdb=" CG2 VAL A  70 "
    ideal   model   delta    sigma   weight residual
   110.40  108.80    1.60 1.70e+00 3.46e-01 8.88e-01
angle pdb=" N   VAL A  84 "
      pdb=" CA  VAL A  84 "
      pdb=" C   VAL A  84 "
    ideal   model   delta    sigma   weight residual
   108.88  106.85    2.03 2.16e+00 2.14e-01 8.84e-01
angle pdb=" N   LEU A  83 "
      pdb=" CA  LEU A  83 "
      pdb=" C   LEU A  83 "
    ideal   model   delta    sigma   weight residual
   110.17  111.62   -1.45 1.61e+00 3.86e-01 8.11e-01
angle pdb=" C   ARG A  16 "
      pdb=" CA  ARG A  16 "
      pdb=" CB  ARG A  16 "
    ideal   model   delta    sigma   weight residual
   109.75  111.23   -1.48 1.65e+00 3.67e-01 8.08e-01
angle pdb=" CA  ASN A  39 "
      pdb=" C   ASN A  39 "
      pdb=" O   ASN A  39 "
    ideal   model   delta    sigma   weight residual
   121.50  120.38    1.12 1.25e+00 6.40e-01 8.01e-01
angle pdb=" C   VAL A  84 "
      pdb=" CA  VAL A  84 "
      pdb=" CB  VAL A  84 "
    ideal   model   delta    sigma   weight residual
   111.36  112.99   -1.63 1.82e+00 3.02e-01 7.98e-01
angle pdb=" N   VAL A  45 "
      pdb=" CA  VAL A  45 "
      pdb=" CB  VAL A  45 "
    ideal   model   delta    sigma   weight residual
   111.39  109.84    1.55 1.74e+00 3.30e-01 7.91e-01
angle pdb=" C   GLY A  18 "
      pdb=" N   VAL A  19 "
      pdb=" CA  VAL A  19 "
    ideal   model   delta    sigma   weight residual
   122.94  121.72    1.22 1.39e+00 5.18e-01 7.67e-01
angle pdb=" C   ASN A  29 "
      pdb=" CA  ASN A  29 "
      pdb=" CB  ASN A  29 "
    ideal   model   delta    sigma   weight residual
   109.75  111.19   -1.44 1.65e+00 3.67e-01 7.64e-01
angle pdb=" NE  ARG A  21 "
      pdb=" CZ  ARG A  21 "
      pdb=" NH2 ARG A  21 "
    ideal   model   delta    sigma   weight residual
   119.20  119.98   -0.78 9.00e-01 1.23e+00 7.59e-01
angle pdb=" CA  LEU A  44 "
      pdb=" C   LEU A  44 "
      pdb=" N   VAL A  45 "
    ideal   model   delta    sigma   weight residual
   116.46  115.28    1.18 1.35e+00 5.49e-01 7.59e-01
angle pdb=" CA  LYS A  24 "
      pdb=" C   LYS A  24 "
      pdb=" O   LYS A  24 "
    ideal   model   delta    sigma   weight residual
   120.25  121.17   -0.92 1.08e+00 8.57e-01 7.28e-01
angle pdb=" N   LYS A   3 "
      pdb=" CA  LYS A   3 "
      pdb=" C   LYS A   3 "
    ideal   model   delta    sigma   weight residual
   109.24  110.62   -1.38 1.63e+00 3.76e-01 7.17e-01
angle pdb=" CA  LEU A  44 "
      pdb=" CB  LEU A  44 "
      pdb=" CG  LEU A  44 "
    ideal   model   delta    sigma   weight residual
   116.30  119.25   -2.95 3.50e+00 8.16e-02 7.10e-01
angle pdb=" C   GLU A  40 "
      pdb=" N   TYR A  41 "
      pdb=" CA  TYR A  41 "
    ideal   model   delta    sigma   weight residual
   122.74  124.79   -2.05 2.44e+00 1.68e-01 7.09e-01
angle pdb=" CA  ARG A  21 "
      pdb=" C   ARG A  21 "
      pdb=" N   GLN A  22 "
    ideal   model   delta    sigma   weight residual
   117.07  116.11    0.96 1.14e+00 7.69e-01 7.04e-01
angle pdb=" CA  LEU A  28 "
      pdb=" CB  LEU A  28 "
      pdb=" CG  LEU A  28 "
    ideal   model   delta    sigma   weight residual
   116.30  119.20   -2.90 3.50e+00 8.16e-02 6.88e-01
angle pdb=" N   VAL A  19 "
      pdb=" CA  VAL A  19 "
      pdb=" C   VAL A  19 "
    ideal   model   delta    sigma   weight residual
   108.46  109.69   -1.23 1.49e+00 4.50e-01 6.80e-01
angle pdb=" N   PHE A  68 "
      pdb=" CA  PHE A  68 "
      pdb=" C   PHE A  68 "
    ideal   model   delta    sigma   weight residual
   109.95  111.24   -1.29 1.59e+00 3.96e-01 6.61e-01
angle pdb=" N   PRO A  25 "
      pdb=" CD  PRO A  25 "
      pdb=" CG  PRO A  25 "
    ideal   model   delta    sigma   weight residual
   103.20  101.99    1.21 1.50e+00 4.44e-01 6.52e-01
angle pdb=" C   ARG A  82 "
      pdb=" CA  ARG A  82 "
      pdb=" CB  ARG A  82 "
    ideal   model   delta    sigma   weight residual
   110.19  111.48   -1.29 1.64e+00 3.72e-01 6.18e-01
angle pdb=" N   ARG A  21 "
      pdb=" CA  ARG A  21 "
      pdb=" CB  ARG A  21 "
    ideal   model   delta    sigma   weight residual
   110.01  108.87    1.14 1.45e+00 4.76e-01 6.14e-01
angle pdb=" O   SER A  27 "
      pdb=" C   SER A  27 "
      pdb=" N   LEU A  28 "
    ideal   model   delta    sigma   weight residual
   123.36  122.41    0.95 1.22e+00 6.72e-01 6.09e-01
angle pdb=" CA  PRO A  25 "
      pdb=" CB  PRO A  25 "
      pdb=" CG  PRO A  25 "
    ideal   model   delta    sigma   weight residual
   104.50  105.97   -1.47 1.90e+00 2.77e-01 6.01e-01
angle pdb=" N   PRO A  54 "
      pdb=" CA  PRO A  54 "
      pdb=" C   PRO A  54 "
    ideal   model   delta    sigma   weight residual
   111.22  110.15    1.07 1.40e+00 5.10e-01 5.86e-01
angle pdb=" N   LYS A  69 "
      pdb=" CA  LYS A  69 "
      pdb=" C   LYS A  69 "
    ideal   model   delta    sigma   weight residual
   108.96  107.82    1.14 1.49e+00 4.50e-01 5.83e-01
angle pdb=" C   LYS A  24 "
      pdb=" N   PRO A  25 "
      pdb=" CA  PRO A  25 "
    ideal   model   delta    sigma   weight residual
   120.14  119.33    0.81 1.06e+00 8.90e-01 5.78e-01
angle pdb=" CA  LYS A   3 "
      pdb=" CB  LYS A   3 "
      pdb=" CG  LYS A   3 "
    ideal   model   delta    sigma   weight residual
   114.10  112.62    1.48 2.00e+00 2.50e-01 5.47e-01
angle pdb=" CA  LEU A  44 "
      pdb=" C   LEU A  44 "
      pdb=" O   LEU A  44 "
    ideal   model   delta    sigma   weight residual
   120.49  121.34   -0.85 1.16e+00 7.43e-01 5.34e-01
angle pdb=" O   VAL A  45 "
      pdb=" C   VAL A  45 "
      pdb=" N   LYS A  46 "
    ideal   model   delta    sigma   weight residual
   123.18  122.40    0.78 1.08e+00 8.57e-01 5.26e-01
angle pdb=" N   ARG A  16 "
      pdb=" CA  ARG A  16 "
      pdb=" CB  ARG A  16 "
    ideal   model   delta    sigma   weight residual
   110.43  111.60   -1.17 1.63e+00 3.76e-01 5.19e-01
angle pdb=" N   TYR A  41 "
      pdb=" CA  TYR A  41 "
      pdb=" CB  TYR A  41 "
    ideal   model   delta    sigma   weight residual
   110.72  111.98   -1.26 1.76e+00 3.23e-01 5.11e-01
angle pdb=" C   VAL A  63 "
      pdb=" N   HIS A  64 "
      pdb=" CA  HIS A  64 "
    ideal   model   delta    sigma   weight residual
   121.39  122.56   -1.17 1.66e+00 3.63e-01 4.93e-01
angle pdb=" CG  LYS A   7 "
      pdb=" CD  LYS A   7 "
      pdb=" CE  LYS A   7 "
    ideal   model   delta    sigma   weight residual
   111.30  112.91   -1.61 2.30e+00 1.89e-01 4.91e-01
angle pdb=" C   GLN A  53 "
      pdb=" N   PRO A  54 "
      pdb=" CD  PRO A  54 "
    ideal   model   delta    sigma   weight residual
   125.00  127.87   -2.87 4.10e+00 5.95e-02 4.89e-01
angle pdb=" CA  ARG A  16 "
      pdb=" CB  ARG A  16 "
      pdb=" CG  ARG A  16 "
    ideal   model   delta    sigma   weight residual
   114.10  115.47   -1.37 2.00e+00 2.50e-01 4.72e-01
angle pdb=" C   LEU A  28 "
      pdb=" N   ASN A  29 "
      pdb=" CA  ASN A  29 "
    ideal   model   delta    sigma   weight residual
   122.72  121.78    0.94 1.38e+00 5.25e-01 4.69e-01
angle pdb=" CA  LEU A  32 "
      pdb=" CB  LEU A  32 "
      pdb=" CG  LEU A  32 "
    ideal   model   delta    sigma   weight residual
   116.30  118.68   -2.38 3.50e+00 8.16e-02 4.62e-01
angle pdb=" C   THR A  62 "
      pdb=" CA  THR A  62 "
      pdb=" CB  THR A  62 "
    ideal   model   delta    sigma   weight residual
   110.30  111.64   -1.34 1.98e+00 2.55e-01 4.57e-01
angle pdb=" N   VAL A  63 "
      pdb=" CA  VAL A  63 "
      pdb=" C   VAL A  63 "
    ideal   model   delta    sigma   weight residual
   108.58  109.54   -0.96 1.44e+00 4.82e-01 4.49e-01
angle pdb=" CA  LEU A  81 "
      pdb=" CB  LEU A  81 "
      pdb=" CG  LEU A  81 "
    ideal   model   delta    sigma   weight residual
   116.30  113.96    2.34 3.50e+00 8.16e-02 4.46e-01
angle pdb=" C   SER A  67 "
      pdb=" CA  SER A  67 "
      pdb=" CB  SER A  67 "
    ideal   model   delta    sigma   weight residual
   110.31  108.92    1.39 2.09e+00 2.29e-01 4.41e-01
angle pdb=" C   ALA A  57 "
      pdb=" N   PRO A  58 "
      pdb=" CD  PRO A  58 "
    ideal   model   delta    sigma   weight residual
   125.00  127.72   -2.72 4.10e+00 5.95e-02 4.39e-01
angle pdb=" N   TYR A  56 "
      pdb=" CA  TYR A  56 "
      pdb=" CB  TYR A  56 "
    ideal   model   delta    sigma   weight residual
   109.83  110.82   -0.99 1.51e+00 4.39e-01 4.34e-01
angle pdb=" C   LYS A   7 "
      pdb=" N   PRO A   8 "
      pdb=" CD  PRO A   8 "
    ideal   model   delta    sigma   weight residual
   125.00  127.68   -2.68 4.10e+00 5.95e-02 4.26e-01
angle pdb=" N   THR A  15 "
      pdb=" CA  THR A  15 "
      pdb=" C   THR A  15 "
    ideal   model   delta    sigma   weight residual
   108.52  109.58   -1.06 1.63e+00 3.76e-01 4.23e-01
angle pdb=" N   LEU A  44 "
      pdb=" CA  LEU A  44 "
      pdb=" CB  LEU A  44 "
    ideal   model   delta    sigma   weight residual
   109.87  108.81    1.06 1.63e+00 3.76e-01 4.22e-01
angle pdb=" O   GLY A  18 "
      pdb=" C   GLY A  18 "
      pdb=" N   VAL A  19 "
    ideal   model   delta    sigma   weight residual
   123.61  122.86    0.75 1.16e+00 7.43e-01 4.20e-01
angle pdb=" N   GLN A  10 "
      pdb=" CA  GLN A  10 "
      pdb=" CB  GLN A  10 "
    ideal   model   delta    sigma   weight residual
   110.92  109.88    1.04 1.60e+00 3.91e-01 4.19e-01
angle pdb=" CB  LEU A  28 "
      pdb=" CG  LEU A  28 "
      pdb=" CD1 LEU A  28 "
    ideal   model   delta    sigma   weight residual
   110.70  108.76    1.94 3.00e+00 1.11e-01 4.17e-01
angle pdb=" CA  TYR A  26 "
      pdb=" C   TYR A  26 "
      pdb=" N   SER A  27 "
    ideal   model   delta    sigma   weight residual
   115.34  116.35   -1.01 1.56e+00 4.11e-01 4.17e-01
angle pdb=" N   SER A  20 "
      pdb=" CA  SER A  20 "
      pdb=" CB  SER A  20 "
    ideal   model   delta    sigma   weight residual
   110.38  109.49    0.89 1.38e+00 5.25e-01 4.17e-01
angle pdb=" CA  VAL A  19 "
      pdb=" C   VAL A  19 "
      pdb=" N   SER A  20 "
    ideal   model   delta    sigma   weight residual
   116.18  116.98   -0.80 1.24e+00 6.50e-01 4.16e-01
angle pdb=" N   PRO A  25 "
      pdb=" CA  PRO A  25 "
      pdb=" CB  PRO A  25 "
    ideal   model   delta    sigma   weight residual
   103.15  102.53    0.62 9.70e-01 1.06e+00 4.08e-01
angle pdb=" CA  LYS A  24 "
      pdb=" CB  LYS A  24 "
      pdb=" CG  LYS A  24 "
    ideal   model   delta    sigma   weight residual
   114.10  115.37   -1.27 2.00e+00 2.50e-01 4.00e-01
angle pdb=" CA  SER A  20 "
      pdb=" C   SER A  20 "
      pdb=" N   ARG A  21 "
    ideal   model   delta    sigma   weight residual
   115.82  114.81    1.01 1.60e+00 3.91e-01 3.98e-01
angle pdb=" CA  VAL A  43 "
      pdb=" CB  VAL A  43 "
      pdb=" CG2 VAL A  43 "
    ideal   model   delta    sigma   weight residual
   110.40  111.47   -1.07 1.70e+00 3.46e-01 3.95e-01
angle pdb=" C   GLN A  31 "
      pdb=" CA  GLN A  31 "
      pdb=" CB  GLN A  31 "
    ideal   model   delta    sigma   weight residual
   109.38  110.69   -1.31 2.09e+00 2.29e-01 3.93e-01
angle pdb=" CA  GLN A  22 "
      pdb=" C   GLN A  22 "
      pdb=" N   GLY A  23 "
    ideal   model   delta    sigma   weight residual
   117.96  117.19    0.77 1.23e+00 6.61e-01 3.93e-01
angle pdb=" C   TYR A  41 "
      pdb=" N   PRO A  42 "
      pdb=" CD  PRO A  42 "
    ideal   model   delta    sigma   weight residual
   125.00  127.55   -2.55 4.10e+00 5.95e-02 3.87e-01
angle pdb=" CG  LYS A  46 "
      pdb=" CD  LYS A  46 "
      pdb=" CE  LYS A  46 "
    ideal   model   delta    sigma   weight residual
   111.30  109.88    1.42 2.30e+00 1.89e-01 3.83e-01
angle pdb=" CB  PRO A  42 "
      pdb=" CG  PRO A  42 "
      pdb=" CD  PRO A  42 "
    ideal   model   delta    sigma   weight residual
   106.10  108.04   -1.94 3.20e+00 9.77e-02 3.67e-01
angle pdb=" O   ASN A  39 "
      pdb=" C   ASN A  39 "
      pdb=" N   GLU A  40 "
    ideal   model   delta    sigma   weight residual
   121.83  122.60   -0.77 1.28e+00 6.10e-01 3.65e-01
angle pdb=" O   PRO A  25 "
      pdb=" C   PRO A  25 "
      pdb=" N   TYR A  26 "
    ideal   model   delta    sigma   weight residual
   123.13  123.89   -0.76 1.26e+00 6.30e-01 3.64e-01
angle pdb=" CA  PRO A  42 "
      pdb=" CB  PRO A  42 "
      pdb=" CG  PRO A  42 "
    ideal   model   delta    sigma   weight residual
   104.50  105.65   -1.15 1.90e+00 2.77e-01 3.64e-01
angle pdb=" CA  VAL A  84 "
      pdb=" CB  VAL A  84 "
      pdb=" CG1 VAL A  84 "
    ideal   model   delta    sigma   weight residual
   110.40  111.42   -1.02 1.70e+00 3.46e-01 3.63e-01
angle pdb=" N   GLN A  53 "
      pdb=" CA  GLN A  53 "
      pdb=" CB  GLN A  53 "
    ideal   model   delta    sigma   weight residual
   110.01  110.99   -0.98 1.63e+00 3.76e-01 3.61e-01
angle pdb=" C   ALA A  57 "
      pdb=" CA  ALA A  57 "
      pdb=" CB  ALA A  57 "
    ideal   model   delta    sigma   weight residual
   109.51  110.62   -1.11 1.85e+00 2.92e-01 3.59e-01
angle pdb=" N   GLU A  30 "
      pdb=" CA  GLU A  30 "
      pdb=" C   GLU A  30 "
    ideal   model   delta    sigma   weight residual
   109.40  110.38   -0.98 1.63e+00 3.76e-01 3.58e-01
angle pdb=" N   ASP A  79 "
      pdb=" CA  ASP A  79 "
      pdb=" C   ASP A  79 "
    ideal   model   delta    sigma   weight residual
   110.80  109.53    1.27 2.13e+00 2.20e-01 3.54e-01
angle pdb=" O   LYS A  46 "
      pdb=" C   LYS A  46 "
      pdb=" N   ILE A  47 "
    ideal   model   delta    sigma   weight residual
   123.19  122.50    0.69 1.17e+00 7.31e-01 3.53e-01
angle pdb=" N   THR A  14 "
      pdb=" CA  THR A  14 "
      pdb=" C   THR A  14 "
    ideal   model   delta    sigma   weight residual
   109.95  109.01    0.94 1.59e+00 3.96e-01 3.48e-01
angle pdb=" C   PHE A  68 "
      pdb=" N   LYS A  69 "
      pdb=" CA  LYS A  69 "
    ideal   model   delta    sigma   weight residual
   121.87  122.84   -0.97 1.64e+00 3.72e-01 3.47e-01
angle pdb=" C   ASP A  50 "
      pdb=" N   GLU A  51 "
      pdb=" CA  GLU A  51 "
    ideal   model   delta    sigma   weight residual
   120.87  120.04    0.83 1.42e+00 4.96e-01 3.43e-01
angle pdb=" CG  ARG A  82 "
      pdb=" CD  ARG A  82 "
      pdb=" NE  ARG A  82 "
    ideal   model   delta    sigma   weight residual
   112.00  110.71    1.29 2.20e+00 2.07e-01 3.41e-01
angle pdb=" CA  TYR A  61 "
      pdb=" CB  TYR A  61 "
      pdb=" CG  TYR A  61 "
    ideal   model   delta    sigma   weight residual
   113.90  114.95   -1.05 1.80e+00 3.09e-01 3.40e-01
angle pdb=" CD  LYS A   7 "
      pdb=" CE  LYS A   7 "
      pdb=" NZ  LYS A   7 "
    ideal   model   delta    sigma   weight residual
   111.90  113.76   -1.86 3.20e+00 9.77e-02 3.37e-01
angle pdb=" O   TYR A  26 "
      pdb=" C   TYR A  26 "
      pdb=" N   SER A  27 "
    ideal   model   delta    sigma   weight residual
   123.15  122.40    0.75 1.30e+00 5.92e-01 3.34e-01
angle pdb=" C   PHE A  73 "
      pdb=" CA  PHE A  73 "
      pdb=" CB  PHE A  73 "
    ideal   model   delta    sigma   weight residual
   110.72  109.74    0.98 1.69e+00 3.50e-01 3.33e-01
angle pdb=" CD  LYS A   3 "
      pdb=" CE  LYS A   3 "
      pdb=" NZ  LYS A   3 "
    ideal   model   delta    sigma   weight residual
   111.90  110.06    1.84 3.20e+00 9.77e-02 3.32e-01
angle pdb=" N   ARG A  16 "
      pdb=" CA  ARG A  16 "
      pdb=" C   ARG A  16 "
    ideal   model   delta    sigma   weight residual
   109.24  108.30    0.94 1.63e+00 3.76e-01 3.31e-01
angle pdb=" N   PRO A  42 "
      pdb=" CA  PRO A  42 "
      pdb=" CB  PRO A  42 "
    ideal   model   delta    sigma   weight residual
   103.39  103.93   -0.54 9.40e-01 1.13e+00 3.30e-01
angle pdb=" C   VAL A  43 "
      pdb=" N   LEU A  44 "
      pdb=" CA  LEU A  44 "
    ideal   model   delta    sigma   weight residual
   121.72  122.55   -0.83 1.45e+00 4.76e-01 3.30e-01
angle pdb=" N   ASN A  29 "
      pdb=" CA  ASN A  29 "
      pdb=" C   ASN A  29 "
    ideal   model   delta    sigma   weight residual
   109.24  108.31    0.93 1.63e+00 3.76e-01 3.27e-01
angle pdb=" CB  GLN A  22 "
      pdb=" CG  GLN A  22 "
      pdb=" CD  GLN A  22 "
    ideal   model   delta    sigma   weight residual
   112.60  113.54   -0.94 1.70e+00 3.46e-01 3.07e-01
angle pdb=" C   GLY A  38 "
      pdb=" N   ASN A  39 "
      pdb=" CA  ASN A  39 "
    ideal   model   delta    sigma   weight residual
   122.12  121.15    0.97 1.76e+00 3.23e-01 3.03e-01
angle pdb=" C   ALA A  55 "
      pdb=" N   TYR A  56 "
      pdb=" CA  TYR A  56 "
    ideal   model   delta    sigma   weight residual
   120.71  119.93    0.78 1.42e+00 4.96e-01 3.03e-01
angle pdb=" CA  THR A  62 "
      pdb=" C   THR A  62 "
      pdb=" N   VAL A  63 "
    ideal   model   delta    sigma   weight residual
   115.42  116.32   -0.90 1.64e+00 3.72e-01 3.01e-01
angle pdb=" CD  LYS A  24 "
      pdb=" CE  LYS A  24 "
      pdb=" NZ  LYS A  24 "
    ideal   model   delta    sigma   weight residual
   111.90  110.14    1.76 3.20e+00 9.77e-02 3.01e-01
angle pdb=" CB  PRO A  25 "
      pdb=" CG  PRO A  25 "
      pdb=" CD  PRO A  25 "
    ideal   model   delta    sigma   weight residual
   106.10  104.35    1.75 3.20e+00 9.77e-02 2.98e-01
angle pdb=" N   PHE A  13 "
      pdb=" CA  PHE A  13 "
      pdb=" CB  PHE A  13 "
    ideal   model   delta    sigma   weight residual
   111.08  112.01   -0.93 1.71e+00 3.42e-01 2.93e-01
angle pdb=" N   LEU A  81 "
      pdb=" CA  LEU A  81 "
      pdb=" CB  LEU A  81 "
    ideal   model   delta    sigma   weight residual
   109.60  110.48   -0.88 1.64e+00 3.72e-01 2.90e-01
angle pdb=" CB  LYS A  24 "
      pdb=" CG  LYS A  24 "
      pdb=" CD  LYS A  24 "
    ideal   model   delta    sigma   weight residual
   111.30  110.06    1.24 2.30e+00 1.89e-01 2.89e-01
angle pdb=" CB  ARG A  82 "
      pdb=" CG  ARG A  82 "
      pdb=" CD  ARG A  82 "
    ideal   model   delta    sigma   weight residual
   111.30  112.53   -1.23 2.30e+00 1.89e-01 2.86e-01
angle pdb=" CG1 VAL A  70 "
      pdb=" CB  VAL A  70 "
      pdb=" CG2 VAL A  70 "
    ideal   model   delta    sigma   weight residual
   110.80  111.97   -1.17 2.20e+00 2.07e-01 2.85e-01
angle pdb=" CA  GLY A  18 "
      pdb=" C   GLY A  18 "
      pdb=" N   VAL A  19 "
    ideal   model   delta    sigma   weight residual
   114.72  115.42   -0.70 1.32e+00 5.74e-01 2.85e-01
angle pdb=" CA  GLU A  40 "
      pdb=" CB  GLU A  40 "
      pdb=" CG  GLU A  40 "
    ideal   model   delta    sigma   weight residual
   114.10  115.17   -1.07 2.00e+00 2.50e-01 2.84e-01
angle pdb=" N   ARG A  80 "
      pdb=" CA  ARG A  80 "
      pdb=" CB  ARG A  80 "
    ideal   model   delta    sigma   weight residual
   111.13  112.09   -0.96 1.81e+00 3.05e-01 2.82e-01
angle pdb=" CA  VAL A  19 "
      pdb=" CB  VAL A  19 "
      pdb=" CG1 VAL A  19 "
    ideal   model   delta    sigma   weight residual
   110.40  111.30   -0.90 1.70e+00 3.46e-01 2.81e-01
angle pdb=" C   LEU A  83 "
      pdb=" N   VAL A  84 "
      pdb=" CA  VAL A  84 "
    ideal   model   delta    sigma   weight residual
   122.13  123.11   -0.98 1.85e+00 2.92e-01 2.80e-01
angle pdb=" N   GLN A  12 "
      pdb=" CA  GLN A  12 "
      pdb=" CB  GLN A  12 "
    ideal   model   delta    sigma   weight residual
   110.70  111.49   -0.79 1.49e+00 4.50e-01 2.78e-01
angle pdb=" C   SER A  17 "
      pdb=" N   GLY A  18 "
      pdb=" CA  GLY A  18 "
    ideal   model   delta    sigma   weight residual
   120.86  120.01    0.85 1.62e+00 3.81e-01 2.78e-01
angle pdb=" CA  GLU A  51 "
      pdb=" CB  GLU A  51 "
      pdb=" CG  GLU A  51 "
    ideal   model   delta    sigma   weight residual
   114.10  115.14   -1.04 2.00e+00 2.50e-01 2.72e-01
angle pdb=" C   VAL A   4 "
      pdb=" N   GLU A   5 "
      pdb=" CA  GLU A   5 "
    ideal   model   delta    sigma   weight residual
   122.73  121.89    0.84 1.62e+00 3.81e-01 2.71e-01
angle pdb=" N   GLN A  72 "
      pdb=" CA  GLN A  72 "
      pdb=" CB  GLN A  72 "
    ideal   model   delta    sigma   weight residual
   110.39  109.49    0.90 1.75e+00 3.27e-01 2.66e-01
angle pdb=" N   GLU A   5 "
      pdb=" CA  GLU A   5 "
      pdb=" C   GLU A   5 "
    ideal   model   delta    sigma   weight residual
   109.24  110.10   -0.86 1.67e+00 3.59e-01 2.64e-01
angle pdb=" NH1 ARG A  21 "
      pdb=" CZ  ARG A  21 "
      pdb=" NH2 ARG A  21 "
    ideal   model   delta    sigma   weight residual
   119.30  119.97   -0.67 1.30e+00 5.92e-01 2.63e-01
angle pdb=" CB  LEU A  44 "
      pdb=" CG  LEU A  44 "
      pdb=" CD2 LEU A  44 "
    ideal   model   delta    sigma   weight residual
   110.70  109.18    1.52 3.00e+00 1.11e-01 2.57e-01
angle pdb=" N   LYS A  46 "
      pdb=" CA  LYS A  46 "
      pdb=" CB  LYS A  46 "
    ideal   model   delta    sigma   weight residual
   110.52  111.35   -0.83 1.65e+00 3.67e-01 2.55e-01
angle pdb=" C   GLN A  10 "
      pdb=" CA  GLN A  10 "
      pdb=" CB  GLN A  10 "
    ideal   model   delta    sigma   weight residual
   111.02  110.21    0.81 1.61e+00 3.86e-01 2.51e-01
angle pdb=" CA  GLY A  23 "
      pdb=" C   GLY A  23 "
      pdb=" N   LYS A  24 "
    ideal   model   delta    sigma   weight residual
   118.05  117.38    0.67 1.34e+00 5.57e-01 2.50e-01
angle pdb=" CA  VAL A  43 "
      pdb=" CB  VAL A  43 "
      pdb=" CG1 VAL A  43 "
    ideal   model   delta    sigma   weight residual
   110.40  111.25   -0.85 1.70e+00 3.46e-01 2.48e-01
angle pdb=" N   THR A  14 "
      pdb=" CA  THR A  14 "
      pdb=" CB  THR A  14 "
    ideal   model   delta    sigma   weight residual
   110.85  111.64   -0.79 1.60e+00 3.91e-01 2.47e-01
angle pdb=" O   SER A  20 "
      pdb=" C   SER A  20 "
      pdb=" N   ARG A  21 "
    ideal   model   delta    sigma   weight residual
   122.23  122.88   -0.65 1.33e+00 5.65e-01 2.35e-01
angle pdb=" C   LEU A  37 "
      pdb=" CA  LEU A  37 "
      pdb=" CB  LEU A  37 "
    ideal   model   delta    sigma   weight residual
   110.94  110.14    0.80 1.65e+00 3.67e-01 2.32e-01
angle pdb=" C   PRO A  25 "
      pdb=" CA  PRO A  25 "
      pdb=" CB  PRO A  25 "
    ideal   model   delta    sigma   weight residual
   110.63  109.94    0.69 1.43e+00 4.89e-01 2.32e-01
angle pdb=" CA  VAL A  45 "
      pdb=" CB  VAL A  45 "
      pdb=" CG2 VAL A  45 "
    ideal   model   delta    sigma   weight residual
   110.40  111.22   -0.82 1.70e+00 3.46e-01 2.31e-01
angle pdb=" N   ASP A  50 "
      pdb=" CA  ASP A  50 "
      pdb=" CB  ASP A  50 "
    ideal   model   delta    sigma   weight residual
   110.36  111.04   -0.68 1.43e+00 4.89e-01 2.25e-01
angle pdb=" N   LEU A  60 "
      pdb=" CA  LEU A  60 "
      pdb=" C   LEU A  60 "
    ideal   model   delta    sigma   weight residual
   109.07  109.83   -0.76 1.61e+00 3.86e-01 2.22e-01
angle pdb=" N   LYS A  46 "
      pdb=" CA  LYS A  46 "
      pdb=" C   LYS A  46 "
    ideal   model   delta    sigma   weight residual
   109.76  108.99    0.77 1.64e+00 3.72e-01 2.20e-01
angle pdb=" C   ARG A  80 "
      pdb=" N   LEU A  81 "
      pdb=" CA  LEU A  81 "
    ideal   model   delta    sigma   weight residual
   121.66  120.93    0.73 1.56e+00 4.11e-01 2.18e-01
angle pdb=" N   LEU A  28 "
      pdb=" CA  LEU A  28 "
      pdb=" CB  LEU A  28 "
    ideal   model   delta    sigma   weight residual
   110.68  109.90    0.78 1.68e+00 3.54e-01 2.18e-01
angle pdb=" C   GLU A  51 "
      pdb=" CA  GLU A  51 "
      pdb=" CB  GLU A  51 "
    ideal   model   delta    sigma   weight residual
   109.65  110.45   -0.80 1.71e+00 3.42e-01 2.17e-01
angle pdb=" CG1 VAL A  45 "
      pdb=" CB  VAL A  45 "
      pdb=" CG2 VAL A  45 "
    ideal   model   delta    sigma   weight residual
   110.80  111.82   -1.02 2.20e+00 2.07e-01 2.14e-01
angle pdb=" O   VAL A  43 "
      pdb=" C   VAL A  43 "
      pdb=" N   LEU A  44 "
    ideal   model   delta    sigma   weight residual
   122.98  123.46   -0.48 1.04e+00 9.25e-01 2.12e-01
angle pdb=" O   LEU A  28 "
      pdb=" C   LEU A  28 "
      pdb=" N   ASN A  29 "
    ideal   model   delta    sigma   weight residual
   123.30  122.75    0.55 1.19e+00 7.06e-01 2.10e-01
angle pdb=" CA  PHE A  13 "
      pdb=" CB  PHE A  13 "
      pdb=" CG  PHE A  13 "
    ideal   model   delta    sigma   weight residual
   113.80  114.26   -0.46 1.00e+00 1.00e+00 2.10e-01
angle pdb=" CA  VAL A   4 "
      pdb=" C   VAL A   4 "
      pdb=" N   GLU A   5 "
    ideal   model   delta    sigma   weight residual
   116.11  116.70   -0.59 1.29e+00 6.01e-01 2.08e-01
angle pdb=" C   SER A   9 "
      pdb=" N   GLN A  10 "
      pdb=" CA  GLN A  10 "
    ideal   model   delta    sigma   weight residual
   122.67  123.39   -0.72 1.59e+00 3.96e-01 2.02e-01
angle pdb=" CA  ARG A  21 "
      pdb=" C   ARG A  21 "
      pdb=" O   ARG A  21 "
    ideal   model   delta    sigma   weight residual
   120.82  121.29   -0.47 1.05e+00 9.07e-01 2.02e-01
angle pdb=" C   SER A   9 "
      pdb=" CA  SER A   9 "
      pdb=" CB  SER A   9 "
    ideal   model   delta    sigma   weight residual
   110.11  109.26    0.85 1.90e+00 2.77e-01 2.00e-01
angle pdb=" CA  GLU A   5 "
      pdb=" CB  GLU A   5 "
      pdb=" CG  GLU A   5 "
    ideal   model   delta    sigma   weight residual
   114.10  113.21    0.89 2.00e+00 2.50e-01 1.97e-01
angle pdb=" CB  ILE A   2 "
      pdb=" CG1 ILE A   2 "
      pdb=" CD1 ILE A   2 "
    ideal   model   delta    sigma   weight residual
   113.80  112.87    0.93 2.10e+00 2.27e-01 1.97e-01
angle pdb=" CA  LYS A  46 "
      pdb=" C   LYS A  46 "
      pdb=" N   ILE A  47 "
    ideal   model   delta    sigma   weight residual
   115.96  116.53   -0.57 1.29e+00 6.01e-01 1.94e-01
angle pdb=" C   ILE A  78 "
      pdb=" N   ASP A  79 "
      pdb=" CA  ASP A  79 "
    ideal   model   delta    sigma   weight residual
   121.54  122.38   -0.84 1.91e+00 2.74e-01 1.93e-01
angle pdb=" CB  GLU A   5 "
      pdb=" CG  GLU A   5 "
      pdb=" CD  GLU A   5 "
    ideal   model   delta    sigma   weight residual
   112.60  113.35   -0.75 1.70e+00 3.46e-01 1.93e-01
angle pdb=" CA  ILE A   2 "
      pdb=" CB  ILE A   2 "
      pdb=" CG1 ILE A   2 "
    ideal   model   delta    sigma   weight residual
   110.40  111.15   -0.75 1.70e+00 3.46e-01 1.93e-01
angle pdb=" C   TYR A  61 "
      pdb=" CA  TYR A  61 "
      pdb=" CB  TYR A  61 "
    ideal   model   delta    sigma   weight residual
   110.30  109.43    0.87 1.98e+00 2.55e-01 1.93e-01
angle pdb=" CA  PRO A  25 "
      pdb=" C   PRO A  25 "
      pdb=" N   TYR A  26 "
    ideal   model   delta    sigma   weight residual
   114.91  115.48   -0.57 1.29e+00 6.01e-01 1.92e-01
angle pdb=" C   ASP A  79 "
      pdb=" N   ARG A  80 "
      pdb=" CA  ARG A  80 "
    ideal   model   delta    sigma   weight residual
   121.94  122.71   -0.77 1.76e+00 3.23e-01 1.92e-01
angle pdb=" O   ARG A  21 "
      pdb=" C   ARG A  21 "
      pdb=" N   GLN A  22 "
    ideal   model   delta    sigma   weight residual
   122.07  122.52   -0.45 1.03e+00 9.43e-01 1.92e-01
angle pdb=" O   GLN A  22 "
      pdb=" C   GLN A  22 "
      pdb=" N   GLY A  23 "
    ideal   model   delta    sigma   weight residual
   122.37  122.93   -0.56 1.28e+00 6.10e-01 1.92e-01
angle pdb=" C   PHE A  13 "
      pdb=" N   THR A  14 "
      pdb=" CA  THR A  14 "
    ideal   model   delta    sigma   weight residual
   122.87  122.17    0.70 1.61e+00 3.86e-01 1.90e-01
angle pdb=" C   GLN A  72 "
      pdb=" N   PHE A  73 "
      pdb=" CA  PHE A  73 "
    ideal   model   delta    sigma   weight residual
   122.60  121.92    0.68 1.56e+00 4.11e-01 1.90e-01
angle pdb=" C   SER A  20 "
      pdb=" N   ARG A  21 "
      pdb=" CA  ARG A  21 "
    ideal   model   delta    sigma   weight residual
   120.44  119.88    0.56 1.30e+00 5.92e-01 1.89e-01
angle pdb=" CA  PRO A  42 "
      pdb=" C   PRO A  42 "
      pdb=" N   VAL A  43 "
    ideal   model   delta    sigma   weight residual
   115.04  114.46    0.58 1.35e+00 5.49e-01 1.87e-01
angle pdb=" CB  LYS A   7 "
      pdb=" CG  LYS A   7 "
      pdb=" CD  LYS A   7 "
    ideal   model   delta    sigma   weight residual
   111.30  110.31    0.99 2.30e+00 1.89e-01 1.87e-01
angle pdb=" CA  ILE A  47 "
      pdb=" CB  ILE A  47 "
      pdb=" CG1 ILE A  47 "
    ideal   model   delta    sigma   weight residual
   110.40  111.13   -0.73 1.70e+00 3.46e-01 1.86e-01
angle pdb=" N   VAL A  19 "
      pdb=" CA  VAL A  19 "
      pdb=" CB  VAL A  19 "
    ideal   model   delta    sigma   weight residual
   111.44  112.15   -0.71 1.64e+00 3.72e-01 1.85e-01
angle pdb=" CA  LEU A  83 "
      pdb=" CB  LEU A  83 "
      pdb=" CG  LEU A  83 "
    ideal   model   delta    sigma   weight residual
   116.30  114.80    1.50 3.50e+00 8.16e-02 1.83e-01
angle pdb=" CA  LEU A  28 "
      pdb=" C   LEU A  28 "
      pdb=" N   ASN A  29 "
    ideal   model   delta    sigma   weight residual
   116.29  116.84   -0.55 1.30e+00 5.92e-01 1.78e-01
angle pdb=" N   ILE A   6 "
      pdb=" CA  ILE A   6 "
      pdb=" CB  ILE A   6 "
    ideal   model   delta    sigma   weight residual
   111.41  111.93   -0.52 1.25e+00 6.40e-01 1.74e-01
angle pdb=" N   TYR A  34 "
      pdb=" CA  TYR A  34 "
      pdb=" CB  TYR A  34 "
    ideal   model   delta    sigma   weight residual
   110.65  111.30   -0.65 1.56e+00 4.11e-01 1.74e-01
angle pdb=" CA  SER A  27 "
      pdb=" C   SER A  27 "
      pdb=" N   LEU A  28 "
    ideal   model   delta    sigma   weight residual
   116.31  116.93   -0.62 1.48e+00 4.57e-01 1.73e-01
angle pdb=" N   GLU A   5 "
      pdb=" CA  GLU A   5 "
      pdb=" CB  GLU A   5 "
    ideal   model   delta    sigma   weight residual
   111.00  111.75   -0.75 1.81e+00 3.05e-01 1.73e-01
angle pdb=" C   HIS A  64 "
      pdb=" N   LEU A  65 "
      pdb=" CA  LEU A  65 "
    ideal   model   delta    sigma   weight residual
   120.28  120.88   -0.60 1.44e+00 4.82e-01 1.72e-01
angle pdb=" CA  PHE A  68 "
      pdb=" C   PHE A  68 "
      pdb=" N   LYS A  69 "
    ideal   model   delta    sigma   weight residual
   115.60  114.99    0.61 1.48e+00 4.57e-01 1.71e-01
angle pdb=" CE2 TYR A  41 "
      pdb=" CZ  TYR A  41 "
      pdb=" OH  TYR A  41 "
    ideal   model   delta    sigma   weight residual
   119.90  118.66    1.24 3.00e+00 1.11e-01 1.70e-01
angle pdb=" N   GLY A  71 "
      pdb=" CA  GLY A  71 "
      pdb=" C   GLY A  71 "
    ideal   model   delta    sigma   weight residual
   112.30  112.99   -0.69 1.68e+00 3.54e-01 1.70e-01
angle pdb=" CB  ILE A  47 "
      pdb=" CG1 ILE A  47 "
      pdb=" CD1 ILE A  47 "
    ideal   model   delta    sigma   weight residual
   113.80  112.94    0.86 2.10e+00 2.27e-01 1.67e-01
angle pdb=" CA  ALA A  11 "
      pdb=" C   ALA A  11 "
      pdb=" N   GLN A  12 "
    ideal   model   delta    sigma   weight residual
   118.44  119.01   -0.57 1.41e+00 5.03e-01 1.65e-01
angle pdb=" O   GLY A  23 "
      pdb=" C   GLY A  23 "
      pdb=" N   LYS A  24 "
    ideal   model   delta    sigma   weight residual
   122.65  122.19    0.46 1.13e+00 7.83e-01 1.64e-01
angle pdb=" C   SER A  75 "
      pdb=" N   LEU A  76 "
      pdb=" CA  LEU A  76 "
    ideal   model   delta    sigma   weight residual
   120.87  121.44   -0.57 1.42e+00 4.96e-01 1.62e-01
angle pdb=" N   LEU A  65 "
      pdb=" CA  LEU A  65 "
      pdb=" CB  LEU A  65 "
    ideal   model   delta    sigma   weight residual
   110.22  109.60    0.62 1.54e+00 4.22e-01 1.62e-01
angle pdb=" CB  LEU A  60 "
      pdb=" CG  LEU A  60 "
      pdb=" CD2 LEU A  60 "
    ideal   model   delta    sigma   weight residual
   110.70  109.49    1.21 3.00e+00 1.11e-01 1.62e-01
angle pdb=" N   ASP A  50 "
      pdb=" CA  ASP A  50 "
      pdb=" C   ASP A  50 "
    ideal   model   delta    sigma   weight residual
   110.53  110.00    0.53 1.32e+00 5.74e-01 1.59e-01
angle pdb=" CA  PHE A  68 "
      pdb=" C   PHE A  68 "
      pdb=" O   PHE A  68 "
    ideal   model   delta    sigma   weight residual
   121.16  121.61   -0.45 1.13e+00 7.83e-01 1.59e-01
angle pdb=" N   GLU A  51 "
      pdb=" CA  GLU A  51 "
      pdb=" CB  GLU A  51 "
    ideal   model   delta    sigma   weight residual
   109.97  110.55   -0.58 1.47e+00 4.63e-01 1.58e-01
angle pdb=" CA  GLN A  31 "
      pdb=" C   GLN A  31 "
      pdb=" N   LEU A  32 "
    ideal   model   delta    sigma   weight residual
   115.58  116.17   -0.59 1.48e+00 4.57e-01 1.57e-01
angle pdb=" C   PRO A  54 "
      pdb=" N   ALA A  55 "
      pdb=" CA  ALA A  55 "
    ideal   model   delta    sigma   weight residual
   120.87  120.31    0.56 1.42e+00 4.96e-01 1.57e-01
angle pdb=" CA  ILE A   6 "
      pdb=" CB  ILE A   6 "
      pdb=" CG1 ILE A   6 "
    ideal   model   delta    sigma   weight residual
   110.40  111.07   -0.67 1.70e+00 3.46e-01 1.56e-01
angle pdb=" C   ASP A  36 "
      pdb=" N   LEU A  37 "
      pdb=" CA  LEU A  37 "
    ideal   model   delta    sigma   weight residual
   122.73  122.10    0.63 1.61e+00 3.86e-01 1.55e-01
angle pdb=" C   GLY A  71 "
      pdb=" N   GLN A  72 "
      pdb=" CA  GLN A  72 "
    ideal   model   delta    sigma   weight residual
   121.18  121.95   -0.77 1.98e+00 2.55e-01 1.53e-01
angle pdb=" CA  SER A  27 "
      pdb=" CB  SER A  27 "
      pdb=" OG  SER A  27 "
    ideal   model   delta    sigma   weight residual
   111.10  111.88   -0.78 2.00e+00 2.50e-01 1.53e-01
angle pdb=" C   LEU A  81 "
      pdb=" CA  LEU A  81 "
      pdb=" CB  LEU A  81 "
    ideal   model   delta    sigma   weight residual
   110.67  111.26   -0.59 1.52e+00 4.33e-01 1.50e-01
angle pdb=" N   TYR A  56 "
      pdb=" CA  TYR A  56 "
      pdb=" C   TYR A  56 "
    ideal   model   delta    sigma   weight residual
   110.23  109.67    0.56 1.45e+00 4.76e-01 1.49e-01
angle pdb=" C   ALA A  55 "
      pdb=" CA  ALA A  55 "
      pdb=" CB  ALA A  55 "
    ideal   model   delta    sigma   weight residual
   109.65  110.31   -0.66 1.71e+00 3.42e-01 1.48e-01
angle pdb=" C   GLN A  12 "
      pdb=" CA  GLN A  12 "
      pdb=" CB  GLN A  12 "
    ideal   model   delta    sigma   weight residual
   110.36  109.68    0.68 1.78e+00 3.16e-01 1.47e-01
angle pdb=" C   LYS A  69 "
      pdb=" N   VAL A  70 "
      pdb=" CA  VAL A  70 "
    ideal   model   delta    sigma   weight residual
   122.37  121.89    0.48 1.25e+00 6.40e-01 1.47e-01
angle pdb=" C   SER A  17 "
      pdb=" CA  SER A  17 "
      pdb=" CB  SER A  17 "
    ideal   model   delta    sigma   weight residual
   109.71  110.40   -0.69 1.80e+00 3.09e-01 1.47e-01
angle pdb=" CA  LEU A  65 "
      pdb=" CB  LEU A  65 "
      pdb=" CG  LEU A  65 "
    ideal   model   delta    sigma   weight residual
   116.30  117.64   -1.34 3.50e+00 8.16e-02 1.47e-01
angle pdb=" N   ALA A  55 "
      pdb=" CA  ALA A  55 "
      pdb=" CB  ALA A  55 "
    ideal   model   delta    sigma   weight residual
   109.97  110.53   -0.56 1.47e+00 4.63e-01 1.47e-01
angle pdb=" C   THR A  15 "
      pdb=" N   ARG A  16 "
      pdb=" CA  ARG A  16 "
    ideal   model   delta    sigma   weight residual
   122.72  122.19    0.53 1.38e+00 5.25e-01 1.46e-01
angle pdb=" N   LEU A  32 "
      pdb=" CA  LEU A  32 "
      pdb=" CB  LEU A  32 "
    ideal   model   delta    sigma   weight residual
   110.56  111.16   -0.60 1.56e+00 4.11e-01 1.46e-01
angle pdb=" N   GLY A  18 "
      pdb=" CA  GLY A  18 "
      pdb=" C   GLY A  18 "
    ideal   model   delta    sigma   weight residual
   110.42  110.99   -0.57 1.49e+00 4.50e-01 1.45e-01
angle pdb=" N   GLN A  10 "
      pdb=" CA  GLN A  10 "
      pdb=" C   GLN A  10 "
    ideal   model   delta    sigma   weight residual
   112.59  112.13    0.46 1.22e+00 6.72e-01 1.42e-01
angle pdb=" N   ILE A  47 "
      pdb=" CA  ILE A  47 "
      pdb=" CB  ILE A  47 "
    ideal   model   delta    sigma   weight residual
   111.39  112.04   -0.65 1.74e+00 3.30e-01 1.41e-01
angle pdb=" N   GLN A  53 "
      pdb=" CA  GLN A  53 "
      pdb=" C   GLN A  53 "
    ideal   model   delta    sigma   weight residual
   109.65  110.12   -0.47 1.26e+00 6.30e-01 1.40e-01
angle pdb=" N   ALA A  11 "
      pdb=" CA  ALA A  11 "
      pdb=" C   ALA A  11 "
    ideal   model   delta    sigma   weight residual
   113.20  113.65   -0.45 1.21e+00 6.83e-01 1.39e-01
angle pdb=" C   VAL A  84 "
      pdb=" N   PRO A  85 "
      pdb=" CA  PRO A  85 "
    ideal   model   delta    sigma   weight residual
   122.60  124.46   -1.86 5.00e+00 4.00e-02 1.39e-01
angle pdb=" N   GLY A  59 "
      pdb=" CA  GLY A  59 "
      pdb=" C   GLY A  59 "
    ideal   model   delta    sigma   weight residual
   110.63  111.16   -0.53 1.43e+00 4.89e-01 1.38e-01
angle pdb=" N   LYS A   7 "
      pdb=" CA  LYS A   7 "
      pdb=" CB  LYS A   7 "
    ideal   model   delta    sigma   weight residual
   110.05  110.58   -0.53 1.44e+00 4.82e-01 1.38e-01
angle pdb=" C   PRO A   8 "
      pdb=" CA  PRO A   8 "
      pdb=" CB  PRO A   8 "
    ideal   model   delta    sigma   weight residual
   112.26  111.64    0.62 1.67e+00 3.59e-01 1.37e-01
angle pdb=" CE1 TYR A  41 "
      pdb=" CZ  TYR A  41 "
      pdb=" CE2 TYR A  41 "
    ideal   model   delta    sigma   weight residual
   120.30  121.04   -0.74 2.00e+00 2.50e-01 1.36e-01
angle pdb=" N   ASN A  29 "
      pdb=" CA  ASN A  29 "
      pdb=" CB  ASN A  29 "
    ideal   model   delta    sigma   weight residual
   110.43  111.03   -0.60 1.63e+00 3.76e-01 1.36e-01
angle pdb=" CA  TYR A  56 "
      pdb=" CB  TYR A  56 "
      pdb=" CG  TYR A  56 "
    ideal   model   delta    sigma   weight residual
   113.90  114.56   -0.66 1.80e+00 3.09e-01 1.32e-01
angle pdb=" C   PRO A  42 "
      pdb=" CA  PRO A  42 "
      pdb=" CB  PRO A  42 "
    ideal   model   delta    sigma   weight residual
   111.12  111.59   -0.47 1.29e+00 6.01e-01 1.32e-01
angle pdb=" CA  ASN A  29 "
      pdb=" C   ASN A  29 "
      pdb=" N   GLU A  30 "
    ideal   model   delta    sigma   weight residual
   116.25  116.70   -0.45 1.23e+00 6.61e-01 1.32e-01
angle pdb=" C   LYS A  24 "
      pdb=" N   PRO A  25 "
      pdb=" CD  PRO A  25 "
    ideal   model   delta    sigma   weight residual
   125.00  126.48   -1.48 4.10e+00 5.95e-02 1.31e-01
angle pdb=" C   ASP A  36 "
      pdb=" CA  ASP A  36 "
      pdb=" CB  ASP A  36 "
    ideal   model   delta    sigma   weight residual
   110.81  111.41   -0.60 1.65e+00 3.67e-01 1.30e-01
angle pdb=" CA  PRO A  42 "
      pdb=" C   PRO A  42 "
      pdb=" O   PRO A  42 "
    ideal   model   delta    sigma   weight residual
   121.95  122.40   -0.45 1.25e+00 6.40e-01 1.30e-01
angle pdb=" CA  GLN A  31 "
      pdb=" CB  GLN A  31 "
      pdb=" CG  GLN A  31 "
    ideal   model   delta    sigma   weight residual
   114.10  114.82   -0.72 2.00e+00 2.50e-01 1.29e-01
angle pdb=" C   THR A  62 "
      pdb=" N   VAL A  63 "
      pdb=" CA  VAL A  63 "
    ideal   model   delta    sigma   weight residual
   122.37  121.91    0.46 1.29e+00 6.01e-01 1.27e-01
angle pdb=" O   VAL A   4 "
      pdb=" C   VAL A   4 "
      pdb=" N   GLU A   5 "
    ideal   model   delta    sigma   weight residual
   123.18  122.80    0.38 1.08e+00 8.57e-01 1.27e-01
angle pdb=" C   VAL A  63 "
      pdb=" CA  VAL A  63 "
      pdb=" CB  VAL A  63 "
    ideal   model   delta    sigma   weight residual
   110.91  111.35   -0.44 1.24e+00 6.50e-01 1.27e-01
angle pdb=" CA  LYS A   7 "
      pdb=" CB  LYS A   7 "
      pdb=" CG  LYS A   7 "
    ideal   model   delta    sigma   weight residual
   114.10  114.81   -0.71 2.00e+00 2.50e-01 1.26e-01
angle pdb=" N   ALA A  11 "
      pdb=" CA  ALA A  11 "
      pdb=" CB  ALA A  11 "
    ideal   model   delta    sigma   weight residual
   110.42  109.85    0.57 1.62e+00 3.81e-01 1.25e-01
angle pdb=" C   LYS A   7 "
      pdb=" N   PRO A   8 "
      pdb=" CA  PRO A   8 "
    ideal   model   delta    sigma   weight residual
   119.47  119.88   -0.41 1.16e+00 7.43e-01 1.23e-01
angle pdb=" CA  VAL A  63 "
      pdb=" CB  VAL A  63 "
      pdb=" CG2 VAL A  63 "
    ideal   model   delta    sigma   weight residual
   110.40  109.81    0.59 1.70e+00 3.46e-01 1.22e-01
angle pdb=" CA  SER A  20 "
      pdb=" C   SER A  20 "
      pdb=" O   SER A  20 "
    ideal   model   delta    sigma   weight residual
   121.88  122.27   -0.39 1.13e+00 7.83e-01 1.21e-01
angle pdb=" CB  LYS A   3 "
      pdb=" CG  LYS A   3 "
      pdb=" CD  LYS A   3 "
    ideal   model   delta    sigma   weight residual
   111.30  112.10   -0.80 2.30e+00 1.89e-01 1.20e-01
angle pdb=" O   TYR A  41 "
      pdb=" C   TYR A  41 "
      pdb=" N   PRO A  42 "
    ideal   model   delta    sigma   weight residual
   121.80  122.10   -0.30 8.60e-01 1.35e+00 1.20e-01
angle pdb=" N   ILE A   2 "
      pdb=" CA  ILE A   2 "
      pdb=" CB  ILE A   2 "
    ideal   model   delta    sigma   weight residual
   111.50  110.91    0.59 1.70e+00 3.46e-01 1.19e-01
angle pdb=" N   PRO A   8 "
      pdb=" CA  PRO A   8 "
      pdb=" CB  PRO A   8 "
    ideal   model   delta    sigma   weight residual
   103.30  102.91    0.39 1.12e+00 7.97e-01 1.19e-01
angle pdb=" CA  SER A  20 "
      pdb=" CB  SER A  20 "
      pdb=" OG  SER A  20 "
    ideal   model   delta    sigma   weight residual
   111.10  111.79   -0.69 2.00e+00 2.50e-01 1.18e-01
angle pdb=" CG  GLU A   5 "
      pdb=" CD  GLU A   5 "
      pdb=" OE1 GLU A   5 "
    ideal   model   delta    sigma   weight residual
   118.40  119.19   -0.79 2.30e+00 1.89e-01 1.18e-01
angle pdb=" C   ALA A  11 "
      pdb=" CA  ALA A  11 "
      pdb=" CB  ALA A  11 "
    ideal   model   delta    sigma   weight residual
   110.11  109.46    0.65 1.90e+00 2.77e-01 1.16e-01
angle pdb=" CA  THR A  62 "
      pdb=" C   THR A  62 "
      pdb=" O   THR A  62 "
    ideal   model   delta    sigma   weight residual
   121.58  121.19    0.39 1.16e+00 7.43e-01 1.15e-01
angle pdb=" C   LEU A  60 "
      pdb=" N   TYR A  61 "
      pdb=" CA  TYR A  61 "
    ideal   model   delta    sigma   weight residual
   122.82  123.39   -0.57 1.68e+00 3.54e-01 1.15e-01
angle pdb=" CA  VAL A  45 "
      pdb=" C   VAL A  45 "
      pdb=" N   LYS A  46 "
    ideal   model   delta    sigma   weight residual
   116.11  116.54   -0.43 1.29e+00 6.01e-01 1.13e-01
angle pdb=" C   ALA A  11 "
      pdb=" N   GLN A  12 "
      pdb=" CA  GLN A  12 "
    ideal   model   delta    sigma   weight residual
   123.05  122.45    0.60 1.79e+00 3.12e-01 1.13e-01
angle pdb=" C   VAL A  19 "
      pdb=" CA  VAL A  19 "
      pdb=" CB  VAL A  19 "
    ideal   model   delta    sigma   weight residual
   110.50  111.02   -0.52 1.54e+00 4.22e-01 1.12e-01
angle pdb=" CB  LYS A  46 "
      pdb=" CG  LYS A  46 "
      pdb=" CD  LYS A  46 "
    ideal   model   delta    sigma   weight residual
   111.30  110.53    0.77 2.30e+00 1.89e-01 1.11e-01
angle pdb=" N   THR A  48 "
      pdb=" CA  THR A  48 "
      pdb=" CB  THR A  48 "
    ideal   model   delta    sigma   weight residual
   110.37  110.91   -0.54 1.65e+00 3.67e-01 1.09e-01
angle pdb=" O   THR A  62 "
      pdb=" C   THR A  62 "
      pdb=" N   VAL A  63 "
    ideal   model   delta    sigma   weight residual
   122.94  122.49    0.45 1.37e+00 5.33e-01 1.08e-01
angle pdb=" CB  LEU A  81 "
      pdb=" CG  LEU A  81 "
      pdb=" CD1 LEU A  81 "
    ideal   model   delta    sigma   weight residual
   110.70  109.71    0.99 3.00e+00 1.11e-01 1.08e-01
angle pdb=" C   GLY A  23 "
      pdb=" N   LYS A  24 "
      pdb=" CA  LYS A  24 "
    ideal   model   delta    sigma   weight residual
   120.49  120.96   -0.47 1.42e+00 4.96e-01 1.08e-01
angle pdb=" C   TYR A  61 "
      pdb=" N   THR A  62 "
      pdb=" CA  THR A  62 "
    ideal   model   delta    sigma   weight residual
   122.82  123.37   -0.55 1.68e+00 3.54e-01 1.06e-01
angle pdb=" CB  GLU A  51 "
      pdb=" CG  GLU A  51 "
      pdb=" CD  GLU A  51 "
    ideal   model   delta    sigma   weight residual
   112.60  112.05    0.55 1.70e+00 3.46e-01 1.05e-01
angle pdb=" N   THR A  15 "
      pdb=" CA  THR A  15 "
      pdb=" CB  THR A  15 "
    ideal   model   delta    sigma   weight residual
   110.55  111.06   -0.51 1.57e+00 4.06e-01 1.05e-01
angle pdb=" CA  GLN A  72 "
      pdb=" C   GLN A  72 "
      pdb=" N   PHE A  73 "
    ideal   model   delta    sigma   weight residual
   118.43  118.86   -0.43 1.33e+00 5.65e-01 1.04e-01
angle pdb=" CG  ARG A  80 "
      pdb=" CD  ARG A  80 "
      pdb=" NE  ARG A  80 "
    ideal   model   delta    sigma   weight residual
   112.00  111.29    0.71 2.20e+00 2.07e-01 1.04e-01
angle pdb=" C   ARG A  16 "
      pdb=" N   SER A  17 "
      pdb=" CA  SER A  17 "
    ideal   model   delta    sigma   weight residual
   122.92  122.35    0.57 1.76e+00 3.23e-01 1.03e-01
angle pdb=" CA  LEU A  83 "
      pdb=" C   LEU A  83 "
      pdb=" O   LEU A  83 "
    ideal   model   delta    sigma   weight residual
   121.28  121.66   -0.38 1.18e+00 7.18e-01 1.02e-01
angle pdb=" CA  VAL A  19 "
      pdb=" C   VAL A  19 "
      pdb=" O   VAL A  19 "
    ideal   model   delta    sigma   weight residual
   120.67  121.03   -0.36 1.12e+00 7.97e-01 1.01e-01
angle pdb=" CA  VAL A   4 "
      pdb=" CB  VAL A   4 "
      pdb=" CG1 VAL A   4 "
    ideal   model   delta    sigma   weight residual
   110.40  110.93   -0.53 1.70e+00 3.46e-01 9.75e-02
angle pdb=" C   ILE A   2 "
      pdb=" CA  ILE A   2 "
      pdb=" CB  ILE A   2 "
    ideal   model   delta    sigma   weight residual
   111.60  110.98    0.62 2.00e+00 2.50e-01 9.71e-02
angle pdb=" CA  ALA A  57 "
      pdb=" C   ALA A  57 "
      pdb=" N   PRO A  58 "
    ideal   model   delta    sigma   weight residual
   117.44  117.79   -0.35 1.13e+00 7.83e-01 9.59e-02
angle pdb=" CB  GLU A  40 "
      pdb=" CG  GLU A  40 "
      pdb=" CD  GLU A  40 "
    ideal   model   delta    sigma   weight residual
   112.60  113.13   -0.53 1.70e+00 3.46e-01 9.55e-02
angle pdb=" CA  LEU A  83 "
      pdb=" C   LEU A  83 "
      pdb=" N   VAL A  84 "
    ideal   model   delta    sigma   weight residual
   115.55  115.14    0.41 1.33e+00 5.65e-01 9.54e-02
angle pdb=" C   THR A  14 "
      pdb=" CA  THR A  14 "
      pdb=" CB  THR A  14 "
    ideal   model   delta    sigma   weight residual
   109.37  109.93   -0.56 1.83e+00 2.99e-01 9.46e-02
angle pdb=" C   ARG A  82 "
      pdb=" N   LEU A  83 "
      pdb=" CA  LEU A  83 "
    ideal   model   delta    sigma   weight residual
   122.64  122.12    0.52 1.70e+00 3.46e-01 9.28e-02
angle pdb=" CB  LEU A  32 "
      pdb=" CG  LEU A  32 "
      pdb=" CD2 LEU A  32 "
    ideal   model   delta    sigma   weight residual
   110.70  111.61   -0.91 3.00e+00 1.11e-01 9.21e-02
angle pdb=" C   VAL A   4 "
      pdb=" CA  VAL A   4 "
      pdb=" CB  VAL A   4 "
    ideal   model   delta    sigma   weight residual
   110.62  111.07   -0.45 1.49e+00 4.50e-01 9.13e-02
angle pdb=" CG1 VAL A  19 "
      pdb=" CB  VAL A  19 "
      pdb=" CG2 VAL A  19 "
    ideal   model   delta    sigma   weight residual
   110.80  110.14    0.66 2.20e+00 2.07e-01 9.07e-02
angle pdb=" C   SER A  66 "
      pdb=" CA  SER A  66 "
      pdb=" CB  SER A  66 "
    ideal   model   delta    sigma   weight residual
   110.27  109.69    0.58 1.94e+00 2.66e-01 9.00e-02
angle pdb=" C   SER A  67 "
      pdb=" N   PHE A  68 "
      pdb=" CA  PHE A  68 "
    ideal   model   delta    sigma   weight residual
   122.87  122.39    0.48 1.61e+00 3.86e-01 8.97e-02
angle pdb=" N   ILE A  47 "
      pdb=" CA  ILE A  47 "
      pdb=" C   ILE A  47 "
    ideal   model   delta    sigma   weight residual
   108.48  108.91   -0.43 1.44e+00 4.82e-01 8.94e-02
angle pdb=" CA  SER A  27 "
      pdb=" C   SER A  27 "
      pdb=" O   SER A  27 "
    ideal   model   delta    sigma   weight residual
   120.28  120.65   -0.37 1.23e+00 6.61e-01 8.92e-02
angle pdb=" N   TYR A  41 "
      pdb=" CA  TYR A  41 "
      pdb=" C   TYR A  41 "
    ideal   model   delta    sigma   weight residual
   109.58  110.07   -0.49 1.63e+00 3.76e-01 8.91e-02
angle pdb=" N   GLY A  52 "
      pdb=" CA  GLY A  52 "
      pdb=" C   GLY A  52 "
    ideal   model   delta    sigma   weight residual
   114.67  115.09   -0.42 1.41e+00 5.03e-01 8.85e-02
angle pdb=" C   THR A  48 "
      pdb=" N   LEU A  49 "
      pdb=" CA  LEU A  49 "
    ideal   model   delta    sigma   weight residual
   120.94  121.41   -0.47 1.57e+00 4.06e-01 8.82e-02
angle pdb=" C   HIS A  64 "
      pdb=" CA  HIS A  64 "
      pdb=" CB  HIS A  64 "
    ideal   model   delta    sigma   weight residual
   109.46  110.01   -0.55 1.84e+00 2.95e-01 8.80e-02
angle pdb=" C   THR A  48 "
      pdb=" CA  THR A  48 "
      pdb=" CB  THR A  48 "
    ideal   model   delta    sigma   weight residual
   110.78  111.25   -0.47 1.60e+00 3.91e-01 8.71e-02
angle pdb=" N   LEU A  65 "
      pdb=" CA  LEU A  65 "
      pdb=" C   LEU A  65 "
    ideal   model   delta    sigma   weight residual
   111.71  112.05   -0.34 1.15e+00 7.56e-01 8.68e-02
angle pdb=" N   VAL A   4 "
      pdb=" CA  VAL A   4 "
      pdb=" C   VAL A   4 "
    ideal   model   delta    sigma   weight residual
   108.48  108.06    0.42 1.44e+00 4.82e-01 8.68e-02
angle pdb=" N   LYS A   7 "
      pdb=" CA  LYS A   7 "
      pdb=" C   LYS A   7 "
    ideal   model   delta    sigma   weight residual
   110.20  110.62   -0.42 1.44e+00 4.82e-01 8.66e-02
angle pdb=" C   TYR A  41 "
      pdb=" CA  TYR A  41 "
      pdb=" CB  TYR A  41 "
    ideal   model   delta    sigma   weight residual
   108.87  108.42    0.45 1.55e+00 4.16e-01 8.56e-02
angle pdb=" O   LEU A  44 "
      pdb=" C   LEU A  44 "
      pdb=" N   VAL A  45 "
    ideal   model   delta    sigma   weight residual
   123.02  123.38   -0.36 1.23e+00 6.61e-01 8.47e-02
angle pdb=" N   ILE A   6 "
      pdb=" CA  ILE A   6 "
      pdb=" C   ILE A   6 "
    ideal   model   delta    sigma   weight residual
   107.51  107.08    0.43 1.49e+00 4.50e-01 8.45e-02
angle pdb=" CA  VAL A  84 "
      pdb=" C   VAL A  84 "
      pdb=" N   PRO A  85 "
    ideal   model   delta    sigma   weight residual
   118.88  119.33   -0.45 1.54e+00 4.22e-01 8.43e-02
angle pdb=" CA  VAL A  45 "
      pdb=" C   VAL A  45 "
      pdb=" O   VAL A  45 "
    ideal   model   delta    sigma   weight residual
   120.67  121.01   -0.34 1.17e+00 7.31e-01 8.27e-02
angle pdb=" CB  ASP A  79 "
      pdb=" CG  ASP A  79 "
      pdb=" OD1 ASP A  79 "
    ideal   model   delta    sigma   weight residual
   118.40  119.06   -0.66 2.30e+00 1.89e-01 8.22e-02
angle pdb=" CD1 LEU A  44 "
      pdb=" CG  LEU A  44 "
      pdb=" CD2 LEU A  44 "
    ideal   model   delta    sigma   weight residual
   110.80  110.17    0.63 2.20e+00 2.07e-01 8.19e-02
angle pdb=" CA  GLN A  31 "
      pdb=" C   GLN A  31 "
      pdb=" O   GLN A  31 "
    ideal   model   delta    sigma   weight residual
   121.11  120.78    0.33 1.17e+00 7.31e-01 8.16e-02
angle pdb=" N   ILE A  78 "
      pdb=" CA  ILE A  78 "
      pdb=" C   ILE A  78 "
    ideal   model   delta    sigma   weight residual
   107.80  108.21   -0.41 1.45e+00 4.76e-01 8.10e-02
angle pdb=" N   PRO A  42 "
      pdb=" CD  PRO A  42 "
      pdb=" CG  PRO A  42 "
    ideal   model   delta    sigma   weight residual
   103.20  102.77    0.43 1.50e+00 4.44e-01 8.03e-02
angle pdb=" CA  VAL A  84 "
      pdb=" C   VAL A  84 "
      pdb=" O   VAL A  84 "
    ideal   model   delta    sigma   weight residual
   119.95  119.57    0.38 1.34e+00 5.57e-01 8.02e-02
angle pdb=" N   LEU A  32 "
      pdb=" CA  LEU A  32 "
      pdb=" C   LEU A  32 "
    ideal   model   delta    sigma   weight residual
   110.42  110.86   -0.44 1.55e+00 4.16e-01 7.88e-02
angle pdb=" CA  ASN A  39 "
      pdb=" C   ASN A  39 "
      pdb=" N   GLU A  40 "
    ideal   model   delta    sigma   weight residual
   116.58  117.01   -0.43 1.55e+00 4.16e-01 7.85e-02
angle pdb=" N   PRO A  58 "
      pdb=" CA  PRO A  58 "
      pdb=" C   PRO A  58 "
    ideal   model   delta    sigma   weight residual
   111.14  111.58   -0.44 1.56e+00 4.11e-01 7.79e-02
angle pdb=" C   VAL A  84 "
      pdb=" N   PRO A  85 "
      pdb=" CD  PRO A  85 "
    ideal   model   delta    sigma   weight residual
   125.00  123.86    1.14 4.10e+00 5.95e-02 7.75e-02
angle pdb=" CA  ALA A  11 "
      pdb=" C   ALA A  11 "
      pdb=" O   ALA A  11 "
    ideal   model   delta    sigma   weight residual
   119.12  118.76    0.36 1.31e+00 5.83e-01 7.75e-02
angle pdb=" CB  TYR A  26 "
      pdb=" CG  TYR A  26 "
      pdb=" CD1 TYR A  26 "
    ideal   model   delta    sigma   weight residual
   120.80  121.21   -0.41 1.50e+00 4.44e-01 7.58e-02
angle pdb=" CA  PRO A  85 "
      pdb=" CB  PRO A  85 "
      pdb=" CG  PRO A  85 "
    ideal   model   delta    sigma   weight residual
   104.50  103.98    0.52 1.90e+00 2.77e-01 7.56e-02
angle pdb=" C   LEU A  37 "
      pdb=" N   GLY A  38 "
      pdb=" CA  GLY A  38 "
    ideal   model   delta    sigma   weight residual
   121.53  120.99    0.54 1.97e+00 2.58e-01 7.55e-02
angle pdb=" CA  PRO A  54 "
      pdb=" C   PRO A  54 "
      pdb=" N   ALA A  55 "
    ideal   model   delta    sigma   weight residual
   114.75  115.15   -0.40 1.45e+00 4.76e-01 7.47e-02
angle pdb=" N   ASN A  39 "
      pdb=" CA  ASN A  39 "
      pdb=" C   ASN A  39 "
    ideal   model   delta    sigma   weight residual
   109.86  110.28   -0.42 1.55e+00 4.16e-01 7.40e-02
angle pdb=" O   ILE A   2 "
      pdb=" C   ILE A   2 "
      pdb=" N   LYS A   3 "
    ideal   model   delta    sigma   weight residual
   123.00  122.57    0.43 1.60e+00 3.91e-01 7.34e-02
angle pdb=" CD1 TYR A  41 "
      pdb=" CG  TYR A  41 "
      pdb=" CD2 TYR A  41 "
    ideal   model   delta    sigma   weight residual
   118.10  118.51   -0.41 1.50e+00 4.44e-01 7.32e-02
angle pdb=" CG1 VAL A  63 "
      pdb=" CB  VAL A  63 "
      pdb=" CG2 VAL A  63 "
    ideal   model   delta    sigma   weight residual
   110.80  110.21    0.59 2.20e+00 2.07e-01 7.21e-02
angle pdb=" C   LYS A   3 "
      pdb=" N   VAL A   4 "
      pdb=" CA  VAL A   4 "
    ideal   model   delta    sigma   weight residual
   123.06  123.43   -0.37 1.38e+00 5.25e-01 7.18e-02
angle pdb=" N   LEU A  49 "
      pdb=" CA  LEU A  49 "
      pdb=" C   LEU A  49 "
    ideal   model   delta    sigma   weight residual
   110.50  110.88   -0.38 1.41e+00 5.03e-01 7.12e-02
angle pdb=" C   ASP A  79 "
      pdb=" CA  ASP A  79 "
      pdb=" CB  ASP A  79 "
    ideal   model   delta    sigma   weight residual
   110.42  110.95   -0.53 1.99e+00 2.53e-01 7.09e-02
angle pdb=" CB  LEU A  65 "
      pdb=" CG  LEU A  65 "
      pdb=" CD2 LEU A  65 "
    ideal   model   delta    sigma   weight residual
   110.70  109.91    0.79 3.00e+00 1.11e-01 7.01e-02
angle pdb=" CD1 TYR A  41 "
      pdb=" CE1 TYR A  41 "
      pdb=" CZ  TYR A  41 "
    ideal   model   delta    sigma   weight residual
   119.60  119.14    0.46 1.80e+00 3.09e-01 6.66e-02
angle pdb=" C   GLY A  59 "
      pdb=" N   LEU A  60 "
      pdb=" CA  LEU A  60 "
    ideal   model   delta    sigma   weight residual
   123.00  123.36   -0.36 1.38e+00 5.25e-01 6.63e-02
angle pdb=" CG1 VAL A  84 "
      pdb=" CB  VAL A  84 "
      pdb=" CG2 VAL A  84 "
    ideal   model   delta    sigma   weight residual
   110.80  111.36   -0.56 2.20e+00 2.07e-01 6.55e-02
angle pdb=" C   THR A  14 "
      pdb=" N   THR A  15 "
      pdb=" CA  THR A  15 "
    ideal   model   delta    sigma   weight residual
   123.05  122.69    0.36 1.40e+00 5.10e-01 6.54e-02
angle pdb=" N   SER A  66 "
      pdb=" CA  SER A  66 "
      pdb=" C   SER A  66 "
    ideal   model   delta    sigma   weight residual
   113.19  112.89    0.30 1.19e+00 7.06e-01 6.52e-02
angle pdb=" CA  GLY A  71 "
      pdb=" C   GLY A  71 "
      pdb=" N   GLN A  72 "
    ideal   model   delta    sigma   weight residual
   114.62  114.27    0.35 1.38e+00 5.25e-01 6.43e-02
angle pdb=" CB  LEU A  37 "
      pdb=" CG  LEU A  37 "
      pdb=" CD2 LEU A  37 "
    ideal   model   delta    sigma   weight residual
   110.70  111.46   -0.76 3.00e+00 1.11e-01 6.39e-02
angle pdb=" N   PRO A   8 "
      pdb=" CA  PRO A   8 "
      pdb=" C   PRO A   8 "
    ideal   model   delta    sigma   weight residual
   113.81  113.44    0.37 1.45e+00 4.76e-01 6.37e-02
angle pdb=" N   ALA A  55 "
      pdb=" CA  ALA A  55 "
      pdb=" C   ALA A  55 "
    ideal   model   delta    sigma   weight residual
   110.28  109.91    0.37 1.48e+00 4.57e-01 6.35e-02
angle pdb=" CB  LEU A  44 "
      pdb=" CG  LEU A  44 "
      pdb=" CD1 LEU A  44 "
    ideal   model   delta    sigma   weight residual
   110.70  109.95    0.75 3.00e+00 1.11e-01 6.32e-02
angle pdb=" N   GLN A  31 "
      pdb=" CA  GLN A  31 "
      pdb=" C   GLN A  31 "
    ideal   model   delta    sigma   weight residual
   109.50  109.10    0.40 1.58e+00 4.01e-01 6.32e-02
angle pdb=" CA  PRO A  85 "
      pdb=" N   PRO A  85 "
      pdb=" CD  PRO A  85 "
    ideal   model   delta    sigma   weight residual
   112.00  111.65    0.35 1.40e+00 5.10e-01 6.28e-02
angle pdb=" C   GLY A  74 "
      pdb=" N   SER A  75 "
      pdb=" CA  SER A  75 "
    ideal   model   delta    sigma   weight residual
   122.07  121.57    0.50 2.01e+00 2.48e-01 6.27e-02
angle pdb=" C   GLU A  40 "
      pdb=" CA  GLU A  40 "
      pdb=" CB  GLU A  40 "
    ideal   model   delta    sigma   weight residual
   110.79  110.37    0.42 1.66e+00 3.63e-01 6.26e-02
angle pdb=" C   GLU A   5 "
      pdb=" CA  GLU A   5 "
      pdb=" CB  GLU A   5 "
    ideal   model   delta    sigma   weight residual
   109.35  109.84   -0.49 1.98e+00 2.55e-01 6.01e-02
angle pdb=" N   GLY A  38 "
      pdb=" CA  GLY A  38 "
      pdb=" C   GLY A  38 "
    ideal   model   delta    sigma   weight residual
   115.30  115.64   -0.34 1.39e+00 5.18e-01 5.92e-02
angle pdb=" CB  ASN A  29 "
      pdb=" CG  ASN A  29 "
      pdb=" ND2 ASN A  29 "
    ideal   model   delta    sigma   weight residual
   116.40  116.76   -0.36 1.50e+00 4.44e-01 5.91e-02
angle pdb=" CA  LEU A  49 "
      pdb=" CB  LEU A  49 "
      pdb=" CG  LEU A  49 "
    ideal   model   delta    sigma   weight residual
   116.30  117.15   -0.85 3.50e+00 8.16e-02 5.91e-02
angle pdb=" CG  TYR A  41 "
      pdb=" CD1 TYR A  41 "
      pdb=" CE1 TYR A  41 "
    ideal   model   delta    sigma   weight residual
   121.20  120.84    0.36 1.50e+00 4.44e-01 5.89e-02
angle pdb=" CA  GLY A  71 "
      pdb=" C   GLY A  71 "
      pdb=" O   GLY A  71 "
    ideal   model   delta    sigma   weight residual
   122.75  123.06   -0.31 1.27e+00 6.20e-01 5.82e-02
angle pdb=" CA  ILE A  47 "
      pdb=" C   ILE A  47 "
      pdb=" O   ILE A  47 "
    ideal   model   delta    sigma   weight residual
   120.67  120.95   -0.28 1.17e+00 7.31e-01 5.76e-02
angle pdb=" C   LEU A  60 "
      pdb=" CA  LEU A  60 "
      pdb=" CB  LEU A  60 "
    ideal   model   delta    sigma   weight residual
   109.72  110.13   -0.41 1.73e+00 3.34e-01 5.75e-02
angle pdb=" CA  VAL A  43 "
      pdb=" C   VAL A  43 "
      pdb=" N   LEU A  44 "
    ideal   model   delta    sigma   weight residual
   115.58  115.25    0.33 1.36e+00 5.41e-01 5.75e-02
angle pdb=" C   VAL A  70 "
      pdb=" CA  VAL A  70 "
      pdb=" CB  VAL A  70 "
    ideal   model   delta    sigma   weight residual
   110.96  111.25   -0.29 1.21e+00 6.83e-01 5.73e-02
angle pdb=" CA  ASP A  79 "
      pdb=" CB  ASP A  79 "
      pdb=" CG  ASP A  79 "
    ideal   model   delta    sigma   weight residual
   112.60  112.84   -0.24 1.00e+00 1.00e+00 5.71e-02
angle pdb=" CA  LEU A  60 "
      pdb=" C   LEU A  60 "
      pdb=" N   TYR A  61 "
    ideal   model   delta    sigma   weight residual
   116.28  115.98    0.30 1.26e+00 6.30e-01 5.68e-02
angle pdb=" C   GLN A  22 "
      pdb=" CA  GLN A  22 "
      pdb=" CB  GLN A  22 "
    ideal   model   delta    sigma   weight residual
   110.81  110.40    0.41 1.73e+00 3.34e-01 5.64e-02
angle pdb=" CA  GLN A  22 "
      pdb=" CB  GLN A  22 "
      pdb=" CG  GLN A  22 "
    ideal   model   delta    sigma   weight residual
   114.10  114.57   -0.47 2.00e+00 2.50e-01 5.53e-02
angle pdb=" N   GLN A  31 "
      pdb=" CA  GLN A  31 "
      pdb=" CB  GLN A  31 "
    ideal   model   delta    sigma   weight residual
   111.37  110.94    0.43 1.82e+00 3.02e-01 5.51e-02
angle pdb=" CA  ILE A   2 "
      pdb=" C   ILE A   2 "
      pdb=" O   ILE A   2 "
    ideal   model   delta    sigma   weight residual
   120.80  121.20   -0.40 1.70e+00 3.46e-01 5.48e-02
angle pdb=" O   GLN A  72 "
      pdb=" C   GLN A  72 "
      pdb=" N   PHE A  73 "
    ideal   model   delta    sigma   weight residual
   122.46  122.14    0.32 1.38e+00 5.25e-01 5.42e-02
angle pdb=" O   SER A   9 "
      pdb=" C   SER A   9 "
      pdb=" N   GLN A  10 "
    ideal   model   delta    sigma   weight residual
   122.39  122.73   -0.34 1.48e+00 4.57e-01 5.37e-02
angle pdb=" N   PHE A  73 "
      pdb=" CA  PHE A  73 "
      pdb=" CB  PHE A  73 "
    ideal   model   delta    sigma   weight residual
   110.73  110.37    0.36 1.55e+00 4.16e-01 5.36e-02
angle pdb=" C   LYS A   7 "
      pdb=" CA  LYS A   7 "
      pdb=" CB  LYS A   7 "
    ideal   model   delta    sigma   weight residual
   109.51  109.08    0.43 1.85e+00 2.92e-01 5.33e-02
angle pdb=" CA  GLY A  74 "
      pdb=" C   GLY A  74 "
      pdb=" N   SER A  75 "
    ideal   model   delta    sigma   weight residual
   118.46  118.74   -0.28 1.21e+00 6.83e-01 5.26e-02
angle pdb=" CA  ALA A  55 "
      pdb=" C   ALA A  55 "
      pdb=" O   ALA A  55 "
    ideal   model   delta    sigma   weight residual
   121.16  121.42   -0.26 1.12e+00 7.97e-01 5.20e-02
angle pdb=" CB  LEU A  32 "
      pdb=" CG  LEU A  32 "
      pdb=" CD1 LEU A  32 "
    ideal   model   delta    sigma   weight residual
   110.70  111.38   -0.68 3.00e+00 1.11e-01 5.19e-02
angle pdb=" C   SER A  66 "
      pdb=" N   SER A  67 "
      pdb=" CA  SER A  67 "
    ideal   model   delta    sigma   weight residual
   120.72  121.10   -0.38 1.67e+00 3.59e-01 5.18e-02
angle pdb=" C   PRO A  54 "
      pdb=" CA  PRO A  54 "
      pdb=" CB  PRO A  54 "
    ideal   model   delta    sigma   weight residual
   111.22  111.56   -0.34 1.51e+00 4.39e-01 5.17e-02
angle pdb=" CA  ASP A  50 "
      pdb=" C   ASP A  50 "
      pdb=" N   GLU A  51 "
    ideal   model   delta    sigma   weight residual
   115.27  115.57   -0.30 1.34e+00 5.57e-01 5.15e-02
angle pdb=" N   SER A  17 "
      pdb=" CA  SER A  17 "
      pdb=" C   SER A  17 "
    ideal   model   delta    sigma   weight residual
   110.14  109.79    0.35 1.55e+00 4.16e-01 5.13e-02
angle pdb=" CA  ILE A  47 "
      pdb=" C   ILE A  47 "
      pdb=" N   THR A  48 "
    ideal   model   delta    sigma   weight residual
   116.11  115.82    0.29 1.29e+00 6.01e-01 5.12e-02
angle pdb=" N   GLN A  22 "
      pdb=" CA  GLN A  22 "
      pdb=" CB  GLN A  22 "
    ideal   model   delta    sigma   weight residual
   110.56  110.25    0.31 1.38e+00 5.25e-01 5.05e-02
angle pdb=" C   PHE A  13 "
      pdb=" CA  PHE A  13 "
      pdb=" CB  PHE A  13 "
    ideal   model   delta    sigma   weight residual
   109.33  109.77   -0.44 1.97e+00 2.58e-01 5.04e-02
angle pdb=" N   LEU A  76 "
      pdb=" CA  LEU A  76 "
      pdb=" C   LEU A  76 "
    ideal   model   delta    sigma   weight residual
   110.28  110.61   -0.33 1.48e+00 4.57e-01 5.04e-02
angle pdb=" N   ILE A  78 "
      pdb=" CA  ILE A  78 "
      pdb=" CB  ILE A  78 "
    ideal   model   delta    sigma   weight residual
   111.46  111.74   -0.28 1.26e+00 6.30e-01 4.97e-02
angle pdb=" N   VAL A  43 "
      pdb=" CA  VAL A  43 "
      pdb=" C   VAL A  43 "
    ideal   model   delta    sigma   weight residual
   108.89  108.55    0.34 1.52e+00 4.33e-01 4.94e-02
angle pdb=" C   CYS A  33 "
      pdb=" CA  CYS A  33 "
      pdb=" CB  CYS A  33 "
    ideal   model   delta    sigma   weight residual
   111.17  110.74    0.43 1.96e+00 2.60e-01 4.92e-02
angle pdb=" CG  ARG A  21 "
      pdb=" CD  ARG A  21 "
      pdb=" NE  ARG A  21 "
    ideal   model   delta    sigma   weight residual
   112.00  111.52    0.48 2.20e+00 2.07e-01 4.85e-02
angle pdb=" CA  PRO A   8 "
      pdb=" CB  PRO A   8 "
      pdb=" CG  PRO A   8 "
    ideal   model   delta    sigma   weight residual
   104.50  104.08    0.42 1.90e+00 2.77e-01 4.85e-02
angle pdb=" CA  LYS A  69 "
      pdb=" C   LYS A  69 "
      pdb=" N   VAL A  70 "
    ideal   model   delta    sigma   weight residual
   115.38  115.70   -0.32 1.45e+00 4.76e-01 4.80e-02
angle pdb=" CA  VAL A  19 "
      pdb=" CB  VAL A  19 "
      pdb=" CG2 VAL A  19 "
    ideal   model   delta    sigma   weight residual
   110.40  110.77   -0.37 1.70e+00 3.46e-01 4.67e-02
angle pdb=" CA  ASP A  36 "
      pdb=" C   ASP A  36 "
      pdb=" N   LEU A  37 "
    ideal   model   delta    sigma   weight residual
   116.43  116.70   -0.27 1.27e+00 6.20e-01 4.64e-02
angle pdb=" N   GLU A  40 "
      pdb=" CA  GLU A  40 "
      pdb=" C   GLU A  40 "
    ideal   model   delta    sigma   weight residual
   111.28  111.05    0.23 1.09e+00 8.42e-01 4.64e-02
angle pdb=" N   SER A   9 "
      pdb=" CA  SER A   9 "
      pdb=" CB  SER A   9 "
    ideal   model   delta    sigma   weight residual
   110.42  110.07    0.35 1.62e+00 3.81e-01 4.63e-02
angle pdb=" C   ILE A  47 "
      pdb=" CA  ILE A  47 "
      pdb=" CB  ILE A  47 "
    ideal   model   delta    sigma   weight residual
   110.62  110.94   -0.32 1.49e+00 4.50e-01 4.61e-02
angle pdb=" CB  ASP A  50 "
      pdb=" CG  ASP A  50 "
      pdb=" OD2 ASP A  50 "
    ideal   model   delta    sigma   weight residual
   118.40  117.91    0.49 2.30e+00 1.89e-01 4.56e-02
angle pdb=" CE1 TYR A  26 "
      pdb=" CZ  TYR A  26 "
      pdb=" OH  TYR A  26 "
    ideal   model   delta    sigma   weight residual
   119.90  119.26    0.64 3.00e+00 1.11e-01 4.54e-02
angle pdb=" CB  ARG A  80 "
      pdb=" CG  ARG A  80 "
      pdb=" CD  ARG A  80 "
    ideal   model   delta    sigma   weight residual
   111.30  111.79   -0.49 2.30e+00 1.89e-01 4.45e-02
angle pdb=" C   VAL A  35 "
      pdb=" CA  VAL A  35 "
      pdb=" CB  VAL A  35 "
    ideal   model   delta    sigma   weight residual
   110.83  111.14   -0.31 1.49e+00 4.50e-01 4.40e-02
angle pdb=" CD  LYS A  69 "
      pdb=" CE  LYS A  69 "
      pdb=" NZ  LYS A  69 "
    ideal   model   delta    sigma   weight residual
   111.90  112.57   -0.67 3.20e+00 9.77e-02 4.40e-02
angle pdb=" C   GLN A  12 "
      pdb=" N   PHE A  13 "
      pdb=" CA  PHE A  13 "
    ideal   model   delta    sigma   weight residual
   122.81  122.48    0.33 1.57e+00 4.06e-01 4.32e-02
angle pdb=" C   TYR A  56 "
      pdb=" N   ALA A  57 "
      pdb=" CA  ALA A  57 "
    ideal   model   delta    sigma   weight residual
   121.03  121.36   -0.33 1.60e+00 3.91e-01 4.26e-02
angle pdb=" CA  PRO A  54 "
      pdb=" C   PRO A  54 "
      pdb=" O   PRO A  54 "
    ideal   model   delta    sigma   weight residual
   122.31  122.02    0.29 1.41e+00 5.03e-01 4.25e-02
angle pdb=" OD1 ASP A  50 "
      pdb=" CG  ASP A  50 "
      pdb=" OD2 ASP A  50 "
    ideal   model   delta    sigma   weight residual
   122.90  123.39   -0.49 2.40e+00 1.74e-01 4.25e-02
angle pdb=" CA  ASP A  36 "
      pdb=" CB  ASP A  36 "
      pdb=" CG  ASP A  36 "
    ideal   model   delta    sigma   weight residual
   112.60  112.80   -0.20 1.00e+00 1.00e+00 4.20e-02
angle pdb=" CA  TYR A  61 "
      pdb=" C   TYR A  61 "
      pdb=" N   THR A  62 "
    ideal   model   delta    sigma   weight residual
   115.42  115.09    0.33 1.64e+00 3.72e-01 4.15e-02
angle pdb=" CA  TYR A  61 "
      pdb=" C   TYR A  61 "
      pdb=" O   TYR A  61 "
    ideal   model   delta    sigma   weight residual
   121.58  121.82   -0.24 1.16e+00 7.43e-01 4.12e-02
angle pdb=" CA  SER A   9 "
      pdb=" C   SER A   9 "
      pdb=" N   GLN A  10 "
    ideal   model   delta    sigma   weight residual
   118.44  118.15    0.29 1.41e+00 5.03e-01 4.11e-02
angle pdb=" CA  SER A  67 "
      pdb=" CB  SER A  67 "
      pdb=" OG  SER A  67 "
    ideal   model   delta    sigma   weight residual
   111.10  111.51   -0.41 2.00e+00 2.50e-01 4.11e-02
angle pdb=" CB  LEU A  49 "
      pdb=" CG  LEU A  49 "
      pdb=" CD2 LEU A  49 "
    ideal   model   delta    sigma   weight residual
   110.70  110.09    0.61 3.00e+00 1.11e-01 4.08e-02
angle pdb=" O   ASP A  79 "
      pdb=" C   ASP A  79 "
      pdb=" N   ARG A  80 "
    ideal   model   delta    sigma   weight residual
   122.59  122.86   -0.27 1.33e+00 5.65e-01 4.05e-02
angle pdb=" CG1 ILE A  47 "
      pdb=" CB  ILE A  47 "
      pdb=" CG2 ILE A  47 "
    ideal   model   delta    sigma   weight residual
   110.70  110.10    0.60 3.00e+00 1.11e-01 4.05e-02
angle pdb=" N   VAL A  35 "
      pdb=" CA  VAL A  35 "
      pdb=" CB  VAL A  35 "
    ideal   model   delta    sigma   weight residual
   111.25  111.52   -0.27 1.36e+00 5.41e-01 4.05e-02
angle pdb=" C   TYR A  34 "
      pdb=" CA  TYR A  34 "
      pdb=" CB  TYR A  34 "
    ideal   model   delta    sigma   weight residual
   110.16  110.49   -0.33 1.66e+00 3.63e-01 3.97e-02
angle pdb=" C   GLN A  31 "
      pdb=" N   LEU A  32 "
      pdb=" CA  LEU A  32 "
    ideal   model   delta    sigma   weight residual
   122.74  122.38    0.36 1.82e+00 3.02e-01 3.93e-02
angle pdb=" O   ASN A  29 "
      pdb=" C   ASN A  29 "
      pdb=" N   GLU A  30 "
    ideal   model   delta    sigma   weight residual
   123.27  123.05    0.22 1.13e+00 7.83e-01 3.92e-02
angle pdb=" CA  ILE A   6 "
      pdb=" CB  ILE A   6 "
      pdb=" CG2 ILE A   6 "
    ideal   model   delta    sigma   weight residual
   110.50  110.17    0.33 1.70e+00 3.46e-01 3.88e-02
angle pdb=" CA  SER A  17 "
      pdb=" C   SER A  17 "
      pdb=" N   GLY A  18 "
    ideal   model   delta    sigma   weight residual
   115.27  115.56   -0.29 1.47e+00 4.63e-01 3.80e-02
angle pdb=" CA  HIS A  64 "
      pdb=" CB  HIS A  64 "
      pdb=" CG  HIS A  64 "
    ideal   model   delta    sigma   weight residual
   113.80  113.99   -0.19 1.00e+00 1.00e+00 3.77e-02
angle pdb=" N   LEU A  37 "
      pdb=" CA  LEU A  37 "
      pdb=" C   LEU A  37 "
    ideal   model   delta    sigma   weight residual
   112.72  112.50    0.22 1.14e+00 7.69e-01 3.75e-02
angle pdb=" OE1 GLU A   5 "
      pdb=" CD  GLU A   5 "
      pdb=" OE2 GLU A   5 "
    ideal   model   delta    sigma   weight residual
   122.90  122.44    0.46 2.40e+00 1.74e-01 3.74e-02
angle pdb=" N   TYR A  34 "
      pdb=" CA  TYR A  34 "
      pdb=" C   TYR A  34 "
    ideal   model   delta    sigma   weight residual
   108.41  108.73   -0.32 1.63e+00 3.76e-01 3.74e-02
angle pdb=" C   LEU A  65 "
      pdb=" N   SER A  66 "
      pdb=" CA  SER A  66 "
    ideal   model   delta    sigma   weight residual
   121.52  121.07    0.45 2.34e+00 1.83e-01 3.72e-02
angle pdb=" O   PRO A  42 "
      pdb=" C   PRO A  42 "
      pdb=" N   VAL A  43 "
    ideal   model   delta    sigma   weight residual
   122.91  123.14   -0.23 1.21e+00 6.83e-01 3.72e-02
angle pdb=" CA  VAL A  43 "
      pdb=" C   VAL A  43 "
      pdb=" O   VAL A  43 "
    ideal   model   delta    sigma   weight residual
   121.40  121.16    0.24 1.27e+00 6.20e-01 3.69e-02
angle pdb=" CA  VAL A  63 "
      pdb=" CB  VAL A  63 "
      pdb=" CG1 VAL A  63 "
    ideal   model   delta    sigma   weight residual
   110.40  110.73   -0.33 1.70e+00 3.46e-01 3.68e-02
angle pdb=" O   PHE A  68 "
      pdb=" C   PHE A  68 "
      pdb=" N   LYS A  69 "
    ideal   model   delta    sigma   weight residual
   123.16  123.40   -0.24 1.26e+00 6.30e-01 3.67e-02
angle pdb=" CG  GLN A  22 "
      pdb=" CD  GLN A  22 "
      pdb=" OE1 GLN A  22 "
    ideal   model   delta    sigma   weight residual
   120.80  121.18   -0.38 2.00e+00 2.50e-01 3.67e-02
angle pdb=" C   TYR A  26 "
      pdb=" CA  TYR A  26 "
      pdb=" CB  TYR A  26 "
    ideal   model   delta    sigma   weight residual
   109.79  109.40    0.39 2.05e+00 2.38e-01 3.64e-02
angle pdb=" N   HIS A  64 "
      pdb=" CA  HIS A  64 "
      pdb=" C   HIS A  64 "
    ideal   model   delta    sigma   weight residual
   110.48  110.76   -0.28 1.48e+00 4.57e-01 3.63e-02
angle pdb=" CA  SER A   9 "
      pdb=" CB  SER A   9 "
      pdb=" OG  SER A   9 "
    ideal   model   delta    sigma   weight residual
   111.10  110.72    0.38 2.00e+00 2.50e-01 3.59e-02
angle pdb=" N   GLY A  74 "
      pdb=" CA  GLY A  74 "
      pdb=" C   GLY A  74 "
    ideal   model   delta    sigma   weight residual
   115.21  115.46   -0.25 1.30e+00 5.92e-01 3.55e-02
angle pdb=" C   ILE A  78 "
      pdb=" CA  ILE A  78 "
      pdb=" CB  ILE A  78 "
    ideal   model   delta    sigma   weight residual
   110.96  111.24   -0.28 1.46e+00 4.69e-01 3.55e-02
angle pdb=" N   LEU A  81 "
      pdb=" CA  LEU A  81 "
      pdb=" C   LEU A  81 "
    ideal   model   delta    sigma   weight residual
   109.15  108.88    0.27 1.44e+00 4.82e-01 3.50e-02
angle pdb=" C   ILE A   6 "
      pdb=" N   LYS A   7 "
      pdb=" CA  LYS A   7 "
    ideal   model   delta    sigma   weight residual
   121.03  121.33   -0.30 1.60e+00 3.91e-01 3.50e-02
angle pdb=" C   LEU A  83 "
      pdb=" CA  LEU A  83 "
      pdb=" CB  LEU A  83 "
    ideal   model   delta    sigma   weight residual
   109.50  109.82   -0.32 1.69e+00 3.50e-01 3.50e-02
angle pdb=" N   SER A  75 "
      pdb=" CA  SER A  75 "
      pdb=" C   SER A  75 "
    ideal   model   delta    sigma   weight residual
   110.52  110.80   -0.28 1.48e+00 4.57e-01 3.46e-02
angle pdb=" O   ALA A  55 "
      pdb=" C   ALA A  55 "
      pdb=" N   TYR A  56 "
    ideal   model   delta    sigma   weight residual
   122.89  122.66    0.23 1.22e+00 6.72e-01 3.46e-02
angle pdb=" N   MSE A  77 "
      pdb=" CA  MSE A  77 "
      pdb=" C   MSE A  77 "
    ideal   model   delta    sigma   weight residual
   109.14  108.86    0.28 1.49e+00 4.50e-01 3.44e-02
angle pdb=" O   ASP A  36 "
      pdb=" C   ASP A  36 "
      pdb=" N   LEU A  37 "
    ideal   model   delta    sigma   weight residual
   122.93  122.71    0.22 1.20e+00 6.94e-01 3.41e-02
angle pdb=" CA  LEU A  76 "
      pdb=" CB  LEU A  76 "
      pdb=" CG  LEU A  76 "
    ideal   model   delta    sigma   weight residual
   116.30  116.94   -0.64 3.50e+00 8.16e-02 3.39e-02
angle pdb=" CE1 TYR A  26 "
      pdb=" CZ  TYR A  26 "
      pdb=" CE2 TYR A  26 "
    ideal   model   delta    sigma   weight residual
   120.30  120.67   -0.37 2.00e+00 2.50e-01 3.38e-02
angle pdb=" CA  ARG A  80 "
      pdb=" CB  ARG A  80 "
      pdb=" CG  ARG A  80 "
    ideal   model   delta    sigma   weight residual
   114.10  113.73    0.37 2.00e+00 2.50e-01 3.36e-02
angle pdb=" CA  ARG A  16 "
      pdb=" C   ARG A  16 "
      pdb=" O   ARG A  16 "
    ideal   model   delta    sigma   weight residual
   120.43  120.63   -0.20 1.09e+00 8.42e-01 3.25e-02
angle pdb=" CG1 ILE A  78 "
      pdb=" CB  ILE A  78 "
      pdb=" CG2 ILE A  78 "
    ideal   model   delta    sigma   weight residual
   110.70  110.16    0.54 3.00e+00 1.11e-01 3.21e-02
angle pdb=" CA  LYS A   7 "
      pdb=" C   LYS A   7 "
      pdb=" O   LYS A   7 "
    ideal   model   delta    sigma   weight residual
   120.87  120.67    0.20 1.10e+00 8.26e-01 3.21e-02
angle pdb=" CA  ASP A  79 "
      pdb=" C   ASP A  79 "
      pdb=" N   ARG A  80 "
    ideal   model   delta    sigma   weight residual
   116.84  116.54    0.30 1.71e+00 3.42e-01 3.16e-02
angle pdb=" CA  THR A  14 "
      pdb=" C   THR A  14 "
      pdb=" O   THR A  14 "
    ideal   model   delta    sigma   weight residual
   121.16  120.96    0.20 1.13e+00 7.83e-01 3.15e-02
angle pdb=" CA  CYS A  33 "
      pdb=" CB  CYS A  33 "
      pdb=" SG  CYS A  33 "
    ideal   model   delta    sigma   weight residual
   114.40  114.81   -0.41 2.30e+00 1.89e-01 3.12e-02
angle pdb=" CA  ILE A  78 "
      pdb=" C   ILE A  78 "
      pdb=" N   ASP A  79 "
    ideal   model   delta    sigma   weight residual
   116.34  116.11    0.23 1.28e+00 6.10e-01 3.12e-02
angle pdb=" C   PHE A  68 "
      pdb=" CA  PHE A  68 "
      pdb=" CB  PHE A  68 "
    ideal   model   delta    sigma   weight residual
   109.37  109.69   -0.32 1.83e+00 2.99e-01 3.06e-02
angle pdb=" N   GLU A  51 "
      pdb=" CA  GLU A  51 "
      pdb=" C   GLU A  51 "
    ideal   model   delta    sigma   weight residual
   110.28  110.54   -0.26 1.48e+00 4.57e-01 3.02e-02
angle pdb=" CG  TYR A  26 "
      pdb=" CD2 TYR A  26 "
      pdb=" CE2 TYR A  26 "
    ideal   model   delta    sigma   weight residual
   121.20  120.94    0.26 1.50e+00 4.44e-01 2.98e-02
angle pdb=" CB  ILE A   6 "
      pdb=" CG1 ILE A   6 "
      pdb=" CD1 ILE A   6 "
    ideal   model   delta    sigma   weight residual
   113.80  114.16   -0.36 2.10e+00 2.27e-01 2.97e-02
angle pdb=" N   LEU A  60 "
      pdb=" CA  LEU A  60 "
      pdb=" CB  LEU A  60 "
    ideal   model   delta    sigma   weight residual
   110.57  110.84   -0.27 1.57e+00 4.06e-01 2.94e-02
angle pdb=" CA  LEU A  65 "
      pdb=" C   LEU A  65 "
      pdb=" N   SER A  66 "
    ideal   model   delta    sigma   weight residual
   117.63  117.84   -0.21 1.25e+00 6.40e-01 2.93e-02
angle pdb=" CA  LYS A  46 "
      pdb=" CB  LYS A  46 "
      pdb=" CG  LYS A  46 "
    ideal   model   delta    sigma   weight residual
   114.10  113.76    0.34 2.00e+00 2.50e-01 2.92e-02
angle pdb=" CA  ILE A  78 "
      pdb=" CB  ILE A  78 "
      pdb=" CG2 ILE A  78 "
    ideal   model   delta    sigma   weight residual
   110.50  110.79   -0.29 1.70e+00 3.46e-01 2.88e-02
angle pdb=" CB  TYR A  41 "
      pdb=" CG  TYR A  41 "
      pdb=" CD2 TYR A  41 "
    ideal   model   delta    sigma   weight residual
   120.80  120.55    0.25 1.50e+00 4.44e-01 2.88e-02
angle pdb=" CA  ASN A  29 "
      pdb=" C   ASN A  29 "
      pdb=" O   ASN A  29 "
    ideal   model   delta    sigma   weight residual
   120.43  120.25    0.18 1.09e+00 8.42e-01 2.88e-02
angle pdb=" N   LYS A  69 "
      pdb=" CA  LYS A  69 "
      pdb=" CB  LYS A  69 "
    ideal   model   delta    sigma   weight residual
   111.56  111.83   -0.27 1.58e+00 4.01e-01 2.86e-02
angle pdb=" CB  ASP A  36 "
      pdb=" CG  ASP A  36 "
      pdb=" OD1 ASP A  36 "
    ideal   model   delta    sigma   weight residual
   118.40  118.79   -0.39 2.30e+00 1.89e-01 2.86e-02
angle pdb=" CA  GLN A  72 "
      pdb=" CB  GLN A  72 "
      pdb=" CG  GLN A  72 "
    ideal   model   delta    sigma   weight residual
   114.10  114.44   -0.34 2.00e+00 2.50e-01 2.83e-02
angle pdb=" N   LYS A   3 "
      pdb=" CA  LYS A   3 "
      pdb=" CB  LYS A   3 "
    ideal   model   delta    sigma   weight residual
   110.43  110.70   -0.27 1.63e+00 3.76e-01 2.82e-02
angle pdb=" N   ASN A  39 "
      pdb=" CA  ASN A  39 "
      pdb=" CB  ASN A  39 "
    ideal   model   delta    sigma   weight residual
   110.39  110.66   -0.27 1.59e+00 3.96e-01 2.80e-02
angle pdb=" O   LYS A  69 "
      pdb=" C   LYS A  69 "
      pdb=" N   VAL A  70 "
    ideal   model   delta    sigma   weight residual
   123.10  122.91    0.19 1.15e+00 7.56e-01 2.79e-02
angle pdb=" CA  GLN A  53 "
      pdb=" CB  GLN A  53 "
      pdb=" CG  GLN A  53 "
    ideal   model   delta    sigma   weight residual
   114.10  114.43   -0.33 2.00e+00 2.50e-01 2.77e-02
angle pdb=" CD1 LEU A  83 "
      pdb=" CG  LEU A  83 "
      pdb=" CD2 LEU A  83 "
    ideal   model   delta    sigma   weight residual
   110.80  111.17   -0.37 2.20e+00 2.07e-01 2.75e-02
angle pdb=" CA  GLN A  12 "
      pdb=" CB  GLN A  12 "
      pdb=" CG  GLN A  12 "
    ideal   model   delta    sigma   weight residual
   114.10  114.43   -0.33 2.00e+00 2.50e-01 2.70e-02
angle pdb=" CA  ILE A  78 "
      pdb=" C   ILE A  78 "
      pdb=" O   ILE A  78 "
    ideal   model   delta    sigma   weight residual
   120.53  120.71   -0.18 1.07e+00 8.73e-01 2.69e-02
angle pdb=" C   VAL A  35 "
      pdb=" N   ASP A  36 "
      pdb=" CA  ASP A  36 "
    ideal   model   delta    sigma   weight residual
   122.42  122.20    0.22 1.33e+00 5.65e-01 2.65e-02
angle pdb=" CA  THR A  62 "
      pdb=" CB  THR A  62 "
      pdb=" CG2 THR A  62 "
    ideal   model   delta    sigma   weight residual
   110.50  110.78   -0.28 1.70e+00 3.46e-01 2.63e-02
angle pdb=" CB  LEU A  76 "
      pdb=" CG  LEU A  76 "
      pdb=" CD1 LEU A  76 "
    ideal   model   delta    sigma   weight residual
   110.70  110.22    0.48 3.00e+00 1.11e-01 2.60e-02
angle pdb=" CB  ASP A  79 "
      pdb=" CG  ASP A  79 "
      pdb=" OD2 ASP A  79 "
    ideal   model   delta    sigma   weight residual
   118.40  118.03    0.37 2.30e+00 1.89e-01 2.58e-02
angle pdb=" O   GLU A  40 "
      pdb=" C   GLU A  40 "
      pdb=" N   TYR A  41 "
    ideal   model   delta    sigma   weight residual
   122.12  122.29   -0.17 1.06e+00 8.90e-01 2.58e-02
angle pdb=" N   ASP A  79 "
      pdb=" CA  ASP A  79 "
      pdb=" CB  ASP A  79 "
    ideal   model   delta    sigma   weight residual
   110.49  110.22    0.27 1.69e+00 3.50e-01 2.57e-02
angle pdb=" N   CYS A  33 "
      pdb=" CA  CYS A  33 "
      pdb=" C   CYS A  33 "
    ideal   model   delta    sigma   weight residual
   108.60  108.83   -0.23 1.46e+00 4.69e-01 2.56e-02
angle pdb=" N   LEU A  76 "
      pdb=" CA  LEU A  76 "
      pdb=" CB  LEU A  76 "
    ideal   model   delta    sigma   weight residual
   109.97  110.20   -0.23 1.47e+00 4.63e-01 2.55e-02
angle pdb=" CA  TYR A  26 "
      pdb=" C   TYR A  26 "
      pdb=" O   TYR A  26 "
    ideal   model   delta    sigma   weight residual
   121.44  121.25    0.19 1.17e+00 7.31e-01 2.55e-02
angle pdb=" N   VAL A  84 "
      pdb=" CA  VAL A  84 "
      pdb=" CB  VAL A  84 "
    ideal   model   delta    sigma   weight residual
   111.21  110.99    0.22 1.40e+00 5.10e-01 2.55e-02
angle pdb=" CA  VAL A  35 "
      pdb=" CB  VAL A  35 "
      pdb=" CG1 VAL A  35 "
    ideal   model   delta    sigma   weight residual
   110.40  110.67   -0.27 1.70e+00 3.46e-01 2.53e-02
angle pdb=" CE1 PHE A  13 "
      pdb=" CZ  PHE A  13 "
      pdb=" CE2 PHE A  13 "
    ideal   model   delta    sigma   weight residual
   120.00  119.71    0.29 1.80e+00 3.09e-01 2.52e-02
angle pdb=" CA  LEU A  60 "
      pdb=" C   LEU A  60 "
      pdb=" O   LEU A  60 "
    ideal   model   delta    sigma   weight residual
   120.38  120.55   -0.17 1.09e+00 8.42e-01 2.51e-02
angle pdb=" O   ARG A  16 "
      pdb=" C   ARG A  16 "
      pdb=" N   SER A  17 "
    ideal   model   delta    sigma   weight residual
   123.27  123.09    0.18 1.13e+00 7.83e-01 2.51e-02
angle pdb=" CA  THR A  48 "
      pdb=" CB  THR A  48 "
      pdb=" OG1 THR A  48 "
    ideal   model   delta    sigma   weight residual
   109.60  109.36    0.24 1.50e+00 4.44e-01 2.50e-02
angle pdb=" C   VAL A  70 "
      pdb=" N   GLY A  71 "
      pdb=" CA  GLY A  71 "
    ideal   model   delta    sigma   weight residual
   121.54  121.76   -0.22 1.43e+00 4.89e-01 2.44e-02
angle pdb=" CD  LYS A  46 "
      pdb=" CE  LYS A  46 "
      pdb=" NZ  LYS A  46 "
    ideal   model   delta    sigma   weight residual
   111.90  112.40   -0.50 3.20e+00 9.77e-02 2.42e-02
angle pdb=" C   GLN A  72 "
      pdb=" CA  GLN A  72 "
      pdb=" CB  GLN A  72 "
    ideal   model   delta    sigma   weight residual
   110.17  109.85    0.32 2.04e+00 2.40e-01 2.42e-02
angle pdb=" C   LEU A  32 "
      pdb=" N   CYS A  33 "
      pdb=" CA  CYS A  33 "
    ideal   model   delta    sigma   weight residual
   121.80  122.06   -0.26 1.71e+00 3.42e-01 2.40e-02
angle pdb=" N   SER A  66 "
      pdb=" CA  SER A  66 "
      pdb=" CB  SER A  66 "
    ideal   model   delta    sigma   weight residual
   110.42  110.15    0.27 1.76e+00 3.23e-01 2.37e-02
angle pdb=" CA  GLU A  30 "
      pdb=" CB  GLU A  30 "
      pdb=" CG  GLU A  30 "
    ideal   model   delta    sigma   weight residual
   114.10  113.79    0.31 2.00e+00 2.50e-01 2.33e-02
angle pdb=" CA  LEU A  37 "
      pdb=" CB  LEU A  37 "
      pdb=" CG  LEU A  37 "
    ideal   model   delta    sigma   weight residual
   116.30  116.83   -0.53 3.50e+00 8.16e-02 2.32e-02
angle pdb=" N   GLN A  22 "
      pdb=" CA  GLN A  22 "
      pdb=" C   GLN A  22 "
    ideal   model   delta    sigma   weight residual
   112.93  113.10   -0.17 1.12e+00 7.97e-01 2.32e-02
angle pdb=" CA  ASP A  50 "
      pdb=" C   ASP A  50 "
      pdb=" O   ASP A  50 "
    ideal   model   delta    sigma   weight residual
   121.87  121.69    0.18 1.16e+00 7.43e-01 2.30e-02
angle pdb=" N   PRO A  54 "
      pdb=" CA  PRO A  54 "
      pdb=" CB  PRO A  54 "
    ideal   model   delta    sigma   weight residual
   103.42  103.62   -0.20 1.32e+00 5.74e-01 2.30e-02
angle pdb=" CA  PRO A  42 "
      pdb=" N   PRO A  42 "
      pdb=" CD  PRO A  42 "
    ideal   model   delta    sigma   weight residual
   112.00  112.21   -0.21 1.40e+00 5.10e-01 2.29e-02
angle pdb=" C   GLN A  10 "
      pdb=" N   ALA A  11 "
      pdb=" CA  ALA A  11 "
    ideal   model   delta    sigma   weight residual
   121.94  122.24   -0.30 2.00e+00 2.50e-01 2.29e-02
angle pdb=" O   GLN A  31 "
      pdb=" C   GLN A  31 "
      pdb=" N   LEU A  32 "
    ideal   model   delta    sigma   weight residual
   123.24  123.06    0.18 1.23e+00 6.61e-01 2.26e-02
angle pdb=" C   ARG A  80 "
      pdb=" CA  ARG A  80 "
      pdb=" CB  ARG A  80 "
    ideal   model   delta    sigma   weight residual
   109.68  109.98   -0.30 1.98e+00 2.55e-01 2.24e-02
angle pdb=" N   GLU A  30 "
      pdb=" CA  GLU A  30 "
      pdb=" CB  GLU A  30 "
    ideal   model   delta    sigma   weight residual
   110.83  111.09   -0.26 1.74e+00 3.30e-01 2.20e-02
angle pdb=" O   LEU A  60 "
      pdb=" C   LEU A  60 "
      pdb=" N   TYR A  61 "
    ideal   model   delta    sigma   weight residual
   123.29  123.46   -0.17 1.18e+00 7.18e-01 2.18e-02
angle pdb=" CA  VAL A   4 "
      pdb=" C   VAL A   4 "
      pdb=" O   VAL A   4 "
    ideal   model   delta    sigma   weight residual
   120.67  120.50    0.17 1.17e+00 7.31e-01 2.18e-02
angle pdb=" CA  ALA A  57 "
      pdb=" C   ALA A  57 "
      pdb=" O   ALA A  57 "
    ideal   model   delta    sigma   weight residual
   120.87  120.71    0.16 1.10e+00 8.26e-01 2.18e-02
angle pdb=" CG  TYR A  56 "
      pdb=" CD2 TYR A  56 "
      pdb=" CE2 TYR A  56 "
    ideal   model   delta    sigma   weight residual
   121.20  120.98    0.22 1.50e+00 4.44e-01 2.15e-02
angle pdb=" CA  LYS A   7 "
      pdb=" C   LYS A   7 "
      pdb=" N   PRO A   8 "
    ideal   model   delta    sigma   weight residual
   117.44  117.61   -0.17 1.13e+00 7.83e-01 2.15e-02
angle pdb=" CA  THR A  14 "
      pdb=" C   THR A  14 "
      pdb=" N   THR A  15 "
    ideal   model   delta    sigma   weight residual
   115.60  115.82   -0.22 1.48e+00 4.57e-01 2.15e-02
angle pdb=" CA  VAL A  63 "
      pdb=" C   VAL A  63 "
      pdb=" N   HIS A  64 "
    ideal   model   delta    sigma   weight residual
   116.31  116.13    0.18 1.20e+00 6.94e-01 2.15e-02
angle pdb=" O   LEU A  65 "
      pdb=" C   LEU A  65 "
      pdb=" N   SER A  66 "
    ideal   model   delta    sigma   weight residual
   122.22  122.05    0.17 1.17e+00 7.31e-01 2.12e-02
angle pdb=" CB  LEU A  81 "
      pdb=" CG  LEU A  81 "
      pdb=" CD2 LEU A  81 "
    ideal   model   delta    sigma   weight residual
   110.70  111.13   -0.43 3.00e+00 1.11e-01 2.09e-02
angle pdb=" OE1 GLN A  53 "
      pdb=" CD  GLN A  53 "
      pdb=" NE2 GLN A  53 "
    ideal   model   delta    sigma   weight residual
   122.60  122.46    0.14 1.00e+00 1.00e+00 2.09e-02
angle pdb=" CA  LYS A   3 "
      pdb=" C   LYS A   3 "
      pdb=" O   LYS A   3 "
    ideal   model   delta    sigma   weight residual
   120.43  120.59   -0.16 1.09e+00 8.42e-01 2.04e-02
angle pdb=" CA  ILE A   6 "
      pdb=" C   ILE A   6 "
      pdb=" N   LYS A   7 "
    ideal   model   delta    sigma   weight residual
   116.46  116.67   -0.21 1.51e+00 4.39e-01 2.01e-02
angle pdb=" CA  SER A  66 "
      pdb=" C   SER A  66 "
      pdb=" N   SER A  67 "
    ideal   model   delta    sigma   weight residual
   118.59  118.36    0.23 1.63e+00 3.76e-01 2.00e-02
angle pdb=" C   ASP A  50 "
      pdb=" CA  ASP A  50 "
      pdb=" CB  ASP A  50 "
    ideal   model   delta    sigma   weight residual
   109.68  109.39    0.29 2.05e+00 2.38e-01 2.00e-02
angle pdb=" C   LEU A  44 "
      pdb=" CA  LEU A  44 "
      pdb=" CB  LEU A  44 "
    ideal   model   delta    sigma   weight residual
   110.29  110.52   -0.23 1.64e+00 3.72e-01 2.00e-02
angle pdb=" N   SER A  75 "
      pdb=" CA  SER A  75 "
      pdb=" CB  SER A  75 "
    ideal   model   delta    sigma   weight residual
   110.46  110.69   -0.23 1.60e+00 3.91e-01 1.99e-02
angle pdb=" O   VAL A  70 "
      pdb=" C   VAL A  70 "
      pdb=" N   GLY A  71 "
    ideal   model   delta    sigma   weight residual
   122.94  123.11   -0.17 1.22e+00 6.72e-01 1.98e-02
angle pdb=" N   SER A  27 "
      pdb=" CA  SER A  27 "
      pdb=" C   SER A  27 "
    ideal   model   delta    sigma   weight residual
   108.69  108.94   -0.25 1.77e+00 3.19e-01 1.98e-02
angle pdb=" CA  LEU A  81 "
      pdb=" C   LEU A  81 "
      pdb=" O   LEU A  81 "
    ideal   model   delta    sigma   weight residual
   120.62  120.79   -0.17 1.19e+00 7.06e-01 1.96e-02
angle pdb=" O   GLY A  59 "
      pdb=" C   GLY A  59 "
      pdb=" N   LEU A  60 "
    ideal   model   delta    sigma   weight residual
   123.96  124.10   -0.14 9.90e-01 1.02e+00 1.94e-02
angle pdb=" CB  LEU A  28 "
      pdb=" CG  LEU A  28 "
      pdb=" CD2 LEU A  28 "
    ideal   model   delta    sigma   weight residual
   110.70  110.28    0.42 3.00e+00 1.11e-01 1.94e-02
angle pdb=" N   PRO A  85 "
      pdb=" CD  PRO A  85 "
      pdb=" CG  PRO A  85 "
    ideal   model   delta    sigma   weight residual
   103.20  103.41   -0.21 1.50e+00 4.44e-01 1.93e-02
angle pdb=" N   ARG A  82 "
      pdb=" CA  ARG A  82 "
      pdb=" C   ARG A  82 "
    ideal   model   delta    sigma   weight residual
   108.52  108.29    0.23 1.63e+00 3.76e-01 1.93e-02
angle pdb=" O   GLY A  74 "
      pdb=" C   GLY A  74 "
      pdb=" N   SER A  75 "
    ideal   model   delta    sigma   weight residual
   122.42  122.24    0.18 1.31e+00 5.83e-01 1.91e-02
angle pdb=" CA  GLU A  51 "
      pdb=" C   GLU A  51 "
      pdb=" O   GLU A  51 "
    ideal   model   delta    sigma   weight residual
   121.16  121.31   -0.15 1.12e+00 7.97e-01 1.90e-02
angle pdb=" CA  PHE A  68 "
      pdb=" CB  PHE A  68 "
      pdb=" CG  PHE A  68 "
    ideal   model   delta    sigma   weight residual
   113.80  113.66    0.14 1.00e+00 1.00e+00 1.90e-02
angle pdb=" OG1 THR A  15 "
      pdb=" CB  THR A  15 "
      pdb=" CG2 THR A  15 "
    ideal   model   delta    sigma   weight residual
   109.30  109.57   -0.27 2.00e+00 2.50e-01 1.89e-02
angle pdb=" CB  TYR A  34 "
      pdb=" CG  TYR A  34 "
      pdb=" CD2 TYR A  34 "
    ideal   model   delta    sigma   weight residual
   120.80  121.01   -0.21 1.50e+00 4.44e-01 1.87e-02
angle pdb=" CA  ARG A  80 "
      pdb=" C   ARG A  80 "
      pdb=" N   LEU A  81 "
    ideal   model   delta    sigma   weight residual
   115.98  116.18   -0.20 1.45e+00 4.76e-01 1.83e-02
angle pdb=" C   GLN A  53 "
      pdb=" N   PRO A  54 "
      pdb=" CA  PRO A  54 "
    ideal   model   delta    sigma   weight residual
   120.21  120.08    0.13 9.60e-01 1.09e+00 1.83e-02
angle pdb=" CA  PHE A  73 "
      pdb=" C   PHE A  73 "
      pdb=" N   GLY A  74 "
    ideal   model   delta    sigma   weight residual
   118.11  118.28   -0.17 1.27e+00 6.20e-01 1.81e-02
angle pdb=" N   PHE A  13 "
      pdb=" CA  PHE A  13 "
      pdb=" C   PHE A  13 "
    ideal   model   delta    sigma   weight residual
   109.72  109.51    0.21 1.60e+00 3.91e-01 1.79e-02
angle pdb=" C   GLY A  52 "
      pdb=" N   GLN A  53 "
      pdb=" CA  GLN A  53 "
    ideal   model   delta    sigma   weight residual
   120.94  120.69    0.25 1.90e+00 2.77e-01 1.77e-02
angle pdb=" N   ASP A  36 "
      pdb=" CA  ASP A  36 "
      pdb=" C   ASP A  36 "
    ideal   model   delta    sigma   weight residual
   108.41  108.62   -0.21 1.61e+00 3.86e-01 1.76e-02
angle pdb=" CE1 TYR A  41 "
      pdb=" CZ  TYR A  41 "
      pdb=" OH  TYR A  41 "
    ideal   model   delta    sigma   weight residual
   119.90  120.30   -0.40 3.00e+00 1.11e-01 1.75e-02
angle pdb=" N   PRO A  85 "
      pdb=" CA  PRO A  85 "
      pdb=" CB  PRO A  85 "
    ideal   model   delta    sigma   weight residual
   103.00  102.85    0.15 1.10e+00 8.26e-01 1.74e-02
angle pdb=" CB  ASP A  50 "
      pdb=" CG  ASP A  50 "
      pdb=" OD1 ASP A  50 "
    ideal   model   delta    sigma   weight residual
   118.40  118.70   -0.30 2.30e+00 1.89e-01 1.65e-02
angle pdb=" CA  ASP A  50 "
      pdb=" CB  ASP A  50 "
      pdb=" CG  ASP A  50 "
    ideal   model   delta    sigma   weight residual
   112.60  112.73   -0.13 1.00e+00 1.00e+00 1.64e-02
angle pdb=" CD1 TYR A  26 "
      pdb=" CE1 TYR A  26 "
      pdb=" CZ  TYR A  26 "
    ideal   model   delta    sigma   weight residual
   119.60  119.37    0.23 1.80e+00 3.09e-01 1.61e-02
angle pdb=" CG  PHE A  13 "
      pdb=" CD1 PHE A  13 "
      pdb=" CE1 PHE A  13 "
    ideal   model   delta    sigma   weight residual
   120.70  120.92   -0.22 1.70e+00 3.46e-01 1.61e-02
angle pdb=" CA  VAL A  35 "
      pdb=" C   VAL A  35 "
      pdb=" N   ASP A  36 "
    ideal   model   delta    sigma   weight residual
   116.31  116.46   -0.15 1.18e+00 7.18e-01 1.60e-02
angle pdb=" CA  PRO A  54 "
      pdb=" CB  PRO A  54 "
      pdb=" CG  PRO A  54 "
    ideal   model   delta    sigma   weight residual
   104.50  104.26    0.24 1.90e+00 2.77e-01 1.60e-02
angle pdb=" N   SER A   9 "
      pdb=" CA  SER A   9 "
      pdb=" C   SER A   9 "
    ideal   model   delta    sigma   weight residual
   113.20  113.05    0.15 1.21e+00 6.83e-01 1.60e-02
angle pdb=" CA  THR A  48 "
      pdb=" C   THR A  48 "
      pdb=" N   LEU A  49 "
    ideal   model   delta    sigma   weight residual
   116.36  116.20    0.16 1.28e+00 6.10e-01 1.57e-02
angle pdb=" C   PHE A  73 "
      pdb=" N   GLY A  74 "
      pdb=" CA  GLY A  74 "
    ideal   model   delta    sigma   weight residual
   122.20  122.00    0.20 1.59e+00 3.96e-01 1.56e-02
angle pdb=" CA  GLU A  30 "
      pdb=" C   GLU A  30 "
      pdb=" N   GLN A  31 "
    ideal   model   delta    sigma   weight residual
   116.01  116.20   -0.19 1.49e+00 4.50e-01 1.55e-02
angle pdb=" CB  LYS A  69 "
      pdb=" CG  LYS A  69 "
      pdb=" CD  LYS A  69 "
    ideal   model   delta    sigma   weight residual
   111.30  111.59   -0.29 2.30e+00 1.89e-01 1.55e-02
angle pdb=" CA  GLU A  40 "
      pdb=" C   GLU A  40 "
      pdb=" O   GLU A  40 "
    ideal   model   delta    sigma   weight residual
   120.55  120.42    0.13 1.06e+00 8.90e-01 1.54e-02
angle pdb=" CG  GLN A  31 "
      pdb=" CD  GLN A  31 "
      pdb=" OE1 GLN A  31 "
    ideal   model   delta    sigma   weight residual
   120.80  121.04   -0.24 2.00e+00 2.50e-01 1.47e-02
angle pdb=" N   GLN A  72 "
      pdb=" CA  GLN A  72 "
      pdb=" C   GLN A  72 "
    ideal   model   delta    sigma   weight residual
   113.01  113.16   -0.15 1.20e+00 6.94e-01 1.46e-02
angle pdb=" CA  CYS A  33 "
      pdb=" C   CYS A  33 "
      pdb=" O   CYS A  33 "
    ideal   model   delta    sigma   weight residual
   121.38  121.51   -0.13 1.06e+00 8.90e-01 1.40e-02
angle pdb=" N   VAL A  63 "
      pdb=" CA  VAL A  63 "
      pdb=" CB  VAL A  63 "
    ideal   model   delta    sigma   weight residual
   110.72  110.85   -0.13 1.09e+00 8.42e-01 1.38e-02
angle pdb=" CB  PHE A  13 "
      pdb=" CG  PHE A  13 "
      pdb=" CD1 PHE A  13 "
    ideal   model   delta    sigma   weight residual
   120.70  120.90   -0.20 1.70e+00 3.46e-01 1.38e-02
angle pdb=" C   TYR A  56 "
      pdb=" CA  TYR A  56 "
      pdb=" CB  TYR A  56 "
    ideal   model   delta    sigma   weight residual
   109.72  109.91   -0.19 1.66e+00 3.63e-01 1.35e-02
angle pdb=" N   ILE A   2 "
      pdb=" CA  ILE A   2 "
      pdb=" C   ILE A   2 "
    ideal   model   delta    sigma   weight residual
   111.00  111.32   -0.32 2.80e+00 1.28e-01 1.32e-02
angle pdb=" O   TYR A  61 "
      pdb=" C   TYR A  61 "
      pdb=" N   THR A  62 "
    ideal   model   delta    sigma   weight residual
   122.94  123.10   -0.16 1.37e+00 5.33e-01 1.32e-02
angle pdb=" CA  PRO A  58 "
      pdb=" C   PRO A  58 "
      pdb=" N   GLY A  59 "
    ideal   model   delta    sigma   weight residual
   115.56  115.71   -0.15 1.27e+00 6.20e-01 1.31e-02
angle pdb=" CB  TYR A  61 "
      pdb=" CG  TYR A  61 "
      pdb=" CD1 TYR A  61 "
    ideal   model   delta    sigma   weight residual
   120.80  120.97   -0.17 1.50e+00 4.44e-01 1.31e-02
angle pdb=" O   HIS A  64 "
      pdb=" C   HIS A  64 "
      pdb=" N   LEU A  65 "
    ideal   model   delta    sigma   weight residual
   122.96  123.09   -0.13 1.13e+00 7.83e-01 1.29e-02
angle pdb=" CD  ARG A  82 "
      pdb=" NE  ARG A  82 "
      pdb=" CZ  ARG A  82 "
    ideal   model   delta    sigma   weight residual
   124.40  124.56   -0.16 1.40e+00 5.10e-01 1.29e-02
angle pdb=" CG  GLN A  53 "
      pdb=" CD  GLN A  53 "
      pdb=" NE2 GLN A  53 "
    ideal   model   delta    sigma   weight residual
   116.40  116.57   -0.17 1.50e+00 4.44e-01 1.28e-02
angle pdb=" C   SER A  75 "
      pdb=" CA  SER A  75 "
      pdb=" CB  SER A  75 "
    ideal   model   delta    sigma   weight residual
   109.83  110.03   -0.20 1.75e+00 3.27e-01 1.28e-02
angle pdb=" CA  THR A  14 "
      pdb=" CB  THR A  14 "
      pdb=" OG1 THR A  14 "
    ideal   model   delta    sigma   weight residual
   109.60  109.43    0.17 1.50e+00 4.44e-01 1.25e-02
angle pdb=" CA  LYS A  69 "
      pdb=" CB  LYS A  69 "
      pdb=" CG  LYS A  69 "
    ideal   model   delta    sigma   weight residual
   114.10  114.32   -0.22 2.00e+00 2.50e-01 1.25e-02
angle pdb=" N   TYR A  61 "
      pdb=" CA  TYR A  61 "
      pdb=" CB  TYR A  61 "
    ideal   model   delta    sigma   weight residual
   111.43  111.61   -0.18 1.59e+00 3.96e-01 1.25e-02
angle pdb=" CA  GLY A  52 "
      pdb=" C   GLY A  52 "
      pdb=" N   GLN A  53 "
    ideal   model   delta    sigma   weight residual
   117.84  117.99   -0.15 1.37e+00 5.33e-01 1.23e-02
angle pdb=" CB  GLN A  12 "
      pdb=" CG  GLN A  12 "
      pdb=" CD  GLN A  12 "
    ideal   model   delta    sigma   weight residual
   112.60  112.41    0.19 1.70e+00 3.46e-01 1.20e-02
angle pdb=" CA  GLY A  59 "
      pdb=" C   GLY A  59 "
      pdb=" N   LEU A  60 "
    ideal   model   delta    sigma   weight residual
   114.53  114.40    0.13 1.20e+00 6.94e-01 1.19e-02
angle pdb=" C   LYS A  46 "
      pdb=" CA  LYS A  46 "
      pdb=" CB  LYS A  46 "
    ideal   model   delta    sigma   weight residual
   109.48  109.66   -0.18 1.68e+00 3.54e-01 1.19e-02
angle pdb=" N   ARG A  80 "
      pdb=" CA  ARG A  80 "
      pdb=" C   ARG A  80 "
    ideal   model   delta    sigma   weight residual
   108.75  108.56    0.19 1.71e+00 3.42e-01 1.19e-02
angle pdb=" N   PRO A  58 "
      pdb=" CD  PRO A  58 "
      pdb=" CG  PRO A  58 "
    ideal   model   delta    sigma   weight residual
   103.20  103.04    0.16 1.50e+00 4.44e-01 1.18e-02
angle pdb=" CA  VAL A  70 "
      pdb=" C   VAL A  70 "
      pdb=" N   GLY A  71 "
    ideal   model   delta    sigma   weight residual
   116.39  116.26    0.13 1.17e+00 7.31e-01 1.18e-02
angle pdb=" N   LEU A  37 "
      pdb=" CA  LEU A  37 "
      pdb=" CB  LEU A  37 "
    ideal   model   delta    sigma   weight residual
   110.70  110.54    0.16 1.49e+00 4.50e-01 1.18e-02
angle pdb=" CA  GLN A  10 "
      pdb=" CB  GLN A  10 "
      pdb=" CG  GLN A  10 "
    ideal   model   delta    sigma   weight residual
   114.10  113.88    0.22 2.00e+00 2.50e-01 1.16e-02
angle pdb=" O   ALA A  11 "
      pdb=" C   ALA A  11 "
      pdb=" N   GLN A  12 "
    ideal   model   delta    sigma   weight residual
   122.39  122.23    0.16 1.48e+00 4.57e-01 1.15e-02
angle pdb=" CA  VAL A   4 "
      pdb=" CB  VAL A   4 "
      pdb=" CG2 VAL A   4 "
    ideal   model   delta    sigma   weight residual
   110.40  110.58   -0.18 1.70e+00 3.46e-01 1.14e-02
angle pdb=" CD1 LEU A  76 "
      pdb=" CG  LEU A  76 "
      pdb=" CD2 LEU A  76 "
    ideal   model   delta    sigma   weight residual
   110.80  111.03   -0.23 2.20e+00 2.07e-01 1.13e-02
angle pdb=" O   SER A  66 "
      pdb=" C   SER A  66 "
      pdb=" N   SER A  67 "
    ideal   model   delta    sigma   weight residual
   122.41  122.58   -0.17 1.60e+00 3.91e-01 1.13e-02
angle pdb=" CA  THR A  48 "
      pdb=" C   THR A  48 "
      pdb=" O   THR A  48 "
    ideal   model   delta    sigma   weight residual
   120.54  120.65   -0.11 1.04e+00 9.25e-01 1.13e-02
angle pdb=" CA  GLY A  52 "
      pdb=" C   GLY A  52 "
      pdb=" O   GLY A  52 "
    ideal   model   delta    sigma   weight residual
   119.59  119.47    0.12 1.11e+00 8.12e-01 1.13e-02
angle pdb=" C   GLU A  30 "
      pdb=" CA  GLU A  30 "
      pdb=" CB  GLU A  30 "
    ideal   model   delta    sigma   weight residual
   109.37  109.57   -0.20 1.91e+00 2.74e-01 1.12e-02
angle pdb=" O   ALA A  57 "
      pdb=" C   ALA A  57 "
      pdb=" N   PRO A  58 "
    ideal   model   delta    sigma   weight residual
   121.60  121.49    0.11 1.06e+00 8.90e-01 1.11e-02
angle pdb=" CA  PHE A  13 "
      pdb=" C   PHE A  13 "
      pdb=" N   THR A  14 "
    ideal   model   delta    sigma   weight residual
   115.63  115.79   -0.16 1.51e+00 4.39e-01 1.08e-02
angle pdb=" CG  GLN A  12 "
      pdb=" CD  GLN A  12 "
      pdb=" NE2 GLN A  12 "
    ideal   model   delta    sigma   weight residual
   116.40  116.56   -0.16 1.50e+00 4.44e-01 1.08e-02
angle pdb=" CG  LYS A  24 "
      pdb=" CD  LYS A  24 "
      pdb=" CE  LYS A  24 "
    ideal   model   delta    sigma   weight residual
   111.30  111.06    0.24 2.30e+00 1.89e-01 1.08e-02
angle pdb=" CG  ARG A  16 "
      pdb=" CD  ARG A  16 "
      pdb=" NE  ARG A  16 "
    ideal   model   delta    sigma   weight residual
   112.00  112.23   -0.23 2.20e+00 2.07e-01 1.07e-02
angle pdb=" CA  ILE A  78 "
      pdb=" CB  ILE A  78 "
      pdb=" CG1 ILE A  78 "
    ideal   model   delta    sigma   weight residual
   110.40  110.22    0.18 1.70e+00 3.46e-01 1.07e-02
angle pdb=" CA  GLU A   5 "
      pdb=" C   GLU A   5 "
      pdb=" N   ILE A   6 "
    ideal   model   delta    sigma   weight residual
   116.00  115.85    0.15 1.50e+00 4.44e-01 1.05e-02
angle pdb=" N   PRO A  42 "
      pdb=" CA  PRO A  42 "
      pdb=" C   PRO A  42 "
    ideal   model   delta    sigma   weight residual
   111.34  111.18    0.16 1.55e+00 4.16e-01 1.04e-02
angle pdb=" O   LYS A   7 "
      pdb=" C   LYS A   7 "
      pdb=" N   PRO A   8 "
    ideal   model   delta    sigma   weight residual
   121.60  121.71   -0.11 1.06e+00 8.90e-01 1.04e-02
angle pdb=" O   GLU A   5 "
      pdb=" C   GLU A   5 "
      pdb=" N   ILE A   6 "
    ideal   model   delta    sigma   weight residual
   123.27  123.39   -0.12 1.22e+00 6.72e-01 1.03e-02
angle pdb=" N   LEU A  83 "
      pdb=" CA  LEU A  83 "
      pdb=" CB  LEU A  83 "
    ideal   model   delta    sigma   weight residual
   110.63  110.46    0.17 1.63e+00 3.76e-01 1.03e-02
angle pdb=" CD1 PHE A  68 "
      pdb=" CG  PHE A  68 "
      pdb=" CD2 PHE A  68 "
    ideal   model   delta    sigma   weight residual
   118.60  118.75   -0.15 1.50e+00 4.44e-01 1.03e-02
angle pdb=" CA  LEU A  76 "
      pdb=" C   LEU A  76 "
      pdb=" N   MSE A  77 "
    ideal   model   delta    sigma   weight residual
   115.88  116.01   -0.13 1.28e+00 6.10e-01 1.03e-02
angle pdb=" CD1 LEU A  28 "
      pdb=" CG  LEU A  28 "
      pdb=" CD2 LEU A  28 "
    ideal   model   delta    sigma   weight residual
   110.80  110.58    0.22 2.20e+00 2.07e-01 1.02e-02
angle pdb=" CB  GLN A  72 "
      pdb=" CG  GLN A  72 "
      pdb=" CD  GLN A  72 "
    ideal   model   delta    sigma   weight residual
   112.60  112.77   -0.17 1.70e+00 3.46e-01 1.02e-02
angle pdb=" CA  HIS A  64 "
      pdb=" C   HIS A  64 "
      pdb=" N   LEU A  65 "
    ideal   model   delta    sigma   weight residual
   115.49  115.37    0.12 1.24e+00 6.50e-01 9.98e-03
angle pdb=" CG  TYR A  41 "
      pdb=" CD2 TYR A  41 "
      pdb=" CE2 TYR A  41 "
    ideal   model   delta    sigma   weight residual
   121.20  121.05    0.15 1.50e+00 4.44e-01 9.91e-03
angle pdb=" CE1 TYR A  34 "
      pdb=" CZ  TYR A  34 "
      pdb=" CE2 TYR A  34 "
    ideal   model   delta    sigma   weight residual
   120.30  120.50   -0.20 2.00e+00 2.50e-01 9.89e-03
angle pdb=" C   LEU A  76 "
      pdb=" CA  LEU A  76 "
      pdb=" CB  LEU A  76 "
    ideal   model   delta    sigma   weight residual
   109.65  109.82   -0.17 1.71e+00 3.42e-01 9.88e-03
angle pdb=" O   LEU A  81 "
      pdb=" C   LEU A  81 "
      pdb=" N   ARG A  82 "
    ideal   model   delta    sigma   weight residual
   122.77  122.64    0.13 1.35e+00 5.49e-01 9.86e-03
angle pdb=" O   SER A  17 "
      pdb=" C   SER A  17 "
      pdb=" N   GLY A  18 "
    ideal   model   delta    sigma   weight residual
   123.10  122.97    0.13 1.29e+00 6.01e-01 9.79e-03
angle pdb=" CD2 PHE A  68 "
      pdb=" CE2 PHE A  68 "
      pdb=" CZ  PHE A  68 "
    ideal   model   delta    sigma   weight residual
   120.00  119.82    0.18 1.80e+00 3.09e-01 9.75e-03
angle pdb=" CB  TYR A  41 "
      pdb=" CG  TYR A  41 "
      pdb=" CD1 TYR A  41 "
    ideal   model   delta    sigma   weight residual
   120.80  120.95   -0.15 1.50e+00 4.44e-01 9.73e-03
angle pdb=" CA  LEU A  37 "
      pdb=" C   LEU A  37 "
      pdb=" N   GLY A  38 "
    ideal   model   delta    sigma   weight residual
   117.79  117.91   -0.12 1.22e+00 6.72e-01 9.65e-03
angle pdb=" CB  TYR A  56 "
      pdb=" CG  TYR A  56 "
      pdb=" CD1 TYR A  56 "
    ideal   model   delta    sigma   weight residual
   120.80  120.95   -0.15 1.50e+00 4.44e-01 9.51e-03
angle pdb=" CB  TYR A  26 "
      pdb=" CG  TYR A  26 "
      pdb=" CD2 TYR A  26 "
    ideal   model   delta    sigma   weight residual
   120.80  120.65    0.15 1.50e+00 4.44e-01 9.50e-03
angle pdb=" CG  GLU A  51 "
      pdb=" CD  GLU A  51 "
      pdb=" OE1 GLU A  51 "
    ideal   model   delta    sigma   weight residual
   118.40  118.62   -0.22 2.30e+00 1.89e-01 9.23e-03
angle pdb=" CD1 LEU A  32 "
      pdb=" CG  LEU A  32 "
      pdb=" CD2 LEU A  32 "
    ideal   model   delta    sigma   weight residual
   110.80  111.01   -0.21 2.20e+00 2.07e-01 9.22e-03
angle pdb=" N   TYR A  61 "
      pdb=" CA  TYR A  61 "
      pdb=" C   TYR A  61 "
    ideal   model   delta    sigma   weight residual
   109.41  109.56   -0.15 1.52e+00 4.33e-01 9.22e-03
angle pdb=" N   ALA A  57 "
      pdb=" CA  ALA A  57 "
      pdb=" CB  ALA A  57 "
    ideal   model   delta    sigma   weight residual
   110.05  109.91    0.14 1.44e+00 4.82e-01 9.20e-03
angle pdb=" O   VAL A  63 "
      pdb=" C   VAL A  63 "
      pdb=" N   HIS A  64 "
    ideal   model   delta    sigma   weight residual
   122.95  123.06   -0.11 1.14e+00 7.69e-01 8.85e-03
angle pdb=" CG  GLU A  40 "
      pdb=" CD  GLU A  40 "
      pdb=" OE1 GLU A  40 "
    ideal   model   delta    sigma   weight residual
   118.40  118.62   -0.22 2.30e+00 1.89e-01 8.85e-03
angle pdb=" CB  LEU A  37 "
      pdb=" CG  LEU A  37 "
      pdb=" CD1 LEU A  37 "
    ideal   model   delta    sigma   weight residual
   110.70  110.42    0.28 3.00e+00 1.11e-01 8.83e-03
angle pdb=" CA  SER A  66 "
      pdb=" C   SER A  66 "
      pdb=" O   SER A  66 "
    ideal   model   delta    sigma   weight residual
   118.91  119.06   -0.15 1.60e+00 3.91e-01 8.80e-03
angle pdb=" CA  LYS A  46 "
      pdb=" C   LYS A  46 "
      pdb=" O   LYS A  46 "
    ideal   model   delta    sigma   weight residual
   120.80  120.90   -0.10 1.11e+00 8.12e-01 8.75e-03
angle pdb=" CA  TYR A  34 "
      pdb=" C   TYR A  34 "
      pdb=" N   VAL A  35 "
    ideal   model   delta    sigma   weight residual
   116.39  116.50   -0.11 1.17e+00 7.31e-01 8.66e-03
angle pdb=" CA  PRO A  58 "
      pdb=" N   PRO A  58 "
      pdb=" CD  PRO A  58 "
    ideal   model   delta    sigma   weight residual
   112.00  111.87    0.13 1.40e+00 5.10e-01 8.58e-03
angle pdb=" CG  GLN A  72 "
      pdb=" CD  GLN A  72 "
      pdb=" OE1 GLN A  72 "
    ideal   model   delta    sigma   weight residual
   120.80  120.99   -0.19 2.00e+00 2.50e-01 8.56e-03
angle pdb=" CD2 TYR A  41 "
      pdb=" CE2 TYR A  41 "
      pdb=" CZ  TYR A  41 "
    ideal   model   delta    sigma   weight residual
   119.60  119.43    0.17 1.80e+00 3.09e-01 8.51e-03
angle pdb=" CA  TYR A  41 "
      pdb=" C   TYR A  41 "
      pdb=" N   PRO A  42 "
    ideal   model   delta    sigma   weight residual
   117.62  117.50    0.12 1.32e+00 5.74e-01 8.45e-03
angle pdb=" CA  THR A  62 "
      pdb=" CB  THR A  62 "
      pdb=" OG1 THR A  62 "
    ideal   model   delta    sigma   weight residual
   109.60  109.74   -0.14 1.50e+00 4.44e-01 8.25e-03
angle pdb=" O   LEU A  83 "
      pdb=" C   LEU A  83 "
      pdb=" N   VAL A  84 "
    ideal   model   delta    sigma   weight residual
   123.10  123.20   -0.10 1.15e+00 7.56e-01 8.22e-03
angle pdb=" O   VAL A  35 "
      pdb=" C   VAL A  35 "
      pdb=" N   ASP A  36 "
    ideal   model   delta    sigma   weight residual
   123.18  123.08    0.10 1.05e+00 9.07e-01 8.22e-03
angle pdb=" CA  TYR A  41 "
      pdb=" CB  TYR A  41 "
      pdb=" CG  TYR A  41 "
    ideal   model   delta    sigma   weight residual
   113.90  113.74    0.16 1.80e+00 3.09e-01 8.20e-03
angle pdb=" C   GLN A  53 "
      pdb=" CA  GLN A  53 "
      pdb=" CB  GLN A  53 "
    ideal   model   delta    sigma   weight residual
   109.41  109.56   -0.15 1.62e+00 3.81e-01 8.20e-03
angle pdb=" C   PRO A  85 "
      pdb=" CA  PRO A  85 "
      pdb=" CB  PRO A  85 "
    ideal   model   delta    sigma   weight residual
   110.10  110.27   -0.17 1.90e+00 2.77e-01 8.18e-03
angle pdb=" CA  GLY A  18 "
      pdb=" C   GLY A  18 "
      pdb=" O   GLY A  18 "
    ideal   model   delta    sigma   weight residual
   121.63  121.72   -0.09 9.50e-01 1.11e+00 8.11e-03
angle pdb=" CB  ASN A  29 "
      pdb=" CG  ASN A  29 "
      pdb=" OD1 ASN A  29 "
    ideal   model   delta    sigma   weight residual
   120.80  120.62    0.18 2.00e+00 2.50e-01 8.07e-03
angle pdb=" CB  PRO A  58 "
      pdb=" CG  PRO A  58 "
      pdb=" CD  PRO A  58 "
    ideal   model   delta    sigma   weight residual
   106.10  105.82    0.28 3.20e+00 9.77e-02 7.92e-03
angle pdb=" O   PHE A  13 "
      pdb=" C   PHE A  13 "
      pdb=" N   THR A  14 "
    ideal   model   delta    sigma   weight residual
   123.19  123.07    0.12 1.30e+00 5.92e-01 7.90e-03
angle pdb=" N   VAL A  70 "
      pdb=" CA  VAL A  70 "
      pdb=" CB  VAL A  70 "
    ideal   model   delta    sigma   weight residual
   111.00  111.10   -0.10 1.14e+00 7.69e-01 7.80e-03
angle pdb=" CB  ARG A  21 "
      pdb=" CG  ARG A  21 "
      pdb=" CD  ARG A  21 "
    ideal   model   delta    sigma   weight residual
   111.30  111.50   -0.20 2.30e+00 1.89e-01 7.65e-03
angle pdb=" CA  VAL A  63 "
      pdb=" C   VAL A  63 "
      pdb=" O   VAL A  63 "
    ideal   model   delta    sigma   weight residual
   120.71  120.81   -0.10 1.13e+00 7.83e-01 7.59e-03
angle pdb=" C   ILE A   6 "
      pdb=" CA  ILE A   6 "
      pdb=" CB  ILE A   6 "
    ideal   model   delta    sigma   weight residual
   111.31  111.19    0.12 1.40e+00 5.10e-01 7.59e-03
angle pdb=" CA  ILE A   6 "
      pdb=" C   ILE A   6 "
      pdb=" O   ILE A   6 "
    ideal   model   delta    sigma   weight residual
   120.74  120.64    0.10 1.16e+00 7.43e-01 7.57e-03
angle pdb=" CG1 VAL A   4 "
      pdb=" CB  VAL A   4 "
      pdb=" CG2 VAL A   4 "
    ideal   model   delta    sigma   weight residual
   110.80  110.61    0.19 2.20e+00 2.07e-01 7.46e-03
angle pdb=" CG  GLN A  53 "
      pdb=" CD  GLN A  53 "
      pdb=" OE1 GLN A  53 "
    ideal   model   delta    sigma   weight residual
   120.80  120.97   -0.17 2.00e+00 2.50e-01 7.46e-03
angle pdb=" CD1 TYR A  56 "
      pdb=" CG  TYR A  56 "
      pdb=" CD2 TYR A  56 "
    ideal   model   delta    sigma   weight residual
   118.10  118.23   -0.13 1.50e+00 4.44e-01 7.37e-03
angle pdb=" CA  PRO A   8 "
      pdb=" N   PRO A   8 "
      pdb=" CD  PRO A   8 "
    ideal   model   delta    sigma   weight residual
   112.00  112.12   -0.12 1.40e+00 5.10e-01 7.36e-03
angle pdb=" CE1 PHE A  73 "
      pdb=" CZ  PHE A  73 "
      pdb=" CE2 PHE A  73 "
    ideal   model   delta    sigma   weight residual
   120.00  119.85    0.15 1.80e+00 3.09e-01 7.35e-03
angle pdb=" O   LEU A  32 "
      pdb=" C   LEU A  32 "
      pdb=" N   CYS A  33 "
    ideal   model   delta    sigma   weight residual
   123.03  123.13   -0.10 1.13e+00 7.83e-01 7.35e-03
angle pdb=" CA  GLU A  30 "
      pdb=" C   GLU A  30 "
      pdb=" O   GLU A  30 "
    ideal   model   delta    sigma   weight residual
   120.70  120.61    0.09 1.08e+00 8.57e-01 7.33e-03
angle pdb=" CB  LEU A  76 "
      pdb=" CG  LEU A  76 "
      pdb=" CD2 LEU A  76 "
    ideal   model   delta    sigma   weight residual
   110.70  110.96   -0.26 3.00e+00 1.11e-01 7.33e-03
angle pdb=" CA  GLY A  38 "
      pdb=" C   GLY A  38 "
      pdb=" N   ASN A  39 "
    ideal   model   delta    sigma   weight residual
   118.42  118.53   -0.11 1.26e+00 6.30e-01 7.30e-03
angle pdb=" CA  GLU A   5 "
      pdb=" C   GLU A   5 "
      pdb=" O   GLU A   5 "
    ideal   model   delta    sigma   weight residual
   120.66  120.76   -0.10 1.15e+00 7.56e-01 7.30e-03
angle pdb=" C   PRO A  25 "
      pdb=" N   TYR A  26 "
      pdb=" CA  TYR A  26 "
    ideal   model   delta    sigma   weight residual
   122.59  122.72   -0.13 1.57e+00 4.06e-01 7.10e-03
angle pdb=" O   GLN A  10 "
      pdb=" C   GLN A  10 "
      pdb=" N   ALA A  11 "
    ideal   model   delta    sigma   weight residual
   122.26  122.36   -0.10 1.23e+00 6.61e-01 7.02e-03
angle pdb=" CD1 TYR A  34 "
      pdb=" CG  TYR A  34 "
      pdb=" CD2 TYR A  34 "
    ideal   model   delta    sigma   weight residual
   118.10  118.23   -0.13 1.50e+00 4.44e-01 6.99e-03
angle pdb=" CA  MSE A  77 "
      pdb=" C   MSE A  77 "
      pdb=" N   ILE A  78 "
    ideal   model   delta    sigma   weight residual
   115.46  115.59   -0.13 1.57e+00 4.06e-01 6.97e-03
angle pdb=" CA  SER A  67 "
      pdb=" C   SER A  67 "
      pdb=" O   SER A  67 "
    ideal   model   delta    sigma   weight residual
   119.38  119.28    0.10 1.23e+00 6.61e-01 6.87e-03
angle pdb=" CG1 VAL A  35 "
      pdb=" CB  VAL A  35 "
      pdb=" CG2 VAL A  35 "
    ideal   model   delta    sigma   weight residual
   110.80  110.62    0.18 2.20e+00 2.07e-01 6.80e-03
angle pdb=" N   CYS A  33 "
      pdb=" CA  CYS A  33 "
      pdb=" CB  CYS A  33 "
    ideal   model   delta    sigma   weight residual
   111.46  111.59   -0.13 1.54e+00 4.22e-01 6.78e-03
angle pdb=" O   THR A  48 "
      pdb=" C   THR A  48 "
      pdb=" N   LEU A  49 "
    ideal   model   delta    sigma   weight residual
   123.05  123.15   -0.10 1.19e+00 7.06e-01 6.74e-03
angle pdb=" CG  GLN A  10 "
      pdb=" CD  GLN A  10 "
      pdb=" NE2 GLN A  10 "
    ideal   model   delta    sigma   weight residual
   116.40  116.52   -0.12 1.50e+00 4.44e-01 6.62e-03
angle pdb=" O   GLN A  12 "
      pdb=" C   GLN A  12 "
      pdb=" N   PHE A  13 "
    ideal   model   delta    sigma   weight residual
   122.97  123.08   -0.11 1.39e+00 5.18e-01 6.51e-03
angle pdb=" CB  LEU A  65 "
      pdb=" CG  LEU A  65 "
      pdb=" CD1 LEU A  65 "
    ideal   model   delta    sigma   weight residual
   110.70  110.46    0.24 3.00e+00 1.11e-01 6.39e-03
angle pdb=" C   PRO A   8 "
      pdb=" N   SER A   9 "
      pdb=" CA  SER A   9 "
    ideal   model   delta    sigma   weight residual
   121.94  122.10   -0.16 2.00e+00 2.50e-01 6.38e-03
angle pdb=" CA  GLN A  22 "
      pdb=" C   GLN A  22 "
      pdb=" O   GLN A  22 "
    ideal   model   delta    sigma   weight residual
   119.59  119.49    0.10 1.23e+00 6.61e-01 6.38e-03
angle pdb=" CA  LEU A  60 "
      pdb=" CB  LEU A  60 "
      pdb=" CG  LEU A  60 "
    ideal   model   delta    sigma   weight residual
   116.30  116.02    0.28 3.50e+00 8.16e-02 6.36e-03
angle pdb=" C   THR A  15 "
      pdb=" CA  THR A  15 "
      pdb=" CB  THR A  15 "
    ideal   model   delta    sigma   weight residual
   110.19  110.06    0.13 1.64e+00 3.72e-01 6.33e-03
angle pdb=" CA  GLN A  12 "
      pdb=" C   GLN A  12 "
      pdb=" O   GLN A  12 "
    ideal   model   delta    sigma   weight residual
   121.78  121.68    0.10 1.28e+00 6.10e-01 6.21e-03
angle pdb=" O   GLY A  71 "
      pdb=" C   GLY A  71 "
      pdb=" N   GLN A  72 "
    ideal   model   delta    sigma   weight residual
   122.59  122.67   -0.08 1.03e+00 9.43e-01 6.16e-03
angle pdb=" CG  GLN A  22 "
      pdb=" CD  GLN A  22 "
      pdb=" NE2 GLN A  22 "
    ideal   model   delta    sigma   weight residual
   116.40  116.28    0.12 1.50e+00 4.44e-01 6.15e-03
angle pdb=" CA  GLN A  10 "
      pdb=" C   GLN A  10 "
      pdb=" N   ALA A  11 "
    ideal   model   delta    sigma   weight residual
   117.71  117.61    0.10 1.28e+00 6.10e-01 6.04e-03
angle pdb=" CA  TYR A  34 "
      pdb=" C   TYR A  34 "
      pdb=" O   TYR A  34 "
    ideal   model   delta    sigma   weight residual
   120.30  120.22    0.08 1.07e+00 8.73e-01 5.93e-03
angle pdb=" CD  ARG A  80 "
      pdb=" NE  ARG A  80 "
      pdb=" CZ  ARG A  80 "
    ideal   model   delta    sigma   weight residual
   124.40  124.51   -0.11 1.40e+00 5.10e-01 5.92e-03
angle pdb=" N   PRO A  25 "
      pdb=" CA  PRO A  25 "
      pdb=" C   PRO A  25 "
    ideal   model   delta    sigma   weight residual
   111.68  111.81   -0.13 1.67e+00 3.59e-01 5.73e-03
angle pdb=" CE1 TYR A  56 "
      pdb=" CZ  TYR A  56 "
      pdb=" CE2 TYR A  56 "
    ideal   model   delta    sigma   weight residual
   120.30  120.45   -0.15 2.00e+00 2.50e-01 5.73e-03
angle pdb=" C   GLU A  51 "
      pdb=" N   GLY A  52 "
      pdb=" CA  GLY A  52 "
    ideal   model   delta    sigma   weight residual
   122.86  122.98   -0.12 1.62e+00 3.81e-01 5.67e-03
angle pdb=" N   ASP A  36 "
      pdb=" CA  ASP A  36 "
      pdb=" CB  ASP A  36 "
    ideal   model   delta    sigma   weight residual
   110.21  110.33   -0.12 1.59e+00 3.96e-01 5.63e-03
angle pdb=" NE  ARG A  16 "
      pdb=" CZ  ARG A  16 "
      pdb=" NH1 ARG A  16 "
    ideal   model   delta    sigma   weight residual
   121.50  121.57   -0.07 1.00e+00 1.00e+00 5.61e-03
angle pdb=" C   GLU A   5 "
      pdb=" N   ILE A   6 "
      pdb=" CA  ILE A   6 "
    ideal   model   delta    sigma   weight residual
   122.93  123.03   -0.10 1.31e+00 5.83e-01 5.59e-03
angle pdb=" CG1 ILE A   2 "
      pdb=" CB  ILE A   2 "
      pdb=" CG2 ILE A   2 "
    ideal   model   delta    sigma   weight residual
   110.70  110.48    0.22 3.00e+00 1.11e-01 5.53e-03
angle pdb=" CD1 PHE A  13 "
      pdb=" CG  PHE A  13 "
      pdb=" CD2 PHE A  13 "
    ideal   model   delta    sigma   weight residual
   118.60  118.49    0.11 1.50e+00 4.44e-01 5.53e-03
angle pdb=" CA  SER A  17 "
      pdb=" C   SER A  17 "
      pdb=" O   SER A  17 "
    ideal   model   delta    sigma   weight residual
   121.56  121.47    0.09 1.21e+00 6.83e-01 5.50e-03
angle pdb=" CG  GLU A  30 "
      pdb=" CD  GLU A  30 "
      pdb=" OE1 GLU A  30 "
    ideal   model   delta    sigma   weight residual
   118.40  118.57   -0.17 2.30e+00 1.89e-01 5.49e-03
angle pdb=" CE1 TYR A  34 "
      pdb=" CZ  TYR A  34 "
      pdb=" OH  TYR A  34 "
    ideal   model   delta    sigma   weight residual
   119.90  119.68    0.22 3.00e+00 1.11e-01 5.44e-03
angle pdb=" CA  TYR A  56 "
      pdb=" C   TYR A  56 "
      pdb=" O   TYR A  56 "
    ideal   model   delta    sigma   weight residual
   121.19  121.11    0.08 1.10e+00 8.26e-01 5.39e-03
angle pdb=" O   LEU A  37 "
      pdb=" C   LEU A  37 "
      pdb=" N   GLY A  38 "
    ideal   model   delta    sigma   weight residual
   122.35  122.26    0.09 1.23e+00 6.61e-01 5.25e-03
angle pdb=" CG  TYR A  34 "
      pdb=" CD2 TYR A  34 "
      pdb=" CE2 TYR A  34 "
    ideal   model   delta    sigma   weight residual
   121.20  121.09    0.11 1.50e+00 4.44e-01 5.25e-03
angle pdb=" NE  ARG A  16 "
      pdb=" CZ  ARG A  16 "
      pdb=" NH2 ARG A  16 "
    ideal   model   delta    sigma   weight residual
   119.20  119.14    0.06 9.00e-01 1.23e+00 5.21e-03
angle pdb=" N   PHE A  73 "
      pdb=" CA  PHE A  73 "
      pdb=" C   PHE A  73 "
    ideal   model   delta    sigma   weight residual
   112.88  112.97   -0.09 1.29e+00 6.01e-01 5.14e-03
angle pdb=" C   LEU A  49 "
      pdb=" CA  LEU A  49 "
      pdb=" CB  LEU A  49 "
    ideal   model   delta    sigma   weight residual
   109.54  109.67   -0.13 1.84e+00 2.95e-01 5.01e-03
angle pdb=" CA  GLY A  74 "
      pdb=" C   GLY A  74 "
      pdb=" O   GLY A  74 "
    ideal   model   delta    sigma   weight residual
   119.10  119.02    0.08 1.09e+00 8.42e-01 4.94e-03
angle pdb=" OE1 GLN A  12 "
      pdb=" CD  GLN A  12 "
      pdb=" NE2 GLN A  12 "
    ideal   model   delta    sigma   weight residual
   122.60  122.67   -0.07 1.00e+00 1.00e+00 4.91e-03
angle pdb=" N   PHE A  68 "
      pdb=" CA  PHE A  68 "
      pdb=" CB  PHE A  68 "
    ideal   model   delta    sigma   weight residual
   110.85  110.74    0.11 1.60e+00 3.91e-01 4.90e-03
angle pdb=" CD2 HIS A  64 "
      pdb=" NE2 HIS A  64 "
      pdb=" CE1 HIS A  64 "
    ideal   model   delta    sigma   weight residual
   109.00  108.93    0.07 1.00e+00 1.00e+00 4.90e-03
angle pdb=" O   ARG A  80 "
      pdb=" C   ARG A  80 "
      pdb=" N   LEU A  81 "
    ideal   model   delta    sigma   weight residual
   123.41  123.33    0.08 1.17e+00 7.31e-01 4.84e-03
angle pdb=" CA  SER A  67 "
      pdb=" C   SER A  67 "
      pdb=" N   PHE A  68 "
    ideal   model   delta    sigma   weight residual
   118.14  118.23   -0.09 1.31e+00 5.83e-01 4.81e-03
angle pdb=" NE  ARG A  80 "
      pdb=" CZ  ARG A  80 "
      pdb=" NH1 ARG A  80 "
    ideal   model   delta    sigma   weight residual
   121.50  121.43    0.07 1.00e+00 1.00e+00 4.80e-03
angle pdb=" C   LEU A  32 "
      pdb=" CA  LEU A  32 "
      pdb=" CB  LEU A  32 "
    ideal   model   delta    sigma   weight residual
   109.80  109.69    0.11 1.65e+00 3.67e-01 4.76e-03
angle pdb=" N   GLU A  40 "
      pdb=" CA  GLU A  40 "
      pdb=" CB  GLU A  40 "
    ideal   model   delta    sigma   weight residual
   110.12  110.22   -0.10 1.47e+00 4.63e-01 4.76e-03
angle pdb=" CA  THR A  15 "
      pdb=" C   THR A  15 "
      pdb=" O   THR A  15 "
    ideal   model   delta    sigma   weight residual
   120.32  120.40   -0.08 1.10e+00 8.26e-01 4.70e-03
angle pdb=" O   MSE A  77 "
      pdb=" C   MSE A  77 "
      pdb=" N   ILE A  78 "
    ideal   model   delta    sigma   weight residual
   122.96  122.87    0.09 1.26e+00 6.30e-01 4.65e-03
angle pdb=" CG1 ILE A   6 "
      pdb=" CB  ILE A   6 "
      pdb=" CG2 ILE A   6 "
    ideal   model   delta    sigma   weight residual
   110.70  110.90   -0.20 3.00e+00 1.11e-01 4.65e-03
angle pdb=" CD1 LEU A  60 "
      pdb=" CG  LEU A  60 "
      pdb=" CD2 LEU A  60 "
    ideal   model   delta    sigma   weight residual
   110.80  110.65    0.15 2.20e+00 2.07e-01 4.56e-03
angle pdb=" CA  ASP A  79 "
      pdb=" C   ASP A  79 "
      pdb=" O   ASP A  79 "
    ideal   model   delta    sigma   weight residual
   120.51  120.61   -0.10 1.43e+00 4.89e-01 4.52e-03
angle pdb=" CA  LEU A  76 "
      pdb=" C   LEU A  76 "
      pdb=" O   LEU A  76 "
    ideal   model   delta    sigma   weight residual
   121.16  121.09    0.07 1.12e+00 7.97e-01 4.44e-03
angle pdb=" CE2 TYR A  61 "
      pdb=" CZ  TYR A  61 "
      pdb=" OH  TYR A  61 "
    ideal   model   delta    sigma   weight residual
   119.90  119.70    0.20 3.00e+00 1.11e-01 4.43e-03
angle pdb=" O   ILE A  78 "
      pdb=" C   ILE A  78 "
      pdb=" N   ASP A  79 "
    ideal   model   delta    sigma   weight residual
   123.10  123.18   -0.08 1.17e+00 7.31e-01 4.40e-03
angle pdb=" CA  VAL A  84 "
      pdb=" CB  VAL A  84 "
      pdb=" CG2 VAL A  84 "
    ideal   model   delta    sigma   weight residual
   110.40  110.51   -0.11 1.70e+00 3.46e-01 4.40e-03
angle pdb=" CG  LYS A  69 "
      pdb=" CD  LYS A  69 "
      pdb=" CE  LYS A  69 "
    ideal   model   delta    sigma   weight residual
   111.30  111.15    0.15 2.30e+00 1.89e-01 4.35e-03
angle pdb=" OE1 GLN A  22 "
      pdb=" CD  GLN A  22 "
      pdb=" NE2 GLN A  22 "
    ideal   model   delta    sigma   weight residual
   122.60  122.53    0.07 1.00e+00 1.00e+00 4.31e-03
angle pdb=" CA  TYR A  56 "
      pdb=" C   TYR A  56 "
      pdb=" N   ALA A  57 "
    ideal   model   delta    sigma   weight residual
   115.85  115.93   -0.08 1.29e+00 6.01e-01 4.30e-03
angle pdb=" CA  PRO A  58 "
      pdb=" CB  PRO A  58 "
      pdb=" CG  PRO A  58 "
    ideal   model   delta    sigma   weight residual
   104.50  104.38    0.12 1.90e+00 2.77e-01 4.24e-03
angle pdb=" C   MSE A  77 "
      pdb=" N   ILE A  78 "
      pdb=" CA  ILE A  78 "
    ideal   model   delta    sigma   weight residual
   123.12  123.04    0.08 1.30e+00 5.92e-01 4.22e-03
angle pdb=" CA  GLN A  10 "
      pdb=" C   GLN A  10 "
      pdb=" O   GLN A  10 "
    ideal   model   delta    sigma   weight residual
   119.95  120.03   -0.08 1.18e+00 7.18e-01 4.11e-03
angle pdb=" CA  THR A  14 "
      pdb=" CB  THR A  14 "
      pdb=" CG2 THR A  14 "
    ideal   model   delta    sigma   weight residual
   110.50  110.39    0.11 1.70e+00 3.46e-01 4.10e-03
angle pdb=" CA  ASN A  29 "
      pdb=" CB  ASN A  29 "
      pdb=" CG  ASN A  29 "
    ideal   model   delta    sigma   weight residual
   112.60  112.54    0.06 1.00e+00 1.00e+00 4.05e-03
angle pdb=" CD1 PHE A  73 "
      pdb=" CG  PHE A  73 "
      pdb=" CD2 PHE A  73 "
    ideal   model   delta    sigma   weight residual
   118.60  118.69   -0.09 1.50e+00 4.44e-01 3.96e-03
angle pdb=" CB  GLN A  31 "
      pdb=" CG  GLN A  31 "
      pdb=" CD  GLN A  31 "
    ideal   model   delta    sigma   weight residual
   112.60  112.49    0.11 1.70e+00 3.46e-01 3.86e-03
angle pdb=" CA  HIS A  64 "
      pdb=" C   HIS A  64 "
      pdb=" O   HIS A  64 "
    ideal   model   delta    sigma   weight residual
   121.47  121.54   -0.07 1.15e+00 7.56e-01 3.85e-03
angle pdb=" CE2 TYR A  56 "
      pdb=" CZ  TYR A  56 "
      pdb=" OH  TYR A  56 "
    ideal   model   delta    sigma   weight residual
   119.90  119.71    0.19 3.00e+00 1.11e-01 3.85e-03
angle pdb=" CE1 TYR A  61 "
      pdb=" CZ  TYR A  61 "
      pdb=" CE2 TYR A  61 "
    ideal   model   delta    sigma   weight residual
   120.30  120.42   -0.12 2.00e+00 2.50e-01 3.83e-03
angle pdb=" C   MSE A  77 "
      pdb=" CA  MSE A  77 "
      pdb=" CB  MSE A  77 "
    ideal   model   delta    sigma   weight residual
   110.67  110.81   -0.14 2.23e+00 2.01e-01 3.82e-03
angle pdb=" N   TYR A  26 "
      pdb=" CA  TYR A  26 "
      pdb=" CB  TYR A  26 "
    ideal   model   delta    sigma   weight residual
   111.55  111.66   -0.11 1.74e+00 3.30e-01 3.81e-03
angle pdb=" NH1 ARG A  82 "
      pdb=" CZ  ARG A  82 "
      pdb=" NH2 ARG A  82 "
    ideal   model   delta    sigma   weight residual
   119.30  119.38   -0.08 1.30e+00 5.92e-01 3.80e-03
angle pdb=" N   ALA A  57 "
      pdb=" CA  ALA A  57 "
      pdb=" C   ALA A  57 "
    ideal   model   delta    sigma   weight residual
   110.20  110.11    0.09 1.44e+00 4.82e-01 3.73e-03
angle pdb=" O   TYR A  56 "
      pdb=" C   TYR A  56 "
      pdb=" N   ALA A  57 "
    ideal   model   delta    sigma   weight residual
   122.87  122.94   -0.07 1.23e+00 6.61e-01 3.68e-03
angle pdb=" CG  PHE A  68 "
      pdb=" CD2 PHE A  68 "
      pdb=" CE2 PHE A  68 "
    ideal   model   delta    sigma   weight residual
   120.70  120.80   -0.10 1.70e+00 3.46e-01 3.67e-03
angle pdb=" CG  PHE A  73 "
      pdb=" CD2 PHE A  73 "
      pdb=" CE2 PHE A  73 "
    ideal   model   delta    sigma   weight residual
   120.70  120.80   -0.10 1.70e+00 3.46e-01 3.49e-03
angle pdb=" CB  PHE A  68 "
      pdb=" CG  PHE A  68 "
      pdb=" CD1 PHE A  68 "
    ideal   model   delta    sigma   weight residual
   120.70  120.60    0.10 1.70e+00 3.46e-01 3.46e-03
angle pdb=" CG  HIS A  64 "
      pdb=" ND1 HIS A  64 "
      pdb=" CE1 HIS A  64 "
    ideal   model   delta    sigma   weight residual
   109.30  109.40   -0.10 1.70e+00 3.46e-01 3.44e-03
angle pdb=" CB  PHE A  13 "
      pdb=" CG  PHE A  13 "
      pdb=" CD2 PHE A  13 "
    ideal   model   delta    sigma   weight residual
   120.70  120.60    0.10 1.70e+00 3.46e-01 3.35e-03
angle pdb=" C   VAL A  19 "
      pdb=" N   SER A  20 "
      pdb=" CA  SER A  20 "
    ideal   model   delta    sigma   weight residual
   121.66  121.77   -0.11 1.92e+00 2.71e-01 3.28e-03
angle pdb=" CE2 TYR A  26 "
      pdb=" CZ  TYR A  26 "
      pdb=" OH  TYR A  26 "
    ideal   model   delta    sigma   weight residual
   119.90  120.07   -0.17 3.00e+00 1.11e-01 3.28e-03
angle pdb=" CA  ILE A  47 "
      pdb=" CB  ILE A  47 "
      pdb=" CG2 ILE A  47 "
    ideal   model   delta    sigma   weight residual
   110.50  110.40    0.10 1.70e+00 3.46e-01 3.27e-03
angle pdb=" CD1 LEU A  65 "
      pdb=" CG  LEU A  65 "
      pdb=" CD2 LEU A  65 "
    ideal   model   delta    sigma   weight residual
   110.80  110.93   -0.13 2.20e+00 2.07e-01 3.27e-03
angle pdb=" CG  PHE A  13 "
      pdb=" CD2 PHE A  13 "
      pdb=" CE2 PHE A  13 "
    ideal   model   delta    sigma   weight residual
   120.70  120.79   -0.09 1.70e+00 3.46e-01 2.92e-03
angle pdb=" CA  PHE A  73 "
      pdb=" C   PHE A  73 "
      pdb=" O   PHE A  73 "
    ideal   model   delta    sigma   weight residual
   119.59  119.53    0.06 1.18e+00 7.18e-01 2.90e-03
angle pdb=" CD2 PHE A  13 "
      pdb=" CE2 PHE A  13 "
      pdb=" CZ  PHE A  13 "
    ideal   model   delta    sigma   weight residual
   120.00  120.10   -0.10 1.80e+00 3.09e-01 2.87e-03
angle pdb=" CG  GLU A  51 "
      pdb=" CD  GLU A  51 "
      pdb=" OE2 GLU A  51 "
    ideal   model   delta    sigma   weight residual
   118.40  118.52   -0.12 2.30e+00 1.89e-01 2.83e-03
angle pdb=" O   ASP A  50 "
      pdb=" C   ASP A  50 "
      pdb=" N   GLU A  51 "
    ideal   model   delta    sigma   weight residual
   122.79  122.73    0.06 1.14e+00 7.69e-01 2.83e-03
angle pdb=" CA  THR A  15 "
      pdb=" CB  THR A  15 "
      pdb=" CG2 THR A  15 "
    ideal   model   delta    sigma   weight residual
   110.50  110.59   -0.09 1.70e+00 3.46e-01 2.81e-03
angle pdb=" CA  LYS A  69 "
      pdb=" C   LYS A  69 "
      pdb=" O   LYS A  69 "
    ideal   model   delta    sigma   weight residual
   121.45  121.39    0.06 1.07e+00 8.73e-01 2.79e-03
angle pdb=" CA  GLY A  38 "
      pdb=" C   GLY A  38 "
      pdb=" O   GLY A  38 "
    ideal   model   delta    sigma   weight residual
   119.13  119.07    0.06 1.22e+00 6.72e-01 2.79e-03
angle pdb=" N   PRO A  58 "
      pdb=" CA  PRO A  58 "
      pdb=" CB  PRO A  58 "
    ideal   model   delta    sigma   weight residual
   103.31  103.36   -0.05 8.90e-01 1.26e+00 2.72e-03
angle pdb=" CB  TYR A  61 "
      pdb=" CG  TYR A  61 "
      pdb=" CD2 TYR A  61 "
    ideal   model   delta    sigma   weight residual
   120.80  120.88   -0.08 1.50e+00 4.44e-01 2.71e-03
angle pdb=" CB  ARG A  16 "
      pdb=" CG  ARG A  16 "
      pdb=" CD  ARG A  16 "
    ideal   model   delta    sigma   weight residual
   111.30  111.42   -0.12 2.30e+00 1.89e-01 2.66e-03
angle pdb=" CA  SER A  75 "
      pdb=" C   SER A  75 "
      pdb=" O   SER A  75 "
    ideal   model   delta    sigma   weight residual
   121.72  121.78   -0.06 1.18e+00 7.18e-01 2.61e-03
angle pdb=" CG  GLN A  10 "
      pdb=" CD  GLN A  10 "
      pdb=" OE1 GLN A  10 "
    ideal   model   delta    sigma   weight residual
   120.80  120.90   -0.10 2.00e+00 2.50e-01 2.61e-03
angle pdb=" CA  SER A  75 "
      pdb=" CB  SER A  75 "
      pdb=" OG  SER A  75 "
    ideal   model   delta    sigma   weight residual
   111.10  111.00    0.10 2.00e+00 2.50e-01 2.60e-03
angle pdb=" O   ILE A   6 "
      pdb=" C   ILE A   6 "
      pdb=" N   LYS A   7 "
    ideal   model   delta    sigma   weight residual
   122.76  122.69    0.07 1.47e+00 4.63e-01 2.57e-03
angle pdb=" C   ALA A  57 "
      pdb=" N   PRO A  58 "
      pdb=" CA  PRO A  58 "
    ideal   model   delta    sigma   weight residual
   119.76  119.81   -0.05 1.03e+00 9.43e-01 2.57e-03
angle pdb=" CA  LYS A   3 "
      pdb=" C   LYS A   3 "
      pdb=" N   VAL A   4 "
    ideal   model   delta    sigma   weight residual
   116.25  116.19    0.06 1.23e+00 6.61e-01 2.55e-03
angle pdb=" CA  TYR A  41 "
      pdb=" C   TYR A  41 "
      pdb=" O   TYR A  41 "
    ideal   model   delta    sigma   weight residual
   120.46  120.40    0.06 1.13e+00 7.83e-01 2.54e-03
angle pdb=" O   THR A  14 "
      pdb=" C   THR A  14 "
      pdb=" N   THR A  15 "
    ideal   model   delta    sigma   weight residual
   123.16  123.22   -0.06 1.26e+00 6.30e-01 2.53e-03
angle pdb=" O   LEU A  49 "
      pdb=" C   LEU A  49 "
      pdb=" N   ASP A  50 "
    ideal   model   delta    sigma   weight residual
   122.86  122.92   -0.06 1.18e+00 7.18e-01 2.45e-03
angle pdb=" N   GLN A  12 "
      pdb=" CA  GLN A  12 "
      pdb=" C   GLN A  12 "
    ideal   model   delta    sigma   weight residual
   110.14  110.21   -0.07 1.47e+00 4.63e-01 2.38e-03
angle pdb=" N   ARG A  82 "
      pdb=" CA  ARG A  82 "
      pdb=" CB  ARG A  82 "
    ideal   model   delta    sigma   weight residual
   110.55  110.63   -0.08 1.57e+00 4.06e-01 2.38e-03
angle pdb=" O   PHE A  73 "
      pdb=" C   PHE A  73 "
      pdb=" N   GLY A  74 "
    ideal   model   delta    sigma   weight residual
   122.25  122.19    0.06 1.19e+00 7.06e-01 2.35e-03
angle pdb=" CD  ARG A  16 "
      pdb=" NE  ARG A  16 "
      pdb=" CZ  ARG A  16 "
    ideal   model   delta    sigma   weight residual
   124.40  124.33    0.07 1.40e+00 5.10e-01 2.32e-03
angle pdb=" N   THR A  62 "
      pdb=" CA  THR A  62 "
      pdb=" CB  THR A  62 "
    ideal   model   delta    sigma   weight residual
   111.43  111.51   -0.08 1.59e+00 3.96e-01 2.29e-03
angle pdb=" N   SER A  67 "
      pdb=" CA  SER A  67 "
      pdb=" C   SER A  67 "
    ideal   model   delta    sigma   weight residual
   112.54  112.48    0.06 1.22e+00 6.72e-01 2.26e-03
angle pdb=" C   LEU A  49 "
      pdb=" N   ASP A  50 "
      pdb=" CA  ASP A  50 "
    ideal   model   delta    sigma   weight residual
   120.97  121.06   -0.09 1.82e+00 3.02e-01 2.24e-03
angle pdb=" CA  VAL A  35 "
      pdb=" CB  VAL A  35 "
      pdb=" CG2 VAL A  35 "
    ideal   model   delta    sigma   weight residual
   110.40  110.32    0.08 1.70e+00 3.46e-01 2.22e-03
angle pdb=" CA  THR A  15 "
      pdb=" C   THR A  15 "
      pdb=" N   ARG A  16 "
    ideal   model   delta    sigma   weight residual
   116.37  116.31    0.06 1.19e+00 7.06e-01 2.19e-03
angle pdb=" C   PRO A  58 "
      pdb=" CA  PRO A  58 "
      pdb=" CB  PRO A  58 "
    ideal   model   delta    sigma   weight residual
   111.46  111.52   -0.06 1.29e+00 6.01e-01 2.18e-03
angle pdb=" O   LYS A   3 "
      pdb=" C   LYS A   3 "
      pdb=" N   VAL A   4 "
    ideal   model   delta    sigma   weight residual
   123.27  123.22    0.05 1.13e+00 7.83e-01 2.15e-03
angle pdb=" CA  LEU A  32 "
      pdb=" C   LEU A  32 "
      pdb=" N   CYS A  33 "
    ideal   model   delta    sigma   weight residual
   115.23  115.17    0.06 1.30e+00 5.92e-01 2.14e-03
angle pdb=" CB  ASN A  39 "
      pdb=" CG  ASN A  39 "
      pdb=" OD1 ASN A  39 "
    ideal   model   delta    sigma   weight residual
   120.80  120.89   -0.09 2.00e+00 2.50e-01 2.08e-03
angle pdb=" O   SER A  67 "
      pdb=" C   SER A  67 "
      pdb=" N   PHE A  68 "
    ideal   model   delta    sigma   weight residual
   122.43  122.49   -0.06 1.34e+00 5.57e-01 2.07e-03
angle pdb=" CA  GLU A  51 "
      pdb=" C   GLU A  51 "
      pdb=" N   GLY A  52 "
    ideal   model   delta    sigma   weight residual
   115.88  115.82    0.06 1.28e+00 6.10e-01 2.03e-03
angle pdb=" C   PRO A  42 "
      pdb=" N   VAL A  43 "
      pdb=" CA  VAL A  43 "
    ideal   model   delta    sigma   weight residual
   122.68  122.75   -0.07 1.50e+00 4.44e-01 2.02e-03
angle pdb=" N   MSE A  77 "
      pdb=" CA  MSE A  77 "
      pdb=" CB  MSE A  77 "
    ideal   model   delta    sigma   weight residual
   111.62  111.55    0.07 1.62e+00 3.81e-01 2.01e-03
angle pdb=" C   LEU A  28 "
      pdb=" CA  LEU A  28 "
      pdb=" CB  LEU A  28 "
    ideal   model   delta    sigma   weight residual
   109.71  109.63    0.08 1.83e+00 2.99e-01 1.98e-03
angle pdb=" CA  CYS A  33 "
      pdb=" C   CYS A  33 "
      pdb=" N   TYR A  34 "
    ideal   model   delta    sigma   weight residual
   115.31  115.25    0.06 1.36e+00 5.41e-01 1.93e-03
angle pdb=" CB  ASN A  39 "
      pdb=" CG  ASN A  39 "
      pdb=" ND2 ASN A  39 "
    ideal   model   delta    sigma   weight residual
   116.40  116.47   -0.07 1.50e+00 4.44e-01 1.92e-03
angle pdb=" O   ILE A  47 "
      pdb=" C   ILE A  47 "
      pdb=" N   THR A  48 "
    ideal   model   delta    sigma   weight residual
   123.18  123.23   -0.05 1.08e+00 8.57e-01 1.91e-03
angle pdb=" CD1 TYR A  34 "
      pdb=" CE1 TYR A  34 "
      pdb=" CZ  TYR A  34 "
    ideal   model   delta    sigma   weight residual
   119.60  119.52    0.08 1.80e+00 3.09e-01 1.87e-03
angle pdb=" C   ASN A  29 "
      pdb=" N   GLU A  30 "
      pdb=" CA  GLU A  30 "
    ideal   model   delta    sigma   weight residual
   122.94  123.00   -0.06 1.50e+00 4.44e-01 1.87e-03
angle pdb=" CD2 PHE A  73 "
      pdb=" CE2 PHE A  73 "
      pdb=" CZ  PHE A  73 "
    ideal   model   delta    sigma   weight residual
   120.00  119.92    0.08 1.80e+00 3.09e-01 1.85e-03
angle pdb=" OD1 ASN A  39 "
      pdb=" CG  ASN A  39 "
      pdb=" ND2 ASN A  39 "
    ideal   model   delta    sigma   weight residual
   122.60  122.64   -0.04 1.00e+00 1.00e+00 1.84e-03
angle pdb=" NE  ARG A  82 "
      pdb=" CZ  ARG A  82 "
      pdb=" NH2 ARG A  82 "
    ideal   model   delta    sigma   weight residual
   119.20  119.16    0.04 9.00e-01 1.23e+00 1.80e-03
angle pdb=" NE  ARG A  82 "
      pdb=" CZ  ARG A  82 "
      pdb=" NH1 ARG A  82 "
    ideal   model   delta    sigma   weight residual
   121.50  121.46    0.04 1.00e+00 1.00e+00 1.77e-03
angle pdb=" C   LEU A  76 "
      pdb=" N   MSE A  77 "
      pdb=" CA  MSE A  77 "
    ideal   model   delta    sigma   weight residual
   122.36  122.43   -0.07 1.60e+00 3.91e-01 1.75e-03
angle pdb=" CD2 TYR A  34 "
      pdb=" CE2 TYR A  34 "
      pdb=" CZ  TYR A  34 "
    ideal   model   delta    sigma   weight residual
   119.60  119.52    0.08 1.80e+00 3.09e-01 1.75e-03
angle pdb=" CG  TYR A  34 "
      pdb=" CD1 TYR A  34 "
      pdb=" CE1 TYR A  34 "
    ideal   model   delta    sigma   weight residual
   121.20  121.14    0.06 1.50e+00 4.44e-01 1.73e-03
angle pdb=" CA  THR A  48 "
      pdb=" CB  THR A  48 "
      pdb=" CG2 THR A  48 "
    ideal   model   delta    sigma   weight residual
   110.50  110.43    0.07 1.70e+00 3.46e-01 1.73e-03
angle pdb=" CA  SER A  66 "
      pdb=" CB  SER A  66 "
      pdb=" OG  SER A  66 "
    ideal   model   delta    sigma   weight residual
   111.10  111.02    0.08 2.00e+00 2.50e-01 1.72e-03
angle pdb=" CA  LEU A  37 "
      pdb=" C   LEU A  37 "
      pdb=" O   LEU A  37 "
    ideal   model   delta    sigma   weight residual
   119.78  119.83   -0.05 1.19e+00 7.06e-01 1.71e-03
angle pdb=" CA  ARG A  21 "
      pdb=" CB  ARG A  21 "
      pdb=" CG  ARG A  21 "
    ideal   model   delta    sigma   weight residual
   114.10  114.02    0.08 2.00e+00 2.50e-01 1.68e-03
angle pdb=" N   VAL A   4 "
      pdb=" CA  VAL A   4 "
      pdb=" CB  VAL A   4 "
    ideal   model   delta    sigma   weight residual
   111.39  111.46   -0.07 1.74e+00 3.30e-01 1.54e-03
angle pdb=" NE  ARG A  80 "
      pdb=" CZ  ARG A  80 "
      pdb=" NH2 ARG A  80 "
    ideal   model   delta    sigma   weight residual
   119.20  119.23   -0.03 9.00e-01 1.23e+00 1.50e-03
angle pdb=" CB  PHE A  73 "
      pdb=" CG  PHE A  73 "
      pdb=" CD2 PHE A  73 "
    ideal   model   delta    sigma   weight residual
   120.70  120.64    0.06 1.70e+00 3.46e-01 1.44e-03
angle pdb=" CG  GLU A  40 "
      pdb=" CD  GLU A  40 "
      pdb=" OE2 GLU A  40 "
    ideal   model   delta    sigma   weight residual
   118.40  118.49   -0.09 2.30e+00 1.89e-01 1.44e-03
angle pdb=" CG  GLN A  31 "
      pdb=" CD  GLN A  31 "
      pdb=" NE2 GLN A  31 "
    ideal   model   delta    sigma   weight residual
   116.40  116.34    0.06 1.50e+00 4.44e-01 1.43e-03
angle pdb=" CA  GLN A  72 "
      pdb=" C   GLN A  72 "
      pdb=" O   GLN A  72 "
    ideal   model   delta    sigma   weight residual
   119.05  119.00    0.05 1.30e+00 5.92e-01 1.42e-03
angle pdb=" CE1 PHE A  68 "
      pdb=" CZ  PHE A  68 "
      pdb=" CE2 PHE A  68 "
    ideal   model   delta    sigma   weight residual
   120.00  119.93    0.07 1.80e+00 3.09e-01 1.36e-03
angle pdb=" O   SER A  75 "
      pdb=" C   SER A  75 "
      pdb=" N   LEU A  76 "
    ideal   model   delta    sigma   weight residual
   122.94  122.98   -0.04 1.12e+00 7.97e-01 1.35e-03
angle pdb=" CA  LEU A  28 "
      pdb=" C   LEU A  28 "
      pdb=" O   LEU A  28 "
    ideal   model   delta    sigma   weight residual
   120.36  120.40   -0.04 1.08e+00 8.57e-01 1.34e-03
angle pdb=" CA  ARG A  80 "
      pdb=" C   ARG A  80 "
      pdb=" O   ARG A  80 "
    ideal   model   delta    sigma   weight residual
   120.54  120.50    0.04 1.23e+00 6.61e-01 1.33e-03
angle pdb=" CA  PRO A  58 "
      pdb=" C   PRO A  58 "
      pdb=" O   PRO A  58 "
    ideal   model   delta    sigma   weight residual
   121.34  121.30    0.04 1.14e+00 7.69e-01 1.32e-03
angle pdb=" OG1 THR A  14 "
      pdb=" CB  THR A  14 "
      pdb=" CG2 THR A  14 "
    ideal   model   delta    sigma   weight residual
   109.30  109.37   -0.07 2.00e+00 2.50e-01 1.32e-03
angle pdb=" CG  TYR A  56 "
      pdb=" CD1 TYR A  56 "
      pdb=" CE1 TYR A  56 "
    ideal   model   delta    sigma   weight residual
   121.20  121.15    0.05 1.50e+00 4.44e-01 1.32e-03
angle pdb=" CA  PRO A  25 "
      pdb=" N   PRO A  25 "
      pdb=" CD  PRO A  25 "
    ideal   model   delta    sigma   weight residual
   112.00  112.05   -0.05 1.40e+00 5.10e-01 1.22e-03
angle pdb=" O   ARG A  82 "
      pdb=" C   ARG A  82 "
      pdb=" N   LEU A  83 "
    ideal   model   delta    sigma   weight residual
   123.27  123.31   -0.04 1.18e+00 7.18e-01 1.22e-03
angle pdb=" CA  LEU A  32 "
      pdb=" C   LEU A  32 "
      pdb=" O   LEU A  32 "
    ideal   model   delta    sigma   weight residual
   121.66  121.70   -0.04 1.22e+00 6.72e-01 1.22e-03
angle pdb=" OE1 GLN A  72 "
      pdb=" CD  GLN A  72 "
      pdb=" NE2 GLN A  72 "
    ideal   model   delta    sigma   weight residual
   122.60  122.63   -0.03 1.00e+00 1.00e+00 1.16e-03
angle pdb=" CA  GLN A  53 "
      pdb=" C   GLN A  53 "
      pdb=" O   GLN A  53 "
    ideal   model   delta    sigma   weight residual
   119.76  119.79   -0.03 8.90e-01 1.26e+00 1.14e-03
angle pdb=" CG  TYR A  61 "
      pdb=" CD2 TYR A  61 "
      pdb=" CE2 TYR A  61 "
    ideal   model   delta    sigma   weight residual
   121.20  121.15    0.05 1.50e+00 4.44e-01 1.14e-03
angle pdb=" CA  PRO A   8 "
      pdb=" C   PRO A   8 "
      pdb=" O   PRO A   8 "
    ideal   model   delta    sigma   weight residual
   119.64  119.69   -0.05 1.58e+00 4.01e-01 1.13e-03
angle pdb=" CA  ARG A  82 "
      pdb=" C   ARG A  82 "
      pdb=" O   ARG A  82 "
    ideal   model   delta    sigma   weight residual
   120.32  120.28    0.04 1.10e+00 8.26e-01 1.10e-03
angle pdb=" CG  TYR A  61 "
      pdb=" CD1 TYR A  61 "
      pdb=" CE1 TYR A  61 "
    ideal   model   delta    sigma   weight residual
   121.20  121.15    0.05 1.50e+00 4.44e-01 1.10e-03
angle pdb=" CA  PHE A  73 "
      pdb=" CB  PHE A  73 "
      pdb=" CG  PHE A  73 "
    ideal   model   delta    sigma   weight residual
   113.80  113.83   -0.03 1.00e+00 1.00e+00 1.10e-03
angle pdb=" CA  GLN A  12 "
      pdb=" C   GLN A  12 "
      pdb=" N   PHE A  13 "
    ideal   model   delta    sigma   weight residual
   115.19  115.24   -0.05 1.48e+00 4.57e-01 1.08e-03
angle pdb=" O   GLN A  53 "
      pdb=" C   GLN A  53 "
      pdb=" N   PRO A  54 "
    ideal   model   delta    sigma   weight residual
   121.42  121.45   -0.03 1.06e+00 8.90e-01 1.05e-03
angle pdb=" CD2 TYR A  26 "
      pdb=" CE2 TYR A  26 "
      pdb=" CZ  TYR A  26 "
    ideal   model   delta    sigma   weight residual
   119.60  119.66   -0.06 1.80e+00 3.09e-01 9.79e-04
angle pdb=" CB  PHE A  68 "
      pdb=" CG  PHE A  68 "
      pdb=" CD2 PHE A  68 "
    ideal   model   delta    sigma   weight residual
   120.70  120.65    0.05 1.70e+00 3.46e-01 9.69e-04
angle pdb=" CG  GLU A  30 "
      pdb=" CD  GLU A  30 "
      pdb=" OE2 GLU A  30 "
    ideal   model   delta    sigma   weight residual
   118.40  118.47   -0.07 2.30e+00 1.89e-01 9.58e-04
angle pdb=" CD1 TYR A  56 "
      pdb=" CE1 TYR A  56 "
      pdb=" CZ  TYR A  56 "
    ideal   model   delta    sigma   weight residual
   119.60  119.54    0.06 1.80e+00 3.09e-01 9.50e-04
angle pdb=" CA  LEU A  49 "
      pdb=" C   LEU A  49 "
      pdb=" O   LEU A  49 "
    ideal   model   delta    sigma   weight residual
   121.56  121.59   -0.03 1.09e+00 8.42e-01 9.43e-04
angle pdb=" OG1 THR A  48 "
      pdb=" CB  THR A  48 "
      pdb=" CG2 THR A  48 "
    ideal   model   delta    sigma   weight residual
   109.30  109.36   -0.06 2.00e+00 2.50e-01 9.31e-04
angle pdb=" O   GLU A  51 "
      pdb=" C   GLU A  51 "
      pdb=" N   GLY A  52 "
    ideal   model   delta    sigma   weight residual
   122.89  122.85    0.04 1.22e+00 6.72e-01 9.01e-04
angle pdb=" CD1 TYR A  61 "
      pdb=" CG  TYR A  61 "
      pdb=" CD2 TYR A  61 "
    ideal   model   delta    sigma   weight residual
   118.10  118.14   -0.04 1.50e+00 4.44e-01 8.99e-04
angle pdb=" CD  ARG A  21 "
      pdb=" NE  ARG A  21 "
      pdb=" CZ  ARG A  21 "
    ideal   model   delta    sigma   weight residual
   124.40  124.36    0.04 1.40e+00 5.10e-01 8.80e-04
angle pdb=" C   TYR A  34 "
      pdb=" N   VAL A  35 "
      pdb=" CA  VAL A  35 "
    ideal   model   delta    sigma   weight residual
   123.19  123.23   -0.04 1.24e+00 6.50e-01 8.65e-04
angle pdb=" CD1 LEU A  37 "
      pdb=" CG  LEU A  37 "
      pdb=" CD2 LEU A  37 "
    ideal   model   delta    sigma   weight residual
   110.80  110.86   -0.06 2.20e+00 2.07e-01 8.55e-04
angle pdb=" O   GLU A  30 "
      pdb=" C   GLU A  30 "
      pdb=" N   GLN A  31 "
    ideal   model   delta    sigma   weight residual
   123.23  123.19    0.04 1.30e+00 5.92e-01 8.10e-04
angle pdb=" CB  LEU A  83 "
      pdb=" CG  LEU A  83 "
      pdb=" CD1 LEU A  83 "
    ideal   model   delta    sigma   weight residual
   110.70  110.78   -0.08 3.00e+00 1.11e-01 8.01e-04
angle pdb=" N   LEU A  49 "
      pdb=" CA  LEU A  49 "
      pdb=" CB  LEU A  49 "
    ideal   model   delta    sigma   weight residual
   110.17  110.21   -0.04 1.44e+00 4.82e-01 7.92e-04
angle pdb=" O   PRO A  58 "
      pdb=" C   PRO A  58 "
      pdb=" N   GLY A  59 "
    ideal   model   delta    sigma   weight residual
   123.03  123.00    0.03 1.21e+00 6.83e-01 7.89e-04
angle pdb=" CA  PRO A  54 "
      pdb=" N   PRO A  54 "
      pdb=" CD  PRO A  54 "
    ideal   model   delta    sigma   weight residual
   112.00  112.04   -0.04 1.40e+00 5.10e-01 7.88e-04
angle pdb=" CA  VAL A  70 "
      pdb=" CB  VAL A  70 "
      pdb=" CG1 VAL A  70 "
    ideal   model   delta    sigma   weight residual
   110.40  110.35    0.05 1.70e+00 3.46e-01 7.75e-04
angle pdb=" C   LYS A  69 "
      pdb=" CA  LYS A  69 "
      pdb=" CB  LYS A  69 "
    ideal   model   delta    sigma   weight residual
   111.09  111.03    0.06 2.27e+00 1.94e-01 7.46e-04
angle pdb=" CD2 TYR A  61 "
      pdb=" CE2 TYR A  61 "
      pdb=" CZ  TYR A  61 "
    ideal   model   delta    sigma   weight residual
   119.60  119.55    0.05 1.80e+00 3.09e-01 7.44e-04
angle pdb=" CA  ARG A  82 "
      pdb=" C   ARG A  82 "
      pdb=" N   LEU A  83 "
    ideal   model   delta    sigma   weight residual
   116.37  116.40   -0.03 1.19e+00 7.06e-01 7.43e-04
angle pdb=" CB  PRO A  54 "
      pdb=" CG  PRO A  54 "
      pdb=" CD  PRO A  54 "
    ideal   model   delta    sigma   weight residual
   106.10  106.01    0.09 3.20e+00 9.77e-02 7.40e-04
angle pdb=" C   LYS A   3 "
      pdb=" CA  LYS A   3 "
      pdb=" CB  LYS A   3 "
    ideal   model   delta    sigma   weight residual
   109.75  109.71    0.04 1.65e+00 3.67e-01 7.39e-04
angle pdb=" CB  PRO A  85 "
      pdb=" CG  PRO A  85 "
      pdb=" CD  PRO A  85 "
    ideal   model   delta    sigma   weight residual
   106.10  106.01    0.09 3.20e+00 9.77e-02 7.28e-04
angle pdb=" CD2 TYR A  56 "
      pdb=" CE2 TYR A  56 "
      pdb=" CZ  TYR A  56 "
    ideal   model   delta    sigma   weight residual
   119.60  119.65   -0.05 1.80e+00 3.09e-01 7.20e-04
angle pdb=" CB  GLN A  10 "
      pdb=" CG  GLN A  10 "
      pdb=" CD  GLN A  10 "
    ideal   model   delta    sigma   weight residual
   112.60  112.65   -0.05 1.70e+00 3.46e-01 7.01e-04
angle pdb=" NH1 ARG A  80 "
      pdb=" CZ  ARG A  80 "
      pdb=" NH2 ARG A  80 "
    ideal   model   delta    sigma   weight residual
   119.30  119.33   -0.03 1.30e+00 5.92e-01 6.99e-04
angle pdb=" CA  ASN A  39 "
      pdb=" CB  ASN A  39 "
      pdb=" CG  ASN A  39 "
    ideal   model   delta    sigma   weight residual
   112.60  112.63   -0.03 1.00e+00 1.00e+00 6.82e-04
angle pdb=" CE2 TYR A  34 "
      pdb=" CZ  TYR A  34 "
      pdb=" OH  TYR A  34 "
    ideal   model   delta    sigma   weight residual
   119.90  119.82    0.08 3.00e+00 1.11e-01 6.76e-04
angle pdb=" CB  ASP A  36 "
      pdb=" CG  ASP A  36 "
      pdb=" OD2 ASP A  36 "
    ideal   model   delta    sigma   weight residual
   118.40  118.34    0.06 2.30e+00 1.89e-01 6.71e-04
angle pdb=" CA  SER A  75 "
      pdb=" C   SER A  75 "
      pdb=" N   LEU A  76 "
    ideal   model   delta    sigma   weight residual
   115.27  115.24    0.03 1.24e+00 6.50e-01 6.55e-04
angle pdb=" N   SER A  17 "
      pdb=" CA  SER A  17 "
      pdb=" CB  SER A  17 "
    ideal   model   delta    sigma   weight residual
   110.85  110.81    0.04 1.54e+00 4.22e-01 6.39e-04
angle pdb=" N   PRO A   8 "
      pdb=" CD  PRO A   8 "
      pdb=" CG  PRO A   8 "
    ideal   model   delta    sigma   weight residual
   103.20  103.16    0.04 1.50e+00 4.44e-01 6.37e-04
angle pdb=" C   LEU A  81 "
      pdb=" N   ARG A  82 "
      pdb=" CA  ARG A  82 "
    ideal   model   delta    sigma   weight residual
   123.05  123.08   -0.03 1.40e+00 5.10e-01 6.03e-04
angle pdb=" N   HIS A  64 "
      pdb=" CA  HIS A  64 "
      pdb=" CB  HIS A  64 "
    ideal   model   delta    sigma   weight residual
   110.29  110.33   -0.04 1.52e+00 4.33e-01 5.89e-04
angle pdb=" OE1 GLN A  10 "
      pdb=" CD  GLN A  10 "
      pdb=" NE2 GLN A  10 "
    ideal   model   delta    sigma   weight residual
   122.60  122.58    0.02 1.00e+00 1.00e+00 5.87e-04
angle pdb=" CA  PHE A  13 "
      pdb=" C   PHE A  13 "
      pdb=" O   PHE A  13 "
    ideal   model   delta    sigma   weight residual
   121.11  121.14   -0.03 1.13e+00 7.83e-01 5.76e-04
angle pdb=" CG  PHE A  73 "
      pdb=" CD1 PHE A  73 "
      pdb=" CE1 PHE A  73 "
    ideal   model   delta    sigma   weight residual
   120.70  120.74   -0.04 1.70e+00 3.46e-01 5.76e-04
angle pdb=" CG  LYS A   3 "
      pdb=" CD  LYS A   3 "
      pdb=" CE  LYS A   3 "
    ideal   model   delta    sigma   weight residual
   111.30  111.35   -0.05 2.30e+00 1.89e-01 5.71e-04
angle pdb=" OE1 GLU A  30 "
      pdb=" CD  GLU A  30 "
      pdb=" OE2 GLU A  30 "
    ideal   model   delta    sigma   weight residual
   122.90  122.96   -0.06 2.40e+00 1.74e-01 5.67e-04
angle pdb=" CG  TYR A  26 "
      pdb=" CD1 TYR A  26 "
      pdb=" CE1 TYR A  26 "
    ideal   model   delta    sigma   weight residual
   121.20  121.24   -0.04 1.50e+00 4.44e-01 5.57e-04
angle pdb=" ND1 HIS A  64 "
      pdb=" CE1 HIS A  64 "
      pdb=" NE2 HIS A  64 "
    ideal   model   delta    sigma   weight residual
   108.40  108.38    0.02 1.00e+00 1.00e+00 5.57e-04
angle pdb=" CA  SER A  17 "
      pdb=" CB  SER A  17 "
      pdb=" OG  SER A  17 "
    ideal   model   delta    sigma   weight residual
   111.10  111.05    0.05 2.00e+00 2.50e-01 5.55e-04
angle pdb=" O   PRO A  54 "
      pdb=" C   PRO A  54 "
      pdb=" N   ALA A  55 "
    ideal   model   delta    sigma   weight residual
   122.86  122.83    0.03 1.24e+00 6.50e-01 5.44e-04
angle pdb=" CA  GLY A  59 "
      pdb=" C   GLY A  59 "
      pdb=" O   GLY A  59 "
    ideal   model   delta    sigma   weight residual
   121.48  121.50   -0.02 9.90e-01 1.02e+00 5.35e-04
angle pdb=" CA  VAL A  35 "
      pdb=" C   VAL A  35 "
      pdb=" O   VAL A  35 "
    ideal   model   delta    sigma   weight residual
   120.48  120.46    0.02 1.06e+00 8.90e-01 5.21e-04
angle pdb=" CA  MSE A  77 "
      pdb=" C   MSE A  77 "
      pdb=" O   MSE A  77 "
    ideal   model   delta    sigma   weight residual
   121.51  121.53   -0.02 1.12e+00 7.97e-01 4.91e-04
angle pdb=" CA  ILE A   2 "
      pdb=" CB  ILE A   2 "
      pdb=" CG2 ILE A   2 "
    ideal   model   delta    sigma   weight residual
   110.50  110.46    0.04 1.70e+00 3.46e-01 4.81e-04
angle pdb=" CE1 TYR A  56 "
      pdb=" CZ  TYR A  56 "
      pdb=" OH  TYR A  56 "
    ideal   model   delta    sigma   weight residual
   119.90  119.83    0.07 3.00e+00 1.11e-01 4.76e-04
angle pdb=" CA  VAL A  70 "
      pdb=" C   VAL A  70 "
      pdb=" O   VAL A  70 "
    ideal   model   delta    sigma   weight residual
   120.65  120.62    0.03 1.17e+00 7.31e-01 4.71e-04
angle pdb=" OE1 GLU A  51 "
      pdb=" CD  GLU A  51 "
      pdb=" OE2 GLU A  51 "
    ideal   model   delta    sigma   weight residual
   122.90  122.85    0.05 2.40e+00 1.74e-01 4.47e-04
angle pdb=" CB  LEU A  83 "
      pdb=" CG  LEU A  83 "
      pdb=" CD2 LEU A  83 "
    ideal   model   delta    sigma   weight residual
   110.70  110.64    0.06 3.00e+00 1.11e-01 4.46e-04
angle pdb=" CA  LEU A  49 "
      pdb=" C   LEU A  49 "
      pdb=" N   ASP A  50 "
    ideal   model   delta    sigma   weight residual
   115.51  115.48    0.03 1.27e+00 6.20e-01 4.44e-04
angle pdb=" CB  HIS A  64 "
      pdb=" CG  HIS A  64 "
      pdb=" CD2 HIS A  64 "
    ideal   model   delta    sigma   weight residual
   131.20  131.23   -0.03 1.30e+00 5.92e-01 4.38e-04
angle pdb=" CB  TYR A  34 "
      pdb=" CG  TYR A  34 "
      pdb=" CD1 TYR A  34 "
    ideal   model   delta    sigma   weight residual
   120.80  120.77    0.03 1.50e+00 4.44e-01 4.15e-04
angle pdb=" CB  PRO A   8 "
      pdb=" CG  PRO A   8 "
      pdb=" CD  PRO A   8 "
    ideal   model   delta    sigma   weight residual
   106.10  106.04    0.06 3.20e+00 9.77e-02 3.93e-04
angle pdb=" C   ILE A  47 "
      pdb=" N   THR A  48 "
      pdb=" CA  THR A  48 "
    ideal   model   delta    sigma   weight residual
   122.84  122.81    0.03 1.30e+00 5.92e-01 3.90e-04
angle pdb=" CA  ALA A  55 "
      pdb=" C   ALA A  55 "
      pdb=" N   TYR A  56 "
    ideal   model   delta    sigma   weight residual
   115.88  115.90   -0.02 1.28e+00 6.10e-01 3.77e-04
angle pdb=" C   LEU A  65 "
      pdb=" CA  LEU A  65 "
      pdb=" CB  LEU A  65 "
    ideal   model   delta    sigma   weight residual
   110.63  110.59    0.04 1.85e+00 2.92e-01 3.61e-04
angle pdb=" CB  PHE A  73 "
      pdb=" CG  PHE A  73 "
      pdb=" CD1 PHE A  73 "
    ideal   model   delta    sigma   weight residual
   120.70  120.67    0.03 1.70e+00 3.46e-01 3.38e-04
angle pdb=" O   THR A  15 "
      pdb=" C   THR A  15 "
      pdb=" N   ARG A  16 "
    ideal   model   delta    sigma   weight residual
   123.27  123.29   -0.02 1.18e+00 7.18e-01 2.90e-04
angle pdb=" N   VAL A  35 "
      pdb=" CA  VAL A  35 "
      pdb=" C   VAL A  35 "
    ideal   model   delta    sigma   weight residual
   108.17  108.19   -0.02 1.40e+00 5.10e-01 2.89e-04
angle pdb=" O   VAL A  84 "
      pdb=" C   VAL A  84 "
      pdb=" N   PRO A  85 "
    ideal   model   delta    sigma   weight residual
   121.10  121.08    0.02 1.14e+00 7.69e-01 2.79e-04
angle pdb=" CA  TYR A  34 "
      pdb=" CB  TYR A  34 "
      pdb=" CG  TYR A  34 "
    ideal   model   delta    sigma   weight residual
   113.90  113.87    0.03 1.80e+00 3.09e-01 2.78e-04
angle pdb=" CB  GLN A  53 "
      pdb=" CG  GLN A  53 "
      pdb=" CD  GLN A  53 "
    ideal   model   delta    sigma   weight residual
   112.60  112.63   -0.03 1.70e+00 3.46e-01 2.75e-04
angle pdb=" C   ASN A  39 "
      pdb=" N   GLU A  40 "
      pdb=" CA  GLU A  40 "
    ideal   model   delta    sigma   weight residual
   120.28  120.26    0.02 1.34e+00 5.57e-01 2.60e-04
angle pdb=" O   PRO A   8 "
      pdb=" C   PRO A   8 "
      pdb=" N   SER A   9 "
    ideal   model   delta    sigma   weight residual
   122.17  122.15    0.02 1.21e+00 6.83e-01 2.34e-04
angle pdb=" OG1 THR A  62 "
      pdb=" CB  THR A  62 "
      pdb=" CG2 THR A  62 "
    ideal   model   delta    sigma   weight residual
   109.30  109.27    0.03 2.00e+00 2.50e-01 2.30e-04
angle pdb=" O   CYS A  33 "
      pdb=" C   CYS A  33 "
      pdb=" N   TYR A  34 "
    ideal   model   delta    sigma   weight residual
   123.26  123.24    0.02 1.05e+00 9.07e-01 2.22e-04
angle pdb=" O   GLY A  52 "
      pdb=" C   GLY A  52 "
      pdb=" N   GLN A  53 "
    ideal   model   delta    sigma   weight residual
   122.52  122.54   -0.02 1.06e+00 8.90e-01 2.21e-04
angle pdb=" CB  LEU A  60 "
      pdb=" CG  LEU A  60 "
      pdb=" CD1 LEU A  60 "
    ideal   model   delta    sigma   weight residual
   110.70  110.66    0.04 3.00e+00 1.11e-01 2.17e-04
angle pdb=" OD1 ASN A  29 "
      pdb=" CG  ASN A  29 "
      pdb=" ND2 ASN A  29 "
    ideal   model   delta    sigma   weight residual
   122.60  122.61   -0.01 1.00e+00 1.00e+00 2.02e-04
angle pdb=" OE1 GLN A  31 "
      pdb=" CD  GLN A  31 "
      pdb=" NE2 GLN A  31 "
    ideal   model   delta    sigma   weight residual
   122.60  122.61   -0.01 1.00e+00 1.00e+00 1.95e-04
angle pdb=" N   THR A  48 "
      pdb=" CA  THR A  48 "
      pdb=" C   THR A  48 "
    ideal   model   delta    sigma   weight residual
   108.20  108.18    0.02 1.71e+00 3.42e-01 1.93e-04
angle pdb=" CB  TYR A  56 "
      pdb=" CG  TYR A  56 "
      pdb=" CD2 TYR A  56 "
    ideal   model   delta    sigma   weight residual
   120.80  120.82   -0.02 1.50e+00 4.44e-01 1.86e-04
angle pdb=" CG  GLN A  12 "
      pdb=" CD  GLN A  12 "
      pdb=" OE1 GLN A  12 "
    ideal   model   delta    sigma   weight residual
   120.80  120.77    0.03 2.00e+00 2.50e-01 1.73e-04
angle pdb=" CD1 PHE A  68 "
      pdb=" CE1 PHE A  68 "
      pdb=" CZ  PHE A  68 "
    ideal   model   delta    sigma   weight residual
   120.00  119.98    0.02 1.80e+00 3.09e-01 1.73e-04
angle pdb=" ND1 HIS A  64 "
      pdb=" CG  HIS A  64 "
      pdb=" CD2 HIS A  64 "
    ideal   model   delta    sigma   weight residual
   106.10  106.09    0.01 1.00e+00 1.00e+00 1.70e-04
angle pdb=" CG  GLN A  72 "
      pdb=" CD  GLN A  72 "
      pdb=" NE2 GLN A  72 "
    ideal   model   delta    sigma   weight residual
   116.40  116.38    0.02 1.50e+00 4.44e-01 1.63e-04
angle pdb=" CG  GLU A   5 "
      pdb=" CD  GLU A   5 "
      pdb=" OE2 GLU A   5 "
    ideal   model   delta    sigma   weight residual
   118.40  118.37    0.03 2.30e+00 1.89e-01 1.62e-04
angle pdb=" OD1 ASP A  36 "
      pdb=" CG  ASP A  36 "
      pdb=" OD2 ASP A  36 "
    ideal   model   delta    sigma   weight residual
   122.90  122.87    0.03 2.40e+00 1.74e-01 1.54e-04
angle pdb=" CD1 TYR A  61 "
      pdb=" CE1 TYR A  61 "
      pdb=" CZ  TYR A  61 "
    ideal   model   delta    sigma   weight residual
   119.60  119.58    0.02 1.80e+00 3.09e-01 1.53e-04
angle pdb=" O   LEU A  76 "
      pdb=" C   LEU A  76 "
      pdb=" N   MSE A  77 "
    ideal   model   delta    sigma   weight residual
   122.89  122.91   -0.02 1.22e+00 6.72e-01 1.51e-04
angle pdb=" O   TYR A  34 "
      pdb=" C   TYR A  34 "
      pdb=" N   VAL A  35 "
    ideal   model   delta    sigma   weight residual
   123.27  123.28   -0.01 1.16e+00 7.43e-01 1.35e-04
angle pdb=" CB  ILE A  78 "
      pdb=" CG1 ILE A  78 "
      pdb=" CD1 ILE A  78 "
    ideal   model   delta    sigma   weight residual
   113.80  113.78    0.02 2.10e+00 2.27e-01 1.22e-04
angle pdb=" CB  GLU A  30 "
      pdb=" CG  GLU A  30 "
      pdb=" CD  GLU A  30 "
    ideal   model   delta    sigma   weight residual
   112.60  112.62   -0.02 1.70e+00 3.46e-01 1.19e-04
angle pdb=" NH1 ARG A  16 "
      pdb=" CZ  ARG A  16 "
      pdb=" NH2 ARG A  16 "
    ideal   model   delta    sigma   weight residual
   119.30  119.29    0.01 1.30e+00 5.92e-01 1.02e-04
angle pdb=" C   GLU A  30 "
      pdb=" N   GLN A  31 "
      pdb=" CA  GLN A  31 "
    ideal   model   delta    sigma   weight residual
   122.62  122.64   -0.02 1.56e+00 4.11e-01 1.02e-04
angle pdb=" CB  HIS A  64 "
      pdb=" CG  HIS A  64 "
      pdb=" ND1 HIS A  64 "
    ideal   model   delta    sigma   weight residual
   122.70  122.69    0.01 1.50e+00 4.44e-01 9.11e-05
angle pdb=" CA  THR A  15 "
      pdb=" CB  THR A  15 "
      pdb=" OG1 THR A  15 "
    ideal   model   delta    sigma   weight residual
   109.60  109.59    0.01 1.50e+00 4.44e-01 8.97e-05
angle pdb=" N   VAL A  70 "
      pdb=" CA  VAL A  70 "
      pdb=" C   VAL A  70 "
    ideal   model   delta    sigma   weight residual
   108.23  108.22    0.01 1.53e+00 4.27e-01 8.16e-05
angle pdb=" N   SER A  67 "
      pdb=" CA  SER A  67 "
      pdb=" CB  SER A  67 "
    ideal   model   delta    sigma   weight residual
   110.39  110.38    0.01 1.66e+00 3.63e-01 7.93e-05
angle pdb=" C   ILE A   2 "
      pdb=" N   LYS A   3 "
      pdb=" CA  LYS A   3 "
    ideal   model   delta    sigma   weight residual
   122.72  122.71    0.01 1.38e+00 5.25e-01 7.92e-05
angle pdb=" N   PRO A  54 "
      pdb=" CD  PRO A  54 "
      pdb=" CG  PRO A  54 "
    ideal   model   delta    sigma   weight residual
   103.20  103.21   -0.01 1.50e+00 4.44e-01 7.70e-05
angle pdb=" CA  GLU A  40 "
      pdb=" C   GLU A  40 "
      pdb=" N   TYR A  41 "
    ideal   model   delta    sigma   weight residual
   117.30  117.29    0.01 1.16e+00 7.43e-01 6.60e-05
angle pdb=" CE1 TYR A  61 "
      pdb=" CZ  TYR A  61 "
      pdb=" OH  TYR A  61 "
    ideal   model   delta    sigma   weight residual
   119.90  119.88    0.02 3.00e+00 1.11e-01 6.40e-05
angle pdb=" CG  PHE A  68 "
      pdb=" CD1 PHE A  68 "
      pdb=" CE1 PHE A  68 "
    ideal   model   delta    sigma   weight residual
   120.70  120.71   -0.01 1.70e+00 3.46e-01 5.21e-05
angle pdb=" CA  ASP A  36 "
      pdb=" C   ASP A  36 "
      pdb=" O   ASP A  36 "
    ideal   model   delta    sigma   weight residual
   120.58  120.59   -0.01 1.07e+00 8.73e-01 4.96e-05
angle pdb=" CG  HIS A  64 "
      pdb=" CD2 HIS A  64 "
      pdb=" NE2 HIS A  64 "
    ideal   model   delta    sigma   weight residual
   107.20  107.21   -0.01 1.00e+00 1.00e+00 4.61e-05
angle pdb=" CA  ILE A   2 "
      pdb=" C   ILE A   2 "
      pdb=" N   LYS A   3 "
    ideal   model   delta    sigma   weight residual
   116.20  116.21   -0.01 2.00e+00 2.50e-01 4.36e-05
angle pdb=" CD1 PHE A  13 "
      pdb=" CE1 PHE A  13 "
      pdb=" CZ  PHE A  13 "
    ideal   model   delta    sigma   weight residual
   120.00  119.99    0.01 1.80e+00 3.09e-01 3.95e-05
angle pdb=" N   SER A  27 "
      pdb=" CA  SER A  27 "
      pdb=" CB  SER A  27 "
    ideal   model   delta    sigma   weight residual
   110.81  110.82   -0.01 1.68e+00 3.54e-01 3.44e-05
angle pdb=" CA  GLN A  53 "
      pdb=" C   GLN A  53 "
      pdb=" N   PRO A  54 "
    ideal   model   delta    sigma   weight residual
   118.75  118.76   -0.01 9.70e-01 1.06e+00 3.31e-05
angle pdb=" CA  SER A   9 "
      pdb=" C   SER A   9 "
      pdb=" O   SER A   9 "
    ideal   model   delta    sigma   weight residual
   119.12  119.11    0.01 1.31e+00 5.83e-01 3.20e-05
angle pdb=" C   CYS A  33 "
      pdb=" N   TYR A  34 "
      pdb=" CA  TYR A  34 "
    ideal   model   delta    sigma   weight residual
   123.00  122.99    0.01 1.41e+00 5.03e-01 2.48e-05
angle pdb=" C   PRO A  58 "
      pdb=" N   GLY A  59 "
      pdb=" CA  GLY A  59 "
    ideal   model   delta    sigma   weight residual
   121.23  121.22    0.01 1.34e+00 5.57e-01 2.30e-05
angle pdb=" CD1 LEU A  81 "
      pdb=" CG  LEU A  81 "
      pdb=" CD2 LEU A  81 "
    ideal   model   delta    sigma   weight residual
   110.80  110.81   -0.01 2.20e+00 2.07e-01 2.02e-05
angle pdb=" CA  ARG A  16 "
      pdb=" C   ARG A  16 "
      pdb=" N   SER A  17 "
    ideal   model   delta    sigma   weight residual
   116.25  116.26   -0.01 1.23e+00 6.61e-01 1.93e-05
angle pdb=" CA  LEU A  65 "
      pdb=" C   LEU A  65 "
      pdb=" O   LEU A  65 "
    ideal   model   delta    sigma   weight residual
   120.10  120.10   -0.00 1.13e+00 7.83e-01 1.82e-05
angle pdb=" CD1 TYR A  26 "
      pdb=" CG  TYR A  26 "
      pdb=" CD2 TYR A  26 "
    ideal   model   delta    sigma   weight residual
   118.10  118.09    0.01 1.50e+00 4.44e-01 1.67e-05
angle pdb=" C   TYR A  41 "
      pdb=" N   PRO A  42 "
      pdb=" CA  PRO A  42 "
    ideal   model   delta    sigma   weight residual
   119.92  119.92   -0.00 1.07e+00 8.73e-01 1.51e-05
angle pdb=" OD1 ASP A  79 "
      pdb=" CG  ASP A  79 "
      pdb=" OD2 ASP A  79 "
    ideal   model   delta    sigma   weight residual
   122.90  122.91   -0.01 2.40e+00 1.74e-01 1.31e-05
angle pdb=" O   GLY A  38 "
      pdb=" C   GLY A  38 "
      pdb=" N   ASN A  39 "
    ideal   model   delta    sigma   weight residual
   122.41  122.41    0.00 1.25e+00 6.40e-01 1.26e-05
angle pdb=" CA  PRO A  85 "
      pdb=" C   PRO A  85 "
      pdb=" O   PRO A  85 "
    ideal   model   delta    sigma   weight residual
   119.00  118.99    0.01 3.00e+00 1.11e-01 5.88e-06
angle pdb=" CD1 PHE A  73 "
      pdb=" CE1 PHE A  73 "
      pdb=" CZ  PHE A  73 "
    ideal   model   delta    sigma   weight residual
   120.00  120.00    0.00 1.80e+00 3.09e-01 5.74e-06
angle pdb=" OE1 GLU A  40 "
      pdb=" CD  GLU A  40 "
      pdb=" OE2 GLU A  40 "
    ideal   model   delta    sigma   weight residual
   122.90  122.90    0.00 2.40e+00 1.74e-01 3.84e-06
angle pdb=" CA  PRO A   8 "
      pdb=" C   PRO A   8 "
      pdb=" N   SER A   9 "
    ideal   model   delta    sigma   weight residual
   118.15  118.15   -0.00 1.58e+00 4.01e-01 1.65e-06
angle pdb=" CB  LEU A  49 "
      pdb=" CG  LEU A  49 "
      pdb=" CD1 LEU A  49 "
    ideal   model   delta    sigma   weight residual
   110.70  110.70    0.00 3.00e+00 1.11e-01 1.22e-06
angle pdb=" CA  LEU A  81 "
      pdb=" C   LEU A  81 "
      pdb=" N   ARG A  82 "
    ideal   model   delta    sigma   weight residual
   116.57  116.57    0.00 1.39e+00 5.18e-01 4.56e-07
angle pdb=" CD1 LEU A  49 "
      pdb=" CG  LEU A  49 "
      pdb=" CD2 LEU A  49 "
    ideal   model   delta    sigma   weight residual
   110.80  110.80   -0.00 2.20e+00 2.07e-01 2.98e-07

Dihedral angle | covalent geometry | restraints: 252
  sinusoidal: 164
    harmonic: 88
Sorted by residual:
dihedral pdb=" N   VAL A  84 "
         pdb=" CA  VAL A  84 "
         pdb=" CB  VAL A  84 "
         pdb=" CG1 VAL A  84 "
    ideal   model   delta sinusoidal    sigma   weight residual
    60.00  109.90  -49.90     3      1.50e+01 4.44e-03 8.83e+00
dihedral pdb=" CB  LYS A   7 "
         pdb=" CG  LYS A   7 "
         pdb=" CD  LYS A   7 "
         pdb=" CE  LYS A   7 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  134.59   45.41     3      1.50e+01 4.44e-03 8.16e+00
dihedral pdb=" CA  GLN A  53 "
         pdb=" CB  GLN A  53 "
         pdb=" CG  GLN A  53 "
         pdb=" CD  GLN A  53 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00 -135.84  -44.16     3      1.50e+01 4.44e-03 7.94e+00
dihedral pdb=" CA  THR A  15 "
         pdb=" C   THR A  15 "
         pdb=" N   ARG A  16 "
         pdb=" CA  ARG A  16 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  166.06   13.94     0      5.00e+00 4.00e-02 7.77e+00
dihedral pdb=" N   GLN A  53 "
         pdb=" CA  GLN A  53 "
         pdb=" CB  GLN A  53 "
         pdb=" CG  GLN A  53 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00 -102.11   42.11     3      1.50e+01 4.44e-03 7.55e+00
dihedral pdb=" CB  LYS A  24 "
         pdb=" CG  LYS A  24 "
         pdb=" CD  LYS A  24 "
         pdb=" CE  LYS A  24 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  143.36   36.64     3      1.50e+01 4.44e-03 6.36e+00
dihedral pdb=" CA  ARG A  82 "
         pdb=" C   ARG A  82 "
         pdb=" N   LEU A  83 "
         pdb=" CA  LEU A  83 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -167.48  -12.52     0      5.00e+00 4.00e-02 6.27e+00
dihedral pdb=" CA  GLU A   5 "
         pdb=" CB  GLU A   5 "
         pdb=" CG  GLU A   5 "
         pdb=" CD  GLU A   5 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  145.39   34.61     3      1.50e+01 4.44e-03 5.87e+00
dihedral pdb=" N   ARG A  21 "
         pdb=" CA  ARG A  21 "
         pdb=" CB  ARG A  21 "
         pdb=" CG  ARG A  21 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -145.70  -34.30     3      1.50e+01 4.44e-03 5.80e+00
dihedral pdb=" CA  LEU A  49 "
         pdb=" C   LEU A  49 "
         pdb=" N   ASP A  50 "
         pdb=" CA  ASP A  50 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  168.06   11.94     0      5.00e+00 4.00e-02 5.70e+00
dihedral pdb=" N   VAL A  45 "
         pdb=" CA  VAL A  45 "
         pdb=" CB  VAL A  45 "
         pdb=" CG1 VAL A  45 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  146.51   33.49     3      1.50e+01 4.44e-03 5.60e+00
dihedral pdb=" CG  LYS A   3 "
         pdb=" CD  LYS A   3 "
         pdb=" CE  LYS A   3 "
         pdb=" NZ  LYS A   3 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -146.77  -33.23     3      1.50e+01 4.44e-03 5.54e+00
dihedral pdb=" CA  GLN A  22 "
         pdb=" CB  GLN A  22 "
         pdb=" CG  GLN A  22 "
         pdb=" CD  GLN A  22 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -92.63   32.63     3      1.50e+01 4.44e-03 5.39e+00
dihedral pdb=" CA  GLN A  53 "
         pdb=" C   GLN A  53 "
         pdb=" N   PRO A  54 "
         pdb=" CA  PRO A  54 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  168.80   11.20     0      5.00e+00 4.00e-02 5.02e+00
dihedral pdb=" CA  LYS A  46 "
         pdb=" CB  LYS A  46 "
         pdb=" CG  LYS A  46 "
         pdb=" CD  LYS A  46 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00 -149.61  -30.39     3      1.50e+01 4.44e-03 4.84e+00
dihedral pdb=" CA  TYR A  61 "
         pdb=" C   TYR A  61 "
         pdb=" N   THR A  62 "
         pdb=" CA  THR A  62 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  169.21   10.79     0      5.00e+00 4.00e-02 4.66e+00
dihedral pdb=" CA  PRO A  42 "
         pdb=" C   PRO A  42 "
         pdb=" N   VAL A  43 "
         pdb=" CA  VAL A  43 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00 -169.43  -10.57     0      5.00e+00 4.00e-02 4.47e+00
dihedral pdb=" N   LEU A  81 "
         pdb=" CA  LEU A  81 "
         pdb=" CB  LEU A  81 "
         pdb=" CG  LEU A  81 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -151.11  -28.89     3      1.50e+01 4.44e-03 4.47e+00
dihedral pdb=" CB  ARG A  21 "
         pdb=" CG  ARG A  21 "
         pdb=" CD  ARG A  21 "
         pdb=" NE  ARG A  21 "
    ideal   model   delta sinusoidal    sigma   weight residual
    60.00   31.19   28.81     3      1.50e+01 4.44e-03 4.45e+00
dihedral pdb=" N   SER A  20 "
         pdb=" CA  SER A  20 "
         pdb=" CB  SER A  20 "
         pdb=" OG  SER A  20 "
    ideal   model   delta sinusoidal    sigma   weight residual
    60.00   88.49  -28.49     3      1.50e+01 4.44e-03 4.37e+00
dihedral pdb=" CB  LYS A   3 "
         pdb=" CG  LYS A   3 "
         pdb=" CD  LYS A   3 "
         pdb=" CE  LYS A   3 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -87.87   27.87     3      1.50e+01 4.44e-03 4.21e+00
dihedral pdb=" CA  GLU A  40 "
         pdb=" CB  GLU A  40 "
         pdb=" CG  GLU A  40 "
         pdb=" CD  GLU A  40 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -86.01   26.01     3      1.50e+01 4.44e-03 3.76e+00
dihedral pdb=" N   SER A  17 "
         pdb=" CA  SER A  17 "
         pdb=" CB  SER A  17 "
         pdb=" OG  SER A  17 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00 -154.47  -25.53     3      1.50e+01 4.44e-03 3.64e+00
dihedral pdb=" CA  SER A  67 "
         pdb=" C   SER A  67 "
         pdb=" N   PHE A  68 "
         pdb=" CA  PHE A  68 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -170.46   -9.54     0      5.00e+00 4.00e-02 3.64e+00
dihedral pdb=" CA  GLN A  12 "
         pdb=" CB  GLN A  12 "
         pdb=" CG  GLN A  12 "
         pdb=" CD  GLN A  12 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -154.53  -25.47     3      1.50e+01 4.44e-03 3.63e+00
dihedral pdb=" CB  GLN A  12 "
         pdb=" CG  GLN A  12 "
         pdb=" CD  GLN A  12 "
         pdb=" OE1 GLN A  12 "
    ideal   model   delta sinusoidal    sigma   weight residual
     0.00   53.33  -53.33     2      3.00e+01 1.11e-03 3.43e+00
dihedral pdb=" CA  GLU A  51 "
         pdb=" CB  GLU A  51 "
         pdb=" CG  GLU A  51 "
         pdb=" CD  GLU A  51 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  156.52   23.48     3      1.50e+01 4.44e-03 3.15e+00
dihedral pdb=" N   SER A  27 "
         pdb=" CA  SER A  27 "
         pdb=" CB  SER A  27 "
         pdb=" OG  SER A  27 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  156.79   23.21     3      1.50e+01 4.44e-03 3.09e+00
dihedral pdb=" CA  GLN A  10 "
         pdb=" C   GLN A  10 "
         pdb=" N   ALA A  11 "
         pdb=" CA  ALA A  11 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -171.38   -8.62     0      5.00e+00 4.00e-02 2.97e+00
dihedral pdb=" CA  ILE A   6 "
         pdb=" CB  ILE A   6 "
         pdb=" CG1 ILE A   6 "
         pdb=" CD1 ILE A   6 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -81.93   21.93     3      1.50e+01 4.44e-03 2.80e+00
dihedral pdb=" N   LYS A  24 "
         pdb=" CA  LYS A  24 "
         pdb=" CB  LYS A  24 "
         pdb=" CG  LYS A  24 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -158.37  -21.63     3      1.50e+01 4.44e-03 2.73e+00
dihedral pdb=" CA  LEU A  32 "
         pdb=" CB  LEU A  32 "
         pdb=" CG  LEU A  32 "
         pdb=" CD1 LEU A  32 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -38.80  -21.20     3      1.50e+01 4.44e-03 2.63e+00
dihedral pdb=" N   GLN A  72 "
         pdb=" CA  GLN A  72 "
         pdb=" CB  GLN A  72 "
         pdb=" CG  GLN A  72 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -158.95  -21.05     3      1.50e+01 4.44e-03 2.60e+00
dihedral pdb=" CA  LYS A   3 "
         pdb=" CB  LYS A   3 "
         pdb=" CG  LYS A   3 "
         pdb=" CD  LYS A   3 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -159.03  -20.97     3      1.50e+01 4.44e-03 2.58e+00
dihedral pdb=" CB  GLN A  10 "
         pdb=" CG  GLN A  10 "
         pdb=" CD  GLN A  10 "
         pdb=" OE1 GLN A  10 "
    ideal   model   delta sinusoidal    sigma   weight residual
     0.00  -43.63   43.63     2      3.00e+01 1.11e-03 2.54e+00
dihedral pdb=" CA  THR A  62 "
         pdb=" C   THR A  62 "
         pdb=" N   VAL A  63 "
         pdb=" CA  VAL A  63 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -172.04   -7.96     0      5.00e+00 4.00e-02 2.53e+00
dihedral pdb=" N   LYS A   7 "
         pdb=" CA  LYS A   7 "
         pdb=" CB  LYS A   7 "
         pdb=" CG  LYS A   7 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -80.44   20.44     3      1.50e+01 4.44e-03 2.47e+00
dihedral pdb=" CA  VAL A  84 "
         pdb=" C   VAL A  84 "
         pdb=" N   PRO A  85 "
         pdb=" CA  PRO A  85 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -172.22   -7.78     0      5.00e+00 4.00e-02 2.42e+00
dihedral pdb=" CA  PHE A  13 "
         pdb=" C   PHE A  13 "
         pdb=" N   THR A  14 "
         pdb=" CA  THR A  14 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  172.23    7.77     0      5.00e+00 4.00e-02 2.42e+00
dihedral pdb=" N   LYS A   3 "
         pdb=" CA  LYS A   3 "
         pdb=" CB  LYS A   3 "
         pdb=" CG  LYS A   3 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  159.84   20.16     3      1.50e+01 4.44e-03 2.41e+00
dihedral pdb=" N   ARG A  80 "
         pdb=" CA  ARG A  80 "
         pdb=" CB  ARG A  80 "
         pdb=" CG  ARG A  80 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -79.35   19.35     3      1.50e+01 4.44e-03 2.23e+00
dihedral pdb=" CA  GLU A   5 "
         pdb=" C   GLU A   5 "
         pdb=" N   ILE A   6 "
         pdb=" CA  ILE A   6 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  172.61    7.39     0      5.00e+00 4.00e-02 2.19e+00
dihedral pdb=" CA  LEU A  44 "
         pdb=" CB  LEU A  44 "
         pdb=" CG  LEU A  44 "
         pdb=" CD1 LEU A  44 "
    ideal   model   delta sinusoidal    sigma   weight residual
    60.00   78.43  -18.43     3      1.50e+01 4.44e-03 2.04e+00
dihedral pdb=" CB  GLN A  22 "
         pdb=" CG  GLN A  22 "
         pdb=" CD  GLN A  22 "
         pdb=" OE1 GLN A  22 "
    ideal   model   delta sinusoidal    sigma   weight residual
     0.00   36.65  -36.65     2      3.00e+01 1.11e-03 1.90e+00
dihedral pdb=" CA  TYR A  56 "
         pdb=" C   TYR A  56 "
         pdb=" N   ALA A  57 "
         pdb=" CA  ALA A  57 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  173.28    6.72     0      5.00e+00 4.00e-02 1.81e+00
dihedral pdb=" CA  VAL A  45 "
         pdb=" C   VAL A  45 "
         pdb=" N   LYS A  46 "
         pdb=" CA  LYS A  46 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  173.30    6.70     0      5.00e+00 4.00e-02 1.79e+00
dihedral pdb=" CA  ARG A  21 "
         pdb=" CB  ARG A  21 "
         pdb=" CG  ARG A  21 "
         pdb=" CD  ARG A  21 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  162.98   17.02     3      1.50e+01 4.44e-03 1.76e+00
dihedral pdb=" CA  LYS A   7 "
         pdb=" C   LYS A   7 "
         pdb=" N   PRO A   8 "
         pdb=" CA  PRO A   8 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  173.39    6.61     0      5.00e+00 4.00e-02 1.75e+00
dihedral pdb=" CA  ASP A  79 "
         pdb=" CB  ASP A  79 "
         pdb=" CG  ASP A  79 "
         pdb=" OD1 ASP A  79 "
    ideal   model   delta sinusoidal    sigma   weight residual
     0.00   21.81  -21.81     1      2.00e+01 2.50e-03 1.72e+00
dihedral pdb=" CA  GLN A  12 "
         pdb=" C   GLN A  12 "
         pdb=" N   PHE A  13 "
         pdb=" CA  PHE A  13 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  173.58    6.42     0      5.00e+00 4.00e-02 1.65e+00
dihedral pdb=" N   TYR A  34 "
         pdb=" CA  TYR A  34 "
         pdb=" CB  TYR A  34 "
         pdb=" CG  TYR A  34 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -75.19   15.19     3      1.50e+01 4.44e-03 1.42e+00
dihedral pdb=" CA  TYR A  41 "
         pdb=" C   TYR A  41 "
         pdb=" N   PRO A  42 "
         pdb=" CA  PRO A  42 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  174.11    5.89     0      5.00e+00 4.00e-02 1.39e+00
dihedral pdb=" N   ILE A   2 "
         pdb=" CA  ILE A   2 "
         pdb=" CB  ILE A   2 "
         pdb=" CG1 ILE A   2 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  165.05   14.95     3      1.50e+01 4.44e-03 1.38e+00
dihedral pdb=" N   LEU A  76 "
         pdb=" CA  LEU A  76 "
         pdb=" CB  LEU A  76 "
         pdb=" CG  LEU A  76 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -165.16  -14.84     3      1.50e+01 4.44e-03 1.36e+00
dihedral pdb=" CA  LEU A  28 "
         pdb=" CB  LEU A  28 "
         pdb=" CG  LEU A  28 "
         pdb=" CD1 LEU A  28 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  165.19   14.81     3      1.50e+01 4.44e-03 1.35e+00
dihedral pdb=" N   LEU A  60 "
         pdb=" CA  LEU A  60 "
         pdb=" CB  LEU A  60 "
         pdb=" CG  LEU A  60 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -74.75   14.75     3      1.50e+01 4.44e-03 1.34e+00
dihedral pdb=" N   GLN A  12 "
         pdb=" CA  GLN A  12 "
         pdb=" CB  GLN A  12 "
         pdb=" CG  GLN A  12 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -74.60   14.60     3      1.50e+01 4.44e-03 1.32e+00
dihedral pdb=" N   LEU A  32 "
         pdb=" CA  LEU A  32 "
         pdb=" CB  LEU A  32 "
         pdb=" CG  LEU A  32 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -74.46   14.46     3      1.50e+01 4.44e-03 1.30e+00
dihedral pdb=" CA  LYS A  24 "
         pdb=" C   LYS A  24 "
         pdb=" N   PRO A  25 "
         pdb=" CA  PRO A  25 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  174.33    5.67     0      5.00e+00 4.00e-02 1.29e+00
dihedral pdb=" CA  HIS A  64 "
         pdb=" C   HIS A  64 "
         pdb=" N   LEU A  65 "
         pdb=" CA  LEU A  65 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00 -174.35   -5.65     0      5.00e+00 4.00e-02 1.28e+00
dihedral pdb=" CA  ASP A  50 "
         pdb=" CB  ASP A  50 "
         pdb=" CG  ASP A  50 "
         pdb=" OD1 ASP A  50 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -30.00  -48.53   18.53     1      2.00e+01 2.50e-03 1.24e+00
dihedral pdb=" N   ASP A  36 "
         pdb=" CA  ASP A  36 "
         pdb=" CB  ASP A  36 "
         pdb=" CG  ASP A  36 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00 -166.20  -13.80     3      1.50e+01 4.44e-03 1.18e+00
dihedral pdb=" CA  ARG A  21 "
         pdb=" C   ARG A  21 "
         pdb=" N   GLN A  22 "
         pdb=" CA  GLN A  22 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00 -174.67   -5.33     0      5.00e+00 4.00e-02 1.14e+00
dihedral pdb=" CA  PRO A  54 "
         pdb=" C   PRO A  54 "
         pdb=" N   ALA A  55 "
         pdb=" CA  ALA A  55 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  174.78    5.22     0      5.00e+00 4.00e-02 1.09e+00
dihedral pdb=" CB  ARG A  82 "
         pdb=" CG  ARG A  82 "
         pdb=" CD  ARG A  82 "
         pdb=" NE  ARG A  82 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  166.85   13.15     3      1.50e+01 4.44e-03 1.08e+00
dihedral pdb=" CA  ILE A  78 "
         pdb=" C   ILE A  78 "
         pdb=" N   ASP A  79 "
         pdb=" CA  ASP A  79 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  174.82    5.18     0      5.00e+00 4.00e-02 1.07e+00
dihedral pdb=" N   VAL A  43 "
         pdb=" CA  VAL A  43 "
         pdb=" CB  VAL A  43 "
         pdb=" CG1 VAL A  43 "
    ideal   model   delta sinusoidal    sigma   weight residual
    60.00   73.06  -13.06     3      1.50e+01 4.44e-03 1.07e+00
dihedral pdb=" CB  LYS A  46 "
         pdb=" CG  LYS A  46 "
         pdb=" CD  LYS A  46 "
         pdb=" CE  LYS A  46 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -72.98   12.98     3      1.50e+01 4.44e-03 1.05e+00
dihedral pdb=" CA  PHE A  73 "
         pdb=" CB  PHE A  73 "
         pdb=" CG  PHE A  73 "
         pdb=" CD1 PHE A  73 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -90.00  -72.77  -17.23     2      2.00e+01 2.50e-03 1.05e+00
dihedral pdb=" CA  GLN A  22 "
         pdb=" C   GLN A  22 "
         pdb=" N   GLY A  23 "
         pdb=" CA  GLY A  23 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  175.03    4.97     0      5.00e+00 4.00e-02 9.86e-01
dihedral pdb=" CA  TYR A  41 "
         pdb=" CB  TYR A  41 "
         pdb=" CG  TYR A  41 "
         pdb=" CD1 TYR A  41 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -90.00  -73.36  -16.64     2      2.00e+01 2.50e-03 9.85e-01
dihedral pdb=" CA  ASN A  29 "
         pdb=" C   ASN A  29 "
         pdb=" N   GLU A  30 "
         pdb=" CA  GLU A  30 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00 -175.07   -4.93     0      5.00e+00 4.00e-02 9.71e-01
dihedral pdb=" CA  LEU A  76 "
         pdb=" CB  LEU A  76 "
         pdb=" CG  LEU A  76 "
         pdb=" CD1 LEU A  76 "
    ideal   model   delta sinusoidal    sigma   weight residual
    60.00   72.42  -12.42     3      1.50e+01 4.44e-03 9.68e-01
dihedral pdb=" CA  ALA A  55 "
         pdb=" C   ALA A  55 "
         pdb=" N   TYR A  56 "
         pdb=" CA  TYR A  56 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  175.08    4.92     0      5.00e+00 4.00e-02 9.67e-01
dihedral pdb=" N   TYR A  26 "
         pdb=" CA  TYR A  26 "
         pdb=" CB  TYR A  26 "
         pdb=" CG  TYR A  26 "
    ideal   model   delta sinusoidal    sigma   weight residual
    60.00   72.20  -12.20     3      1.50e+01 4.44e-03 9.35e-01
dihedral pdb=" N   PRO A  42 "
         pdb=" CA  PRO A  42 "
         pdb=" CB  PRO A  42 "
         pdb=" CG  PRO A  42 "
    ideal   model   delta sinusoidal    sigma   weight residual
    30.00   14.03   15.97     1      2.00e+01 2.50e-03 9.26e-01
dihedral pdb=" CB  GLU A  51 "
         pdb=" CG  GLU A  51 "
         pdb=" CD  GLU A  51 "
         pdb=" OE1 GLU A  51 "
    ideal   model   delta sinusoidal    sigma   weight residual
     0.00   23.94  -23.94     1      3.00e+01 1.11e-03 9.17e-01
dihedral pdb=" N   GLU A  40 "
         pdb=" CA  GLU A  40 "
         pdb=" CB  GLU A  40 "
         pdb=" CG  GLU A  40 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -48.20  -11.80     3      1.50e+01 4.44e-03 8.77e-01
dihedral pdb=" N   THR A  62 "
         pdb=" CA  THR A  62 "
         pdb=" CB  THR A  62 "
         pdb=" OG1 THR A  62 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -168.39  -11.61     3      1.50e+01 4.44e-03 8.50e-01
dihedral pdb=" CB  GLN A  53 "
         pdb=" CG  GLN A  53 "
         pdb=" CD  GLN A  53 "
         pdb=" OE1 GLN A  53 "
    ideal   model   delta sinusoidal    sigma   weight residual
     0.00  -23.52   23.52     2      3.00e+01 1.11e-03 8.50e-01
dihedral pdb=" CA  GLY A  38 "
         pdb=" C   GLY A  38 "
         pdb=" N   ASN A  39 "
         pdb=" CA  ASN A  39 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  175.49    4.51     0      5.00e+00 4.00e-02 8.14e-01
dihedral pdb=" CA  ALA A  57 "
         pdb=" C   ALA A  57 "
         pdb=" N   PRO A  58 "
         pdb=" CA  PRO A  58 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  175.53    4.47     0      5.00e+00 4.00e-02 7.98e-01
dihedral pdb=" CG  ARG A  21 "
         pdb=" CD  ARG A  21 "
         pdb=" NE  ARG A  21 "
         pdb=" CZ  ARG A  21 "
    ideal   model   delta sinusoidal    sigma   weight residual
    90.00  101.14  -11.14     2      1.50e+01 4.44e-03 7.97e-01
dihedral pdb=" CA  ASP A  79 "
         pdb=" C   ASP A  79 "
         pdb=" N   ARG A  80 "
         pdb=" CA  ARG A  80 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  175.55    4.45     0      5.00e+00 4.00e-02 7.91e-01
dihedral pdb=" CA  CYS A  33 "
         pdb=" C   CYS A  33 "
         pdb=" N   TYR A  34 "
         pdb=" CA  TYR A  34 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  175.58    4.42     0      5.00e+00 4.00e-02 7.80e-01
dihedral pdb=" CA  VAL A  70 "
         pdb=" C   VAL A  70 "
         pdb=" N   GLY A  71 "
         pdb=" CA  GLY A  71 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00 -175.61   -4.39     0      5.00e+00 4.00e-02 7.71e-01
dihedral pdb=" N   ILE A  78 "
         pdb=" CA  ILE A  78 "
         pdb=" CB  ILE A  78 "
         pdb=" CG1 ILE A  78 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -70.86   10.86     3      1.50e+01 4.44e-03 7.46e-01
dihedral pdb=" N   VAL A  70 "
         pdb=" CA  VAL A  70 "
         pdb=" CB  VAL A  70 "
         pdb=" CG1 VAL A  70 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -169.15  -10.85     3      1.50e+01 4.44e-03 7.45e-01
dihedral pdb=" N   HIS A  64 "
         pdb=" CA  HIS A  64 "
         pdb=" CB  HIS A  64 "
         pdb=" CG  HIS A  64 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00 -169.20  -10.80     3      1.50e+01 4.44e-03 7.37e-01
dihedral pdb=" N   LEU A  44 "
         pdb=" CA  LEU A  44 "
         pdb=" CB  LEU A  44 "
         pdb=" CG  LEU A  44 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -169.22  -10.78     3      1.50e+01 4.44e-03 7.36e-01
dihedral pdb=" CA  LYS A   3 "
         pdb=" C   LYS A   3 "
         pdb=" N   VAL A   4 "
         pdb=" CA  VAL A   4 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  175.74    4.26     0      5.00e+00 4.00e-02 7.25e-01
dihedral pdb=" CA  LEU A  49 "
         pdb=" CB  LEU A  49 "
         pdb=" CG  LEU A  49 "
         pdb=" CD1 LEU A  49 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  169.42   10.58     3      1.50e+01 4.44e-03 7.09e-01
dihedral pdb=" N   LEU A  65 "
         pdb=" CA  LEU A  65 "
         pdb=" CB  LEU A  65 "
         pdb=" CG  LEU A  65 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -169.47  -10.53     3      1.50e+01 4.44e-03 7.02e-01
dihedral pdb=" CA  LYS A  69 "
         pdb=" CB  LYS A  69 "
         pdb=" CG  LYS A  69 "
         pdb=" CD  LYS A  69 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  169.54   10.46     3      1.50e+01 4.44e-03 6.94e-01
dihedral pdb=" N   SER A   9 "
         pdb=" CA  SER A   9 "
         pdb=" CB  SER A   9 "
         pdb=" OG  SER A   9 "
    ideal   model   delta sinusoidal    sigma   weight residual
    60.00   70.45  -10.45     3      1.50e+01 4.44e-03 6.93e-01
dihedral pdb=" CG  LYS A   7 "
         pdb=" CD  LYS A   7 "
         pdb=" CE  LYS A   7 "
         pdb=" NZ  LYS A   7 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  169.61   10.39     3      1.50e+01 4.44e-03 6.85e-01
dihedral pdb=" CG  ARG A  16 "
         pdb=" CD  ARG A  16 "
         pdb=" NE  ARG A  16 "
         pdb=" CZ  ARG A  16 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -169.69  -10.31     2      1.50e+01 4.44e-03 6.83e-01
dihedral pdb=" N   GLN A  31 "
         pdb=" CA  GLN A  31 "
         pdb=" CB  GLN A  31 "
         pdb=" CG  GLN A  31 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -169.68  -10.32     3      1.50e+01 4.44e-03 6.75e-01
dihedral pdb=" CA  ARG A  16 "
         pdb=" C   ARG A  16 "
         pdb=" N   SER A  17 "
         pdb=" CA  SER A  17 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -176.04   -3.96     0      5.00e+00 4.00e-02 6.28e-01
dihedral pdb=" CA  GLY A  23 "
         pdb=" C   GLY A  23 "
         pdb=" N   LYS A  24 "
         pdb=" CA  LYS A  24 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -176.13   -3.87     0      5.00e+00 4.00e-02 6.00e-01
dihedral pdb=" CA  HIS A  64 "
         pdb=" CB  HIS A  64 "
         pdb=" CG  HIS A  64 "
         pdb=" ND1 HIS A  64 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -90.00 -109.37   19.37     2      3.00e+01 1.11e-03 5.87e-01
dihedral pdb=" CA  ASN A  39 "
         pdb=" C   ASN A  39 "
         pdb=" N   GLU A  40 "
         pdb=" CA  GLU A  40 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  176.20    3.80     0      5.00e+00 4.00e-02 5.79e-01
dihedral pdb=" CA  TYR A  56 "
         pdb=" CB  TYR A  56 "
         pdb=" CG  TYR A  56 "
         pdb=" CD1 TYR A  56 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -90.00  -77.50  -12.50     2      2.00e+01 2.50e-03 5.62e-01
dihedral pdb=" CB  GLU A  30 "
         pdb=" CG  GLU A  30 "
         pdb=" CD  GLU A  30 "
         pdb=" OE1 GLU A  30 "
    ideal   model   delta sinusoidal    sigma   weight residual
     0.00  -18.51   18.51     1      3.00e+01 1.11e-03 5.52e-01
dihedral pdb=" N   CYS A  33 "
         pdb=" CA  CYS A  33 "
         pdb=" CB  CYS A  33 "
         pdb=" SG  CYS A  33 "
    ideal   model   delta sinusoidal    sigma   weight residual
    60.00   69.28   -9.28     3      1.50e+01 4.44e-03 5.49e-01
dihedral pdb=" CA  PRO A  42 "
         pdb=" CB  PRO A  42 "
         pdb=" CG  PRO A  42 "
         pdb=" CD  PRO A  42 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -38.00  -26.04  -11.96     1      2.00e+01 2.50e-03 5.21e-01
dihedral pdb=" N   PRO A  25 "
         pdb=" CA  PRO A  25 "
         pdb=" CB  PRO A  25 "
         pdb=" CG  PRO A  25 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -30.00  -18.07  -11.93     1      2.00e+01 2.50e-03 5.18e-01
dihedral pdb=" N   GLU A   5 "
         pdb=" CA  GLU A   5 "
         pdb=" CB  GLU A   5 "
         pdb=" CG  GLU A   5 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  171.18    8.82     3      1.50e+01 4.44e-03 4.97e-01
dihedral pdb=" CA  PHE A  68 "
         pdb=" C   PHE A  68 "
         pdb=" N   LYS A  69 "
         pdb=" CA  LYS A  69 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  176.51    3.49     0      5.00e+00 4.00e-02 4.87e-01
dihedral pdb=" N   THR A  15 "
         pdb=" CA  THR A  15 "
         pdb=" CB  THR A  15 "
         pdb=" OG1 THR A  15 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -68.68    8.68     3      1.50e+01 4.44e-03 4.82e-01
dihedral pdb=" CB  GLU A  40 "
         pdb=" CG  GLU A  40 "
         pdb=" CD  GLU A  40 "
         pdb=" OE1 GLU A  40 "
    ideal   model   delta sinusoidal    sigma   weight residual
     0.00   16.23  -16.23     1      3.00e+01 1.11e-03 4.25e-01
dihedral pdb=" CA  LEU A  37 "
         pdb=" CB  LEU A  37 "
         pdb=" CG  LEU A  37 "
         pdb=" CD1 LEU A  37 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -171.86   -8.14     3      1.50e+01 4.44e-03 4.24e-01
dihedral pdb=" CA  ASP A  36 "
         pdb=" C   ASP A  36 "
         pdb=" N   LEU A  37 "
         pdb=" CA  LEU A  37 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  176.75    3.25     0      5.00e+00 4.00e-02 4.22e-01
dihedral pdb=" CA  THR A  14 "
         pdb=" C   THR A  14 "
         pdb=" N   THR A  15 "
         pdb=" CA  THR A  15 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00 -176.78   -3.22     0      5.00e+00 4.00e-02 4.14e-01
dihedral pdb=" CA  LEU A  37 "
         pdb=" C   LEU A  37 "
         pdb=" N   GLY A  38 "
         pdb=" CA  GLY A  38 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  176.86    3.14     0      5.00e+00 4.00e-02 3.93e-01
dihedral pdb=" CA  LYS A  69 "
         pdb=" C   LYS A  69 "
         pdb=" N   VAL A  70 "
         pdb=" CA  VAL A  70 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  177.02    2.98     0      5.00e+00 4.00e-02 3.56e-01
dihedral pdb=" CA  LEU A  83 "
         pdb=" C   LEU A  83 "
         pdb=" N   VAL A  84 "
         pdb=" CA  VAL A  84 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  177.03    2.97     0      5.00e+00 4.00e-02 3.53e-01
dihedral pdb=" N   LEU A  37 "
         pdb=" CA  LEU A  37 "
         pdb=" CB  LEU A  37 "
         pdb=" CG  LEU A  37 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -67.27    7.27     3      1.50e+01 4.44e-03 3.40e-01
dihedral pdb=" CA  LYS A  46 "
         pdb=" C   LYS A  46 "
         pdb=" N   ILE A  47 "
         pdb=" CA  ILE A  47 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  177.09    2.91     0      5.00e+00 4.00e-02 3.38e-01
dihedral pdb=" CA  GLN A  10 "
         pdb=" CB  GLN A  10 "
         pdb=" CG  GLN A  10 "
         pdb=" CD  GLN A  10 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  172.78    7.22     3      1.50e+01 4.44e-03 3.34e-01
dihedral pdb=" CA  ARG A  80 "
         pdb=" C   ARG A  80 "
         pdb=" N   LEU A  81 "
         pdb=" CA  LEU A  81 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  177.11    2.89     0      5.00e+00 4.00e-02 3.34e-01
dihedral pdb=" N   THR A  48 "
         pdb=" CA  THR A  48 "
         pdb=" CB  THR A  48 "
         pdb=" OG1 THR A  48 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -67.17    7.17     3      1.50e+01 4.44e-03 3.30e-01
dihedral pdb=" CA  TYR A  26 "
         pdb=" CB  TYR A  26 "
         pdb=" CG  TYR A  26 "
         pdb=" CD1 TYR A  26 "
    ideal   model   delta sinusoidal    sigma   weight residual
    90.00   80.50    9.50     2      2.00e+01 2.50e-03 3.27e-01
dihedral pdb=" CA  GLN A  72 "
         pdb=" C   GLN A  72 "
         pdb=" N   PHE A  73 "
         pdb=" CA  PHE A  73 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -177.14   -2.86     0      5.00e+00 4.00e-02 3.26e-01
dihedral pdb=" CA  LEU A  32 "
         pdb=" C   LEU A  32 "
         pdb=" N   CYS A  33 "
         pdb=" CA  CYS A  33 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  177.20    2.80     0      5.00e+00 4.00e-02 3.13e-01
dihedral pdb=" CA  SER A  66 "
         pdb=" C   SER A  66 "
         pdb=" N   SER A  67 "
         pdb=" CA  SER A  67 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  177.20    2.80     0      5.00e+00 4.00e-02 3.13e-01
dihedral pdb=" CA  GLY A  71 "
         pdb=" C   GLY A  71 "
         pdb=" N   GLN A  72 "
         pdb=" CA  GLN A  72 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -177.21   -2.79     0      5.00e+00 4.00e-02 3.11e-01
dihedral pdb=" N   TYR A  41 "
         pdb=" CA  TYR A  41 "
         pdb=" CB  TYR A  41 "
         pdb=" CG  TYR A  41 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -66.86    6.86     3      1.50e+01 4.44e-03 3.03e-01
dihedral pdb=" CA  ASN A  29 "
         pdb=" CB  ASN A  29 "
         pdb=" CG  ASN A  29 "
         pdb=" OD1 ASN A  29 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -30.00  -21.23   -8.77     2      2.00e+01 2.50e-03 2.79e-01
dihedral pdb=" CA  SER A  20 "
         pdb=" C   SER A  20 "
         pdb=" N   ARG A  21 "
         pdb=" CA  ARG A  21 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00 -177.41   -2.59     0      5.00e+00 4.00e-02 2.68e-01
dihedral pdb=" N   GLU A  51 "
         pdb=" CA  GLU A  51 "
         pdb=" CB  GLU A  51 "
         pdb=" CG  GLU A  51 "
    ideal   model   delta sinusoidal    sigma   weight residual
    60.00   66.33   -6.33     3      1.50e+01 4.44e-03 2.58e-01
dihedral pdb=" CA  ILE A   2 "
         pdb=" CB  ILE A   2 "
         pdb=" CG1 ILE A   2 "
         pdb=" CD1 ILE A   2 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  173.70    6.30     3      1.50e+01 4.44e-03 2.55e-01
dihedral pdb=" N   VAL A  63 "
         pdb=" CA  VAL A  63 "
         pdb=" CB  VAL A  63 "
         pdb=" CG1 VAL A  63 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  173.83    6.17     3      1.50e+01 4.44e-03 2.46e-01
dihedral pdb=" N   LEU A  49 "
         pdb=" CA  LEU A  49 "
         pdb=" CB  LEU A  49 "
         pdb=" CG  LEU A  49 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -53.97   -6.03     3      1.50e+01 4.44e-03 2.34e-01
dihedral pdb=" CA  ILE A   2 "
         pdb=" C   ILE A   2 "
         pdb=" N   LYS A   3 "
         pdb=" CA  LYS A   3 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -177.63   -2.37     0      5.00e+00 4.00e-02 2.25e-01
dihedral pdb=" CB  ARG A  80 "
         pdb=" CG  ARG A  80 "
         pdb=" CD  ARG A  80 "
         pdb=" NE  ARG A  80 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -174.18   -5.82     3      1.50e+01 4.44e-03 2.19e-01
dihedral pdb=" CA  SER A   9 "
         pdb=" C   SER A   9 "
         pdb=" N   GLN A  10 "
         pdb=" CA  GLN A  10 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -177.69   -2.31     0      5.00e+00 4.00e-02 2.14e-01
dihedral pdb=" N   SER A  66 "
         pdb=" CA  SER A  66 "
         pdb=" CB  SER A  66 "
         pdb=" OG  SER A  66 "
    ideal   model   delta sinusoidal    sigma   weight residual
    60.00   65.72   -5.72     3      1.50e+01 4.44e-03 2.11e-01
dihedral pdb=" CA  TYR A  34 "
         pdb=" C   TYR A  34 "
         pdb=" N   VAL A  35 "
         pdb=" CA  VAL A  35 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  177.77    2.23     0      5.00e+00 4.00e-02 1.99e-01
dihedral pdb=" CA  GLY A  59 "
         pdb=" C   GLY A  59 "
         pdb=" N   LEU A  60 "
         pdb=" CA  LEU A  60 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00 -177.85   -2.15     0      5.00e+00 4.00e-02 1.86e-01
dihedral pdb=" N   PRO A  25 "
         pdb=" CG  PRO A  25 "
         pdb=" CD  PRO A  25 "
         pdb=" CB  PRO A  25 "
    ideal   model   delta sinusoidal    sigma   weight residual
    30.00   35.33   -5.33     1      1.50e+01 4.44e-03 1.84e-01
dihedral pdb=" CA  LEU A  44 "
         pdb=" C   LEU A  44 "
         pdb=" N   VAL A  45 "
         pdb=" CA  VAL A  45 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -177.89   -2.11     0      5.00e+00 4.00e-02 1.78e-01
dihedral pdb=" CA  GLU A  40 "
         pdb=" C   GLU A  40 "
         pdb=" N   TYR A  41 "
         pdb=" CA  TYR A  41 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  177.92    2.08     0      5.00e+00 4.00e-02 1.74e-01
dihedral pdb=" CA  GLY A  18 "
         pdb=" C   GLY A  18 "
         pdb=" N   VAL A  19 "
         pdb=" CA  VAL A  19 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  177.93    2.07     0      5.00e+00 4.00e-02 1.72e-01
dihedral pdb=" CA  LEU A  83 "
         pdb=" CB  LEU A  83 "
         pdb=" CG  LEU A  83 "
         pdb=" CD1 LEU A  83 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00 -174.94   -5.06     3      1.50e+01 4.44e-03 1.66e-01
dihedral pdb=" CA  PRO A  25 "
         pdb=" C   PRO A  25 "
         pdb=" N   TYR A  26 "
         pdb=" CA  TYR A  26 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  178.01    1.99     0      5.00e+00 4.00e-02 1.58e-01
dihedral pdb=" CA  TYR A  26 "
         pdb=" C   TYR A  26 "
         pdb=" N   SER A  27 "
         pdb=" CA  SER A  27 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  178.01    1.99     0      5.00e+00 4.00e-02 1.58e-01
dihedral pdb=" CB  ARG A  16 "
         pdb=" CG  ARG A  16 "
         pdb=" CD  ARG A  16 "
         pdb=" NE  ARG A  16 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -55.18   -4.82     3      1.50e+01 4.44e-03 1.50e-01
dihedral pdb=" CA  ARG A  82 "
         pdb=" CB  ARG A  82 "
         pdb=" CG  ARG A  82 "
         pdb=" CD  ARG A  82 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -175.19   -4.81     3      1.50e+01 4.44e-03 1.50e-01
dihedral pdb=" N   GLN A  10 "
         pdb=" CA  GLN A  10 "
         pdb=" CB  GLN A  10 "
         pdb=" CG  GLN A  10 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -55.36   -4.64     3      1.50e+01 4.44e-03 1.39e-01
dihedral pdb=" CG  LYS A  24 "
         pdb=" CD  LYS A  24 "
         pdb=" CE  LYS A  24 "
         pdb=" NZ  LYS A  24 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -175.55   -4.45     3      1.50e+01 4.44e-03 1.28e-01
dihedral pdb=" CA  LEU A  60 "
         pdb=" C   LEU A  60 "
         pdb=" N   TYR A  61 "
         pdb=" CA  TYR A  61 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -178.22   -1.78     0      5.00e+00 4.00e-02 1.27e-01
dihedral pdb=" CA  TYR A  34 "
         pdb=" CB  TYR A  34 "
         pdb=" CG  TYR A  34 "
         pdb=" CD1 TYR A  34 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -90.00  -84.12   -5.88     2      2.00e+01 2.50e-03 1.26e-01
dihedral pdb=" CA  GLU A  51 "
         pdb=" C   GLU A  51 "
         pdb=" N   GLY A  52 "
         pdb=" CA  GLY A  52 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  178.27    1.73     0      5.00e+00 4.00e-02 1.20e-01
dihedral pdb=" N   ASN A  39 "
         pdb=" CA  ASN A  39 "
         pdb=" CB  ASN A  39 "
         pdb=" CG  ASN A  39 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -64.29    4.29     3      1.50e+01 4.44e-03 1.19e-01
dihedral pdb=" N   PHE A  68 "
         pdb=" CA  PHE A  68 "
         pdb=" CB  PHE A  68 "
         pdb=" CG  PHE A  68 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -55.74   -4.26     3      1.50e+01 4.44e-03 1.18e-01
dihedral pdb=" CA  GLY A  52 "
         pdb=" C   GLY A  52 "
         pdb=" N   GLN A  53 "
         pdb=" CA  GLN A  53 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -178.32   -1.68     0      5.00e+00 4.00e-02 1.12e-01
dihedral pdb=" CA  GLU A  30 "
         pdb=" CB  GLU A  30 "
         pdb=" CG  GLU A  30 "
         pdb=" CD  GLU A  30 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00 -176.01   -3.99     3      1.50e+01 4.44e-03 1.03e-01
dihedral pdb=" CA  GLN A  31 "
         pdb=" CB  GLN A  31 "
         pdb=" CG  GLN A  31 "
         pdb=" CD  GLN A  31 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  176.20    3.80     3      1.50e+01 4.44e-03 9.34e-02
dihedral pdb=" CA  LEU A  65 "
         pdb=" CB  LEU A  65 "
         pdb=" CG  LEU A  65 "
         pdb=" CD1 LEU A  65 "
    ideal   model   delta sinusoidal    sigma   weight residual
    60.00   56.21    3.79     3      1.50e+01 4.44e-03 9.29e-02
dihedral pdb=" CA  ILE A  78 "
         pdb=" CB  ILE A  78 "
         pdb=" CG1 ILE A  78 "
         pdb=" CD1 ILE A  78 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -176.30   -3.70     3      1.50e+01 4.44e-03 8.86e-02
dihedral pdb=" CB  GLU A   5 "
         pdb=" CG  GLU A   5 "
         pdb=" CD  GLU A   5 "
         pdb=" OE1 GLU A   5 "
    ideal   model   delta sinusoidal    sigma   weight residual
     0.00    7.38   -7.38     1      3.00e+01 1.11e-03 8.85e-02
dihedral pdb=" N   PHE A  13 "
         pdb=" CA  PHE A  13 "
         pdb=" CB  PHE A  13 "
         pdb=" CG  PHE A  13 "
    ideal   model   delta sinusoidal    sigma   weight residual
    60.00   63.68   -3.68     3      1.50e+01 4.44e-03 8.79e-02
dihedral pdb=" N   PRO A  85 "
         pdb=" CG  PRO A  85 "
         pdb=" CD  PRO A  85 "
         pdb=" CB  PRO A  85 "
    ideal   model   delta sinusoidal    sigma   weight residual
    30.00   26.42    3.58     1      1.50e+01 4.44e-03 8.32e-02
dihedral pdb=" CA  ARG A  80 "
         pdb=" CB  ARG A  80 "
         pdb=" CG  ARG A  80 "
         pdb=" CD  ARG A  80 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  176.45    3.55     3      1.50e+01 4.44e-03 8.18e-02
dihedral pdb=" N   PHE A  73 "
         pdb=" CA  PHE A  73 "
         pdb=" CB  PHE A  73 "
         pdb=" CG  PHE A  73 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -63.55    3.55     3      1.50e+01 4.44e-03 8.16e-02
dihedral pdb=" CA  VAL A  63 "
         pdb=" C   VAL A  63 "
         pdb=" N   HIS A  64 "
         pdb=" CA  HIS A  64 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -178.58   -1.42     0      5.00e+00 4.00e-02 8.08e-02
dihedral pdb=" CA  VAL A  43 "
         pdb=" C   VAL A  43 "
         pdb=" N   LEU A  44 "
         pdb=" CA  LEU A  44 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -178.59   -1.41     0      5.00e+00 4.00e-02 7.91e-02
dihedral pdb=" N   PRO A  58 "
         pdb=" CA  PRO A  58 "
         pdb=" CB  PRO A  58 "
         pdb=" CG  PRO A  58 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -30.00  -25.45   -4.55     1      2.00e+01 2.50e-03 7.56e-02
dihedral pdb=" N   SER A  67 "
         pdb=" CA  SER A  67 "
         pdb=" CB  SER A  67 "
         pdb=" OG  SER A  67 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -56.63   -3.37     3      1.50e+01 4.44e-03 7.37e-02
dihedral pdb=" CA  LEU A  60 "
         pdb=" CB  LEU A  60 "
         pdb=" CG  LEU A  60 "
         pdb=" CD1 LEU A  60 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  176.70    3.30     3      1.50e+01 4.44e-03 7.06e-02
dihedral pdb=" CA  ASP A  50 "
         pdb=" C   ASP A  50 "
         pdb=" N   GLU A  51 "
         pdb=" CA  GLU A  51 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -178.67   -1.33     0      5.00e+00 4.00e-02 7.03e-02
dihedral pdb=" N   ILE A  47 "
         pdb=" CA  ILE A  47 "
         pdb=" CB  ILE A  47 "
         pdb=" CG1 ILE A  47 "
    ideal   model   delta sinusoidal    sigma   weight residual
    60.00   63.29   -3.29     3      1.50e+01 4.44e-03 7.01e-02
dihedral pdb=" CA  GLU A  30 "
         pdb=" C   GLU A  30 "
         pdb=" N   GLN A  31 "
         pdb=" CA  GLN A  31 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00 -178.68   -1.32     0      5.00e+00 4.00e-02 6.99e-02
dihedral pdb=" CA  THR A  48 "
         pdb=" C   THR A  48 "
         pdb=" N   LEU A  49 "
         pdb=" CA  LEU A  49 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  178.70    1.30     0      5.00e+00 4.00e-02 6.80e-02
dihedral pdb=" CA  ASN A  39 "
         pdb=" CB  ASN A  39 "
         pdb=" CG  ASN A  39 "
         pdb=" OD1 ASN A  39 "
    ideal   model   delta sinusoidal    sigma   weight residual
   120.00  124.29   -4.29     2      2.00e+01 2.50e-03 6.73e-02
dihedral pdb=" CA  TYR A  61 "
         pdb=" CB  TYR A  61 "
         pdb=" CG  TYR A  61 "
         pdb=" CD1 TYR A  61 "
    ideal   model   delta sinusoidal    sigma   weight residual
    90.00   85.71    4.29     2      2.00e+01 2.50e-03 6.71e-02
dihedral pdb=" CA  PRO A  54 "
         pdb=" CB  PRO A  54 "
         pdb=" CG  PRO A  54 "
         pdb=" CD  PRO A  54 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -38.00  -33.77   -4.23     1      2.00e+01 2.50e-03 6.53e-02
dihedral pdb=" N   PRO A  54 "
         pdb=" CA  PRO A  54 "
         pdb=" CB  PRO A  54 "
         pdb=" CG  PRO A  54 "
    ideal   model   delta sinusoidal    sigma   weight residual
    30.00   25.84    4.16     1      2.00e+01 2.50e-03 6.32e-02
dihedral pdb=" CB  GLN A  31 "
         pdb=" CG  GLN A  31 "
         pdb=" CD  GLN A  31 "
         pdb=" OE1 GLN A  31 "
    ideal   model   delta sinusoidal    sigma   weight residual
     0.00    6.19   -6.19     2      3.00e+01 1.11e-03 6.19e-02
dihedral pdb=" CA  LEU A  81 "
         pdb=" CB  LEU A  81 "
         pdb=" CG  LEU A  81 "
         pdb=" CD1 LEU A  81 "
    ideal   model   delta sinusoidal    sigma   weight residual
    60.00   63.07   -3.07     3      1.50e+01 4.44e-03 6.10e-02
dihedral pdb=" CA  PRO A  25 "
         pdb=" CB  PRO A  25 "
         pdb=" CG  PRO A  25 "
         pdb=" CD  PRO A  25 "
    ideal   model   delta sinusoidal    sigma   weight residual
    38.00   33.92    4.08     1      2.00e+01 2.50e-03 6.09e-02
dihedral pdb=" CD  ARG A  82 "
         pdb=" NE  ARG A  82 "
         pdb=" CZ  ARG A  82 "
         pdb=" NH1 ARG A  82 "
    ideal   model   delta sinusoidal    sigma   weight residual
     0.00    2.03   -2.03     1      1.00e+01 1.00e-02 6.00e-02
dihedral pdb=" CA  VAL A  19 "
         pdb=" C   VAL A  19 "
         pdb=" N   SER A  20 "
         pdb=" CA  SER A  20 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -178.79   -1.21     0      5.00e+00 4.00e-02 5.86e-02
dihedral pdb=" CG  LYS A  69 "
         pdb=" CD  LYS A  69 "
         pdb=" CE  LYS A  69 "
         pdb=" NZ  LYS A  69 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  177.03    2.97     3      1.50e+01 4.44e-03 5.70e-02
dihedral pdb=" N   PRO A  42 "
         pdb=" CG  PRO A  42 "
         pdb=" CD  PRO A  42 "
         pdb=" CB  PRO A  42 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -30.00  -27.06   -2.94     1      1.50e+01 4.44e-03 5.61e-02
dihedral pdb=" CA  ILE A  47 "
         pdb=" CB  ILE A  47 "
         pdb=" CG1 ILE A  47 "
         pdb=" CD1 ILE A  47 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -177.18   -2.82     3      1.50e+01 4.44e-03 5.17e-02
dihedral pdb=" CA  MSE A  77 "
         pdb=" C   MSE A  77 "
         pdb=" N   ILE A  78 "
         pdb=" CA  ILE A  78 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00 -178.88   -1.12     0      5.00e+00 4.00e-02 5.05e-02
dihedral pdb=" CA  LEU A  76 "
         pdb=" C   LEU A  76 "
         pdb=" N   MSE A  77 "
         pdb=" CA  MSE A  77 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  178.88    1.12     0      5.00e+00 4.00e-02 5.00e-02
dihedral pdb=" CA  ILE A   6 "
         pdb=" C   ILE A   6 "
         pdb=" N   LYS A   7 "
         pdb=" CA  LYS A   7 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  178.89    1.11     0      5.00e+00 4.00e-02 4.96e-02
dihedral pdb=" CA  PRO A  58 "
         pdb=" C   PRO A  58 "
         pdb=" N   GLY A  59 "
         pdb=" CA  GLY A  59 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  178.92    1.08     0      5.00e+00 4.00e-02 4.68e-02
dihedral pdb=" CA  VAL A   4 "
         pdb=" C   VAL A   4 "
         pdb=" N   GLU A   5 "
         pdb=" CA  GLU A   5 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  178.93    1.07     0      5.00e+00 4.00e-02 4.56e-02
dihedral pdb=" N   LEU A  83 "
         pdb=" CA  LEU A  83 "
         pdb=" CB  LEU A  83 "
         pdb=" CG  LEU A  83 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -57.36   -2.64     3      1.50e+01 4.44e-03 4.53e-02
dihedral pdb=" N   ASP A  79 "
         pdb=" CA  ASP A  79 "
         pdb=" CB  ASP A  79 "
         pdb=" CG  ASP A  79 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  177.37    2.63     3      1.50e+01 4.44e-03 4.48e-02
dihedral pdb=" CB  LYS A  69 "
         pdb=" CG  LYS A  69 "
         pdb=" CD  LYS A  69 "
         pdb=" CE  LYS A  69 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -62.49    2.49     3      1.50e+01 4.44e-03 4.04e-02
dihedral pdb=" CA  SER A  27 "
         pdb=" C   SER A  27 "
         pdb=" N   LEU A  28 "
         pdb=" CA  LEU A  28 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -179.00   -1.00     0      5.00e+00 4.00e-02 4.01e-02
dihedral pdb=" CA  PRO A  58 "
         pdb=" CB  PRO A  58 "
         pdb=" CG  PRO A  58 "
         pdb=" CD  PRO A  58 "
    ideal   model   delta sinusoidal    sigma   weight residual
    38.00   34.74    3.26     1      2.00e+01 2.50e-03 3.88e-02
dihedral pdb=" CA  GLN A  31 "
         pdb=" C   GLN A  31 "
         pdb=" N   LEU A  32 "
         pdb=" CA  LEU A  32 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  179.05    0.95     0      5.00e+00 4.00e-02 3.63e-02
dihedral pdb=" CG  ARG A  82 "
         pdb=" CD  ARG A  82 "
         pdb=" NE  ARG A  82 "
         pdb=" CZ  ARG A  82 "
    ideal   model   delta sinusoidal    sigma   weight residual
    90.00   92.35   -2.35     2      1.50e+01 4.44e-03 3.59e-02
dihedral pdb=" N   ILE A   6 "
         pdb=" CA  ILE A   6 "
         pdb=" CB  ILE A   6 "
         pdb=" CG1 ILE A   6 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -57.66   -2.34     3      1.50e+01 4.44e-03 3.56e-02
dihedral pdb=" CA  PHE A  68 "
         pdb=" CB  PHE A  68 "
         pdb=" CG  PHE A  68 "
         pdb=" CD1 PHE A  68 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -90.00  -86.98   -3.02     2      2.00e+01 2.50e-03 3.33e-02
dihedral pdb=" CA  PRO A   8 "
         pdb=" CB  PRO A   8 "
         pdb=" CG  PRO A   8 "
         pdb=" CD  PRO A   8 "
    ideal   model   delta sinusoidal    sigma   weight residual
    38.00   35.14    2.86     1      2.00e+01 2.50e-03 2.98e-02
dihedral pdb=" N   GLU A  30 "
         pdb=" CA  GLU A  30 "
         pdb=" CB  GLU A  30 "
         pdb=" CG  GLU A  30 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -57.86   -2.14     3      1.50e+01 4.44e-03 2.96e-02
dihedral pdb=" CG  ARG A  80 "
         pdb=" CD  ARG A  80 "
         pdb=" NE  ARG A  80 "
         pdb=" CZ  ARG A  80 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -177.86   -2.14     2      1.50e+01 4.44e-03 2.96e-02
dihedral pdb=" N   PRO A  54 "
         pdb=" CG  PRO A  54 "
         pdb=" CD  PRO A  54 "
         pdb=" CB  PRO A  54 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -30.00  -27.88   -2.12     1      1.50e+01 4.44e-03 2.93e-02
dihedral pdb=" N   ASP A  50 "
         pdb=" CA  ASP A  50 "
         pdb=" CB  ASP A  50 "
         pdb=" CG  ASP A  50 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -62.10    2.10     3      1.50e+01 4.44e-03 2.86e-02
dihedral pdb=" N   VAL A  35 "
         pdb=" CA  VAL A  35 "
         pdb=" CB  VAL A  35 "
         pdb=" CG1 VAL A  35 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  177.94    2.06     3      1.50e+01 4.44e-03 2.76e-02
dihedral pdb=" N   PRO A   8 "
         pdb=" CG  PRO A   8 "
         pdb=" CD  PRO A   8 "
         pdb=" CB  PRO A   8 "
    ideal   model   delta sinusoidal    sigma   weight residual
    30.00   28.00    2.00     1      1.50e+01 4.44e-03 2.61e-02
dihedral pdb=" CB  GLN A  72 "
         pdb=" CG  GLN A  72 "
         pdb=" CD  GLN A  72 "
         pdb=" OE1 GLN A  72 "
    ideal   model   delta sinusoidal    sigma   weight residual
     0.00    3.83   -3.83     2      3.00e+01 1.11e-03 2.39e-02
dihedral pdb=" CA  PRO A  85 "
         pdb=" CB  PRO A  85 "
         pdb=" CG  PRO A  85 "
         pdb=" CD  PRO A  85 "
    ideal   model   delta sinusoidal    sigma   weight residual
    38.00   35.53    2.47     1      2.00e+01 2.50e-03 2.24e-02
dihedral pdb=" N   PRO A   8 "
         pdb=" CA  PRO A   8 "
         pdb=" CB  PRO A   8 "
         pdb=" CG  PRO A   8 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -30.00  -27.62   -2.38     1      2.00e+01 2.50e-03 2.07e-02
dihedral pdb=" CD  ARG A  16 "
         pdb=" NE  ARG A  16 "
         pdb=" CZ  ARG A  16 "
         pdb=" NH1 ARG A  16 "
    ideal   model   delta sinusoidal    sigma   weight residual
     0.00    1.13   -1.13     1      1.00e+01 1.00e-02 1.87e-02
dihedral pdb=" CA  ARG A  16 "
         pdb=" CB  ARG A  16 "
         pdb=" CG  ARG A  16 "
         pdb=" CD  ARG A  16 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  178.32    1.68     3      1.50e+01 4.44e-03 1.83e-02
dihedral pdb=" N   TYR A  61 "
         pdb=" CA  TYR A  61 "
         pdb=" CB  TYR A  61 "
         pdb=" CG  TYR A  61 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -61.68    1.68     3      1.50e+01 4.44e-03 1.83e-02
dihedral pdb=" CA  PHE A  13 "
         pdb=" CB  PHE A  13 "
         pdb=" CG  PHE A  13 "
         pdb=" CD1 PHE A  13 "
    ideal   model   delta sinusoidal    sigma   weight residual
    90.00   87.81    2.19     2      2.00e+01 2.50e-03 1.76e-02
dihedral pdb=" N   VAL A   4 "
         pdb=" CA  VAL A   4 "
         pdb=" CB  VAL A   4 "
         pdb=" CG1 VAL A   4 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -178.59   -1.41     3      1.50e+01 4.44e-03 1.29e-02
dihedral pdb=" N   LEU A  28 "
         pdb=" CA  LEU A  28 "
         pdb=" CB  LEU A  28 "
         pdb=" CG  LEU A  28 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -61.33    1.33     3      1.50e+01 4.44e-03 1.15e-02
dihedral pdb=" CD1 TYR A  26 "
         pdb=" CE1 TYR A  26 "
         pdb=" CZ  TYR A  26 "
         pdb=" OH  TYR A  26 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -179.48   -0.52     0      5.00e+00 4.00e-02 1.09e-02
dihedral pdb=" CA  SER A  17 "
         pdb=" C   SER A  17 "
         pdb=" N   GLY A  18 "
         pdb=" CA  GLY A  18 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  179.48    0.52     0      5.00e+00 4.00e-02 1.07e-02
dihedral pdb=" N   SER A  75 "
         pdb=" CA  SER A  75 "
         pdb=" CB  SER A  75 "
         pdb=" OG  SER A  75 "
    ideal   model   delta sinusoidal    sigma   weight residual
    60.00   61.27   -1.27     3      1.50e+01 4.44e-03 1.04e-02
dihedral pdb=" CA  ASP A  36 "
         pdb=" CB  ASP A  36 "
         pdb=" CG  ASP A  36 "
         pdb=" OD1 ASP A  36 "
    ideal   model   delta sinusoidal    sigma   weight residual
     0.00   -1.62    1.62     1      2.00e+01 2.50e-03 9.61e-03
dihedral pdb=" CA  LEU A  28 "
         pdb=" C   LEU A  28 "
         pdb=" N   ASN A  29 "
         pdb=" CA  ASN A  29 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  179.56    0.44     0      5.00e+00 4.00e-02 7.71e-03
dihedral pdb=" CG  LYS A  46 "
         pdb=" CD  LYS A  46 "
         pdb=" CE  LYS A  46 "
         pdb=" NZ  LYS A  46 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  178.93    1.07     3      1.50e+01 4.44e-03 7.41e-03
dihedral pdb=" CA  PHE A  73 "
         pdb=" C   PHE A  73 "
         pdb=" N   GLY A  74 "
         pdb=" CA  GLY A  74 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  179.62    0.38     0      5.00e+00 4.00e-02 5.79e-03
dihedral pdb=" CA  SER A  75 "
         pdb=" C   SER A  75 "
         pdb=" N   LEU A  76 "
         pdb=" CA  LEU A  76 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -179.64   -0.36     0      5.00e+00 4.00e-02 5.05e-03
dihedral pdb=" CA  LYS A  24 "
         pdb=" CB  LYS A  24 "
         pdb=" CG  LYS A  24 "
         pdb=" CD  LYS A  24 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  179.15    0.85     3      1.50e+01 4.44e-03 4.65e-03
dihedral pdb=" CA  LEU A  65 "
         pdb=" C   LEU A  65 "
         pdb=" N   SER A  66 "
         pdb=" CA  SER A  66 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  179.71    0.29     0      5.00e+00 4.00e-02 3.27e-03
dihedral pdb=" N   ASN A  29 "
         pdb=" CA  ASN A  29 "
         pdb=" CB  ASN A  29 "
         pdb=" CG  ASN A  29 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -60.68    0.68     3      1.50e+01 4.44e-03 3.01e-03
dihedral pdb=" CD1 TYR A  41 "
         pdb=" CE1 TYR A  41 "
         pdb=" CZ  TYR A  41 "
         pdb=" OH  TYR A  41 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -179.73   -0.27     0      5.00e+00 4.00e-02 2.93e-03
dihedral pdb=" CA  ILE A  47 "
         pdb=" C   ILE A  47 "
         pdb=" N   THR A  48 "
         pdb=" CA  THR A  48 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  179.74    0.26     0      5.00e+00 4.00e-02 2.75e-03
dihedral pdb=" N   LYS A  46 "
         pdb=" CA  LYS A  46 "
         pdb=" CB  LYS A  46 "
         pdb=" CG  LYS A  46 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -179.36   -0.64     3      1.50e+01 4.44e-03 2.67e-03
dihedral pdb=" N   VAL A  19 "
         pdb=" CA  VAL A  19 "
         pdb=" CB  VAL A  19 "
         pdb=" CG1 VAL A  19 "
    ideal   model   delta sinusoidal    sigma   weight residual
   180.00  179.38    0.62     3      1.50e+01 4.44e-03 2.48e-03
dihedral pdb=" CA  VAL A  35 "
         pdb=" C   VAL A  35 "
         pdb=" N   ASP A  36 "
         pdb=" CA  ASP A  36 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00 -179.76   -0.24     0      5.00e+00 4.00e-02 2.26e-03
dihedral pdb=" N   THR A  14 "
         pdb=" CA  THR A  14 "
         pdb=" CB  THR A  14 "
         pdb=" OG1 THR A  14 "
    ideal   model   delta sinusoidal    sigma   weight residual
    60.00   59.50    0.50     3      1.50e+01 4.44e-03 1.65e-03
dihedral pdb=" N   ARG A  16 "
         pdb=" CA  ARG A  16 "
         pdb=" CB  ARG A  16 "
         pdb=" CG  ARG A  16 "
    ideal   model   delta sinusoidal    sigma   weight residual
    60.00   60.48   -0.48     3      1.50e+01 4.44e-03 1.51e-03
dihedral pdb=" N   LYS A  69 "
         pdb=" CA  LYS A  69 "
         pdb=" CB  LYS A  69 "
         pdb=" CG  LYS A  69 "
    ideal   model   delta sinusoidal    sigma   weight residual
    60.00   59.52    0.48     3      1.50e+01 4.44e-03 1.47e-03
dihedral pdb=" CD  ARG A  80 "
         pdb=" NE  ARG A  80 "
         pdb=" CZ  ARG A  80 "
         pdb=" NH1 ARG A  80 "
    ideal   model   delta sinusoidal    sigma   weight residual
     0.00    0.29   -0.29     1      1.00e+01 1.00e-02 1.25e-03
dihedral pdb=" CD1 TYR A  34 "
         pdb=" CE1 TYR A  34 "
         pdb=" CZ  TYR A  34 "
         pdb=" OH  TYR A  34 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -179.83   -0.17     0      5.00e+00 4.00e-02 1.10e-03
dihedral pdb=" CA  LEU A  81 "
         pdb=" C   LEU A  81 "
         pdb=" N   ARG A  82 "
         pdb=" CA  ARG A  82 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  179.85    0.15     0      5.00e+00 4.00e-02 9.40e-04
dihedral pdb=" CA  GLN A  72 "
         pdb=" CB  GLN A  72 "
         pdb=" CG  GLN A  72 "
         pdb=" CD  GLN A  72 "
    ideal   model   delta sinusoidal    sigma   weight residual
  -180.00 -179.66   -0.34     3      1.50e+01 4.44e-03 7.43e-04
dihedral pdb=" CA  ALA A  11 "
         pdb=" C   ALA A  11 "
         pdb=" N   GLN A  12 "
         pdb=" CA  GLN A  12 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  179.87    0.13     0      5.00e+00 4.00e-02 6.47e-04
dihedral pdb=" N   PRO A  58 "
         pdb=" CG  PRO A  58 "
         pdb=" CD  PRO A  58 "
         pdb=" CB  PRO A  58 "
    ideal   model   delta sinusoidal    sigma   weight residual
    30.00   29.69    0.31     1      1.50e+01 4.44e-03 6.20e-04
dihedral pdb=" CD  ARG A  21 "
         pdb=" NE  ARG A  21 "
         pdb=" CZ  ARG A  21 "
         pdb=" NH1 ARG A  21 "
    ideal   model   delta sinusoidal    sigma   weight residual
     0.00    0.19   -0.19     1      1.00e+01 1.00e-02 5.36e-04
dihedral pdb=" CD1 TYR A  61 "
         pdb=" CE1 TYR A  61 "
         pdb=" CZ  TYR A  61 "
         pdb=" OH  TYR A  61 "
    ideal   model   delta  harmonic     sigma   weight residual
  -180.00 -179.89   -0.11     0      5.00e+00 4.00e-02 5.20e-04
dihedral pdb=" N   ARG A  82 "
         pdb=" CA  ARG A  82 "
         pdb=" CB  ARG A  82 "
         pdb=" CG  ARG A  82 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -59.76   -0.24     3      1.50e+01 4.44e-03 3.88e-04
dihedral pdb=" CA  PRO A   8 "
         pdb=" C   PRO A   8 "
         pdb=" N   SER A   9 "
         pdb=" CA  SER A   9 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  179.92    0.08     0      5.00e+00 4.00e-02 2.81e-04
dihedral pdb=" CA  GLY A  74 "
         pdb=" C   GLY A  74 "
         pdb=" N   SER A  75 "
         pdb=" CA  SER A  75 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  179.94    0.06     0      5.00e+00 4.00e-02 1.68e-04
dihedral pdb=" N   GLN A  22 "
         pdb=" CA  GLN A  22 "
         pdb=" CB  GLN A  22 "
         pdb=" CG  GLN A  22 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -60.12    0.12     3      1.50e+01 4.44e-03 1.00e-04
dihedral pdb=" N   TYR A  56 "
         pdb=" CA  TYR A  56 "
         pdb=" CB  TYR A  56 "
         pdb=" CG  TYR A  56 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -60.11    0.11     3      1.50e+01 4.44e-03 7.77e-05
dihedral pdb=" CD1 TYR A  56 "
         pdb=" CE1 TYR A  56 "
         pdb=" CZ  TYR A  56 "
         pdb=" OH  TYR A  56 "
    ideal   model   delta  harmonic     sigma   weight residual
   180.00  179.96    0.04     0      5.00e+00 4.00e-02 5.73e-05
dihedral pdb=" CA  LYS A   7 "
         pdb=" CB  LYS A   7 "
         pdb=" CG  LYS A   7 "
         pdb=" CD  LYS A   7 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -60.00  -59.91   -0.09     3      1.50e+01 4.44e-03 5.65e-05
dihedral pdb=" N   PRO A  85 "
         pdb=" CA  PRO A  85 "
         pdb=" CB  PRO A  85 "
         pdb=" CG  PRO A  85 "
    ideal   model   delta sinusoidal    sigma   weight residual
   -30.00  -29.95   -0.05     1      2.00e+01 2.50e-03 9.89e-06

Chirality | covalent geometry | restraints: 103
Sorted by residual:
chirality pdb=" CB  VAL A  45 "
          pdb=" CA  VAL A  45 "
          pdb=" CG1 VAL A  45 "
          pdb=" CG2 VAL A  45 "
  both_signs  ideal   model   delta    sigma   weight residual
    False     -2.63   -2.44   -0.19 2.00e-01 2.50e+01 9.25e-01
chirality pdb=" CA  LEU A  44 "
          pdb=" N   LEU A  44 "
          pdb=" C   LEU A  44 "
          pdb=" CB  LEU A  44 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.35    0.16 2.00e-01 2.50e+01 6.68e-01
chirality pdb=" CB  VAL A  43 "
          pdb=" CA  VAL A  43 "
          pdb=" CG1 VAL A  43 "
          pdb=" CG2 VAL A  43 "
  both_signs  ideal   model   delta    sigma   weight residual
    False     -2.63   -2.48   -0.15 2.00e-01 2.50e+01 5.26e-01
chirality pdb=" CA  ILE A   6 "
          pdb=" N   ILE A   6 "
          pdb=" C   ILE A   6 "
          pdb=" CB  ILE A   6 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.43    2.55   -0.12 2.00e-01 2.50e+01 3.69e-01
chirality pdb=" CA  VAL A   4 "
          pdb=" N   VAL A   4 "
          pdb=" C   VAL A   4 "
          pdb=" CB  VAL A   4 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.44    2.56   -0.12 2.00e-01 2.50e+01 3.68e-01
chirality pdb=" CA  VAL A  84 "
          pdb=" N   VAL A  84 "
          pdb=" C   VAL A  84 "
          pdb=" CB  VAL A  84 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.44    2.55   -0.11 2.00e-01 2.50e+01 3.05e-01
chirality pdb=" CA  VAL A  35 "
          pdb=" N   VAL A  35 "
          pdb=" C   VAL A  35 "
          pdb=" CB  VAL A  35 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.44    2.55   -0.11 2.00e-01 2.50e+01 2.82e-01
chirality pdb=" CA  LEU A  28 "
          pdb=" N   LEU A  28 "
          pdb=" C   LEU A  28 "
          pdb=" CB  LEU A  28 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.41    0.10 2.00e-01 2.50e+01 2.58e-01
chirality pdb=" CA  SER A  20 "
          pdb=" N   SER A  20 "
          pdb=" C   SER A  20 "
          pdb=" CB  SER A  20 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.41    0.10 2.00e-01 2.50e+01 2.54e-01
chirality pdb=" CA  VAL A  43 "
          pdb=" N   VAL A  43 "
          pdb=" C   VAL A  43 "
          pdb=" CB  VAL A  43 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.44    2.54   -0.10 2.00e-01 2.50e+01 2.51e-01
chirality pdb=" CA  ILE A  78 "
          pdb=" N   ILE A  78 "
          pdb=" C   ILE A  78 "
          pdb=" CB  ILE A  78 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.43    2.53   -0.10 2.00e-01 2.50e+01 2.30e-01
chirality pdb=" CA  VAL A  70 "
          pdb=" N   VAL A  70 "
          pdb=" C   VAL A  70 "
          pdb=" CB  VAL A  70 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.44    2.54   -0.09 2.00e-01 2.50e+01 2.25e-01
chirality pdb=" CA  LYS A  24 "
          pdb=" N   LYS A  24 "
          pdb=" C   LYS A  24 "
          pdb=" CB  LYS A  24 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.42    0.09 2.00e-01 2.50e+01 1.85e-01
chirality pdb=" CA  ILE A  47 "
          pdb=" N   ILE A  47 "
          pdb=" C   ILE A  47 "
          pdb=" CB  ILE A  47 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.43    2.52   -0.08 2.00e-01 2.50e+01 1.78e-01
chirality pdb=" CA  PRO A   8 "
          pdb=" N   PRO A   8 "
          pdb=" C   PRO A   8 "
          pdb=" CB  PRO A   8 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.72    2.64    0.08 2.00e-01 2.50e+01 1.74e-01
chirality pdb=" CA  PRO A  85 "
          pdb=" N   PRO A  85 "
          pdb=" C   PRO A  85 "
          pdb=" CB  PRO A  85 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.72    2.64    0.08 2.00e-01 2.50e+01 1.65e-01
chirality pdb=" CA  GLN A  22 "
          pdb=" N   GLN A  22 "
          pdb=" C   GLN A  22 "
          pdb=" CB  GLN A  22 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.43    0.08 2.00e-01 2.50e+01 1.47e-01
chirality pdb=" CA  VAL A  63 "
          pdb=" N   VAL A  63 "
          pdb=" C   VAL A  63 "
          pdb=" CB  VAL A  63 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.44    2.52   -0.08 2.00e-01 2.50e+01 1.42e-01
chirality pdb=" CA  ILE A   2 "
          pdb=" N   ILE A   2 "
          pdb=" C   ILE A   2 "
          pdb=" CB  ILE A   2 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.43    2.51   -0.07 2.00e-01 2.50e+01 1.39e-01
chirality pdb=" CA  SER A  27 "
          pdb=" N   SER A  27 "
          pdb=" C   SER A  27 "
          pdb=" CB  SER A  27 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.44    0.07 2.00e-01 2.50e+01 1.17e-01
chirality pdb=" CA  ARG A  21 "
          pdb=" N   ARG A  21 "
          pdb=" C   ARG A  21 "
          pdb=" CB  ARG A  21 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.44    0.07 2.00e-01 2.50e+01 1.08e-01
chirality pdb=" CB  VAL A  84 "
          pdb=" CA  VAL A  84 "
          pdb=" CG1 VAL A  84 "
          pdb=" CG2 VAL A  84 "
  both_signs  ideal   model   delta    sigma   weight residual
    False     -2.63   -2.56   -0.07 2.00e-01 2.50e+01 1.07e-01
chirality pdb=" CA  PHE A  73 "
          pdb=" N   PHE A  73 "
          pdb=" C   PHE A  73 "
          pdb=" CB  PHE A  73 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.45    0.06 2.00e-01 2.50e+01 1.02e-01
chirality pdb=" CG  LEU A  44 "
          pdb=" CB  LEU A  44 "
          pdb=" CD1 LEU A  44 "
          pdb=" CD2 LEU A  44 "
  both_signs  ideal   model   delta    sigma   weight residual
    False     -2.59   -2.65    0.06 2.00e-01 2.50e+01 9.63e-02
chirality pdb=" CA  LEU A  37 "
          pdb=" N   LEU A  37 "
          pdb=" C   LEU A  37 "
          pdb=" CB  LEU A  37 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.45    0.06 2.00e-01 2.50e+01 8.74e-02
chirality pdb=" CA  VAL A  19 "
          pdb=" N   VAL A  19 "
          pdb=" C   VAL A  19 "
          pdb=" CB  VAL A  19 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.44    2.50   -0.06 2.00e-01 2.50e+01 7.72e-02
chirality pdb=" CG  LEU A  32 "
          pdb=" CB  LEU A  32 "
          pdb=" CD1 LEU A  32 "
          pdb=" CD2 LEU A  32 "
  both_signs  ideal   model   delta    sigma   weight residual
    False     -2.59   -2.54   -0.05 2.00e-01 2.50e+01 7.13e-02
chirality pdb=" CB  VAL A  19 "
          pdb=" CA  VAL A  19 "
          pdb=" CG1 VAL A  19 "
          pdb=" CG2 VAL A  19 "
  both_signs  ideal   model   delta    sigma   weight residual
    False     -2.63   -2.58   -0.05 2.00e-01 2.50e+01 6.02e-02
chirality pdb=" CA  SER A  66 "
          pdb=" N   SER A  66 "
          pdb=" C   SER A  66 "
          pdb=" CB  SER A  66 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.46    0.05 2.00e-01 2.50e+01 5.70e-02
chirality pdb=" CA  PRO A  42 "
          pdb=" N   PRO A  42 "
          pdb=" C   PRO A  42 "
          pdb=" CB  PRO A  42 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.72    2.67    0.04 2.00e-01 2.50e+01 4.80e-02
chirality pdb=" CA  ASP A  36 "
          pdb=" N   ASP A  36 "
          pdb=" C   ASP A  36 "
          pdb=" CB  ASP A  36 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.55   -0.04 2.00e-01 2.50e+01 4.21e-02
chirality pdb=" CA  ALA A  57 "
          pdb=" N   ALA A  57 "
          pdb=" C   ALA A  57 "
          pdb=" CB  ALA A  57 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.48    2.53   -0.04 2.00e-01 2.50e+01 4.09e-02
chirality pdb=" CA  ALA A  55 "
          pdb=" N   ALA A  55 "
          pdb=" C   ALA A  55 "
          pdb=" CB  ALA A  55 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.48    2.52   -0.04 2.00e-01 2.50e+01 3.71e-02
chirality pdb=" CG  LEU A  28 "
          pdb=" CB  LEU A  28 "
          pdb=" CD1 LEU A  28 "
          pdb=" CD2 LEU A  28 "
  both_signs  ideal   model   delta    sigma   weight residual
    False     -2.59   -2.63    0.04 2.00e-01 2.50e+01 3.53e-02
chirality pdb=" CA  SER A   9 "
          pdb=" N   SER A   9 "
          pdb=" C   SER A   9 "
          pdb=" CB  SER A   9 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.47    0.04 2.00e-01 2.50e+01 3.48e-02
chirality pdb=" CA  LYS A  46 "
          pdb=" N   LYS A  46 "
          pdb=" C   LYS A  46 "
          pdb=" CB  LYS A  46 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.47    0.04 2.00e-01 2.50e+01 3.46e-02
chirality pdb=" CA  GLN A  31 "
          pdb=" N   GLN A  31 "
          pdb=" C   GLN A  31 "
          pdb=" CB  GLN A  31 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.54   -0.03 2.00e-01 2.50e+01 2.99e-02
chirality pdb=" CG  LEU A  60 "
          pdb=" CB  LEU A  60 "
          pdb=" CD1 LEU A  60 "
          pdb=" CD2 LEU A  60 "
  both_signs  ideal   model   delta    sigma   weight residual
    False     -2.59   -2.62    0.03 2.00e-01 2.50e+01 2.91e-02
chirality pdb=" CA  ALA A  11 "
          pdb=" N   ALA A  11 "
          pdb=" C   ALA A  11 "
          pdb=" CB  ALA A  11 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.48    2.45    0.03 2.00e-01 2.50e+01 2.85e-02
chirality pdb=" CA  PRO A  58 "
          pdb=" N   PRO A  58 "
          pdb=" C   PRO A  58 "
          pdb=" CB  PRO A  58 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.72    2.68    0.03 2.00e-01 2.50e+01 2.85e-02
chirality pdb=" CA  GLN A  72 "
          pdb=" N   GLN A  72 "
          pdb=" C   GLN A  72 "
          pdb=" CB  GLN A  72 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.48    0.03 2.00e-01 2.50e+01 2.80e-02
chirality pdb=" CB  THR A  15 "
          pdb=" CA  THR A  15 "
          pdb=" OG1 THR A  15 "
          pdb=" CG2 THR A  15 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.55    2.52    0.03 2.00e-01 2.50e+01 2.55e-02
chirality pdb=" CA  ASN A  29 "
          pdb=" N   ASN A  29 "
          pdb=" C   ASN A  29 "
          pdb=" CB  ASN A  29 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.54   -0.03 2.00e-01 2.50e+01 2.22e-02
chirality pdb=" CA  GLN A  10 "
          pdb=" N   GLN A  10 "
          pdb=" C   GLN A  10 "
          pdb=" CB  GLN A  10 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.48    0.03 2.00e-01 2.50e+01 2.12e-02
chirality pdb=" CA  ASP A  50 "
          pdb=" N   ASP A  50 "
          pdb=" C   ASP A  50 "
          pdb=" CB  ASP A  50 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.54   -0.03 2.00e-01 2.50e+01 2.10e-02
chirality pdb=" CB  ILE A   6 "
          pdb=" CA  ILE A   6 "
          pdb=" CG1 ILE A   6 "
          pdb=" CG2 ILE A   6 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.64    2.62    0.03 2.00e-01 2.50e+01 2.10e-02
chirality pdb=" CA  TYR A  61 "
          pdb=" N   TYR A  61 "
          pdb=" C   TYR A  61 "
          pdb=" CB  TYR A  61 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.54   -0.03 2.00e-01 2.50e+01 2.05e-02
chirality pdb=" CB  THR A  62 "
          pdb=" CA  THR A  62 "
          pdb=" OG1 THR A  62 "
          pdb=" CG2 THR A  62 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.55    2.52    0.03 2.00e-01 2.50e+01 2.03e-02
chirality pdb=" CA  ASP A  79 "
          pdb=" N   ASP A  79 "
          pdb=" C   ASP A  79 "
          pdb=" CB  ASP A  79 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.54   -0.03 2.00e-01 2.50e+01 2.00e-02
chirality pdb=" CA  TYR A  41 "
          pdb=" N   TYR A  41 "
          pdb=" C   TYR A  41 "
          pdb=" CB  TYR A  41 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.54   -0.03 2.00e-01 2.50e+01 1.78e-02
chirality pdb=" CA  TYR A  34 "
          pdb=" N   TYR A  34 "
          pdb=" C   TYR A  34 "
          pdb=" CB  TYR A  34 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.54   -0.03 2.00e-01 2.50e+01 1.71e-02
chirality pdb=" CG  LEU A  65 "
          pdb=" CB  LEU A  65 "
          pdb=" CD1 LEU A  65 "
          pdb=" CD2 LEU A  65 "
  both_signs  ideal   model   delta    sigma   weight residual
    False     -2.59   -2.62    0.03 2.00e-01 2.50e+01 1.70e-02
chirality pdb=" CA  ARG A  80 "
          pdb=" N   ARG A  80 "
          pdb=" C   ARG A  80 "
          pdb=" CB  ARG A  80 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.54   -0.03 2.00e-01 2.50e+01 1.69e-02
chirality pdb=" CA  LYS A   7 "
          pdb=" N   LYS A   7 "
          pdb=" C   LYS A   7 "
          pdb=" CB  LYS A   7 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.54   -0.03 2.00e-01 2.50e+01 1.66e-02
chirality pdb=" CA  TYR A  56 "
          pdb=" N   TYR A  56 "
          pdb=" C   TYR A  56 "
          pdb=" CB  TYR A  56 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.54   -0.03 2.00e-01 2.50e+01 1.64e-02
chirality pdb=" CA  ARG A  82 "
          pdb=" N   ARG A  82 "
          pdb=" C   ARG A  82 "
          pdb=" CB  ARG A  82 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.54   -0.03 2.00e-01 2.50e+01 1.64e-02
chirality pdb=" CA  LEU A  81 "
          pdb=" N   LEU A  81 "
          pdb=" C   LEU A  81 "
          pdb=" CB  LEU A  81 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.54   -0.03 2.00e-01 2.50e+01 1.58e-02
chirality pdb=" CA  LEU A  76 "
          pdb=" N   LEU A  76 "
          pdb=" C   LEU A  76 "
          pdb=" CB  LEU A  76 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.53   -0.02 2.00e-01 2.50e+01 1.49e-02
chirality pdb=" CA  GLN A  53 "
          pdb=" N   GLN A  53 "
          pdb=" C   GLN A  53 "
          pdb=" CB  GLN A  53 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.53   -0.02 2.00e-01 2.50e+01 1.44e-02
chirality pdb=" CA  LEU A  65 "
          pdb=" N   LEU A  65 "
          pdb=" C   LEU A  65 "
          pdb=" CB  LEU A  65 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.49    0.02 2.00e-01 2.50e+01 1.44e-02
chirality pdb=" CA  LEU A  60 "
          pdb=" N   LEU A  60 "
          pdb=" C   LEU A  60 "
          pdb=" CB  LEU A  60 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.53   -0.02 2.00e-01 2.50e+01 1.24e-02
chirality pdb=" CA  LEU A  83 "
          pdb=" N   LEU A  83 "
          pdb=" C   LEU A  83 "
          pdb=" CB  LEU A  83 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.49    0.02 2.00e-01 2.50e+01 1.18e-02
chirality pdb=" CB  VAL A  70 "
          pdb=" CA  VAL A  70 "
          pdb=" CG1 VAL A  70 "
          pdb=" CG2 VAL A  70 "
  both_signs  ideal   model   delta    sigma   weight residual
    False     -2.63   -2.61   -0.02 2.00e-01 2.50e+01 1.13e-02
chirality pdb=" CB  THR A  48 "
          pdb=" CA  THR A  48 "
          pdb=" OG1 THR A  48 "
          pdb=" CG2 THR A  48 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.55    2.53    0.02 2.00e-01 2.50e+01 9.85e-03
chirality pdb=" CA  LEU A  49 "
          pdb=" N   LEU A  49 "
          pdb=" C   LEU A  49 "
          pdb=" CB  LEU A  49 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.53   -0.02 2.00e-01 2.50e+01 9.21e-03
chirality pdb=" CA  TYR A  26 "
          pdb=" N   TYR A  26 "
          pdb=" C   TYR A  26 "
          pdb=" CB  TYR A  26 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.49    0.02 2.00e-01 2.50e+01 9.20e-03
chirality pdb=" CA  LYS A  69 "
          pdb=" N   LYS A  69 "
          pdb=" C   LYS A  69 "
          pdb=" CB  LYS A  69 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.53   -0.02 2.00e-01 2.50e+01 8.94e-03
chirality pdb=" CG  LEU A  37 "
          pdb=" CB  LEU A  37 "
          pdb=" CD1 LEU A  37 "
          pdb=" CD2 LEU A  37 "
  both_signs  ideal   model   delta    sigma   weight residual
    False     -2.59   -2.57   -0.02 2.00e-01 2.50e+01 8.23e-03
chirality pdb=" CA  SER A  67 "
          pdb=" N   SER A  67 "
          pdb=" C   SER A  67 "
          pdb=" CB  SER A  67 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.49    0.02 2.00e-01 2.50e+01 8.10e-03
chirality pdb=" CG  LEU A  49 "
          pdb=" CB  LEU A  49 "
          pdb=" CD1 LEU A  49 "
          pdb=" CD2 LEU A  49 "
  both_signs  ideal   model   delta    sigma   weight residual
    False     -2.59   -2.61    0.02 2.00e-01 2.50e+01 7.21e-03
chirality pdb=" CA  GLU A  30 "
          pdb=" N   GLU A  30 "
          pdb=" C   GLU A  30 "
          pdb=" CB  GLU A  30 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.53   -0.02 2.00e-01 2.50e+01 6.83e-03
chirality pdb=" CA  THR A  48 "
          pdb=" N   THR A  48 "
          pdb=" C   THR A  48 "
          pdb=" CB  THR A  48 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.53    2.54   -0.02 2.00e-01 2.50e+01 6.58e-03
chirality pdb=" CA  VAL A  45 "
          pdb=" N   VAL A  45 "
          pdb=" C   VAL A  45 "
          pdb=" CB  VAL A  45 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.44    2.46   -0.02 2.00e-01 2.50e+01 6.22e-03
chirality pdb=" CA  HIS A  64 "
          pdb=" N   HIS A  64 "
          pdb=" C   HIS A  64 "
          pdb=" CB  HIS A  64 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.53   -0.01 2.00e-01 2.50e+01 5.44e-03
chirality pdb=" CB  VAL A  63 "
          pdb=" CA  VAL A  63 "
          pdb=" CG1 VAL A  63 "
          pdb=" CG2 VAL A  63 "
  both_signs  ideal   model   delta    sigma   weight residual
    False     -2.63   -2.64    0.01 2.00e-01 2.50e+01 5.19e-03
chirality pdb=" CA  MSE A  77 "
          pdb=" N   MSE A  77 "
          pdb=" C   MSE A  77 "
          pdb=" CB  MSE A  77 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.50    2.52   -0.01 2.00e-01 2.50e+01 4.51e-03
chirality pdb=" CA  LYS A   3 "
          pdb=" N   LYS A   3 "
          pdb=" C   LYS A   3 "
          pdb=" CB  LYS A   3 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.52   -0.01 2.00e-01 2.50e+01 4.49e-03
chirality pdb=" CA  CYS A  33 "
          pdb=" N   CYS A  33 "
          pdb=" C   CYS A  33 "
          pdb=" CB  CYS A  33 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.52   -0.01 2.00e-01 2.50e+01 3.80e-03
chirality pdb=" CA  PHE A  68 "
          pdb=" N   PHE A  68 "
          pdb=" C   PHE A  68 "
          pdb=" CB  PHE A  68 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.50    0.01 2.00e-01 2.50e+01 3.43e-03
chirality pdb=" CB  ILE A   2 "
          pdb=" CA  ILE A   2 "
          pdb=" CG1 ILE A   2 "
          pdb=" CG2 ILE A   2 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.64    2.63    0.01 2.00e-01 2.50e+01 3.25e-03
chirality pdb=" CG  LEU A  83 "
          pdb=" CB  LEU A  83 "
          pdb=" CD1 LEU A  83 "
          pdb=" CD2 LEU A  83 "
  both_signs  ideal   model   delta    sigma   weight residual
    False     -2.59   -2.58   -0.01 2.00e-01 2.50e+01 2.92e-03
chirality pdb=" CA  GLU A  51 "
          pdb=" N   GLU A  51 "
          pdb=" C   GLU A  51 "
          pdb=" CB  GLU A  51 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.50    0.01 2.00e-01 2.50e+01 2.58e-03
chirality pdb=" CA  PHE A  13 "
          pdb=" N   PHE A  13 "
          pdb=" C   PHE A  13 "
          pdb=" CB  PHE A  13 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.52   -0.01 2.00e-01 2.50e+01 2.39e-03
chirality pdb=" CB  THR A  14 "
          pdb=" CA  THR A  14 "
          pdb=" OG1 THR A  14 "
          pdb=" CG2 THR A  14 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.55    2.54    0.01 2.00e-01 2.50e+01 1.90e-03
chirality pdb=" CA  PRO A  54 "
          pdb=" N   PRO A  54 "
          pdb=" C   PRO A  54 "
          pdb=" CB  PRO A  54 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.72    2.71    0.01 2.00e-01 2.50e+01 1.85e-03
chirality pdb=" CA  SER A  17 "
          pdb=" N   SER A  17 "
          pdb=" C   SER A  17 "
          pdb=" CB  SER A  17 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.52   -0.01 2.00e-01 2.50e+01 1.67e-03
chirality pdb=" CA  PRO A  25 "
          pdb=" N   PRO A  25 "
          pdb=" C   PRO A  25 "
          pdb=" CB  PRO A  25 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.72    2.71    0.01 2.00e-01 2.50e+01 1.29e-03
chirality pdb=" CA  ARG A  16 "
          pdb=" N   ARG A  16 "
          pdb=" C   ARG A  16 "
          pdb=" CB  ARG A  16 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.52   -0.01 2.00e-01 2.50e+01 8.22e-04
chirality pdb=" CA  ASN A  39 "
          pdb=" N   ASN A  39 "
          pdb=" C   ASN A  39 "
          pdb=" CB  ASN A  39 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.52   -0.01 2.00e-01 2.50e+01 7.51e-04
chirality pdb=" CA  GLU A   5 "
          pdb=" N   GLU A   5 "
          pdb=" C   GLU A   5 "
          pdb=" CB  GLU A   5 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.51    0.00 2.00e-01 2.50e+01 5.75e-04
chirality pdb=" CG  LEU A  81 "
          pdb=" CB  LEU A  81 "
          pdb=" CD1 LEU A  81 "
          pdb=" CD2 LEU A  81 "
  both_signs  ideal   model   delta    sigma   weight residual
    False     -2.59   -2.59    0.00 2.00e-01 2.50e+01 4.27e-04
chirality pdb=" CB  VAL A   4 "
          pdb=" CA  VAL A   4 "
          pdb=" CG1 VAL A   4 "
          pdb=" CG2 VAL A   4 "
  both_signs  ideal   model   delta    sigma   weight residual
    False     -2.63   -2.63   -0.00 2.00e-01 2.50e+01 3.14e-04
chirality pdb=" CB  VAL A  35 "
          pdb=" CA  VAL A  35 "
          pdb=" CG1 VAL A  35 "
          pdb=" CG2 VAL A  35 "
  both_signs  ideal   model   delta    sigma   weight residual
    False     -2.63   -2.63    0.00 2.00e-01 2.50e+01 2.94e-04
chirality pdb=" CA  THR A  15 "
          pdb=" N   THR A  15 "
          pdb=" C   THR A  15 "
          pdb=" CB  THR A  15 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.53    2.53   -0.00 2.00e-01 2.50e+01 2.81e-04
chirality pdb=" CA  GLN A  12 "
          pdb=" N   GLN A  12 "
          pdb=" C   GLN A  12 "
          pdb=" CB  GLN A  12 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.51   -0.00 2.00e-01 2.50e+01 2.08e-04
chirality pdb=" CA  THR A  14 "
          pdb=" N   THR A  14 "
          pdb=" C   THR A  14 "
          pdb=" CB  THR A  14 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.53    2.53   -0.00 2.00e-01 2.50e+01 2.04e-04
chirality pdb=" CA  THR A  62 "
          pdb=" N   THR A  62 "
          pdb=" C   THR A  62 "
          pdb=" CB  THR A  62 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.53    2.53   -0.00 2.00e-01 2.50e+01 1.16e-04
chirality pdb=" CB  ILE A  47 "
          pdb=" CA  ILE A  47 "
          pdb=" CG1 ILE A  47 "
          pdb=" CG2 ILE A  47 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.64    2.64    0.00 2.00e-01 2.50e+01 1.10e-04
chirality pdb=" CB  ILE A  78 "
          pdb=" CA  ILE A  78 "
          pdb=" CG1 ILE A  78 "
          pdb=" CG2 ILE A  78 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.64    2.65   -0.00 2.00e-01 2.50e+01 5.63e-05
chirality pdb=" CA  SER A  75 "
          pdb=" N   SER A  75 "
          pdb=" C   SER A  75 "
          pdb=" CB  SER A  75 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.51    0.00 2.00e-01 2.50e+01 4.85e-05
chirality pdb=" CG  LEU A  76 "
          pdb=" CB  LEU A  76 "
          pdb=" CD1 LEU A  76 "
          pdb=" CD2 LEU A  76 "
  both_signs  ideal   model   delta    sigma   weight residual
    False     -2.59   -2.59   -0.00 2.00e-01 2.50e+01 3.09e-05
chirality pdb=" CA  GLU A  40 "
          pdb=" N   GLU A  40 "
          pdb=" C   GLU A  40 "
          pdb=" CB  GLU A  40 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.51   -0.00 2.00e-01 2.50e+01 6.60e-06
chirality pdb=" CA  LEU A  32 "
          pdb=" N   LEU A  32 "
          pdb=" C   LEU A  32 "
          pdb=" CB  LEU A  32 "
  both_signs  ideal   model   delta    sigma   weight residual
    False      2.51    2.51    0.00 2.00e-01 2.50e+01 1.55e-06

Planarity | covalent geometry | restraints: 117
Sorted by residual:
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  GLN A  22 "   -0.010 2.00e-02 2.50e+03   2.11e-02 4.46e+00
      pdb=" C   GLN A  22 "    0.037 2.00e-02 2.50e+03
      pdb=" O   GLN A  22 "   -0.014 2.00e-02 2.50e+03
      pdb=" N   GLY A  23 "   -0.012 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" C   LYS A  24 "   -0.034 5.00e-02 4.00e+02   5.14e-02 4.23e+00
      pdb=" N   PRO A  25 "    0.089 5.00e-02 4.00e+02
      pdb=" CA  PRO A  25 "   -0.026 5.00e-02 4.00e+02
      pdb=" CD  PRO A  25 "   -0.029 5.00e-02 4.00e+02
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  VAL A  43 "   -0.006 2.00e-02 2.50e+03   1.22e-02 1.48e+00
      pdb=" C   VAL A  43 "    0.021 2.00e-02 2.50e+03
      pdb=" O   VAL A  43 "   -0.008 2.00e-02 2.50e+03
      pdb=" N   LEU A  44 "   -0.007 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" C   ALA A  57 "   -0.018 5.00e-02 4.00e+02   2.74e-02 1.20e+00
      pdb=" N   PRO A  58 "    0.047 5.00e-02 4.00e+02
      pdb=" CA  PRO A  58 "   -0.014 5.00e-02 4.00e+02
      pdb=" CD  PRO A  58 "   -0.015 5.00e-02 4.00e+02
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  ARG A  21 "    0.005 2.00e-02 2.50e+03   8.99e-03 8.08e-01
      pdb=" C   ARG A  21 "   -0.016 2.00e-02 2.50e+03
      pdb=" O   ARG A  21 "    0.006 2.00e-02 2.50e+03
      pdb=" N   GLN A  22 "    0.005 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  LYS A  46 "    0.004 2.00e-02 2.50e+03   8.96e-03 8.02e-01
      pdb=" C   LYS A  46 "   -0.015 2.00e-02 2.50e+03
      pdb=" O   LYS A  46 "    0.006 2.00e-02 2.50e+03
      pdb=" N   ILE A  47 "    0.005 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CB  TYR A  26 "    0.003 2.00e-02 2.50e+03   6.22e-03 7.75e-01
      pdb=" CG  TYR A  26 "   -0.012 2.00e-02 2.50e+03
      pdb=" CD1 TYR A  26 "    0.009 2.00e-02 2.50e+03
      pdb=" CD2 TYR A  26 "   -0.001 2.00e-02 2.50e+03
      pdb=" CE1 TYR A  26 "   -0.004 2.00e-02 2.50e+03
      pdb=" CE2 TYR A  26 "    0.006 2.00e-02 2.50e+03
      pdb=" CZ  TYR A  26 "    0.000 2.00e-02 2.50e+03
      pdb=" OH  TYR A  26 "   -0.002 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" C   LYS A   7 "    0.013 5.00e-02 4.00e+02   2.03e-02 6.57e-01
      pdb=" N   PRO A   8 "   -0.035 5.00e-02 4.00e+02
      pdb=" CA  PRO A   8 "    0.010 5.00e-02 4.00e+02
      pdb=" CD  PRO A   8 "    0.011 5.00e-02 4.00e+02
                               delta    sigma   weight rms_deltas residual
plane pdb=" C   TYR A  41 "    0.013 5.00e-02 4.00e+02   1.97e-02 6.24e-01
      pdb=" N   PRO A  42 "   -0.034 5.00e-02 4.00e+02
      pdb=" CA  PRO A  42 "    0.010 5.00e-02 4.00e+02
      pdb=" CD  PRO A  42 "    0.011 5.00e-02 4.00e+02
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  VAL A  45 "   -0.004 2.00e-02 2.50e+03   7.64e-03 5.83e-01
      pdb=" C   VAL A  45 "    0.013 2.00e-02 2.50e+03
      pdb=" O   VAL A  45 "   -0.005 2.00e-02 2.50e+03
      pdb=" N   LYS A  46 "   -0.004 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  SER A  20 "   -0.003 2.00e-02 2.50e+03   6.76e-03 4.57e-01
      pdb=" C   SER A  20 "    0.012 2.00e-02 2.50e+03
      pdb=" O   SER A  20 "   -0.004 2.00e-02 2.50e+03
      pdb=" N   ARG A  21 "   -0.004 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  ARG A  16 "   -0.003 2.00e-02 2.50e+03   5.58e-03 3.11e-01
      pdb=" C   ARG A  16 "    0.010 2.00e-02 2.50e+03
      pdb=" O   ARG A  16 "   -0.004 2.00e-02 2.50e+03
      pdb=" N   SER A  17 "   -0.003 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  ILE A   2 "    0.003 2.00e-02 2.50e+03   5.07e-03 2.57e-01
      pdb=" C   ILE A   2 "   -0.009 2.00e-02 2.50e+03
      pdb=" O   ILE A   2 "    0.003 2.00e-02 2.50e+03
      pdb=" N   LYS A   3 "    0.003 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  VAL A  84 "   -0.003 2.00e-02 2.50e+03   5.01e-03 2.51e-01
      pdb=" C   VAL A  84 "    0.009 2.00e-02 2.50e+03
      pdb=" O   VAL A  84 "   -0.003 2.00e-02 2.50e+03
      pdb=" N   PRO A  85 "   -0.003 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  PRO A  25 "   -0.002 2.00e-02 2.50e+03   4.75e-03 2.25e-01
      pdb=" C   PRO A  25 "    0.008 2.00e-02 2.50e+03
      pdb=" O   PRO A  25 "   -0.003 2.00e-02 2.50e+03
      pdb=" N   TYR A  26 "   -0.003 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  SER A  27 "   -0.002 2.00e-02 2.50e+03   4.61e-03 2.12e-01
      pdb=" C   SER A  27 "    0.008 2.00e-02 2.50e+03
      pdb=" O   SER A  27 "   -0.003 2.00e-02 2.50e+03
      pdb=" N   LEU A  28 "   -0.003 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  ALA A  55 "    0.002 2.00e-02 2.50e+03   4.33e-03 1.88e-01
      pdb=" C   ALA A  55 "   -0.007 2.00e-02 2.50e+03
      pdb=" O   ALA A  55 "    0.003 2.00e-02 2.50e+03
      pdb=" N   TYR A  56 "    0.003 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  VAL A  19 "    0.002 2.00e-02 2.50e+03   4.32e-03 1.87e-01
      pdb=" C   VAL A  19 "   -0.007 2.00e-02 2.50e+03
      pdb=" O   VAL A  19 "    0.003 2.00e-02 2.50e+03
      pdb=" N   SER A  20 "    0.003 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CD  ARG A  82 "   -0.039 9.50e-02 1.11e+02   1.73e-02 1.85e-01
      pdb=" NE  ARG A  82 "    0.002 2.00e-02 2.50e+03
      pdb=" CZ  ARG A  82 "    0.001 2.00e-02 2.50e+03
      pdb=" NH1 ARG A  82 "    0.000 2.00e-02 2.50e+03
      pdb=" NH2 ARG A  82 "   -0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CB  PHE A  13 "    0.004 2.00e-02 2.50e+03   3.13e-03 1.72e-01
      pdb=" CG  PHE A  13 "   -0.007 2.00e-02 2.50e+03
      pdb=" CD1 PHE A  13 "    0.001 2.00e-02 2.50e+03
      pdb=" CD2 PHE A  13 "   -0.000 2.00e-02 2.50e+03
      pdb=" CE1 PHE A  13 "   -0.001 2.00e-02 2.50e+03
      pdb=" CE2 PHE A  13 "    0.001 2.00e-02 2.50e+03
      pdb=" CZ  PHE A  13 "    0.002 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  ALA A  57 "   -0.002 2.00e-02 2.50e+03   4.03e-03 1.63e-01
      pdb=" C   ALA A  57 "    0.007 2.00e-02 2.50e+03
      pdb=" O   ALA A  57 "   -0.003 2.00e-02 2.50e+03
      pdb=" N   PRO A  58 "   -0.002 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  LYS A   7 "    0.002 2.00e-02 2.50e+03   3.93e-03 1.54e-01
      pdb=" C   LYS A   7 "   -0.007 2.00e-02 2.50e+03
      pdb=" O   LYS A   7 "    0.003 2.00e-02 2.50e+03
      pdb=" N   PRO A   8 "    0.002 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  ASN A  29 "   -0.002 2.00e-02 2.50e+03   3.74e-03 1.40e-01
      pdb=" C   ASN A  29 "    0.006 2.00e-02 2.50e+03
      pdb=" O   ASN A  29 "   -0.002 2.00e-02 2.50e+03
      pdb=" N   GLU A  30 "   -0.002 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  TYR A  56 "   -0.002 2.00e-02 2.50e+03   3.62e-03 1.31e-01
      pdb=" C   TYR A  56 "    0.006 2.00e-02 2.50e+03
      pdb=" O   TYR A  56 "   -0.002 2.00e-02 2.50e+03
      pdb=" N   ALA A  57 "   -0.002 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  GLU A  51 "    0.002 2.00e-02 2.50e+03   3.33e-03 1.11e-01
      pdb=" C   GLU A  51 "   -0.006 2.00e-02 2.50e+03
      pdb=" O   GLU A  51 "    0.002 2.00e-02 2.50e+03
      pdb=" N   GLY A  52 "    0.002 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  VAL A   4 "    0.002 2.00e-02 2.50e+03   3.26e-03 1.06e-01
      pdb=" C   VAL A   4 "   -0.006 2.00e-02 2.50e+03
      pdb=" O   VAL A   4 "    0.002 2.00e-02 2.50e+03
      pdb=" N   GLU A   5 "    0.002 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  LYS A   3 "   -0.002 2.00e-02 2.50e+03   3.13e-03 9.77e-02
      pdb=" C   LYS A   3 "    0.005 2.00e-02 2.50e+03
      pdb=" O   LYS A   3 "   -0.002 2.00e-02 2.50e+03
      pdb=" N   VAL A   4 "   -0.002 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  GLY A  23 "   -0.002 2.00e-02 2.50e+03   3.09e-03 9.56e-02
      pdb=" C   GLY A  23 "    0.005 2.00e-02 2.50e+03
      pdb=" O   GLY A  23 "   -0.002 2.00e-02 2.50e+03
      pdb=" N   LYS A  24 "   -0.002 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  LEU A  81 "   -0.002 2.00e-02 2.50e+03   3.06e-03 9.38e-02
      pdb=" C   LEU A  81 "    0.005 2.00e-02 2.50e+03
      pdb=" O   LEU A  81 "   -0.002 2.00e-02 2.50e+03
      pdb=" N   ARG A  82 "   -0.002 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  LEU A  28 "    0.001 2.00e-02 2.50e+03   2.91e-03 8.44e-02
      pdb=" C   LEU A  28 "   -0.005 2.00e-02 2.50e+03
      pdb=" O   LEU A  28 "    0.002 2.00e-02 2.50e+03
      pdb=" N   ASN A  29 "    0.002 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CG  GLU A  51 "   -0.001 2.00e-02 2.50e+03   2.85e-03 8.10e-02
      pdb=" CD  GLU A  51 "    0.005 2.00e-02 2.50e+03
      pdb=" OE1 GLU A  51 "   -0.002 2.00e-02 2.50e+03
      pdb=" OE2 GLU A  51 "   -0.002 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CB  TYR A  61 "   -0.002 2.00e-02 2.50e+03   1.96e-03 7.67e-02
      pdb=" CG  TYR A  61 "    0.005 2.00e-02 2.50e+03
      pdb=" CD1 TYR A  61 "   -0.001 2.00e-02 2.50e+03
      pdb=" CD2 TYR A  61 "   -0.001 2.00e-02 2.50e+03
      pdb=" CE1 TYR A  61 "    0.001 2.00e-02 2.50e+03
      pdb=" CE2 TYR A  61 "    0.000 2.00e-02 2.50e+03
      pdb=" CZ  TYR A  61 "   -0.000 2.00e-02 2.50e+03
      pdb=" OH  TYR A  61 "   -0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CB  TYR A  56 "    0.003 2.00e-02 2.50e+03   1.94e-03 7.51e-02
      pdb=" CG  TYR A  56 "   -0.005 2.00e-02 2.50e+03
      pdb=" CD1 TYR A  56 "    0.000 2.00e-02 2.50e+03
      pdb=" CD2 TYR A  56 "   -0.000 2.00e-02 2.50e+03
      pdb=" CE1 TYR A  56 "    0.001 2.00e-02 2.50e+03
      pdb=" CE2 TYR A  56 "    0.001 2.00e-02 2.50e+03
      pdb=" CZ  TYR A  56 "   -0.001 2.00e-02 2.50e+03
      pdb=" OH  TYR A  56 "    0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CB  TYR A  41 "    0.001 2.00e-02 2.50e+03   1.93e-03 7.48e-02
      pdb=" CG  TYR A  41 "    0.002 2.00e-02 2.50e+03
      pdb=" CD1 TYR A  41 "   -0.001 2.00e-02 2.50e+03
      pdb=" CD2 TYR A  41 "   -0.000 2.00e-02 2.50e+03
      pdb=" CE1 TYR A  41 "   -0.001 2.00e-02 2.50e+03
      pdb=" CE2 TYR A  41 "   -0.002 2.00e-02 2.50e+03
      pdb=" CZ  TYR A  41 "   -0.002 2.00e-02 2.50e+03
      pdb=" OH  TYR A  41 "    0.004 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" C   VAL A  84 "   -0.004 5.00e-02 4.00e+02   6.07e-03 5.89e-02
      pdb=" N   PRO A  85 "    0.010 5.00e-02 4.00e+02
      pdb=" CA  PRO A  85 "   -0.003 5.00e-02 4.00e+02
      pdb=" CD  PRO A  85 "   -0.003 5.00e-02 4.00e+02
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  LEU A  49 "    0.001 2.00e-02 2.50e+03   2.35e-03 5.53e-02
      pdb=" C   LEU A  49 "   -0.004 2.00e-02 2.50e+03
      pdb=" O   LEU A  49 "    0.002 2.00e-02 2.50e+03
      pdb=" N   ASP A  50 "    0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CD  ARG A  16 "   -0.012 9.50e-02 1.11e+02   5.44e-03 5.23e-02
      pdb=" NE  ARG A  16 "    0.002 2.00e-02 2.50e+03
      pdb=" CZ  ARG A  16 "   -0.003 2.00e-02 2.50e+03
      pdb=" NH1 ARG A  16 "    0.001 2.00e-02 2.50e+03
      pdb=" NH2 ARG A  16 "    0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  THR A  62 "   -0.001 2.00e-02 2.50e+03   2.24e-03 5.01e-02
      pdb=" C   THR A  62 "    0.004 2.00e-02 2.50e+03
      pdb=" O   THR A  62 "   -0.001 2.00e-02 2.50e+03
      pdb=" N   VAL A  63 "   -0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  HIS A  64 "   -0.001 2.00e-02 2.50e+03   2.17e-03 4.72e-02
      pdb=" C   HIS A  64 "    0.004 2.00e-02 2.50e+03
      pdb=" O   HIS A  64 "   -0.001 2.00e-02 2.50e+03
      pdb=" N   LEU A  65 "   -0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  GLU A  30 "    0.001 2.00e-02 2.50e+03   2.15e-03 4.62e-02
      pdb=" C   GLU A  30 "   -0.004 2.00e-02 2.50e+03
      pdb=" O   GLU A  30 "    0.001 2.00e-02 2.50e+03
      pdb=" N   GLN A  31 "    0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CG  GLU A   5 "   -0.001 2.00e-02 2.50e+03   2.15e-03 4.61e-02
      pdb=" CD  GLU A   5 "    0.004 2.00e-02 2.50e+03
      pdb=" OE1 GLU A   5 "   -0.001 2.00e-02 2.50e+03
      pdb=" OE2 GLU A   5 "   -0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  ILE A  47 "   -0.001 2.00e-02 2.50e+03   2.09e-03 4.37e-02
      pdb=" C   ILE A  47 "    0.004 2.00e-02 2.50e+03
      pdb=" O   ILE A  47 "   -0.001 2.00e-02 2.50e+03
      pdb=" N   THR A  48 "   -0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  PRO A  54 "   -0.001 2.00e-02 2.50e+03   1.99e-03 3.96e-02
      pdb=" C   PRO A  54 "    0.003 2.00e-02 2.50e+03
      pdb=" O   PRO A  54 "   -0.001 2.00e-02 2.50e+03
      pdb=" N   ALA A  55 "   -0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  PRO A   8 "    0.001 2.00e-02 2.50e+03   1.95e-03 3.79e-02
      pdb=" C   PRO A   8 "   -0.003 2.00e-02 2.50e+03
      pdb=" O   PRO A   8 "    0.001 2.00e-02 2.50e+03
      pdb=" N   SER A   9 "    0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  LEU A  60 "    0.001 2.00e-02 2.50e+03   1.94e-03 3.76e-02
      pdb=" C   LEU A  60 "   -0.003 2.00e-02 2.50e+03
      pdb=" O   LEU A  60 "    0.001 2.00e-02 2.50e+03
      pdb=" N   TYR A  61 "    0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  ARG A  82 "    0.001 2.00e-02 2.50e+03   1.83e-03 3.33e-02
      pdb=" C   ARG A  82 "   -0.003 2.00e-02 2.50e+03
      pdb=" O   ARG A  82 "    0.001 2.00e-02 2.50e+03
      pdb=" N   LEU A  83 "    0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  ASP A  50 "    0.001 2.00e-02 2.50e+03   1.79e-03 3.20e-02
      pdb=" C   ASP A  50 "   -0.003 2.00e-02 2.50e+03
      pdb=" O   ASP A  50 "    0.001 2.00e-02 2.50e+03
      pdb=" N   GLU A  51 "    0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  GLY A  71 "    0.001 2.00e-02 2.50e+03   1.77e-03 3.12e-02
      pdb=" C   GLY A  71 "   -0.003 2.00e-02 2.50e+03
      pdb=" O   GLY A  71 "    0.001 2.00e-02 2.50e+03
      pdb=" N   GLN A  72 "    0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  ILE A  78 "    0.001 2.00e-02 2.50e+03   1.76e-03 3.09e-02
      pdb=" C   ILE A  78 "   -0.003 2.00e-02 2.50e+03
      pdb=" O   ILE A  78 "    0.001 2.00e-02 2.50e+03
      pdb=" N   ASP A  79 "    0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" C   GLN A  53 "    0.003 5.00e-02 4.00e+02   4.21e-03 2.83e-02
      pdb=" N   PRO A  54 "   -0.007 5.00e-02 4.00e+02
      pdb=" CA  PRO A  54 "    0.002 5.00e-02 4.00e+02
      pdb=" CD  PRO A  54 "    0.002 5.00e-02 4.00e+02
                               delta    sigma   weight rms_deltas residual
plane pdb=" CB  PHE A  73 "    0.002 2.00e-02 2.50e+03   1.21e-03 2.55e-02
      pdb=" CG  PHE A  73 "   -0.003 2.00e-02 2.50e+03
      pdb=" CD1 PHE A  73 "   -0.000 2.00e-02 2.50e+03
      pdb=" CD2 PHE A  73 "    0.000 2.00e-02 2.50e+03
      pdb=" CE1 PHE A  73 "    0.000 2.00e-02 2.50e+03
      pdb=" CE2 PHE A  73 "    0.000 2.00e-02 2.50e+03
      pdb=" CZ  PHE A  73 "    0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  GLY A  18 "    0.001 2.00e-02 2.50e+03   1.59e-03 2.54e-02
      pdb=" C   GLY A  18 "   -0.003 2.00e-02 2.50e+03
      pdb=" O   GLY A  18 "    0.001 2.00e-02 2.50e+03
      pdb=" N   VAL A  19 "    0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CG  GLN A  53 "   -0.001 2.00e-02 2.50e+03   1.59e-03 2.52e-02
      pdb=" CD  GLN A  53 "    0.003 2.00e-02 2.50e+03
      pdb=" OE1 GLN A  53 "   -0.001 2.00e-02 2.50e+03
      pdb=" NE2 GLN A  53 "   -0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  GLN A  31 "   -0.001 2.00e-02 2.50e+03   1.55e-03 2.40e-02
      pdb=" C   GLN A  31 "    0.003 2.00e-02 2.50e+03
      pdb=" O   GLN A  31 "   -0.001 2.00e-02 2.50e+03
      pdb=" N   LEU A  32 "   -0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  THR A  48 "    0.001 2.00e-02 2.50e+03   1.54e-03 2.39e-02
      pdb=" C   THR A  48 "   -0.003 2.00e-02 2.50e+03
      pdb=" O   THR A  48 "    0.001 2.00e-02 2.50e+03
      pdb=" N   LEU A  49 "    0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CB  HIS A  64 "   -0.001 2.00e-02 2.50e+03   1.08e-03 1.76e-02
      pdb=" CG  HIS A  64 "    0.001 2.00e-02 2.50e+03
      pdb=" ND1 HIS A  64 "    0.001 2.00e-02 2.50e+03
      pdb=" CD2 HIS A  64 "    0.001 2.00e-02 2.50e+03
      pdb=" CE1 HIS A  64 "   -0.000 2.00e-02 2.50e+03
      pdb=" NE2 HIS A  64 "   -0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  LEU A  65 "   -0.001 2.00e-02 2.50e+03   1.31e-03 1.71e-02
      pdb=" C   LEU A  65 "    0.002 2.00e-02 2.50e+03
      pdb=" O   LEU A  65 "   -0.001 2.00e-02 2.50e+03
      pdb=" N   SER A  66 "   -0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  TYR A  61 "   -0.001 2.00e-02 2.50e+03   1.28e-03 1.64e-02
      pdb=" C   TYR A  61 "    0.002 2.00e-02 2.50e+03
      pdb=" O   TYR A  61 "   -0.001 2.00e-02 2.50e+03
      pdb=" N   THR A  62 "   -0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CB  ASP A  79 "   -0.001 2.00e-02 2.50e+03   1.26e-03 1.58e-02
      pdb=" CG  ASP A  79 "    0.002 2.00e-02 2.50e+03
      pdb=" OD1 ASP A  79 "   -0.001 2.00e-02 2.50e+03
      pdb=" OD2 ASP A  79 "   -0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  GLU A   5 "    0.001 2.00e-02 2.50e+03   1.25e-03 1.56e-02
      pdb=" C   GLU A   5 "   -0.002 2.00e-02 2.50e+03
      pdb=" O   GLU A   5 "    0.001 2.00e-02 2.50e+03
      pdb=" N   ILE A   6 "    0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CB  PHE A  68 "   -0.001 2.00e-02 2.50e+03   9.32e-04 1.52e-02
      pdb=" CG  PHE A  68 "    0.002 2.00e-02 2.50e+03
      pdb=" CD1 PHE A  68 "   -0.000 2.00e-02 2.50e+03
      pdb=" CD2 PHE A  68 "   -0.001 2.00e-02 2.50e+03
      pdb=" CE1 PHE A  68 "   -0.001 2.00e-02 2.50e+03
      pdb=" CE2 PHE A  68 "   -0.000 2.00e-02 2.50e+03
      pdb=" CZ  PHE A  68 "    0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  ILE A   6 "    0.001 2.00e-02 2.50e+03   1.16e-03 1.35e-02
      pdb=" C   ILE A   6 "   -0.002 2.00e-02 2.50e+03
      pdb=" O   ILE A   6 "    0.001 2.00e-02 2.50e+03
      pdb=" N   LYS A   7 "    0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  PHE A  13 "   -0.001 2.00e-02 2.50e+03   1.16e-03 1.34e-02
      pdb=" C   PHE A  13 "    0.002 2.00e-02 2.50e+03
      pdb=" O   PHE A  13 "   -0.001 2.00e-02 2.50e+03
      pdb=" N   THR A  14 "   -0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CG  GLU A  30 "    0.001 2.00e-02 2.50e+03   1.16e-03 1.33e-02
      pdb=" CD  GLU A  30 "   -0.002 2.00e-02 2.50e+03
      pdb=" OE1 GLU A  30 "    0.001 2.00e-02 2.50e+03
      pdb=" OE2 GLU A  30 "    0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  GLY A  38 "   -0.001 2.00e-02 2.50e+03   1.15e-03 1.33e-02
      pdb=" C   GLY A  38 "    0.002 2.00e-02 2.50e+03
      pdb=" O   GLY A  38 "   -0.001 2.00e-02 2.50e+03
      pdb=" N   ASN A  39 "   -0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  TYR A  26 "    0.001 2.00e-02 2.50e+03   1.15e-03 1.32e-02
      pdb=" C   TYR A  26 "   -0.002 2.00e-02 2.50e+03
      pdb=" O   TYR A  26 "    0.001 2.00e-02 2.50e+03
      pdb=" N   SER A  27 "    0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  ASN A  39 "    0.001 2.00e-02 2.50e+03   1.09e-03 1.20e-02
      pdb=" C   ASN A  39 "   -0.002 2.00e-02 2.50e+03
      pdb=" O   ASN A  39 "    0.001 2.00e-02 2.50e+03
      pdb=" N   GLU A  40 "    0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  LYS A  69 "    0.001 2.00e-02 2.50e+03   1.09e-03 1.19e-02
      pdb=" C   LYS A  69 "   -0.002 2.00e-02 2.50e+03
      pdb=" O   LYS A  69 "    0.001 2.00e-02 2.50e+03
      pdb=" N   VAL A  70 "    0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  SER A  17 "    0.001 2.00e-02 2.50e+03   1.07e-03 1.15e-02
      pdb=" C   SER A  17 "   -0.002 2.00e-02 2.50e+03
      pdb=" O   SER A  17 "    0.001 2.00e-02 2.50e+03
      pdb=" N   GLY A  18 "    0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CG  GLU A  40 "   -0.001 2.00e-02 2.50e+03   1.07e-03 1.14e-02
      pdb=" CD  GLU A  40 "    0.002 2.00e-02 2.50e+03
      pdb=" OE1 GLU A  40 "   -0.001 2.00e-02 2.50e+03
      pdb=" OE2 GLU A  40 "   -0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  ALA A  11 "   -0.001 2.00e-02 2.50e+03   1.06e-03 1.13e-02
      pdb=" C   ALA A  11 "    0.002 2.00e-02 2.50e+03
      pdb=" O   ALA A  11 "   -0.001 2.00e-02 2.50e+03
      pdb=" N   GLN A  12 "   -0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CB  TYR A  34 "    0.000 2.00e-02 2.50e+03   7.28e-04 1.06e-02
      pdb=" CG  TYR A  34 "   -0.000 2.00e-02 2.50e+03
      pdb=" CD1 TYR A  34 "   -0.000 2.00e-02 2.50e+03
      pdb=" CD2 TYR A  34 "   -0.000 2.00e-02 2.50e+03
      pdb=" CE1 TYR A  34 "    0.001 2.00e-02 2.50e+03
      pdb=" CE2 TYR A  34 "    0.000 2.00e-02 2.50e+03
      pdb=" CZ  TYR A  34 "    0.001 2.00e-02 2.50e+03
      pdb=" OH  TYR A  34 "   -0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CB  ASN A  29 "    0.000 2.00e-02 2.50e+03   9.45e-04 8.93e-03
      pdb=" CG  ASN A  29 "   -0.002 2.00e-02 2.50e+03
      pdb=" OD1 ASN A  29 "    0.001 2.00e-02 2.50e+03
      pdb=" ND2 ASN A  29 "    0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  GLN A  10 "   -0.000 2.00e-02 2.50e+03   9.42e-04 8.88e-03
      pdb=" C   GLN A  10 "    0.002 2.00e-02 2.50e+03
      pdb=" O   GLN A  10 "   -0.001 2.00e-02 2.50e+03
      pdb=" N   ALA A  11 "   -0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  LEU A  32 "   -0.000 2.00e-02 2.50e+03   9.13e-04 8.34e-03
      pdb=" C   LEU A  32 "    0.002 2.00e-02 2.50e+03
      pdb=" O   LEU A  32 "   -0.001 2.00e-02 2.50e+03
      pdb=" N   CYS A  33 "   -0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  GLU A  40 "   -0.000 2.00e-02 2.50e+03   8.75e-04 7.65e-03
      pdb=" C   GLU A  40 "    0.002 2.00e-02 2.50e+03
      pdb=" O   GLU A  40 "   -0.001 2.00e-02 2.50e+03
      pdb=" N   TYR A  41 "   -0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  VAL A  70 "   -0.000 2.00e-02 2.50e+03   8.57e-04 7.34e-03
      pdb=" C   VAL A  70 "    0.001 2.00e-02 2.50e+03
      pdb=" O   VAL A  70 "   -0.001 2.00e-02 2.50e+03
      pdb=" N   GLY A  71 "   -0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CB  ASP A  50 "   -0.000 2.00e-02 2.50e+03   8.46e-04 7.16e-03
      pdb=" CG  ASP A  50 "    0.001 2.00e-02 2.50e+03
      pdb=" OD1 ASP A  50 "   -0.001 2.00e-02 2.50e+03
      pdb=" OD2 ASP A  50 "   -0.001 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CG  GLN A  12 "    0.000 2.00e-02 2.50e+03   7.67e-04 5.89e-03
      pdb=" CD  GLN A  12 "   -0.001 2.00e-02 2.50e+03
      pdb=" OE1 GLN A  12 "    0.000 2.00e-02 2.50e+03
      pdb=" NE2 GLN A  12 "    0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  SER A   9 "    0.000 2.00e-02 2.50e+03   6.88e-04 4.74e-03
      pdb=" C   SER A   9 "   -0.001 2.00e-02 2.50e+03
      pdb=" O   SER A   9 "    0.000 2.00e-02 2.50e+03
      pdb=" N   GLN A  10 "    0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  ASP A  36 "   -0.000 2.00e-02 2.50e+03   6.87e-04 4.72e-03
      pdb=" C   ASP A  36 "    0.001 2.00e-02 2.50e+03
      pdb=" O   ASP A  36 "   -0.000 2.00e-02 2.50e+03
      pdb=" N   LEU A  37 "   -0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CB  ASP A  36 "   -0.000 2.00e-02 2.50e+03   6.83e-04 4.67e-03
      pdb=" CG  ASP A  36 "    0.001 2.00e-02 2.50e+03
      pdb=" OD1 ASP A  36 "   -0.000 2.00e-02 2.50e+03
      pdb=" OD2 ASP A  36 "   -0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  GLY A  52 "    0.000 2.00e-02 2.50e+03   6.61e-04 4.37e-03
      pdb=" C   GLY A  52 "   -0.001 2.00e-02 2.50e+03
      pdb=" O   GLY A  52 "    0.000 2.00e-02 2.50e+03
      pdb=" N   GLN A  53 "    0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CG  GLN A  31 "   -0.000 2.00e-02 2.50e+03   6.35e-04 4.03e-03
      pdb=" CD  GLN A  31 "    0.001 2.00e-02 2.50e+03
      pdb=" OE1 GLN A  31 "   -0.000 2.00e-02 2.50e+03
      pdb=" NE2 GLN A  31 "   -0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  PRO A  42 "    0.000 2.00e-02 2.50e+03   5.91e-04 3.49e-03
      pdb=" C   PRO A  42 "   -0.001 2.00e-02 2.50e+03
      pdb=" O   PRO A  42 "    0.000 2.00e-02 2.50e+03
      pdb=" N   VAL A  43 "    0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  GLN A  72 "   -0.000 2.00e-02 2.50e+03   5.79e-04 3.36e-03
      pdb=" C   GLN A  72 "    0.001 2.00e-02 2.50e+03
      pdb=" O   GLN A  72 "   -0.000 2.00e-02 2.50e+03
      pdb=" N   PHE A  73 "   -0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  LEU A  83 "   -0.000 2.00e-02 2.50e+03   5.70e-04 3.24e-03
      pdb=" C   LEU A  83 "    0.001 2.00e-02 2.50e+03
      pdb=" O   LEU A  83 "   -0.000 2.00e-02 2.50e+03
      pdb=" N   VAL A  84 "   -0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  PHE A  68 "   -0.000 2.00e-02 2.50e+03   5.64e-04 3.19e-03
      pdb=" C   PHE A  68 "    0.001 2.00e-02 2.50e+03
      pdb=" O   PHE A  68 "   -0.000 2.00e-02 2.50e+03
      pdb=" N   LYS A  69 "   -0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  SER A  66 "   -0.000 2.00e-02 2.50e+03   5.58e-04 3.12e-03
      pdb=" C   SER A  66 "    0.001 2.00e-02 2.50e+03
      pdb=" O   SER A  66 "   -0.000 2.00e-02 2.50e+03
      pdb=" N   SER A  67 "   -0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CD  ARG A  80 "    0.005 9.50e-02 1.11e+02   2.10e-03 2.95e-03
      pdb=" NE  ARG A  80 "   -0.000 2.00e-02 2.50e+03
      pdb=" CZ  ARG A  80 "    0.000 2.00e-02 2.50e+03
      pdb=" NH1 ARG A  80 "   -0.000 2.00e-02 2.50e+03
      pdb=" NH2 ARG A  80 "    0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  PRO A  58 "    0.000 2.00e-02 2.50e+03   5.42e-04 2.93e-03
      pdb=" C   PRO A  58 "   -0.001 2.00e-02 2.50e+03
      pdb=" O   PRO A  58 "    0.000 2.00e-02 2.50e+03
      pdb=" N   GLY A  59 "    0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CB  ASN A  39 "    0.000 2.00e-02 2.50e+03   5.36e-04 2.87e-03
      pdb=" CG  ASN A  39 "   -0.001 2.00e-02 2.50e+03
      pdb=" OD1 ASN A  39 "    0.000 2.00e-02 2.50e+03
      pdb=" ND2 ASN A  39 "    0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  PHE A  73 "    0.000 2.00e-02 2.50e+03   5.28e-04 2.79e-03
      pdb=" C   PHE A  73 "   -0.001 2.00e-02 2.50e+03
      pdb=" O   PHE A  73 "    0.000 2.00e-02 2.50e+03
      pdb=" N   GLY A  74 "    0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  THR A  14 "   -0.000 2.00e-02 2.50e+03   5.19e-04 2.69e-03
      pdb=" C   THR A  14 "    0.001 2.00e-02 2.50e+03
      pdb=" O   THR A  14 "   -0.000 2.00e-02 2.50e+03
      pdb=" N   THR A  15 "   -0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  THR A  15 "    0.000 2.00e-02 2.50e+03   5.10e-04 2.60e-03
      pdb=" C   THR A  15 "   -0.001 2.00e-02 2.50e+03
      pdb=" O   THR A  15 "    0.000 2.00e-02 2.50e+03
      pdb=" N   ARG A  16 "    0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  SER A  75 "   -0.000 2.00e-02 2.50e+03   5.05e-04 2.55e-03
      pdb=" C   SER A  75 "    0.001 2.00e-02 2.50e+03
      pdb=" O   SER A  75 "   -0.000 2.00e-02 2.50e+03
      pdb=" N   LEU A  76 "   -0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CD  ARG A  21 "   -0.004 9.50e-02 1.11e+02   1.93e-03 2.45e-03
      pdb=" NE  ARG A  21 "    0.000 2.00e-02 2.50e+03
      pdb=" CZ  ARG A  21 "    0.000 2.00e-02 2.50e+03
      pdb=" NH1 ARG A  21 "   -0.000 2.00e-02 2.50e+03
      pdb=" NH2 ARG A  21 "   -0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  LYS A  24 "    0.000 2.00e-02 2.50e+03   4.70e-04 2.21e-03
      pdb=" C   LYS A  24 "   -0.001 2.00e-02 2.50e+03
      pdb=" O   LYS A  24 "    0.000 2.00e-02 2.50e+03
      pdb=" N   PRO A  25 "    0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  VAL A  63 "    0.000 2.00e-02 2.50e+03   4.16e-04 1.73e-03
      pdb=" C   VAL A  63 "   -0.001 2.00e-02 2.50e+03
      pdb=" O   VAL A  63 "    0.000 2.00e-02 2.50e+03
      pdb=" N   HIS A  64 "    0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  ARG A  80 "    0.000 2.00e-02 2.50e+03   4.03e-04 1.62e-03
      pdb=" C   ARG A  80 "   -0.001 2.00e-02 2.50e+03
      pdb=" O   ARG A  80 "    0.000 2.00e-02 2.50e+03
      pdb=" N   LEU A  81 "    0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  LEU A  37 "   -0.000 2.00e-02 2.50e+03   3.15e-04 9.91e-04
      pdb=" C   LEU A  37 "    0.001 2.00e-02 2.50e+03
      pdb=" O   LEU A  37 "   -0.000 2.00e-02 2.50e+03
      pdb=" N   GLY A  38 "   -0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  LEU A  44 "    0.000 2.00e-02 2.50e+03   2.94e-04 8.62e-04
      pdb=" C   LEU A  44 "   -0.001 2.00e-02 2.50e+03
      pdb=" O   LEU A  44 "    0.000 2.00e-02 2.50e+03
      pdb=" N   VAL A  45 "    0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  GLN A  53 "   -0.000 2.00e-02 2.50e+03   2.79e-04 7.81e-04
      pdb=" C   GLN A  53 "    0.000 2.00e-02 2.50e+03
      pdb=" O   GLN A  53 "   -0.000 2.00e-02 2.50e+03
      pdb=" N   PRO A  54 "   -0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  TYR A  34 "   -0.000 2.00e-02 2.50e+03   2.69e-04 7.25e-04
      pdb=" C   TYR A  34 "    0.000 2.00e-02 2.50e+03
      pdb=" O   TYR A  34 "   -0.000 2.00e-02 2.50e+03
      pdb=" N   VAL A  35 "   -0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CG  GLN A  22 "   -0.000 2.00e-02 2.50e+03   2.56e-04 6.57e-04
      pdb=" CD  GLN A  22 "    0.000 2.00e-02 2.50e+03
      pdb=" OE1 GLN A  22 "   -0.000 2.00e-02 2.50e+03
      pdb=" NE2 GLN A  22 "   -0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  CYS A  33 "    0.000 2.00e-02 2.50e+03   2.48e-04 6.15e-04
      pdb=" C   CYS A  33 "   -0.000 2.00e-02 2.50e+03
      pdb=" O   CYS A  33 "    0.000 2.00e-02 2.50e+03
      pdb=" N   TYR A  34 "    0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  SER A  67 "    0.000 2.00e-02 2.50e+03   2.48e-04 6.14e-04
      pdb=" C   SER A  67 "   -0.000 2.00e-02 2.50e+03
      pdb=" O   SER A  67 "    0.000 2.00e-02 2.50e+03
      pdb=" N   PHE A  68 "    0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  VAL A  35 "   -0.000 2.00e-02 2.50e+03   2.47e-04 6.09e-04
      pdb=" C   VAL A  35 "    0.000 2.00e-02 2.50e+03
      pdb=" O   VAL A  35 "   -0.000 2.00e-02 2.50e+03
      pdb=" N   ASP A  36 "   -0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  MSE A  77 "    0.000 2.00e-02 2.50e+03   2.00e-04 4.00e-04
      pdb=" C   MSE A  77 "   -0.000 2.00e-02 2.50e+03
      pdb=" O   MSE A  77 "    0.000 2.00e-02 2.50e+03
      pdb=" N   ILE A  78 "    0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  GLY A  74 "   -0.000 2.00e-02 2.50e+03   1.89e-04 3.56e-04
      pdb=" C   GLY A  74 "    0.000 2.00e-02 2.50e+03
      pdb=" O   GLY A  74 "   -0.000 2.00e-02 2.50e+03
      pdb=" N   SER A  75 "   -0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CG  GLN A  72 "    0.000 2.00e-02 2.50e+03   1.68e-04 2.81e-04
      pdb=" CD  GLN A  72 "   -0.000 2.00e-02 2.50e+03
      pdb=" OE1 GLN A  72 "    0.000 2.00e-02 2.50e+03
      pdb=" NE2 GLN A  72 "    0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  GLN A  12 "    0.000 2.00e-02 2.50e+03   1.67e-04 2.80e-04
      pdb=" C   GLN A  12 "   -0.000 2.00e-02 2.50e+03
      pdb=" O   GLN A  12 "    0.000 2.00e-02 2.50e+03
      pdb=" N   PHE A  13 "    0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  ASP A  79 "    0.000 2.00e-02 2.50e+03   1.65e-04 2.71e-04
      pdb=" C   ASP A  79 "   -0.000 2.00e-02 2.50e+03
      pdb=" O   ASP A  79 "    0.000 2.00e-02 2.50e+03
      pdb=" N   ARG A  80 "    0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  LEU A  76 "   -0.000 2.00e-02 2.50e+03   1.09e-04 1.19e-04
      pdb=" C   LEU A  76 "    0.000 2.00e-02 2.50e+03
      pdb=" O   LEU A  76 "   -0.000 2.00e-02 2.50e+03
      pdb=" N   MSE A  77 "   -0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  GLY A  59 "   -0.000 2.00e-02 2.50e+03   9.58e-05 9.18e-05
      pdb=" C   GLY A  59 "    0.000 2.00e-02 2.50e+03
      pdb=" O   GLY A  59 "   -0.000 2.00e-02 2.50e+03
      pdb=" N   LEU A  60 "   -0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CG  GLN A  10 "    0.000 2.00e-02 2.50e+03   1.84e-05 3.38e-06
      pdb=" CD  GLN A  10 "   -0.000 2.00e-02 2.50e+03
      pdb=" OE1 GLN A  10 "    0.000 2.00e-02 2.50e+03
      pdb=" NE2 GLN A  10 "    0.000 2.00e-02 2.50e+03
                               delta    sigma   weight rms_deltas residual
plane pdb=" CA  TYR A  41 "   -0.000 2.00e-02 2.50e+03   6.48e-06 4.20e-07
      pdb=" C   TYR A  41 "    0.000 2.00e-02 2.50e+03
      pdb=" O   TYR A  41 "   -0.000 2.00e-02 2.50e+03
      pdb=" N   PRO A  42 "   -0.000 2.00e-02 2.50e+03

Nonbonded | unspecified | interactions: 6051
Sorted by model distance:
nonbonded pdb=" NH2 ARG A  21 "
          pdb=" OE1 GLU A  51 "
   model   vdw sym.op.
   1.658 3.120 -x+1/2,y-1/2,-z+2
nonbonded pdb=" CB  MSE A  77 "
          pdb="SE    SE Z   1 "
   model   vdw sym.op.
   2.278 3.820 -x,y+1,-z+1
nonbonded pdb="SE    SE Z   4 "
          pdb="O    HOH S 103 "
   model   vdw sym.op.
   2.391 3.420 -x-1/2,y-1/2,-z-1
nonbonded pdb="SE    SE Z   1 "
          pdb="O    HOH S 103 "
   model   vdw
   2.467 3.420
nonbonded pdb="SE    SE Z   1 "
          pdb="SE    SE Z   4 "
   model   vdw sym.op.
   2.507 3.800 -x-1/2,y+1/2,-z-1
nonbonded pdb=" N   SER A  20 "
          pdb=" O   LYS A  24 "
   model   vdw
   2.531 3.120
nonbonded pdb=" O   ARG A  21 "
          pdb=" CA  GLN A  22 "
   model   vdw
   2.596 2.776
nonbonded pdb=" N   THR A  62 "
          pdb=" O   THR A  62 "
   model   vdw
   2.639 2.496
nonbonded pdb=" N   LYS A  69 "
          pdb=" O   LYS A  69 "
   model   vdw
   2.639 2.496
nonbonded pdb=" C   SER A  20 "
          pdb=" OG  SER A  20 "
   model   vdw
   2.654 2.616
nonbonded pdb=" N   MSE A  77 "
          pdb=" O   MSE A  77 "
   model   vdw
   2.660 2.496
nonbonded pdb=" N   CYS A  33 "
          pdb=" O   CYS A  33 "
   model   vdw
   2.662 2.496
nonbonded pdb=" N   VAL A  84 "
          pdb=" O   VAL A  84 "
   model   vdw
   2.680 2.496
nonbonded pdb=" O   PRO A  54 "
          pdb="O    HOH S  98 "
   model   vdw
   2.683 3.040
nonbonded pdb=" N   TYR A  61 "
          pdb=" O   TYR A  61 "
   model   vdw
   2.688 2.496
nonbonded pdb=" N   ASN A  39 "
          pdb=" O   ASN A  39 "
   model   vdw
   2.690 2.496
nonbonded pdb=" N   SER A  17 "
          pdb=" O   SER A  17 "
   model   vdw
   2.695 2.496
nonbonded pdb=" N   GLY A  18 "
          pdb=" O   GLY A  18 "
   model   vdw
   2.699 2.496
nonbonded pdb=" O   LYS A  24 "
          pdb=" CA  PRO A  25 "
   model   vdw
   2.701 2.776
nonbonded pdb=" C   VAL A  84 "
          pdb=" CG1 VAL A  84 "
   model   vdw
   2.701 2.952
nonbonded pdb=" O   SER A  20 "
          pdb=" CA  ARG A  21 "
   model   vdw
   2.701 2.776
nonbonded pdb=" N   ALA A  57 "
          pdb=" O   ALA A  57 "
   model   vdw
   2.703 2.496
nonbonded pdb=" O   GLY A  23 "
          pdb=" CA  LYS A  24 "
   model   vdw
   2.704 2.776
nonbonded pdb=" N   VAL A  43 "
          pdb=" O   VAL A  43 "
   model   vdw
   2.705 2.496
nonbonded pdb=" N   PRO A  54 "
          pdb=" O   PRO A  54 "
   model   vdw
   2.705 2.496
nonbonded pdb=" N   GLN A  12 "
          pdb=" O   GLN A  12 "
   model   vdw
   2.708 2.496
nonbonded pdb=" O   TYR A  26 "
          pdb=" CA  SER A  27 "
   model   vdw
   2.708 2.776
nonbonded pdb=" CB  ARG A  21 "
          pdb=" NE  ARG A  21 "
   model   vdw
   2.713 2.816
nonbonded pdb=" O   ASP A  36 "
          pdb="O    HOH S   2 "
   model   vdw
   2.716 3.040
nonbonded pdb=" N   GLY A  59 "
          pdb=" O   GLY A  59 "
   model   vdw
   2.716 2.496
nonbonded pdb=" O   VAL A  19 "
          pdb=" CA  SER A  20 "
   model   vdw
   2.717 2.776
nonbonded pdb=" N   ASP A  50 "
          pdb=" O   ASP A  50 "
   model   vdw
   2.717 2.496
nonbonded pdb=" N   LYS A   7 "
          pdb=" O   LYS A   7 "
   model   vdw
   2.718 2.496
nonbonded pdb=" OE1 GLN A  53 "
          pdb="O    HOH S  98 "
   model   vdw
   2.718 3.040
nonbonded pdb=" O   TYR A  41 "
          pdb="O    HOH S   3 "
   model   vdw
   2.719 3.040
nonbonded pdb=" O   ALA A  57 "
          pdb=" CA  PRO A  58 "
   model   vdw
   2.720 2.776
nonbonded pdb=" O   VAL A  45 "
          pdb=" CA  LYS A  46 "
   model   vdw
   2.721 2.776
nonbonded pdb=" OH  TYR A  26 "
          pdb="O    HOH S  85 "
   model   vdw
   2.722 3.040
nonbonded pdb=" N   THR A  14 "
          pdb=" O   THR A  14 "
   model   vdw
   2.723 2.496
nonbonded pdb=" O   GLN A  53 "
          pdb=" CA  PRO A  54 "
   model   vdw
   2.728 2.776
nonbonded pdb=" N   SER A   9 "
          pdb=" N   GLN A  10 "
   model   vdw
   2.728 2.560
nonbonded pdb=" N   SER A  66 "
          pdb=" N   SER A  67 "
   model   vdw
   2.728 2.560
nonbonded pdb=" O   TYR A  41 "
          pdb=" CA  PRO A  42 "
   model   vdw
   2.729 2.776
nonbonded pdb=" N   TYR A  41 "
          pdb=" O   TYR A  41 "
   model   vdw
   2.729 2.496
nonbonded pdb=" O   LYS A  46 "
          pdb=" CA  ILE A  47 "
   model   vdw
   2.729 2.776
nonbonded pdb=" O   LYS A   7 "
          pdb=" CA  PRO A   8 "
   model   vdw
   2.730 2.776
nonbonded pdb=" N   GLN A  31 "
          pdb=" O   GLN A  31 "
   model   vdw
   2.731 2.496
nonbonded pdb=" CA  ASP A  36 "
          pdb=" OD1 ASP A  36 "
   model   vdw
   2.732 2.776
nonbonded pdb=" N   GLN A  10 "
          pdb=" N   ALA A  11 "
   model   vdw
   2.732 2.560
nonbonded pdb=" O   ALA A  57 "
          pdb=" OH  TYR A  61 "
   model   vdw
   2.732 3.040
nonbonded pdb=" O   SER A  27 "
          pdb=" CA  LEU A  28 "
   model   vdw
   2.733 2.776
nonbonded pdb=" O   ASP A  50 "
          pdb=" CA  GLU A  51 "
   model   vdw
   2.733 2.776
nonbonded pdb=" O   SER A  17 "
          pdb=" CA  GLY A  18 "
   model   vdw
   2.733 2.752
nonbonded pdb=" N   PHE A  73 "
          pdb=" N   GLY A  74 "
   model   vdw
   2.733 2.560
nonbonded pdb=" O   ALA A  55 "
          pdb=" CA  TYR A  56 "
   model   vdw
   2.734 2.776
nonbonded pdb=" CZ  ARG A  21 "
          pdb=" OE1 GLU A  51 "
   model   vdw sym.op.
   2.736 3.270 -x+1/2,y-1/2,-z+2
nonbonded pdb=" N   PHE A  13 "
          pdb=" O   PHE A  13 "
   model   vdw
   2.736 2.496
nonbonded pdb=" O   LEU A  44 "
          pdb=" CA  VAL A  45 "
   model   vdw
   2.738 2.776
nonbonded pdb=" N   TYR A  26 "
          pdb=" O   TYR A  26 "
   model   vdw
   2.739 2.496
nonbonded pdb=" O   PRO A  54 "
          pdb=" CA  ALA A  55 "
   model   vdw
   2.741 2.776
nonbonded pdb=" N   SER A  67 "
          pdb=" N   PHE A  68 "
   model   vdw
   2.742 2.560
nonbonded pdb=" O   LEU A  37 "
          pdb=" CA  GLY A  38 "
   model   vdw
   2.743 2.752
nonbonded pdb=" N   LEU A  37 "
          pdb=" N   GLY A  38 "
   model   vdw
   2.744 2.560
nonbonded pdb=" CB  GLU A  30 "
          pdb=" OE1 GLU A  30 "
   model   vdw
   2.744 2.752
nonbonded pdb=" N   LYS A  46 "
          pdb=" O   LYS A  46 "
   model   vdw
   2.744 2.496
nonbonded pdb=" CD1 TYR A  26 "
          pdb=" CE2 TYR A  26 "
   model   vdw
   2.746 2.912
nonbonded pdb=" O   ASN A  39 "
          pdb=" CA  GLU A  40 "
   model   vdw
   2.747 2.776
nonbonded pdb=" O   GLY A  52 "
          pdb=" CA  GLN A  53 "
   model   vdw
   2.747 2.776
nonbonded pdb=" O   VAL A   4 "
          pdb=" N   TYR A  61 "
   model   vdw
   2.748 3.120
nonbonded pdb=" N   LEU A  32 "
          pdb=" O   LEU A  32 "
   model   vdw
   2.748 2.496
nonbonded pdb=" O   LEU A  28 "
          pdb=" CA  ASN A  29 "
   model   vdw
   2.748 2.776
nonbonded pdb=" N   ILE A  47 "
          pdb=" O   ILE A  47 "
   model   vdw
   2.751 2.496
nonbonded pdb=" O   LEU A  65 "
          pdb=" CA  SER A  66 "
   model   vdw
   2.751 2.776
nonbonded pdb=" CB  GLU A  51 "
          pdb=" OE1 GLU A  51 "
   model   vdw
   2.751 2.752
nonbonded pdb=" CB  GLU A   5 "
          pdb=" OE1 GLU A   5 "
   model   vdw
   2.753 2.752
nonbonded pdb=" N   SER A  75 "
          pdb=" O   SER A  75 "
   model   vdw
   2.753 2.496
nonbonded pdb=" CD1 PHE A  13 "
          pdb=" CE2 PHE A  13 "
   model   vdw
   2.753 2.912
nonbonded pdb=" O   PRO A  58 "
          pdb=" CA  GLY A  59 "
   model   vdw
   2.754 2.752
nonbonded pdb=" CD1 TYR A  41 "
          pdb=" CE2 TYR A  41 "
   model   vdw
   2.755 2.912
nonbonded pdb=" OE2 GLU A   5 "
          pdb="O    HOH S  51 "
   model   vdw
   2.755 3.040
nonbonded pdb=" CD2 PHE A  73 "
          pdb=" CE1 PHE A  73 "
   model   vdw
   2.755 2.912
nonbonded pdb=" CD2 TYR A  41 "
          pdb=" CE1 TYR A  41 "
   model   vdw
   2.755 2.912
nonbonded pdb=" CD2 TYR A  26 "
          pdb=" CE1 TYR A  26 "
   model   vdw
   2.755 2.912
nonbonded pdb=" CD2 TYR A  61 "
          pdb=" CE1 TYR A  61 "
   model   vdw
   2.756 2.912
nonbonded pdb=" CD1 TYR A  61 "
          pdb=" CE2 TYR A  61 "
   model   vdw
   2.756 2.912
nonbonded pdb=" N   ALA A  11 "
          pdb=" N   GLN A  12 "
   model   vdw
   2.757 2.560
nonbonded pdb=" CD2 PHE A  68 "
          pdb=" CE1 PHE A  68 "
   model   vdw
   2.757 2.912
nonbonded pdb=" O   GLY A  74 "
          pdb=" CA  SER A  75 "
   model   vdw
   2.757 2.776
nonbonded pdb=" CD1 PHE A  73 "
          pdb=" CE2 PHE A  73 "
   model   vdw
   2.757 2.912
nonbonded pdb=" CD1 TYR A  56 "
          pdb=" CE2 TYR A  56 "
   model   vdw
   2.757 2.912
nonbonded pdb=" CD2 PHE A  13 "
          pdb=" CE1 PHE A  13 "
   model   vdw
   2.757 2.912
nonbonded pdb=" CB  GLN A  31 "
          pdb=" OE1 GLN A  31 "
   model   vdw
   2.757 2.752
nonbonded pdb=" CG  TYR A  41 "
          pdb=" CZ  TYR A  41 "
   model   vdw
   2.758 2.784
nonbonded pdb=" N   VAL A   4 "
          pdb=" O   VAL A   4 "
   model   vdw
   2.758 2.496
nonbonded pdb=" O   ILE A   6 "
          pdb=" CA  LYS A   7 "
   model   vdw
   2.758 2.776
nonbonded pdb=" CB  GLU A  40 "
          pdb=" OE1 GLU A  40 "
   model   vdw
   2.758 2.752
nonbonded pdb=" O   GLY A  38 "
          pdb=" CA  ASN A  39 "
   model   vdw
   2.758 2.776
nonbonded pdb=" CD1 TYR A  34 "
          pdb=" CE2 TYR A  34 "
   model   vdw
   2.759 2.912
nonbonded pdb=" CD1 PHE A  68 "
          pdb=" CE2 PHE A  68 "
   model   vdw
   2.761 2.912
nonbonded pdb=" OG1 THR A  15 "
          pdb=" OD1 ASN A  29 "
   model   vdw
   2.761 3.040
nonbonded pdb=" O   SER A  66 "
          pdb=" CA  SER A  67 "
   model   vdw
   2.761 2.776
nonbonded pdb=" CD2 TYR A  34 "
          pdb=" CE1 TYR A  34 "
   model   vdw
   2.761 2.912
nonbonded pdb=" CD2 TYR A  56 "
          pdb=" CE1 TYR A  56 "
   model   vdw
   2.762 2.912
nonbonded pdb=" O   PHE A  73 "
          pdb=" CA  GLY A  74 "
   model   vdw
   2.762 2.752
nonbonded pdb="O    HOH S   9 "
          pdb="O    HOH S  54 "
   model   vdw
   2.762 3.040
nonbonded pdb=" N   LEU A  65 "
          pdb=" N   SER A  66 "
   model   vdw
   2.762 2.560
nonbonded pdb=" O   TYR A  56 "
          pdb=" CA  ALA A  57 "
   model   vdw
   2.763 2.776
nonbonded pdb=" O   SER A  67 "
          pdb=" N   ASP A  79 "
   model   vdw
   2.764 3.120
nonbonded pdb=" N   PHE A  68 "
          pdb=" O   PHE A  68 "
   model   vdw
   2.764 2.496
nonbonded pdb=" O   ARG A  80 "
          pdb=" CA  LEU A  81 "
   model   vdw
   2.764 2.776
nonbonded pdb=" CB  GLN A  72 "
          pdb=" OE1 GLN A  72 "
   model   vdw
   2.765 2.752
nonbonded pdb=" N   GLN A  72 "
          pdb=" N   PHE A  73 "
   model   vdw
   2.765 2.560
nonbonded pdb=" N   VAL A  70 "
          pdb=" CG2 VAL A  70 "
   model   vdw
   2.765 2.832
nonbonded pdb=" N   HIS A  64 "
          pdb=" O   HIS A  64 "
   model   vdw
   2.766 2.496
nonbonded pdb=" CG  TYR A  26 "
          pdb=" CZ  TYR A  26 "
   model   vdw
   2.767 2.784
nonbonded pdb=" O   GLN A  72 "
          pdb=" CA  PHE A  73 "
   model   vdw
   2.768 2.776
nonbonded pdb=" N   GLY A  71 "
          pdb=" O   GLY A  71 "
   model   vdw
   2.768 2.496
nonbonded pdb=" N   GLN A  22 "
          pdb=" N   GLY A  23 "
   model   vdw
   2.768 2.560
nonbonded pdb=" N   PRO A  42 "
          pdb=" O   PRO A  42 "
   model   vdw
   2.769 2.496
nonbonded pdb=" O   LEU A  49 "
          pdb=" CA  ASP A  50 "
   model   vdw
   2.769 2.776
nonbonded pdb=" O   THR A  48 "
          pdb=" CA  LEU A  49 "
   model   vdw
   2.769 2.776
nonbonded pdb=" O   VAL A  70 "
          pdb=" CA  GLY A  71 "
   model   vdw
   2.769 2.752
nonbonded pdb=" N   ALA A  55 "
          pdb=" O   ALA A  55 "
   model   vdw
   2.770 2.496
nonbonded pdb=" O   SER A  75 "
          pdb=" CA  LEU A  76 "
   model   vdw
   2.770 2.776
nonbonded pdb=" N   TYR A  56 "
          pdb=" O   TYR A  56 "
   model   vdw
   2.770 2.496
nonbonded pdb=" O   HIS A  64 "
          pdb=" CA  LEU A  65 "
   model   vdw
   2.771 2.776
nonbonded pdb=" O   GLN A  22 "
          pdb=" CA  GLY A  23 "
   model   vdw
   2.771 2.752
nonbonded pdb=" O   PRO A   8 "
          pdb=" CA  SER A   9 "
   model   vdw
   2.772 2.776
nonbonded pdb=" O   GLY A  18 "
          pdb=" CA  VAL A  19 "
   model   vdw
   2.774 2.776
nonbonded pdb=" O   LYS A  69 "
          pdb=" CA  VAL A  70 "
   model   vdw
   2.774 2.776
nonbonded pdb=" O   ASN A  39 "
          pdb="O    HOH S 123 "
   model   vdw
   2.774 3.040
nonbonded pdb=" O   THR A  62 "
          pdb=" CA  VAL A  63 "
   model   vdw
   2.774 2.776
nonbonded pdb=" O   ALA A  11 "
          pdb=" CA  GLN A  12 "
   model   vdw
   2.775 2.776
nonbonded pdb=" C   SER A  27 "
          pdb=" OG  SER A  27 "
   model   vdw
   2.775 2.616
nonbonded pdb=" O   VAL A   4 "
          pdb=" CA  GLU A   5 "
   model   vdw
   2.776 2.776
nonbonded pdb=" C   LYS A   3 "
          pdb=" CG  LYS A   3 "
   model   vdw
   2.776 2.936
nonbonded pdb=" N   ARG A  80 "
          pdb=" O   ARG A  80 "
   model   vdw
   2.777 2.496
nonbonded pdb=" O   GLY A  71 "
          pdb=" CA  GLN A  72 "
   model   vdw
   2.777 2.776
nonbonded pdb=" CG  TYR A  61 "
          pdb=" CZ  TYR A  61 "
   model   vdw
   2.777 2.784
nonbonded pdb=" CG  TYR A  34 "
          pdb=" CZ  TYR A  34 "
   model   vdw
   2.778 2.784
nonbonded pdb=" CA  ASP A  79 "
          pdb=" OD1 ASP A  79 "
   model   vdw
   2.778 2.776
nonbonded pdb=" CG  TYR A  56 "
          pdb=" CZ  TYR A  56 "
   model   vdw
   2.779 2.784
nonbonded pdb=" O   LEU A  49 "
          pdb="O    HOH S  33 "
   model   vdw
   2.779 3.040
nonbonded pdb=" CG  PHE A  73 "
          pdb=" CZ  PHE A  73 "
   model   vdw
   2.780 2.848
nonbonded pdb=" CG  PHE A  68 "
          pdb=" CZ  PHE A  68 "
   model   vdw
   2.780 2.848
nonbonded pdb=" O   SER A  67 "
          pdb=" CA  PHE A  68 "
   model   vdw
   2.782 2.776
nonbonded pdb=" O   GLN A  10 "
          pdb=" CA  ALA A  11 "
   model   vdw
   2.782 2.776
nonbonded pdb=" N   LEU A  49 "
          pdb=" O   LEU A  49 "
   model   vdw
   2.782 2.496
nonbonded pdb=" N   VAL A  45 "
          pdb=" O   VAL A  45 "
   model   vdw
   2.783 2.496
nonbonded pdb=" O   ASP A  36 "
          pdb=" CA  LEU A  37 "
   model   vdw
   2.783 2.776
nonbonded pdb=" O   VAL A  43 "
          pdb=" CA  LEU A  44 "
   model   vdw
   2.784 2.776
nonbonded pdb=" O   PHE A  13 "
          pdb=" CA  THR A  14 "
   model   vdw
   2.784 2.776
nonbonded pdb=" N   ARG A  21 "
          pdb=" N   GLN A  22 "
   model   vdw
   2.785 2.560
nonbonded pdb=" CG  PHE A  13 "
          pdb=" CZ  PHE A  13 "
   model   vdw
   2.785 2.848
nonbonded pdb=" O   ARG A  16 "
          pdb=" CA  SER A  17 "
   model   vdw
   2.786 2.776
nonbonded pdb=" N   PRO A  25 "
          pdb=" O   PRO A  25 "
   model   vdw
   2.786 2.496
nonbonded pdb=" N   ILE A   2 "
          pdb=" CG2 ILE A   2 "
   model   vdw
   2.787 2.832
nonbonded pdb=" OD1 ASP A  79 "
          pdb="O    HOH S 160 "
   model   vdw
   2.787 3.040
nonbonded pdb=" CA  ASN A  29 "
          pdb=" OD1 ASN A  29 "
   model   vdw
   2.787 2.776
nonbonded pdb=" O   LEU A  32 "
          pdb=" CA  CYS A  33 "
   model   vdw
   2.788 2.776
nonbonded pdb=" O   ILE A   2 "
          pdb=" CA  LYS A   3 "
   model   vdw
   2.788 2.776
nonbonded pdb=" O   LEU A  76 "
          pdb=" CA  MSE A  77 "
   model   vdw
   2.789 2.776
nonbonded pdb=" O   GLN A  31 "
          pdb=" CA  LEU A  32 "
   model   vdw
   2.789 2.776
nonbonded pdb=" O   VAL A  35 "
          pdb=" CA  ASP A  36 "
   model   vdw
   2.790 2.776
nonbonded pdb=" N   GLY A  74 "
          pdb=" N   SER A  75 "
   model   vdw
   2.790 2.560
nonbonded pdb=" N   LYS A   3 "
          pdb="O    HOH S   2 "
   model   vdw
   2.792 3.120
nonbonded pdb=" N   GLY A  38 "
          pdb=" N   ASN A  39 "
   model   vdw
   2.792 2.560
nonbonded pdb=" N   LEU A  83 "
          pdb=" O   LEU A  83 "
   model   vdw
   2.792 2.496
nonbonded pdb=" O   GLN A  12 "
          pdb=" CA  PHE A  13 "
   model   vdw
   2.793 2.776
nonbonded pdb=" O   ASP A  79 "
          pdb=" CA  ARG A  80 "
   model   vdw
   2.794 2.776
nonbonded pdb=" O   GLU A  51 "
          pdb=" CA  GLY A  52 "
   model   vdw
   2.794 2.752
nonbonded pdb=" O   LEU A  81 "
          pdb=" CA  ARG A  82 "
   model   vdw
   2.795 2.776
nonbonded pdb=" O   ARG A  82 "
          pdb=" CA  LEU A  83 "
   model   vdw
   2.796 2.776
nonbonded pdb=" O   ILE A  78 "
          pdb=" CA  ASP A  79 "
   model   vdw
   2.796 2.776
nonbonded pdb=" O   PRO A  42 "
          pdb=" CA  VAL A  43 "
   model   vdw
   2.796 2.776
nonbonded pdb=" O   VAL A  63 "
          pdb=" CA  HIS A  64 "
   model   vdw
   2.797 2.776
nonbonded pdb=" N   VAL A  35 "
          pdb=" O   VAL A  43 "
   model   vdw
   2.798 3.120
nonbonded pdb=" O   THR A  14 "
          pdb=" CA  THR A  15 "
   model   vdw
   2.798 2.776
nonbonded pdb=" N   SER A  20 "
          pdb=" O   SER A  20 "
   model   vdw
   2.799 2.496
nonbonded pdb=" N   VAL A  35 "
          pdb=" O   VAL A  35 "
   model   vdw
   2.799 2.496
nonbonded pdb=" O   MSE A  77 "
          pdb=" CA  ILE A  78 "
   model   vdw
   2.800 2.776
nonbonded pdb=" C   VAL A  45 "
          pdb=" CG1 VAL A  45 "
   model   vdw
   2.800 2.952
nonbonded pdb=" OD2 ASP A  50 "
          pdb=" NE  ARG A  82 "
   model   vdw
   2.800 3.120
nonbonded pdb=" O   GLU A  30 "
          pdb=" CA  GLN A  31 "
   model   vdw
   2.800 2.776
nonbonded pdb=" O   ILE A  47 "
          pdb=" CA  THR A  48 "
   model   vdw
   2.802 2.776
nonbonded pdb=" O   THR A  15 "
          pdb=" CA  ARG A  16 "
   model   vdw
   2.802 2.776
nonbonded pdb=" O   LEU A  37 "
          pdb=" CB  LEU A  37 "
   model   vdw
   2.803 2.752
nonbonded pdb=" O   PHE A  68 "
          pdb=" CA  LYS A  69 "
   model   vdw
   2.804 2.776
nonbonded pdb=" OD1 ASP A  36 "
          pdb="O    HOH S 123 "
   model   vdw
   2.804 3.040
nonbonded pdb=" O   PRO A  25 "
          pdb=" CA  TYR A  26 "
   model   vdw
   2.806 2.776
nonbonded pdb=" O   ASN A  29 "
          pdb=" CA  GLU A  30 "
   model   vdw
   2.806 2.776
nonbonded pdb=" O   SER A  20 "
          pdb=" C   ARG A  21 "
   model   vdw
   2.806 3.270
nonbonded pdb=" CB  GLN A  53 "
          pdb=" OE1 GLN A  53 "
   model   vdw
   2.807 2.752
nonbonded pdb=" O   LEU A  83 "
          pdb=" CA  VAL A  84 "
   model   vdw
   2.807 2.776
nonbonded pdb=" N   VAL A  19 "
          pdb=" O   VAL A  19 "
   model   vdw
   2.808 2.496
nonbonded pdb=" O   GLN A  10 "
          pdb=" CB  GLN A  10 "
   model   vdw
   2.808 2.752
nonbonded pdb=" O   SER A   9 "
          pdb=" CA  GLN A  10 "
   model   vdw
   2.809 2.776
nonbonded pdb=" N   GLU A  51 "
          pdb=" O   GLU A  51 "
   model   vdw
   2.809 2.496
nonbonded pdb=" N   PRO A   8 "
          pdb=" N   SER A   9 "
   model   vdw
   2.809 2.560
nonbonded pdb=" O   CYS A  33 "
          pdb=" CA  TYR A  34 "
   model   vdw
   2.809 2.776
nonbonded pdb=" N   GLY A  52 "
          pdb=" N   GLN A  53 "
   model   vdw
   2.810 2.560
nonbonded pdb=" O   TYR A  34 "
          pdb=" CA  VAL A  35 "
   model   vdw
   2.813 2.776
nonbonded pdb=" O   GLN A  22 "
          pdb=" CB  GLN A  22 "
   model   vdw
   2.813 2.752
nonbonded pdb=" O   GLU A   5 "
          pdb=" CA  ILE A   6 "
   model   vdw
   2.813 2.776
nonbonded pdb=" CD  ARG A  21 "
          pdb=" NH1 ARG A  21 "
   model   vdw
   2.814 2.816
nonbonded pdb=" O   TYR A  61 "
          pdb=" CA  THR A  62 "
   model   vdw
   2.815 2.776
nonbonded pdb=" N   GLU A  30 "
          pdb=" O   GLU A  30 "
   model   vdw
   2.815 2.496
nonbonded pdb=" O   LYS A   3 "
          pdb=" CA  VAL A   4 "
   model   vdw
   2.815 2.776
nonbonded pdb=" O   LEU A  60 "
          pdb=" CA  TYR A  61 "
   model   vdw
   2.816 2.776
nonbonded pdb=" N   SER A  27 "
          pdb=" O   SER A  27 "
   model   vdw
   2.816 2.496
nonbonded pdb=" O   GLU A  30 "
          pdb="O    HOH S 151 "
   model   vdw
   2.817 3.040
nonbonded pdb=" N   GLU A   5 "
          pdb=" O   TYR A  34 "
   model   vdw
   2.819 3.120
nonbonded pdb=" N   ARG A  16 "
          pdb=" O   ARG A  16 "
   model   vdw
   2.820 2.496
nonbonded pdb=" N   HIS A  64 "
          pdb=" O   ARG A  82 "
   model   vdw
   2.820 3.120
nonbonded pdb=" N   GLU A   5 "
          pdb=" O   GLU A   5 "
   model   vdw
   2.821 2.496
nonbonded pdb=" N   GLU A  40 "
          pdb=" N   TYR A  41 "
   model   vdw
   2.824 2.560
nonbonded pdb=" O   VAL A  84 "
          pdb=" CA  PRO A  85 "
   model   vdw
   2.826 2.776
nonbonded pdb=" O   GLU A  40 "
          pdb=" CA  TYR A  41 "
   model   vdw
   2.827 2.776
nonbonded pdb=" O   GLY A  59 "
          pdb=" CA  LEU A  60 "
   model   vdw
   2.828 2.776
nonbonded pdb=" C   SER A   9 "
          pdb=" OG  SER A   9 "
   model   vdw
   2.830 2.616
nonbonded pdb=" OG  SER A  75 "
          pdb="O    HOH S   4 "
   model   vdw
   2.831 3.040
nonbonded pdb=" O   ASN A  39 "
          pdb="O    HOH S 131 "
   model   vdw
   2.831 3.040
nonbonded pdb=" N   VAL A  63 "
          pdb=" O   VAL A  63 "
   model   vdw
   2.834 2.496
nonbonded pdb=" C   ILE A   2 "
          pdb=" CG1 ILE A   2 "
   model   vdw
   2.835 2.936
nonbonded pdb=" N   LEU A  76 "
          pdb=" O   LEU A  76 "
   model   vdw
   2.836 2.496
nonbonded pdb=" N   ASN A  29 "
          pdb=" O   ASN A  29 "
   model   vdw
   2.837 2.496
nonbonded pdb=" N   GLN A  53 "
          pdb=" O   GLN A  53 "
   model   vdw
   2.837 2.496
nonbonded pdb=" OE2 GLU A  40 "
          pdb="O    HOH S 117 "
   model   vdw sym.op.
   2.839 3.040 x+1/2,y+1/2,z
nonbonded pdb=" CB  ASN A  39 "
          pdb=" N   GLU A  40 "
   model   vdw
   2.839 2.816
nonbonded pdb=" C   THR A  15 "
          pdb=" CG2 THR A  15 "
   model   vdw
   2.841 2.952
nonbonded pdb=" CD  ARG A  82 "
          pdb=" NH1 ARG A  82 "
   model   vdw
   2.843 2.816
nonbonded pdb=" CD  ARG A  80 "
          pdb=" NH1 ARG A  80 "
   model   vdw
   2.843 2.816
nonbonded pdb=" CD  ARG A  16 "
          pdb=" NH1 ARG A  16 "
   model   vdw
   2.843 2.816
nonbonded pdb=" NH2 ARG A  21 "
          pdb=" CD  GLU A  51 "
   model   vdw sym.op.
   2.845 3.350 -x+1/2,y-1/2,-z+2
nonbonded pdb=" ND1 HIS A  64 "
          pdb=" OG  SER A  66 "
   model   vdw
   2.846 3.120
nonbonded pdb=" N   LYS A   7 "
          pdb=" OE1 GLN A  10 "
   model   vdw
   2.849 3.120
nonbonded pdb=" N   LEU A  60 "
          pdb=" O   LEU A  60 "
   model   vdw
   2.850 2.496
nonbonded pdb=" C   ILE A  78 "
          pdb=" CG2 ILE A  78 "
   model   vdw
   2.851 2.952
nonbonded pdb=" N   LYS A  24 "
          pdb=" O   LYS A  24 "
   model   vdw
   2.852 2.496
nonbonded pdb=" N   PRO A  85 "
          pdb=" O   PRO A  85 "
   model   vdw
   2.853 2.496
nonbonded pdb=" O   PHE A  73 "
          pdb=" CB  PHE A  73 "
   model   vdw
   2.854 2.752
nonbonded pdb=" OG1 THR A  62 "
          pdb="O    HOH S  12 "
   model   vdw
   2.854 3.040
nonbonded pdb=" O   THR A  14 "
          pdb=" N   GLU A  30 "
   model   vdw
   2.854 3.120
nonbonded pdb=" O   VAL A  84 "
          pdb=" C   PRO A  85 "
   model   vdw
   2.854 3.270
nonbonded pdb=" N   GLY A  71 "
          pdb=" O   SER A  75 "
   model   vdw
   2.854 3.120
nonbonded pdb="O    HOH S  81 "
          pdb="O    HOH S 120 "
   model   vdw
   2.855 3.040
nonbonded pdb=" N   PRO A  58 "
          pdb=" O   PRO A  58 "
   model   vdw
   2.856 2.496
nonbonded pdb=" N   SER A  67 "
          pdb=" OG  SER A  67 "
   model   vdw
   2.856 2.496
nonbonded pdb=" O   VAL A  35 "
          pdb=" N   VAL A  43 "
   model   vdw
   2.856 3.120
nonbonded pdb=" N   LEU A  76 "
          pdb="O    HOH S  10 "
   model   vdw sym.op.
   2.862 3.120 -x+1,y,-z+2
nonbonded pdb=" N   GLY A  23 "
          pdb=" N   LYS A  24 "
   model   vdw
   2.863 2.560
nonbonded pdb=" CB  SER A  20 "
          pdb=" N   ARG A  21 "
   model   vdw
   2.864 2.816
nonbonded pdb=" OE2 GLU A  40 "
          pdb=" OG  SER A   9 "
   model   vdw sym.op.
   2.865 3.040 -x+1,y,-z+1
nonbonded pdb=" OG  SER A   9 "
          pdb=" OE2 GLU A  40 "
   model   vdw sym.op.
   2.865 3.040 -x+1,y,-z+1
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" CD1 ILE A   6 "
   model   vdw
   2.865 3.104
nonbonded pdb=" N   LEU A  28 "
          pdb=" O   LEU A  28 "
   model   vdw
   2.865 2.496
nonbonded pdb=" OE1 GLU A  30 "
          pdb="O    HOH S   8 "
   model   vdw
   2.866 3.040
nonbonded pdb=" N   ALA A  55 "
          pdb="O    HOH S  44 "
   model   vdw
   2.868 3.120
nonbonded pdb=" N   TYR A  34 "
          pdb=" O   TYR A  34 "
   model   vdw
   2.870 2.496
nonbonded pdb=" O   ASN A  29 "
          pdb=" N   LEU A  49 "
   model   vdw
   2.871 3.120
nonbonded pdb=" OG  SER A  67 "
          pdb=" N   ARG A  82 "
   model   vdw
   2.872 3.120
nonbonded pdb=" O   PRO A   8 "
          pdb=" N   THR A  15 "
   model   vdw sym.op.
   2.872 3.120 -x+1/2,y+1/2,-z+1
nonbonded pdb=" N   THR A  14 "
          pdb=" OG1 THR A  14 "
   model   vdw
   2.874 2.496
nonbonded pdb=" O   THR A  15 "
          pdb="O    HOH S  34 "
   model   vdw
   2.874 3.040
nonbonded pdb=" N   LEU A  32 "
          pdb="O    HOH S   7 "
   model   vdw
   2.874 3.120
nonbonded pdb=" N   LYS A   3 "
          pdb=" O   LYS A   3 "
   model   vdw
   2.874 2.496
nonbonded pdb=" O   HIS A  64 "
          pdb=" OG  SER A  67 "
   model   vdw
   2.875 3.040
nonbonded pdb=" OG1 THR A  15 "
          pdb="O    HOH S 117 "
   model   vdw
   2.876 3.040
nonbonded pdb=" N   ARG A  82 "
          pdb=" O   ARG A  82 "
   model   vdw
   2.877 2.496
nonbonded pdb=" OH  TYR A  34 "
          pdb="O    HOH S  24 "
   model   vdw
   2.877 3.040
nonbonded pdb=" O   ALA A  55 "
          pdb="O    HOH S 134 "
   model   vdw
   2.880 3.040
nonbonded pdb=" C   SER A  66 "
          pdb=" OG  SER A  66 "
   model   vdw
   2.890 2.616
nonbonded pdb=" O   LYS A   7 "
          pdb=" C   PRO A   8 "
   model   vdw
   2.891 3.270
nonbonded pdb=" C   THR A  48 "
          pdb=" CG2 THR A  48 "
   model   vdw
   2.891 2.952
nonbonded pdb=" N   THR A  15 "
          pdb=" O   THR A  15 "
   model   vdw
   2.891 2.496
nonbonded pdb=" N   SER A  75 "
          pdb=" OG  SER A  75 "
   model   vdw
   2.893 2.496
nonbonded pdb=" C   THR A  62 "
          pdb=" CG2 THR A  62 "
   model   vdw
   2.893 2.952
nonbonded pdb=" O   LYS A  69 "
          pdb=" N   MSE A  77 "
   model   vdw
   2.895 3.120
nonbonded pdb=" OE1 GLN A  12 "
          pdb="O    HOH S 110 "
   model   vdw
   2.897 3.040
nonbonded pdb=" O   GLN A  10 "
          pdb=" NE2 GLN A  31 "
   model   vdw
   2.898 3.120
nonbonded pdb=" CB  GLN A  10 "
          pdb=" OE1 GLN A  10 "
   model   vdw
   2.898 2.752
nonbonded pdb=" C   GLU A   5 "
          pdb=" CG  GLU A   5 "
   model   vdw
   2.898 2.936
nonbonded pdb=" C   THR A  14 "
          pdb=" OG1 THR A  14 "
   model   vdw
   2.899 2.616
nonbonded pdb=" CB  GLN A  22 "
          pdb=" OE1 GLN A  22 "
   model   vdw
   2.901 2.752
nonbonded pdb=" CA  ASP A  50 "
          pdb=" OD1 ASP A  50 "
   model   vdw
   2.904 2.776
nonbonded pdb=" N   ILE A  78 "
          pdb=" O   ILE A  78 "
   model   vdw
   2.905 2.496
nonbonded pdb=" C   VAL A  63 "
          pdb=" CG1 VAL A  63 "
   model   vdw
   2.905 2.952
nonbonded pdb=" CA  LYS A  24 "
          pdb=" CD  PRO A  25 "
   model   vdw
   2.906 3.096
nonbonded pdb=" O   ALA A  11 "
          pdb=" CB  ALA A  11 "
   model   vdw
   2.907 2.768
nonbonded pdb=" N   GLU A  40 "
          pdb=" CG  GLU A  40 "
   model   vdw
   2.909 2.816
nonbonded pdb=" N   VAL A  70 "
          pdb=" O   VAL A  70 "
   model   vdw
   2.911 2.496
nonbonded pdb=" OH  TYR A  61 "
          pdb="O    HOH S  14 "
   model   vdw
   2.913 3.040
nonbonded pdb=" O   GLN A  31 "
          pdb=" N   ILE A  47 "
   model   vdw
   2.914 3.120
nonbonded pdb=" O   GLY A  18 "
          pdb=" N   TYR A  26 "
   model   vdw
   2.915 3.120
nonbonded pdb=" O   THR A  62 "
          pdb=" N   VAL A  84 "
   model   vdw
   2.915 3.120
nonbonded pdb=" N   ASN A  29 "
          pdb="O    HOH S  33 "
   model   vdw
   2.917 3.120
nonbonded pdb=" O   ASP A  36 "
          pdb=" CB  ASP A  36 "
   model   vdw
   2.917 2.752
nonbonded pdb=" N   ALA A  57 "
          pdb="O    HOH S  14 "
   model   vdw
   2.918 3.120
nonbonded pdb=" N   VAL A   4 "
          pdb=" CG2 VAL A   4 "
   model   vdw
   2.919 2.832
nonbonded pdb=" N   ILE A   6 "
          pdb=" O   GLY A  59 "
   model   vdw
   2.919 3.120
nonbonded pdb=" CA  VAL A  84 "
          pdb=" CD  PRO A  85 "
   model   vdw
   2.921 3.096
nonbonded pdb=" O   LEU A  81 "
          pdb=" CB  LEU A  81 "
   model   vdw
   2.922 2.752
nonbonded pdb=" C   SER A  75 "
          pdb=" OG  SER A  75 "
   model   vdw
   2.922 2.616
nonbonded pdb=" O   ARG A  16 "
          pdb=" N   LEU A  28 "
   model   vdw
   2.922 3.120
nonbonded pdb=" NE  ARG A  16 "
          pdb="O    HOH S  85 "
   model   vdw
   2.923 3.120
nonbonded pdb=" O   SER A  66 "
          pdb=" CB  SER A  66 "
   model   vdw
   2.923 2.752
nonbonded pdb=" CB  ASP A  79 "
          pdb=" N   ARG A  80 "
   model   vdw
   2.924 2.816
nonbonded pdb=" N   ILE A   6 "
          pdb=" O   ILE A   6 "
   model   vdw
   2.925 2.496
nonbonded pdb=" N   LEU A  81 "
          pdb="O    HOH S 106 "
   model   vdw
   2.925 3.120
nonbonded pdb=" O   GLU A   5 "
          pdb=" N   TYR A  34 "
   model   vdw
   2.927 3.120
nonbonded pdb=" C   SER A  20 "
          pdb=" C   ARG A  21 "
   model   vdw
   2.927 2.800
nonbonded pdb=" CB  ARG A  16 "
          pdb=" NE  ARG A  16 "
   model   vdw
   2.927 2.816
nonbonded pdb=" N   SER A  66 "
          pdb=" OG  SER A  66 "
   model   vdw
   2.930 2.496
nonbonded pdb=" OE2 GLU A   5 "
          pdb=" NZ  LYS A   7 "
   model   vdw
   2.930 3.120
nonbonded pdb=" O   LYS A  46 "
          pdb="O    HOH S  10 "
   model   vdw
   2.931 3.040
nonbonded pdb=" N   VAL A  70 "
          pdb="O    HOH S  16 "
   model   vdw
   2.931 3.120
nonbonded pdb=" O   LYS A   7 "
          pdb=" N   GLN A  10 "
   model   vdw
   2.933 3.120
nonbonded pdb=" N   GLN A  10 "
          pdb=" CG  GLN A  10 "
   model   vdw
   2.934 2.816
nonbonded pdb=" N   LEU A  65 "
          pdb="O    HOH S  35 "
   model   vdw
   2.934 3.120
nonbonded pdb=" N   THR A  48 "
          pdb=" OG1 THR A  48 "
   model   vdw
   2.934 2.496
nonbonded pdb=" CG2 ILE A  47 "
          pdb=" CD1 ILE A  47 "
   model   vdw
   2.935 3.104
nonbonded pdb=" C   VAL A  43 "
          pdb=" CG1 VAL A  43 "
   model   vdw
   2.936 2.952
nonbonded pdb=" CB  ARG A  21 "
          pdb=" N   GLN A  22 "
   model   vdw
   2.937 2.816
nonbonded pdb=" O   LYS A   3 "
          pdb=" N   ASP A  36 "
   model   vdw
   2.939 3.120
nonbonded pdb=" O   ALA A  57 "
          pdb=" C   PRO A  58 "
   model   vdw
   2.939 3.270
nonbonded pdb=" O   ALA A  55 "
          pdb=" C   TYR A  56 "
   model   vdw
   2.939 3.270
nonbonded pdb=" N   PHE A  68 "
          pdb=" CG  PHE A  68 "
   model   vdw
   2.940 2.672
nonbonded pdb=" O   SER A   9 "
          pdb=" CB  SER A   9 "
   model   vdw
   2.940 2.752
nonbonded pdb=" OG1 THR A  62 "
          pdb=" N   VAL A  63 "
   model   vdw
   2.941 3.120
nonbonded pdb=" O   CYS A  33 "
          pdb=" N   VAL A  45 "
   model   vdw
   2.943 3.120
nonbonded pdb=" N   THR A  62 "
          pdb=" O   VAL A  84 "
   model   vdw
   2.943 3.120
nonbonded pdb=" N   VAL A  35 "
          pdb=" CG2 VAL A  35 "
   model   vdw
   2.946 2.832
nonbonded pdb=" CA  TYR A  41 "
          pdb=" CD  PRO A  42 "
   model   vdw
   2.946 3.096
nonbonded pdb=" CG2 ILE A  78 "
          pdb=" CD1 ILE A  78 "
   model   vdw
   2.947 3.104
nonbonded pdb=" OD2 ASP A  50 "
          pdb="O    HOH S 135 "
   model   vdw
   2.949 3.040
nonbonded pdb=" N   THR A  48 "
          pdb=" O   THR A  48 "
   model   vdw
   2.951 2.496
nonbonded pdb=" N   ILE A   6 "
          pdb=" CG1 ILE A   6 "
   model   vdw
   2.951 2.816
nonbonded pdb=" NH1 ARG A  80 "
          pdb="O    HOH S 175 "
   model   vdw
   2.951 3.120
nonbonded pdb=" N   VAL A  19 "
          pdb=" CG2 VAL A  19 "
   model   vdw
   2.953 2.832
nonbonded pdb=" N   ARG A  82 "
          pdb=" CG  ARG A  82 "
   model   vdw
   2.954 2.816
nonbonded pdb=" N   THR A  14 "
          pdb=" CG2 THR A  14 "
   model   vdw
   2.955 2.832
nonbonded pdb=" O   HIS A  64 "
          pdb=" C   LEU A  65 "
   model   vdw
   2.955 3.270
nonbonded pdb=" O   THR A  48 "
          pdb=" CB  THR A  48 "
   model   vdw
   2.956 2.776
nonbonded pdb=" C   ALA A  55 "
          pdb=" C   TYR A  56 "
   model   vdw
   2.956 2.800
nonbonded pdb=" C   VAL A  19 "
          pdb=" CG1 VAL A  19 "
   model   vdw
   2.956 2.952
nonbonded pdb=" N   THR A  15 "
          pdb=" OG1 THR A  15 "
   model   vdw
   2.957 2.496
nonbonded pdb=" C   VAL A  35 "
          pdb=" CG1 VAL A  35 "
   model   vdw
   2.957 2.952
nonbonded pdb=" N   ILE A  47 "
          pdb=" CG2 ILE A  47 "
   model   vdw
   2.959 2.832
nonbonded pdb=" C   TYR A  26 "
          pdb=" CG  TYR A  26 "
   model   vdw
   2.959 2.792
nonbonded pdb=" CB  GLN A  12 "
          pdb=" OE1 GLN A  12 "
   model   vdw
   2.961 2.752
nonbonded pdb=" O   ARG A  80 "
          pdb=" N   ARG A  82 "
   model   vdw
   2.962 3.120
nonbonded pdb=" OH  TYR A  41 "
          pdb=" CG  PRO A  42 "
   model   vdw sym.op.
   2.963 3.440 -x+1,y,-z+1
nonbonded pdb=" CA  LYS A   7 "
          pdb=" CD  PRO A   8 "
   model   vdw
   2.963 3.096
nonbonded pdb=" CA  ASN A  39 "
          pdb=" ND2 ASN A  39 "
   model   vdw
   2.964 2.840
nonbonded pdb=" C   ASP A  79 "
          pdb=" OD1 ASP A  79 "
   model   vdw
   2.965 3.270
nonbonded pdb=" C   ILE A   6 "
          pdb=" CG2 ILE A   6 "
   model   vdw
   2.965 2.952
nonbonded pdb=" O   ILE A   6 "
          pdb=" CB  ILE A   6 "
   model   vdw
   2.965 2.776
nonbonded pdb="O    HOH S  12 "
          pdb="O    HOH S 163 "
   model   vdw sym.op.
   2.966 3.040 x,y,z
nonbonded pdb="O    HOH S 163 "
          pdb="O    HOH S  12 "
   model   vdw sym.op.
   2.966 3.040 x,y,z
nonbonded pdb="O    HOH S 163 "
          pdb="O    HOH S  12 "
   model   vdw sym.op.
   2.966 3.040 -x+1,y,-z+2
nonbonded pdb=" CA  LEU A  83 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   2.968 3.112
nonbonded pdb=" N   ILE A   2 "
          pdb=" O   ILE A   2 "
   model   vdw
   2.968 2.496
nonbonded pdb=" CA  ALA A  57 "
          pdb=" CD  PRO A  58 "
   model   vdw
   2.969 3.096
nonbonded pdb=" N   VAL A  63 "
          pdb=" CG2 VAL A  63 "
   model   vdw
   2.970 2.832
nonbonded pdb=" N   SER A   9 "
          pdb=" OG  SER A   9 "
   model   vdw
   2.970 2.496
nonbonded pdb=" C   LYS A  46 "
          pdb=" CG  LYS A  46 "
   model   vdw
   2.971 2.936
nonbonded pdb=" O   VAL A  84 "
          pdb=" O   PRO A  85 "
   model   vdw
   2.971 3.040
nonbonded pdb=" CA  LEU A  32 "
          pdb=" CD1 LEU A  32 "
   model   vdw
   2.971 3.112
nonbonded pdb=" O   TYR A  41 "
          pdb=" C   PRO A  42 "
   model   vdw
   2.973 3.270
nonbonded pdb=" O   ASP A  50 "
          pdb=" C   GLU A  51 "
   model   vdw
   2.974 3.270
nonbonded pdb=" C   ASP A  79 "
          pdb=" CG  ASP A  79 "
   model   vdw
   2.975 2.800
nonbonded pdb=" N   GLN A  31 "
          pdb=" O   ILE A  47 "
   model   vdw
   2.978 3.120
nonbonded pdb=" N   ASP A  79 "
          pdb=" N   ARG A  80 "
   model   vdw
   2.978 2.560
nonbonded pdb=" N   ASN A  29 "
          pdb=" CG  ASN A  29 "
   model   vdw
   2.979 2.680
nonbonded pdb=" NH1 ARG A  16 "
          pdb=" O   LEU A  60 "
   model   vdw sym.op.
   2.979 3.120 x,y-1,z
nonbonded pdb=" CA  GLN A  53 "
          pdb=" CD  PRO A  54 "
   model   vdw
   2.980 3.096
nonbonded pdb=" N   GLU A  30 "
          pdb=" CG  GLU A  30 "
   model   vdw
   2.982 2.816
nonbonded pdb=" N   LYS A  69 "
          pdb=" O   MSE A  77 "
   model   vdw
   2.983 3.120
nonbonded pdb=" C   ILE A  47 "
          pdb=" CG1 ILE A  47 "
   model   vdw
   2.984 2.936
nonbonded pdb=" O   LEU A  83 "
          pdb="O    HOH S  81 "
   model   vdw sym.op.
   2.986 3.040 x,y+1,z
nonbonded pdb=" N   LEU A  44 "
          pdb=" O   LEU A  44 "
   model   vdw
   2.986 2.496
nonbonded pdb=" N   LEU A  83 "
          pdb=" CG  LEU A  83 "
   model   vdw
   2.987 2.840
nonbonded pdb=" CB  MSE A  77 "
          pdb=" N   ILE A  78 "
   model   vdw
   2.988 2.816
nonbonded pdb=" C   LYS A   7 "
          pdb=" C   PRO A   8 "
   model   vdw
   2.988 2.800
nonbonded pdb=" CB  CYS A  33 "
          pdb=" N   TYR A  34 "
   model   vdw
   2.989 2.816
nonbonded pdb=" N   LYS A  46 "
          pdb=" O   GLY A  74 "
   model   vdw sym.op.
   2.989 3.120 -x+1,y,-z+2
nonbonded pdb=" N   VAL A   4 "
          pdb=" O   TYR A  61 "
   model   vdw
   2.990 3.120
nonbonded pdb=" O   ASN A  39 "
          pdb=" C   GLU A  40 "
   model   vdw
   2.990 3.270
nonbonded pdb=" N   ASP A  50 "
          pdb=" CG  ASP A  50 "
   model   vdw
   2.991 2.680
nonbonded pdb=" O   VAL A  70 "
          pdb=" CB  VAL A  70 "
   model   vdw
   2.992 2.776
nonbonded pdb=" O   SER A  66 "
          pdb=" NH1 ARG A  82 "
   model   vdw
   2.994 3.120
nonbonded pdb=" O   ILE A   6 "
          pdb="O    HOH S  51 "
   model   vdw
   2.994 3.040
nonbonded pdb=" N   LEU A  49 "
          pdb=" CG  LEU A  49 "
   model   vdw
   2.996 2.840
nonbonded pdb=" C   ARG A  80 "
          pdb=" C   LEU A  81 "
   model   vdw
   2.997 2.800
nonbonded pdb=" C   ALA A  57 "
          pdb=" C   PRO A  58 "
   model   vdw
   2.999 2.800
nonbonded pdb=" CA  LEU A  37 "
          pdb=" CD2 LEU A  37 "
   model   vdw
   3.001 3.112
nonbonded pdb=" C   VAL A   4 "
          pdb=" CG1 VAL A   4 "
   model   vdw
   3.002 2.952
nonbonded pdb=" C   PHE A  13 "
          pdb=" CG  PHE A  13 "
   model   vdw
   3.002 2.792
nonbonded pdb=" NE2 GLN A  31 "
          pdb=" O   TYR A  56 "
   model   vdw
   3.003 3.120
nonbonded pdb=" C   TYR A  41 "
          pdb=" C   PRO A  42 "
   model   vdw
   3.003 2.800
nonbonded pdb=" OH  TYR A  56 "
          pdb=" N   LEU A  83 "
   model   vdw
   3.004 3.120
nonbonded pdb=" N   TYR A  56 "
          pdb=" CG  TYR A  56 "
   model   vdw
   3.004 2.672
nonbonded pdb=" CB  TYR A  61 "
          pdb=" N   THR A  62 "
   model   vdw
   3.004 2.816
nonbonded pdb=" OG1 THR A  14 "
          pdb="O    HOH S   8 "
   model   vdw
   3.005 3.040
nonbonded pdb=" O   VAL A  70 "
          pdb=" O   GLY A  71 "
   model   vdw
   3.006 3.040
nonbonded pdb=" C   PRO A  54 "
          pdb=" C   ALA A  55 "
   model   vdw
   3.006 2.800
nonbonded pdb=" C   GLN A  53 "
          pdb=" O   PRO A  54 "
   model   vdw
   3.006 3.270
nonbonded pdb=" O   HIS A  64 "
          pdb=" N   SER A  67 "
   model   vdw
   3.007 3.120
nonbonded pdb=" N   ASP A  36 "
          pdb=" O   ASP A  36 "
   model   vdw
   3.008 2.496
nonbonded pdb=" N   GLN A  22 "
          pdb=" CG  GLN A  22 "
   model   vdw
   3.008 2.816
nonbonded pdb=" N   LEU A  81 "
          pdb=" O   LEU A  81 "
   model   vdw
   3.008 2.496
nonbonded pdb=" C   GLU A  51 "
          pdb=" CG  GLU A  51 "
   model   vdw
   3.010 2.936
nonbonded pdb=" O   ARG A  80 "
          pdb=" C   LEU A  81 "
   model   vdw
   3.011 3.270
nonbonded pdb=" O   THR A  15 "
          pdb=" CB  THR A  15 "
   model   vdw
   3.011 2.776
nonbonded pdb=" N   PHE A  73 "
          pdb=" CG  PHE A  73 "
   model   vdw
   3.011 2.672
nonbonded pdb=" N   ASN A  39 "
          pdb=" CG  ASN A  39 "
   model   vdw
   3.012 2.680
nonbonded pdb=" OD1 ASP A  50 "
          pdb=" NH2 ARG A  82 "
   model   vdw
   3.012 3.120
nonbonded pdb=" C   ASN A  39 "
          pdb=" C   GLU A  40 "
   model   vdw
   3.014 2.800
nonbonded pdb=" O   ARG A  82 "
          pdb=" CB  ARG A  82 "
   model   vdw
   3.014 2.752
nonbonded pdb=" N   ILE A  47 "
          pdb=" CG1 ILE A  47 "
   model   vdw
   3.016 2.816
nonbonded pdb=" O   TYR A  34 "
          pdb=" CB  TYR A  34 "
   model   vdw
   3.016 2.752
nonbonded pdb=" CB  LYS A  69 "
          pdb=" CE  LYS A  69 "
   model   vdw
   3.017 3.072
nonbonded pdb=" O   ILE A  78 "
          pdb=" CB  ILE A  78 "
   model   vdw
   3.017 2.776
nonbonded pdb=" C   ASP A  50 "
          pdb=" C   GLU A  51 "
   model   vdw
   3.019 2.800
nonbonded pdb=" CG1 VAL A  45 "
          pdb="O    HOH S  10 "
   model   vdw
   3.019 3.460
nonbonded pdb=" O   LEU A  44 "
          pdb=" CB  LEU A  44 "
   model   vdw
   3.020 2.752
nonbonded pdb=" CA  LYS A   7 "
          pdb=" CD  LYS A   7 "
   model   vdw
   3.022 3.096
nonbonded pdb=" O   THR A  48 "
          pdb=" C   LEU A  49 "
   model   vdw
   3.023 3.270
nonbonded pdb=" N   LYS A  69 "
          pdb=" CG  LYS A  69 "
   model   vdw
   3.025 2.816
nonbonded pdb=" N   THR A  14 "
          pdb=" O   GLU A  30 "
   model   vdw
   3.026 3.120
nonbonded pdb=" OG  SER A  20 "
          pdb=" N   ARG A  21 "
   model   vdw
   3.026 3.120
nonbonded pdb=" N   ASN A  29 "
          pdb=" OD1 ASN A  29 "
   model   vdw
   3.027 3.120
nonbonded pdb=" O   PRO A  54 "
          pdb=" C   ALA A  55 "
   model   vdw
   3.029 3.270
nonbonded pdb=" O   LEU A  28 "
          pdb=" CB  LEU A  28 "
   model   vdw
   3.031 2.752
nonbonded pdb=" C   THR A  48 "
          pdb=" C   LEU A  49 "
   model   vdw
   3.031 2.800
nonbonded pdb=" C   GLN A  53 "
          pdb=" C   PRO A  54 "
   model   vdw
   3.032 2.800
nonbonded pdb=" C   LEU A  65 "
          pdb=" N   SER A  67 "
   model   vdw
   3.033 3.350
nonbonded pdb=" OE1 GLN A  31 "
          pdb=" N   TYR A  56 "
   model   vdw
   3.035 3.120
nonbonded pdb=" N   ARG A  16 "
          pdb=" O   LEU A  28 "
   model   vdw
   3.035 3.120
nonbonded pdb=" CG2 ILE A   2 "
          pdb=" CD1 ILE A   2 "
   model   vdw
   3.037 3.104
nonbonded pdb=" CB  GLN A  12 "
          pdb=" N   PHE A  13 "
   model   vdw
   3.037 2.816
nonbonded pdb=" C   ASP A  36 "
          pdb=" OD1 ASP A  36 "
   model   vdw
   3.038 3.270
nonbonded pdb=" C   THR A  62 "
          pdb=" OG1 THR A  62 "
   model   vdw
   3.040 2.616
nonbonded pdb=" O   GLN A  72 "
          pdb=" CB  GLN A  72 "
   model   vdw
   3.043 2.752
nonbonded pdb=" CA  LEU A  81 "
          pdb=" CD1 LEU A  81 "
   model   vdw
   3.043 3.112
nonbonded pdb=" C   HIS A  64 "
          pdb=" C   LEU A  65 "
   model   vdw
   3.043 2.800
nonbonded pdb=" CB  LYS A  69 "
          pdb=" N   VAL A  70 "
   model   vdw
   3.044 2.816
nonbonded pdb=" N   TYR A  61 "
          pdb=" CG  TYR A  61 "
   model   vdw
   3.045 2.672
nonbonded pdb=" N   ARG A  16 "
          pdb=" CG  ARG A  16 "
   model   vdw
   3.047 2.816
nonbonded pdb=" O   ARG A  16 "
          pdb=" CG  ARG A  16 "
   model   vdw
   3.047 3.440
nonbonded pdb=" N   THR A  48 "
          pdb="O    HOH S 106 "
   model   vdw
   3.052 3.120
nonbonded pdb=" CA  LEU A  60 "
          pdb=" CD2 LEU A  60 "
   model   vdw
   3.056 3.112
nonbonded pdb=" C   VAL A  84 "
          pdb=" C   PRO A  85 "
   model   vdw
   3.058 2.800
nonbonded pdb=" O   LYS A   3 "
          pdb=" CB  LYS A   3 "
   model   vdw
   3.058 2.752
nonbonded pdb=" O   GLN A  53 "
          pdb=" CB  GLN A  53 "
   model   vdw
   3.059 2.752
nonbonded pdb=" O   SER A  67 "
          pdb=" CB  SER A  67 "
   model   vdw
   3.059 2.752
nonbonded pdb=" C   LYS A  69 "
          pdb=" CG  LYS A  69 "
   model   vdw
   3.059 2.936
nonbonded pdb=" O   ILE A   2 "
          pdb=" CB  ILE A   2 "
   model   vdw
   3.060 2.776
nonbonded pdb=" C   LYS A   7 "
          pdb=" N   SER A   9 "
   model   vdw
   3.060 3.350
nonbonded pdb=" O   LYS A  24 "
          pdb=" CB  LYS A  24 "
   model   vdw
   3.061 2.752
nonbonded pdb=" N   THR A  62 "
          pdb=" CG2 THR A  62 "
   model   vdw
   3.061 2.832
nonbonded pdb=" C   VAL A  70 "
          pdb=" O   GLY A  71 "
   model   vdw
   3.061 3.270
nonbonded pdb=" N   PHE A  13 "
          pdb=" CG  PHE A  13 "
   model   vdw
   3.062 2.672
nonbonded pdb=" CA  LEU A  65 "
          pdb=" CD1 LEU A  65 "
   model   vdw
   3.062 3.112
nonbonded pdb=" O   ASN A  29 "
          pdb=" CB  ASN A  29 "
   model   vdw
   3.063 2.752
nonbonded pdb=" O   ILE A   6 "
          pdb=" N   GLY A  59 "
   model   vdw
   3.064 3.120
nonbonded pdb=" N   ILE A  78 "
          pdb=" CG1 ILE A  78 "
   model   vdw
   3.065 2.816
nonbonded pdb=" C   LEU A  49 "
          pdb=" C   ASP A  50 "
   model   vdw
   3.065 2.800
nonbonded pdb=" CB  LYS A  46 "
          pdb=" CE  LYS A  46 "
   model   vdw
   3.066 3.072
nonbonded pdb=" N   GLU A  51 "
          pdb="O    HOH S 175 "
   model   vdw
   3.067 3.120
nonbonded pdb=" OG  SER A  17 "
          pdb=" O   TYR A  26 "
   model   vdw
   3.067 3.040
nonbonded pdb=" CB  SER A  17 "
          pdb=" N   GLY A  18 "
   model   vdw
   3.067 2.816
nonbonded pdb=" O   VAL A  84 "
          pdb=" CG1 VAL A  84 "
   model   vdw
   3.069 3.460
nonbonded pdb=" N   TYR A  41 "
          pdb=" CG  TYR A  41 "
   model   vdw
   3.069 2.672
nonbonded pdb=" N   SER A  17 "
          pdb="O    HOH S  34 "
   model   vdw
   3.069 3.120
nonbonded pdb=" N   LEU A  28 "
          pdb=" CG  LEU A  28 "
   model   vdw
   3.070 2.840
nonbonded pdb=" N   GLU A  51 "
          pdb=" CG  GLU A  51 "
   model   vdw
   3.071 2.816
nonbonded pdb=" CB  THR A  62 "
          pdb=" N   VAL A  63 "
   model   vdw
   3.073 2.840
nonbonded pdb=" N   VAL A  43 "
          pdb=" CG1 VAL A  43 "
   model   vdw
   3.073 2.832
nonbonded pdb=" O   LEU A  60 "
          pdb=" CB  LEU A  60 "
   model   vdw
   3.075 2.752
nonbonded pdb=" C   ILE A  78 "
          pdb=" C   ASP A  79 "
   model   vdw
   3.075 2.800
nonbonded pdb=" O   LEU A  65 "
          pdb=" N   SER A  67 "
   model   vdw
   3.076 3.120
nonbonded pdb=" CB  ASP A  50 "
          pdb=" N   GLU A  51 "
   model   vdw
   3.078 2.816
nonbonded pdb=" C   ARG A  16 "
          pdb=" CG  ARG A  16 "
   model   vdw
   3.079 2.936
nonbonded pdb=" N   LEU A  37 "
          pdb="O    HOH S   3 "
   model   vdw
   3.079 3.120
nonbonded pdb=" C   ILE A   6 "
          pdb=" C   LYS A   7 "
   model   vdw
   3.080 2.800
nonbonded pdb=" C   VAL A  70 "
          pdb=" CG1 VAL A  70 "
   model   vdw
   3.080 2.952
nonbonded pdb=" O   GLN A  10 "
          pdb="O    HOH S   7 "
   model   vdw
   3.081 3.040
nonbonded pdb=" N   PHE A  73 "
          pdb="O    HOH S   4 "
   model   vdw
   3.082 3.120
nonbonded pdb=" O   SER A  17 "
          pdb="O    HOH S  85 "
   model   vdw
   3.082 3.040
nonbonded pdb=" O   VAL A  70 "
          pdb=" C   GLY A  71 "
   model   vdw
   3.082 3.270
nonbonded pdb=" O   VAL A   4 "
          pdb=" O   TYR A  61 "
   model   vdw
   3.083 3.040
nonbonded pdb=" C   TYR A  26 "
          pdb=" CD1 TYR A  26 "
   model   vdw
   3.084 3.570
nonbonded pdb=" N   ASN A  39 "
          pdb="O    HOH S   3 "
   model   vdw
   3.088 3.120
nonbonded pdb=" C   TYR A  41 "
          pdb=" O   PRO A  42 "
   model   vdw
   3.091 3.270
nonbonded pdb=" C   TYR A  56 "
          pdb=" C   ALA A  57 "
   model   vdw
   3.091 2.800
nonbonded pdb=" O   GLY A  71 "
          pdb=" C   GLN A  72 "
   model   vdw
   3.091 3.270
nonbonded pdb=" C   HIS A  64 "
          pdb=" CG  HIS A  64 "
   model   vdw
   3.091 2.792
nonbonded pdb=" O   LYS A  46 "
          pdb=" CB  LYS A  46 "
   model   vdw
   3.093 2.752
nonbonded pdb=" O   GLN A  53 "
          pdb=" C   PRO A  54 "
   model   vdw
   3.093 3.270
nonbonded pdb=" O   PHE A  73 "
          pdb="O    HOH S  25 "
   model   vdw
   3.094 3.040
nonbonded pdb=" N   CYS A  33 "
          pdb=" O   VAL A  45 "
   model   vdw
   3.096 3.120
nonbonded pdb=" C   VAL A  70 "
          pdb=" C   GLY A  71 "
   model   vdw
   3.097 2.800
nonbonded pdb=" CB  PRO A  54 "
          pdb=" N   ALA A  55 "
   model   vdw
   3.098 2.816
nonbonded pdb=" O   THR A  14 "
          pdb=" OG1 THR A  14 "
   model   vdw
   3.100 3.040
nonbonded pdb=" O   ARG A  16 "
          pdb=" CB  ARG A  16 "
   model   vdw
   3.101 2.752
nonbonded pdb=" O   PRO A  25 "
          pdb=" CB  PRO A  25 "
   model   vdw
   3.103 2.752
nonbonded pdb=" NE2 GLN A  12 "
          pdb=" O   PRO A  58 "
   model   vdw sym.op.
   3.104 3.120 -x+1/2,y-1/2,-z+1
nonbonded pdb=" CB  LEU A  32 "
          pdb=" N   CYS A  33 "
   model   vdw
   3.104 2.816
nonbonded pdb=" C   GLY A  52 "
          pdb=" C   GLN A  53 "
   model   vdw
   3.105 2.800
nonbonded pdb=" O   SER A   9 "
          pdb="O    HOH S  34 "
   model   vdw sym.op.
   3.106 3.040 -x+1/2,y+1/2,-z+1
nonbonded pdb=" O   PRO A  85 "
          pdb=" CB  PRO A  85 "
   model   vdw
   3.106 2.752
nonbonded pdb=" C   TYR A  41 "
          pdb="O    HOH S 123 "
   model   vdw
   3.107 3.270
nonbonded pdb=" O   PRO A  58 "
          pdb=" CB  PRO A  58 "
   model   vdw
   3.107 2.752
nonbonded pdb=" CB  TYR A  26 "
          pdb=" N   SER A  27 "
   model   vdw
   3.107 2.816
nonbonded pdb=" C   GLY A  38 "
          pdb=" O   ASN A  39 "
   model   vdw
   3.107 3.270
nonbonded pdb=" O   LYS A   7 "
          pdb=" N   SER A   9 "
   model   vdw
   3.110 3.120
nonbonded pdb=" C   SER A  75 "
          pdb=" C   LEU A  76 "
   model   vdw
   3.112 2.800
nonbonded pdb=" NZ  LYS A  46 "
          pdb="O    HOH S  25 "
   model   vdw sym.op.
   3.113 3.120 -x+1,y,-z+2
nonbonded pdb=" O   GLU A  51 "
          pdb=" CG  GLU A  51 "
   model   vdw
   3.114 3.440
nonbonded pdb=" O   SER A  20 "
          pdb=" N   GLY A  23 "
   model   vdw
   3.115 3.120
nonbonded pdb=" O   ILE A   6 "
          pdb=" C   LYS A   7 "
   model   vdw
   3.116 3.270
nonbonded pdb=" O   ILE A  47 "
          pdb=" CG1 ILE A  47 "
   model   vdw
   3.118 3.440
nonbonded pdb=" C   GLY A  71 "
          pdb=" C   GLN A  72 "
   model   vdw
   3.118 2.800
nonbonded pdb=" C   SER A  66 "
          pdb=" C   SER A  67 "
   model   vdw
   3.119 2.800
nonbonded pdb=" O   LEU A  76 "
          pdb=" CB  LEU A  76 "
   model   vdw
   3.120 2.752
nonbonded pdb=" N   LEU A  37 "
          pdb=" CG  LEU A  37 "
   model   vdw
   3.122 2.840
nonbonded pdb=" O   VAL A  35 "
          pdb=" CB  VAL A  35 "
   model   vdw
   3.123 2.776
nonbonded pdb=" O   GLU A  30 "
          pdb=" CB  GLU A  30 "
   model   vdw
   3.125 2.752
nonbonded pdb=" OG  SER A  17 "
          pdb=" N   GLY A  18 "
   model   vdw
   3.125 3.120
nonbonded pdb=" C   LEU A  65 "
          pdb=" C   SER A  66 "
   model   vdw
   3.125 2.800
nonbonded pdb=" O   LEU A  65 "
          pdb=" C   SER A  66 "
   model   vdw
   3.125 3.270
nonbonded pdb=" O   LEU A  44 "
          pdb="O    HOH S  17 "
   model   vdw
   3.127 3.040
nonbonded pdb=" O   ARG A  80 "
          pdb=" CB  ARG A  80 "
   model   vdw
   3.128 2.752
nonbonded pdb=" CB  SER A  75 "
          pdb=" N   LEU A  76 "
   model   vdw
   3.129 2.816
nonbonded pdb=" O   ASP A  79 "
          pdb=" CG  ARG A  80 "
   model   vdw
   3.129 3.440
nonbonded pdb=" O   GLY A  23 "
          pdb=" C   LYS A  24 "
   model   vdw
   3.129 3.270
nonbonded pdb=" O   GLU A   5 "
          pdb=" CB  GLU A   5 "
   model   vdw
   3.129 2.752
nonbonded pdb=" O   LYS A  69 "
          pdb=" O   MSE A  77 "
   model   vdw
   3.131 3.040
nonbonded pdb=" O   VAL A  63 "
          pdb=" CB  VAL A  63 "
   model   vdw
   3.131 2.776
nonbonded pdb=" C   ARG A  21 "
          pdb=" N   GLY A  23 "
   model   vdw
   3.132 3.350
nonbonded pdb=" C   LYS A  24 "
          pdb=" CG  LYS A  24 "
   model   vdw
   3.133 2.936
nonbonded pdb=" O   SER A  27 "
          pdb=" CB  SER A  27 "
   model   vdw
   3.134 2.752
nonbonded pdb=" C   GLY A  23 "
          pdb=" C   LYS A  24 "
   model   vdw
   3.135 2.800
nonbonded pdb=" C   GLY A  71 "
          pdb=" N   PHE A  73 "
   model   vdw
   3.136 3.350
nonbonded pdb=" C   HIS A  64 "
          pdb=" N   SER A  66 "
   model   vdw
   3.136 3.350
nonbonded pdb=" C   CYS A  33 "
          pdb=" SG  CYS A  33 "
   model   vdw
   3.138 2.904
nonbonded pdb=" O   LEU A  76 "
          pdb="SE    SE Z   3 "
   model   vdw sym.op.
   3.138 3.420 -x+1/2,y+3/2,-z+1
nonbonded pdb=" CB  PHE A  68 "
          pdb=" N   LYS A  69 "
   model   vdw
   3.139 2.816
nonbonded pdb=" O   GLN A  72 "
          pdb=" CG  GLN A  72 "
   model   vdw
   3.139 3.440
nonbonded pdb=" O   GLN A  12 "
          pdb="O    HOH S   7 "
   model   vdw
   3.141 3.040
nonbonded pdb=" CG  HIS A  64 "
          pdb=" N   LEU A  65 "
   model   vdw
   3.142 3.340
nonbonded pdb=" C   GLN A  31 "
          pdb=" CG  GLN A  31 "
   model   vdw
   3.142 2.936
nonbonded pdb=" O   GLY A  52 "
          pdb=" C   GLN A  53 "
   model   vdw
   3.145 3.270
nonbonded pdb=" CD  GLU A  30 "
          pdb="O    HOH S   8 "
   model   vdw
   3.145 3.270
nonbonded pdb=" C   LEU A  44 "
          pdb=" CG  LEU A  44 "
   model   vdw
   3.146 2.960
nonbonded pdb=" C   LEU A  49 "
          pdb=" O   ASP A  50 "
   model   vdw
   3.147 3.270
nonbonded pdb=" CB  LYS A   7 "
          pdb=" N   PRO A   8 "
   model   vdw
   3.147 2.816
nonbonded pdb=" N   SER A  20 "
          pdb=" OG  SER A  20 "
   model   vdw
   3.148 2.496
nonbonded pdb=" C   LEU A  32 "
          pdb=" CB  CYS A  33 "
   model   vdw
   3.149 2.936
nonbonded pdb=" N   TYR A  34 "
          pdb=" CG  TYR A  34 "
   model   vdw
   3.150 2.672
nonbonded pdb=" O   PRO A  85 "
          pdb="O    HOH S  54 "
   model   vdw
   3.150 3.040
nonbonded pdb=" O   HIS A  64 "
          pdb=" N   SER A  66 "
   model   vdw
   3.152 3.120
nonbonded pdb=" C   PRO A  85 "
          pdb="O    HOH S  54 "
   model   vdw
   3.154 3.270
nonbonded pdb=" CG1 VAL A  45 "
          pdb=" N   LYS A  46 "
   model   vdw
   3.154 3.540
nonbonded pdb=" OG1 THR A  14 "
          pdb="O    HOH S 151 "
   model   vdw
   3.156 3.040
nonbonded pdb=" CB  GLU A  40 "
          pdb=" N   TYR A  41 "
   model   vdw
   3.156 2.816
nonbonded pdb=" C   ASP A  36 "
          pdb=" CG  ASP A  36 "
   model   vdw
   3.157 2.800
nonbonded pdb=" O   ILE A   2 "
          pdb=" OG1 THR A  62 "
   model   vdw
   3.157 3.040
nonbonded pdb=" CA  LEU A  49 "
          pdb=" CD2 LEU A  49 "
   model   vdw
   3.158 3.112
nonbonded pdb=" C   SER A  17 "
          pdb=" OG  SER A  17 "
   model   vdw
   3.158 2.616
nonbonded pdb=" CB  MSE A  77 "
          pdb="SE    SE Z   4 "
   model   vdw sym.op.
   3.159 3.820 x+1/2,y+3/2,z+2
nonbonded pdb=" O   SER A  66 "
          pdb=" C   SER A  67 "
   model   vdw
   3.161 3.270
nonbonded pdb=" OD1 ASP A  36 "
          pdb=" N   GLY A  38 "
   model   vdw
   3.162 3.120
nonbonded pdb=" CE2 PHE A  13 "
          pdb="O    HOH S  44 "
   model   vdw
   3.162 3.340
nonbonded pdb=" O   VAL A  19 "
          pdb=" CB  VAL A  19 "
   model   vdw
   3.162 2.776
nonbonded pdb=" O   SER A  75 "
          pdb=" C   LEU A  76 "
   model   vdw
   3.162 3.270
nonbonded pdb=" OE2 GLU A   5 "
          pdb=" CE  LYS A   7 "
   model   vdw
   3.163 3.440
nonbonded pdb=" CB  ALA A  57 "
          pdb=" N   PRO A  58 "
   model   vdw
   3.163 2.832
nonbonded pdb=" C   LYS A  24 "
          pdb=" C   PRO A  25 "
   model   vdw
   3.163 2.800
nonbonded pdb=" N   GLN A  12 "
          pdb=" CG  GLN A  12 "
   model   vdw
   3.164 2.816
nonbonded pdb=" C   LEU A  65 "
          pdb=" CG  LEU A  65 "
   model   vdw
   3.165 2.960
nonbonded pdb=" OG  SER A  20 "
          pdb=" N   LYS A  24 "
   model   vdw
   3.165 3.120
nonbonded pdb=" C   VAL A  84 "
          pdb=" O   PRO A  85 "
   model   vdw
   3.166 3.270
nonbonded pdb=" CD  GLN A  53 "
          pdb="O    HOH S  98 "
   model   vdw
   3.166 3.270
nonbonded pdb=" O   ILE A  78 "
          pdb=" C   ASP A  79 "
   model   vdw
   3.168 3.270
nonbonded pdb=" C   ALA A  55 "
          pdb=" O   TYR A  56 "
   model   vdw
   3.168 3.270
nonbonded pdb=" O   VAL A   4 "
          pdb=" CB  VAL A   4 "
   model   vdw
   3.169 2.776
nonbonded pdb=" O   VAL A  19 "
          pdb=" NE2 GLN A  53 "
   model   vdw sym.op.
   3.172 3.120 x,y-1,z
nonbonded pdb=" N   TYR A  26 "
          pdb=" CG  TYR A  26 "
   model   vdw
   3.173 2.672
nonbonded pdb=" C   ILE A   6 "
          pdb=" O   LYS A   7 "
   model   vdw
   3.173 3.270
nonbonded pdb=" O   LEU A  65 "
          pdb=" CB  LEU A  65 "
   model   vdw
   3.175 2.752
nonbonded pdb=" C   TYR A  56 "
          pdb=" O   ALA A  57 "
   model   vdw
   3.177 3.270
nonbonded pdb=" CB  HIS A  64 "
          pdb=" N   LEU A  65 "
   model   vdw
   3.178 2.816
nonbonded pdb=" CB  SER A  67 "
          pdb=" O   ARG A  80 "
   model   vdw
   3.178 3.440
nonbonded pdb=" O   ASP A  79 "
          pdb=" OD1 ASP A  79 "
   model   vdw
   3.178 3.040
nonbonded pdb=" CD  LYS A  24 "
          pdb=" NH2 ARG A  82 "
   model   vdw sym.op.
   3.178 3.520 -x+1/2,y-1/2,-z+2
nonbonded pdb=" NH2 ARG A  82 "
          pdb=" CD  LYS A  24 "
   model   vdw sym.op.
   3.178 3.520 -x+1/2,y+1/2,-z+2
nonbonded pdb=" CB  GLN A  22 "
          pdb="O    HOH S 175 "
   model   vdw sym.op.
   3.179 3.440 -x+1/2,y-1/2,-z+2
nonbonded pdb=" C   VAL A  19 "
          pdb=" C   SER A  20 "
   model   vdw
   3.180 2.800
nonbonded pdb=" O   TYR A  56 "
          pdb=" CB  TYR A  56 "
   model   vdw
   3.180 2.752
nonbonded pdb=" CB  LEU A  83 "
          pdb=" N   VAL A  84 "
   model   vdw
   3.181 2.816
nonbonded pdb=" C   GLN A  10 "
          pdb=" N   GLN A  12 "
   model   vdw
   3.181 3.350
nonbonded pdb=" CD  LYS A   7 "
          pdb=" OE1 GLU A  40 "
   model   vdw sym.op.
   3.182 3.440 -x+1,y,-z+1
nonbonded pdb=" O   GLU A  51 "
          pdb=" CB  GLU A  51 "
   model   vdw
   3.183 2.752
nonbonded pdb=" O   GLY A  71 "
          pdb=" N   PHE A  73 "
   model   vdw
   3.184 3.120
nonbonded pdb=" OE1 GLU A   5 "
          pdb=" CD2 LEU A  60 "
   model   vdw
   3.184 3.460
nonbonded pdb=" N   LEU A  60 "
          pdb=" CG  LEU A  60 "
   model   vdw
   3.184 2.840
nonbonded pdb=" O   ILE A   2 "
          pdb=" CG2 ILE A   2 "
   model   vdw
   3.185 3.460
nonbonded pdb=" C   SER A  66 "
          pdb=" N   PHE A  68 "
   model   vdw
   3.185 3.350
nonbonded pdb=" CB  TYR A  41 "
          pdb=" N   PRO A  42 "
   model   vdw
   3.185 2.816
nonbonded pdb=" O   ILE A   6 "
          pdb=" CA  PRO A  58 "
   model   vdw
   3.188 3.470
nonbonded pdb=" O   VAL A  43 "
          pdb=" CG1 VAL A  43 "
   model   vdw
   3.188 3.460
nonbonded pdb=" O   TYR A  41 "
          pdb=" O   PRO A  42 "
   model   vdw
   3.189 3.040
nonbonded pdb=" N   GLY A  18 "
          pdb=" O   TYR A  26 "
   model   vdw
   3.190 3.120
nonbonded pdb=" O   PHE A  13 "
          pdb=" CD1 PHE A  13 "
   model   vdw
   3.191 3.340
nonbonded pdb=" C   VAL A  35 "
          pdb=" C   ASP A  36 "
   model   vdw
   3.192 2.800
nonbonded pdb=" O   LEU A  32 "
          pdb=" CB  CYS A  33 "
   model   vdw
   3.193 3.440
nonbonded pdb=" O   GLN A  53 "
          pdb=" O   PRO A  54 "
   model   vdw
   3.194 3.040
nonbonded pdb=" C   GLN A  72 "
          pdb=" CG  GLN A  72 "
   model   vdw
   3.195 2.936
nonbonded pdb=" O   SER A  20 "
          pdb=" NE2 GLN A  53 "
   model   vdw sym.op.
   3.195 3.120 x,y-1,z
nonbonded pdb=" CB  HIS A  64 "
          pdb=" O   ARG A  82 "
   model   vdw
   3.196 3.440
nonbonded pdb=" C   PHE A  13 "
          pdb=" CD1 PHE A  13 "
   model   vdw
   3.196 3.570
nonbonded pdb=" CA  SER A  67 "
          pdb=" O   ARG A  80 "
   model   vdw
   3.197 3.470
nonbonded pdb=" CB  PHE A  13 "
          pdb=" N   THR A  14 "
   model   vdw
   3.199 2.816
nonbonded pdb=" N   LYS A   7 "
          pdb=" CG  LYS A   7 "
   model   vdw
   3.199 2.816
nonbonded pdb=" C   LEU A  76 "
          pdb=" CG  LEU A  76 "
   model   vdw
   3.200 2.960
nonbonded pdb=" C   GLY A  38 "
          pdb=" C   ASN A  39 "
   model   vdw
   3.200 2.800
nonbonded pdb=" O   ARG A  21 "
          pdb=" N   GLY A  23 "
   model   vdw
   3.201 3.120
nonbonded pdb=" CB  PRO A  42 "
          pdb=" N   VAL A  43 "
   model   vdw
   3.201 2.816
nonbonded pdb=" CB  THR A  14 "
          pdb=" N   THR A  15 "
   model   vdw
   3.202 2.840
nonbonded pdb=" O   PRO A  85 "
          pdb="O    HOH S   9 "
   model   vdw
   3.202 3.040
nonbonded pdb=" CA  LEU A  76 "
          pdb=" CD1 LEU A  76 "
   model   vdw
   3.202 3.112
nonbonded pdb=" O   LEU A  49 "
          pdb=" C   ASP A  50 "
   model   vdw
   3.205 3.270
nonbonded pdb=" CA  GLY A  71 "
          pdb="O    HOH S 103 "
   model   vdw sym.op.
   3.207 3.440 -x,y+1,-z+1
nonbonded pdb=" O   GLN A  10 "
          pdb=" N   GLN A  12 "
   model   vdw
   3.207 3.120
nonbonded pdb=" NE  ARG A  21 "
          pdb=" OE1 GLU A  51 "
   model   vdw sym.op.
   3.207 3.120 -x+1/2,y-1/2,-z+2
nonbonded pdb=" N   ARG A  80 "
          pdb=" CG  ARG A  80 "
   model   vdw
   3.207 2.816
nonbonded pdb=" C   ARG A  21 "
          pdb=" C   GLN A  22 "
   model   vdw
   3.208 2.800
nonbonded pdb=" C   PRO A   8 "
          pdb=" N   GLN A  10 "
   model   vdw
   3.209 3.350
nonbonded pdb=" O   TYR A  56 "
          pdb=" C   ALA A  57 "
   model   vdw
   3.209 3.270
nonbonded pdb=" C   PRO A  54 "
          pdb=" CG  PRO A  54 "
   model   vdw
   3.211 2.936
nonbonded pdb=" C   THR A  48 "
          pdb=" O   LEU A  49 "
   model   vdw
   3.211 3.270
nonbonded pdb=" O   PHE A  13 "
          pdb=" CG  PHE A  13 "
   model   vdw
   3.211 3.260
nonbonded pdb=" C   GLN A  10 "
          pdb=" C   ALA A  11 "
   model   vdw
   3.212 2.800
nonbonded pdb=" C   LEU A  37 "
          pdb=" C   GLY A  38 "
   model   vdw
   3.213 2.800
nonbonded pdb=" CA  ILE A   2 "
          pdb="O    HOH S   2 "
   model   vdw
   3.213 3.470
nonbonded pdb=" C   THR A  62 "
          pdb=" C   VAL A  63 "
   model   vdw
   3.214 2.800
nonbonded pdb=" O   VAL A  19 "
          pdb=" C   SER A  20 "
   model   vdw
   3.214 3.270
nonbonded pdb=" CB  LEU A  49 "
          pdb=" N   ASP A  50 "
   model   vdw
   3.215 2.816
nonbonded pdb=" O   ALA A  55 "
          pdb=" CB  ALA A  55 "
   model   vdw
   3.216 2.768
nonbonded pdb=" O   TYR A  41 "
          pdb=" CB  TYR A  41 "
   model   vdw
   3.218 2.752
nonbonded pdb=" C   VAL A  63 "
          pdb=" C   HIS A  64 "
   model   vdw
   3.218 2.800
nonbonded pdb=" CB  LYS A  24 "
          pdb=" N   PRO A  25 "
   model   vdw
   3.219 2.816
nonbonded pdb=" CG  GLU A   5 "
          pdb=" N   ILE A   6 "
   model   vdw
   3.219 3.520
nonbonded pdb=" CA  PHE A  73 "
          pdb=" CD1 PHE A  73 "
   model   vdw
   3.219 3.016
nonbonded pdb=" C   PRO A  54 "
          pdb=" O   ALA A  55 "
   model   vdw
   3.220 3.270
nonbonded pdb=" N   VAL A  45 "
          pdb=" CG2 VAL A  45 "
   model   vdw
   3.221 2.832
nonbonded pdb=" C   PRO A   8 "
          pdb=" C   SER A   9 "
   model   vdw
   3.222 2.800
nonbonded pdb=" O   LEU A  60 "
          pdb="O    HOH S  54 "
   model   vdw
   3.223 3.040
nonbonded pdb=" C   LYS A  69 "
          pdb=" C   VAL A  70 "
   model   vdw
   3.225 2.800
nonbonded pdb=" C   TYR A  26 "
          pdb=" CB  SER A  27 "
   model   vdw
   3.225 2.936
nonbonded pdb="SE    SE Z   3 "
          pdb=" CB  MSE A  77 "
   model   vdw sym.op.
   3.227 3.820 -x+1/2,y-3/2,-z+1
nonbonded pdb=" CB  MSE A  77 "
          pdb="SE    SE Z   3 "
   model   vdw sym.op.
   3.227 3.820 -x+1/2,y+3/2,-z+1
nonbonded pdb=" O   GLN A  10 "
          pdb=" C   ALA A  11 "
   model   vdw
   3.227 3.270
nonbonded pdb=" N   PHE A  68 "
          pdb=" CD2 PHE A  68 "
   model   vdw
   3.227 3.420
nonbonded pdb=" CA  LEU A  28 "
          pdb=" CD2 LEU A  28 "
   model   vdw
   3.227 3.112
nonbonded pdb=" CG2 VAL A  70 "
          pdb="O    HOH S  16 "
   model   vdw
   3.228 3.460
nonbonded pdb=" C   ILE A   2 "
          pdb=" CG2 ILE A   2 "
   model   vdw
   3.228 2.952
nonbonded pdb=" O   LEU A  49 "
          pdb=" CB  LEU A  49 "
   model   vdw
   3.228 2.752
nonbonded pdb=" NH2 ARG A  16 "
          pdb=" O   LEU A  60 "
   model   vdw sym.op.
   3.228 3.120 x,y-1,z
nonbonded pdb=" CA  TYR A  41 "
          pdb=" CD1 TYR A  41 "
   model   vdw
   3.229 3.016
nonbonded pdb=" N   ALA A  57 "
          pdb=" OH  TYR A  61 "
   model   vdw
   3.230 3.120
nonbonded pdb=" CD  ARG A  16 "
          pdb=" OE2 GLU A  30 "
   model   vdw
   3.231 3.440
nonbonded pdb=" O   ARG A  21 "
          pdb=" CB  ARG A  21 "
   model   vdw
   3.232 2.752
nonbonded pdb=" O   ILE A  47 "
          pdb=" CB  ILE A  47 "
   model   vdw
   3.233 2.776
nonbonded pdb=" CA  GLU A  40 "
          pdb=" OE1 GLU A  40 "
   model   vdw
   3.233 3.470
nonbonded pdb=" O   THR A  14 "
          pdb=" CB  THR A  14 "
   model   vdw
   3.235 2.776
nonbonded pdb=" CD  GLN A  53 "
          pdb="O    HOH S 135 "
   model   vdw
   3.236 3.270
nonbonded pdb=" N   LEU A  32 "
          pdb=" CG  LEU A  32 "
   model   vdw
   3.237 2.840
nonbonded pdb=" O   GLN A  31 "
          pdb=" CB  GLN A  31 "
   model   vdw
   3.238 2.752
nonbonded pdb=" O   TYR A  26 "
          pdb=" CD1 TYR A  26 "
   model   vdw
   3.239 3.340
nonbonded pdb=" O   SER A  75 "
          pdb=" OG  SER A  75 "
   model   vdw
   3.242 3.040
nonbonded pdb=" CG1 VAL A  19 "
          pdb=" N   SER A  20 "
   model   vdw
   3.244 3.540
nonbonded pdb=" C   VAL A  43 "
          pdb=" CG2 VAL A  43 "
   model   vdw
   3.244 2.952
nonbonded pdb=" C   GLU A  51 "
          pdb=" N   GLN A  53 "
   model   vdw
   3.245 3.350
nonbonded pdb=" CB  GLN A  31 "
          pdb=" N   LEU A  32 "
   model   vdw
   3.246 2.816
nonbonded pdb=" O   LEU A  37 "
          pdb=" C   GLY A  38 "
   model   vdw
   3.246 3.270
nonbonded pdb=" O   SER A  20 "
          pdb=" OG  SER A  20 "
   model   vdw
   3.247 3.040
nonbonded pdb=" O   HIS A  64 "
          pdb=" CB  SER A  67 "
   model   vdw
   3.247 3.440
nonbonded pdb=" O   PHE A  13 "
          pdb=" CB  PHE A  13 "
   model   vdw
   3.247 2.752
nonbonded pdb=" C   SER A  20 "
          pdb=" N   GLN A  22 "
   model   vdw
   3.247 3.350
nonbonded pdb=" O   LEU A  83 "
          pdb=" CB  LEU A  83 "
   model   vdw
   3.248 2.752
nonbonded pdb=" C   VAL A  19 "
          pdb=" O   SER A  20 "
   model   vdw
   3.249 3.270
nonbonded pdb=" OD2 ASP A  79 "
          pdb=" NH1 ARG A  82 "
   model   vdw
   3.249 3.120
nonbonded pdb=" C   PHE A  68 "
          pdb=" CB  LYS A  69 "
   model   vdw
   3.249 2.936
nonbonded pdb=" O   ILE A  78 "
          pdb=" O   ASP A  79 "
   model   vdw
   3.250 3.040
nonbonded pdb=" O   VAL A  84 "
          pdb=" CB  VAL A  84 "
   model   vdw
   3.251 2.776
nonbonded pdb=" CA  TYR A  61 "
          pdb=" O   VAL A  84 "
   model   vdw
   3.251 3.470
nonbonded pdb=" CA  TYR A  34 "
          pdb=" O   VAL A  43 "
   model   vdw
   3.251 3.470
nonbonded pdb=" C   VAL A  45 "
          pdb=" C   LYS A  46 "
   model   vdw
   3.251 2.800
nonbonded pdb=" N   TYR A  61 "
          pdb=" CD1 TYR A  61 "
   model   vdw
   3.251 3.420
nonbonded pdb=" CG2 ILE A   2 "
          pdb="O    HOH S  12 "
   model   vdw
   3.254 3.460
nonbonded pdb=" ND1 HIS A  64 "
          pdb=" N   SER A  66 "
   model   vdw
   3.256 3.200
nonbonded pdb=" O   SER A  20 "
          pdb=" O   ARG A  21 "
   model   vdw
   3.256 3.040
nonbonded pdb=" CB  PRO A   8 "
          pdb=" N   SER A   9 "
   model   vdw
   3.258 2.816
nonbonded pdb=" OE1 GLN A  53 "
          pdb="O    HOH S 135 "
   model   vdw
   3.258 3.040
nonbonded pdb=" CB  ALA A  55 "
          pdb=" N   TYR A  56 "
   model   vdw
   3.258 2.832
nonbonded pdb=" CG  LYS A   3 "
          pdb=" N   VAL A   4 "
   model   vdw
   3.259 3.520
nonbonded pdb=" CA  PHE A  13 "
          pdb=" O   GLU A  30 "
   model   vdw
   3.259 3.470
nonbonded pdb=" OH  TYR A  26 "
          pdb=" CG  PRO A  85 "
   model   vdw sym.op.
   3.259 3.440 x,y-1,z
nonbonded pdb=" CG  LYS A  46 "
          pdb=" N   ILE A  47 "
   model   vdw
   3.260 3.520
nonbonded pdb=" C   ARG A  21 "
          pdb=" CG  ARG A  21 "
   model   vdw
   3.264 2.936
nonbonded pdb=" O   PRO A   8 "
          pdb=" CB  PRO A   8 "
   model   vdw
   3.264 2.752
nonbonded pdb=" O   LEU A  65 "
          pdb=" CG  LEU A  65 "
   model   vdw
   3.265 3.470
nonbonded pdb=" O   HIS A  64 "
          pdb=" CB  HIS A  64 "
   model   vdw
   3.265 2.752
nonbonded pdb=" N   PRO A  42 "
          pdb="O    HOH S 123 "
   model   vdw
   3.265 3.120
nonbonded pdb=" O   THR A  14 "
          pdb="O    HOH S   8 "
   model   vdw
   3.266 3.040
nonbonded pdb=" C   VAL A  43 "
          pdb=" C   LEU A  44 "
   model   vdw
   3.266 2.800
nonbonded pdb=" CB  VAL A  43 "
          pdb=" N   LEU A  44 "
   model   vdw
   3.266 2.840
nonbonded pdb=" CA  ILE A   6 "
          pdb=" CD1 ILE A   6 "
   model   vdw
   3.269 3.112
nonbonded pdb=" CG1 VAL A  63 "
          pdb=" N   HIS A  64 "
   model   vdw
   3.270 3.540
nonbonded pdb=" CB  TYR A  56 "
          pdb=" N   ALA A  57 "
   model   vdw
   3.270 2.816
nonbonded pdb=" O   ALA A  57 "
          pdb=" CE1 TYR A  61 "
   model   vdw
   3.272 3.340
nonbonded pdb=" CB  ILE A  47 "
          pdb=" N   THR A  48 "
   model   vdw
   3.272 2.840
nonbonded pdb=" CB  TYR A  61 "
          pdb=" O   VAL A  84 "
   model   vdw
   3.272 3.440
nonbonded pdb=" OE1 GLU A  30 "
          pdb=" CE  LYS A  46 "
   model   vdw
   3.274 3.440
nonbonded pdb=" O   SER A  75 "
          pdb="O    HOH S   4 "
   model   vdw
   3.275 3.040
nonbonded pdb=" C   GLY A  74 "
          pdb=" C   SER A  75 "
   model   vdw
   3.275 2.800
nonbonded pdb=" CB  LYS A   3 "
          pdb=" CE  LYS A   3 "
   model   vdw
   3.276 3.072
nonbonded pdb=" CG  GLN A  31 "
          pdb=" N   LEU A  32 "
   model   vdw
   3.276 3.520
nonbonded pdb=" O   VAL A  45 "
          pdb=" CB  VAL A  45 "
   model   vdw
   3.276 2.776
nonbonded pdb=" CG1 VAL A   4 "
          pdb=" N   GLU A   5 "
   model   vdw
   3.277 3.540
nonbonded pdb=" CA  THR A  15 "
          pdb=" O   LEU A  28 "
   model   vdw
   3.278 3.470
nonbonded pdb=" O   TYR A  26 "
          pdb=" CB  TYR A  26 "
   model   vdw
   3.278 2.752
nonbonded pdb=" O   TYR A  26 "
          pdb=" CG  TYR A  26 "
   model   vdw
   3.280 3.260
nonbonded pdb=" CB  LYS A  46 "
          pdb=" N   ILE A  47 "
   model   vdw
   3.281 2.816
nonbonded pdb=" OG  SER A  67 "
          pdb=" O   ARG A  80 "
   model   vdw
   3.281 3.040
nonbonded pdb=" CB  ASN A  39 "
          pdb="O    HOH S   3 "
   model   vdw
   3.282 3.440
nonbonded pdb=" OE1 GLU A  30 "
          pdb=" NZ  LYS A  46 "
   model   vdw
   3.282 3.120
nonbonded pdb=" CA  LEU A  44 "
          pdb=" CD1 LEU A  44 "
   model   vdw
   3.283 3.112
nonbonded pdb=" O   LYS A  24 "
          pdb=" C   PRO A  25 "
   model   vdw
   3.283 3.270
nonbonded pdb=" O   LYS A   7 "
          pdb=" CB  LYS A   7 "
   model   vdw
   3.285 2.752
nonbonded pdb=" O   ARG A  21 "
          pdb=" C   GLN A  22 "
   model   vdw
   3.285 3.270
nonbonded pdb=" O   PHE A  68 "
          pdb=" CB  PHE A  68 "
   model   vdw
   3.286 2.752
nonbonded pdb=" O   PRO A  42 "
          pdb=" CB  PRO A  42 "
   model   vdw
   3.289 2.752
nonbonded pdb=" CA  TYR A  56 "
          pdb=" CD1 TYR A  56 "
   model   vdw
   3.290 3.016
nonbonded pdb="O    HOH S   3 "
          pdb="O    HOH S 123 "
   model   vdw
   3.290 3.040
nonbonded pdb=" CG  ARG A  82 "
          pdb=" CZ  ARG A  82 "
   model   vdw
   3.293 2.936
nonbonded pdb=" CB  PRO A   8 "
          pdb=" O   PHE A  13 "
   model   vdw sym.op.
   3.293 3.440 -x+1/2,y+1/2,-z+1
nonbonded pdb=" C   ASP A  79 "
          pdb=" CB  ARG A  80 "
   model   vdw
   3.293 2.936
nonbonded pdb=" OE2 GLU A  40 "
          pdb=" CB  SER A   9 "
   model   vdw sym.op.
   3.293 3.440 -x+1,y,-z+1
nonbonded pdb=" CB  SER A   9 "
          pdb=" OE2 GLU A  40 "
   model   vdw sym.op.
   3.293 3.440 -x+1,y,-z+1
nonbonded pdb=" C   ALA A  57 "
          pdb=" O   PRO A  58 "
   model   vdw
   3.294 3.270
nonbonded pdb=" CB  PRO A  25 "
          pdb=" N   TYR A  26 "
   model   vdw
   3.295 2.816
nonbonded pdb=" O   LYS A   3 "
          pdb=" CG  LYS A   3 "
   model   vdw
   3.296 3.440
nonbonded pdb=" O   ILE A   2 "
          pdb=" CG1 ILE A   2 "
   model   vdw
   3.297 3.440
nonbonded pdb=" C   ASP A  50 "
          pdb=" O   GLU A  51 "
   model   vdw
   3.297 3.270
nonbonded pdb=" CB  GLU A  51 "
          pdb=" N   GLY A  52 "
   model   vdw
   3.297 2.816
nonbonded pdb=" CG  LYS A  24 "
          pdb=" NH2 ARG A  82 "
   model   vdw sym.op.
   3.297 3.520 -x+1/2,y-1/2,-z+2
nonbonded pdb=" NH2 ARG A  82 "
          pdb=" CG  LYS A  24 "
   model   vdw sym.op.
   3.297 3.520 -x+1/2,y+1/2,-z+2
nonbonded pdb=" NE2 GLN A  10 "
          pdb=" CD1 LEU A  44 "
   model   vdw
   3.298 3.540
nonbonded pdb=" CD1 TYR A  56 "
          pdb="O    HOH S  98 "
   model   vdw
   3.299 3.340
nonbonded pdb=" NH2 ARG A  16 "
          pdb="O    HOH S  85 "
   model   vdw
   3.302 3.120
nonbonded pdb=" O   SER A  20 "
          pdb=" N   GLN A  22 "
   model   vdw
   3.303 3.120
nonbonded pdb=" CA  ILE A  47 "
          pdb="O    HOH S 106 "
   model   vdw
   3.303 3.470
nonbonded pdb=" CG1 VAL A  35 "
          pdb=" N   ASP A  36 "
   model   vdw
   3.304 3.540
nonbonded pdb=" CA  GLY A  71 "
          pdb="O    HOH S   4 "
   model   vdw
   3.305 3.440
nonbonded pdb=" O   THR A  48 "
          pdb=" CG2 THR A  48 "
   model   vdw
   3.306 3.460
nonbonded pdb=" CB  VAL A  45 "
          pdb=" N   LYS A  46 "
   model   vdw
   3.306 2.840
nonbonded pdb=" N   CYS A  33 "
          pdb=" SG  CYS A  33 "
   model   vdw
   3.307 2.784
nonbonded pdb=" O   GLU A  40 "
          pdb=" CB  GLU A  40 "
   model   vdw
   3.307 2.752
nonbonded pdb=" O   SER A  75 "
          pdb=" CB  SER A  75 "
   model   vdw
   3.307 2.752
nonbonded pdb=" O   PRO A   8 "
          pdb=" C   SER A   9 "
   model   vdw
   3.310 3.270
nonbonded pdb=" N   LEU A  81 "
          pdb=" N   ARG A  82 "
   model   vdw
   3.310 2.560
nonbonded pdb=" OD1 ASP A  36 "
          pdb=" N   LEU A  37 "
   model   vdw
   3.310 3.120
nonbonded pdb=" CB  GLU A  30 "
          pdb=" N   GLN A  31 "
   model   vdw
   3.310 2.816
nonbonded pdb=" C   LEU A  37 "
          pdb=" N   ASN A  39 "
   model   vdw
   3.311 3.350
nonbonded pdb=" C   GLN A  31 "
          pdb=" C   LEU A  32 "
   model   vdw
   3.311 2.800
nonbonded pdb=" OG  SER A  20 "
          pdb=" N   GLN A  22 "
   model   vdw
   3.312 3.120
nonbonded pdb=" O   GLY A  38 "
          pdb=" O   ASN A  39 "
   model   vdw
   3.313 3.040
nonbonded pdb=" C   ASN A  39 "
          pdb=" N   TYR A  41 "
   model   vdw
   3.313 3.350
nonbonded pdb=" O   SER A  27 "
          pdb=" OG  SER A  27 "
   model   vdw
   3.315 3.040
nonbonded pdb=" CD2 LEU A  32 "
          pdb="O    HOH S 151 "
   model   vdw
   3.316 3.460
nonbonded pdb=" O   ILE A  78 "
          pdb=" CG2 ILE A  78 "
   model   vdw
   3.316 3.460
nonbonded pdb=" N   ASP A  36 "
          pdb=" N   LEU A  37 "
   model   vdw
   3.316 2.560
nonbonded pdb=" O   CYS A  33 "
          pdb=" CD1 LEU A  44 "
   model   vdw
   3.316 3.460
nonbonded pdb=" C   GLU A   5 "
          pdb=" C   ILE A   6 "
   model   vdw
   3.317 2.800
nonbonded pdb=" CB  LEU A  65 "
          pdb=" N   SER A  66 "
   model   vdw
   3.318 2.816
nonbonded pdb=" O   GLU A  51 "
          pdb=" N   GLN A  53 "
   model   vdw
   3.320 3.120
nonbonded pdb=" O   LEU A  32 "
          pdb=" CB  LEU A  32 "
   model   vdw
   3.320 2.752
nonbonded pdb=" CE  LYS A  46 "
          pdb="O    HOH S  25 "
   model   vdw sym.op.
   3.321 3.440 -x+1,y,-z+2
nonbonded pdb=" OG  SER A  27 "
          pdb=" N   LEU A  28 "
   model   vdw
   3.321 3.120
nonbonded pdb=" C   GLU A  51 "
          pdb=" C   GLY A  52 "
   model   vdw
   3.321 2.800
nonbonded pdb=" O   THR A  62 "
          pdb=" C   VAL A  63 "
   model   vdw
   3.322 3.270
nonbonded pdb=" CG  GLU A  30 "
          pdb="O    HOH S   8 "
   model   vdw
   3.323 3.440
nonbonded pdb=" O   ARG A  80 "
          pdb=" CG  ARG A  82 "
   model   vdw
   3.323 3.440
nonbonded pdb=" O   VAL A  43 "
          pdb=" CB  VAL A  43 "
   model   vdw
   3.324 2.776
nonbonded pdb=" O   SER A   9 "
          pdb=" OG  SER A   9 "
   model   vdw
   3.324 3.040
nonbonded pdb=" CG1 VAL A  19 "
          pdb=" O   GLY A  23 "
   model   vdw
   3.324 3.460
nonbonded pdb=" CB  ARG A  80 "
          pdb=" N   LEU A  81 "
   model   vdw
   3.324 2.816
nonbonded pdb=" N   ASP A  79 "
          pdb=" O   ASP A  79 "
   model   vdw
   3.324 2.496
nonbonded pdb=" CB  GLU A   5 "
          pdb=" N   ILE A   6 "
   model   vdw
   3.325 2.816
nonbonded pdb=" O   ASP A  50 "
          pdb=" CB  ASP A  50 "
   model   vdw
   3.325 2.752
nonbonded pdb=" C   LEU A  28 "
          pdb=" C   ASN A  29 "
   model   vdw
   3.327 2.800
nonbonded pdb=" O   ALA A  57 "
          pdb=" CB  ALA A  57 "
   model   vdw
   3.327 2.768
nonbonded pdb=" C   ILE A  47 "
          pdb=" C   THR A  48 "
   model   vdw
   3.329 2.800
nonbonded pdb=" O   GLN A  31 "
          pdb=" CG1 ILE A  47 "
   model   vdw
   3.330 3.440
nonbonded pdb=" NE2 GLN A  10 "
          pdb=" CE2 TYR A  34 "
   model   vdw
   3.330 3.420
nonbonded pdb=" CB  LEU A  76 "
          pdb=" N   MSE A  77 "
   model   vdw
   3.331 2.816
nonbonded pdb=" CZ  TYR A  26 "
          pdb=" CG  PRO A  85 "
   model   vdw sym.op.
   3.332 3.660 x,y-1,z
nonbonded pdb=" C   LEU A  81 "
          pdb=" CG  LEU A  81 "
   model   vdw
   3.332 2.960
nonbonded pdb=" C   ARG A  82 "
          pdb=" C   LEU A  83 "
   model   vdw
   3.333 2.800
nonbonded pdb=" CA  TYR A  34 "
          pdb=" CD1 TYR A  34 "
   model   vdw
   3.333 3.016
nonbonded pdb=" CB  LEU A  28 "
          pdb=" N   ASN A  29 "
   model   vdw
   3.334 2.816
nonbonded pdb=" CB  SER A  20 "
          pdb=" O   LYS A  24 "
   model   vdw
   3.335 3.440
nonbonded pdb=" N   ILE A   6 "
          pdb=" N   LYS A   7 "
   model   vdw
   3.335 2.560
nonbonded pdb=" CA  HIS A  64 "
          pdb=" CD2 HIS A  64 "
   model   vdw
   3.335 2.952
nonbonded pdb=" OG  SER A  67 "
          pdb=" O   ARG A  82 "
   model   vdw
   3.337 3.040
nonbonded pdb=" O   ALA A  55 "
          pdb=" O   TYR A  56 "
   model   vdw
   3.338 3.040
nonbonded pdb=" C   THR A  15 "
          pdb=" C   ARG A  16 "
   model   vdw
   3.339 2.800
nonbonded pdb=" CA  PHE A  68 "
          pdb=" CD1 PHE A  68 "
   model   vdw
   3.339 3.016
nonbonded pdb=" C   PHE A  73 "
          pdb=" C   GLY A  74 "
   model   vdw
   3.340 2.800
nonbonded pdb=" N   THR A  48 "
          pdb=" N   LEU A  49 "
   model   vdw
   3.341 2.560
nonbonded pdb=" N   LEU A  32 "
          pdb=" CD2 LEU A  32 "
   model   vdw
   3.342 3.540
nonbonded pdb=" CD2 HIS A  64 "
          pdb="O    HOH S  35 "
   model   vdw
   3.342 3.260
nonbonded pdb=" CB  VAL A  19 "
          pdb=" N   SER A  20 "
   model   vdw
   3.342 2.840
nonbonded pdb=" CA  VAL A  19 "
          pdb=" O   LYS A  24 "
   model   vdw
   3.342 3.470
nonbonded pdb=" C   PHE A  73 "
          pdb=" N   SER A  75 "
   model   vdw
   3.344 3.350
nonbonded pdb=" O   GLY A  38 "
          pdb="O    HOH S 131 "
   model   vdw
   3.345 3.040
nonbonded pdb=" O   VAL A  19 "
          pdb=" O   SER A  20 "
   model   vdw
   3.346 3.040
nonbonded pdb="SE    SE Z   1 "
          pdb="SE    SE Z   3 "
   model   vdw sym.op.
   3.346 3.800 x-1/2,y+1/2,z
nonbonded pdb="SE    SE Z   3 "
          pdb="SE    SE Z   1 "
   model   vdw sym.op.
   3.346 3.800 x+1/2,y-1/2,z
nonbonded pdb=" O   THR A  48 "
          pdb=" O   LEU A  49 "
   model   vdw
   3.349 3.040
nonbonded pdb=" CA  TYR A  26 "
          pdb=" CD1 TYR A  26 "
   model   vdw
   3.349 3.016
nonbonded pdb=" CE1 TYR A  56 "
          pdb="O    HOH S  98 "
   model   vdw
   3.350 3.340
nonbonded pdb=" CA  PHE A  68 "
          pdb=" O   MSE A  77 "
   model   vdw
   3.354 3.470
nonbonded pdb=" CB  VAL A   4 "
          pdb=" N   GLU A   5 "
   model   vdw
   3.354 2.840
nonbonded pdb=" C   ILE A   2 "
          pdb=" C   LYS A   3 "
   model   vdw
   3.355 2.800
nonbonded pdb=" O   GLY A  18 "
          pdb=" O   TYR A  26 "
   model   vdw
   3.355 3.040
nonbonded pdb=" O   GLY A  71 "
          pdb=" N   GLY A  74 "
   model   vdw
   3.355 3.120
nonbonded pdb=" CB  SER A  17 "
          pdb="O    HOH S  34 "
   model   vdw
   3.356 3.440
nonbonded pdb=" O   ILE A   6 "
          pdb=" O   LYS A   7 "
   model   vdw
   3.356 3.040
nonbonded pdb=" O   VAL A  63 "
          pdb=" C   HIS A  64 "
   model   vdw
   3.358 3.270
nonbonded pdb=" O   VAL A  35 "
          pdb=" C   ASP A  36 "
   model   vdw
   3.358 3.270
nonbonded pdb=" CG2 VAL A  43 "
          pdb=" N   LEU A  44 "
   model   vdw
   3.358 3.540
nonbonded pdb=" CB  SER A  67 "
          pdb=" N   PHE A  68 "
   model   vdw
   3.359 2.816
nonbonded pdb=" N   PHE A  13 "
          pdb=" CD2 PHE A  13 "
   model   vdw
   3.359 3.420
nonbonded pdb=" C   MSE A  77 "
          pdb=" C   ILE A  78 "
   model   vdw
   3.359 2.800
nonbonded pdb=" CA  GLU A  40 "
          pdb=" CD  GLU A  40 "
   model   vdw
   3.361 2.960
nonbonded pdb=" CG1 VAL A  63 "
          pdb=" OG  SER A  67 "
   model   vdw
   3.361 3.460
nonbonded pdb=" CG  LYS A  24 "
          pdb=" N   PRO A  25 "
   model   vdw
   3.362 3.520
nonbonded pdb=" C   PRO A  42 "
          pdb=" CG  PRO A  42 "
   model   vdw
   3.362 2.936
nonbonded pdb=" O   TYR A  26 "
          pdb=" CB  SER A  27 "
   model   vdw
   3.363 3.440
nonbonded pdb=" C   PHE A  13 "
          pdb=" C   THR A  14 "
   model   vdw
   3.364 2.800
nonbonded pdb=" O   SER A  20 "
          pdb=" CB  SER A  20 "
   model   vdw
   3.365 2.752
nonbonded pdb=" O   VAL A  35 "
          pdb=" N   LEU A  37 "
   model   vdw
   3.366 3.120
nonbonded pdb=" C   VAL A  19 "
          pdb=" O   LYS A  24 "
   model   vdw
   3.367 3.270
nonbonded pdb=" CG2 THR A  15 "
          pdb=" N   ARG A  16 "
   model   vdw
   3.367 3.540
nonbonded pdb=" O   THR A  62 "
          pdb=" CG2 THR A  62 "
   model   vdw
   3.367 3.460
nonbonded pdb=" O   GLN A  12 "
          pdb=" CB  GLN A  12 "
   model   vdw
   3.369 2.752
nonbonded pdb=" O   SER A  17 "
          pdb=" CB  SER A  17 "
   model   vdw
   3.369 2.752
nonbonded pdb=" CA  TYR A  61 "
          pdb=" CD1 TYR A  61 "
   model   vdw
   3.369 3.016
nonbonded pdb=" O   CYS A  33 "
          pdb=" CA  LEU A  44 "
   model   vdw
   3.370 3.470
nonbonded pdb=" NH2 ARG A  16 "
          pdb=" CZ  TYR A  61 "
   model   vdw sym.op.
   3.370 3.340 x,y-1,z
nonbonded pdb=" CB  VAL A  84 "
          pdb=" N   PRO A  85 "
   model   vdw
   3.371 2.840
nonbonded pdb=" O   GLY A  38 "
          pdb=" C   ASN A  39 "
   model   vdw
   3.371 3.270
nonbonded pdb=" OD2 ASP A  79 "
          pdb="O    HOH S  97 "
   model   vdw sym.op.
   3.371 3.040 -x+1/2,y+1/2,-z+2
nonbonded pdb=" C   LEU A  76 "
          pdb=" CB  MSE A  77 "
   model   vdw
   3.372 2.936
nonbonded pdb=" CA  GLN A  22 "
          pdb=" OE1 GLN A  22 "
   model   vdw
   3.372 3.470
nonbonded pdb=" C   ASP A  36 "
          pdb=" N   GLY A  38 "
   model   vdw
   3.373 3.350
nonbonded pdb=" NZ  LYS A  24 "
          pdb=" OD2 ASP A  50 "
   model   vdw sym.op.
   3.374 3.120 -x+1/2,y-1/2,-z+2
nonbonded pdb=" OD2 ASP A  50 "
          pdb=" NZ  LYS A  24 "
   model   vdw sym.op.
   3.374 3.120 -x+1/2,y+1/2,-z+2
nonbonded pdb=" O   SER A  66 "
          pdb=" OG  SER A  66 "
   model   vdw
   3.374 3.040
nonbonded pdb=" O   THR A  15 "
          pdb=" CG2 THR A  15 "
   model   vdw
   3.374 3.460
nonbonded pdb=" CA  PHE A  13 "
          pdb=" CD1 PHE A  13 "
   model   vdw
   3.376 3.016
nonbonded pdb=" N   VAL A  70 "
          pdb=" N   GLY A  71 "
   model   vdw
   3.376 2.560
nonbonded pdb=" OD2 ASP A  79 "
          pdb=" NH2 ARG A  82 "
   model   vdw
   3.377 3.120
nonbonded pdb=" CB  LEU A  60 "
          pdb=" N   TYR A  61 "
   model   vdw
   3.377 2.816
nonbonded pdb=" O   PRO A  54 "
          pdb=" CB  PRO A  54 "
   model   vdw
   3.378 2.752
nonbonded pdb=" CB  LYS A   3 "
          pdb=" N   VAL A   4 "
   model   vdw
   3.378 2.816
nonbonded pdb=" OG  SER A  20 "
          pdb=" O   LYS A  24 "
   model   vdw
   3.378 3.040
nonbonded pdb=" CG  ARG A  21 "
          pdb=" CZ  ARG A  21 "
   model   vdw
   3.379 2.936
nonbonded pdb=" N   LYS A  24 "
          pdb="O    HOH S  97 "
   model   vdw
   3.380 3.120
nonbonded pdb=" O   THR A  62 "
          pdb=" O   VAL A  84 "
   model   vdw
   3.380 3.040
nonbonded pdb=" CA  VAL A   4 "
          pdb=" O   TYR A  34 "
   model   vdw
   3.380 3.470
nonbonded pdb=" C   TYR A  34 "
          pdb=" C   VAL A  35 "
   model   vdw
   3.381 2.800
nonbonded pdb=" C   LEU A  81 "
          pdb=" C   ARG A  82 "
   model   vdw
   3.381 2.800
nonbonded pdb=" N   ASP A  50 "
          pdb=" OD1 ASP A  50 "
   model   vdw
   3.382 3.120
nonbonded pdb=" O   PHE A  68 "
          pdb=" CB  LYS A  69 "
   model   vdw
   3.383 3.440
nonbonded pdb=" CA  GLU A   5 "
          pdb=" O   GLY A  59 "
   model   vdw
   3.384 3.470
nonbonded pdb=" CG1 VAL A  84 "
          pdb=" N   PRO A  85 "
   model   vdw
   3.385 3.540
nonbonded pdb=" C   LEU A  28 "
          pdb=" OD1 ASN A  29 "
   model   vdw
   3.385 3.270
nonbonded pdb=" C   GLU A  30 "
          pdb=" CB  GLN A  31 "
   model   vdw
   3.385 2.936
nonbonded pdb=" CB  VAL A  35 "
          pdb=" N   ASP A  36 "
   model   vdw
   3.386 2.840
nonbonded pdb=" CB  VAL A  63 "
          pdb=" N   HIS A  64 "
   model   vdw
   3.386 2.840
nonbonded pdb=" C   PRO A  42 "
          pdb=" C   VAL A  43 "
   model   vdw
   3.389 2.800
nonbonded pdb=" O   TYR A  61 "
          pdb=" CB  TYR A  61 "
   model   vdw
   3.389 2.752
nonbonded pdb=" O   LEU A  65 "
          pdb=" N   PHE A  68 "
   model   vdw
   3.389 3.120
nonbonded pdb=" N   ILE A  78 "
          pdb=" N   ASP A  79 "
   model   vdw
   3.390 2.560
nonbonded pdb=" O   SER A  66 "
          pdb=" N   PHE A  68 "
   model   vdw
   3.390 3.120
nonbonded pdb=" CG2 VAL A  84 "
          pdb="O    HOH S 120 "
   model   vdw sym.op.
   3.390 3.460 x,y+1,z
nonbonded pdb=" CA  PHE A  68 "
          pdb=" CD2 PHE A  68 "
   model   vdw
   3.391 3.016
nonbonded pdb=" CG  ASP A  79 "
          pdb=" N   ARG A  80 "
   model   vdw
   3.391 3.350
nonbonded pdb=" CD2 TYR A  61 "
          pdb=" O   VAL A  84 "
   model   vdw
   3.391 3.340
nonbonded pdb=" C   ASP A  36 "
          pdb=" C   LEU A  37 "
   model   vdw
   3.391 2.800
nonbonded pdb=" C   GLY A  59 "
          pdb=" C   LEU A  60 "
   model   vdw
   3.392 2.800
nonbonded pdb=" OE1 GLN A  10 "
          pdb=" CA  CYS A  33 "
   model   vdw
   3.395 3.470
nonbonded pdb=" CA  GLN A  10 "
          pdb="O    HOH S   7 "
   model   vdw
   3.396 3.470
nonbonded pdb=" C   GLY A  71 "
          pdb="O    HOH S   4 "
   model   vdw
   3.396 3.270
nonbonded pdb=" CB  GLN A  53 "
          pdb=" N   PRO A  54 "
   model   vdw
   3.396 2.816
nonbonded pdb=" CA  LEU A  32 "
          pdb=" CD2 LEU A  32 "
   model   vdw
   3.397 3.112
nonbonded pdb=" CG  GLN A  22 "
          pdb="O    HOH S 175 "
   model   vdw sym.op.
   3.397 3.440 -x+1/2,y-1/2,-z+2
nonbonded pdb=" C   GLY A  18 "
          pdb=" CE2 TYR A  26 "
   model   vdw
   3.400 3.570
nonbonded pdb=" OG  SER A  66 "
          pdb=" CD  ARG A  82 "
   model   vdw
   3.400 3.440
nonbonded pdb=" CB  PRO A  58 "
          pdb=" N   GLY A  59 "
   model   vdw
   3.401 2.816
nonbonded pdb=" O   PRO A   8 "
          pdb=" N   GLN A  10 "
   model   vdw
   3.402 3.120
nonbonded pdb=" CB  LEU A  44 "
          pdb=" N   VAL A  45 "
   model   vdw
   3.403 2.816
nonbonded pdb=" CA  VAL A  45 "
          pdb=" O   GLY A  74 "
   model   vdw sym.op.
   3.406 3.470 -x+1,y,-z+2
nonbonded pdb=" N   ARG A  82 "
          pdb=" N   LEU A  83 "
   model   vdw
   3.406 2.560
nonbonded pdb=" O   LYS A  69 "
          pdb=" CB  LYS A  69 "
   model   vdw
   3.407 2.752
nonbonded pdb=" OD1 ASN A  39 "
          pdb="O    HOH S   3 "
   model   vdw
   3.407 3.040
nonbonded pdb=" CA  GLU A  30 "
          pdb=" O   ILE A  47 "
   model   vdw
   3.407 3.470
nonbonded pdb=" C   SER A  67 "
          pdb=" C   PHE A  68 "
   model   vdw
   3.408 2.800
nonbonded pdb=" C   LEU A  83 "
          pdb=" CB  VAL A  84 "
   model   vdw
   3.410 2.960
nonbonded pdb=" O   ALA A  57 "
          pdb=" N   GLY A  59 "
   model   vdw
   3.411 3.120
nonbonded pdb=" CE1 TYR A  34 "
          pdb=" CE2 TYR A  41 "
   model   vdw sym.op.
   3.411 3.640 -x+1,y,-z+1
nonbonded pdb=" CE2 TYR A  41 "
          pdb=" CE1 TYR A  34 "
   model   vdw sym.op.
   3.411 3.640 -x+1,y,-z+1
nonbonded pdb=" O   THR A  14 "
          pdb=" CA  ASN A  29 "
   model   vdw
   3.411 3.470
nonbonded pdb=" O   GLN A  31 "
          pdb=" O   ILE A  47 "
   model   vdw
   3.412 3.040
nonbonded pdb=" CB  ARG A  16 "
          pdb=" N   SER A  17 "
   model   vdw
   3.412 2.816
nonbonded pdb=" C   PRO A  25 "
          pdb=" CB  TYR A  26 "
   model   vdw
   3.413 2.936
nonbonded pdb=" C   THR A  14 "
          pdb=" C   THR A  15 "
   model   vdw
   3.415 2.800
nonbonded pdb=" CA  PHE A  13 "
          pdb=" CD2 PHE A  13 "
   model   vdw
   3.417 3.016
nonbonded pdb=" C   TYR A  61 "
          pdb=" CB  THR A  62 "
   model   vdw
   3.417 2.960
nonbonded pdb=" N   SER A  75 "
          pdb="O    HOH S   4 "
   model   vdw
   3.418 3.120
nonbonded pdb=" O   VAL A  43 "
          pdb=" C   LEU A  44 "
   model   vdw
   3.419 3.270
nonbonded pdb=" O   THR A  62 "
          pdb=" CB  THR A  62 "
   model   vdw
   3.420 2.776
nonbonded pdb=" O   ASP A  50 "
          pdb=" O   GLU A  51 "
   model   vdw
   3.421 3.040
nonbonded pdb=" CZ  TYR A  41 "
          pdb=" CG  PRO A  42 "
   model   vdw sym.op.
   3.421 3.660 -x+1,y,-z+1
nonbonded pdb=" CB  GLN A  72 "
          pdb=" N   PHE A  73 "
   model   vdw
   3.422 2.816
nonbonded pdb=" C   LEU A  44 "
          pdb=" CB  VAL A  45 "
   model   vdw
   3.423 2.960
nonbonded pdb=" O   ALA A  57 "
          pdb=" O   PRO A  58 "
   model   vdw
   3.424 3.040
nonbonded pdb=" C   PRO A  54 "
          pdb=" CD  PRO A  54 "
   model   vdw
   3.425 2.936
nonbonded pdb=" N   GLN A  53 "
          pdb=" CG  GLN A  53 "
   model   vdw
   3.427 2.816
nonbonded pdb=" ND1 HIS A  64 "
          pdb=" N   LEU A  65 "
   model   vdw
   3.428 3.200
nonbonded pdb=" N   TYR A  34 "
          pdb=" N   VAL A  35 "
   model   vdw
   3.431 2.560
nonbonded pdb=" N   LEU A  83 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   3.432 3.540
nonbonded pdb=" C   LEU A  60 "
          pdb=" CB  TYR A  61 "
   model   vdw
   3.433 2.936
nonbonded pdb=" C   SER A  27 "
          pdb=" CB  LEU A  28 "
   model   vdw
   3.434 2.936
nonbonded pdb=" CA  GLN A  22 "
          pdb=" CD  GLN A  22 "
   model   vdw
   3.434 2.960
nonbonded pdb=" O   PRO A  54 "
          pdb=" O   ALA A  55 "
   model   vdw
   3.434 3.040
nonbonded pdb=" C   ARG A  16 "
          pdb=" C   SER A  17 "
   model   vdw
   3.435 2.800
nonbonded pdb=" O   TYR A  41 "
          pdb="O    HOH S 123 "
   model   vdw
   3.435 3.040
nonbonded pdb=" CB  SER A  27 "
          pdb=" N   LEU A  28 "
   model   vdw
   3.435 2.816
nonbonded pdb=" CA  SER A   9 "
          pdb=" O   THR A  15 "
   model   vdw sym.op.
   3.436 3.470 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CA  TYR A  34 "
          pdb=" CD2 TYR A  34 "
   model   vdw
   3.437 3.016
nonbonded pdb=" O   CYS A  33 "
          pdb=" CB  CYS A  33 "
   model   vdw
   3.437 2.752
nonbonded pdb=" O   ASP A  50 "
          pdb=" N   GLN A  53 "
   model   vdw
   3.437 3.120
nonbonded pdb=" O   ALA A  57 "
          pdb=" CZ  TYR A  61 "
   model   vdw
   3.438 3.260
nonbonded pdb=" O   VAL A  35 "
          pdb=" CA  PRO A  42 "
   model   vdw
   3.438 3.470
nonbonded pdb=" N   ARG A  21 "
          pdb=" O   ARG A  21 "
   model   vdw
   3.440 2.496
nonbonded pdb=" O   LYS A  69 "
          pdb=" CD1 LEU A  76 "
   model   vdw
   3.440 3.460
nonbonded pdb=" CB  THR A  15 "
          pdb=" N   ARG A  16 "
   model   vdw
   3.440 2.840
nonbonded pdb=" N   THR A  15 "
          pdb=" N   ARG A  16 "
   model   vdw
   3.440 2.560
nonbonded pdb=" C   GLY A  18 "
          pdb=" CG2 VAL A  19 "
   model   vdw
   3.441 3.690
nonbonded pdb=" CD1 ILE A   6 "
          pdb=" O   LEU A  32 "
   model   vdw
   3.442 3.460
nonbonded pdb=" O   ASN A  39 "
          pdb=" O   GLU A  40 "
   model   vdw
   3.442 3.040
nonbonded pdb=" O   VAL A  45 "
          pdb=" CG1 VAL A  45 "
   model   vdw
   3.443 3.460
nonbonded pdb=" CG1 ILE A   2 "
          pdb=" N   LYS A   3 "
   model   vdw
   3.443 3.520
nonbonded pdb=" O   MSE A  77 "
          pdb=" CB  MSE A  77 "
   model   vdw
   3.443 2.752
nonbonded pdb=" CE2 TYR A  41 "
          pdb=" CD1 TYR A  34 "
   model   vdw sym.op.
   3.443 3.640 -x+1,y,-z+1
nonbonded pdb=" CD1 TYR A  34 "
          pdb=" CE2 TYR A  41 "
   model   vdw sym.op.
   3.443 3.640 -x+1,y,-z+1
nonbonded pdb=" CG2 THR A  15 "
          pdb=" OG  SER A  27 "
   model   vdw
   3.444 3.460
nonbonded pdb=" O   ASP A  79 "
          pdb=" CB  ARG A  80 "
   model   vdw
   3.444 3.440
nonbonded pdb=" OE1 GLU A  30 "
          pdb=" CD  LYS A  46 "
   model   vdw
   3.444 3.440
nonbonded pdb=" C   VAL A   4 "
          pdb=" CB  GLU A   5 "
   model   vdw
   3.445 2.936
nonbonded pdb=" CA  ASP A  50 "
          pdb="O    HOH S 175 "
   model   vdw
   3.445 3.470
nonbonded pdb=" CD  GLU A   5 "
          pdb=" CE  LYS A   7 "
   model   vdw
   3.445 3.670
nonbonded pdb=" CB  ASN A  29 "
          pdb=" N   GLU A  30 "
   model   vdw
   3.445 2.816
nonbonded pdb=" OG  SER A   9 "
          pdb=" N   GLN A  10 "
   model   vdw
   3.445 3.120
nonbonded pdb=" N   TYR A  56 "
          pdb=" CD2 TYR A  56 "
   model   vdw
   3.445 3.420
nonbonded pdb=" O   ILE A   6 "
          pdb=" CG2 ILE A   6 "
   model   vdw
   3.445 3.460
nonbonded pdb=" CB  PHE A  13 "
          pdb=" O   GLU A  30 "
   model   vdw
   3.446 3.440
nonbonded pdb=" C   GLN A  72 "
          pdb=" C   PHE A  73 "
   model   vdw
   3.447 2.800
nonbonded pdb=" CG1 VAL A  45 "
          pdb=" O   LYS A  46 "
   model   vdw
   3.449 3.460
nonbonded pdb=" CA  TYR A  61 "
          pdb=" CD2 TYR A  61 "
   model   vdw
   3.449 3.016
nonbonded pdb=" C   ALA A  11 "
          pdb=" C   GLN A  12 "
   model   vdw
   3.449 2.800
nonbonded pdb=" CB  TYR A  34 "
          pdb=" N   VAL A  35 "
   model   vdw
   3.449 2.816
nonbonded pdb=" N   ILE A   2 "
          pdb=" N   LYS A   3 "
   model   vdw
   3.450 2.560
nonbonded pdb=" OE1 GLN A  31 "
          pdb=" CD2 TYR A  56 "
   model   vdw
   3.450 3.340
nonbonded pdb=" C   PRO A  85 "
          pdb="O    HOH S   9 "
   model   vdw
   3.451 3.270
nonbonded pdb=" C   CYS A  33 "
          pdb=" C   TYR A  34 "
   model   vdw
   3.451 2.800
nonbonded pdb=" N   ASN A  29 "
          pdb=" N   GLU A  30 "
   model   vdw
   3.452 2.560
nonbonded pdb=" C   ASP A  79 "
          pdb=" CG  ARG A  80 "
   model   vdw
   3.453 3.670
nonbonded pdb=" CB  ILE A  47 "
          pdb="O    HOH S 106 "
   model   vdw
   3.454 3.470
nonbonded pdb=" NZ  LYS A  24 "
          pdb=" CG  ARG A  21 "
   model   vdw sym.op.
   3.455 3.520 -x+1/2,y+1/2,-z+2
nonbonded pdb=" CG  ARG A  21 "
          pdb=" NZ  LYS A  24 "
   model   vdw sym.op.
   3.455 3.520 -x+1/2,y-1/2,-z+2
nonbonded pdb=" N   ARG A  16 "
          pdb=" N   SER A  17 "
   model   vdw
   3.456 2.560
nonbonded pdb=" O   VAL A  35 "
          pdb=" CG1 VAL A  43 "
   model   vdw
   3.456 3.460
nonbonded pdb=" OG  SER A  20 "
          pdb=" CB  LYS A  24 "
   model   vdw
   3.456 3.440
nonbonded pdb=" O   VAL A  19 "
          pdb="O    HOH S  81 "
   model   vdw
   3.456 3.040
nonbonded pdb=" C   ASN A  39 "
          pdb="O    HOH S 123 "
   model   vdw
   3.457 3.270
nonbonded pdb=" CG1 VAL A  19 "
          pdb=" O   LYS A  24 "
   model   vdw
   3.458 3.460
nonbonded pdb=" C   GLY A  18 "
          pdb=" CB  VAL A  19 "
   model   vdw
   3.458 2.960
nonbonded pdb=" C   GLU A  40 "
          pdb=" CB  TYR A  41 "
   model   vdw
   3.458 2.936
nonbonded pdb=" C   PRO A  25 "
          pdb=" CD  PRO A  25 "
   model   vdw
   3.458 2.936
nonbonded pdb=" C   ARG A  80 "
          pdb=" N   ARG A  82 "
   model   vdw
   3.459 3.350
nonbonded pdb=" CG2 ILE A  78 "
          pdb=" N   ASP A  79 "
   model   vdw
   3.459 3.540
nonbonded pdb=" ND1 HIS A  64 "
          pdb=" CB  SER A  66 "
   model   vdw
   3.459 3.520
nonbonded pdb=" O   LYS A  69 "
          pdb=" C   VAL A  70 "
   model   vdw
   3.459 3.270
nonbonded pdb=" C   VAL A  63 "
          pdb=" O   HIS A  64 "
   model   vdw
   3.460 3.270
nonbonded pdb=" C   LYS A  46 "
          pdb=" CB  ILE A  47 "
   model   vdw
   3.460 2.960
nonbonded pdb=" C   GLY A  23 "
          pdb=" O   LYS A  24 "
   model   vdw
   3.461 3.270
nonbonded pdb=" O   GLY A  74 "
          pdb=" C   SER A  75 "
   model   vdw
   3.462 3.270
nonbonded pdb=" OG  SER A  66 "
          pdb=" CD  ARG A  21 "
   model   vdw sym.op.
   3.462 3.440 x,y+1,z
nonbonded pdb=" CD  ARG A  21 "
          pdb=" OG  SER A  66 "
   model   vdw sym.op.
   3.462 3.440 x,y-1,z
nonbonded pdb=" C   LYS A   3 "
          pdb=" C   VAL A   4 "
   model   vdw
   3.462 2.800
nonbonded pdb=" OD2 ASP A  36 "
          pdb=" NE2 GLN A  72 "
   model   vdw sym.op.
   3.463 3.120 -x+1,y+1,-z+2
nonbonded pdb=" CB  PRO A  54 "
          pdb="O    HOH S  44 "
   model   vdw
   3.466 3.440
nonbonded pdb=" N   VAL A  84 "
          pdb=" CG1 VAL A  84 "
   model   vdw
   3.466 2.832
nonbonded pdb=" N   SER A  27 "
          pdb=" N   LEU A  28 "
   model   vdw
   3.467 2.560
nonbonded pdb=" O   LEU A  37 "
          pdb=" N   ASN A  39 "
   model   vdw
   3.467 3.120
nonbonded pdb=" NH2 ARG A  21 "
          pdb=" OE2 GLU A  51 "
   model   vdw sym.op.
   3.467 3.120 -x+1/2,y-1/2,-z+2
nonbonded pdb=" CB  SER A   9 "
          pdb="O    HOH S  34 "
   model   vdw sym.op.
   3.467 3.440 -x+1/2,y+1/2,-z+1
nonbonded pdb=" C   LYS A  24 "
          pdb=" O   PRO A  25 "
   model   vdw
   3.468 3.270
nonbonded pdb=" O   LEU A  49 "
          pdb=" O   ASP A  50 "
   model   vdw
   3.469 3.040
nonbonded pdb=" C   SER A   9 "
          pdb=" C   GLN A  10 "
   model   vdw
   3.469 2.800
nonbonded pdb=" O   GLY A  18 "
          pdb=" CA  PRO A  25 "
   model   vdw
   3.469 3.470
nonbonded pdb=" C   LYS A  46 "
          pdb=" C   ILE A  47 "
   model   vdw
   3.470 2.800
nonbonded pdb=" O   VAL A  35 "
          pdb=" CB  PRO A  42 "
   model   vdw
   3.470 3.440
nonbonded pdb=" OG  SER A  75 "
          pdb="SE    SE Z   3 "
   model   vdw sym.op.
   3.470 3.420 -x+1/2,y+3/2,-z+1
nonbonded pdb=" CA  TYR A  41 "
          pdb="O    HOH S 123 "
   model   vdw
   3.470 3.470
nonbonded pdb=" CA  SER A  20 "
          pdb=" O   LYS A  24 "
   model   vdw
   3.471 3.470
nonbonded pdb=" C   ILE A   2 "
          pdb="O    HOH S   2 "
   model   vdw
   3.472 3.270
nonbonded pdb=" CA  HIS A  64 "
          pdb="O    HOH S  35 "
   model   vdw
   3.472 3.470
nonbonded pdb=" C   LYS A  46 "
          pdb=" CG2 ILE A  47 "
   model   vdw
   3.472 3.690
nonbonded pdb=" C   GLN A  22 "
          pdb=" C   GLY A  23 "
   model   vdw
   3.473 2.800
nonbonded pdb=" O   VAL A  35 "
          pdb=" O   VAL A  43 "
   model   vdw
   3.474 3.040
nonbonded pdb=" O   GLU A  51 "
          pdb=" C   GLY A  52 "
   model   vdw
   3.474 3.270
nonbonded pdb=" O   TYR A  56 "
          pdb=" O   ALA A  57 "
   model   vdw
   3.474 3.040
nonbonded pdb=" C   LYS A  24 "
          pdb=" CG  PRO A  25 "
   model   vdw
   3.478 2.936
nonbonded pdb=" CB  GLN A  10 "
          pdb="O    HOH S   7 "
   model   vdw
   3.478 3.440
nonbonded pdb=" C   SER A  20 "
          pdb=" NE2 GLN A  53 "
   model   vdw sym.op.
   3.478 3.350 x,y-1,z
nonbonded pdb=" CA  PRO A  54 "
          pdb="O    HOH S  44 "
   model   vdw
   3.479 3.470
nonbonded pdb=" C   SER A  75 "
          pdb=" O   LEU A  76 "
   model   vdw
   3.481 3.270
nonbonded pdb=" CB  ARG A  82 "
          pdb=" N   LEU A  83 "
   model   vdw
   3.481 2.816
nonbonded pdb=" O   ALA A  55 "
          pdb=" N   ALA A  57 "
   model   vdw
   3.481 3.120
nonbonded pdb=" N   LEU A  44 "
          pdb=" N   VAL A  45 "
   model   vdw
   3.483 2.560
nonbonded pdb=" N   TYR A  34 "
          pdb=" CD2 TYR A  34 "
   model   vdw
   3.484 3.420
nonbonded pdb=" C   GLN A  12 "
          pdb=" C   PHE A  13 "
   model   vdw
   3.484 2.800
nonbonded pdb=" O   ASP A  50 "
          pdb=" N   GLY A  52 "
   model   vdw
   3.485 3.120
nonbonded pdb=" O   GLU A   5 "
          pdb=" CB  CYS A  33 "
   model   vdw
   3.485 3.440
nonbonded pdb=" CD  GLU A  40 "
          pdb="O    HOH S 117 "
   model   vdw sym.op.
   3.485 3.270 x+1/2,y+1/2,z
nonbonded pdb=" CB  SER A   9 "
          pdb=" N   GLN A  10 "
   model   vdw
   3.486 2.816
nonbonded pdb=" O   CYS A  33 "
          pdb=" O   VAL A  45 "
   model   vdw
   3.486 3.040
nonbonded pdb=" N   LYS A  46 "
          pdb=" N   ILE A  47 "
   model   vdw
   3.487 2.560
nonbonded pdb=" O   GLN A  10 "
          pdb=" CG  GLN A  31 "
   model   vdw
   3.487 3.440
nonbonded pdb=" CA  PRO A  42 "
          pdb="O    HOH S   3 "
   model   vdw
   3.487 3.470
nonbonded pdb=" N   VAL A  35 "
          pdb=" N   ASP A  36 "
   model   vdw
   3.490 2.560
nonbonded pdb=" C   SER A   9 "
          pdb=" N   ALA A  11 "
   model   vdw
   3.490 3.350
nonbonded pdb=" C   SER A  27 "
          pdb=" C   LEU A  28 "
   model   vdw
   3.491 2.800
nonbonded pdb=" C   TYR A  34 "
          pdb=" O   VAL A  43 "
   model   vdw
   3.492 3.270
nonbonded pdb=" O   ASP A  36 "
          pdb=" CD2 LEU A  65 "
   model   vdw sym.op.
   3.492 3.460 -x+1,y,-z+2
nonbonded pdb=" NE2 GLN A  10 "
          pdb=" N   CYS A  33 "
   model   vdw
   3.493 3.200
nonbonded pdb=" C   ASN A  29 "
          pdb=" C   GLU A  30 "
   model   vdw
   3.494 2.800
nonbonded pdb=" N   LEU A  60 "
          pdb=" N   TYR A  61 "
   model   vdw
   3.495 2.560
nonbonded pdb=" CB  ASP A  36 "
          pdb="O    HOH S   2 "
   model   vdw
   3.495 3.440
nonbonded pdb=" CB  ILE A  78 "
          pdb=" N   ASP A  79 "
   model   vdw
   3.496 2.840
nonbonded pdb=" N   PHE A  73 "
          pdb=" CD2 PHE A  73 "
   model   vdw
   3.496 3.420
nonbonded pdb=" O   SER A  67 "
          pdb=" CA  ILE A  78 "
   model   vdw
   3.497 3.470
nonbonded pdb=" CA  GLY A  18 "
          pdb=" CZ  TYR A  26 "
   model   vdw
   3.498 3.660
nonbonded pdb=" CA  GLY A  18 "
          pdb=" CE2 TYR A  26 "
   model   vdw
   3.498 3.740
nonbonded pdb=" O   ILE A   6 "
          pdb=" CB  PRO A  58 "
   model   vdw
   3.499 3.440
nonbonded pdb=" C   GLY A  18 "
          pdb=" CD2 TYR A  26 "
   model   vdw
   3.499 3.570
nonbonded pdb=" CB  ILE A   2 "
          pdb=" N   LYS A   3 "
   model   vdw
   3.500 2.840
nonbonded pdb=" CZ  ARG A  16 "
          pdb="O    HOH S  85 "
   model   vdw
   3.501 3.270
nonbonded pdb=" C   TYR A  41 "
          pdb="O    HOH S   3 "
   model   vdw
   3.501 3.270
nonbonded pdb=" C   GLN A  12 "
          pdb=" CB  PHE A  13 "
   model   vdw
   3.501 2.936
nonbonded pdb=" CB  VAL A  70 "
          pdb=" N   GLY A  71 "
   model   vdw
   3.502 2.840
nonbonded pdb=" CD1 TYR A  26 "
          pdb=" N   SER A  27 "
   model   vdw
   3.502 3.420
nonbonded pdb=" O   ASP A  79 "
          pdb=" CB  ASP A  79 "
   model   vdw
   3.502 2.752
nonbonded pdb=" CE1 TYR A  34 "
          pdb="O    HOH S  24 "
   model   vdw
   3.502 3.340
nonbonded pdb=" CB  ALA A  57 "
          pdb=" CD  PRO A  58 "
   model   vdw
   3.502 3.860
nonbonded pdb=" C   LEU A  44 "
          pdb=" C   VAL A  45 "
   model   vdw
   3.503 2.800
nonbonded pdb=" N   LYS A   3 "
          pdb=" N   VAL A   4 "
   model   vdw
   3.503 2.560
nonbonded pdb=" CB  LEU A  32 "
          pdb="O    HOH S   7 "
   model   vdw
   3.503 3.440
nonbonded pdb=" O   ARG A  82 "
          pdb=" C   LEU A  83 "
   model   vdw
   3.503 3.270
nonbonded pdb=" CG  LEU A  76 "
          pdb=" N   MSE A  77 "
   model   vdw
   3.504 3.550
nonbonded pdb=" CA  TYR A  56 "
          pdb=" CD2 TYR A  56 "
   model   vdw
   3.504 3.016
nonbonded pdb=" CE  LYS A   3 "
          pdb=" O   GLN A  72 "
   model   vdw sym.op.
   3.505 3.440 -x+1,y+1,-z+2
nonbonded pdb=" CB  LYS A   7 "
          pdb=" CD  PRO A   8 "
   model   vdw
   3.505 3.840
nonbonded pdb=" CB  PHE A  73 "
          pdb="O    HOH S   4 "
   model   vdw
   3.505 3.440
nonbonded pdb=" N   GLU A  40 "
          pdb=" O   GLU A  40 "
   model   vdw
   3.506 2.496
nonbonded pdb=" O   LYS A   3 "
          pdb=" CA  VAL A  35 "
   model   vdw
   3.506 3.470
nonbonded pdb=" CA  ASN A  39 "
          pdb=" OD1 ASN A  39 "
   model   vdw
   3.506 2.776
nonbonded pdb=" C   GLN A  10 "
          pdb="O    HOH S   7 "
   model   vdw
   3.506 3.270
nonbonded pdb=" N   VAL A  63 "
          pdb=" N   HIS A  64 "
   model   vdw
   3.507 2.560
nonbonded pdb=" CA  TYR A  41 "
          pdb=" CD2 TYR A  41 "
   model   vdw
   3.508 3.016
nonbonded pdb=" C   ASN A  29 "
          pdb=" CB  GLU A  30 "
   model   vdw
   3.508 2.936
nonbonded pdb=" N   ARG A  80 "
          pdb=" N   LEU A  81 "
   model   vdw
   3.508 2.560
nonbonded pdb=" CB  LYS A   7 "
          pdb=" OE2 GLU A  40 "
   model   vdw sym.op.
   3.509 3.440 -x+1,y,-z+1
nonbonded pdb=" N   TYR A  41 "
          pdb="O    HOH S 123 "
   model   vdw
   3.510 3.120
nonbonded pdb=" O   PHE A  73 "
          pdb=" C   GLY A  74 "
   model   vdw
   3.511 3.270
nonbonded pdb=" CA  TYR A  26 "
          pdb=" CD2 TYR A  26 "
   model   vdw
   3.512 3.016
nonbonded pdb=" CD  GLU A   5 "
          pdb=" NZ  LYS A   7 "
   model   vdw
   3.512 3.350
nonbonded pdb=" O   LEU A  28 "
          pdb=" OD1 ASN A  29 "
   model   vdw
   3.513 3.040
nonbonded pdb=" O   THR A  48 "
          pdb=" CD  ARG A  80 "
   model   vdw
   3.514 3.440
nonbonded pdb=" CG2 THR A  62 "
          pdb=" N   VAL A  63 "
   model   vdw
   3.514 3.540
nonbonded pdb=" O   LYS A  69 "
          pdb=" CG  LYS A  69 "
   model   vdw
   3.515 3.440
nonbonded pdb=" OD1 ASP A  50 "
          pdb=" NH1 ARG A  80 "
   model   vdw
   3.515 3.120
nonbonded pdb=" C   LEU A  60 "
          pdb=" CD1 TYR A  61 "
   model   vdw
   3.515 3.570
nonbonded pdb=" CB  SER A  66 "
          pdb=" N   SER A  67 "
   model   vdw
   3.516 2.816
nonbonded pdb=" CA  PHE A  73 "
          pdb=" CD2 PHE A  73 "
   model   vdw
   3.516 3.016
nonbonded pdb=" N   VAL A   4 "
          pdb=" N   GLU A   5 "
   model   vdw
   3.517 2.560
nonbonded pdb=" N   LEU A  28 "
          pdb=" N   ASN A  29 "
   model   vdw
   3.517 2.560
nonbonded pdb=" N   VAL A  19 "
          pdb=" N   SER A  20 "
   model   vdw
   3.519 2.560
nonbonded pdb=" C   GLY A  18 "
          pdb=" C   VAL A  19 "
   model   vdw
   3.519 2.800
nonbonded pdb=" O   GLY A  52 "
          pdb=" N   PRO A  54 "
   model   vdw
   3.519 3.120
nonbonded pdb=" C   GLY A  74 "
          pdb=" O   SER A  75 "
   model   vdw
   3.520 3.270
nonbonded pdb=" C   LYS A   3 "
          pdb=" CB  VAL A   4 "
   model   vdw
   3.520 2.960
nonbonded pdb=" N   GLU A   5 "
          pdb=" N   ILE A   6 "
   model   vdw
   3.520 2.560
nonbonded pdb=" CB  ALA A  11 "
          pdb=" N   GLN A  12 "
   model   vdw
   3.521 2.832
nonbonded pdb=" O   ASN A  39 "
          pdb=" N   TYR A  41 "
   model   vdw
   3.521 3.120
nonbonded pdb=" C   ARG A  16 "
          pdb=" CB  SER A  17 "
   model   vdw
   3.521 2.936
nonbonded pdb=" C   GLN A  72 "
          pdb=" N   GLY A  74 "
   model   vdw
   3.522 3.350
nonbonded pdb=" C   LEU A  83 "
          pdb=" C   VAL A  84 "
   model   vdw
   3.522 2.800
nonbonded pdb=" O   PHE A  13 "
          pdb="O    HOH S 110 "
   model   vdw
   3.522 3.040
nonbonded pdb=" C   LEU A  60 "
          pdb=" CG  TYR A  61 "
   model   vdw
   3.523 3.490
nonbonded pdb=" C   CYS A  33 "
          pdb=" CB  TYR A  34 "
   model   vdw
   3.523 2.936
nonbonded pdb=" N   VAL A  19 "
          pdb=" CE2 TYR A  26 "
   model   vdw
   3.523 3.420
nonbonded pdb=" CB  LYS A   7 "
          pdb=" OE1 GLN A  10 "
   model   vdw
   3.524 3.440
nonbonded pdb=" C   GLY A  52 "
          pdb=" O   GLN A  53 "
   model   vdw
   3.526 3.270
nonbonded pdb=" O   GLY A  18 "
          pdb=" CD2 TYR A  26 "
   model   vdw
   3.527 3.340
nonbonded pdb=" N   GLN A  53 "
          pdb=" N   PRO A  54 "
   model   vdw
   3.527 2.560
nonbonded pdb=" O   LEU A  60 "
          pdb=" C   PRO A  85 "
   model   vdw
   3.528 3.270
nonbonded pdb=" C   PRO A  42 "
          pdb=" CB  VAL A  43 "
   model   vdw
   3.528 2.960
nonbonded pdb=" CA  GLY A  74 "
          pdb="O    HOH S  17 "
   model   vdw sym.op.
   3.529 3.440 -x+1,y,-z+2
nonbonded pdb=" CA  ASP A  50 "
          pdb=" OD2 ASP A  50 "
   model   vdw
   3.529 2.776
nonbonded pdb=" CD  GLU A  30 "
          pdb=" CD  LYS A  46 "
   model   vdw
   3.529 3.670
nonbonded pdb=" NE2 GLN A  10 "
          pdb=" CD2 TYR A  34 "
   model   vdw
   3.529 3.420
nonbonded pdb=" CG  GLN A  31 "
          pdb="O    HOH S   7 "
   model   vdw
   3.530 3.440
nonbonded pdb=" O   SER A  67 "
          pdb=" N   ARG A  80 "
   model   vdw
   3.531 3.120
nonbonded pdb=" C   VAL A   4 "
          pdb=" C   GLU A   5 "
   model   vdw
   3.531 2.800
nonbonded pdb=" C   LYS A   3 "
          pdb=" CG2 VAL A   4 "
   model   vdw
   3.532 3.690
nonbonded pdb=" NE  ARG A  21 "
          pdb=" CE1 HIS A  64 "
   model   vdw sym.op.
   3.533 3.340 x,y-1,z
nonbonded pdb=" O   ASN A  29 "
          pdb=" CA  THR A  48 "
   model   vdw
   3.533 3.470
nonbonded pdb=" N   ASN A  39 "
          pdb=" ND2 ASN A  39 "
   model   vdw
   3.533 3.200
nonbonded pdb=" C   TYR A  61 "
          pdb=" C   THR A  62 "
   model   vdw
   3.534 2.800
nonbonded pdb=" O   PRO A  25 "
          pdb=" CD  PRO A  25 "
   model   vdw
   3.535 3.440
nonbonded pdb=" OE1 GLN A  31 "
          pdb=" CA  ALA A  55 "
   model   vdw
   3.535 3.470
nonbonded pdb=" O   THR A  62 "
          pdb=" CA  LEU A  83 "
   model   vdw
   3.535 3.470
nonbonded pdb=" C   SER A   9 "
          pdb=" CB  GLN A  10 "
   model   vdw
   3.536 2.936
nonbonded pdb=" C   ALA A  11 "
          pdb=" CB  GLN A  12 "
   model   vdw
   3.536 2.936
nonbonded pdb=" N   LEU A  76 "
          pdb=" N   MSE A  77 "
   model   vdw
   3.536 2.560
nonbonded pdb=" C   GLN A  22 "
          pdb=" N   LYS A  24 "
   model   vdw
   3.537 3.350
nonbonded pdb=" CB  THR A  48 "
          pdb=" N   LEU A  49 "
   model   vdw
   3.537 2.840
nonbonded pdb=" O   LYS A  46 "
          pdb=" CG2 ILE A  47 "
   model   vdw
   3.537 3.460
nonbonded pdb=" CD2 TYR A  61 "
          pdb=" C   VAL A  84 "
   model   vdw
   3.537 3.570
nonbonded pdb=" OG  SER A  66 "
          pdb=" N   SER A  67 "
   model   vdw
   3.538 3.120
nonbonded pdb=" NE2 GLN A  53 "
          pdb="O    HOH S  98 "
   model   vdw
   3.539 3.120
nonbonded pdb=" O   GLN A  10 "
          pdb=" O   GLN A  12 "
   model   vdw
   3.539 3.040
nonbonded pdb=" CB  ILE A   6 "
          pdb=" N   LYS A   7 "
   model   vdw
   3.540 2.840
nonbonded pdb=" O   THR A  15 "
          pdb=" O   PRO A   8 "
   model   vdw sym.op.
   3.540 3.040 -x+1/2,y-1/2,-z+1
nonbonded pdb=" O   PRO A   8 "
          pdb=" O   THR A  15 "
   model   vdw sym.op.
   3.540 3.040 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CD1 ILE A   6 "
          pdb=" CB  CYS A  33 "
   model   vdw
   3.540 3.860
nonbonded pdb=" CG  ARG A  82 "
          pdb=" NH1 ARG A  82 "
   model   vdw
   3.540 3.520
nonbonded pdb=" C   ALA A  57 "
          pdb=" OH  TYR A  61 "
   model   vdw
   3.541 3.270
nonbonded pdb=" O   GLN A  12 "
          pdb=" CG  GLN A  31 "
   model   vdw
   3.541 3.440
nonbonded pdb=" NH2 ARG A  16 "
          pdb=" CE2 TYR A  61 "
   model   vdw sym.op.
   3.541 3.420 x,y-1,z
nonbonded pdb=" CB  GLN A  10 "
          pdb=" O   LEU A  32 "
   model   vdw
   3.542 3.440
nonbonded pdb=" CB  GLU A  30 "
          pdb="O    HOH S   8 "
   model   vdw
   3.542 3.440
nonbonded pdb=" O   VAL A  45 "
          pdb=" C   LYS A  46 "
   model   vdw
   3.542 3.270
nonbonded pdb=" CE1 TYR A  26 "
          pdb="O    HOH S  85 "
   model   vdw
   3.543 3.340
nonbonded pdb=" CZ  TYR A  26 "
          pdb="O    HOH S  85 "
   model   vdw
   3.544 3.260
nonbonded pdb=" O   ASP A  36 "
          pdb=" CD1 LEU A  65 "
   model   vdw sym.op.
   3.544 3.460 -x+1,y,-z+2
nonbonded pdb=" O   LYS A  46 "
          pdb=" CA  SER A  75 "
   model   vdw sym.op.
   3.544 3.470 -x+1,y,-z+2
nonbonded pdb=" C   PRO A  42 "
          pdb=" CD  PRO A  42 "
   model   vdw
   3.544 2.936
nonbonded pdb=" NE2 GLN A  53 "
          pdb="O    HOH S 135 "
   model   vdw
   3.545 3.120
nonbonded pdb=" C   GLN A  72 "
          pdb=" CB  PHE A  73 "
   model   vdw
   3.545 2.936
nonbonded pdb=" O   SER A  67 "
          pdb=" C   ILE A  78 "
   model   vdw
   3.545 3.270
nonbonded pdb=" C   PRO A   8 "
          pdb=" N   THR A  15 "
   model   vdw sym.op.
   3.546 3.350 -x+1/2,y+1/2,-z+1
nonbonded pdb=" N   GLU A  30 "
          pdb=" N   GLN A  31 "
   model   vdw
   3.546 2.560
nonbonded pdb=" CG2 ILE A  47 "
          pdb="O    HOH S  10 "
   model   vdw
   3.546 3.460
nonbonded pdb=" CA  HIS A  64 "
          pdb=" ND1 HIS A  64 "
   model   vdw
   3.546 2.840
nonbonded pdb=" N   TYR A  41 "
          pdb=" CD2 TYR A  41 "
   model   vdw
   3.547 3.420
nonbonded pdb=" O   GLY A  18 "
          pdb=" CG2 VAL A  19 "
   model   vdw
   3.548 3.460
nonbonded pdb=" C   GLN A  31 "
          pdb=" O   LEU A  32 "
   model   vdw
   3.548 3.270
nonbonded pdb=" N   TYR A  56 "
          pdb=" N   ALA A  57 "
   model   vdw
   3.548 2.560
nonbonded pdb=" N   VAL A  43 "
          pdb=" N   LEU A  44 "
   model   vdw
   3.549 2.560
nonbonded pdb=" OE1 GLN A  53 "
          pdb=" OH  TYR A  56 "
   model   vdw
   3.549 3.040
nonbonded pdb=" O   GLN A  31 "
          pdb=" C   LEU A  32 "
   model   vdw
   3.551 3.270
nonbonded pdb=" C   THR A  14 "
          pdb=" CB  THR A  15 "
   model   vdw
   3.551 2.960
nonbonded pdb=" CD1 PHE A  13 "
          pdb=" CG  ASN A  29 "
   model   vdw
   3.552 3.570
nonbonded pdb=" O   LYS A  46 "
          pdb=" CB  SER A  75 "
   model   vdw sym.op.
   3.552 3.440 -x+1,y,-z+2
nonbonded pdb=" O   THR A  14 "
          pdb=" O   LEU A  28 "
   model   vdw
   3.553 3.040
nonbonded pdb=" N   ILE A  47 "
          pdb=" N   THR A  48 "
   model   vdw
   3.553 2.560
nonbonded pdb=" CB  GLN A  12 "
          pdb=" NE2 GLN A  12 "
   model   vdw
   3.553 2.816
nonbonded pdb=" OE1 GLN A  12 "
          pdb=" CB  PRO A  58 "
   model   vdw sym.op.
   3.553 3.440 -x+1/2,y-1/2,-z+1
nonbonded pdb=" CZ  ARG A  16 "
          pdb=" O   LEU A  60 "
   model   vdw sym.op.
   3.553 3.270 x,y-1,z
nonbonded pdb=" CG2 VAL A  84 "
          pdb=" CD  PRO A  85 "
   model   vdw
   3.553 3.860
nonbonded pdb=" OD1 ASP A  50 "
          pdb=" NE  ARG A  82 "
   model   vdw
   3.553 3.120
nonbonded pdb=" C   LEU A  60 "
          pdb=" C   TYR A  61 "
   model   vdw
   3.554 2.800
nonbonded pdb=" CA  HIS A  64 "
          pdb=" O   ARG A  82 "
   model   vdw
   3.555 3.470
nonbonded pdb=" N   PRO A  58 "
          pdb=" N   GLY A  59 "
   model   vdw
   3.555 2.560
nonbonded pdb=" N   GLU A  51 "
          pdb=" N   GLY A  52 "
   model   vdw
   3.555 2.560
nonbonded pdb=" C   ARG A  21 "
          pdb=" CB  GLN A  22 "
   model   vdw
   3.558 2.936
nonbonded pdb=" NE2 GLN A  31 "
          pdb=" N   TYR A  56 "
   model   vdw
   3.558 3.200
nonbonded pdb=" CG  ASP A  50 "
          pdb=" NE  ARG A  82 "
   model   vdw
   3.558 3.350
nonbonded pdb=" C   VAL A   4 "
          pdb=" O   TYR A  34 "
   model   vdw
   3.558 3.270
nonbonded pdb=" O   ASN A  39 "
          pdb=" CB  ASN A  39 "
   model   vdw
   3.558 2.752
nonbonded pdb=" C   LEU A  81 "
          pdb=" CB  ARG A  82 "
   model   vdw
   3.558 2.936
nonbonded pdb=" CA  SER A  17 "
          pdb=" O   TYR A  26 "
   model   vdw
   3.560 3.470
nonbonded pdb=" N   GLY A  38 "
          pdb="O    HOH S   3 "
   model   vdw
   3.560 3.120
nonbonded pdb=" O   GLU A   5 "
          pdb=" CA  CYS A  33 "
   model   vdw
   3.561 3.470
nonbonded pdb=" O   GLN A  22 "
          pdb="O    HOH S  97 "
   model   vdw
   3.562 3.040
nonbonded pdb=" CG1 VAL A   4 "
          pdb=" SG  CYS A  33 "
   model   vdw
   3.563 3.820
nonbonded pdb=" CB  THR A  15 "
          pdb="O    HOH S 117 "
   model   vdw
   3.564 3.470
nonbonded pdb=" C   LYS A  24 "
          pdb=" CB  PRO A  25 "
   model   vdw
   3.564 2.936
nonbonded pdb=" CD2 LEU A  49 "
          pdb=" CE2 TYR A  56 "
   model   vdw
   3.564 3.760
nonbonded pdb=" C   SER A  67 "
          pdb=" CB  PHE A  68 "
   model   vdw
   3.566 2.936
nonbonded pdb=" N   ALA A  55 "
          pdb=" N   TYR A  56 "
   model   vdw
   3.566 2.560
nonbonded pdb=" OE1 GLN A  31 "
          pdb=" CB  ALA A  55 "
   model   vdw
   3.567 3.460
nonbonded pdb=" N   VAL A  45 "
          pdb=" N   LYS A  46 "
   model   vdw
   3.568 2.560
nonbonded pdb=" O   PHE A  73 "
          pdb=" N   SER A  75 "
   model   vdw
   3.568 3.120
nonbonded pdb=" O   LYS A  24 "
          pdb=" CD  PRO A  25 "
   model   vdw
   3.568 2.752
nonbonded pdb=" O   GLY A  52 "
          pdb=" CD  PRO A  54 "
   model   vdw
   3.569 3.440
nonbonded pdb=" C   GLU A  40 "
          pdb=" CG  TYR A  41 "
   model   vdw
   3.569 3.490
nonbonded pdb=" CZ  TYR A  56 "
          pdb=" CB  LEU A  83 "
   model   vdw
   3.569 3.660
nonbonded pdb=" N   GLN A  72 "
          pdb="O    HOH S   4 "
   model   vdw
   3.571 3.120
nonbonded pdb=" O   PRO A  54 "
          pdb=" CD  PRO A  54 "
   model   vdw
   3.571 3.440
nonbonded pdb=" CG2 THR A  48 "
          pdb=" N   LEU A  49 "
   model   vdw
   3.571 3.540
nonbonded pdb=" N   THR A  14 "
          pdb=" N   THR A  15 "
   model   vdw
   3.571 2.560
nonbonded pdb=" C   GLU A  30 "
          pdb=" C   GLN A  31 "
   model   vdw
   3.571 2.800
nonbonded pdb=" C   LEU A  76 "
          pdb=" C   MSE A  77 "
   model   vdw
   3.571 2.800
nonbonded pdb=" CB  SER A  75 "
          pdb="O    HOH S  10 "
   model   vdw sym.op.
   3.572 3.440 -x+1,y,-z+2
nonbonded pdb=" O   LYS A   7 "
          pdb=" O   PRO A   8 "
   model   vdw
   3.572 3.040
nonbonded pdb="O    HOH S 103 "
          pdb=" N   GLN A  72 "
   model   vdw sym.op.
   3.573 3.120 -x,y-1,-z+1
nonbonded pdb=" N   GLN A  72 "
          pdb="O    HOH S 103 "
   model   vdw sym.op.
   3.573 3.120 -x,y+1,-z+1
nonbonded pdb=" CA  LEU A  32 "
          pdb=" O   VAL A  45 "
   model   vdw
   3.573 3.470
nonbonded pdb=" C   GLU A  40 "
          pdb=" C   TYR A  41 "
   model   vdw
   3.573 2.800
nonbonded pdb=" N   PHE A  13 "
          pdb=" N   THR A  14 "
   model   vdw
   3.574 2.560
nonbonded pdb=" N   GLN A  31 "
          pdb=" N   LEU A  32 "
   model   vdw
   3.574 2.560
nonbonded pdb=" C   GLY A  38 "
          pdb="O    HOH S 131 "
   model   vdw
   3.574 3.270
nonbonded pdb=" CD  LYS A  24 "
          pdb=" CZ  ARG A  82 "
   model   vdw sym.op.
   3.575 3.670 -x+1/2,y-1/2,-z+2
nonbonded pdb=" CZ  ARG A  82 "
          pdb=" CD  LYS A  24 "
   model   vdw sym.op.
   3.575 3.670 -x+1/2,y+1/2,-z+2
nonbonded pdb=" CA  SER A  75 "
          pdb="O    HOH S  10 "
   model   vdw sym.op.
   3.575 3.470 -x+1,y,-z+2
nonbonded pdb=" C   VAL A  84 "
          pdb=" CG2 VAL A  84 "
   model   vdw
   3.575 2.952
nonbonded pdb=" C   LEU A  28 "
          pdb=" CB  ASN A  29 "
   model   vdw
   3.576 2.936
nonbonded pdb=" N   LYS A  24 "
          pdb=" N   PRO A  25 "
   model   vdw
   3.576 2.560
nonbonded pdb=" N   VAL A  84 "
          pdb=" N   PRO A  85 "
   model   vdw
   3.577 2.560
nonbonded pdb=" CE2 TYR A  41 "
          pdb=" CZ  TYR A  34 "
   model   vdw sym.op.
   3.577 3.560 -x+1,y,-z+1
nonbonded pdb=" CZ  TYR A  34 "
          pdb=" CE2 TYR A  41 "
   model   vdw sym.op.
   3.577 3.560 -x+1,y,-z+1
nonbonded pdb=" CE1 PHE A  13 "
          pdb=" CG  ASN A  29 "
   model   vdw
   3.578 3.570
nonbonded pdb=" NH2 ARG A  82 "
          pdb="O    HOH S  97 "
   model   vdw sym.op.
   3.578 3.120 -x+1/2,y+1/2,-z+2
nonbonded pdb="O    HOH S  97 "
          pdb=" NH2 ARG A  82 "
   model   vdw sym.op.
   3.578 3.120 -x+1/2,y-1/2,-z+2
nonbonded pdb=" C   PHE A  13 "
          pdb=" CB  THR A  14 "
   model   vdw
   3.578 2.960
nonbonded pdb=" CB  LEU A  81 "
          pdb=" N   ARG A  82 "
   model   vdw
   3.579 2.816
nonbonded pdb=" N   LEU A  65 "
          pdb=" O   LEU A  65 "
   model   vdw
   3.579 2.496
nonbonded pdb=" O   VAL A   4 "
          pdb=" CA  TYR A  61 "
   model   vdw
   3.580 3.470
nonbonded pdb=" CD  PRO A  42 "
          pdb="O    HOH S 123 "
   model   vdw
   3.580 3.440
nonbonded pdb=" CB  TYR A  41 "
          pdb=" CD  PRO A  42 "
   model   vdw
   3.580 3.840
nonbonded pdb=" C   VAL A  45 "
          pdb=" CB  LYS A  46 "
   model   vdw
   3.581 2.936
nonbonded pdb=" OD2 ASP A  50 "
          pdb=" CD  ARG A  82 "
   model   vdw
   3.582 3.440
nonbonded pdb=" CG1 VAL A  63 "
          pdb=" O   HIS A  64 "
   model   vdw
   3.582 3.460
nonbonded pdb=" C   PRO A  25 "
          pdb=" C   TYR A  26 "
   model   vdw
   3.582 2.800
nonbonded pdb=" CB  VAL A  84 "
          pdb=" CD  PRO A  85 "
   model   vdw
   3.582 3.870
nonbonded pdb=" C   TYR A  26 "
          pdb=" C   SER A  27 "
   model   vdw
   3.583 2.800
nonbonded pdb=" CA  TYR A  56 "
          pdb="O    HOH S  14 "
   model   vdw
   3.584 3.470
nonbonded pdb=" C   GLY A  59 "
          pdb=" CB  LEU A  60 "
   model   vdw
   3.584 2.936
nonbonded pdb=" N   TYR A  26 "
          pdb=" CD2 TYR A  26 "
   model   vdw
   3.584 3.420
nonbonded pdb=" CD  LYS A  24 "
          pdb=" NE  ARG A  82 "
   model   vdw sym.op.
   3.585 3.520 -x+1/2,y-1/2,-z+2
nonbonded pdb=" NE  ARG A  82 "
          pdb=" CD  LYS A  24 "
   model   vdw sym.op.
   3.585 3.520 -x+1/2,y+1/2,-z+2
nonbonded pdb=" N   ARG A  16 "
          pdb="O    HOH S   8 "
   model   vdw
   3.585 3.120
nonbonded pdb=" C   PRO A  58 "
          pdb=" CD  PRO A  58 "
   model   vdw
   3.585 2.936
nonbonded pdb=" CB  PHE A  73 "
          pdb=" N   GLY A  74 "
   model   vdw
   3.586 2.816
nonbonded pdb=" C   TYR A  34 "
          pdb=" CB  VAL A  35 "
   model   vdw
   3.587 2.960
nonbonded pdb=" CD1 ILE A   2 "
          pdb=" CG2 VAL A  63 "
   model   vdw
   3.587 3.880
nonbonded pdb=" CB  ASP A  36 "
          pdb=" N   LEU A  37 "
   model   vdw
   3.588 2.816
nonbonded pdb=" C   THR A  15 "
          pdb=" CB  ARG A  16 "
   model   vdw
   3.589 2.936
nonbonded pdb=" CD1 PHE A  13 "
          pdb=" CB  ASN A  29 "
   model   vdw
   3.589 3.740
nonbonded pdb=" O   PRO A  54 "
          pdb=" CG  PRO A  54 "
   model   vdw
   3.590 3.440
nonbonded pdb=" N   LEU A  49 "
          pdb=" N   ASP A  50 "
   model   vdw
   3.590 2.560
nonbonded pdb=" CD2 LEU A  32 "
          pdb="O    HOH S   7 "
   model   vdw
   3.590 3.460
nonbonded pdb=" C   ASP A  36 "
          pdb=" CB  LEU A  37 "
   model   vdw
   3.590 2.936
nonbonded pdb=" N   SER A  67 "
          pdb=" O   SER A  67 "
   model   vdw
   3.591 2.496
nonbonded pdb=" O   GLY A  74 "
          pdb="O    HOH S  17 "
   model   vdw sym.op.
   3.591 3.040 -x+1,y,-z+2
nonbonded pdb=" O   ARG A  16 "
          pdb=" O   LEU A  28 "
   model   vdw
   3.591 3.040
nonbonded pdb=" C   HIS A  64 "
          pdb=" ND1 HIS A  64 "
   model   vdw
   3.592 3.350
nonbonded pdb=" N   VAL A  84 "
          pdb=" CG2 VAL A  84 "
   model   vdw
   3.592 2.832
nonbonded pdb=" O   LYS A   7 "
          pdb=" CA  GLN A  10 "
   model   vdw
   3.593 3.470
nonbonded pdb=" N   PRO A   8 "
          pdb=" O   PRO A   8 "
   model   vdw
   3.593 2.496
nonbonded pdb=" CE1 TYR A  56 "
          pdb=" CB  LEU A  83 "
   model   vdw
   3.593 3.740
nonbonded pdb=" N   GLY A  52 "
          pdb=" O   GLY A  52 "
   model   vdw
   3.593 2.496
nonbonded pdb=" N   GLN A  10 "
          pdb=" O   GLN A  10 "
   model   vdw
   3.593 2.496
nonbonded pdb=" N   PRO A  25 "
          pdb=" N   TYR A  26 "
   model   vdw
   3.594 2.560
nonbonded pdb=" O   VAL A  63 "
          pdb=" CG1 VAL A  63 "
   model   vdw
   3.594 3.460
nonbonded pdb=" C   TYR A  61 "
          pdb=" O   VAL A  84 "
   model   vdw
   3.594 3.270
nonbonded pdb=" O   ILE A   6 "
          pdb=" C   PRO A  58 "
   model   vdw
   3.595 3.270
nonbonded pdb=" CE1 PHE A  68 "
          pdb=" CG1 ILE A  78 "
   model   vdw
   3.597 3.740
nonbonded pdb=" O   GLU A   5 "
          pdb=" CG  GLU A   5 "
   model   vdw
   3.598 3.440
nonbonded pdb=" C   MSE A  77 "
          pdb=" CB  ILE A  78 "
   model   vdw
   3.599 2.960
nonbonded pdb=" C   ILE A  47 "
          pdb=" CB  THR A  48 "
   model   vdw
   3.599 2.960
nonbonded pdb=" O   GLU A  40 "
          pdb=" CG  TYR A  41 "
   model   vdw
   3.600 3.260
nonbonded pdb=" O   SER A  75 "
          pdb=" N   MSE A  77 "
   model   vdw
   3.600 3.120
nonbonded pdb=" CG2 VAL A  63 "
          pdb=" CD1 LEU A  81 "
   model   vdw
   3.600 3.880
nonbonded pdb=" CG1 VAL A  19 "
          pdb=" C   GLY A  23 "
   model   vdw
   3.600 3.690
nonbonded pdb=" O   GLU A   5 "
          pdb=" O   TYR A  34 "
   model   vdw
   3.601 3.040
nonbonded pdb=" N   LEU A  83 "
          pdb=" N   VAL A  84 "
   model   vdw
   3.601 2.560
nonbonded pdb=" O   PRO A  54 "
          pdb=" N   TYR A  56 "
   model   vdw
   3.601 3.120
nonbonded pdb=" N   LEU A  37 "
          pdb=" O   LEU A  37 "
   model   vdw
   3.602 2.496
nonbonded pdb=" CE1 TYR A  34 "
          pdb=" CD2 TYR A  41 "
   model   vdw sym.op.
   3.602 3.640 -x+1,y,-z+1
nonbonded pdb=" CD2 TYR A  41 "
          pdb=" CE1 TYR A  34 "
   model   vdw sym.op.
   3.602 3.640 -x+1,y,-z+1
nonbonded pdb=" C   ILE A  78 "
          pdb=" O   ASP A  79 "
   model   vdw
   3.603 3.270
nonbonded pdb=" O   LEU A  28 "
          pdb=" C   ASN A  29 "
   model   vdw
   3.603 3.270
nonbonded pdb=" CD2 PHE A  13 "
          pdb="O    HOH S  44 "
   model   vdw
   3.603 3.340
nonbonded pdb=" CA  GLY A  71 "
          pdb=" O   SER A  75 "
   model   vdw
   3.603 3.440
nonbonded pdb=" C   GLU A  30 "
          pdb="O    HOH S 151 "
   model   vdw
   3.603 3.270
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" N   LYS A   7 "
   model   vdw
   3.604 3.540
nonbonded pdb=" C   GLY A  23 "
          pdb=" CB  LYS A  24 "
   model   vdw
   3.604 2.936
nonbonded pdb=" O   THR A  14 "
          pdb=" C   ASN A  29 "
   model   vdw
   3.605 3.270
nonbonded pdb=" O   CYS A  33 "
          pdb=" SG  CYS A  33 "
   model   vdw
   3.605 3.400
nonbonded pdb=" CD2 TYR A  41 "
          pdb=" OH  TYR A  41 "
   model   vdw
   3.605 2.672
nonbonded pdb=" CG2 ILE A   2 "
          pdb="O    HOH S 163 "
   model   vdw sym.op.
   3.606 3.460 x,y,z
nonbonded pdb="O    HOH S 163 "
          pdb=" CG2 ILE A   2 "
   model   vdw sym.op.
   3.606 3.460 x,y,z
nonbonded pdb="O    HOH S 163 "
          pdb=" CG2 ILE A   2 "
   model   vdw sym.op.
   3.606 3.460 -x+1,y,-z+2
nonbonded pdb=" N   TYR A  41 "
          pdb=" N   PRO A  42 "
   model   vdw
   3.606 2.560
nonbonded pdb=" C   ALA A  57 "
          pdb=" CG  PRO A  58 "
   model   vdw
   3.606 2.936
nonbonded pdb=" C   ILE A   2 "
          pdb=" CB  LYS A   3 "
   model   vdw
   3.609 2.936
nonbonded pdb=" N   LYS A  69 "
          pdb=" N   VAL A  70 "
   model   vdw
   3.609 2.560
nonbonded pdb=" C   TYR A  41 "
          pdb=" CG  PRO A  42 "
   model   vdw
   3.609 2.936
nonbonded pdb=" C   THR A  15 "
          pdb="O    HOH S  34 "
   model   vdw
   3.609 3.270
nonbonded pdb=" CA  PHE A  73 "
          pdb="O    HOH S   4 "
   model   vdw
   3.610 3.470
nonbonded pdb=" N   GLN A  22 "
          pdb=" O   GLN A  22 "
   model   vdw
   3.610 2.496
nonbonded pdb=" CB  GLN A  10 "
          pdb=" NE2 GLN A  10 "
   model   vdw
   3.611 2.816
nonbonded pdb=" C   ASN A  29 "
          pdb=" CG  GLU A  30 "
   model   vdw
   3.611 3.670
nonbonded pdb=" C   ARG A  82 "
          pdb=" CB  LEU A  83 "
   model   vdw
   3.611 2.936
nonbonded pdb=" N   GLN A  72 "
          pdb=" O   GLN A  72 "
   model   vdw
   3.611 2.496
nonbonded pdb=" O   LEU A  65 "
          pdb=" CD1 LEU A  65 "
   model   vdw
   3.611 3.460
nonbonded pdb=" O   LYS A   7 "
          pdb=" CB  GLN A  10 "
   model   vdw
   3.611 3.440
nonbonded pdb=" N   LEU A  37 "
          pdb=" CD2 LEU A  37 "
   model   vdw
   3.612 3.540
nonbonded pdb=" O   SER A  67 "
          pdb=" CA  ASP A  79 "
   model   vdw
   3.613 3.470
nonbonded pdb=" N   PHE A  68 "
          pdb=" N   LYS A  69 "
   model   vdw
   3.613 2.560
nonbonded pdb=" CD1 TYR A  26 "
          pdb=" OH  TYR A  26 "
   model   vdw
   3.613 2.672
nonbonded pdb=" O   ILE A   2 "
          pdb=" C   LYS A   3 "
   model   vdw
   3.614 3.270
nonbonded pdb=" N   PHE A  13 "
          pdb="O    HOH S 110 "
   model   vdw
   3.615 3.120
nonbonded pdb=" N   HIS A  64 "
          pdb=" N   LEU A  65 "
   model   vdw
   3.615 2.560
nonbonded pdb=" C   PRO A  25 "
          pdb=" CG  PRO A  25 "
   model   vdw
   3.615 2.936
nonbonded pdb=" O   ASP A  36 "
          pdb=" CG  ASP A  36 "
   model   vdw
   3.615 3.270
nonbonded pdb=" C   GLU A   5 "
          pdb=" CB  ILE A   6 "
   model   vdw
   3.616 2.960
nonbonded pdb=" N   THR A  62 "
          pdb=" N   VAL A  63 "
   model   vdw
   3.618 2.560
nonbonded pdb=" CD2 TYR A  61 "
          pdb=" CA  PRO A  85 "
   model   vdw
   3.618 3.770
nonbonded pdb=" N   PHE A  73 "
          pdb=" O   PHE A  73 "
   model   vdw
   3.618 2.496
nonbonded pdb=" OG  SER A  20 "
          pdb=" N   GLY A  23 "
   model   vdw
   3.619 3.120
nonbonded pdb=" N   PRO A  42 "
          pdb=" N   VAL A  43 "
   model   vdw
   3.619 2.560
nonbonded pdb=" CG2 THR A  62 "
          pdb=" CG1 VAL A  84 "
   model   vdw
   3.619 3.880
nonbonded pdb=" O   SER A  17 "
          pdb="O    HOH S  14 "
   model   vdw sym.op.
   3.619 3.040 x,y-1,z
nonbonded pdb=" N   GLY A  38 "
          pdb=" O   GLY A  38 "
   model   vdw
   3.620 2.496
nonbonded pdb=" OE2 GLU A  30 "
          pdb=" NZ  LYS A  46 "
   model   vdw
   3.620 3.120
nonbonded pdb=" OE1 GLU A  40 "
          pdb="O    HOH S 117 "
   model   vdw sym.op.
   3.620 3.040 x+1/2,y+1/2,z
nonbonded pdb=" O   VAL A   4 "
          pdb=" CA  LEU A  60 "
   model   vdw
   3.620 3.470
nonbonded pdb=" O   VAL A  84 "
          pdb=" CD  PRO A  85 "
   model   vdw
   3.621 2.752
nonbonded pdb=" N   GLY A  74 "
          pdb=" O   GLY A  74 "
   model   vdw
   3.621 2.496
nonbonded pdb=" CB  LEU A  76 "
          pdb="O    HOH S  10 "
   model   vdw sym.op.
   3.621 3.440 -x+1,y,-z+2
nonbonded pdb=" O   SER A  67 "
          pdb=" CB  ASP A  79 "
   model   vdw
   3.622 3.440
nonbonded pdb=" C   LYS A   7 "
          pdb=" CG  PRO A   8 "
   model   vdw
   3.622 2.936
nonbonded pdb=" N   SER A   9 "
          pdb=" O   SER A   9 "
   model   vdw
   3.622 2.496
nonbonded pdb=" O   ALA A  57 "
          pdb=" CD  PRO A  58 "
   model   vdw
   3.622 2.752
nonbonded pdb=" N   SER A  66 "
          pdb=" O   SER A  66 "
   model   vdw
   3.623 2.496
nonbonded pdb=" O   GLN A  31 "
          pdb=" CA  LYS A  46 "
   model   vdw
   3.623 3.470
nonbonded pdb=" N   TYR A  26 "
          pdb=" N   SER A  27 "
   model   vdw
   3.623 2.560
nonbonded pdb=" O   TYR A  41 "
          pdb=" CD  PRO A  42 "
   model   vdw
   3.623 2.752
nonbonded pdb=" OG  SER A  67 "
          pdb=" CA  ARG A  82 "
   model   vdw
   3.623 3.470
nonbonded pdb=" OG  SER A  67 "
          pdb=" CB  ARG A  82 "
   model   vdw
   3.624 3.440
nonbonded pdb=" N   SER A  75 "
          pdb=" N   LEU A  76 "
   model   vdw
   3.624 2.560
nonbonded pdb=" O   GLY A  23 "
          pdb=" O   LYS A  24 "
   model   vdw
   3.624 3.040
nonbonded pdb=" NE2 GLN A  10 "
          pdb=" CA  CYS A  33 "
   model   vdw
   3.624 3.550
nonbonded pdb=" O   LYS A   7 "
          pdb=" CD  PRO A   8 "
   model   vdw
   3.624 2.752
nonbonded pdb=" CG  LEU A  44 "
          pdb=" N   VAL A  45 "
   model   vdw
   3.624 3.550
nonbonded pdb=" N   ALA A  11 "
          pdb=" O   ALA A  11 "
   model   vdw
   3.624 2.496
nonbonded pdb=" OH  TYR A  26 "
          pdb="O    HOH S  14 "
   model   vdw sym.op.
   3.624 3.040 x,y-1,z
nonbonded pdb=" C   ASP A  79 "
          pdb=" C   ARG A  80 "
   model   vdw
   3.625 2.800
nonbonded pdb=" N   SER A  17 "
          pdb=" N   GLY A  18 "
   model   vdw
   3.625 2.560
nonbonded pdb=" CD1 TYR A  41 "
          pdb=" OH  TYR A  41 "
   model   vdw
   3.625 2.672
nonbonded pdb=" N   ASP A  50 "
          pdb=" N   GLU A  51 "
   model   vdw
   3.625 2.560
nonbonded pdb=" CG  GLU A   5 "
          pdb=" CE  LYS A   7 "
   model   vdw
   3.626 3.840
nonbonded pdb=" C   VAL A  43 "
          pdb=" CB  LEU A  44 "
   model   vdw
   3.626 2.936
nonbonded pdb=" CA  LYS A  69 "
          pdb="O    HOH S  16 "
   model   vdw
   3.626 3.470
nonbonded pdb=" C   GLN A  53 "
          pdb=" CB  PRO A  54 "
   model   vdw
   3.626 2.936
nonbonded pdb=" N   GLY A  59 "
          pdb=" N   LEU A  60 "
   model   vdw
   3.626 2.560
nonbonded pdb=" O   LEU A  76 "
          pdb=" CB  MSE A  77 "
   model   vdw
   3.627 3.440
nonbonded pdb=" NE2 GLN A  10 "
          pdb=" CB  LEU A  32 "
   model   vdw
   3.627 3.520
nonbonded pdb=" N   TYR A  61 "
          pdb=" N   THR A  62 "
   model   vdw
   3.627 2.560
nonbonded pdb=" O   VAL A  35 "
          pdb=" C   PRO A  42 "
   model   vdw
   3.627 3.270
nonbonded pdb=" CG2 THR A  14 "
          pdb="O    HOH S 151 "
   model   vdw
   3.628 3.460
nonbonded pdb=" CA  SER A   9 "
          pdb="O    HOH S  34 "
   model   vdw sym.op.
   3.628 3.470 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CD2 TYR A  26 "
          pdb=" OH  TYR A  26 "
   model   vdw
   3.628 2.672
nonbonded pdb=" CG1 VAL A  70 "
          pdb=" N   GLY A  71 "
   model   vdw
   3.628 3.540
nonbonded pdb=" C   PHE A  68 "
          pdb=" C   LYS A  69 "
   model   vdw
   3.628 2.800
nonbonded pdb=" O   ARG A  21 "
          pdb=" CG  ARG A  21 "
   model   vdw
   3.628 3.440
nonbonded pdb=" O   GLN A  53 "
          pdb=" CD  PRO A  54 "
   model   vdw
   3.628 2.752
nonbonded pdb=" C   LYS A   7 "
          pdb=" CB  PRO A   8 "
   model   vdw
   3.629 2.936
nonbonded pdb=" CB  HIS A  64 "
          pdb=" CE1 HIS A  64 "
   model   vdw
   3.629 2.928
nonbonded pdb=" O   LYS A  69 "
          pdb=" N   GLY A  71 "
   model   vdw
   3.629 3.120
nonbonded pdb=" C   SER A  20 "
          pdb=" CB  ARG A  21 "
   model   vdw
   3.630 2.936
nonbonded pdb=" C   LEU A  37 "
          pdb=" CD2 LEU A  65 "
   model   vdw sym.op.
   3.630 3.690 -x+1,y,-z+2
nonbonded pdb=" C   GLN A  53 "
          pdb=" CG  PRO A  54 "
   model   vdw
   3.630 2.936
nonbonded pdb=" CB  GLU A  51 "
          pdb=" OE2 GLU A  51 "
   model   vdw
   3.631 2.752
nonbonded pdb=" N   LEU A  32 "
          pdb=" N   CYS A  33 "
   model   vdw
   3.631 2.560
nonbonded pdb=" N   ASN A  39 "
          pdb=" OD1 ASN A  39 "
   model   vdw
   3.631 3.120
nonbonded pdb=" O   ASP A  79 "
          pdb=" CG  ASP A  79 "
   model   vdw
   3.631 3.270
nonbonded pdb=" C   ALA A  57 "
          pdb=" CB  PRO A  58 "
   model   vdw
   3.632 2.936
nonbonded pdb=" CA  LEU A  28 "
          pdb="O    HOH S  33 "
   model   vdw
   3.632 3.470
nonbonded pdb=" O   LEU A  65 "
          pdb=" CD2 PHE A  68 "
   model   vdw
   3.633 3.340
nonbonded pdb=" N   MSE A  77 "
          pdb=" N   ILE A  78 "
   model   vdw
   3.633 2.560
nonbonded pdb=" O   LYS A  69 "
          pdb=" CA  LEU A  76 "
   model   vdw
   3.633 3.470
nonbonded pdb=" CG  LYS A  24 "
          pdb=" CD  PRO A  25 "
   model   vdw
   3.633 3.840
nonbonded pdb=" N   LEU A  32 "
          pdb=" CD1 LEU A  32 "
   model   vdw
   3.634 3.540
nonbonded pdb=" N   CYS A  33 "
          pdb=" N   TYR A  34 "
   model   vdw
   3.634 2.560
nonbonded pdb=" N   GLN A  12 "
          pdb=" N   PHE A  13 "
   model   vdw
   3.634 2.560
nonbonded pdb=" CD  PRO A   8 "
          pdb="O    HOH S  51 "
   model   vdw
   3.635 3.440
nonbonded pdb=" C   GLY A  74 "
          pdb=" CB  SER A  75 "
   model   vdw
   3.635 2.936
nonbonded pdb=" CG2 THR A  48 "
          pdb=" O   LEU A  49 "
   model   vdw
   3.636 3.460
nonbonded pdb=" C   TYR A  41 "
          pdb=" CB  PRO A  42 "
   model   vdw
   3.636 2.936
nonbonded pdb=" O   ILE A  47 "
          pdb=" C   THR A  48 "
   model   vdw
   3.637 3.270
nonbonded pdb=" O   ASN A  29 "
          pdb=" C   THR A  48 "
   model   vdw
   3.638 3.270
nonbonded pdb=" C   VAL A  84 "
          pdb=" CG  PRO A  85 "
   model   vdw
   3.638 2.936
nonbonded pdb=" CB  VAL A  70 "
          pdb="O    HOH S  16 "
   model   vdw
   3.638 3.470
nonbonded pdb=" CG  ASP A  79 "
          pdb="O    HOH S 160 "
   model   vdw
   3.638 3.270
nonbonded pdb=" CD2 TYR A  61 "
          pdb=" OH  TYR A  61 "
   model   vdw
   3.639 2.672
nonbonded pdb=" CE1 TYR A  26 "
          pdb=" CG  PRO A  85 "
   model   vdw sym.op.
   3.639 3.740 x,y-1,z
nonbonded pdb=" CD1 TYR A  56 "
          pdb=" OH  TYR A  56 "
   model   vdw
   3.639 2.672
nonbonded pdb=" OE1 GLN A  10 "
          pdb=" O   LEU A  32 "
   model   vdw
   3.639 3.040
nonbonded pdb=" N   GLY A  18 "
          pdb=" N   VAL A  19 "
   model   vdw
   3.639 2.560
nonbonded pdb=" C   GLN A  31 "
          pdb=" CB  LEU A  32 "
   model   vdw
   3.640 2.936
nonbonded pdb=" CB  ILE A   6 "
          pdb=" O   ALA A  57 "
   model   vdw
   3.640 3.470
nonbonded pdb=" CD1 TYR A  34 "
          pdb=" OH  TYR A  34 "
   model   vdw
   3.640 2.672
nonbonded pdb=" CE1 HIS A  64 "
          pdb=" OG  SER A  66 "
   model   vdw
   3.640 3.260
nonbonded pdb=" CD1 TYR A  61 "
          pdb=" OH  TYR A  61 "
   model   vdw
   3.640 2.672
nonbonded pdb=" O   TYR A  61 "
          pdb=" CE1 PHE A  73 "
   model   vdw sym.op.
   3.640 3.340 -x+1,y+1,-z+2
nonbonded pdb=" C   HIS A  64 "
          pdb="O    HOH S  35 "
   model   vdw
   3.641 3.270
nonbonded pdb=" N   ALA A  57 "
          pdb=" N   PRO A  58 "
   model   vdw
   3.641 2.560
nonbonded pdb=" N   LYS A   7 "
          pdb=" N   PRO A   8 "
   model   vdw
   3.642 2.560
nonbonded pdb=" C   PRO A   8 "
          pdb=" CD  PRO A   8 "
   model   vdw
   3.642 2.936
nonbonded pdb=" CE1 PHE A  13 "
          pdb=" OG1 THR A  15 "
   model   vdw
   3.642 3.340
nonbonded pdb=" C   GLU A   5 "
          pdb=" O   GLY A  59 "
   model   vdw
   3.642 3.270
nonbonded pdb=" CD2 TYR A  56 "
          pdb=" OH  TYR A  56 "
   model   vdw
   3.642 2.672
nonbonded pdb=" CA  LEU A  32 "
          pdb="O    HOH S   7 "
   model   vdw
   3.643 3.470
nonbonded pdb=" C   PHE A  13 "
          pdb=" O   GLU A  30 "
   model   vdw
   3.643 3.270
nonbonded pdb=" CD2 TYR A  34 "
          pdb=" OH  TYR A  34 "
   model   vdw
   3.643 2.672
nonbonded pdb=" O   LEU A  49 "
          pdb=" NH1 ARG A  80 "
   model   vdw
   3.644 3.120
nonbonded pdb=" CB  THR A  15 "
          pdb=" CA  SER A   9 "
   model   vdw sym.op.
   3.644 3.900 -x+1/2,y-1/2,-z+1
nonbonded pdb=" CA  SER A   9 "
          pdb=" CB  THR A  15 "
   model   vdw sym.op.
   3.644 3.900 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CZ  TYR A  34 "
          pdb="O    HOH S  24 "
   model   vdw
   3.644 3.260
nonbonded pdb=" N   ASN A  39 "
          pdb="O    HOH S 123 "
   model   vdw
   3.645 3.120
nonbonded pdb=" CB  GLN A  10 "
          pdb=" N   ALA A  11 "
   model   vdw
   3.645 2.816
nonbonded pdb=" CB  LEU A  37 "
          pdb=" N   GLY A  38 "
   model   vdw
   3.645 2.816
nonbonded pdb=" N   GLY A  23 "
          pdb=" O   GLY A  23 "
   model   vdw
   3.646 2.496
nonbonded pdb=" C   THR A  14 "
          pdb="O    HOH S   8 "
   model   vdw
   3.646 3.270
nonbonded pdb=" CG  ARG A  21 "
          pdb=" NH1 ARG A  21 "
   model   vdw
   3.646 3.520
nonbonded pdb=" C   LYS A  69 "
          pdb=" CB  VAL A  70 "
   model   vdw
   3.646 2.960
nonbonded pdb=" O   VAL A   4 "
          pdb=" C   LEU A  60 "
   model   vdw
   3.647 3.270
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" O   LYS A   7 "
   model   vdw
   3.648 3.460
nonbonded pdb=" O   LEU A  60 "
          pdb=" CG  TYR A  61 "
   model   vdw
   3.648 3.260
nonbonded pdb=" N   PRO A  54 "
          pdb=" N   ALA A  55 "
   model   vdw
   3.649 2.560
nonbonded pdb=" C   VAL A  84 "
          pdb=" CB  PRO A  85 "
   model   vdw
   3.649 2.936
nonbonded pdb=" O   CYS A  33 "
          pdb=" C   LEU A  44 "
   model   vdw
   3.649 3.270
nonbonded pdb=" O   PRO A   8 "
          pdb=" CA  THR A  14 "
   model   vdw sym.op.
   3.650 3.470 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CD  GLN A  10 "
          pdb=" O   LEU A  32 "
   model   vdw
   3.650 3.270
nonbonded pdb=" O   SER A  67 "
          pdb=" C   PHE A  68 "
   model   vdw
   3.651 3.270
nonbonded pdb=" C   THR A  15 "
          pdb=" O   LEU A  28 "
   model   vdw
   3.651 3.270
nonbonded pdb=" CA  LEU A  37 "
          pdb="O    HOH S   3 "
   model   vdw
   3.652 3.470
nonbonded pdb=" NE2 GLN A  72 "
          pdb="O    HOH S   2 "
   model   vdw sym.op.
   3.652 3.120 -x+1,y-1,-z+2
nonbonded pdb=" CB  ARG A  21 "
          pdb=" CZ  ARG A  21 "
   model   vdw
   3.652 3.670
nonbonded pdb=" CG  TYR A  34 "
          pdb=" CE2 TYR A  41 "
   model   vdw sym.op.
   3.652 3.560 -x+1,y,-z+1
nonbonded pdb=" CE2 TYR A  41 "
          pdb=" CG  TYR A  34 "
   model   vdw sym.op.
   3.652 3.560 -x+1,y,-z+1
nonbonded pdb=" CB  LYS A   7 "
          pdb=" CE  LYS A   7 "
   model   vdw
   3.652 3.072
nonbonded pdb=" C   VAL A  45 "
          pdb=" O   LYS A  46 "
   model   vdw
   3.653 3.270
nonbonded pdb=" C   GLU A  40 "
          pdb="O    HOH S 123 "
   model   vdw
   3.653 3.270
nonbonded pdb=" CB  GLU A  30 "
          pdb=" OE2 GLU A  30 "
   model   vdw
   3.654 2.752
nonbonded pdb=" C   VAL A  19 "
          pdb=" CB  SER A  20 "
   model   vdw
   3.654 2.936
nonbonded pdb=" CA  ARG A  80 "
          pdb="O    HOH S 106 "
   model   vdw
   3.655 3.470
nonbonded pdb=" CG2 ILE A  47 "
          pdb=" CB  LEU A  81 "
   model   vdw
   3.655 3.860
nonbonded pdb=" O   VAL A  43 "
          pdb=" N   VAL A  45 "
   model   vdw
   3.656 3.120
nonbonded pdb=" O   HIS A  64 "
          pdb=" O   LEU A  65 "
   model   vdw
   3.656 3.040
nonbonded pdb=" N   SER A  17 "
          pdb=" OG  SER A  17 "
   model   vdw
   3.656 2.496
nonbonded pdb=" CB  ALA A  57 "
          pdb="O    HOH S  14 "
   model   vdw
   3.656 3.460
nonbonded pdb=" CG  PRO A   8 "
          pdb="O    HOH S 110 "
   model   vdw sym.op.
   3.656 3.440 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CE  LYS A  24 "
          pdb=" NE  ARG A  82 "
   model   vdw sym.op.
   3.657 3.520 -x+1/2,y-1/2,-z+2
nonbonded pdb=" NE  ARG A  82 "
          pdb=" CE  LYS A  24 "
   model   vdw sym.op.
   3.657 3.520 -x+1/2,y+1/2,-z+2
nonbonded pdb=" C   SER A   9 "
          pdb=" CG  GLN A  10 "
   model   vdw
   3.657 3.670
nonbonded pdb=" N   ASN A  39 "
          pdb=" N   GLU A  40 "
   model   vdw
   3.657 2.560
nonbonded pdb=" N   GLY A  71 "
          pdb=" N   GLN A  72 "
   model   vdw
   3.657 2.560
nonbonded pdb=" CG  LYS A   7 "
          pdb=" CD  GLU A  40 "
   model   vdw sym.op.
   3.658 3.670 -x+1,y,-z+1
nonbonded pdb=" CA  ASP A  79 "
          pdb=" OD2 ASP A  79 "
   model   vdw
   3.658 2.776
nonbonded pdb=" SG  CYS A  33 "
          pdb=" N   TYR A  34 "
   model   vdw
   3.658 3.480
nonbonded pdb=" N   SER A  27 "
          pdb=" OG  SER A  27 "
   model   vdw
   3.658 2.496
nonbonded pdb=" CA  ILE A   6 "
          pdb=" OE1 GLN A  10 "
   model   vdw
   3.661 3.470
nonbonded pdb=" CA  ASN A  39 "
          pdb="O    HOH S   3 "
   model   vdw
   3.661 3.470
nonbonded pdb=" C   VAL A  35 "
          pdb=" N   LEU A  37 "
   model   vdw
   3.662 3.350
nonbonded pdb=" N   SER A  20 "
          pdb=" N   ARG A  21 "
   model   vdw
   3.662 2.560
nonbonded pdb=" CD  ARG A  82 "
          pdb=" NH2 ARG A  82 "
   model   vdw
   3.662 2.816
nonbonded pdb=" C   VAL A  35 "
          pdb=" CB  ASP A  36 "
   model   vdw
   3.664 2.936
nonbonded pdb=" CD  ARG A  80 "
          pdb=" NH2 ARG A  80 "
   model   vdw
   3.664 2.816
nonbonded pdb=" O   TYR A  61 "
          pdb=" CB  THR A  62 "
   model   vdw
   3.664 3.470
nonbonded pdb=" CD  ARG A  16 "
          pdb=" NH2 ARG A  16 "
   model   vdw
   3.664 2.816
nonbonded pdb=" N   THR A  14 "
          pdb="O    HOH S 151 "
   model   vdw
   3.665 3.120
nonbonded pdb=" CD2 TYR A  61 "
          pdb=" N   PRO A  85 "
   model   vdw
   3.666 3.420
nonbonded pdb=" C   ARG A  82 "
          pdb=" O   LEU A  83 "
   model   vdw
   3.666 3.270
nonbonded pdb=" N   GLY A  38 "
          pdb=" CD2 LEU A  65 "
   model   vdw sym.op.
   3.666 3.540 -x+1,y,-z+2
nonbonded pdb=" C   PRO A  54 "
          pdb="O    HOH S  44 "
   model   vdw
   3.666 3.270
nonbonded pdb=" CD  ARG A  21 "
          pdb=" NH2 ARG A  21 "
   model   vdw
   3.667 2.816
nonbonded pdb=" O   THR A  48 "
          pdb=" N   ASP A  50 "
   model   vdw
   3.667 3.120
nonbonded pdb=" C   SER A  27 "
          pdb=" CG  LEU A  28 "
   model   vdw
   3.668 3.700
nonbonded pdb=" C   THR A  62 "
          pdb=" O   VAL A  63 "
   model   vdw
   3.668 3.270
nonbonded pdb=" CD  LYS A   7 "
          pdb=" CD  GLU A  40 "
   model   vdw sym.op.
   3.668 3.670 -x+1,y,-z+1
nonbonded pdb=" O   GLN A  10 "
          pdb=" CD  GLN A  31 "
   model   vdw
   3.668 3.270
nonbonded pdb=" C   PRO A  58 "
          pdb=" C   GLY A  59 "
   model   vdw
   3.668 2.800
nonbonded pdb=" C   THR A  62 "
          pdb=" CB  VAL A  63 "
   model   vdw
   3.669 2.960
nonbonded pdb=" C   GLY A  38 "
          pdb=" CB  ASN A  39 "
   model   vdw
   3.669 2.936
nonbonded pdb=" C   ARG A  16 "
          pdb="O    HOH S  34 "
   model   vdw
   3.669 3.270
nonbonded pdb=" C   ARG A  80 "
          pdb=" O   LEU A  81 "
   model   vdw
   3.670 3.270
nonbonded pdb=" C   PHE A  68 "
          pdb=" O   MSE A  77 "
   model   vdw
   3.670 3.270
nonbonded pdb=" C   ILE A  47 "
          pdb="O    HOH S 106 "
   model   vdw
   3.670 3.270
nonbonded pdb=" CG1 VAL A  19 "
          pdb=" O   SER A  20 "
   model   vdw
   3.670 3.460
nonbonded pdb=" O   MSE A  77 "
          pdb=" C   ILE A  78 "
   model   vdw
   3.671 3.270
nonbonded pdb=" C   PRO A  58 "
          pdb=" CG  PRO A  58 "
   model   vdw
   3.671 2.936
nonbonded pdb=" C   THR A  14 "
          pdb=" OG1 THR A  15 "
   model   vdw
   3.672 3.270
nonbonded pdb=" C   PRO A  85 "
          pdb=" CD  PRO A  85 "
   model   vdw
   3.672 2.936
nonbonded pdb=" CB  HIS A  64 "
          pdb=" NE2 HIS A  64 "
   model   vdw
   3.673 2.816
nonbonded pdb=" C   LEU A  37 "
          pdb="O    HOH S   3 "
   model   vdw
   3.673 3.270
nonbonded pdb=" NH2 ARG A  16 "
          pdb=" OH  TYR A  61 "
   model   vdw sym.op.
   3.673 3.120 x,y-1,z
nonbonded pdb=" CA  ARG A  16 "
          pdb="O    HOH S  34 "
   model   vdw
   3.674 3.470
nonbonded pdb=" O   VAL A   4 "
          pdb=" C   TYR A  61 "
   model   vdw
   3.674 3.270
nonbonded pdb=" O   ASP A  36 "
          pdb=" C   LEU A  37 "
   model   vdw
   3.674 3.270
nonbonded pdb=" C   LEU A  32 "
          pdb=" C   CYS A  33 "
   model   vdw
   3.675 2.800
nonbonded pdb=" O   GLY A  23 "
          pdb=" N   PRO A  25 "
   model   vdw
   3.676 3.120
nonbonded pdb=" C   VAL A  63 "
          pdb=" CB  HIS A  64 "
   model   vdw
   3.676 2.936
nonbonded pdb=" CB  GLN A  22 "
          pdb=" NE2 GLN A  22 "
   model   vdw
   3.676 2.816
nonbonded pdb=" CB  GLU A  40 "
          pdb=" OE2 GLU A  40 "
   model   vdw
   3.676 2.752
nonbonded pdb=" O   PRO A  42 "
          pdb=" C   VAL A  43 "
   model   vdw
   3.676 3.270
nonbonded pdb=" CA  GLY A  18 "
          pdb="O    HOH S  14 "
   model   vdw sym.op.
   3.677 3.440 x,y-1,z
nonbonded pdb=" O   VAL A  35 "
          pdb=" CG1 VAL A  35 "
   model   vdw
   3.677 3.460
nonbonded pdb=" O   VAL A  70 "
          pdb=" CG1 VAL A  70 "
   model   vdw
   3.678 3.460
nonbonded pdb=" C   TYR A  56 "
          pdb=" CB  ALA A  57 "
   model   vdw
   3.678 2.952
nonbonded pdb=" C   ASP A  50 "
          pdb="O    HOH S 175 "
   model   vdw
   3.678 3.270
nonbonded pdb=" CB  GLN A  22 "
          pdb=" N   GLY A  23 "
   model   vdw
   3.678 2.816
nonbonded pdb=" N   ARG A  21 "
          pdb=" CG  ARG A  21 "
   model   vdw
   3.678 2.816
nonbonded pdb=" O   SER A  67 "
          pdb=" O   ARG A  80 "
   model   vdw
   3.679 3.040
nonbonded pdb=" C   VAL A  45 "
          pdb=" O   GLY A  74 "
   model   vdw sym.op.
   3.679 3.270 -x+1,y,-z+2
nonbonded pdb=" CA  LYS A  24 "
          pdb="O    HOH S  97 "
   model   vdw
   3.679 3.470
nonbonded pdb=" C   PRO A   8 "
          pdb=" CB  SER A   9 "
   model   vdw
   3.680 2.936
nonbonded pdb=" C   ARG A  16 "
          pdb=" O   SER A  17 "
   model   vdw
   3.680 3.270
nonbonded pdb=" CG1 VAL A  43 "
          pdb=" CG2 VAL A  70 "
   model   vdw sym.op.
   3.680 3.880 -x+1,y,-z+2
nonbonded pdb=" C   GLY A  23 "
          pdb="O    HOH S  97 "
   model   vdw
   3.681 3.270
nonbonded pdb=" CD2 TYR A  41 "
          pdb=" CZ  TYR A  34 "
   model   vdw sym.op.
   3.682 3.560 -x+1,y,-z+1
nonbonded pdb=" CZ  TYR A  34 "
          pdb=" CD2 TYR A  41 "
   model   vdw sym.op.
   3.682 3.560 -x+1,y,-z+1
nonbonded pdb=" CE1 PHE A  13 "
          pdb=" OD1 ASN A  29 "
   model   vdw
   3.683 3.340
nonbonded pdb=" O   GLY A  18 "
          pdb=" C   PRO A  25 "
   model   vdw
   3.683 3.270
nonbonded pdb=" C   GLN A  10 "
          pdb=" CB  ALA A  11 "
   model   vdw
   3.684 2.952
nonbonded pdb=" C   GLU A  30 "
          pdb=" O   ILE A  47 "
   model   vdw
   3.684 3.270
nonbonded pdb=" CD1 ILE A  47 "
          pdb=" CE2 TYR A  56 "
   model   vdw
   3.684 3.760
nonbonded pdb=" CB  GLU A   5 "
          pdb=" OE2 GLU A   5 "
   model   vdw
   3.684 2.752
nonbonded pdb=" CB  TYR A  56 "
          pdb=" OH  TYR A  61 "
   model   vdw
   3.684 3.440
nonbonded pdb=" CG  GLU A   5 "
          pdb=" O   GLY A  59 "
   model   vdw
   3.685 3.440
nonbonded pdb=" O   LEU A  44 "
          pdb=" CG2 VAL A  45 "
   model   vdw
   3.685 3.460
nonbonded pdb=" O   GLU A  30 "
          pdb=" CB  GLN A  31 "
   model   vdw
   3.686 3.440
nonbonded pdb=" O   GLU A   5 "
          pdb=" OE1 GLN A  10 "
   model   vdw
   3.687 3.040
nonbonded pdb=" CG  TYR A  26 "
          pdb=" N   SER A  27 "
   model   vdw
   3.687 3.340
nonbonded pdb=" CG  LYS A   7 "
          pdb=" OE1 GLU A  40 "
   model   vdw sym.op.
   3.687 3.440 -x+1,y,-z+1
nonbonded pdb=" O   PRO A  42 "
          pdb=" CG  PRO A  42 "
   model   vdw
   3.687 3.440
nonbonded pdb=" C   LEU A  60 "
          pdb="O    HOH S  54 "
   model   vdw
   3.687 3.270
nonbonded pdb=" O   ASN A  29 "
          pdb=" CB  LEU A  49 "
   model   vdw
   3.688 3.440
nonbonded pdb=" CA  ASP A  36 "
          pdb=" OD2 ASP A  36 "
   model   vdw
   3.688 2.776
nonbonded pdb=" C   SER A  17 "
          pdb=" C   GLY A  18 "
   model   vdw
   3.688 2.800
nonbonded pdb=" CD  GLN A  12 "
          pdb="O    HOH S 110 "
   model   vdw
   3.689 3.270
nonbonded pdb=" CD  GLU A   5 "
          pdb="O    HOH S  51 "
   model   vdw
   3.689 3.270
nonbonded pdb=" CB  PHE A  68 "
          pdb=" O   MSE A  77 "
   model   vdw
   3.689 3.440
nonbonded pdb=" N   ASP A  50 "
          pdb=" OD2 ASP A  50 "
   model   vdw
   3.691 3.120
nonbonded pdb=" O   GLU A   5 "
          pdb=" C   ILE A   6 "
   model   vdw
   3.691 3.270
nonbonded pdb=" CA  ARG A  21 "
          pdb=" CA  GLN A  22 "
   model   vdw
   3.691 3.120
nonbonded pdb=" C   LEU A  44 "
          pdb=" CG2 VAL A  45 "
   model   vdw
   3.691 3.690
nonbonded pdb=" C   PRO A  85 "
          pdb=" CG  PRO A  85 "
   model   vdw
   3.692 2.936
nonbonded pdb=" CD1 PHE A  68 "
          pdb=" CG1 ILE A  78 "
   model   vdw
   3.693 3.740
nonbonded pdb=" C   TYR A  34 "
          pdb=" CG2 VAL A  35 "
   model   vdw
   3.693 3.690
nonbonded pdb=" CD  GLN A  31 "
          pdb=" N   TYR A  56 "
   model   vdw
   3.693 3.350
nonbonded pdb=" O   THR A  14 "
          pdb=" O   GLU A  30 "
   model   vdw
   3.694 3.040
nonbonded pdb=" CG  GLN A  31 "
          pdb=" O   LEU A  32 "
   model   vdw
   3.694 3.440
nonbonded pdb=" C   SER A  75 "
          pdb=" CB  LEU A  76 "
   model   vdw
   3.694 2.936
nonbonded pdb=" CB  LEU A  65 "
          pdb="O    HOH S  35 "
   model   vdw
   3.694 3.440
nonbonded pdb=" O   THR A  62 "
          pdb=" C   LEU A  83 "
   model   vdw
   3.695 3.270
nonbonded pdb=" C   PRO A   8 "
          pdb=" CG  PRO A   8 "
   model   vdw
   3.695 2.936
nonbonded pdb=" C   GLY A  52 "
          pdb=" CB  GLN A  53 "
   model   vdw
   3.695 2.936
nonbonded pdb=" C   LYS A   7 "
          pdb=" N   GLN A  10 "
   model   vdw
   3.695 3.350
nonbonded pdb=" C   ASP A  50 "
          pdb=" CB  GLU A  51 "
   model   vdw
   3.696 2.936
nonbonded pdb=" N   LEU A  49 "
          pdb=" CD2 LEU A  49 "
   model   vdw
   3.696 3.540
nonbonded pdb=" C   ILE A   6 "
          pdb=" CB  LYS A   7 "
   model   vdw
   3.696 2.936
nonbonded pdb=" CB  ASN A  29 "
          pdb="O    HOH S  33 "
   model   vdw
   3.697 3.440
nonbonded pdb=" C   ALA A  11 "
          pdb=" O   GLN A  12 "
   model   vdw
   3.697 3.270
nonbonded pdb=" C   PRO A  54 "
          pdb=" CB  ALA A  55 "
   model   vdw
   3.698 2.952
nonbonded pdb=" CB  ALA A  55 "
          pdb="O    HOH S  44 "
   model   vdw
   3.698 3.460
nonbonded pdb=" O   THR A  62 "
          pdb=" N   HIS A  64 "
   model   vdw
   3.698 3.120
nonbonded pdb=" O   LEU A  83 "
          pdb=" CB  VAL A  84 "
   model   vdw
   3.699 3.470
nonbonded pdb=" CG  ARG A  21 "
          pdb="O    HOH S 135 "
   model   vdw sym.op.
   3.699 3.440 x,y-1,z
nonbonded pdb="O    HOH S 135 "
          pdb=" CG  ARG A  21 "
   model   vdw sym.op.
   3.699 3.440 x,y+1,z
nonbonded pdb=" C   LEU A  81 "
          pdb=" CG  ARG A  82 "
   model   vdw
   3.699 3.670
nonbonded pdb=" C   PRO A  42 "
          pdb=" O   VAL A  43 "
   model   vdw
   3.699 3.270
nonbonded pdb=" C   LEU A  65 "
          pdb=" CB  SER A  66 "
   model   vdw
   3.700 2.936
nonbonded pdb=" OD1 ASP A  79 "
          pdb=" N   ARG A  80 "
   model   vdw
   3.700 3.120
nonbonded pdb=" OG  SER A  20 "
          pdb=" CA  LYS A  24 "
   model   vdw
   3.700 3.470
nonbonded pdb=" C   SER A  75 "
          pdb="O    HOH S  10 "
   model   vdw sym.op.
   3.701 3.270 -x+1,y,-z+2
nonbonded pdb=" C   PHE A  13 "
          pdb=" O   THR A  14 "
   model   vdw
   3.701 3.270
nonbonded pdb=" C   ASP A  36 "
          pdb="O    HOH S   2 "
   model   vdw
   3.702 3.270
nonbonded pdb=" O   LYS A   3 "
          pdb=" C   VAL A  35 "
   model   vdw
   3.703 3.270
nonbonded pdb=" C   ARG A  80 "
          pdb=" CB  LEU A  81 "
   model   vdw
   3.703 2.936
nonbonded pdb=" C   GLY A  71 "
          pdb=" CB  GLN A  72 "
   model   vdw
   3.703 2.936
nonbonded pdb=" O   GLY A  23 "
          pdb=" CD  PRO A  25 "
   model   vdw
   3.703 3.440
nonbonded pdb=" C   THR A  48 "
          pdb=" CB  LEU A  49 "
   model   vdw
   3.704 2.936
nonbonded pdb=" N   THR A  62 "
          pdb=" OG1 THR A  62 "
   model   vdw
   3.704 2.496
nonbonded pdb=" C   SER A  66 "
          pdb=" CB  SER A  67 "
   model   vdw
   3.704 2.936
nonbonded pdb=" N   SER A   9 "
          pdb=" OE2 GLU A  40 "
   model   vdw sym.op.
   3.704 3.120 -x+1,y,-z+1
nonbonded pdb=" NH2 ARG A  16 "
          pdb=" CE1 TYR A  61 "
   model   vdw sym.op.
   3.704 3.420 x,y-1,z
nonbonded pdb=" C   LEU A  49 "
          pdb=" CB  ASP A  50 "
   model   vdw
   3.705 2.936
nonbonded pdb=" C   HIS A  64 "
          pdb=" CB  LEU A  65 "
   model   vdw
   3.706 2.936
nonbonded pdb=" C   ARG A  80 "
          pdb="O    HOH S 106 "
   model   vdw
   3.706 3.270
nonbonded pdb=" C   ALA A  55 "
          pdb=" CB  TYR A  56 "
   model   vdw
   3.707 2.936
nonbonded pdb=" CB  GLN A  53 "
          pdb=" NE2 GLN A  53 "
   model   vdw
   3.707 2.816
nonbonded pdb=" CE1 PHE A  13 "
          pdb=" ND2 ASN A  29 "
   model   vdw
   3.707 3.420
nonbonded pdb=" CB  LEU A  81 "
          pdb="O    HOH S 106 "
   model   vdw
   3.708 3.440
nonbonded pdb=" C   ILE A  78 "
          pdb=" CB  ASP A  79 "
   model   vdw
   3.708 2.936
nonbonded pdb=" CG2 ILE A  47 "
          pdb=" CD2 LEU A  81 "
   model   vdw
   3.708 3.880
nonbonded pdb=" O   GLN A  22 "
          pdb=" C   GLY A  23 "
   model   vdw
   3.708 3.270
nonbonded pdb=" N   SER A  20 "
          pdb=" C   LYS A  24 "
   model   vdw
   3.709 3.350
nonbonded pdb=" C   ASN A  39 "
          pdb=" CB  GLU A  40 "
   model   vdw
   3.709 2.936
nonbonded pdb=" OD2 ASP A  50 "
          pdb=" CZ  ARG A  82 "
   model   vdw
   3.710 3.270
nonbonded pdb=" CG1 VAL A  84 "
          pdb=" O   PRO A  85 "
   model   vdw
   3.712 3.460
nonbonded pdb=" O   PRO A  25 "
          pdb=" CB  TYR A  26 "
   model   vdw
   3.713 3.440
nonbonded pdb=" CG2 THR A  48 "
          pdb=" CZ  ARG A  80 "
   model   vdw
   3.713 3.690
nonbonded pdb=" CB  GLN A  12 "
          pdb="O    HOH S 110 "
   model   vdw
   3.713 3.440
nonbonded pdb=" NE2 GLN A  10 "
          pdb=" C   LEU A  32 "
   model   vdw
   3.713 3.350
nonbonded pdb=" NZ  LYS A   3 "
          pdb=" O   GLN A  72 "
   model   vdw sym.op.
   3.715 3.120 -x+1,y+1,-z+2
nonbonded pdb=" CG  LYS A  24 "
          pdb=" O   PRO A  25 "
   model   vdw
   3.715 3.440
nonbonded pdb=" O   SER A  67 "
          pdb=" CG2 ILE A  78 "
   model   vdw
   3.716 3.460
nonbonded pdb=" C   PHE A  13 "
          pdb=" CG2 THR A  14 "
   model   vdw
   3.716 3.690
nonbonded pdb=" OD1 ASP A  50 "
          pdb=" CZ  ARG A  82 "
   model   vdw
   3.716 3.270
nonbonded pdb=" CD2 HIS A  64 "
          pdb=" N   LEU A  65 "
   model   vdw
   3.716 3.340
nonbonded pdb=" CA  ASN A  29 "
          pdb=" ND2 ASN A  29 "
   model   vdw
   3.717 2.840
nonbonded pdb=" CG  ASN A  39 "
          pdb="O    HOH S   3 "
   model   vdw
   3.717 3.270
nonbonded pdb=" O   GLY A  59 "
          pdb=" C   LEU A  60 "
   model   vdw
   3.718 3.270
nonbonded pdb=" N   GLY A  18 "
          pdb=" CE1 TYR A  26 "
   model   vdw
   3.718 3.420
nonbonded pdb=" CG  LYS A   3 "
          pdb=" NZ  LYS A   3 "
   model   vdw
   3.718 2.816
nonbonded pdb=" C   ILE A   6 "
          pdb=" OE1 GLN A  10 "
   model   vdw
   3.718 3.270
nonbonded pdb=" OH  TYR A  61 "
          pdb="O    HOH S  85 "
   model   vdw sym.op.
   3.718 3.040 x,y+1,z
nonbonded pdb=" CA  SER A  20 "
          pdb=" CA  ARG A  21 "
   model   vdw
   3.718 3.120
nonbonded pdb=" CZ  TYR A  56 "
          pdb=" N   LEU A  83 "
   model   vdw
   3.719 3.340
nonbonded pdb=" O   VAL A  19 "
          pdb=" CG1 VAL A  19 "
   model   vdw
   3.719 3.460
nonbonded pdb=" CG  LYS A  69 "
          pdb=" N   VAL A  70 "
   model   vdw
   3.719 3.520
nonbonded pdb=" O   HIS A  64 "
          pdb=" CA  SER A  67 "
   model   vdw
   3.720 3.470
nonbonded pdb=" O   GLN A  72 "
          pdb=" C   PHE A  73 "
   model   vdw
   3.720 3.270
nonbonded pdb=" CD  GLU A  30 "
          pdb=" NZ  LYS A  46 "
   model   vdw
   3.721 3.350
nonbonded pdb=" C   SER A  67 "
          pdb=" CG  PHE A  68 "
   model   vdw
   3.723 3.490
nonbonded pdb=" CB  LYS A  24 "
          pdb=" CE  LYS A  24 "
   model   vdw
   3.723 3.072
nonbonded pdb=" CE1 PHE A  68 "
          pdb=" CE1 PHE A  68 "
   model   vdw sym.op.
   3.724 3.640 -x+1,y,-z+2
nonbonded pdb=" CD2 PHE A  13 "
          pdb=" CB  ALA A  55 "
   model   vdw
   3.724 3.760
nonbonded pdb=" C   LEU A  28 "
          pdb="O    HOH S  33 "
   model   vdw
   3.724 3.270
nonbonded pdb=" O   LEU A  81 "
          pdb=" C   ARG A  82 "
   model   vdw
   3.725 3.270
nonbonded pdb=" CD  GLU A   5 "
          pdb=" CD2 LEU A  60 "
   model   vdw
   3.725 3.690
nonbonded pdb=" N   LYS A  24 "
          pdb=" CG  LYS A  24 "
   model   vdw
   3.725 2.816
nonbonded pdb=" O   GLU A  40 "
          pdb=" CD1 TYR A  41 "
   model   vdw
   3.725 3.340
nonbonded pdb=" CG  ARG A  80 "
          pdb=" CZ  ARG A  80 "
   model   vdw
   3.725 2.936
nonbonded pdb="SE    SE Z   3 "
          pdb=" CA  MSE A  77 "
   model   vdw sym.op.
   3.725 3.850 -x+1/2,y-3/2,-z+1
nonbonded pdb=" CA  MSE A  77 "
          pdb="SE    SE Z   3 "
   model   vdw sym.op.
   3.725 3.850 -x+1/2,y+3/2,-z+1
nonbonded pdb=" C   SER A  67 "
          pdb=" O   PHE A  68 "
   model   vdw
   3.727 3.270
nonbonded pdb=" OD1 ASP A  79 "
          pdb="O    HOH S  97 "
   model   vdw sym.op.
   3.728 3.040 -x+1/2,y+1/2,-z+2
nonbonded pdb=" CB  GLN A  31 "
          pdb=" NE2 GLN A  31 "
   model   vdw
   3.728 2.816
nonbonded pdb=" OE1 GLN A  12 "
          pdb=" O   PRO A  58 "
   model   vdw sym.op.
   3.730 3.040 -x+1/2,y-1/2,-z+1
nonbonded pdb=" C   TYR A  56 "
          pdb="O    HOH S  14 "
   model   vdw
   3.732 3.270
nonbonded pdb=" C   ILE A  78 "
          pdb=" N   ARG A  80 "
   model   vdw
   3.732 3.350
nonbonded pdb=" O   LEU A  44 "
          pdb=" CG  LEU A  44 "
   model   vdw
   3.733 3.470
nonbonded pdb=" O   GLU A   5 "
          pdb=" C   CYS A  33 "
   model   vdw
   3.733 3.270
nonbonded pdb=" SG  CYS A  33 "
          pdb=" O   VAL A  45 "
   model   vdw
   3.733 3.400
nonbonded pdb=" OE1 GLN A  53 "
          pdb=" CZ  TYR A  56 "
   model   vdw
   3.734 3.260
nonbonded pdb=" O   GLN A  31 "
          pdb=" C   LYS A  46 "
   model   vdw
   3.734 3.270
nonbonded pdb=" O   LYS A  46 "
          pdb=" CB  ILE A  47 "
   model   vdw
   3.734 3.470
nonbonded pdb=" O   ASP A  36 "
          pdb=" OD1 ASP A  36 "
   model   vdw
   3.734 3.040
nonbonded pdb=" O   PRO A   8 "
          pdb=" CB  ALA A  11 "
   model   vdw
   3.734 3.460
nonbonded pdb=" O   PRO A  42 "
          pdb=" CD  PRO A  42 "
   model   vdw
   3.735 3.440
nonbonded pdb=" C   GLN A  53 "
          pdb=" CG  GLN A  53 "
   model   vdw
   3.736 2.936
nonbonded pdb=" O   ASP A  36 "
          pdb=" N   GLY A  38 "
   model   vdw
   3.737 3.120
nonbonded pdb=" OD2 ASP A  50 "
          pdb=" NH2 ARG A  82 "
   model   vdw
   3.738 3.120
nonbonded pdb=" CG1 ILE A   6 "
          pdb=" CE1 TYR A  61 "
   model   vdw
   3.738 3.740
nonbonded pdb=" CG  ARG A  16 "
          pdb=" CZ  ARG A  16 "
   model   vdw
   3.739 2.936
nonbonded pdb=" CA  LYS A   7 "
          pdb=" OE1 GLN A  10 "
   model   vdw
   3.739 3.470
nonbonded pdb=" O   ARG A  16 "
          pdb=" CA  SER A  27 "
   model   vdw
   3.739 3.470
nonbonded pdb=" C   GLN A  72 "
          pdb=" CG  PHE A  73 "
   model   vdw
   3.739 3.490
nonbonded pdb=" O   PRO A   8 "
          pdb=" C   THR A  14 "
   model   vdw sym.op.
   3.739 3.270 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CZ  TYR A  34 "
          pdb=" CD1 LEU A  44 "
   model   vdw
   3.739 3.680
nonbonded pdb=" N   VAL A  45 "
          pdb=" CG1 VAL A  45 "
   model   vdw
   3.740 2.832
nonbonded pdb=" C   LYS A  69 "
          pdb="O    HOH S  16 "
   model   vdw
   3.740 3.270
nonbonded pdb=" O   TYR A  41 "
          pdb=" N   VAL A  43 "
   model   vdw
   3.740 3.120
nonbonded pdb=" O   PHE A  13 "
          pdb=" C   THR A  14 "
   model   vdw
   3.741 3.270
nonbonded pdb=" CB  PRO A   8 "
          pdb="O    HOH S 117 "
   model   vdw sym.op.
   3.741 3.440 -x+1/2,y+1/2,-z+1
nonbonded pdb=" O   SER A  75 "
          pdb=" O   LEU A  76 "
   model   vdw
   3.741 3.040
nonbonded pdb=" CB  GLN A  72 "
          pdb=" NE2 GLN A  72 "
   model   vdw
   3.741 2.816
nonbonded pdb=" O   LYS A  46 "
          pdb=" CG  LYS A  46 "
   model   vdw
   3.741 3.440
nonbonded pdb=" CD  LYS A   7 "
          pdb=" CD  PRO A   8 "
   model   vdw
   3.742 3.840
nonbonded pdb=" N   GLY A  74 "
          pdb="O    HOH S   4 "
   model   vdw
   3.742 3.120
nonbonded pdb=" O   GLY A  59 "
          pdb=" CD1 TYR A  61 "
   model   vdw
   3.742 3.340
nonbonded pdb=" O   TYR A  34 "
          pdb=" C   VAL A  35 "
   model   vdw
   3.742 3.270
nonbonded pdb=" NE2 GLN A  31 "
          pdb=" CB  ALA A  55 "
   model   vdw
   3.743 3.540
nonbonded pdb=" O   LYS A  69 "
          pdb=" C   LEU A  76 "
   model   vdw
   3.743 3.270
nonbonded pdb=" C   SER A  20 "
          pdb=" O   ARG A  21 "
   model   vdw
   3.743 3.270
nonbonded pdb=" C   LYS A  69 "
          pdb=" CG2 VAL A  70 "
   model   vdw
   3.743 3.690
nonbonded pdb=" O   ILE A   6 "
          pdb=" O   GLY A  59 "
   model   vdw
   3.744 3.040
nonbonded pdb=" C   LEU A  49 "
          pdb="O    HOH S  33 "
   model   vdw
   3.744 3.270
nonbonded pdb=" CG1 VAL A  63 "
          pdb=" CB  SER A  67 "
   model   vdw
   3.745 3.860
nonbonded pdb=" O   PRO A   8 "
          pdb=" CA  THR A  15 "
   model   vdw sym.op.
   3.745 3.470 -x+1/2,y+1/2,-z+1
nonbonded pdb=" O   THR A  14 "
          pdb=" C   THR A  15 "
   model   vdw
   3.745 3.270
nonbonded pdb=" O   VAL A   4 "
          pdb=" CB  GLU A   5 "
   model   vdw
   3.745 3.440
nonbonded pdb=" O   PRO A   8 "
          pdb=" N   ALA A  11 "
   model   vdw
   3.746 3.120
nonbonded pdb=" C   LEU A  32 "
          pdb=" O   VAL A  45 "
   model   vdw
   3.746 3.270
nonbonded pdb=" CG  ASP A  50 "
          pdb=" NH2 ARG A  82 "
   model   vdw
   3.746 3.350
nonbonded pdb=" N   GLY A  18 "
          pdb=" CZ  TYR A  26 "
   model   vdw
   3.747 3.340
nonbonded pdb=" O   ALA A  11 "
          pdb=" CB  ALA A  55 "
   model   vdw
   3.747 3.460
nonbonded pdb=" OE1 GLN A  31 "
          pdb=" C   ALA A  55 "
   model   vdw
   3.747 3.270
nonbonded pdb=" O   GLU A  40 "
          pdb="O    HOH S 123 "
   model   vdw
   3.748 3.040
nonbonded pdb=" C   THR A  15 "
          pdb=" OG1 THR A  15 "
   model   vdw
   3.749 2.616
nonbonded pdb=" C   SER A  67 "
          pdb=" OG  SER A  67 "
   model   vdw
   3.750 2.616
nonbonded pdb=" CA  GLY A  23 "
          pdb=" CA  LYS A  24 "
   model   vdw
   3.750 3.096
nonbonded pdb=" OG  SER A  75 "
          pdb=" N   LEU A  76 "
   model   vdw
   3.750 3.120
nonbonded pdb=" CD  GLN A  10 "
          pdb=" CA  CYS A  33 "
   model   vdw
   3.751 3.700
nonbonded pdb=" CB  THR A  15 "
          pdb=" OD1 ASN A  29 "
   model   vdw
   3.752 3.470
nonbonded pdb=" O   VAL A  63 "
          pdb="O    HOH S  12 "
   model   vdw
   3.753 3.040
nonbonded pdb=" CA  LEU A  44 "
          pdb=" CA  VAL A  45 "
   model   vdw
   3.753 3.120
nonbonded pdb=" C   ILE A  47 "
          pdb=" OG1 THR A  48 "
   model   vdw
   3.754 3.270
nonbonded pdb=" C   SER A  17 "
          pdb="O    HOH S  85 "
   model   vdw
   3.754 3.270
nonbonded pdb=" OG1 THR A  14 "
          pdb=" O   GLU A  30 "
   model   vdw
   3.756 3.040
nonbonded pdb=" CA  LYS A  24 "
          pdb=" CA  PRO A  25 "
   model   vdw
   3.756 3.120
nonbonded pdb=" O   THR A  15 "
          pdb=" C   ARG A  16 "
   model   vdw
   3.757 3.270
nonbonded pdb=" CB  GLU A   5 "
          pdb=" CD2 LEU A  60 "
   model   vdw
   3.757 3.860
nonbonded pdb=" O   LYS A   3 "
          pdb=" CG2 VAL A   4 "
   model   vdw
   3.758 3.460
nonbonded pdb=" O   GLY A  18 "
          pdb=" CB  VAL A  19 "
   model   vdw
   3.759 3.470
nonbonded pdb=" O   LEU A  44 "
          pdb=" CB  VAL A  45 "
   model   vdw
   3.759 3.470
nonbonded pdb=" CE1 TYR A  56 "
          pdb=" O   LEU A  83 "
   model   vdw
   3.760 3.340
nonbonded pdb=" CA  VAL A   4 "
          pdb=" O   TYR A  61 "
   model   vdw
   3.760 3.470
nonbonded pdb=" CA  ALA A  57 "
          pdb=" OH  TYR A  61 "
   model   vdw
   3.761 3.470
nonbonded pdb=" CD  GLN A  10 "
          pdb=" C   LEU A  32 "
   model   vdw
   3.761 3.500
nonbonded pdb=" CD1 LEU A  28 "
          pdb=" CB  PRO A  85 "
   model   vdw sym.op.
   3.761 3.860 x,y-1,z
nonbonded pdb=" NE2 GLN A  22 "
          pdb=" O   SER A  27 "
   model   vdw sym.op.
   3.763 3.120 -x+1/2,y-1/2,-z+2
nonbonded pdb=" C   THR A  48 "
          pdb=" OG1 THR A  48 "
   model   vdw
   3.763 2.616
nonbonded pdb=" CG  GLN A  12 "
          pdb="O    HOH S 110 "
   model   vdw
   3.764 3.440
nonbonded pdb=" CD  GLN A  31 "
          pdb=" CB  ALA A  55 "
   model   vdw
   3.764 3.690
nonbonded pdb=" CD2 LEU A  76 "
          pdb=" CD1 ILE A   2 "
   model   vdw sym.op.
   3.765 3.880 -x+1,y,-z+2
nonbonded pdb=" CD1 ILE A   2 "
          pdb=" CD2 LEU A  76 "
   model   vdw sym.op.
   3.765 3.880 -x+1,y,-z+2
nonbonded pdb=" O   SER A  27 "
          pdb="O    HOH S  33 "
   model   vdw
   3.765 3.040
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" O   GLN A  10 "
   model   vdw
   3.767 3.460
nonbonded pdb=" CB  TYR A  41 "
          pdb=" CE2 TYR A  41 "
   model   vdw
   3.767 2.992
nonbonded pdb=" CA  GLY A  18 "
          pdb=" OH  TYR A  26 "
   model   vdw
   3.767 3.440
nonbonded pdb=" CA  TYR A  26 "
          pdb=" CA  SER A  27 "
   model   vdw
   3.768 3.120
nonbonded pdb=" N   VAL A  43 "
          pdb=" CG2 VAL A  43 "
   model   vdw
   3.768 2.832
nonbonded pdb=" O   GLU A  40 "
          pdb=" CB  TYR A  41 "
   model   vdw
   3.768 3.440
nonbonded pdb=" CA  SER A  20 "
          pdb="O    HOH S 120 "
   model   vdw
   3.768 3.470
nonbonded pdb=" N   LEU A  81 "
          pdb=" CG  LEU A  81 "
   model   vdw
   3.769 2.840
nonbonded pdb=" CD1 PHE A  13 "
          pdb=" OD1 ASN A  29 "
   model   vdw
   3.769 3.340
nonbonded pdb=" CA  GLN A  53 "
          pdb=" CD  GLN A  53 "
   model   vdw
   3.769 2.960
nonbonded pdb=" N   SER A   9 "
          pdb=" CB  THR A  15 "
   model   vdw sym.op.
   3.769 3.550 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CG  TYR A  61 "
          pdb=" O   VAL A  84 "
   model   vdw
   3.770 3.260
nonbonded pdb=" CA  TYR A  61 "
          pdb="O    HOH S  54 "
   model   vdw
   3.770 3.470
nonbonded pdb=" C   LEU A  65 "
          pdb=" CD1 LEU A  65 "
   model   vdw
   3.770 3.690
nonbonded pdb=" C   TYR A  61 "
          pdb=" O   THR A  62 "
   model   vdw
   3.771 3.270
nonbonded pdb=" CA  PRO A  42 "
          pdb=" CA  VAL A  43 "
   model   vdw
   3.771 3.120
nonbonded pdb=" CG1 VAL A  70 "
          pdb=" O   GLY A  74 "
   model   vdw
   3.772 3.460
nonbonded pdb=" CD2 LEU A  65 "
          pdb="O    HOH S   2 "
   model   vdw sym.op.
   3.772 3.460 -x+1,y,-z+2
nonbonded pdb=" C   LEU A  28 "
          pdb=" CG  ASN A  29 "
   model   vdw
   3.772 3.500
nonbonded pdb=" CA  PRO A  54 "
          pdb=" CA  ALA A  55 "
   model   vdw
   3.773 3.120
nonbonded pdb=" CA  GLY A  71 "
          pdb="SE    SE Z   1 "
   model   vdw sym.op.
   3.773 3.820 -x,y+1,-z+1
nonbonded pdb=" CE2 TYR A  34 "
          pdb=" CE2 TYR A  41 "
   model   vdw sym.op.
   3.773 3.640 -x+1,y,-z+1
nonbonded pdb=" CE2 TYR A  41 "
          pdb=" CE2 TYR A  34 "
   model   vdw sym.op.
   3.773 3.640 -x+1,y,-z+1
nonbonded pdb=" CB  LYS A  24 "
          pdb="O    HOH S  97 "
   model   vdw
   3.773 3.440
nonbonded pdb=" CD1 TYR A  34 "
          pdb=" O   PRO A  42 "
   model   vdw
   3.773 3.340
nonbonded pdb=" CD1 ILE A  78 "
          pdb=" CE1 PHE A  68 "
   model   vdw sym.op.
   3.773 3.760 -x+1,y,-z+2
nonbonded pdb=" CE1 PHE A  68 "
          pdb=" CD1 ILE A  78 "
   model   vdw sym.op.
   3.773 3.760 -x+1,y,-z+2
nonbonded pdb=" CA  SER A  17 "
          pdb=" CA  GLY A  18 "
   model   vdw
   3.773 3.096
nonbonded pdb=" CA  LYS A  46 "
          pdb=" CA  ILE A  47 "
   model   vdw
   3.774 3.120
nonbonded pdb=" CA  VAL A  45 "
          pdb=" CA  LYS A  46 "
   model   vdw
   3.774 3.120
nonbonded pdb=" O   ASP A  50 "
          pdb=" CB  GLN A  53 "
   model   vdw
   3.775 3.440
nonbonded pdb=" O   SER A  27 "
          pdb=" CB  LEU A  28 "
   model   vdw
   3.775 3.440
nonbonded pdb=" CD  LYS A  24 "
          pdb=" OD2 ASP A  50 "
   model   vdw sym.op.
   3.775 3.440 -x+1/2,y-1/2,-z+2
nonbonded pdb=" OD2 ASP A  50 "
          pdb=" CD  LYS A  24 "
   model   vdw sym.op.
   3.775 3.440 -x+1/2,y+1/2,-z+2
nonbonded pdb=" N   LYS A   3 "
          pdb=" CG  LYS A   3 "
   model   vdw
   3.776 2.816
nonbonded pdb=" CG1 ILE A  78 "
          pdb=" CG1 ILE A  78 "
   model   vdw sym.op.
   3.776 3.840 -x+1,y,-z+2
nonbonded pdb=" C   GLU A   5 "
          pdb=" CG1 ILE A   6 "
   model   vdw
   3.776 3.670
nonbonded pdb=" CA  LEU A  81 "
          pdb="O    HOH S 106 "
   model   vdw
   3.776 3.470
nonbonded pdb=" CA  LYS A  46 "
          pdb=" CD  LYS A  46 "
   model   vdw
   3.776 3.096
nonbonded pdb=" CZ  ARG A  21 "
          pdb=" CD  GLU A  51 "
   model   vdw sym.op.
   3.777 3.500 -x+1/2,y-1/2,-z+2
nonbonded pdb="O    HOH S  44 "
          pdb="O    HOH S 134 "
   model   vdw
   3.777 3.040
nonbonded pdb=" CD1 LEU A  32 "
          pdb=" O   VAL A  45 "
   model   vdw
   3.777 3.460
nonbonded pdb=" O   ASN A  29 "
          pdb=" CG  LEU A  49 "
   model   vdw
   3.777 3.470
nonbonded pdb=" O   PRO A  58 "
          pdb=" CD  PRO A  58 "
   model   vdw
   3.777 3.440
nonbonded pdb=" O   LEU A  60 "
          pdb=" CB  TYR A  61 "
   model   vdw
   3.777 3.440
nonbonded pdb=" CG  TYR A  56 "
          pdb="O    HOH S  98 "
   model   vdw
   3.777 3.260
nonbonded pdb=" OD2 ASP A  79 "
          pdb=" CZ  ARG A  82 "
   model   vdw
   3.778 3.270
nonbonded pdb=" CG  GLN A  53 "
          pdb="O    HOH S 135 "
   model   vdw
   3.778 3.440
nonbonded pdb=" CB  TYR A  41 "
          pdb=" CE1 TYR A  41 "
   model   vdw
   3.778 2.992
nonbonded pdb=" CD  LYS A  69 "
          pdb="SE    SE Z   4 "
   model   vdw sym.op.
   3.778 3.820 x+1/2,y+3/2,z+2
nonbonded pdb=" CA  PRO A  58 "
          pdb=" CA  GLY A  59 "
   model   vdw
   3.779 3.096
nonbonded pdb=" CA  LEU A  49 "
          pdb=" CA  ASP A  50 "
   model   vdw
   3.780 3.120
nonbonded pdb=" CB  PHE A  68 "
          pdb=" CE1 PHE A  68 "
   model   vdw
   3.780 2.992
nonbonded pdb=" O   ILE A   2 "
          pdb=" CA  THR A  62 "
   model   vdw
   3.780 3.470
nonbonded pdb=" CA  GLY A  71 "
          pdb=" CA  GLN A  72 "
   model   vdw
   3.781 3.096
nonbonded pdb=" N   VAL A  19 "
          pdb=" CD2 TYR A  26 "
   model   vdw
   3.781 3.420
nonbonded pdb=" CA  ASP A  50 "
          pdb=" CA  GLU A  51 "
   model   vdw
   3.781 3.120
nonbonded pdb=" CA  TYR A  56 "
          pdb=" CA  ALA A  57 "
   model   vdw
   3.781 3.120
nonbonded pdb=" O   ARG A  80 "
          pdb=" NH1 ARG A  82 "
   model   vdw
   3.782 3.120
nonbonded pdb=" CB  PHE A  73 "
          pdb=" CE1 PHE A  73 "
   model   vdw
   3.782 2.992
nonbonded pdb=" CB  ARG A  16 "
          pdb="O    HOH S  85 "
   model   vdw
   3.782 3.440
nonbonded pdb=" CA  VAL A  70 "
          pdb=" CA  GLY A  71 "
   model   vdw
   3.783 3.096
nonbonded pdb=" CA  LEU A  76 "
          pdb="O    HOH S  10 "
   model   vdw sym.op.
   3.783 3.470 -x+1,y,-z+2
nonbonded pdb=" CG2 VAL A  19 "
          pdb=" CG  PRO A  54 "
   model   vdw sym.op.
   3.783 3.860 x,y-1,z
nonbonded pdb=" CA  VAL A  43 "
          pdb=" CA  LEU A  44 "
   model   vdw
   3.783 3.120
nonbonded pdb=" CB  PHE A  73 "
          pdb=" CE2 PHE A  73 "
   model   vdw
   3.783 2.992
nonbonded pdb=" CA  VAL A  19 "
          pdb=" CA  SER A  20 "
   model   vdw
   3.783 3.120
nonbonded pdb=" OH  TYR A  56 "
          pdb=" CB  LEU A  83 "
   model   vdw
   3.784 3.440
nonbonded pdb=" CA  ALA A  55 "
          pdb=" CA  TYR A  56 "
   model   vdw
   3.784 3.120
nonbonded pdb=" CA  LEU A  28 "
          pdb=" CA  ASN A  29 "
   model   vdw
   3.784 3.120
nonbonded pdb=" CB  PHE A  68 "
          pdb=" CE2 PHE A  68 "
   model   vdw
   3.785 2.992
nonbonded pdb=" CA  MSE A  77 "
          pdb="SE    SE Z   1 "
   model   vdw sym.op.
   3.785 3.850 -x,y+1,-z+1
nonbonded pdb=" O   ARG A  16 "
          pdb=" C   SER A  17 "
   model   vdw
   3.785 3.270
nonbonded pdb=" C   PRO A  54 "
          pdb="O    HOH S  98 "
   model   vdw
   3.786 3.270
nonbonded pdb=" CG2 VAL A   4 "
          pdb=" CG2 VAL A  35 "
   model   vdw
   3.786 3.880
nonbonded pdb=" CB  ARG A  82 "
          pdb=" NE  ARG A  82 "
   model   vdw
   3.786 2.816
nonbonded pdb=" CB  TYR A  26 "
          pdb=" CE2 TYR A  26 "
   model   vdw
   3.786 2.992
nonbonded pdb=" CD1 PHE A  73 "
          pdb="O    HOH S  54 "
   model   vdw sym.op.
   3.787 3.340 -x+1,y-1,-z+2
nonbonded pdb=" CA  THR A  15 "
          pdb=" CA  ARG A  16 "
   model   vdw
   3.787 3.120
nonbonded pdb=" CA  TYR A  61 "
          pdb=" CA  THR A  62 "
   model   vdw
   3.787 3.120
nonbonded pdb=" CA  PHE A  13 "
          pdb=" CA  THR A  14 "
   model   vdw
   3.787 3.120
nonbonded pdb=" CA  GLY A  18 "
          pdb=" CA  VAL A  19 "
   model   vdw
   3.788 3.096
nonbonded pdb=" C   CYS A  33 "
          pdb=" CG  TYR A  34 "
   model   vdw
   3.788 3.490
nonbonded pdb=" O   ASN A  29 "
          pdb=" CA  LEU A  49 "
   model   vdw
   3.788 3.470
nonbonded pdb=" CB  LEU A  37 "
          pdb="O    HOH S   3 "
   model   vdw
   3.788 3.440
nonbonded pdb=" CB  LYS A   3 "
          pdb=" CE1 PHE A  73 "
   model   vdw sym.op.
   3.788 3.740 -x+1,y+1,-z+2
nonbonded pdb=" OE1 GLN A  10 "
          pdb=" CD2 TYR A  34 "
   model   vdw
   3.788 3.340
nonbonded pdb=" CA  GLN A  12 "
          pdb=" CA  PHE A  13 "
   model   vdw
   3.789 3.120
nonbonded pdb=" CA  ARG A  82 "
          pdb=" CA  LEU A  83 "
   model   vdw
   3.789 3.120
nonbonded pdb=" CA  GLY A  59 "
          pdb=" CA  LEU A  60 "
   model   vdw
   3.789 3.096
nonbonded pdb=" N   THR A  48 "
          pdb=" CG2 THR A  48 "
   model   vdw
   3.789 2.832
nonbonded pdb=" N   VAL A  70 "
          pdb=" CG1 VAL A  70 "
   model   vdw
   3.790 2.832
nonbonded pdb=" N   GLN A  72 "
          pdb=" CG  GLN A  72 "
   model   vdw
   3.790 2.816
nonbonded pdb=" O   SER A  20 "
          pdb=" CA  GLY A  23 "
   model   vdw
   3.791 3.440
nonbonded pdb=" CB  PHE A  13 "
          pdb=" CE2 PHE A  13 "
   model   vdw
   3.791 2.992
nonbonded pdb=" O   ARG A  16 "
          pdb=" C   SER A  27 "
   model   vdw
   3.791 3.270
nonbonded pdb=" O   ARG A  16 "
          pdb=" CA  LEU A  28 "
   model   vdw
   3.791 3.470
nonbonded pdb=" CA  LYS A  69 "
          pdb=" CA  VAL A  70 "
   model   vdw
   3.792 3.120
nonbonded pdb=" CA  PHE A  68 "
          pdb=" CA  LYS A  69 "
   model   vdw
   3.792 3.120
nonbonded pdb=" CA  ARG A  80 "
          pdb=" CA  LEU A  81 "
   model   vdw
   3.792 3.120
nonbonded pdb=" N   THR A  15 "
          pdb=" CG2 THR A  15 "
   model   vdw
   3.792 2.832
nonbonded pdb=" CB  LYS A  24 "
          pdb=" CD  PRO A  25 "
   model   vdw
   3.793 3.840
nonbonded pdb=" CG  ASP A  36 "
          pdb="O    HOH S 123 "
   model   vdw
   3.793 3.270
nonbonded pdb=" O   LYS A  69 "
          pdb=" CA  MSE A  77 "
   model   vdw
   3.793 3.470
nonbonded pdb=" NZ  LYS A  24 "
          pdb=" NE  ARG A  82 "
   model   vdw sym.op.
   3.793 3.200 -x+1/2,y-1/2,-z+2
nonbonded pdb=" NE  ARG A  82 "
          pdb=" NZ  LYS A  24 "
   model   vdw sym.op.
   3.793 3.200 -x+1/2,y+1/2,-z+2
nonbonded pdb=" N   HIS A  64 "
          pdb=" CG  HIS A  64 "
   model   vdw
   3.794 2.672
nonbonded pdb=" CA  SER A  27 "
          pdb=" CA  LEU A  28 "
   model   vdw
   3.794 3.120
nonbonded pdb=" O   SER A   9 "
          pdb=" C   GLN A  10 "
   model   vdw
   3.794 3.270
nonbonded pdb=" O   LYS A   3 "
          pdb=" CB  ASP A  36 "
   model   vdw
   3.794 3.440
nonbonded pdb=" C   LEU A  76 "
          pdb="SE    SE Z   3 "
   model   vdw sym.op.
   3.794 3.650 -x+1/2,y+3/2,-z+1
nonbonded pdb=" CG1 VAL A  63 "
          pdb=" CD1 LEU A  81 "
   model   vdw
   3.794 3.880
nonbonded pdb=" CA  SER A  75 "
          pdb=" CA  LEU A  76 "
   model   vdw
   3.794 3.120
nonbonded pdb=" OG1 THR A  15 "
          pdb=" CG  ASN A  29 "
   model   vdw
   3.795 3.270
nonbonded pdb=" CB  TYR A  61 "
          pdb=" CE1 TYR A  61 "
   model   vdw
   3.795 2.992
nonbonded pdb=" CB  TYR A  61 "
          pdb=" CE2 TYR A  61 "
   model   vdw
   3.795 2.992
nonbonded pdb=" CB  ARG A  80 "
          pdb="O    HOH S 106 "
   model   vdw
   3.795 3.440
nonbonded pdb=" CA  THR A  48 "
          pdb=" CA  LEU A  49 "
   model   vdw
   3.795 3.120
nonbonded pdb=" CD  GLN A  12 "
          pdb=" O   PRO A  58 "
   model   vdw sym.op.
   3.795 3.270 -x+1/2,y-1/2,-z+1
nonbonded pdb=" O   VAL A  63 "
          pdb=" O   HIS A  64 "
   model   vdw
   3.796 3.040
nonbonded pdb=" CB  PHE A  13 "
          pdb=" CE1 PHE A  13 "
   model   vdw
   3.796 2.992
nonbonded pdb=" CB  ARG A  80 "
          pdb=" NE  ARG A  80 "
   model   vdw
   3.796 2.816
nonbonded pdb=" NE2 GLN A  10 "
          pdb=" C   CYS A  33 "
   model   vdw
   3.797 3.350
nonbonded pdb=" CA  HIS A  64 "
          pdb=" CA  LEU A  65 "
   model   vdw
   3.797 3.120
nonbonded pdb=" CB  TYR A  26 "
          pdb=" CE1 TYR A  26 "
   model   vdw
   3.797 2.992
nonbonded pdb=" CB  TYR A  56 "
          pdb=" CE2 TYR A  56 "
   model   vdw
   3.797 2.992
nonbonded pdb=" O   GLY A  52 "
          pdb=" O   GLN A  53 "
   model   vdw
   3.798 3.040
nonbonded pdb=" CA  ILE A   6 "
          pdb=" CA  LYS A   7 "
   model   vdw
   3.798 3.120
nonbonded pdb=" O   LYS A  69 "
          pdb=" C   MSE A  77 "
   model   vdw
   3.798 3.270
nonbonded pdb=" CB  TYR A  34 "
          pdb=" CE1 TYR A  34 "
   model   vdw
   3.798 2.992
nonbonded pdb=" CB  LEU A  49 "
          pdb=" O   ASP A  50 "
   model   vdw
   3.798 3.440
nonbonded pdb=" CA  GLU A  51 "
          pdb=" CA  GLY A  52 "
   model   vdw
   3.798 3.096
nonbonded pdb=" C   SER A  20 "
          pdb=" N   GLY A  23 "
   model   vdw
   3.798 3.350
nonbonded pdb=" CB  TYR A  34 "
          pdb=" CE2 TYR A  34 "
   model   vdw
   3.798 2.992
nonbonded pdb=" CA  LEU A  32 "
          pdb=" CA  CYS A  33 "
   model   vdw
   3.799 3.120
nonbonded pdb=" CA  ARG A  16 "
          pdb=" CA  SER A  17 "
   model   vdw
   3.799 3.120
nonbonded pdb=" O   ILE A  47 "
          pdb=" N   LEU A  49 "
   model   vdw
   3.799 3.120
nonbonded pdb=" O   ALA A  11 "
          pdb=" C   GLN A  12 "
   model   vdw
   3.799 3.270
nonbonded pdb=" C   SER A   9 "
          pdb="O    HOH S  34 "
   model   vdw sym.op.
   3.799 3.270 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CA  CYS A  33 "
          pdb=" CA  TYR A  34 "
   model   vdw
   3.799 3.120
nonbonded pdb=" C   VAL A  63 "
          pdb=" O   ARG A  82 "
   model   vdw
   3.800 3.270
nonbonded pdb=" CZ  ARG A  21 "
          pdb=" CE1 HIS A  64 "
   model   vdw sym.op.
   3.800 3.490 x,y-1,z
nonbonded pdb=" CA  THR A  14 "
          pdb=" CA  THR A  15 "
   model   vdw
   3.800 3.120
nonbonded pdb=" CG  LYS A  24 "
          pdb=" NZ  LYS A  24 "
   model   vdw
   3.800 2.816
nonbonded pdb=" CA  GLU A   5 "
          pdb=" CA  ILE A   6 "
   model   vdw
   3.800 3.120
nonbonded pdb=" N   ILE A  78 "
          pdb=" CG2 ILE A  78 "
   model   vdw
   3.800 2.832
nonbonded pdb=" CD2 TYR A  34 "
          pdb=" CE2 TYR A  41 "
   model   vdw sym.op.
   3.801 3.640 -x+1,y,-z+1
nonbonded pdb=" CE2 TYR A  41 "
          pdb=" CD2 TYR A  34 "
   model   vdw sym.op.
   3.801 3.640 -x+1,y,-z+1
nonbonded pdb=" N   ASP A  36 "
          pdb=" CG  ASP A  36 "
   model   vdw
   3.801 2.680
nonbonded pdb=" CB  TYR A  56 "
          pdb=" CE1 TYR A  56 "
   model   vdw
   3.801 2.992
nonbonded pdb=" CA  PRO A  25 "
          pdb=" CA  TYR A  26 "
   model   vdw
   3.801 3.120
nonbonded pdb=" CA  LEU A  83 "
          pdb=" CA  VAL A  84 "
   model   vdw
   3.801 3.120
nonbonded pdb=" N   LYS A  46 "
          pdb=" CG  LYS A  46 "
   model   vdw
   3.801 2.816
nonbonded pdb=" O   VAL A   4 "
          pdb=" CG1 VAL A   4 "
   model   vdw
   3.801 3.460
nonbonded pdb=" CD  LYS A  69 "
          pdb="O    HOH S 160 "
   model   vdw
   3.801 3.440
nonbonded pdb=" N   VAL A  63 "
          pdb=" CG1 VAL A  63 "
   model   vdw
   3.801 2.832
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" NE2 GLN A  31 "
   model   vdw
   3.803 3.540
nonbonded pdb=" CB  ARG A  16 "
          pdb="O    HOH S   8 "
   model   vdw
   3.803 3.440
nonbonded pdb=" CA  MSE A  77 "
          pdb=" CA  ILE A  78 "
   model   vdw
   3.803 3.120
nonbonded pdb=" CA  THR A  62 "
          pdb=" CA  VAL A  63 "
   model   vdw
   3.803 3.120
nonbonded pdb=" CA  ILE A  78 "
          pdb=" CA  ASP A  79 "
   model   vdw
   3.803 3.120
nonbonded pdb=" CA  LEU A  76 "
          pdb=" CA  MSE A  77 "
   model   vdw
   3.804 3.120
nonbonded pdb=" CE1 TYR A  41 "
          pdb=" CG  PRO A  42 "
   model   vdw sym.op.
   3.804 3.740 -x+1,y,-z+1
nonbonded pdb=" CA  TYR A  41 "
          pdb=" CA  PRO A  42 "
   model   vdw
   3.804 3.120
nonbonded pdb=" CA  LEU A  60 "
          pdb=" CA  TYR A  61 "
   model   vdw
   3.805 3.120
nonbonded pdb=" N   LYS A   7 "
          pdb=" CD  GLN A  10 "
   model   vdw
   3.805 3.350
nonbonded pdb=" CA  LEU A  37 "
          pdb=" CA  GLY A  38 "
   model   vdw
   3.805 3.096
nonbonded pdb=" CA  ASN A  39 "
          pdb=" CA  GLU A  40 "
   model   vdw
   3.805 3.120
nonbonded pdb=" CA  GLN A  31 "
          pdb=" CA  LEU A  32 "
   model   vdw
   3.805 3.120
nonbonded pdb=" CA  ILE A  47 "
          pdb=" CA  THR A  48 "
   model   vdw
   3.806 3.120
nonbonded pdb=" O   CYS A  33 "
          pdb=" O   VAL A  43 "
   model   vdw
   3.806 3.040
nonbonded pdb=" CD  GLU A  30 "
          pdb=" CE  LYS A  46 "
   model   vdw
   3.806 3.670
nonbonded pdb=" CB  LEU A  81 "
          pdb="O    HOH S  10 "
   model   vdw
   3.806 3.440
nonbonded pdb=" CA  GLY A  52 "
          pdb=" CA  GLN A  53 "
   model   vdw
   3.806 3.096
nonbonded pdb=" N   ILE A   6 "
          pdb=" CG2 ILE A   6 "
   model   vdw
   3.806 2.832
nonbonded pdb=" CD1 ILE A   2 "
          pdb=" CG1 VAL A  35 "
   model   vdw
   3.806 3.880
nonbonded pdb=" CG1 VAL A  43 "
          pdb=" N   LEU A  44 "
   model   vdw
   3.807 3.540
nonbonded pdb=" CA  VAL A  63 "
          pdb=" CA  HIS A  64 "
   model   vdw
   3.807 3.120
nonbonded pdb=" C   ALA A  55 "
          pdb="O    HOH S 134 "
   model   vdw
   3.807 3.270
nonbonded pdb=" CA  VAL A   4 "
          pdb=" CA  GLU A   5 "
   model   vdw
   3.807 3.120
nonbonded pdb=" CA  GLU A  30 "
          pdb=" CA  GLN A  31 "
   model   vdw
   3.807 3.120
nonbonded pdb=" CG1 VAL A  45 "
          pdb=" C   LYS A  46 "
   model   vdw
   3.807 3.690
nonbonded pdb=" CD1 TYR A  41 "
          pdb=" CD1 TYR A  41 "
   model   vdw sym.op.
   3.807 3.640 -x+1,y,-z+1
nonbonded pdb=" C   VAL A  70 "
          pdb=" O   SER A  75 "
   model   vdw
   3.808 3.270
nonbonded pdb=" CA  SER A  17 "
          pdb="O    HOH S  34 "
   model   vdw
   3.809 3.470
nonbonded pdb=" CA  ASP A  79 "
          pdb=" CA  ARG A  80 "
   model   vdw
   3.809 3.120
nonbonded pdb=" CA  VAL A  35 "
          pdb=" CA  ASP A  36 "
   model   vdw
   3.809 3.120
nonbonded pdb=" OE1 GLN A  31 "
          pdb=" CD2 LEU A  49 "
   model   vdw
   3.809 3.460
nonbonded pdb=" CA  GLY A  38 "
          pdb=" CA  ASN A  39 "
   model   vdw
   3.809 3.096
nonbonded pdb=" NE  ARG A  21 "
          pdb=" ND1 HIS A  64 "
   model   vdw sym.op.
   3.811 3.200 x,y-1,z
nonbonded pdb=" N   ASP A  79 "
          pdb=" CG  ASP A  79 "
   model   vdw
   3.811 2.680
nonbonded pdb=" CA  PHE A  73 "
          pdb=" CA  GLY A  74 "
   model   vdw
   3.811 3.096
nonbonded pdb=" CA  SER A  67 "
          pdb=" CA  PHE A  68 "
   model   vdw
   3.812 3.120
nonbonded pdb=" CA  LYS A   3 "
          pdb=" CA  VAL A   4 "
   model   vdw
   3.812 3.120
nonbonded pdb=" OE2 GLU A  30 "
          pdb=" CD  LYS A  46 "
   model   vdw
   3.812 3.440
nonbonded pdb=" CA  GLN A  22 "
          pdb=" CA  GLY A  23 "
   model   vdw
   3.812 3.096
nonbonded pdb=" OD1 ASP A  50 "
          pdb=" CD  ARG A  80 "
   model   vdw
   3.812 3.440
nonbonded pdb=" CA  GLY A  74 "
          pdb=" CA  SER A  75 "
   model   vdw
   3.813 3.096
nonbonded pdb=" CA  TYR A  34 "
          pdb=" CA  VAL A  35 "
   model   vdw
   3.813 3.120
nonbonded pdb=" CA  GLN A  53 "
          pdb=" CA  PRO A  54 "
   model   vdw
   3.813 3.120
nonbonded pdb=" CB  ASN A  39 "
          pdb=" O   TYR A  41 "
   model   vdw
   3.814 3.440
nonbonded pdb=" CA  LEU A  81 "
          pdb=" CA  ARG A  82 "
   model   vdw
   3.814 3.120
nonbonded pdb=" CG  LYS A  46 "
          pdb=" NZ  LYS A  46 "
   model   vdw
   3.815 2.816
nonbonded pdb=" CA  ASP A  36 "
          pdb=" CA  LEU A  37 "
   model   vdw
   3.815 3.120
nonbonded pdb=" N   VAL A  35 "
          pdb=" CG1 VAL A  35 "
   model   vdw
   3.816 2.832
nonbonded pdb=" CG  HIS A  64 "
          pdb="O    HOH S  35 "
   model   vdw
   3.816 3.260
nonbonded pdb=" O   LYS A   7 "
          pdb=" C   GLN A  10 "
   model   vdw
   3.816 3.270
nonbonded pdb=" C   MSE A  77 "
          pdb=" CG1 ILE A  78 "
   model   vdw
   3.816 3.670
nonbonded pdb=" CA  GLN A  10 "
          pdb=" CA  ALA A  11 "
   model   vdw
   3.816 3.120
nonbonded pdb=" N   VAL A   4 "
          pdb=" CG1 VAL A   4 "
   model   vdw
   3.816 2.832
nonbonded pdb=" CA  ASN A  29 "
          pdb=" CA  GLU A  30 "
   model   vdw
   3.817 3.120
nonbonded pdb=" CA  SER A  66 "
          pdb=" CA  SER A  67 "
   model   vdw
   3.817 3.120
nonbonded pdb=" C   VAL A  70 "
          pdb=" CG2 VAL A  70 "
   model   vdw
   3.818 2.952
nonbonded pdb=" CA  LYS A   7 "
          pdb=" CA  PRO A   8 "
   model   vdw
   3.818 3.120
nonbonded pdb=" C   LEU A  76 "
          pdb=" O   MSE A  77 "
   model   vdw
   3.818 3.270
nonbonded pdb=" CA  ILE A   2 "
          pdb=" CA  LYS A   3 "
   model   vdw
   3.819 3.120
nonbonded pdb=" N   ILE A   2 "
          pdb=" CG1 ILE A   2 "
   model   vdw
   3.819 2.816
nonbonded pdb=" CA  LEU A  65 "
          pdb=" CA  SER A  66 "
   model   vdw
   3.819 3.120
nonbonded pdb=" CA  ALA A  57 "
          pdb=" CA  PRO A  58 "
   model   vdw
   3.820 3.120
nonbonded pdb=" CG1 VAL A  45 "
          pdb=" CG2 ILE A  47 "
   model   vdw
   3.821 3.880
nonbonded pdb=" CG  LYS A   7 "
          pdb=" NZ  LYS A   7 "
   model   vdw
   3.821 2.816
nonbonded pdb=" CA  PRO A   8 "
          pdb=" CA  SER A   9 "
   model   vdw
   3.821 3.120
nonbonded pdb=" C   VAL A  45 "
          pdb=" CG2 VAL A  45 "
   model   vdw
   3.822 2.952
nonbonded pdb=" CD  GLN A  10 "
          pdb=" N   CYS A  33 "
   model   vdw
   3.822 3.350
nonbonded pdb=" O   VAL A  35 "
          pdb=" CA  VAL A  43 "
   model   vdw
   3.822 3.470
nonbonded pdb=" N   PRO A  42 "
          pdb="O    HOH S   3 "
   model   vdw
   3.823 3.120
nonbonded pdb=" C   LYS A  69 "
          pdb=" N   GLY A  71 "
   model   vdw
   3.823 3.350
nonbonded pdb=" CA  ASN A  29 "
          pdb="O    HOH S  33 "
   model   vdw
   3.823 3.470
nonbonded pdb=" C   LEU A  60 "
          pdb=" O   TYR A  61 "
   model   vdw
   3.824 3.270
nonbonded pdb=" N   VAL A  19 "
          pdb=" CG1 VAL A  19 "
   model   vdw
   3.824 2.832
nonbonded pdb=" OH  TYR A  56 "
          pdb=" CA  ARG A  82 "
   model   vdw
   3.824 3.470
nonbonded pdb=" O   LYS A   7 "
          pdb=" N   ALA A  11 "
   model   vdw
   3.824 3.120
nonbonded pdb=" N   TYR A  56 "
          pdb="O    HOH S  98 "
   model   vdw
   3.825 3.120
nonbonded pdb=" CA  GLU A   5 "
          pdb=" CD  GLU A   5 "
   model   vdw
   3.825 2.960
nonbonded pdb=" O   LYS A  24 "
          pdb=" O   PRO A  25 "
   model   vdw
   3.825 3.040
nonbonded pdb=" C   ALA A  11 "
          pdb=" CG  GLN A  12 "
   model   vdw
   3.826 3.670
nonbonded pdb=" CE  LYS A  69 "
          pdb=" O   VAL A  70 "
   model   vdw
   3.826 3.440
nonbonded pdb=" CD1 ILE A  78 "
          pdb=" CD1 PHE A  68 "
   model   vdw sym.op.
   3.827 3.760 -x+1,y,-z+2
nonbonded pdb=" CD1 PHE A  68 "
          pdb=" CD1 ILE A  78 "
   model   vdw sym.op.
   3.827 3.760 -x+1,y,-z+2
nonbonded pdb=" CA  GLU A   5 "
          pdb=" O   TYR A  34 "
   model   vdw
   3.827 3.470
nonbonded pdb=" C   PHE A  73 "
          pdb="O    HOH S   4 "
   model   vdw
   3.827 3.270
nonbonded pdb=" CE2 PHE A  13 "
          pdb="O    HOH S 110 "
   model   vdw
   3.828 3.340
nonbonded pdb=" CD1 LEU A  65 "
          pdb="O    HOH S   2 "
   model   vdw sym.op.
   3.828 3.460 -x+1,y,-z+2
nonbonded pdb=" O   GLN A  12 "
          pdb=" CB  PHE A  13 "
   model   vdw
   3.828 3.440
nonbonded pdb=" CA  ALA A  11 "
          pdb=" CA  GLN A  12 "
   model   vdw
   3.829 3.120
nonbonded pdb=" OG  SER A  67 "
          pdb=" C   LEU A  81 "
   model   vdw
   3.830 3.270
nonbonded pdb=" C   VAL A  43 "
          pdb=" O   LEU A  44 "
   model   vdw
   3.830 3.270
nonbonded pdb=" N   GLN A  31 "
          pdb=" CG  GLN A  31 "
   model   vdw
   3.830 2.816
nonbonded pdb=" C   LYS A   7 "
          pdb=" CG  LYS A   7 "
   model   vdw
   3.830 2.936
nonbonded pdb=" CA  GLN A  72 "
          pdb=" CA  PHE A  73 "
   model   vdw
   3.831 3.120
nonbonded pdb=" C   GLN A  31 "
          pdb="O    HOH S   7 "
   model   vdw
   3.831 3.270
nonbonded pdb=" CA  SER A   9 "
          pdb=" CA  GLN A  10 "
   model   vdw
   3.831 3.120
nonbonded pdb=" NH2 ARG A  21 "
          pdb=" CE1 HIS A  64 "
   model   vdw sym.op.
   3.831 3.340 x,y-1,z
nonbonded pdb=" OD1 ASP A  36 "
          pdb=" CA  GLY A  38 "
   model   vdw
   3.831 3.440
nonbonded pdb=" CA  GLU A  40 "
          pdb=" CA  TYR A  41 "
   model   vdw
   3.832 3.120
nonbonded pdb=" NH2 ARG A  16 "
          pdb=" N   LEU A  60 "
   model   vdw sym.op.
   3.832 3.200 x,y-1,z
nonbonded pdb=" CD2 PHE A  13 "
          pdb="O    HOH S 110 "
   model   vdw
   3.832 3.340
nonbonded pdb=" CA  VAL A  35 "
          pdb=" O   VAL A  43 "
   model   vdw
   3.833 3.470
nonbonded pdb=" N   ARG A  21 "
          pdb=" NE2 GLN A  53 "
   model   vdw sym.op.
   3.833 3.200 x,y-1,z
nonbonded pdb=" OG1 THR A  14 "
          pdb=" N   THR A  15 "
   model   vdw
   3.833 3.120
nonbonded pdb=" NH1 ARG A  21 "
          pdb=" OE1 GLU A  51 "
   model   vdw sym.op.
   3.833 3.120 -x+1/2,y-1/2,-z+2
nonbonded pdb=" CG  ARG A  16 "
          pdb="O    HOH S   8 "
   model   vdw
   3.834 3.440
nonbonded pdb=" CB  LYS A   7 "
          pdb=" CD  GLU A  40 "
   model   vdw sym.op.
   3.834 3.670 -x+1,y,-z+1
nonbonded pdb=" C   VAL A   4 "
          pdb=" O   TYR A  61 "
   model   vdw
   3.834 3.270
nonbonded pdb=" O   GLN A  22 "
          pdb=" N   LYS A  24 "
   model   vdw
   3.834 3.120
nonbonded pdb=" C   TYR A  41 "
          pdb=" CG  TYR A  41 "
   model   vdw
   3.835 2.792
nonbonded pdb=" N   GLU A   5 "
          pdb=" CG  GLU A   5 "
   model   vdw
   3.835 2.816
nonbonded pdb=" O   GLN A  31 "
          pdb=" CA  ILE A  47 "
   model   vdw
   3.837 3.470
nonbonded pdb=" N   LEU A  44 "
          pdb=" CG  LEU A  44 "
   model   vdw
   3.837 2.840
nonbonded pdb=" CD  LYS A  24 "
          pdb=" OD1 ASP A  50 "
   model   vdw sym.op.
   3.838 3.440 -x+1/2,y-1/2,-z+2
nonbonded pdb=" OD1 ASP A  50 "
          pdb=" CD  LYS A  24 "
   model   vdw sym.op.
   3.838 3.440 -x+1/2,y+1/2,-z+2
nonbonded pdb=" O   PRO A   8 "
          pdb=" CB  THR A  15 "
   model   vdw sym.op.
   3.838 3.470 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CG  LYS A   7 "
          pdb=" OE2 GLU A  40 "
   model   vdw sym.op.
   3.838 3.440 -x+1,y,-z+1
nonbonded pdb=" O   THR A  14 "
          pdb=" CA  GLU A  30 "
   model   vdw
   3.838 3.470
nonbonded pdb=" N   LEU A  76 "
          pdb=" CG  LEU A  76 "
   model   vdw
   3.839 2.840
nonbonded pdb=" CG  LYS A  69 "
          pdb="SE    SE Z   4 "
   model   vdw sym.op.
   3.839 3.820 x+1/2,y+3/2,z+2
nonbonded pdb=" O   SER A  27 "
          pdb=" C   LEU A  28 "
   model   vdw
   3.839 3.270
nonbonded pdb=" CD1 PHE A  13 "
          pdb=" N   THR A  14 "
   model   vdw
   3.840 3.420
nonbonded pdb=" CA  VAL A  70 "
          pdb="O    HOH S  16 "
   model   vdw
   3.841 3.470
nonbonded pdb=" CB  PRO A   8 "
          pdb=" OG1 THR A  15 "
   model   vdw sym.op.
   3.841 3.440 -x+1/2,y+1/2,-z+1
nonbonded pdb=" O   THR A  62 "
          pdb=" CA  VAL A  84 "
   model   vdw
   3.841 3.470
nonbonded pdb=" CB  LYS A  69 "
          pdb="O    HOH S  16 "
   model   vdw
   3.841 3.440
nonbonded pdb=" CA  LYS A   3 "
          pdb=" CD  LYS A   3 "
   model   vdw
   3.842 3.096
nonbonded pdb=" CD  PRO A   8 "
          pdb=" N   SER A   9 "
   model   vdw
   3.842 3.520
nonbonded pdb=" C   ARG A  80 "
          pdb=" CG  ARG A  80 "
   model   vdw
   3.843 2.936
nonbonded pdb=" CD1 LEU A  37 "
          pdb=" CG1 VAL A  43 "
   model   vdw
   3.843 3.880
nonbonded pdb=" N   PHE A  73 "
          pdb=" CD1 PHE A  73 "
   model   vdw
   3.843 3.420
nonbonded pdb=" CA  LYS A   3 "
          pdb="O    HOH S   2 "
   model   vdw
   3.843 3.470
nonbonded pdb=" C   VAL A  35 "
          pdb=" CB  PRO A  42 "
   model   vdw
   3.846 3.670
nonbonded pdb=" CG2 VAL A  43 "
          pdb=" CG2 VAL A  70 "
   model   vdw sym.op.
   3.846 3.880 -x+1,y,-z+2
nonbonded pdb=" OD1 ASP A  36 "
          pdb="O    HOH S   3 "
   model   vdw
   3.846 3.040
nonbonded pdb=" C   ASN A  39 "
          pdb=" O   GLU A  40 "
   model   vdw
   3.846 3.270
nonbonded pdb=" CA  PRO A   8 "
          pdb=" CG  PRO A  58 "
   model   vdw
   3.847 3.870
nonbonded pdb=" CA  ALA A  55 "
          pdb="O    HOH S  44 "
   model   vdw
   3.847 3.470
nonbonded pdb=" C   TYR A  61 "
          pdb="O    HOH S  54 "
   model   vdw
   3.847 3.270
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" O   ALA A  57 "
   model   vdw
   3.847 3.460
nonbonded pdb=" N   LEU A  65 "
          pdb=" CG  LEU A  65 "
   model   vdw
   3.848 2.840
nonbonded pdb=" C   THR A  14 "
          pdb=" CG2 THR A  14 "
   model   vdw
   3.849 2.952
nonbonded pdb=" CA  ARG A  21 "
          pdb=" CD  ARG A  21 "
   model   vdw
   3.850 3.096
nonbonded pdb=" C   PHE A  73 "
          pdb=" CG  PHE A  73 "
   model   vdw
   3.853 2.792
nonbonded pdb=" C   ASP A  50 "
          pdb=" CG  ASP A  50 "
   model   vdw
   3.853 2.800
nonbonded pdb=" CD1 PHE A  68 "
          pdb=" O   MSE A  77 "
   model   vdw
   3.853 3.340
nonbonded pdb=" CG  LYS A  69 "
          pdb=" NZ  LYS A  69 "
   model   vdw
   3.853 2.816
nonbonded pdb=" CA  LYS A   7 "
          pdb="O    HOH S  51 "
   model   vdw
   3.854 3.470
nonbonded pdb=" CG1 VAL A   4 "
          pdb=" CB  CYS A  33 "
   model   vdw
   3.854 3.860
nonbonded pdb=" CA  ARG A  21 "
          pdb=" NE2 GLN A  53 "
   model   vdw sym.op.
   3.854 3.550 x,y-1,z
nonbonded pdb=" CE2 TYR A  56 "
          pdb=" CD1 LEU A  83 "
   model   vdw
   3.854 3.760
nonbonded pdb=" C   SER A  17 "
          pdb=" O   TYR A  26 "
   model   vdw
   3.855 3.270
nonbonded pdb=" CA  LEU A  65 "
          pdb="O    HOH S  35 "
   model   vdw
   3.855 3.470
nonbonded pdb=" CG  ASN A  29 "
          pdb="O    HOH S  33 "
   model   vdw
   3.855 3.270
nonbonded pdb=" C   TYR A  34 "
          pdb=" CG  TYR A  34 "
   model   vdw
   3.855 2.792
nonbonded pdb=" O   GLU A   5 "
          pdb=" CA  TYR A  34 "
   model   vdw
   3.855 3.470
nonbonded pdb=" O   LEU A  60 "
          pdb=" CD1 TYR A  61 "
   model   vdw
   3.856 3.340
nonbonded pdb=" C   LYS A  69 "
          pdb=" O   VAL A  70 "
   model   vdw
   3.856 3.270
nonbonded pdb=" CG  LYS A  24 "
          pdb=" CZ  ARG A  82 "
   model   vdw sym.op.
   3.856 3.670 -x+1/2,y-1/2,-z+2
nonbonded pdb=" CZ  ARG A  82 "
          pdb=" CG  LYS A  24 "
   model   vdw sym.op.
   3.856 3.670 -x+1/2,y+1/2,-z+2
nonbonded pdb=" C   VAL A  63 "
          pdb=" CG2 VAL A  63 "
   model   vdw
   3.856 2.952
nonbonded pdb=" C   THR A  15 "
          pdb=" O   ARG A  16 "
   model   vdw
   3.856 3.270
nonbonded pdb=" O   GLY A  18 "
          pdb=" CG  TYR A  26 "
   model   vdw
   3.857 3.260
nonbonded pdb=" CZ  TYR A  56 "
          pdb="O    HOH S  98 "
   model   vdw
   3.857 3.260
nonbonded pdb=" O   LYS A  24 "
          pdb=" N   TYR A  26 "
   model   vdw
   3.857 3.120
nonbonded pdb=" C   PHE A  68 "
          pdb=" CG  PHE A  68 "
   model   vdw
   3.858 2.792
nonbonded pdb=" CG1 VAL A   4 "
          pdb=" CD1 LEU A  83 "
   model   vdw
   3.858 3.880
nonbonded pdb=" C   ILE A  78 "
          pdb=" CG1 ILE A  78 "
   model   vdw
   3.858 2.936
nonbonded pdb=" CA  GLN A  31 "
          pdb="O    HOH S   7 "
   model   vdw
   3.859 3.470
nonbonded pdb=" CB  LYS A   3 "
          pdb="O    HOH S   2 "
   model   vdw
   3.859 3.440
nonbonded pdb=" OH  TYR A  56 "
          pdb=" CA  LEU A  83 "
   model   vdw
   3.859 3.470
nonbonded pdb=" CD1 PHE A  13 "
          pdb=" OG1 THR A  15 "
   model   vdw
   3.859 3.340
nonbonded pdb=" C   GLN A  12 "
          pdb=" O   PHE A  13 "
   model   vdw
   3.859 3.270
nonbonded pdb=" C   GLN A  12 "
          pdb=" CG  GLN A  12 "
   model   vdw
   3.860 2.936
nonbonded pdb=" CD  GLU A  40 "
          pdb=" OG  SER A   9 "
   model   vdw sym.op.
   3.860 3.270 -x+1,y,-z+1
nonbonded pdb=" OG  SER A   9 "
          pdb=" CD  GLU A  40 "
   model   vdw sym.op.
   3.860 3.270 -x+1,y,-z+1
nonbonded pdb=" CA  ALA A  57 "
          pdb="O    HOH S  14 "
   model   vdw
   3.860 3.470
nonbonded pdb=" CB  GLN A  53 "
          pdb=" O   PRO A  54 "
   model   vdw
   3.860 3.440
nonbonded pdb=" CA  LYS A  24 "
          pdb=" CD  LYS A  24 "
   model   vdw
   3.860 3.096
nonbonded pdb=" N   HIS A  64 "
          pdb=" OG  SER A  67 "
   model   vdw
   3.860 3.120
nonbonded pdb=" O   SER A  27 "
          pdb=" CG  LEU A  28 "
   model   vdw
   3.861 3.470
nonbonded pdb=" CG1 VAL A  84 "
          pdb=" CD  PRO A  85 "
   model   vdw
   3.861 3.860
nonbonded pdb=" CA  GLN A  12 "
          pdb=" CD  GLN A  12 "
   model   vdw
   3.863 2.960
nonbonded pdb=" CA  GLU A  51 "
          pdb=" CD  GLU A  51 "
   model   vdw
   3.864 2.960
nonbonded pdb=" CG  PRO A   8 "
          pdb=" O   PHE A  13 "
   model   vdw sym.op.
   3.865 3.440 -x+1/2,y+1/2,-z+1
nonbonded pdb=" O   ILE A   2 "
          pdb=" CB  THR A  62 "
   model   vdw
   3.866 3.470
nonbonded pdb=" C   TYR A  34 "
          pdb=" O   VAL A  35 "
   model   vdw
   3.866 3.270
nonbonded pdb=" CA  VAL A  63 "
          pdb=" O   ARG A  82 "
   model   vdw
   3.867 3.470
nonbonded pdb=" C   VAL A  35 "
          pdb=" CG2 VAL A  35 "
   model   vdw
   3.867 2.952
nonbonded pdb=" O   ASN A  29 "
          pdb=" C   GLU A  30 "
   model   vdw
   3.867 3.270
nonbonded pdb=" O   LEU A  81 "
          pdb=" CG  LEU A  81 "
   model   vdw
   3.867 3.470
nonbonded pdb=" CD2 TYR A  56 "
          pdb=" CD1 LEU A  83 "
   model   vdw
   3.867 3.760
nonbonded pdb=" C   HIS A  64 "
          pdb=" OG  SER A  67 "
   model   vdw
   3.868 3.270
nonbonded pdb=" C   PRO A   8 "
          pdb=" CB  THR A  15 "
   model   vdw sym.op.
   3.868 3.700 -x+1/2,y+1/2,-z+1
nonbonded pdb=" C   ASN A  39 "
          pdb=" CG  ASN A  39 "
   model   vdw
   3.868 2.800
nonbonded pdb=" C   VAL A  19 "
          pdb=" CG2 VAL A  19 "
   model   vdw
   3.869 2.952
nonbonded pdb=" C   ILE A  47 "
          pdb=" CG2 ILE A  47 "
   model   vdw
   3.869 2.952
nonbonded pdb=" CA  LEU A  28 "
          pdb=" CD1 LEU A  28 "
   model   vdw
   3.870 3.112
nonbonded pdb=" CG  LYS A   3 "
          pdb=" CE1 PHE A  73 "
   model   vdw sym.op.
   3.870 3.740 -x+1,y+1,-z+2
nonbonded pdb=" CB  SER A   9 "
          pdb=" CB  THR A  15 "
   model   vdw sym.op.
   3.871 3.870 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CB  THR A  15 "
          pdb=" CB  SER A   9 "
   model   vdw sym.op.
   3.871 3.870 -x+1/2,y-1/2,-z+1
nonbonded pdb=" C   LEU A  28 "
          pdb=" O   ASN A  29 "
   model   vdw
   3.871 3.270
nonbonded pdb=" O   CYS A  33 "
          pdb=" C   TYR A  34 "
   model   vdw
   3.871 3.270
nonbonded pdb=" C   ARG A  82 "
          pdb=" CG  ARG A  82 "
   model   vdw
   3.872 2.936
nonbonded pdb=" CG  ASP A  36 "
          pdb=" N   LEU A  37 "
   model   vdw
   3.873 3.350
nonbonded pdb=" OG  SER A  67 "
          pdb=" CA  LEU A  81 "
   model   vdw
   3.873 3.470
nonbonded pdb=" CZ  TYR A  56 "
          pdb=" CG  LEU A  83 "
   model   vdw
   3.873 3.690
nonbonded pdb=" C   ALA A  57 "
          pdb=" N   GLY A  59 "
   model   vdw
   3.873 3.350
nonbonded pdb=" C   GLU A  30 "
          pdb=" CG  GLU A  30 "
   model   vdw
   3.874 2.936
nonbonded pdb=" CA  VAL A  84 "
          pdb=" CA  PRO A  85 "
   model   vdw
   3.874 3.120
nonbonded pdb=" OG  SER A   9 "
          pdb=" CG  GLN A  10 "
   model   vdw
   3.874 3.440
nonbonded pdb=" C   TYR A  56 "
          pdb=" CG  TYR A  56 "
   model   vdw
   3.875 2.792
nonbonded pdb=" CG  GLU A   5 "
          pdb="O    HOH S  51 "
   model   vdw
   3.875 3.440
nonbonded pdb=" O   LEU A  32 "
          pdb="O    HOH S   7 "
   model   vdw
   3.875 3.040
nonbonded pdb=" CG1 VAL A   4 "
          pdb=" O   TYR A  34 "
   model   vdw
   3.876 3.460
nonbonded pdb=" CA  ARG A  82 "
          pdb=" CD  ARG A  82 "
   model   vdw
   3.876 3.096
nonbonded pdb=" OE1 GLN A  53 "
          pdb=" CE1 TYR A  56 "
   model   vdw
   3.876 3.340
nonbonded pdb=" CB  SER A  20 "
          pdb="O    HOH S 120 "
   model   vdw
   3.876 3.440
nonbonded pdb=" C   VAL A   4 "
          pdb=" CG2 VAL A   4 "
   model   vdw
   3.877 2.952
nonbonded pdb=" O   LEU A  44 "
          pdb=" C   VAL A  45 "
   model   vdw
   3.877 3.270
nonbonded pdb=" C   TYR A  61 "
          pdb=" CG  TYR A  61 "
   model   vdw
   3.877 2.792
nonbonded pdb=" O   GLY A  18 "
          pdb=" CE2 TYR A  26 "
   model   vdw
   3.878 3.340
nonbonded pdb=" C   ASN A  29 "
          pdb=" CG  ASN A  29 "
   model   vdw
   3.878 2.800
nonbonded pdb=" CB  LYS A   7 "
          pdb=" CD  GLN A  10 "
   model   vdw
   3.878 3.670
nonbonded pdb=" N   GLU A  40 "
          pdb=" CD  GLU A  40 "
   model   vdw
   3.880 3.350
nonbonded pdb=" C   ILE A   6 "
          pdb=" CG1 ILE A   6 "
   model   vdw
   3.880 2.936
nonbonded pdb=" C   ARG A  82 "
          pdb=" CG  LEU A  83 "
   model   vdw
   3.880 3.700
nonbonded pdb=" C   HIS A  64 "
          pdb=" N   SER A  67 "
   model   vdw
   3.880 3.350
nonbonded pdb=" O   CYS A  33 "
          pdb=" CG  LEU A  44 "
   model   vdw
   3.880 3.470
nonbonded pdb=" OH  TYR A  56 "
          pdb=" C   ARG A  82 "
   model   vdw
   3.881 3.270
nonbonded pdb=" CA  LEU A  44 "
          pdb=" CD2 LEU A  44 "
   model   vdw
   3.881 3.112
nonbonded pdb=" CD  LYS A  24 "
          pdb=" CG  ASP A  50 "
   model   vdw sym.op.
   3.881 3.670 -x+1/2,y-1/2,-z+2
nonbonded pdb=" CG  ASP A  50 "
          pdb=" CD  LYS A  24 "
   model   vdw sym.op.
   3.881 3.670 -x+1/2,y+1/2,-z+2
nonbonded pdb=" CG2 VAL A  45 "
          pdb=" O   GLY A  74 "
   model   vdw sym.op.
   3.881 3.460 -x+1,y,-z+2
nonbonded pdb=" CE2 TYR A  26 "
          pdb=" CG  PRO A  85 "
   model   vdw sym.op.
   3.882 3.740 x,y-1,z
nonbonded pdb=" C   ASN A  39 "
          pdb="O    HOH S 131 "
   model   vdw
   3.882 3.270
nonbonded pdb=" CG  ARG A  16 "
          pdb=" CB  LEU A  28 "
   model   vdw
   3.882 3.840
nonbonded pdb=" CA  ILE A  78 "
          pdb=" CD1 ILE A  78 "
   model   vdw
   3.883 3.112
nonbonded pdb=" CD  LYS A  69 "
          pdb=" CB  ASP A  79 "
   model   vdw
   3.883 3.840
nonbonded pdb=" O   GLY A  59 "
          pdb=" CE1 TYR A  61 "
   model   vdw
   3.883 3.340
nonbonded pdb=" C   GLN A  10 "
          pdb=" CG  GLN A  10 "
   model   vdw
   3.883 2.936
nonbonded pdb=" C   ILE A   2 "
          pdb=" O   LYS A   3 "
   model   vdw
   3.884 3.270
nonbonded pdb=" CB  ALA A  11 "
          pdb=" CG2 THR A  14 "
   model   vdw sym.op.
   3.884 3.880 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CA  VAL A  70 "
          pdb=" O   SER A  75 "
   model   vdw
   3.884 3.470
nonbonded pdb=" N   LEU A  60 "
          pdb=" CD2 LEU A  60 "
   model   vdw
   3.884 3.540
nonbonded pdb=" N   TYR A  56 "
          pdb=" CD1 TYR A  56 "
   model   vdw
   3.885 3.420
nonbonded pdb=" C   ARG A  82 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   3.885 3.690
nonbonded pdb=" CA  ASP A  79 "
          pdb="O    HOH S 160 "
   model   vdw
   3.885 3.470
nonbonded pdb=" CA  LYS A   7 "
          pdb=" CE  LYS A   7 "
   model   vdw
   3.886 3.870
nonbonded pdb=" C   ILE A  47 "
          pdb=" N   LEU A  49 "
   model   vdw
   3.886 3.350
nonbonded pdb=" CG2 THR A  48 "
          pdb=" NE  ARG A  80 "
   model   vdw
   3.886 3.540
nonbonded pdb=" O   LYS A  46 "
          pdb=" C   ILE A  47 "
   model   vdw
   3.886 3.270
nonbonded pdb=" C   LEU A  83 "
          pdb=" O   VAL A  84 "
   model   vdw
   3.887 3.270
nonbonded pdb=" C   LEU A  60 "
          pdb=" CG  LEU A  60 "
   model   vdw
   3.887 2.960
nonbonded pdb=" O   LEU A  81 "
          pdb="O    HOH S 106 "
   model   vdw
   3.887 3.040
nonbonded pdb=" O   ASP A  36 "
          pdb=" CD2 LEU A  37 "
   model   vdw
   3.887 3.460
nonbonded pdb=" C   LYS A  46 "
          pdb=" O   ILE A  47 "
   model   vdw
   3.887 3.270
nonbonded pdb=" C   GLU A   5 "
          pdb=" N   LYS A   7 "
   model   vdw
   3.888 3.350
nonbonded pdb=" O   PRO A  85 "
          pdb=" CD  PRO A  85 "
   model   vdw
   3.888 3.440
nonbonded pdb=" CA  LEU A  81 "
          pdb=" CD2 LEU A  81 "
   model   vdw
   3.888 3.112
nonbonded pdb=" C   ALA A  55 "
          pdb=" N   ALA A  57 "
   model   vdw
   3.888 3.350
nonbonded pdb=" NE2 GLN A  31 "
          pdb=" C   TYR A  56 "
   model   vdw
   3.889 3.350
nonbonded pdb=" CA  ILE A  47 "
          pdb=" CD1 ILE A  47 "
   model   vdw
   3.889 3.112
nonbonded pdb=" O   ARG A  16 "
          pdb=" CB  LEU A  28 "
   model   vdw
   3.889 3.440
nonbonded pdb=" C   LEU A  28 "
          pdb=" CG  LEU A  28 "
   model   vdw
   3.889 2.960
nonbonded pdb=" CG  ARG A  16 "
          pdb="O    HOH S  85 "
   model   vdw
   3.889 3.440
nonbonded pdb=" CG  PHE A  13 "
          pdb=" N   THR A  14 "
   model   vdw
   3.890 3.340
nonbonded pdb=" O   LYS A   3 "
          pdb=" CB  VAL A   4 "
   model   vdw
   3.891 3.470
nonbonded pdb=" O   ILE A   6 "
          pdb=" N   PRO A   8 "
   model   vdw
   3.891 3.120
nonbonded pdb=" CB  SER A   9 "
          pdb=" CG2 THR A  15 "
   model   vdw sym.op.
   3.891 3.860 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CG2 THR A  15 "
          pdb=" CB  SER A   9 "
   model   vdw sym.op.
   3.891 3.860 -x+1/2,y-1/2,-z+1
nonbonded pdb=" CA  ARG A  80 "
          pdb=" CD  ARG A  80 "
   model   vdw
   3.891 3.096
nonbonded pdb=" C   ARG A  21 "
          pdb=" CG  GLN A  22 "
   model   vdw
   3.892 3.670
nonbonded pdb=" O   GLU A   5 "
          pdb=" N   LYS A   7 "
   model   vdw
   3.892 3.120
nonbonded pdb=" CB  THR A  14 "
          pdb="O    HOH S 151 "
   model   vdw
   3.892 3.470
nonbonded pdb=" C   GLU A  40 "
          pdb=" CD2 TYR A  41 "
   model   vdw
   3.892 3.570
nonbonded pdb=" CB  SER A  17 "
          pdb=" O   TYR A  26 "
   model   vdw
   3.893 3.440
nonbonded pdb=" O   GLY A  18 "
          pdb=" CA  TYR A  26 "
   model   vdw
   3.893 3.470
nonbonded pdb=" C   ILE A   6 "
          pdb="O    HOH S  51 "
   model   vdw
   3.895 3.270
nonbonded pdb=" CE1 PHE A  73 "
          pdb="O    HOH S  54 "
   model   vdw sym.op.
   3.896 3.340 -x+1,y-1,-z+2
nonbonded pdb=" C   LEU A  83 "
          pdb=" CG  LEU A  83 "
   model   vdw
   3.896 2.960
nonbonded pdb=" O   LYS A   3 "
          pdb=" C   VAL A   4 "
   model   vdw
   3.897 3.270
nonbonded pdb=" CA  GLN A  10 "
          pdb=" CD  GLN A  10 "
   model   vdw
   3.898 2.960
nonbonded pdb=" O   ARG A  80 "
          pdb=" O   LEU A  81 "
   model   vdw
   3.898 3.040
nonbonded pdb=" C   GLU A  40 "
          pdb=" CG  GLU A  40 "
   model   vdw
   3.899 2.936
nonbonded pdb=" N   GLY A  59 "
          pdb="O    HOH S  51 "
   model   vdw
   3.899 3.120
nonbonded pdb=" CA  LYS A   3 "
          pdb=" O   TYR A  61 "
   model   vdw
   3.900 3.470
nonbonded pdb=" CD  ARG A  16 "
          pdb=" CD  GLU A  30 "
   model   vdw
   3.900 3.670
nonbonded pdb=" O   SER A   9 "
          pdb=" N   ALA A  11 "
   model   vdw
   3.900 3.120
nonbonded pdb=" CG1 ILE A   2 "
          pdb=" CG1 VAL A  35 "
   model   vdw
   3.900 3.860
nonbonded pdb=" CB  PRO A   8 "
          pdb=" CE1 PHE A  13 "
   model   vdw sym.op.
   3.900 3.740 -x+1/2,y+1/2,-z+1
nonbonded pdb=" N   GLY A  71 "
          pdb="O    HOH S   4 "
   model   vdw
   3.901 3.120
nonbonded pdb=" O   CYS A  33 "
          pdb=" CB  TYR A  34 "
   model   vdw
   3.901 3.440
nonbonded pdb=" OE1 GLN A  10 "
          pdb=" N   CYS A  33 "
   model   vdw
   3.901 3.120
nonbonded pdb=" CG  LYS A   7 "
          pdb=" CE2 TYR A  34 "
   model   vdw
   3.902 3.740
nonbonded pdb=" CA  LYS A  69 "
          pdb=" CD  LYS A  69 "
   model   vdw
   3.902 3.096
nonbonded pdb=" NZ  LYS A  24 "
          pdb=" CD  ARG A  21 "
   model   vdw sym.op.
   3.902 3.520 -x+1/2,y+1/2,-z+2
nonbonded pdb=" CD  ARG A  21 "
          pdb=" NZ  LYS A  24 "
   model   vdw sym.op.
   3.902 3.520 -x+1/2,y-1/2,-z+2
nonbonded pdb=" CB  SER A  67 "
          pdb=" N   ARG A  82 "
   model   vdw
   3.903 3.520
nonbonded pdb=" CA  GLU A  30 "
          pdb=" CD  GLU A  30 "
   model   vdw
   3.903 2.960
nonbonded pdb=" O   VAL A   4 "
          pdb=" CB  TYR A  61 "
   model   vdw
   3.903 3.440
nonbonded pdb=" N   ILE A   6 "
          pdb=" CD1 ILE A   6 "
   model   vdw
   3.903 3.540
nonbonded pdb=" N   PHE A  68 "
          pdb=" CD1 PHE A  68 "
   model   vdw
   3.903 3.420
nonbonded pdb=" C   LYS A   3 "
          pdb=" O   VAL A   4 "
   model   vdw
   3.903 3.270
nonbonded pdb=" CB  TYR A  56 "
          pdb=" CZ  TYR A  61 "
   model   vdw
   3.903 3.660
nonbonded pdb=" CA  LEU A  83 "
          pdb=" CD1 LEU A  83 "
   model   vdw
   3.904 3.112
nonbonded pdb=" C   GLY A  52 "
          pdb=" N   PRO A  54 "
   model   vdw
   3.905 3.350
nonbonded pdb=" C   GLN A  22 "
          pdb=" CG  GLN A  22 "
   model   vdw
   3.905 2.936
nonbonded pdb=" CB  SER A  75 "
          pdb="O    HOH S   4 "
   model   vdw
   3.906 3.440
nonbonded pdb=" CA  LEU A  76 "
          pdb=" CD2 LEU A  76 "
   model   vdw
   3.906 3.112
nonbonded pdb=" CG  LYS A   7 "
          pdb=" CD2 TYR A  34 "
   model   vdw
   3.906 3.740
nonbonded pdb=" C   LEU A  37 "
          pdb=" CG  LEU A  37 "
   model   vdw
   3.907 2.960
nonbonded pdb=" CG1 VAL A  45 "
          pdb=" N   LEU A  76 "
   model   vdw sym.op.
   3.907 3.540 -x+1,y,-z+2
nonbonded pdb=" CE1 TYR A  34 "
          pdb=" CD1 LEU A  44 "
   model   vdw
   3.908 3.760
nonbonded pdb="O    HOH S  14 "
          pdb="O    HOH S  85 "
   model   vdw sym.op.
   3.908 3.040 x,y+1,z
nonbonded pdb=" C   PHE A  68 "
          pdb=" O   LYS A  69 "
   model   vdw
   3.909 3.270
nonbonded pdb=" N   LYS A  46 "
          pdb=" C   GLY A  74 "
   model   vdw sym.op.
   3.909 3.350 -x+1,y,-z+2
nonbonded pdb=" NE  ARG A  21 "
          pdb=" OG  SER A  66 "
   model   vdw sym.op.
   3.909 3.120 x,y-1,z
nonbonded pdb=" OG  SER A  66 "
          pdb=" NE  ARG A  21 "
   model   vdw sym.op.
   3.909 3.120 x,y+1,z
nonbonded pdb=" O   CYS A  33 "
          pdb=" CG  TYR A  34 "
   model   vdw
   3.910 3.260
nonbonded pdb=" OG  SER A  67 "
          pdb=" C   ARG A  82 "
   model   vdw
   3.910 3.270
nonbonded pdb=" CA  LEU A  60 "
          pdb=" CD1 LEU A  60 "
   model   vdw
   3.910 3.112
nonbonded pdb=" O   ASN A  29 "
          pdb=" CG  GLU A  30 "
   model   vdw
   3.910 3.440
nonbonded pdb=" CB  ASN A  29 "
          pdb=" CD1 LEU A  49 "
   model   vdw
   3.911 3.860
nonbonded pdb=" CE2 TYR A  56 "
          pdb=" CG  LEU A  83 "
   model   vdw
   3.911 3.770
nonbonded pdb=" N   LEU A  28 "
          pdb=" CD2 LEU A  28 "
   model   vdw
   3.911 3.540
nonbonded pdb=" C   GLY A  59 "
          pdb=" O   LEU A  60 "
   model   vdw
   3.911 3.270
nonbonded pdb=" C   LEU A  32 "
          pdb=" CG  LEU A  32 "
   model   vdw
   3.911 2.960
nonbonded pdb=" CA  LEU A  37 "
          pdb=" CD1 LEU A  37 "
   model   vdw
   3.912 3.112
nonbonded pdb=" CA  ILE A   2 "
          pdb=" CD1 ILE A   2 "
   model   vdw
   3.912 3.112
nonbonded pdb=" NE  ARG A  21 "
          pdb=" CD  GLU A  51 "
   model   vdw sym.op.
   3.912 3.350 -x+1/2,y-1/2,-z+2
nonbonded pdb=" CE1 HIS A  64 "
          pdb=" N   SER A  66 "
   model   vdw
   3.913 3.340
nonbonded pdb=" CA  LEU A  49 "
          pdb=" CD1 LEU A  49 "
   model   vdw
   3.913 3.112
nonbonded pdb=" N   TYR A  61 "
          pdb="O    HOH S  54 "
   model   vdw
   3.913 3.120
nonbonded pdb=" C   TYR A  56 "
          pdb=" OH  TYR A  61 "
   model   vdw
   3.913 3.270
nonbonded pdb=" C   LEU A  49 "
          pdb=" CG  LEU A  49 "
   model   vdw
   3.915 2.960
nonbonded pdb=" CA  LEU A  65 "
          pdb=" CD2 LEU A  65 "
   model   vdw
   3.915 3.112
nonbonded pdb=" CA  GLN A  31 "
          pdb=" CD  GLN A  31 "
   model   vdw
   3.915 2.960
nonbonded pdb=" CA  ARG A  16 "
          pdb=" CD  ARG A  16 "
   model   vdw
   3.916 3.096
nonbonded pdb=" O   ASN A  29 "
          pdb=" CB  GLU A  30 "
   model   vdw
   3.916 3.440
nonbonded pdb=" CA  GLN A  72 "
          pdb=" CD  GLN A  72 "
   model   vdw
   3.916 2.960
nonbonded pdb=" CG2 THR A  15 "
          pdb="O    HOH S  34 "
   model   vdw
   3.917 3.460
nonbonded pdb=" N   LYS A   7 "
          pdb=" CD  LYS A   7 "
   model   vdw
   3.917 3.520
nonbonded pdb=" CD2 LEU A  28 "
          pdb=" NH2 ARG A  80 "
   model   vdw
   3.918 3.540
nonbonded pdb=" CG1 VAL A  35 "
          pdb=" CD2 LEU A  37 "
   model   vdw
   3.918 3.880
nonbonded pdb=" CD1 TYR A  34 "
          pdb=" O   VAL A  43 "
   model   vdw
   3.918 3.340
nonbonded pdb=" CA  LEU A  37 "
          pdb=" CD2 LEU A  65 "
   model   vdw sym.op.
   3.918 3.890 -x+1,y,-z+2
nonbonded pdb=" C   ASP A  50 "
          pdb=" N   GLY A  52 "
   model   vdw
   3.919 3.350
nonbonded pdb=" CB  THR A  14 "
          pdb="O    HOH S   8 "
   model   vdw
   3.919 3.470
nonbonded pdb=" O   MSE A  77 "
          pdb=" N   ASP A  79 "
   model   vdw
   3.919 3.120
nonbonded pdb=" CB  ALA A  11 "
          pdb=" CG  PRO A  58 "
   model   vdw
   3.919 3.860
nonbonded pdb=" C   LYS A   3 "
          pdb=" O   TYR A  61 "
   model   vdw
   3.919 3.270
nonbonded pdb=" CA  ILE A   6 "
          pdb=" O   GLY A  59 "
   model   vdw
   3.920 3.470
nonbonded pdb="O    HOH S  10 "
          pdb="O    HOH S 106 "
   model   vdw
   3.920 3.040
nonbonded pdb=" O   ALA A  11 "
          pdb=" CB  GLN A  12 "
   model   vdw
   3.921 3.440
nonbonded pdb=" O   SER A  27 "
          pdb=" CD2 LEU A  28 "
   model   vdw
   3.921 3.460
nonbonded pdb=" O   LYS A   3 "
          pdb=" CA  ASP A  36 "
   model   vdw
   3.921 3.470
nonbonded pdb=" N   TYR A  41 "
          pdb=" CD1 TYR A  41 "
   model   vdw
   3.921 3.420
nonbonded pdb=" CG  HIS A  64 "
          pdb=" OG  SER A  66 "
   model   vdw
   3.922 3.260
nonbonded pdb=" NE  ARG A  21 "
          pdb=" OE2 GLU A  51 "
   model   vdw sym.op.
   3.922 3.120 -x+1/2,y-1/2,-z+2
nonbonded pdb=" O   SER A  66 "
          pdb=" O   SER A  67 "
   model   vdw
   3.923 3.040
nonbonded pdb=" C   VAL A  35 "
          pdb=" O   ASP A  36 "
   model   vdw
   3.924 3.270
nonbonded pdb=" O   GLY A  74 "
          pdb=" O   SER A  75 "
   model   vdw
   3.924 3.040
nonbonded pdb=" C   PRO A  25 "
          pdb=" O   TYR A  26 "
   model   vdw
   3.926 3.270
nonbonded pdb=" CB  TYR A  61 "
          pdb=" CB  LEU A  83 "
   model   vdw
   3.927 3.840
nonbonded pdb=" C   LEU A  44 "
          pdb=" O   VAL A  45 "
   model   vdw
   3.927 3.270
nonbonded pdb=" CD2 LEU A  49 "
          pdb=" CD2 TYR A  56 "
   model   vdw
   3.927 3.760
nonbonded pdb=" C   SER A  75 "
          pdb="O    HOH S   4 "
   model   vdw
   3.927 3.270
nonbonded pdb=" CD1 LEU A  60 "
          pdb="O    HOH S  25 "
   model   vdw sym.op.
   3.927 3.460 -x+1,y+1,-z+2
nonbonded pdb="O    HOH S  25 "
          pdb=" CD1 LEU A  60 "
   model   vdw sym.op.
   3.927 3.460 -x+1,y-1,-z+2
nonbonded pdb=" CB  GLN A  53 "
          pdb=" CD  PRO A  54 "
   model   vdw
   3.927 3.840
nonbonded pdb=" CG  ASP A  79 "
          pdb=" NH1 ARG A  82 "
   model   vdw
   3.927 3.350
nonbonded pdb=" C   SER A  67 "
          pdb=" CD2 PHE A  68 "
   model   vdw
   3.928 3.570
nonbonded pdb=" CA  GLN A  31 "
          pdb="O    HOH S 151 "
   model   vdw
   3.928 3.470
nonbonded pdb=" O   GLN A  12 "
          pdb=" C   PHE A  13 "
   model   vdw
   3.928 3.270
nonbonded pdb=" C   GLU A  40 "
          pdb=" O   TYR A  41 "
   model   vdw
   3.929 3.270
nonbonded pdb=" CA  PRO A  42 "
          pdb="O    HOH S 123 "
   model   vdw
   3.929 3.470
nonbonded pdb=" O   LEU A  76 "
          pdb=" CG2 ILE A  78 "
   model   vdw sym.op.
   3.930 3.460 -x+1,y,-z+2
nonbonded pdb=" OE1 GLN A  31 "
          pdb=" CB  TYR A  56 "
   model   vdw
   3.930 3.440
nonbonded pdb=" C   VAL A  43 "
          pdb=" N   VAL A  45 "
   model   vdw
   3.931 3.350
nonbonded pdb=" CG  ARG A  16 "
          pdb=" O   LEU A  28 "
   model   vdw
   3.931 3.440
nonbonded pdb=" CG  ASP A  50 "
          pdb="O    HOH S 135 "
   model   vdw
   3.931 3.270
nonbonded pdb=" C   CYS A  33 "
          pdb=" CD2 TYR A  34 "
   model   vdw
   3.932 3.570
nonbonded pdb=" CA  SER A  75 "
          pdb="O    HOH S   4 "
   model   vdw
   3.932 3.470
nonbonded pdb=" O   LYS A   3 "
          pdb=" O   TYR A  34 "
   model   vdw
   3.932 3.040
nonbonded pdb=" CD1 ILE A  47 "
          pdb=" CD2 TYR A  56 "
   model   vdw
   3.932 3.760
nonbonded pdb=" O   ASP A  36 "
          pdb=" CG  LEU A  65 "
   model   vdw sym.op.
   3.933 3.470 -x+1,y,-z+2
nonbonded pdb=" CG2 ILE A  47 "
          pdb="O    HOH S 106 "
   model   vdw
   3.933 3.460
nonbonded pdb=" O   GLY A  71 "
          pdb=" O   GLN A  72 "
   model   vdw
   3.933 3.040
nonbonded pdb=" C   LYS A  46 "
          pdb="O    HOH S  10 "
   model   vdw
   3.934 3.270
nonbonded pdb=" O   SER A   9 "
          pdb=" O   THR A  15 "
   model   vdw sym.op.
   3.935 3.040 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CD  ARG A  16 "
          pdb="O    HOH S  85 "
   model   vdw
   3.936 3.440
nonbonded pdb=" C   THR A  62 "
          pdb=" CG2 VAL A  63 "
   model   vdw
   3.937 3.690
nonbonded pdb=" C   PHE A  68 "
          pdb=" CG  LYS A  69 "
   model   vdw
   3.937 3.670
nonbonded pdb=" C   VAL A   4 "
          pdb=" N   TYR A  61 "
   model   vdw
   3.938 3.350
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" CA  PRO A  58 "
   model   vdw
   3.938 3.890
nonbonded pdb=" O   GLN A  72 "
          pdb=" N   GLY A  74 "
   model   vdw
   3.939 3.120
nonbonded pdb=" C   SER A  67 "
          pdb=" O   ARG A  80 "
   model   vdw
   3.939 3.270
nonbonded pdb=" CE1 HIS A  64 "
          pdb=" CB  SER A  66 "
   model   vdw
   3.940 3.660
nonbonded pdb=" C   ASP A  36 "
          pdb=" CG  LEU A  37 "
   model   vdw
   3.940 3.700
nonbonded pdb=" O   GLY A  18 "
          pdb=" C   VAL A  19 "
   model   vdw
   3.940 3.270
nonbonded pdb=" CE1 TYR A  41 "
          pdb=" CD  PRO A  42 "
   model   vdw sym.op.
   3.940 3.740 -x+1,y,-z+1
nonbonded pdb=" CD  PRO A  42 "
          pdb=" CE1 TYR A  41 "
   model   vdw sym.op.
   3.940 3.740 -x+1,y,-z+1
nonbonded pdb=" C   SER A  17 "
          pdb=" CE1 TYR A  26 "
   model   vdw
   3.940 3.570
nonbonded pdb=" O   ARG A  16 "
          pdb=" CB  SER A  17 "
   model   vdw
   3.941 3.440
nonbonded pdb=" CG  GLU A   5 "
          pdb=" C   ILE A   6 "
   model   vdw
   3.943 3.670
nonbonded pdb=" C   GLY A  71 "
          pdb="O    HOH S 103 "
   model   vdw sym.op.
   3.943 3.270 -x,y+1,-z+1
nonbonded pdb=" O   LYS A  69 "
          pdb=" CG  LEU A  76 "
   model   vdw
   3.944 3.470
nonbonded pdb=" C   THR A  15 "
          pdb="O    HOH S   8 "
   model   vdw
   3.944 3.270
nonbonded pdb=" C   GLY A  18 "
          pdb=" CZ  TYR A  26 "
   model   vdw
   3.944 3.490
nonbonded pdb=" CG2 THR A  15 "
          pdb=" O   LEU A  28 "
   model   vdw
   3.944 3.460
nonbonded pdb=" CD2 TYR A  41 "
          pdb=" OH  TYR A  34 "
   model   vdw sym.op.
   3.945 3.340 -x+1,y,-z+1
nonbonded pdb=" OH  TYR A  34 "
          pdb=" CD2 TYR A  41 "
   model   vdw sym.op.
   3.945 3.340 -x+1,y,-z+1
nonbonded pdb=" CE1 PHE A  68 "
          pdb=" CD1 ILE A  78 "
   model   vdw
   3.946 3.760
nonbonded pdb=" CG2 THR A  48 "
          pdb=" NH1 ARG A  80 "
   model   vdw
   3.946 3.540
nonbonded pdb=" CB  ILE A   6 "
          pdb=" CA  PRO A  58 "
   model   vdw
   3.948 3.900
nonbonded pdb=" O   LYS A   7 "
          pdb=" C   SER A   9 "
   model   vdw
   3.948 3.270
nonbonded pdb=" CG2 VAL A  84 "
          pdb=" N   PRO A  85 "
   model   vdw
   3.948 3.540
nonbonded pdb=" O   LEU A  28 "
          pdb=" N   GLU A  30 "
   model   vdw
   3.949 3.120
nonbonded pdb=" C   SER A  67 "
          pdb=" N   ASP A  79 "
   model   vdw
   3.949 3.350
nonbonded pdb=" CG1 ILE A   6 "
          pdb=" CD1 TYR A  61 "
   model   vdw
   3.950 3.740
nonbonded pdb=" O   LYS A   3 "
          pdb=" CG1 VAL A  35 "
   model   vdw
   3.950 3.460
nonbonded pdb=" CG  LYS A  69 "
          pdb=" CB  ASP A  79 "
   model   vdw
   3.950 3.840
nonbonded pdb=" O   LEU A  76 "
          pdb=" CD1 ILE A  78 "
   model   vdw sym.op.
   3.951 3.460 -x+1,y,-z+2
nonbonded pdb=" CB  VAL A  19 "
          pdb=" O   LYS A  24 "
   model   vdw
   3.951 3.470
nonbonded pdb=" CB  VAL A  45 "
          pdb=" O   GLY A  74 "
   model   vdw sym.op.
   3.951 3.470 -x+1,y,-z+2
nonbonded pdb=" CD  GLN A  10 "
          pdb=" CE2 TYR A  34 "
   model   vdw
   3.951 3.570
nonbonded pdb=" OG  SER A  20 "
          pdb=" C   LYS A  24 "
   model   vdw
   3.952 3.270
nonbonded pdb=" CB  TYR A  41 "
          pdb=" O   PRO A  42 "
   model   vdw
   3.952 3.440
nonbonded pdb=" CA  GLY A  38 "
          pdb="O    HOH S 131 "
   model   vdw
   3.952 3.440
nonbonded pdb=" CB  LYS A   7 "
          pdb=" OG  SER A   9 "
   model   vdw
   3.952 3.440
nonbonded pdb=" CB  GLU A   5 "
          pdb=" O   GLY A  59 "
   model   vdw
   3.954 3.440
nonbonded pdb=" C   SER A  75 "
          pdb=" N   MSE A  77 "
   model   vdw
   3.954 3.350
nonbonded pdb=" O   GLY A  71 "
          pdb="O    HOH S   4 "
   model   vdw
   3.954 3.040
nonbonded pdb=" CG1 ILE A  47 "
          pdb=" N   THR A  48 "
   model   vdw
   3.955 3.520
nonbonded pdb=" OE2 GLU A  30 "
          pdb="O    HOH S   8 "
   model   vdw
   3.955 3.040
nonbonded pdb=" CB  LYS A   7 "
          pdb=" N   SER A   9 "
   model   vdw
   3.955 3.520
nonbonded pdb=" C   VAL A  19 "
          pdb=" CD2 TYR A  26 "
   model   vdw
   3.956 3.570
nonbonded pdb=" C   LYS A  69 "
          pdb=" O   MSE A  77 "
   model   vdw
   3.956 3.270
nonbonded pdb=" CG2 THR A  15 "
          pdb=" OD1 ASN A  29 "
   model   vdw
   3.957 3.460
nonbonded pdb=" C   PRO A  54 "
          pdb=" N   TYR A  56 "
   model   vdw
   3.957 3.350
nonbonded pdb=" OH  TYR A  41 "
          pdb=" CD  PRO A  42 "
   model   vdw sym.op.
   3.957 3.440 -x+1,y,-z+1
nonbonded pdb=" CD  PRO A  42 "
          pdb=" OH  TYR A  41 "
   model   vdw sym.op.
   3.957 3.440 -x+1,y,-z+1
nonbonded pdb=" C   VAL A  19 "
          pdb=" CE2 TYR A  26 "
   model   vdw
   3.958 3.570
nonbonded pdb=" ND1 HIS A  64 "
          pdb=" CA  SER A  66 "
   model   vdw
   3.958 3.550
nonbonded pdb=" C   GLY A  59 "
          pdb=" CE1 TYR A  61 "
   model   vdw
   3.960 3.570
nonbonded pdb=" C   VAL A  35 "
          pdb=" N   VAL A  43 "
   model   vdw
   3.960 3.350
nonbonded pdb=" NH1 ARG A  16 "
          pdb=" C   PRO A  85 "
   model   vdw sym.op.
   3.962 3.350 x,y-1,z
nonbonded pdb=" O   LYS A   7 "
          pdb=" CG  PRO A  58 "
   model   vdw
   3.962 3.440
nonbonded pdb=" C   GLY A  59 "
          pdb=" CG  LEU A  60 "
   model   vdw
   3.962 3.700
nonbonded pdb=" C   GLU A  30 "
          pdb=" O   GLN A  31 "
   model   vdw
   3.962 3.270
nonbonded pdb=" CD1 LEU A  32 "
          pdb=" CA  LYS A  46 "
   model   vdw
   3.963 3.890
nonbonded pdb=" O   VAL A   4 "
          pdb=" C   GLU A   5 "
   model   vdw
   3.964 3.270
nonbonded pdb=" CB  VAL A   4 "
          pdb=" O   TYR A  61 "
   model   vdw
   3.965 3.470
nonbonded pdb=" O   PRO A   8 "
          pdb=" CB  THR A  14 "
   model   vdw sym.op.
   3.965 3.470 -x+1/2,y+1/2,-z+1
nonbonded pdb=" O   LYS A  24 "
          pdb=" CG  LYS A  24 "
   model   vdw
   3.965 3.440
nonbonded pdb=" OH  TYR A  56 "
          pdb=" O   LEU A  83 "
   model   vdw
   3.965 3.040
nonbonded pdb=" O   ARG A  21 "
          pdb=" CB  GLN A  22 "
   model   vdw
   3.966 3.440
nonbonded pdb=" CG  ASP A  79 "
          pdb="O    HOH S  97 "
   model   vdw sym.op.
   3.966 3.270 -x+1/2,y+1/2,-z+2
nonbonded pdb=" NE2 GLN A  53 "
          pdb="O    HOH S  81 "
   model   vdw sym.op.
   3.966 3.120 x,y+1,z
nonbonded pdb=" O   CYS A  33 "
          pdb=" CA  VAL A  45 "
   model   vdw
   3.967 3.470
nonbonded pdb=" CD1 ILE A  78 "
          pdb=" CG1 ILE A  78 "
   model   vdw sym.op.
   3.967 3.860 -x+1,y,-z+2
nonbonded pdb=" CG1 ILE A  78 "
          pdb=" CD1 ILE A  78 "
   model   vdw sym.op.
   3.967 3.860 -x+1,y,-z+2
nonbonded pdb=" C   SER A  66 "
          pdb=" NH1 ARG A  82 "
   model   vdw
   3.968 3.350
nonbonded pdb=" C   LEU A  32 "
          pdb=" O   CYS A  33 "
   model   vdw
   3.968 3.270
nonbonded pdb=" O   GLN A  72 "
          pdb=" CB  PHE A  73 "
   model   vdw
   3.968 3.440
nonbonded pdb=" C   ASN A  29 "
          pdb=" O   GLU A  30 "
   model   vdw
   3.969 3.270
nonbonded pdb=" OE1 GLN A  10 "
          pdb=" C   LEU A  32 "
   model   vdw
   3.970 3.270
nonbonded pdb=" N   SER A   9 "
          pdb="O    HOH S 117 "
   model   vdw sym.op.
   3.970 3.120 -x+1/2,y+1/2,-z+1
nonbonded pdb=" O   GLN A  31 "
          pdb=" O   VAL A  45 "
   model   vdw
   3.970 3.040
nonbonded pdb=" CB  GLU A  51 "
          pdb="O    HOH S 175 "
   model   vdw
   3.970 3.440
nonbonded pdb=" CE2 TYR A  34 "
          pdb=" CD1 LEU A  44 "
   model   vdw
   3.971 3.760
nonbonded pdb=" CG  LYS A   7 "
          pdb=" OE1 GLN A  10 "
   model   vdw
   3.973 3.440
nonbonded pdb=" CG1 VAL A  19 "
          pdb=" C   LYS A  24 "
   model   vdw
   3.973 3.690
nonbonded pdb=" O   VAL A  19 "
          pdb=" CE2 TYR A  26 "
   model   vdw
   3.975 3.340
nonbonded pdb=" O   THR A  48 "
          pdb="O    HOH S 106 "
   model   vdw
   3.975 3.040
nonbonded pdb=" OE1 GLN A  10 "
          pdb=" C   CYS A  33 "
   model   vdw
   3.975 3.270
nonbonded pdb=" O   SER A   9 "
          pdb=" CB  GLN A  10 "
   model   vdw
   3.976 3.440
nonbonded pdb=" NE2 GLN A  10 "
          pdb=" O   CYS A  33 "
   model   vdw
   3.976 3.120
nonbonded pdb=" C   LYS A   7 "
          pdb=" O   PRO A   8 "
   model   vdw
   3.976 3.270
nonbonded pdb=" CD1 ILE A  47 "
          pdb=" CD1 LEU A  83 "
   model   vdw
   3.977 3.880
nonbonded pdb=" CG  LEU A  37 "
          pdb=" CG1 VAL A  43 "
   model   vdw
   3.977 3.890
nonbonded pdb=" N   VAL A  63 "
          pdb="O    HOH S  12 "
   model   vdw
   3.977 3.120
nonbonded pdb=" C   SER A   9 "
          pdb=" O   THR A  15 "
   model   vdw sym.op.
   3.979 3.270 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CD1 TYR A  34 "
          pdb=" C   VAL A  43 "
   model   vdw
   3.979 3.570
nonbonded pdb=" O   PHE A  13 "
          pdb=" CB  THR A  14 "
   model   vdw
   3.980 3.470
nonbonded pdb=" C   ASP A  79 "
          pdb=" OD2 ASP A  79 "
   model   vdw
   3.980 3.270
nonbonded pdb=" CD1 ILE A   6 "
          pdb=" NE2 GLN A  31 "
   model   vdw
   3.981 3.540
nonbonded pdb=" CD1 LEU A  49 "
          pdb=" CA  ALA A  55 "
   model   vdw
   3.981 3.890
nonbonded pdb=" O   THR A  15 "
          pdb=" CB  ARG A  16 "
   model   vdw
   3.981 3.440
nonbonded pdb=" C   HIS A  64 "
          pdb=" CD2 HIS A  64 "
   model   vdw
   3.981 3.490
nonbonded pdb=" O   THR A  14 "
          pdb=" OG1 THR A  15 "
   model   vdw
   3.981 3.040
nonbonded pdb=" O   ARG A  80 "
          pdb=" CB  ARG A  82 "
   model   vdw
   3.982 3.440
nonbonded pdb=" CG1 VAL A  70 "
          pdb=" C   GLY A  74 "
   model   vdw
   3.982 3.690
nonbonded pdb=" CA  GLY A  18 "
          pdb=" CD2 TYR A  26 "
   model   vdw
   3.982 3.740
nonbonded pdb=" CE  LYS A  24 "
          pdb=" CZ  ARG A  82 "
   model   vdw sym.op.
   3.983 3.670 -x+1/2,y-1/2,-z+2
nonbonded pdb=" CZ  ARG A  82 "
          pdb=" CE  LYS A  24 "
   model   vdw sym.op.
   3.983 3.670 -x+1/2,y+1/2,-z+2
nonbonded pdb=" CG  HIS A  64 "
          pdb=" N   SER A  66 "
   model   vdw
   3.984 3.340
nonbonded pdb=" CD1 LEU A  37 "
          pdb="O    HOH S  16 "
   model   vdw sym.op.
   3.984 3.460 -x+1,y,-z+2
nonbonded pdb=" O   PRO A  25 "
          pdb=" CG  PRO A  25 "
   model   vdw
   3.985 3.440
nonbonded pdb=" C   LEU A  81 "
          pdb=" O   ARG A  82 "
   model   vdw
   3.985 3.270
nonbonded pdb=" C   GLY A  59 "
          pdb=" CD1 TYR A  61 "
   model   vdw
   3.985 3.570
nonbonded pdb=" CD  GLN A  10 "
          pdb=" CD2 TYR A  34 "
   model   vdw
   3.985 3.570
nonbonded pdb=" SG  CYS A  33 "
          pdb=" CG2 VAL A  35 "
   model   vdw
   3.985 3.820
nonbonded pdb=" CB  LYS A   7 "
          pdb=" CG  GLN A  10 "
   model   vdw
   3.986 3.840
nonbonded pdb=" O   LEU A  81 "
          pdb=" CB  ARG A  82 "
   model   vdw
   3.986 3.440
nonbonded pdb=" CD1 LEU A  32 "
          pdb=" CB  LYS A  46 "
   model   vdw
   3.986 3.860
nonbonded pdb=" CA  GLN A  53 "
          pdb=" O   PRO A  54 "
   model   vdw
   3.987 3.470
nonbonded pdb=" N   VAL A  35 "
          pdb=" C   VAL A  43 "
   model   vdw
   3.987 3.350
nonbonded pdb=" OG  SER A  20 "
          pdb=" C   ARG A  21 "
   model   vdw
   3.987 3.270
nonbonded pdb=" CG2 THR A  15 "
          pdb="O    HOH S 117 "
   model   vdw
   3.987 3.460
nonbonded pdb=" O   VAL A  45 "
          pdb=" CB  LYS A  46 "
   model   vdw
   3.988 3.440
nonbonded pdb=" N   ILE A   2 "
          pdb="O    HOH S   2 "
   model   vdw
   3.988 3.120
nonbonded pdb=" O   PHE A  13 "
          pdb=" CG2 THR A  14 "
   model   vdw
   3.988 3.460
nonbonded pdb=" O   LEU A  76 "
          pdb=" CG  LEU A  76 "
   model   vdw
   3.988 3.470
nonbonded pdb=" O   TYR A  61 "
          pdb=" CZ  PHE A  73 "
   model   vdw sym.op.
   3.989 3.340 -x+1,y+1,-z+2
nonbonded pdb=" CA  GLY A  18 "
          pdb=" CE1 TYR A  26 "
   model   vdw
   3.989 3.740
nonbonded pdb=" O   ILE A   2 "
          pdb=" N   VAL A   4 "
   model   vdw
   3.990 3.120
nonbonded pdb=" N   GLU A   5 "
          pdb=" C   TYR A  34 "
   model   vdw
   3.990 3.350
nonbonded pdb=" C   MSE A  77 "
          pdb=" O   ILE A  78 "
   model   vdw
   3.991 3.270
nonbonded pdb=" O   VAL A  45 "
          pdb=" N   ILE A  47 "
   model   vdw
   3.991 3.120
nonbonded pdb=" CG2 ILE A   2 "
          pdb=" CG2 VAL A  63 "
   model   vdw
   3.993 3.880
nonbonded pdb=" N   GLY A  18 "
          pdb=" CD1 TYR A  26 "
   model   vdw
   3.994 3.420
nonbonded pdb=" CG2 THR A  48 "
          pdb=" NH2 ARG A  80 "
   model   vdw
   3.995 3.540
nonbonded pdb=" CB  ARG A  80 "
          pdb=" CZ  ARG A  82 "
   model   vdw
   3.995 3.670
nonbonded pdb=" C   GLY A  18 "
          pdb=" N   TYR A  26 "
   model   vdw
   3.995 3.350
nonbonded pdb=" C   MSE A  77 "
          pdb=" N   ASP A  79 "
   model   vdw
   3.995 3.350
nonbonded pdb=" C   PHE A  73 "
          pdb="O    HOH S  25 "
   model   vdw
   3.996 3.270
nonbonded pdb=" CB  ALA A  57 "
          pdb=" OH  TYR A  61 "
   model   vdw
   3.996 3.460
nonbonded pdb=" O   THR A  14 "
          pdb=" CB  THR A  15 "
   model   vdw
   3.996 3.470
nonbonded pdb=" CG2 ILE A  78 "
          pdb=" N   ARG A  80 "
   model   vdw
   3.996 3.540
nonbonded pdb=" N   ILE A   2 "
          pdb="O    HOH S  12 "
   model   vdw
   3.998 3.120
nonbonded pdb=" O   TYR A  56 "
          pdb=" N   PRO A  58 "
   model   vdw
   3.998 3.120
nonbonded pdb=" C   GLU A   5 "
          pdb=" O   ILE A   6 "
   model   vdw
   3.998 3.270
nonbonded pdb=" O   PHE A  13 "
          pdb=" CE1 PHE A  13 "
   model   vdw
   3.998 3.340
nonbonded pdb=" O   VAL A  63 "
          pdb="O    HOH S  35 "
   model   vdw
   3.998 3.040
nonbonded pdb=" O   ALA A  11 "
          pdb=" CG  GLN A  12 "
   model   vdw
   3.999 3.440
nonbonded pdb=" C   LYS A  69 "
          pdb=" CD1 LEU A  76 "
   model   vdw
   3.999 3.690
nonbonded pdb=" C   GLY A  18 "
          pdb=" O   VAL A  19 "
   model   vdw
   3.999 3.270
nonbonded pdb=" O   LYS A   7 "
          pdb=" CB  PRO A  58 "
   model   vdw
   3.999 3.440
nonbonded pdb=" N   SER A  20 "
          pdb=" CD2 TYR A  26 "
   model   vdw
   3.999 3.420
nonbonded pdb=" OE1 GLN A  31 "
          pdb=" CA  TYR A  56 "
   model   vdw
   4.000 3.470
nonbonded pdb=" CB  TYR A  56 "
          pdb=" O   ALA A  57 "
   model   vdw
   4.001 3.440
nonbonded pdb=" C   ALA A  55 "
          pdb="O    HOH S  98 "
   model   vdw
   4.001 3.270
nonbonded pdb=" CG1 ILE A   2 "
          pdb=" CG2 VAL A  63 "
   model   vdw
   4.002 3.860
nonbonded pdb=" CA  GLN A  31 "
          pdb=" O   ILE A  47 "
   model   vdw
   4.002 3.470
nonbonded pdb=" C   THR A  62 "
          pdb=" N   HIS A  64 "
   model   vdw
   4.003 3.350
nonbonded pdb=" CB  VAL A  19 "
          pdb=" CG  PRO A  54 "
   model   vdw sym.op.
   4.004 3.870 x,y-1,z
nonbonded pdb=" O   ASN A  29 "
          pdb=" CG2 THR A  48 "
   model   vdw
   4.004 3.460
nonbonded pdb=" C   LEU A  44 "
          pdb="O    HOH S  17 "
   model   vdw
   4.004 3.270
nonbonded pdb=" CA  THR A  62 "
          pdb=" O   VAL A  84 "
   model   vdw
   4.004 3.470
nonbonded pdb=" O   SER A  66 "
          pdb=" O   PHE A  68 "
   model   vdw
   4.004 3.040
nonbonded pdb=" CB  TYR A  34 "
          pdb=" O   VAL A  43 "
   model   vdw
   4.005 3.440
nonbonded pdb=" O   LEU A  28 "
          pdb=" CB  ASN A  29 "
   model   vdw
   4.005 3.440
nonbonded pdb=" CG1 VAL A  70 "
          pdb=" O   GLY A  71 "
   model   vdw
   4.005 3.460
nonbonded pdb=" O   HIS A  64 "
          pdb=" C   SER A  66 "
   model   vdw
   4.005 3.270
nonbonded pdb=" CA  ASP A  36 "
          pdb=" CB  PRO A  42 "
   model   vdw
   4.006 3.870
nonbonded pdb=" CB  SER A  66 "
          pdb=" NH1 ARG A  21 "
   model   vdw sym.op.
   4.006 3.520 x,y+1,z
nonbonded pdb=" NH1 ARG A  21 "
          pdb=" CB  SER A  66 "
   model   vdw sym.op.
   4.006 3.520 x,y-1,z
nonbonded pdb=" CD2 LEU A  28 "
          pdb=" CG2 THR A  48 "
   model   vdw
   4.006 3.880
nonbonded pdb=" N   ARG A  80 "
          pdb=" NH1 ARG A  82 "
   model   vdw
   4.006 3.200
nonbonded pdb=" O   GLN A  31 "
          pdb=" O   LEU A  32 "
   model   vdw
   4.007 3.040
nonbonded pdb=" CZ  TYR A  61 "
          pdb="O    HOH S  14 "
   model   vdw
   4.007 3.260
nonbonded pdb=" O   THR A  14 "
          pdb=" CB  GLU A  30 "
   model   vdw
   4.008 3.440
nonbonded pdb=" CG  GLU A  51 "
          pdb=" N   GLY A  52 "
   model   vdw
   4.008 3.520
nonbonded pdb=" O   VAL A   4 "
          pdb=" CD2 LEU A  60 "
   model   vdw
   4.009 3.460
nonbonded pdb=" O   LEU A  49 "
          pdb=" N   GLU A  51 "
   model   vdw
   4.009 3.120
nonbonded pdb=" O   THR A  62 "
          pdb=" O   VAL A  63 "
   model   vdw
   4.009 3.040
nonbonded pdb=" CD1 PHE A  13 "
          pdb=" ND2 ASN A  29 "
   model   vdw
   4.010 3.420
nonbonded pdb=" CG  LEU A  81 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   4.010 3.890
nonbonded pdb=" NH2 ARG A  16 "
          pdb=" CD2 TYR A  61 "
   model   vdw sym.op.
   4.011 3.420 x,y-1,z
nonbonded pdb=" O   ASN A  29 "
          pdb=" O   ILE A  47 "
   model   vdw
   4.011 3.040
nonbonded pdb=" C   GLY A  71 "
          pdb=" N   GLY A  74 "
   model   vdw
   4.011 3.350
nonbonded pdb=" C   ASP A  36 "
          pdb=" CD2 LEU A  37 "
   model   vdw
   4.011 3.690
nonbonded pdb=" O   ARG A  80 "
          pdb=" CA  ARG A  82 "
   model   vdw
   4.012 3.470
nonbonded pdb=" O   GLU A   5 "
          pdb=" CB  TYR A  34 "
   model   vdw
   4.012 3.440
nonbonded pdb=" CD2 TYR A  61 "
          pdb=" CB  LEU A  83 "
   model   vdw
   4.012 3.740
nonbonded pdb=" CB  LYS A  24 "
          pdb=" NH2 ARG A  82 "
   model   vdw sym.op.
   4.013 3.520 -x+1/2,y-1/2,-z+2
nonbonded pdb=" NH2 ARG A  82 "
          pdb=" CB  LYS A  24 "
   model   vdw sym.op.
   4.013 3.520 -x+1/2,y+1/2,-z+2
nonbonded pdb=" C   THR A  14 "
          pdb=" O   THR A  15 "
   model   vdw
   4.013 3.270
nonbonded pdb=" O   LEU A  83 "
          pdb=" CG2 VAL A  84 "
   model   vdw
   4.013 3.460
nonbonded pdb=" O   LEU A  83 "
          pdb=" C   VAL A  84 "
   model   vdw
   4.014 3.270
nonbonded pdb=" CD2 LEU A  76 "
          pdb=" CD1 LEU A  81 "
   model   vdw sym.op.
   4.014 3.880 -x+1,y,-z+2
nonbonded pdb=" O   LEU A  60 "
          pdb=" C   TYR A  61 "
   model   vdw
   4.015 3.270
nonbonded pdb=" C   PRO A  58 "
          pdb=" O   GLY A  59 "
   model   vdw
   4.015 3.270
nonbonded pdb=" NE2 HIS A  64 "
          pdb="O    HOH S  35 "
   model   vdw
   4.015 3.120
nonbonded pdb=" CA  LYS A  69 "
          pdb=" O   MSE A  77 "
   model   vdw
   4.016 3.470
nonbonded pdb=" CG2 VAL A   4 "
          pdb=" CG2 VAL A  63 "
   model   vdw
   4.016 3.880
nonbonded pdb=" O   GLN A  53 "
          pdb=" N   ALA A  55 "
   model   vdw
   4.016 3.120
nonbonded pdb=" O   SER A  17 "
          pdb=" CB  ALA A  57 "
   model   vdw sym.op.
   4.017 3.460 x,y-1,z
nonbonded pdb=" CG2 THR A  62 "
          pdb=" O   VAL A  84 "
   model   vdw
   4.018 3.460
nonbonded pdb=" O   TYR A  34 "
          pdb=" CB  VAL A  35 "
   model   vdw
   4.019 3.470
nonbonded pdb=" OG  SER A  66 "
          pdb=" NH1 ARG A  21 "
   model   vdw sym.op.
   4.021 3.120 x,y+1,z
nonbonded pdb=" NH1 ARG A  21 "
          pdb=" OG  SER A  66 "
   model   vdw sym.op.
   4.021 3.120 x,y-1,z
nonbonded pdb=" O   PRO A  42 "
          pdb=" CB  VAL A  43 "
   model   vdw
   4.021 3.470
nonbonded pdb=" C   GLY A  38 "
          pdb=" CG  ASN A  39 "
   model   vdw
   4.021 3.500
nonbonded pdb=" C   ILE A  47 "
          pdb=" O   THR A  48 "
   model   vdw
   4.021 3.270
nonbonded pdb=" NH2 ARG A  21 "
          pdb=" CG  GLU A  51 "
   model   vdw sym.op.
   4.022 3.520 -x+1/2,y-1/2,-z+2
nonbonded pdb=" C   THR A  48 "
          pdb=" N   ASP A  50 "
   model   vdw
   4.022 3.350
nonbonded pdb=" C   SER A  17 "
          pdb=" O   GLY A  18 "
   model   vdw
   4.023 3.270
nonbonded pdb=" CB  ALA A  11 "
          pdb=" CD  PRO A  58 "
   model   vdw
   4.024 3.860
nonbonded pdb=" CG1 ILE A   6 "
          pdb=" O   ALA A  57 "
   model   vdw
   4.024 3.440
nonbonded pdb=" O   GLN A  31 "
          pdb=" CG  LYS A  46 "
   model   vdw
   4.024 3.440
nonbonded pdb=" O   ASP A  36 "
          pdb=" CB  LEU A  37 "
   model   vdw
   4.025 3.440
nonbonded pdb=" CD2 LEU A  81 "
          pdb="O    HOH S  10 "
   model   vdw
   4.026 3.460
nonbonded pdb=" C   SER A  66 "
          pdb=" OG  SER A  67 "
   model   vdw
   4.026 3.270
nonbonded pdb=" CB  GLU A  30 "
          pdb=" O   ILE A  47 "
   model   vdw
   4.026 3.440
nonbonded pdb=" O   TYR A  34 "
          pdb=" CG2 VAL A  35 "
   model   vdw
   4.026 3.460
nonbonded pdb=" O   LEU A  81 "
          pdb=" N   LEU A  83 "
   model   vdw
   4.027 3.120
nonbonded pdb=" O   LEU A  37 "
          pdb=" CD2 LEU A  65 "
   model   vdw sym.op.
   4.027 3.460 -x+1,y,-z+2
nonbonded pdb=" CB  THR A  15 "
          pdb=" O   LEU A  28 "
   model   vdw
   4.028 3.470
nonbonded pdb=" CE2 TYR A  61 "
          pdb=" CA  PRO A  85 "
   model   vdw
   4.029 3.770
nonbonded pdb=" CG  LEU A  81 "
          pdb=" N   ARG A  82 "
   model   vdw
   4.029 3.550
nonbonded pdb=" CG  ARG A  16 "
          pdb=" OE2 GLU A  30 "
   model   vdw
   4.029 3.440
nonbonded pdb=" OD1 ASP A  50 "
          pdb="O    HOH S 175 "
   model   vdw
   4.030 3.040
nonbonded pdb=" NE2 GLN A  10 "
          pdb=" O   LEU A  32 "
   model   vdw
   4.030 3.120
nonbonded pdb=" CG  GLU A   5 "
          pdb=" O   ILE A   6 "
   model   vdw
   4.030 3.440
nonbonded pdb=" C   GLN A  10 "
          pdb=" NE2 GLN A  31 "
   model   vdw
   4.030 3.350
nonbonded pdb=" OD2 ASP A  50 "
          pdb=" CG  ARG A  82 "
   model   vdw
   4.031 3.440
nonbonded pdb=" CD1 TYR A  56 "
          pdb=" CE2 TYR A  61 "
   model   vdw
   4.032 3.640
nonbonded pdb=" OH  TYR A  41 "
          pdb=" CB  PRO A  42 "
   model   vdw sym.op.
   4.032 3.440 -x+1,y,-z+1
nonbonded pdb=" N   VAL A   4 "
          pdb=" C   TYR A  61 "
   model   vdw
   4.032 3.350
nonbonded pdb=" C   HIS A  64 "
          pdb=" O   LEU A  65 "
   model   vdw
   4.033 3.270
nonbonded pdb=" CG2 VAL A  45 "
          pdb=" N   LEU A  76 "
   model   vdw sym.op.
   4.033 3.540 -x+1,y,-z+2
nonbonded pdb=" ND2 ASN A  29 "
          pdb="O    HOH S  33 "
   model   vdw
   4.033 3.120
nonbonded pdb=" CB  LYS A   3 "
          pdb=" CZ  PHE A  73 "
   model   vdw sym.op.
   4.033 3.740 -x+1,y+1,-z+2
nonbonded pdb=" O   VAL A  63 "
          pdb=" N   LEU A  65 "
   model   vdw
   4.033 3.120
nonbonded pdb=" C   SER A  27 "
          pdb=" O   LEU A  28 "
   model   vdw
   4.033 3.270
nonbonded pdb=" N   ARG A  16 "
          pdb="O    HOH S  34 "
   model   vdw
   4.034 3.120
nonbonded pdb=" C   VAL A   4 "
          pdb=" O   GLU A   5 "
   model   vdw
   4.034 3.270
nonbonded pdb=" O   ARG A  82 "
          pdb=" O   LEU A  83 "
   model   vdw
   4.034 3.040
nonbonded pdb=" CA  CYS A  33 "
          pdb=" O   VAL A  45 "
   model   vdw
   4.034 3.470
nonbonded pdb=" CB  ARG A  80 "
          pdb=" NH2 ARG A  82 "
   model   vdw
   4.035 3.520
nonbonded pdb=" O   SER A  67 "
          pdb=" C   ASP A  79 "
   model   vdw
   4.035 3.270
nonbonded pdb=" N   SER A  17 "
          pdb="O    HOH S  85 "
   model   vdw
   4.035 3.120
nonbonded pdb=" O   LEU A  81 "
          pdb=" CG  ARG A  82 "
   model   vdw
   4.035 3.440
nonbonded pdb=" CG1 VAL A  19 "
          pdb=" CA  GLY A  23 "
   model   vdw
   4.036 3.860
nonbonded pdb=" C   ARG A  16 "
          pdb="O    HOH S  85 "
   model   vdw
   4.036 3.270
nonbonded pdb=" NE2 GLN A  72 "
          pdb=" CB  LYS A   3 "
   model   vdw sym.op.
   4.036 3.520 -x+1,y-1,-z+2
nonbonded pdb=" CB  LYS A   3 "
          pdb=" NE2 GLN A  72 "
   model   vdw sym.op.
   4.036 3.520 -x+1,y+1,-z+2
nonbonded pdb=" CA  PRO A   8 "
          pdb=" CB  PRO A  58 "
   model   vdw
   4.037 3.870
nonbonded pdb=" O   HIS A  64 "
          pdb=" CE2 PHE A  68 "
   model   vdw
   4.037 3.340
nonbonded pdb=" CB  PHE A  13 "
          pdb=" CD1 LEU A  49 "
   model   vdw
   4.037 3.860
nonbonded pdb=" C   LYS A  46 "
          pdb=" CD  LYS A  46 "
   model   vdw
   4.038 3.670
nonbonded pdb=" CG2 THR A  15 "
          pdb=" C   ARG A  16 "
   model   vdw
   4.038 3.690
nonbonded pdb=" O   PRO A  25 "
          pdb=" C   TYR A  26 "
   model   vdw
   4.038 3.270
nonbonded pdb=" N   PRO A   8 "
          pdb=" CB  PRO A  58 "
   model   vdw
   4.038 3.520
nonbonded pdb=" OG  SER A  20 "
          pdb=" C   GLN A  22 "
   model   vdw
   4.038 3.270
nonbonded pdb=" O   GLU A  30 "
          pdb=" C   GLN A  31 "
   model   vdw
   4.039 3.270
nonbonded pdb=" O   SER A   9 "
          pdb=" CG  GLN A  10 "
   model   vdw
   4.039 3.440
nonbonded pdb=" CD  ARG A  80 "
          pdb=" NH2 ARG A  82 "
   model   vdw
   4.040 3.520
nonbonded pdb=" C   GLY A  23 "
          pdb=" N   PRO A  25 "
   model   vdw
   4.040 3.350
nonbonded pdb=" OG  SER A  27 "
          pdb=" OD1 ASN A  29 "
   model   vdw
   4.040 3.040
nonbonded pdb=" O   THR A  48 "
          pdb=" CG  ARG A  80 "
   model   vdw
   4.040 3.440
nonbonded pdb="O    HOH S   7 "
          pdb="O    HOH S 151 "
   model   vdw
   4.040 3.040
nonbonded pdb=" O   PHE A  13 "
          pdb=" CD2 PHE A  13 "
   model   vdw
   4.041 3.340
nonbonded pdb=" OG  SER A  66 "
          pdb=" CB  ARG A  82 "
   model   vdw
   4.041 3.440
nonbonded pdb=" O   GLY A  18 "
          pdb=" C   TYR A  26 "
   model   vdw
   4.042 3.270
nonbonded pdb=" CD  GLN A  31 "
          pdb=" O   TYR A  56 "
   model   vdw
   4.042 3.270
nonbonded pdb=" O   LEU A  44 "
          pdb=" O   GLY A  74 "
   model   vdw sym.op.
   4.043 3.040 -x+1,y,-z+2
nonbonded pdb=" O   LEU A  76 "
          pdb=" CB  ILE A  78 "
   model   vdw sym.op.
   4.043 3.470 -x+1,y,-z+2
nonbonded pdb=" C   CYS A  33 "
          pdb=" O   TYR A  34 "
   model   vdw
   4.043 3.270
nonbonded pdb=" CG2 VAL A  35 "
          pdb=" CB  VAL A  45 "
   model   vdw
   4.044 3.890
nonbonded pdb=" N   GLY A  18 "
          pdb=" CE2 TYR A  26 "
   model   vdw
   4.044 3.420
nonbonded pdb=" CG  GLN A  10 "
          pdb=" O   LEU A  32 "
   model   vdw
   4.044 3.440
nonbonded pdb=" NH2 ARG A  16 "
          pdb=" C   LEU A  60 "
   model   vdw sym.op.
   4.045 3.350 x,y-1,z
nonbonded pdb=" CD2 HIS A  64 "
          pdb=" CG2 VAL A  84 "
   model   vdw
   4.045 3.680
nonbonded pdb=" OH  TYR A  26 "
          pdb=" CE2 TYR A  61 "
   model   vdw sym.op.
   4.045 3.340 x,y-1,z
nonbonded pdb=" CZ  TYR A  41 "
          pdb=" CD  PRO A  42 "
   model   vdw sym.op.
   4.046 3.660 -x+1,y,-z+1
nonbonded pdb=" CD  PRO A  42 "
          pdb=" CZ  TYR A  41 "
   model   vdw sym.op.
   4.046 3.660 -x+1,y,-z+1
nonbonded pdb=" N   GLY A  71 "
          pdb=" C   SER A  75 "
   model   vdw
   4.046 3.350
nonbonded pdb=" CA  GLN A  12 "
          pdb="O    HOH S 110 "
   model   vdw
   4.046 3.470
nonbonded pdb=" O   MSE A  77 "
          pdb=" CB  ILE A  78 "
   model   vdw
   4.046 3.470
nonbonded pdb=" N   ASN A  29 "
          pdb=" ND2 ASN A  29 "
   model   vdw
   4.046 3.200
nonbonded pdb=" O   SER A  67 "
          pdb=" CB  PHE A  68 "
   model   vdw
   4.047 3.440
nonbonded pdb=" C   THR A  14 "
          pdb=" N   GLU A  30 "
   model   vdw
   4.047 3.350
nonbonded pdb=" CA  TYR A  56 "
          pdb=" OH  TYR A  61 "
   model   vdw
   4.047 3.470
nonbonded pdb=" CA  SER A  20 "
          pdb="O    HOH S  81 "
   model   vdw
   4.048 3.470
nonbonded pdb=" O   HIS A  64 "
          pdb=" CG  HIS A  64 "
   model   vdw
   4.048 3.260
nonbonded pdb=" CB  TYR A  34 "
          pdb=" CB  PRO A  42 "
   model   vdw
   4.048 3.840
nonbonded pdb=" O   GLU A  40 "
          pdb=" C   TYR A  41 "
   model   vdw
   4.049 3.270
nonbonded pdb=" NZ  LYS A   3 "
          pdb=" CD2 LEU A  60 "
   model   vdw
   4.049 3.540
nonbonded pdb=" CA  LYS A  46 "
          pdb=" O   GLY A  74 "
   model   vdw sym.op.
   4.049 3.470 -x+1,y,-z+2
nonbonded pdb=" NE2 GLN A  12 "
          pdb=" C   PRO A  58 "
   model   vdw sym.op.
   4.049 3.350 -x+1/2,y-1/2,-z+1
nonbonded pdb=" C   GLY A  74 "
          pdb="O    HOH S  17 "
   model   vdw sym.op.
   4.050 3.270 -x+1,y,-z+2
nonbonded pdb=" N   GLU A  40 "
          pdb=" OE1 GLU A  40 "
   model   vdw
   4.050 3.120
nonbonded pdb=" CD2 LEU A  37 "
          pdb=" CB  PHE A  68 "
   model   vdw sym.op.
   4.050 3.860 -x+1,y,-z+2
nonbonded pdb=" N   HIS A  64 "
          pdb=" C   ARG A  82 "
   model   vdw
   4.050 3.350
nonbonded pdb=" O   THR A  62 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   4.050 3.460
nonbonded pdb=" NZ  LYS A  24 "
          pdb=" CG  ASP A  50 "
   model   vdw sym.op.
   4.051 3.350 -x+1/2,y-1/2,-z+2
nonbonded pdb=" CG  ASP A  50 "
          pdb=" NZ  LYS A  24 "
   model   vdw sym.op.
   4.051 3.350 -x+1/2,y+1/2,-z+2
nonbonded pdb=" OG  SER A  20 "
          pdb=" CA  ARG A  21 "
   model   vdw
   4.051 3.470
nonbonded pdb=" CG1 VAL A  63 "
          pdb=" CE2 PHE A  68 "
   model   vdw
   4.051 3.760
nonbonded pdb=" O   GLU A   5 "
          pdb=" CB  ILE A   6 "
   model   vdw
   4.052 3.470
nonbonded pdb=" C   LEU A  28 "
          pdb=" N   GLU A  30 "
   model   vdw
   4.052 3.350
nonbonded pdb=" OH  TYR A  26 "
          pdb=" CB  PRO A  85 "
   model   vdw sym.op.
   4.052 3.440 x,y-1,z
nonbonded pdb=" C   CYS A  33 "
          pdb=" N   VAL A  45 "
   model   vdw
   4.052 3.350
nonbonded pdb=" C   LEU A  81 "
          pdb=" N   LEU A  83 "
   model   vdw
   4.053 3.350
nonbonded pdb=" N   ARG A  21 "
          pdb="O    HOH S 120 "
   model   vdw
   4.054 3.120
nonbonded pdb=" CE  LYS A  24 "
          pdb=" OD2 ASP A  50 "
   model   vdw sym.op.
   4.054 3.440 -x+1/2,y-1/2,-z+2
nonbonded pdb=" OD2 ASP A  50 "
          pdb=" CE  LYS A  24 "
   model   vdw sym.op.
   4.054 3.440 -x+1/2,y+1/2,-z+2
nonbonded pdb=" N   MSE A  77 "
          pdb="SE    SE Z   3 "
   model   vdw sym.op.
   4.054 3.500 -x+1/2,y+3/2,-z+1
nonbonded pdb=" O   TYR A  26 "
          pdb=" CE1 TYR A  26 "
   model   vdw
   4.055 3.340
nonbonded pdb=" O   THR A  62 "
          pdb=" CB  VAL A  84 "
   model   vdw
   4.055 3.470
nonbonded pdb=" O   LEU A  76 "
          pdb=" C   MSE A  77 "
   model   vdw
   4.055 3.270
nonbonded pdb=" CA  GLU A  51 "
          pdb="O    HOH S 175 "
   model   vdw
   4.056 3.470
nonbonded pdb=" O   GLN A  31 "
          pdb=" CG  GLN A  31 "
   model   vdw
   4.056 3.440
nonbonded pdb=" C   PRO A  42 "
          pdb="O    HOH S   3 "
   model   vdw
   4.057 3.270
nonbonded pdb=" CB  PRO A  54 "
          pdb=" O   ALA A  55 "
   model   vdw
   4.057 3.440
nonbonded pdb=" O   LEU A  37 "
          pdb=" O   GLY A  38 "
   model   vdw
   4.057 3.040
nonbonded pdb=" C   PHE A  13 "
          pdb=" CD2 PHE A  13 "
   model   vdw
   4.058 3.570
nonbonded pdb=" CG1 VAL A  45 "
          pdb=" CA  LYS A  46 "
   model   vdw
   4.058 3.890
nonbonded pdb=" SG  CYS A  33 "
          pdb=" CG1 VAL A  45 "
   model   vdw
   4.058 3.820
nonbonded pdb=" CB  VAL A  19 "
          pdb=" CD  PRO A  54 "
   model   vdw sym.op.
   4.058 3.870 x,y-1,z
nonbonded pdb=" CD  PRO A  54 "
          pdb=" CB  VAL A  19 "
   model   vdw sym.op.
   4.058 3.870 x,y+1,z
nonbonded pdb=" O   TYR A  26 "
          pdb=" C   SER A  27 "
   model   vdw
   4.058 3.270
nonbonded pdb=" O   VAL A  35 "
          pdb=" CB  VAL A  43 "
   model   vdw
   4.059 3.470
nonbonded pdb=" CG2 THR A  15 "
          pdb=" O   ARG A  16 "
   model   vdw
   4.059 3.460
nonbonded pdb=" NE2 GLN A  31 "
          pdb=" CA  TYR A  56 "
   model   vdw
   4.059 3.550
nonbonded pdb=" CG  ARG A  21 "
          pdb=" N   GLN A  22 "
   model   vdw
   4.059 3.520
nonbonded pdb=" O   ASP A  50 "
          pdb="O    HOH S  33 "
   model   vdw
   4.060 3.040
nonbonded pdb=" CB  ASP A  79 "
          pdb="O    HOH S 160 "
   model   vdw
   4.060 3.440
nonbonded pdb=" O   CYS A  33 "
          pdb=" CB  LEU A  44 "
   model   vdw
   4.061 3.440
nonbonded pdb=" C   VAL A  19 "
          pdb=" NE2 GLN A  53 "
   model   vdw sym.op.
   4.061 3.350 x,y-1,z
nonbonded pdb=" O   ILE A  47 "
          pdb=" CB  THR A  48 "
   model   vdw
   4.063 3.470
nonbonded pdb=" OE1 GLU A   5 "
          pdb=" NZ  LYS A   7 "
   model   vdw
   4.063 3.120
nonbonded pdb=" CB  LEU A  37 "
          pdb=" OD1 ASN A  39 "
   model   vdw
   4.063 3.440
nonbonded pdb=" CD  ARG A  21 "
          pdb=" ND1 HIS A  64 "
   model   vdw sym.op.
   4.063 3.520 x,y-1,z
nonbonded pdb=" CA  LEU A  49 "
          pdb=" O   ASP A  50 "
   model   vdw
   4.063 3.470
nonbonded pdb=" O   THR A  62 "
          pdb=" C   VAL A  84 "
   model   vdw
   4.064 3.270
nonbonded pdb=" O   GLN A  31 "
          pdb=" C   ILE A  47 "
   model   vdw
   4.064 3.270
nonbonded pdb=" C   LEU A  44 "
          pdb=" CD1 LEU A  44 "
   model   vdw
   4.064 3.690
nonbonded pdb=" O   TYR A  61 "
          pdb=" C   THR A  62 "
   model   vdw
   4.065 3.270
nonbonded pdb=" CD  LYS A   7 "
          pdb=" OE2 GLU A  40 "
   model   vdw sym.op.
   4.066 3.440 -x+1,y,-z+1
nonbonded pdb=" CE  LYS A  24 "
          pdb=" O   PRO A  25 "
   model   vdw
   4.066 3.440
nonbonded pdb=" OD2 ASP A  79 "
          pdb=" N   ARG A  80 "
   model   vdw
   4.066 3.120
nonbonded pdb=" OH  TYR A  41 "
          pdb=" CG  TYR A  34 "
   model   vdw sym.op.
   4.066 3.260 -x+1,y,-z+1
nonbonded pdb=" CG  TYR A  34 "
          pdb=" OH  TYR A  41 "
   model   vdw sym.op.
   4.066 3.260 -x+1,y,-z+1
nonbonded pdb=" O   SER A  17 "
          pdb=" OH  TYR A  26 "
   model   vdw
   4.066 3.040
nonbonded pdb=" C   VAL A  45 "
          pdb=" N   ILE A  47 "
   model   vdw
   4.067 3.350
nonbonded pdb=" O   GLY A  59 "
          pdb=" CB  LEU A  60 "
   model   vdw
   4.067 3.440
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" CB  GLN A  10 "
   model   vdw
   4.067 3.860
nonbonded pdb=" CA  LEU A  37 "
          pdb=" CG  LEU A  65 "
   model   vdw sym.op.
   4.067 3.900 -x+1,y,-z+2
nonbonded pdb=" N   PHE A  13 "
          pdb=" CD1 PHE A  13 "
   model   vdw
   4.070 3.420
nonbonded pdb=" CD2 PHE A  73 "
          pdb="O    HOH S   4 "
   model   vdw
   4.070 3.340
nonbonded pdb=" CB  PRO A   8 "
          pdb=" N   THR A  15 "
   model   vdw sym.op.
   4.070 3.520 -x+1/2,y+1/2,-z+1
nonbonded pdb=" O   GLN A  72 "
          pdb=" CG  PHE A  73 "
   model   vdw
   4.071 3.260
nonbonded pdb=" CB  ASP A  50 "
          pdb="O    HOH S 175 "
   model   vdw
   4.071 3.440
nonbonded pdb=" OH  TYR A  34 "
          pdb=" CD1 LEU A  44 "
   model   vdw
   4.071 3.460
nonbonded pdb=" CB  ARG A  80 "
          pdb=" NH1 ARG A  82 "
   model   vdw
   4.071 3.520
nonbonded pdb=" N   LEU A  81 "
          pdb=" CD1 LEU A  81 "
   model   vdw
   4.072 3.540
nonbonded pdb=" O   THR A  14 "
          pdb=" N   ARG A  16 "
   model   vdw
   4.073 3.120
nonbonded pdb=" CE  LYS A  24 "
          pdb=" NH2 ARG A  82 "
   model   vdw sym.op.
   4.073 3.520 -x+1/2,y-1/2,-z+2
nonbonded pdb=" NH2 ARG A  82 "
          pdb=" CE  LYS A  24 "
   model   vdw sym.op.
   4.073 3.520 -x+1/2,y+1/2,-z+2
nonbonded pdb=" CG  TYR A  61 "
          pdb=" CB  LEU A  83 "
   model   vdw
   4.073 3.660
nonbonded pdb=" NH1 ARG A  16 "
          pdb=" C   LEU A  60 "
   model   vdw sym.op.
   4.074 3.350 x,y-1,z
nonbonded pdb=" NH1 ARG A  16 "
          pdb=" OE2 GLU A  30 "
   model   vdw
   4.074 3.120
nonbonded pdb=" CB  TYR A  34 "
          pdb=" OH  TYR A  41 "
   model   vdw sym.op.
   4.074 3.440 -x+1,y,-z+1
nonbonded pdb=" C   ASP A  50 "
          pdb="O    HOH S  33 "
   model   vdw
   4.075 3.270
nonbonded pdb=" CA  ASN A  39 "
          pdb="O    HOH S 123 "
   model   vdw
   4.075 3.470
nonbonded pdb=" C   ASN A  29 "
          pdb=" N   LEU A  49 "
   model   vdw
   4.075 3.350
nonbonded pdb=" O   LEU A  65 "
          pdb=" CB  PHE A  68 "
   model   vdw
   4.075 3.440
nonbonded pdb=" C   LEU A  37 "
          pdb=" CG  LEU A  65 "
   model   vdw sym.op.
   4.075 3.700 -x+1,y,-z+2
nonbonded pdb=" N   GLN A  31 "
          pdb="O    HOH S 151 "
   model   vdw
   4.076 3.120
nonbonded pdb=" C   TYR A  26 "
          pdb=" CD2 TYR A  26 "
   model   vdw
   4.076 3.570
nonbonded pdb=" C   LYS A   3 "
          pdb=" CD  LYS A   3 "
   model   vdw
   4.076 3.670
nonbonded pdb=" N   VAL A  43 "
          pdb="O    HOH S   3 "
   model   vdw
   4.076 3.120
nonbonded pdb=" C   ILE A   6 "
          pdb=" N   GLY A  59 "
   model   vdw
   4.076 3.350
nonbonded pdb=" C   TYR A  41 "
          pdb=" N   VAL A  43 "
   model   vdw
   4.076 3.350
nonbonded pdb=" O   ILE A   2 "
          pdb=" CB  LYS A   3 "
   model   vdw
   4.077 3.440
nonbonded pdb=" C   VAL A  35 "
          pdb=" O   VAL A  43 "
   model   vdw
   4.078 3.270
nonbonded pdb=" N   LYS A  24 "
          pdb=" CD  PRO A  25 "
   model   vdw
   4.078 3.520
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" O   TYR A  56 "
   model   vdw
   4.079 3.460
nonbonded pdb=" CG  PHE A  13 "
          pdb=" CB  ASN A  29 "
   model   vdw
   4.079 3.660
nonbonded pdb=" N   THR A  15 "
          pdb="O    HOH S   8 "
   model   vdw
   4.079 3.120
nonbonded pdb=" C   THR A  15 "
          pdb=" O   PRO A   8 "
   model   vdw sym.op.
   4.079 3.270 -x+1/2,y-1/2,-z+1
nonbonded pdb=" O   PRO A   8 "
          pdb=" C   THR A  15 "
   model   vdw sym.op.
   4.079 3.270 -x+1/2,y+1/2,-z+1
nonbonded pdb=" OH  TYR A  56 "
          pdb=" CG  LEU A  83 "
   model   vdw
   4.079 3.470
nonbonded pdb=" OG  SER A  20 "
          pdb=" C   GLY A  23 "
   model   vdw
   4.080 3.270
nonbonded pdb=" CA  PRO A   8 "
          pdb=" O   PHE A  13 "
   model   vdw sym.op.
   4.081 3.470 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CE2 TYR A  56 "
          pdb=" CB  LEU A  83 "
   model   vdw
   4.081 3.740
nonbonded pdb=" CD1 TYR A  26 "
          pdb=" CA  SER A  27 "
   model   vdw
   4.081 3.770
nonbonded pdb=" CA  LYS A   3 "
          pdb=" CZ  PHE A  73 "
   model   vdw sym.op.
   4.082 3.770 -x+1,y+1,-z+2
nonbonded pdb=" CD1 LEU A  49 "
          pdb=" O   PRO A  54 "
   model   vdw
   4.083 3.460
nonbonded pdb=" CD2 TYR A  41 "
          pdb=" CD1 TYR A  34 "
   model   vdw sym.op.
   4.083 3.640 -x+1,y,-z+1
nonbonded pdb=" CD1 TYR A  34 "
          pdb=" CD2 TYR A  41 "
   model   vdw sym.op.
   4.083 3.640 -x+1,y,-z+1
nonbonded pdb=" C   THR A  15 "
          pdb=" N   SER A  17 "
   model   vdw
   4.083 3.350
nonbonded pdb=" SG  CYS A  33 "
          pdb=" CG2 ILE A  47 "
   model   vdw
   4.085 3.820
nonbonded pdb=" CE  LYS A   7 "
          pdb="O    HOH S  51 "
   model   vdw
   4.085 3.440
nonbonded pdb=" CA  ASP A  36 "
          pdb="O    HOH S   2 "
   model   vdw
   4.086 3.470
nonbonded pdb=" O   VAL A  35 "
          pdb=" C   VAL A  43 "
   model   vdw
   4.086 3.270
nonbonded pdb=" CE  LYS A   3 "
          pdb=" CD2 LEU A  60 "
   model   vdw
   4.086 3.860
nonbonded pdb=" C   ASP A  79 "
          pdb=" O   ARG A  80 "
   model   vdw
   4.087 3.270
nonbonded pdb=" CA  TYR A  61 "
          pdb=" C   PRO A  85 "
   model   vdw
   4.087 3.700
nonbonded pdb=" CA  ARG A  16 "
          pdb=" O   LEU A  28 "
   model   vdw
   4.088 3.470
nonbonded pdb=" C   LEU A  76 "
          pdb=" CD1 LEU A  76 "
   model   vdw
   4.089 3.690
nonbonded pdb=" CZ  PHE A  68 "
          pdb=" CE1 PHE A  68 "
   model   vdw sym.op.
   4.089 3.640 -x+1,y,-z+2
nonbonded pdb=" CE1 PHE A  68 "
          pdb=" CZ  PHE A  68 "
   model   vdw sym.op.
   4.089 3.640 -x+1,y,-z+2
nonbonded pdb=" CB  LYS A   7 "
          pdb=" OE1 GLU A  40 "
   model   vdw sym.op.
   4.089 3.440 -x+1,y,-z+1
nonbonded pdb=" CE1 HIS A  64 "
          pdb=" N   LEU A  65 "
   model   vdw
   4.089 3.340
nonbonded pdb=" N   GLN A  53 "
          pdb=" CD  PRO A  54 "
   model   vdw
   4.090 3.520
nonbonded pdb=" CA  TYR A  56 "
          pdb="O    HOH S  98 "
   model   vdw
   4.090 3.470
nonbonded pdb=" C   ILE A   6 "
          pdb=" CA  PRO A  58 "
   model   vdw
   4.091 3.700
nonbonded pdb=" O   LYS A  24 "
          pdb=" CB  PRO A  25 "
   model   vdw
   4.092 3.440
nonbonded pdb=" N   ASP A  36 "
          pdb=" CB  PRO A  42 "
   model   vdw
   4.092 3.520
nonbonded pdb=" CB  ILE A   6 "
          pdb=" N   GLY A  59 "
   model   vdw
   4.093 3.550
nonbonded pdb=" N   LYS A   7 "
          pdb=" CB  GLN A  10 "
   model   vdw
   4.093 3.520
nonbonded pdb=" CD1 LEU A  37 "
          pdb=" O   PHE A  68 "
   model   vdw sym.op.
   4.093 3.460 -x+1,y,-z+2
nonbonded pdb=" O   LEU A  65 "
          pdb=" O   SER A  66 "
   model   vdw
   4.093 3.040
nonbonded pdb=" OE1 GLN A  31 "
          pdb=" CG  TYR A  56 "
   model   vdw
   4.094 3.260
nonbonded pdb=" CD  PRO A  85 "
          pdb="O    HOH S 120 "
   model   vdw sym.op.
   4.094 3.440 x,y+1,z
nonbonded pdb=" O   PRO A  58 "
          pdb=" CG  PRO A  58 "
   model   vdw
   4.094 3.440
nonbonded pdb=" CG2 VAL A   4 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   4.095 3.880
nonbonded pdb=" CG  PRO A   8 "
          pdb="O    HOH S 117 "
   model   vdw sym.op.
   4.095 3.440 -x+1/2,y+1/2,-z+1
nonbonded pdb=" C   THR A  62 "
          pdb=" O   VAL A  84 "
   model   vdw
   4.095 3.270
nonbonded pdb=" O   LYS A   7 "
          pdb=" CA  SER A   9 "
   model   vdw
   4.096 3.470
nonbonded pdb=" O   ASN A  29 "
          pdb=" O   LEU A  49 "
   model   vdw
   4.096 3.040
nonbonded pdb=" O   ILE A  78 "
          pdb=" N   ARG A  80 "
   model   vdw
   4.096 3.120
nonbonded pdb=" CG  GLU A  30 "
          pdb=" CD  LYS A  46 "
   model   vdw
   4.097 3.840
nonbonded pdb=" CA  LYS A   3 "
          pdb=" CE1 PHE A  73 "
   model   vdw sym.op.
   4.097 3.770 -x+1,y+1,-z+2
nonbonded pdb=" NH1 ARG A  16 "
          pdb=" N   LEU A  60 "
   model   vdw sym.op.
   4.097 3.200 x,y-1,z
nonbonded pdb=" CG  PRO A   8 "
          pdb=" CE1 PHE A  13 "
   model   vdw sym.op.
   4.098 3.740 -x+1/2,y+1/2,-z+1
nonbonded pdb=" OE2 GLU A  30 "
          pdb=" CE  LYS A  46 "
   model   vdw
   4.098 3.440
nonbonded pdb=" CG  ASP A  36 "
          pdb=" N   GLY A  38 "
   model   vdw
   4.098 3.350
nonbonded pdb=" CG2 VAL A  45 "
          pdb=" CB  LEU A  76 "
   model   vdw sym.op.
   4.098 3.860 -x+1,y,-z+2
nonbonded pdb=" C   LYS A  24 "
          pdb=" N   TYR A  26 "
   model   vdw
   4.100 3.350
nonbonded pdb=" CZ  ARG A  80 "
          pdb="O    HOH S 175 "
   model   vdw
   4.100 3.270
nonbonded pdb=" O   GLN A  31 "
          pdb=" CB  ILE A  47 "
   model   vdw
   4.100 3.470
nonbonded pdb=" CB  GLU A   5 "
          pdb=" O   TYR A  34 "
   model   vdw
   4.100 3.440
nonbonded pdb=" O   VAL A   4 "
          pdb=" O   GLY A  59 "
   model   vdw
   4.100 3.040
nonbonded pdb=" O   GLY A  71 "
          pdb=" CA  GLY A  74 "
   model   vdw
   4.100 3.440
nonbonded pdb=" O   SER A  67 "
          pdb=" CB  ILE A  78 "
   model   vdw
   4.100 3.470
nonbonded pdb=" CA  THR A  15 "
          pdb=" OD1 ASN A  29 "
   model   vdw
   4.101 3.470
nonbonded pdb=" CG  ARG A  80 "
          pdb="O    HOH S 106 "
   model   vdw
   4.101 3.440
nonbonded pdb=" C   LYS A   7 "
          pdb=" CB  PRO A  58 "
   model   vdw
   4.101 3.670
nonbonded pdb=" C   ARG A  16 "
          pdb=" N   LEU A  28 "
   model   vdw
   4.101 3.350
nonbonded pdb=" C   ASP A  36 "
          pdb="O    HOH S   3 "
   model   vdw
   4.102 3.270
nonbonded pdb=" CD1 TYR A  34 "
          pdb=" N   LEU A  44 "
   model   vdw
   4.103 3.420
nonbonded pdb=" CA  ASP A  50 "
          pdb=" NH1 ARG A  80 "
   model   vdw
   4.104 3.550
nonbonded pdb=" CG  LYS A  46 "
          pdb=" O   ILE A  47 "
   model   vdw
   4.104 3.440
nonbonded pdb=" CA  THR A  14 "
          pdb=" O   GLU A  30 "
   model   vdw
   4.105 3.470
nonbonded pdb=" C   TYR A  26 "
          pdb=" O   SER A  27 "
   model   vdw
   4.105 3.270
nonbonded pdb=" N   LYS A  69 "
          pdb=" C   MSE A  77 "
   model   vdw
   4.106 3.350
nonbonded pdb=" CG2 VAL A  63 "
          pdb=" CG  LEU A  81 "
   model   vdw
   4.106 3.890
nonbonded pdb=" CB  ALA A  55 "
          pdb=" O   TYR A  56 "
   model   vdw
   4.106 3.460
nonbonded pdb=" CG  GLN A  53 "
          pdb="O    HOH S  98 "
   model   vdw
   4.107 3.440
nonbonded pdb=" C   GLU A   5 "
          pdb=" N   TYR A  34 "
   model   vdw
   4.107 3.350
nonbonded pdb=" C   LEU A  83 "
          pdb="O    HOH S  81 "
   model   vdw sym.op.
   4.108 3.270 x,y+1,z
nonbonded pdb=" C   ARG A  80 "
          pdb=" CG  ARG A  82 "
   model   vdw
   4.108 3.670
nonbonded pdb=" O   GLU A  40 "
          pdb=" CD2 TYR A  41 "
   model   vdw
   4.108 3.340
nonbonded pdb=" N   ILE A   6 "
          pdb=" C   GLY A  59 "
   model   vdw
   4.109 3.350
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" C   GLN A  10 "
   model   vdw
   4.111 3.690
nonbonded pdb=" OE1 GLN A  12 "
          pdb=" C   PRO A  58 "
   model   vdw sym.op.
   4.112 3.270 -x+1/2,y-1/2,-z+1
nonbonded pdb=" CA  GLY A  23 "
          pdb="O    HOH S  97 "
   model   vdw
   4.112 3.440
nonbonded pdb=" O   SER A  66 "
          pdb=" CZ  ARG A  82 "
   model   vdw
   4.112 3.270
nonbonded pdb=" O   GLY A  74 "
          pdb=" CB  SER A  75 "
   model   vdw
   4.113 3.440
nonbonded pdb=" CG2 ILE A   2 "
          pdb=" CB  VAL A  63 "
   model   vdw
   4.113 3.890
nonbonded pdb=" CG  PRO A  54 "
          pdb=" N   ALA A  55 "
   model   vdw
   4.113 3.520
nonbonded pdb=" O   ASN A  29 "
          pdb="O    HOH S  33 "
   model   vdw
   4.113 3.040
nonbonded pdb=" CB  HIS A  64 "
          pdb=" C   ARG A  82 "
   model   vdw
   4.114 3.670
nonbonded pdb=" CB  ASP A  79 "
          pdb=" NH1 ARG A  82 "
   model   vdw
   4.115 3.520
nonbonded pdb=" C   LEU A  81 "
          pdb=" CD1 LEU A  81 "
   model   vdw
   4.115 3.690
nonbonded pdb=" C   THR A  14 "
          pdb=" N   ARG A  16 "
   model   vdw
   4.115 3.350
nonbonded pdb=" O   GLY A  18 "
          pdb=" CB  PRO A  25 "
   model   vdw
   4.115 3.440
nonbonded pdb=" C   LYS A  69 "
          pdb=" N   MSE A  77 "
   model   vdw
   4.116 3.350
nonbonded pdb=" CD  GLN A  10 "
          pdb=" CB  LEU A  32 "
   model   vdw
   4.116 3.670
nonbonded pdb="SE    SE Z   3 "
          pdb="O    HOH S   4 "
   model   vdw sym.op.
   4.116 3.420 -x+1/2,y-3/2,-z+1
nonbonded pdb=" CG  ASP A  36 "
          pdb="O    HOH S   2 "
   model   vdw
   4.117 3.270
nonbonded pdb=" O   ILE A  47 "
          pdb=" OG1 THR A  48 "
   model   vdw
   4.117 3.040
nonbonded pdb=" C   GLN A  31 "
          pdb=" CG1 ILE A  47 "
   model   vdw
   4.118 3.670
nonbonded pdb=" O   GLN A  31 "
          pdb=" CD1 LEU A  32 "
   model   vdw
   4.118 3.460
nonbonded pdb=" CB  GLU A  30 "
          pdb=" CD  LYS A  46 "
   model   vdw
   4.119 3.840
nonbonded pdb=" N   ALA A  55 "
          pdb="O    HOH S 134 "
   model   vdw
   4.119 3.120
nonbonded pdb=" C   ILE A   2 "
          pdb=" N   VAL A   4 "
   model   vdw
   4.119 3.350
nonbonded pdb=" C   CYS A  33 "
          pdb=" O   VAL A  45 "
   model   vdw
   4.120 3.270
nonbonded pdb=" O   GLN A  31 "
          pdb=" CB  LEU A  32 "
   model   vdw
   4.121 3.440
nonbonded pdb=" O   MSE A  77 "
          pdb=" CG1 ILE A  78 "
   model   vdw
   4.121 3.440
nonbonded pdb=" O   LEU A  60 "
          pdb=" CD2 TYR A  61 "
   model   vdw
   4.121 3.340
nonbonded pdb=" O   ASP A  50 "
          pdb=" CA  GLN A  53 "
   model   vdw
   4.122 3.470
nonbonded pdb=" CG  TYR A  41 "
          pdb=" OH  TYR A  41 "
   model   vdw
   4.122 3.260
nonbonded pdb=" C   GLY A  18 "
          pdb=" CG  TYR A  26 "
   model   vdw
   4.122 3.490
nonbonded pdb=" CD1 TYR A  26 "
          pdb=" CG  LEU A  28 "
   model   vdw
   4.122 3.770
nonbonded pdb=" CA  VAL A  19 "
          pdb=" CD2 TYR A  26 "
   model   vdw
   4.123 3.770
nonbonded pdb=" C   THR A  62 "
          pdb=" N   VAL A  84 "
   model   vdw
   4.123 3.350
nonbonded pdb=" O   GLY A  59 "
          pdb=" N   TYR A  61 "
   model   vdw
   4.124 3.120
nonbonded pdb=" O   SER A  66 "
          pdb=" CD  ARG A  82 "
   model   vdw
   4.124 3.440
nonbonded pdb=" CG  GLU A   5 "
          pdb=" CD2 LEU A  60 "
   model   vdw
   4.124 3.860
nonbonded pdb=" CD1 TYR A  56 "
          pdb=" CB  LEU A  83 "
   model   vdw
   4.124 3.740
nonbonded pdb=" CA  THR A  48 "
          pdb="O    HOH S 106 "
   model   vdw
   4.124 3.470
nonbonded pdb=" CB  THR A  62 "
          pdb=" CZ  PHE A  73 "
   model   vdw sym.op.
   4.124 3.770 -x+1,y+1,-z+2
nonbonded pdb=" O   ARG A  82 "
          pdb=" N   VAL A  84 "
   model   vdw
   4.125 3.120
nonbonded pdb=" O   LYS A  69 "
          pdb=" CB  VAL A  70 "
   model   vdw
   4.125 3.470
nonbonded pdb=" CD1 LEU A  65 "
          pdb=" CB  ILE A   2 "
   model   vdw sym.op.
   4.125 3.890 -x+1,y,-z+2
nonbonded pdb=" CB  ILE A   2 "
          pdb=" CD1 LEU A  65 "
   model   vdw sym.op.
   4.125 3.890 -x+1,y,-z+2
nonbonded pdb=" NE2 GLN A  31 "
          pdb=" CB  TYR A  56 "
   model   vdw
   4.126 3.520
nonbonded pdb=" O   GLU A   5 "
          pdb=" CG1 ILE A   6 "
   model   vdw
   4.126 3.440
nonbonded pdb=" CG1 VAL A   4 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   4.127 3.880
nonbonded pdb=" O   ARG A  82 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   4.127 3.460
nonbonded pdb=" CB  SER A  67 "
          pdb=" C   ARG A  80 "
   model   vdw
   4.127 3.670
nonbonded pdb=" CB  PRO A   8 "
          pdb=" CD1 PHE A  13 "
   model   vdw sym.op.
   4.127 3.740 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CB  GLU A  30 "
          pdb=" CG  LYS A  46 "
   model   vdw
   4.128 3.840
nonbonded pdb=" N   TYR A  61 "
          pdb=" CD2 TYR A  61 "
   model   vdw
   4.129 3.420
nonbonded pdb=" CG2 ILE A  78 "
          pdb=" C   ASP A  79 "
   model   vdw
   4.129 3.690
nonbonded pdb=" C   GLN A  31 "
          pdb=" N   ILE A  47 "
   model   vdw
   4.129 3.350
nonbonded pdb=" C   GLN A  31 "
          pdb=" CD2 LEU A  32 "
   model   vdw
   4.129 3.690
nonbonded pdb=" CB  GLN A  53 "
          pdb="O    HOH S  98 "
   model   vdw
   4.129 3.440
nonbonded pdb=" CG  ASP A  50 "
          pdb=" CZ  ARG A  82 "
   model   vdw
   4.130 3.500
nonbonded pdb=" O   SER A  20 "
          pdb=" C   GLN A  22 "
   model   vdw
   4.130 3.270
nonbonded pdb=" CG2 VAL A  45 "
          pdb=" CD1 LEU A  76 "
   model   vdw sym.op.
   4.131 3.880 -x+1,y,-z+2
nonbonded pdb=" CA  GLY A  38 "
          pdb=" CD2 LEU A  65 "
   model   vdw sym.op.
   4.132 3.860 -x+1,y,-z+2
nonbonded pdb=" NH2 ARG A  21 "
          pdb=" CB  GLU A  51 "
   model   vdw sym.op.
   4.132 3.520 -x+1/2,y-1/2,-z+2
nonbonded pdb=" C   GLU A  40 "
          pdb=" CD1 TYR A  41 "
   model   vdw
   4.132 3.570
nonbonded pdb=" OE1 GLN A  10 "
          pdb=" CE2 TYR A  34 "
   model   vdw
   4.132 3.340
nonbonded pdb=" OE2 GLU A  40 "
          pdb=" CA  SER A   9 "
   model   vdw sym.op.
   4.132 3.470 -x+1,y,-z+1
nonbonded pdb=" CA  SER A   9 "
          pdb=" OE2 GLU A  40 "
   model   vdw sym.op.
   4.132 3.470 -x+1,y,-z+1
nonbonded pdb=" OG  SER A  20 "
          pdb=" CA  GLN A  22 "
   model   vdw
   4.133 3.470
nonbonded pdb=" CG  TYR A  26 "
          pdb=" OH  TYR A  26 "
   model   vdw
   4.133 3.260
nonbonded pdb=" CD1 TYR A  34 "
          pdb=" C   PRO A  42 "
   model   vdw
   4.133 3.570
nonbonded pdb=" CB  LYS A  46 "
          pdb=" O   GLY A  74 "
   model   vdw sym.op.
   4.134 3.440 -x+1,y,-z+2
nonbonded pdb=" CE1 PHE A  13 "
          pdb=" CB  ASN A  29 "
   model   vdw
   4.134 3.740
nonbonded pdb=" C   GLN A  10 "
          pdb=" O   GLN A  12 "
   model   vdw
   4.134 3.270
nonbonded pdb=" O   LEU A  60 "
          pdb=" CA  PRO A  85 "
   model   vdw
   4.135 3.470
nonbonded pdb=" CZ  PHE A  68 "
          pdb=" CZ  PHE A  68 "
   model   vdw sym.op.
   4.135 3.640 -x+1,y,-z+2
nonbonded pdb=" CD2 PHE A  13 "
          pdb=" N   ALA A  55 "
   model   vdw
   4.135 3.420
nonbonded pdb=" CZ  TYR A  56 "
          pdb=" CA  LEU A  83 "
   model   vdw
   4.135 3.690
nonbonded pdb=" C   GLY A  18 "
          pdb=" O   TYR A  26 "
   model   vdw
   4.136 3.270
nonbonded pdb=" CE1 TYR A  26 "
          pdb=" CD1 LEU A  28 "
   model   vdw
   4.137 3.760
nonbonded pdb=" N   GLN A  22 "
          pdb=" CD  GLN A  22 "
   model   vdw
   4.137 3.350
nonbonded pdb=" C   GLN A  31 "
          pdb=" CD1 LEU A  32 "
   model   vdw
   4.137 3.690
nonbonded pdb=" NH2 ARG A  16 "
          pdb=" CA  PRO A  85 "
   model   vdw sym.op.
   4.138 3.550 x,y-1,z
nonbonded pdb=" C   GLN A  31 "
          pdb=" O   ILE A  47 "
   model   vdw
   4.138 3.270
nonbonded pdb=" CD1 PHE A  68 "
          pdb=" CD2 LEU A  76 "
   model   vdw
   4.138 3.760
nonbonded pdb=" O   HIS A  64 "
          pdb=" CA  SER A  66 "
   model   vdw
   4.140 3.470
nonbonded pdb=" O   THR A  62 "
          pdb=" CB  LEU A  83 "
   model   vdw
   4.140 3.440
nonbonded pdb=" CG2 ILE A  78 "
          pdb=" C   ARG A  80 "
   model   vdw
   4.140 3.690
nonbonded pdb=" N   GLN A  10 "
          pdb=" CA  ALA A  11 "
   model   vdw
   4.140 3.550
nonbonded pdb=" C   CYS A  33 "
          pdb=" CD1 LEU A  44 "
   model   vdw
   4.141 3.690
nonbonded pdb=" OD1 ASP A  79 "
          pdb=" CG  ARG A  80 "
   model   vdw
   4.141 3.440
nonbonded pdb=" CA  LYS A   7 "
          pdb=" N   SER A   9 "
   model   vdw
   4.142 3.550
nonbonded pdb=" CG1 VAL A  45 "
          pdb=" O   GLY A  74 "
   model   vdw sym.op.
   4.142 3.460 -x+1,y,-z+2
nonbonded pdb=" CA  GLY A  38 "
          pdb=" O   ASN A  39 "
   model   vdw
   4.142 3.440
nonbonded pdb=" O   GLY A  23 "
          pdb=" CB  LYS A  24 "
   model   vdw
   4.143 3.440
nonbonded pdb=" CG1 VAL A   4 "
          pdb=" CG2 VAL A  35 "
   model   vdw
   4.143 3.880
nonbonded pdb=" CD2 TYR A  61 "
          pdb=" N   VAL A  84 "
   model   vdw
   4.143 3.420
nonbonded pdb=" CG1 ILE A   6 "
          pdb=" CB  TYR A  56 "
   model   vdw
   4.144 3.840
nonbonded pdb=" O   ARG A  16 "
          pdb=" C   LEU A  28 "
   model   vdw
   4.144 3.270
nonbonded pdb=" C   LEU A  32 "
          pdb=" SG  CYS A  33 "
   model   vdw
   4.144 3.630
nonbonded pdb=" OE1 GLN A  10 "
          pdb=" N   TYR A  34 "
   model   vdw
   4.145 3.120
nonbonded pdb=" N   THR A  62 "
          pdb=" C   VAL A  84 "
   model   vdw
   4.146 3.350
nonbonded pdb=" C   LEU A  49 "
          pdb=" CG  ASP A  50 "
   model   vdw
   4.146 3.500
nonbonded pdb=" NH2 ARG A  16 "
          pdb=" CA  GLY A  59 "
   model   vdw sym.op.
   4.146 3.520 x,y-1,z
nonbonded pdb=" CB  PHE A  13 "
          pdb=" C   GLU A  30 "
   model   vdw
   4.147 3.670
nonbonded pdb=" CD1 LEU A  49 "
          pdb=" O   GLN A  53 "
   model   vdw
   4.147 3.460
nonbonded pdb=" C   GLN A  31 "
          pdb=" CG  LEU A  32 "
   model   vdw
   4.148 3.700
nonbonded pdb=" N   TYR A  26 "
          pdb=" CD1 TYR A  26 "
   model   vdw
   4.148 3.420
nonbonded pdb=" C   SER A  17 "
          pdb=" CZ  TYR A  26 "
   model   vdw
   4.148 3.490
nonbonded pdb=" O   GLN A  12 "
          pdb=" CB  GLN A  31 "
   model   vdw
   4.148 3.440
nonbonded pdb=" O   LEU A  28 "
          pdb=" CG  ASN A  29 "
   model   vdw
   4.148 3.270
nonbonded pdb=" OH  TYR A  26 "
          pdb=" CD  PRO A  85 "
   model   vdw sym.op.
   4.149 3.440 x,y-1,z
nonbonded pdb=" O   ARG A  82 "
          pdb=" CB  LEU A  83 "
   model   vdw
   4.149 3.440
nonbonded pdb=" C   ASN A  39 "
          pdb=" CG  GLU A  40 "
   model   vdw
   4.149 3.670
nonbonded pdb=" O   THR A  62 "
          pdb=" OG1 THR A  62 "
   model   vdw
   4.149 3.040
nonbonded pdb=" O   LYS A  46 "
          pdb=" O   GLY A  74 "
   model   vdw sym.op.
   4.149 3.040 -x+1,y,-z+2
nonbonded pdb=" C   ALA A  11 "
          pdb=" NE2 GLN A  31 "
   model   vdw
   4.150 3.350
nonbonded pdb=" CA  LEU A  65 "
          pdb=" N   SER A  67 "
   model   vdw
   4.150 3.550
nonbonded pdb=" OE1 GLN A  53 "
          pdb=" O   PRO A  54 "
   model   vdw
   4.150 3.040
nonbonded pdb=" CE1 TYR A  56 "
          pdb=" N   LEU A  83 "
   model   vdw
   4.150 3.420
nonbonded pdb=" O   LEU A  49 "
          pdb="O    HOH S 175 "
   model   vdw
   4.150 3.040
nonbonded pdb=" O   HIS A  64 "
          pdb=" CD2 PHE A  68 "
   model   vdw
   4.151 3.340
nonbonded pdb=" CD1 LEU A  76 "
          pdb=" N   MSE A  77 "
   model   vdw
   4.151 3.540
nonbonded pdb=" O   PRO A  85 "
          pdb=" CG  PRO A  85 "
   model   vdw
   4.151 3.440
nonbonded pdb=" O   GLY A  38 "
          pdb=" CB  ASN A  39 "
   model   vdw
   4.152 3.440
nonbonded pdb=" N   THR A  62 "
          pdb="O    HOH S  54 "
   model   vdw
   4.152 3.120
nonbonded pdb=" N   VAL A  35 "
          pdb=" N   VAL A  43 "
   model   vdw
   4.152 3.200
nonbonded pdb=" C   SER A  66 "
          pdb=" O   SER A  67 "
   model   vdw
   4.152 3.270
nonbonded pdb=" CD1 LEU A  37 "
          pdb=" CA  LYS A  69 "
   model   vdw sym.op.
   4.152 3.890 -x+1,y,-z+2
nonbonded pdb=" CG  TYR A  61 "
          pdb=" OH  TYR A  61 "
   model   vdw
   4.152 3.260
nonbonded pdb=" O   THR A  15 "
          pdb=" N   SER A  17 "
   model   vdw
   4.153 3.120
nonbonded pdb=" CG  TYR A  56 "
          pdb=" OH  TYR A  56 "
   model   vdw
   4.153 3.260
nonbonded pdb=" CE  LYS A   3 "
          pdb=" CG  GLN A  72 "
   model   vdw sym.op.
   4.154 3.840 -x+1,y+1,-z+2
nonbonded pdb=" CG  GLN A  72 "
          pdb=" CE  LYS A   3 "
   model   vdw sym.op.
   4.154 3.840 -x+1,y-1,-z+2
nonbonded pdb=" CG  TYR A  34 "
          pdb=" OH  TYR A  34 "
   model   vdw
   4.154 3.260
nonbonded pdb=" CB  SER A  67 "
          pdb=" CD2 PHE A  68 "
   model   vdw
   4.154 3.740
nonbonded pdb=" CB  PHE A  68 "
          pdb=" CD1 LEU A  76 "
   model   vdw
   4.154 3.860
nonbonded pdb=" CA  TYR A  56 "
          pdb=" O   ALA A  57 "
   model   vdw
   4.155 3.470
nonbonded pdb=" OG  SER A   9 "
          pdb=" CG  GLU A  40 "
   model   vdw sym.op.
   4.155 3.440 -x+1,y,-z+1
nonbonded pdb=" CG  GLU A  40 "
          pdb=" OG  SER A   9 "
   model   vdw sym.op.
   4.155 3.440 -x+1,y,-z+1
nonbonded pdb=" NH2 ARG A  16 "
          pdb=" CD1 TYR A  61 "
   model   vdw sym.op.
   4.156 3.420 x,y-1,z
nonbonded pdb=" CA  GLY A  71 "
          pdb="SE    SE Z   4 "
   model   vdw sym.op.
   4.156 3.820 x+1/2,y+3/2,z+2
nonbonded pdb=" CA  TYR A  41 "
          pdb=" O   PRO A  42 "
   model   vdw
   4.157 3.470
nonbonded pdb=" CA  ALA A  11 "
          pdb=" NE2 GLN A  31 "
   model   vdw
   4.157 3.550
nonbonded pdb=" C   LYS A   3 "
          pdb=" N   ASP A  36 "
   model   vdw
   4.158 3.350
nonbonded pdb=" O   CYS A  33 "
          pdb=" C   VAL A  45 "
   model   vdw
   4.158 3.270
nonbonded pdb=" O   GLU A   5 "
          pdb=" C   TYR A  34 "
   model   vdw
   4.158 3.270
nonbonded pdb=" C   GLN A  72 "
          pdb=" CD2 PHE A  73 "
   model   vdw
   4.159 3.570
nonbonded pdb=" O   VAL A  43 "
          pdb=" CB  LEU A  44 "
   model   vdw
   4.159 3.440
nonbonded pdb=" N   ASP A  36 "
          pdb=" OD1 ASP A  36 "
   model   vdw
   4.160 3.120
nonbonded pdb=" CB  TYR A  61 "
          pdb=" C   VAL A  84 "
   model   vdw
   4.160 3.670
nonbonded pdb=" CG  PHE A  73 "
          pdb="O    HOH S  54 "
   model   vdw sym.op.
   4.160 3.260 -x+1,y-1,-z+2
nonbonded pdb=" O   VAL A  70 "
          pdb=" N   GLN A  72 "
   model   vdw
   4.160 3.120
nonbonded pdb=" CB  ILE A   6 "
          pdb=" O   GLY A  59 "
   model   vdw
   4.160 3.470
nonbonded pdb=" C   PHE A  13 "
          pdb=" OG1 THR A  14 "
   model   vdw
   4.161 3.270
nonbonded pdb=" O   TYR A  26 "
          pdb=" CD2 TYR A  26 "
   model   vdw
   4.161 3.340
nonbonded pdb=" NE2 GLN A  31 "
          pdb=" C   ALA A  55 "
   model   vdw
   4.161 3.350
nonbonded pdb=" CZ  ARG A  21 "
          pdb=" OE2 GLU A  51 "
   model   vdw sym.op.
   4.161 3.270 -x+1/2,y-1/2,-z+2
nonbonded pdb=" CA  SER A   9 "
          pdb=" CG2 THR A  15 "
   model   vdw sym.op.
   4.162 3.890 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CG2 THR A  15 "
          pdb=" CA  SER A   9 "
   model   vdw sym.op.
   4.162 3.890 -x+1/2,y-1/2,-z+1
nonbonded pdb=" O   ILE A   2 "
          pdb="O    HOH S  12 "
   model   vdw
   4.162 3.040
nonbonded pdb=" O   ASP A  79 "
          pdb=" C   ARG A  80 "
   model   vdw
   4.165 3.270
nonbonded pdb=" C   GLU A   5 "
          pdb=" O   TYR A  34 "
   model   vdw
   4.165 3.270
nonbonded pdb=" OG  SER A  67 "
          pdb=" CG  ARG A  82 "
   model   vdw
   4.165 3.440
nonbonded pdb=" CA  GLU A   5 "
          pdb=" OE1 GLU A   5 "
   model   vdw
   4.165 3.470
nonbonded pdb=" C   ILE A   6 "
          pdb=" N   PRO A   8 "
   model   vdw
   4.165 3.350
nonbonded pdb=" O   GLN A  12 "
          pdb=" CD  GLN A  31 "
   model   vdw
   4.165 3.270
nonbonded pdb=" CG2 ILE A  78 "
          pdb=" N   LEU A  81 "
   model   vdw
   4.166 3.540
nonbonded pdb=" NZ  LYS A   7 "
          pdb="O    HOH S  51 "
   model   vdw
   4.166 3.120
nonbonded pdb=" CB  ASP A  50 "
          pdb="O    HOH S 135 "
   model   vdw
   4.166 3.440
nonbonded pdb=" N   TYR A  34 "
          pdb=" CD1 TYR A  34 "
   model   vdw
   4.166 3.420
nonbonded pdb=" O   ASP A  50 "
          pdb=" O   GLN A  53 "
   model   vdw
   4.167 3.040
nonbonded pdb=" C   GLY A  38 "
          pdb="O    HOH S   3 "
   model   vdw
   4.167 3.270
nonbonded pdb=" N   THR A  14 "
          pdb=" C   GLU A  30 "
   model   vdw
   4.167 3.350
nonbonded pdb=" CZ  PHE A  13 "
          pdb=" ND2 ASN A  29 "
   model   vdw
   4.167 3.420
nonbonded pdb=" C   CYS A  33 "
          pdb=" N   VAL A  35 "
   model   vdw
   4.168 3.350
nonbonded pdb=" CB  TYR A  56 "
          pdb="O    HOH S  14 "
   model   vdw
   4.168 3.440
nonbonded pdb=" O   GLY A  74 "
          pdb=" N   LEU A  76 "
   model   vdw
   4.168 3.120
nonbonded pdb=" O   SER A  20 "
          pdb=" CB  ARG A  21 "
   model   vdw
   4.169 3.440
nonbonded pdb=" O   ILE A   6 "
          pdb=" CA  GLY A  59 "
   model   vdw
   4.169 3.440
nonbonded pdb=" CD2 LEU A  81 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   4.170 3.880
nonbonded pdb=" N   PHE A  73 "
          pdb=" CA  GLY A  74 "
   model   vdw
   4.170 3.520
nonbonded pdb=" O   VAL A  19 "
          pdb=" CB  SER A  20 "
   model   vdw
   4.170 3.440
nonbonded pdb=" CD  GLN A  31 "
          pdb=" CA  ALA A  55 "
   model   vdw
   4.170 3.700
nonbonded pdb=" C   LEU A  49 "
          pdb=" N   GLU A  51 "
   model   vdw
   4.170 3.350
nonbonded pdb=" CG  LEU A  32 "
          pdb="O    HOH S   7 "
   model   vdw
   4.171 3.470
nonbonded pdb=" O   GLN A  53 "
          pdb=" CB  PRO A  54 "
   model   vdw
   4.171 3.440
nonbonded pdb=" CB  TYR A  61 "
          pdb=" O   THR A  62 "
   model   vdw
   4.171 3.440
nonbonded pdb=" C   GLY A  59 "
          pdb=" N   TYR A  61 "
   model   vdw
   4.171 3.350
nonbonded pdb=" N   LYS A   7 "
          pdb=" CG  GLN A  10 "
   model   vdw
   4.172 3.520
nonbonded pdb=" O   LEU A  65 "
          pdb=" CA  SER A  67 "
   model   vdw
   4.172 3.470
nonbonded pdb="SE    SE Z   1 "
          pdb="O    HOH S   4 "
   model   vdw sym.op.
   4.172 3.420 -x,y-1,-z+1
nonbonded pdb="O    HOH S   4 "
          pdb="SE    SE Z   1 "
   model   vdw sym.op.
   4.172 3.420 -x,y+1,-z+1
nonbonded pdb=" CE1 TYR A  56 "
          pdb="O    HOH S  81 "
   model   vdw sym.op.
   4.172 3.340 x,y+1,z
nonbonded pdb=" N   LEU A  60 "
          pdb=" CD1 TYR A  61 "
   model   vdw
   4.173 3.420
nonbonded pdb=" CD  GLN A  53 "
          pdb=" O   SER A  20 "
   model   vdw sym.op.
   4.173 3.270 x,y+1,z
nonbonded pdb=" O   SER A  20 "
          pdb=" CD  GLN A  53 "
   model   vdw sym.op.
   4.173 3.270 x,y-1,z
nonbonded pdb=" CB  SER A  20 "
          pdb=" N   LYS A  24 "
   model   vdw
   4.173 3.520
nonbonded pdb=" OD1 ASP A  36 "
          pdb=" C   LEU A  37 "
   model   vdw
   4.174 3.270
nonbonded pdb=" N   SER A   9 "
          pdb=" CA  GLN A  10 "
   model   vdw
   4.174 3.550
nonbonded pdb=" N   GLN A  31 "
          pdb=" C   ILE A  47 "
   model   vdw
   4.174 3.350
nonbonded pdb=" OG  SER A  66 "
          pdb=" CZ  ARG A  21 "
   model   vdw sym.op.
   4.175 3.270 x,y+1,z
nonbonded pdb=" CZ  ARG A  21 "
          pdb=" OG  SER A  66 "
   model   vdw sym.op.
   4.175 3.270 x,y-1,z
nonbonded pdb=" CD1 PHE A  13 "
          pdb=" O   THR A  14 "
   model   vdw
   4.176 3.340
nonbonded pdb="O    HOH S 117 "
          pdb=" CB  SER A   9 "
   model   vdw sym.op.
   4.177 3.440 -x+1/2,y-1/2,-z+1
nonbonded pdb=" CB  SER A   9 "
          pdb="O    HOH S 117 "
   model   vdw sym.op.
   4.177 3.440 -x+1/2,y+1/2,-z+1
nonbonded pdb=" N   SER A  66 "
          pdb=" CA  SER A  67 "
   model   vdw
   4.178 3.550
nonbonded pdb=" CG1 VAL A  70 "
          pdb=" CA  GLY A  74 "
   model   vdw
   4.178 3.860
nonbonded pdb=" C   LEU A  32 "
          pdb="O    HOH S   7 "
   model   vdw
   4.179 3.270
nonbonded pdb=" CD1 LEU A  37 "
          pdb=" CG2 VAL A  70 "
   model   vdw sym.op.
   4.179 3.880 -x+1,y,-z+2
nonbonded pdb=" O   LEU A  65 "
          pdb=" O   PHE A  68 "
   model   vdw
   4.179 3.040
nonbonded pdb=" C   LEU A  83 "
          pdb=" CG2 VAL A  84 "
   model   vdw
   4.180 3.690
nonbonded pdb=" N   ARG A  16 "
          pdb=" C   LEU A  28 "
   model   vdw
   4.180 3.350
nonbonded pdb=" CB  ALA A  55 "
          pdb="O    HOH S 134 "
   model   vdw
   4.180 3.460
nonbonded pdb=" C   GLN A  72 "
          pdb="O    HOH S   4 "
   model   vdw
   4.181 3.270
nonbonded pdb=" N   LEU A  37 "
          pdb=" CA  GLY A  38 "
   model   vdw
   4.181 3.520
nonbonded pdb=" CB  VAL A   4 "
          pdb=" O   TYR A  34 "
   model   vdw
   4.181 3.470
nonbonded pdb=" O   GLN A  72 "
          pdb=" CD1 PHE A  73 "
   model   vdw
   4.182 3.340
nonbonded pdb=" O   THR A  62 "
          pdb=" CG1 VAL A  84 "
   model   vdw
   4.182 3.460
nonbonded pdb=" O   GLY A  23 "
          pdb="O    HOH S  97 "
   model   vdw
   4.183 3.040
nonbonded pdb=" N   ASN A  39 "
          pdb="O    HOH S 131 "
   model   vdw
   4.183 3.120
nonbonded pdb=" O   ALA A  57 "
          pdb=" CB  PRO A  58 "
   model   vdw
   4.183 3.440
nonbonded pdb=" OE1 GLU A   5 "
          pdb=" CG  LEU A  60 "
   model   vdw
   4.184 3.470
nonbonded pdb=" O   PRO A  58 "
          pdb=" C   GLY A  59 "
   model   vdw
   4.185 3.270
nonbonded pdb=" CG  LYS A   3 "
          pdb=" CD2 LEU A  60 "
   model   vdw
   4.185 3.860
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" C   ALA A  57 "
   model   vdw
   4.185 3.690
nonbonded pdb=" OG  SER A  17 "
          pdb=" C   TYR A  26 "
   model   vdw
   4.185 3.270
nonbonded pdb=" CG  LEU A  65 "
          pdb=" N   SER A  66 "
   model   vdw
   4.186 3.550
nonbonded pdb=" O   VAL A  35 "
          pdb=" CB  ASP A  36 "
   model   vdw
   4.187 3.440
nonbonded pdb=" CB  TYR A  56 "
          pdb=" CE1 TYR A  61 "
   model   vdw
   4.187 3.740
nonbonded pdb=" C   TYR A  34 "
          pdb=" N   ASP A  36 "
   model   vdw
   4.188 3.350
nonbonded pdb=" C   TYR A  56 "
          pdb=" N   PRO A  58 "
   model   vdw
   4.188 3.350
nonbonded pdb=" CB  VAL A  35 "
          pdb=" O   VAL A  43 "
   model   vdw
   4.188 3.470
nonbonded pdb=" CG  GLU A   5 "
          pdb=" CA  ILE A   6 "
   model   vdw
   4.188 3.870
nonbonded pdb=" C   SER A  27 "
          pdb=" CD2 LEU A  28 "
   model   vdw
   4.188 3.690
nonbonded pdb=" CE2 TYR A  41 "
          pdb=" CG  PRO A  42 "
   model   vdw sym.op.
   4.188 3.740 -x+1,y,-z+1
nonbonded pdb=" N   SER A  67 "
          pdb=" CA  PHE A  68 "
   model   vdw
   4.189 3.550
nonbonded pdb=" O   VAL A  19 "
          pdb=" N   ARG A  21 "
   model   vdw
   4.189 3.120
nonbonded pdb=" CB  VAL A   4 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   4.189 3.890
nonbonded pdb=" CG1 VAL A  70 "
          pdb=" O   SER A  75 "
   model   vdw
   4.189 3.460
nonbonded pdb=" O   THR A  62 "
          pdb=" CB  VAL A  63 "
   model   vdw
   4.190 3.470
nonbonded pdb=" O   LYS A   7 "
          pdb=" CB  PRO A   8 "
   model   vdw
   4.191 3.440
nonbonded pdb=" C   LYS A   7 "
          pdb=" CD  LYS A   7 "
   model   vdw
   4.191 3.670
nonbonded pdb=" CA  GLN A  53 "
          pdb=" OE1 GLN A  53 "
   model   vdw
   4.191 3.470
nonbonded pdb=" CD1 LEU A  49 "
          pdb=" N   ALA A  55 "
   model   vdw
   4.191 3.540
nonbonded pdb=" O   PHE A  68 "
          pdb=" C   LYS A  69 "
   model   vdw
   4.192 3.270
nonbonded pdb=" O   TYR A  34 "
          pdb=" N   ASP A  36 "
   model   vdw
   4.192 3.120
nonbonded pdb=" C   GLY A  71 "
          pdb=" O   GLN A  72 "
   model   vdw
   4.192 3.270
nonbonded pdb=" N   GLY A  18 "
          pdb=" OH  TYR A  26 "
   model   vdw
   4.192 3.120
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" N   PRO A  58 "
   model   vdw
   4.193 3.540
nonbonded pdb=" O   VAL A  35 "
          pdb="O    HOH S   3 "
   model   vdw
   4.194 3.040
nonbonded pdb=" CB  SER A   9 "
          pdb=" O   THR A  15 "
   model   vdw sym.op.
   4.194 3.440 -x+1/2,y+1/2,-z+1
nonbonded pdb=" O   SER A  67 "
          pdb=" O   PHE A  68 "
   model   vdw
   4.195 3.040
nonbonded pdb=" CE1 TYR A  56 "
          pdb=" CA  LEU A  83 "
   model   vdw
   4.195 3.770
nonbonded pdb=" CB  GLN A  31 "
          pdb=" CG1 ILE A  47 "
   model   vdw
   4.195 3.840
nonbonded pdb=" NE2 GLN A  10 "
          pdb=" CZ  TYR A  34 "
   model   vdw
   4.195 3.340
nonbonded pdb=" CD2 LEU A  76 "
          pdb=" CD1 ILE A  78 "
   model   vdw sym.op.
   4.195 3.880 -x+1,y,-z+2
nonbonded pdb=" CB  HIS A  64 "
          pdb="O    HOH S  35 "
   model   vdw
   4.196 3.440
nonbonded pdb=" CE  LYS A  24 "
          pdb=" NH1 ARG A  21 "
   model   vdw sym.op.
   4.196 3.520 -x+1/2,y+1/2,-z+2
nonbonded pdb=" NH1 ARG A  21 "
          pdb=" CE  LYS A  24 "
   model   vdw sym.op.
   4.196 3.520 -x+1/2,y-1/2,-z+2
nonbonded pdb=" O   TYR A  41 "
          pdb=" CB  PRO A  42 "
   model   vdw
   4.196 3.440
nonbonded pdb=" CD  LYS A   3 "
          pdb=" CD2 LEU A  60 "
   model   vdw
   4.196 3.860
nonbonded pdb=" N   LEU A  65 "
          pdb=" CA  SER A  66 "
   model   vdw
   4.196 3.550
nonbonded pdb=" OG1 THR A  14 "
          pdb=" CB  GLU A  30 "
   model   vdw
   4.196 3.440
nonbonded pdb=" C   GLU A  51 "
          pdb=" CD  GLU A  51 "
   model   vdw
   4.197 3.500
nonbonded pdb=" CD1 PHE A  13 "
          pdb=" C   THR A  14 "
   model   vdw
   4.197 3.570
nonbonded pdb=" CG  LYS A   7 "
          pdb=" CG  GLU A  40 "
   model   vdw sym.op.
   4.197 3.840 -x+1,y,-z+1
nonbonded pdb=" CG  LYS A  69 "
          pdb=" O   MSE A  77 "
   model   vdw
   4.197 3.440
nonbonded pdb=" C   LYS A  46 "
          pdb=" CG1 ILE A  47 "
   model   vdw
   4.197 3.670
nonbonded pdb=" O   LYS A   7 "
          pdb=" CG  GLN A  10 "
   model   vdw
   4.198 3.440
nonbonded pdb=" CB  ARG A  21 "
          pdb=" CA  GLN A  22 "
   model   vdw
   4.198 3.870
nonbonded pdb=" CB  SER A  20 "
          pdb=" CA  ARG A  21 "
   model   vdw
   4.198 3.870
nonbonded pdb=" N   ARG A  21 "
          pdb=" CA  GLN A  22 "
   model   vdw
   4.200 3.550
nonbonded pdb=" O   GLN A  10 "
          pdb=" O   ALA A  11 "
   model   vdw
   4.200 3.040
nonbonded pdb=" O   PRO A   8 "
          pdb=" CB  SER A   9 "
   model   vdw
   4.200 3.440
nonbonded pdb=" O   ARG A  16 "
          pdb=" CE1 TYR A  26 "
   model   vdw
   4.201 3.340
nonbonded pdb=" CG1 VAL A  63 "
          pdb=" CZ  PHE A  68 "
   model   vdw
   4.201 3.760
nonbonded pdb=" NZ  LYS A  46 "
          pdb=" O   PHE A  73 "
   model   vdw sym.op.
   4.201 3.120 -x+1,y,-z+2
nonbonded pdb=" C   ILE A   6 "
          pdb=" O   GLY A  59 "
   model   vdw
   4.201 3.270
nonbonded pdb=" CD1 LEU A  65 "
          pdb=" CD2 LEU A  37 "
   model   vdw sym.op.
   4.201 3.880 -x+1,y,-z+2
nonbonded pdb=" CD2 LEU A  37 "
          pdb=" CD1 LEU A  65 "
   model   vdw sym.op.
   4.201 3.880 -x+1,y,-z+2
nonbonded pdb=" CA  VAL A  19 "
          pdb=" CE2 TYR A  26 "
   model   vdw
   4.201 3.770
nonbonded pdb=" O   THR A  62 "
          pdb=" O   ARG A  82 "
   model   vdw
   4.201 3.040
nonbonded pdb=" O   LEU A  65 "
          pdb=" CA  PHE A  68 "
   model   vdw
   4.202 3.470
nonbonded pdb=" CB  TYR A  61 "
          pdb=" CD1 LEU A  83 "
   model   vdw
   4.202 3.860
nonbonded pdb=" CG  ARG A  16 "
          pdb=" N   SER A  17 "
   model   vdw
   4.202 3.520
nonbonded pdb=" O   SER A  20 "
          pdb=" CG  GLN A  53 "
   model   vdw sym.op.
   4.203 3.440 x,y-1,z
nonbonded pdb=" CG  GLN A  53 "
          pdb=" O   SER A  20 "
   model   vdw sym.op.
   4.203 3.440 x,y+1,z
nonbonded pdb=" CG1 VAL A  19 "
          pdb=" N   LYS A  24 "
   model   vdw
   4.203 3.540
nonbonded pdb=" CG  GLN A  10 "
          pdb=" CB  LEU A  32 "
   model   vdw
   4.203 3.840
nonbonded pdb=" CA  SER A  67 "
          pdb=" NH1 ARG A  82 "
   model   vdw
   4.204 3.550
nonbonded pdb=" CA  LEU A  60 "
          pdb=" CD1 TYR A  61 "
   model   vdw
   4.204 3.770
nonbonded pdb=" CG  LYS A  69 "
          pdb=" N   ASP A  79 "
   model   vdw
   4.204 3.520
nonbonded pdb=" C   ASN A  39 "
          pdb="O    HOH S   3 "
   model   vdw
   4.205 3.270
nonbonded pdb=" O   THR A  48 "
          pdb=" CB  ARG A  80 "
   model   vdw
   4.205 3.440
nonbonded pdb=" O   TYR A  56 "
          pdb=" CB  ALA A  57 "
   model   vdw
   4.205 3.460
nonbonded pdb=" N   ALA A  11 "
          pdb=" CA  GLN A  12 "
   model   vdw
   4.205 3.550
nonbonded pdb="O    HOH S 123 "
          pdb="O    HOH S 131 "
   model   vdw
   4.207 3.040
nonbonded pdb=" OE1 GLU A   5 "
          pdb=" CE  LYS A   7 "
   model   vdw
   4.207 3.440
nonbonded pdb=" CB  GLU A  40 "
          pdb=" CD2 TYR A  41 "
   model   vdw
   4.209 3.740
nonbonded pdb=" OE2 GLU A  51 "
          pdb=" NE2 HIS A  64 "
   model   vdw sym.op.
   4.209 3.120 -x+1/2,y-1/2,-z+2
nonbonded pdb=" CB  GLN A  10 "
          pdb=" C   LEU A  32 "
   model   vdw
   4.210 3.670
nonbonded pdb=" N   GLN A  22 "
          pdb=" CA  GLY A  23 "
   model   vdw
   4.210 3.520
nonbonded pdb=" NH1 ARG A  16 "
          pdb=" CA  PRO A  85 "
   model   vdw sym.op.
   4.210 3.550 x,y-1,z
nonbonded pdb=" C   GLY A  38 "
          pdb=" ND2 ASN A  39 "
   model   vdw
   4.210 3.350
nonbonded pdb=" CG2 VAL A  19 "
          pdb=" CD  PRO A  54 "
   model   vdw sym.op.
   4.210 3.860 x,y-1,z
nonbonded pdb=" CD  PRO A  54 "
          pdb=" CG2 VAL A  19 "
   model   vdw sym.op.
   4.210 3.860 x,y+1,z
nonbonded pdb=" C   GLN A  53 "
          pdb=" N   ALA A  55 "
   model   vdw
   4.211 3.350
nonbonded pdb=" CA  GLY A  18 "
          pdb=" O   TYR A  26 "
   model   vdw
   4.211 3.440
nonbonded pdb=" O   VAL A  63 "
          pdb=" CB  HIS A  64 "
   model   vdw
   4.211 3.440
nonbonded pdb=" O   ARG A  80 "
          pdb=" CD  ARG A  82 "
   model   vdw
   4.211 3.440
nonbonded pdb=" CE1 TYR A  34 "
          pdb=" CB  LEU A  44 "
   model   vdw
   4.211 3.740
nonbonded pdb=" O   GLY A  52 "
          pdb=" CB  GLN A  53 "
   model   vdw
   4.211 3.440
nonbonded pdb=" CE2 TYR A  61 "
          pdb=" N   PRO A  85 "
   model   vdw
   4.212 3.420
nonbonded pdb=" CG  GLU A  51 "
          pdb="O    HOH S 175 "
   model   vdw
   4.212 3.440
nonbonded pdb=" N   ASP A  79 "
          pdb=" OD1 ASP A  79 "
   model   vdw
   4.212 3.120
nonbonded pdb=" N   GLU A  40 "
          pdb=" CA  TYR A  41 "
   model   vdw
   4.212 3.550
nonbonded pdb=" CD1 ILE A   6 "
          pdb=" CD  GLN A  31 "
   model   vdw
   4.213 3.690
nonbonded pdb=" OG1 THR A  62 "
          pdb=" O   VAL A  63 "
   model   vdw
   4.213 3.040
nonbonded pdb=" O   SER A  20 "
          pdb=" C   GLY A  23 "
   model   vdw
   4.213 3.270
nonbonded pdb=" O   CYS A  33 "
          pdb=" CD2 TYR A  34 "
   model   vdw
   4.214 3.340
nonbonded pdb=" O   VAL A  43 "
          pdb=" O   LEU A  44 "
   model   vdw
   4.214 3.040
nonbonded pdb=" N   GLN A  72 "
          pdb=" CA  PHE A  73 "
   model   vdw
   4.214 3.550
nonbonded pdb=" CG  GLU A  30 "
          pdb=" OG1 THR A  48 "
   model   vdw
   4.215 3.440
nonbonded pdb=" CA  LYS A  24 "
          pdb=" CG  PRO A  25 "
   model   vdw
   4.215 3.870
nonbonded pdb=" O   ILE A   2 "
          pdb=" N   VAL A  63 "
   model   vdw
   4.215 3.120
nonbonded pdb=" CG  GLN A  10 "
          pdb="O    HOH S   7 "
   model   vdw
   4.215 3.440
nonbonded pdb=" OE1 GLN A  72 "
          pdb="O    HOH S   2 "
   model   vdw sym.op.
   4.216 3.040 -x+1,y-1,-z+2
nonbonded pdb=" NZ  LYS A  24 "
          pdb=" NH1 ARG A  21 "
   model   vdw sym.op.
   4.216 3.200 -x+1/2,y+1/2,-z+2
nonbonded pdb=" NH1 ARG A  21 "
          pdb=" NZ  LYS A  24 "
   model   vdw sym.op.
   4.216 3.200 -x+1/2,y-1/2,-z+2
nonbonded pdb=" N   VAL A  84 "
          pdb=" CD  PRO A  85 "
   model   vdw
   4.216 3.520
nonbonded pdb=" O   SER A  17 "
          pdb=" C   GLY A  18 "
   model   vdw
   4.217 3.270
nonbonded pdb=" CZ  TYR A  56 "
          pdb=" CD1 LEU A  83 "
   model   vdw
   4.217 3.680
nonbonded pdb=" C   TYR A  26 "
          pdb=" CE1 TYR A  26 "
   model   vdw
   4.217 3.570
nonbonded pdb=" CD  ARG A  16 "
          pdb=" CD1 LEU A  28 "
   model   vdw
   4.217 3.860
nonbonded pdb=" C   GLY A  74 "
          pdb=" OG  SER A  75 "
   model   vdw
   4.217 3.270
nonbonded pdb=" CA  ARG A  21 "
          pdb=" NE  ARG A  21 "
   model   vdw
   4.217 3.550
nonbonded pdb=" CD2 LEU A  37 "
          pdb=" CD1 LEU A  76 "
   model   vdw sym.op.
   4.217 3.880 -x+1,y,-z+2
nonbonded pdb=" CD1 LEU A  76 "
          pdb=" CD2 LEU A  37 "
   model   vdw sym.op.
   4.217 3.880 -x+1,y,-z+2
nonbonded pdb=" O   SER A  67 "
          pdb=" CG  PHE A  68 "
   model   vdw
   4.218 3.260
nonbonded pdb=" SG  CYS A  33 "
          pdb=" CB  VAL A  45 "
   model   vdw
   4.218 3.830
nonbonded pdb=" OG  SER A  17 "
          pdb=" CB  SER A  27 "
   model   vdw
   4.219 3.440
nonbonded pdb=" CB  ASN A  39 "
          pdb=" CA  GLU A  40 "
   model   vdw
   4.220 3.870
nonbonded pdb=" CD  ARG A  16 "
          pdb="O    HOH S   8 "
   model   vdw
   4.220 3.440
nonbonded pdb=" C   THR A  48 "
          pdb=" CG  LEU A  49 "
   model   vdw
   4.220 3.700
nonbonded pdb=" CG  PRO A   8 "
          pdb=" N   SER A   9 "
   model   vdw
   4.220 3.520
nonbonded pdb=" O   LEU A  65 "
          pdb=" CB  SER A  66 "
   model   vdw
   4.220 3.440
nonbonded pdb=" C   LEU A  65 "
          pdb=" N   PHE A  68 "
   model   vdw
   4.220 3.350
nonbonded pdb=" CG  ARG A  16 "
          pdb=" CD1 LEU A  28 "
   model   vdw
   4.221 3.860
nonbonded pdb=" O   LEU A  37 "
          pdb=" OD1 ASN A  39 "
   model   vdw
   4.221 3.040
nonbonded pdb=" O   LEU A  37 "
          pdb=" CG  LEU A  65 "
   model   vdw sym.op.
   4.221 3.470 -x+1,y,-z+2
nonbonded pdb=" CG  LEU A  76 "
          pdb=" O   MSE A  77 "
   model   vdw
   4.221 3.470
nonbonded pdb=" CE1 PHE A  13 "
          pdb="O    HOH S 117 "
   model   vdw
   4.221 3.340
nonbonded pdb=" CB  HIS A  64 "
          pdb=" OG  SER A  66 "
   model   vdw
   4.222 3.440
nonbonded pdb=" O   ASP A  50 "
          pdb=" CB  GLU A  51 "
   model   vdw
   4.222 3.440
nonbonded pdb=" CB  SER A  20 "
          pdb=" N   GLN A  22 "
   model   vdw
   4.222 3.520
nonbonded pdb=" O   VAL A  45 "
          pdb=" O   LYS A  46 "
   model   vdw
   4.222 3.040
nonbonded pdb=" CG2 THR A  15 "
          pdb=" CA  ARG A  16 "
   model   vdw
   4.222 3.890
nonbonded pdb=" CG  LYS A   3 "
          pdb=" O   VAL A   4 "
   model   vdw
   4.222 3.440
nonbonded pdb=" CB  SER A  67 "
          pdb=" CA  LEU A  81 "
   model   vdw
   4.222 3.870
nonbonded pdb=" CG  LYS A   3 "
          pdb=" CA  VAL A   4 "
   model   vdw
   4.222 3.870
nonbonded pdb=" CB  ARG A  16 "
          pdb=" CZ  ARG A  16 "
   model   vdw
   4.223 3.670
nonbonded pdb=" CB  THR A  62 "
          pdb="O    HOH S  12 "
   model   vdw
   4.223 3.470
nonbonded pdb=" O   PRO A  54 "
          pdb=" CB  ALA A  55 "
   model   vdw
   4.223 3.460
nonbonded pdb=" N   SER A   9 "
          pdb=" N   THR A  15 "
   model   vdw sym.op.
   4.223 3.200 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CA  VAL A  19 "
          pdb=" CA  PRO A  25 "
   model   vdw
   4.224 3.900
nonbonded pdb=" CB  SER A  20 "
          pdb=" C   LYS A  24 "
   model   vdw
   4.224 3.670
nonbonded pdb=" CE1 TYR A  56 "
          pdb=" C   LEU A  83 "
   model   vdw
   4.225 3.570
nonbonded pdb=" O   PRO A  42 "
          pdb=" O   VAL A  43 "
   model   vdw
   4.225 3.040
nonbonded pdb=" O   LEU A  49 "
          pdb=" CB  ASP A  50 "
   model   vdw
   4.225 3.440
nonbonded pdb=" O   ILE A   2 "
          pdb=" O   TYR A  61 "
   model   vdw
   4.226 3.040
nonbonded pdb=" C   VAL A  63 "
          pdb=" N   LEU A  65 "
   model   vdw
   4.226 3.350
nonbonded pdb=" CD  GLN A  72 "
          pdb=" CB  LYS A   3 "
   model   vdw sym.op.
   4.226 3.670 -x+1,y-1,-z+2
nonbonded pdb=" CB  LYS A   3 "
          pdb=" CD  GLN A  72 "
   model   vdw sym.op.
   4.226 3.670 -x+1,y+1,-z+2
nonbonded pdb=" O   LEU A  44 "
          pdb=" CG1 VAL A  70 "
   model   vdw sym.op.
   4.227 3.460 -x+1,y,-z+2
nonbonded pdb=" CB  ALA A  11 "
          pdb=" CB  THR A  14 "
   model   vdw sym.op.
   4.227 3.890 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CD2 TYR A  41 "
          pdb=" CE2 TYR A  34 "
   model   vdw sym.op.
   4.227 3.640 -x+1,y,-z+1
nonbonded pdb=" CE2 TYR A  34 "
          pdb=" CD2 TYR A  41 "
   model   vdw sym.op.
   4.227 3.640 -x+1,y,-z+1
nonbonded pdb=" C   TYR A  61 "
          pdb=" CG2 THR A  62 "
   model   vdw
   4.228 3.690
nonbonded pdb=" O   ALA A  55 "
          pdb=" CB  TYR A  56 "
   model   vdw
   4.229 3.440
nonbonded pdb=" CA  ALA A  55 "
          pdb=" O   TYR A  56 "
   model   vdw
   4.229 3.470
nonbonded pdb=" O   ILE A   6 "
          pdb=" CB  LYS A   7 "
   model   vdw
   4.229 3.440
nonbonded pdb="SE    SE Z   5 "
          pdb="O    HOH S  12 "
   model   vdw sym.op.
   4.229 3.420 x-1/2,y-3/2,z-1
nonbonded pdb=" OE2 GLU A   5 "
          pdb=" CD  LYS A   7 "
   model   vdw
   4.230 3.440
nonbonded pdb=" O   PRO A   8 "
          pdb=" O   SER A   9 "
   model   vdw
   4.230 3.040
nonbonded pdb=" C   PRO A   8 "
          pdb=" CA  THR A  15 "
   model   vdw sym.op.
   4.230 3.700 -x+1/2,y+1/2,-z+1
nonbonded pdb=" O   SER A  66 "
          pdb=" CB  SER A  67 "
   model   vdw
   4.231 3.440
nonbonded pdb=" C   VAL A  35 "
          pdb=" CA  PRO A  42 "
   model   vdw
   4.231 3.700
nonbonded pdb=" CB  PRO A   8 "
          pdb=" CA  THR A  14 "
   model   vdw sym.op.
   4.232 3.870 -x+1/2,y+1/2,-z+1
nonbonded pdb=" O   LYS A  69 "
          pdb=" O   SER A  75 "
   model   vdw
   4.232 3.040
nonbonded pdb=" CD2 TYR A  56 "
          pdb="O    HOH S  98 "
   model   vdw
   4.232 3.340
nonbonded pdb=" O   SER A  75 "
          pdb=" CB  LEU A  76 "
   model   vdw
   4.232 3.440
nonbonded pdb=" CD  GLN A  53 "
          pdb=" O   VAL A  19 "
   model   vdw sym.op.
   4.232 3.270 x,y+1,z
nonbonded pdb=" O   VAL A  19 "
          pdb=" CD  GLN A  53 "
   model   vdw sym.op.
   4.232 3.270 x,y-1,z
nonbonded pdb=" CB  THR A  48 "
          pdb=" NE  ARG A  80 "
   model   vdw
   4.233 3.550
nonbonded pdb=" CA  SER A   9 "
          pdb=" C   THR A  15 "
   model   vdw sym.op.
   4.233 3.700 -x+1/2,y+1/2,-z+1
nonbonded pdb=" C   ALA A  55 "
          pdb=" CG  TYR A  56 "
   model   vdw
   4.234 3.490
nonbonded pdb=" O   LEU A  32 "
          pdb=" C   CYS A  33 "
   model   vdw
   4.234 3.270
nonbonded pdb=" O   GLN A  10 "
          pdb=" O   LEU A  32 "
   model   vdw
   4.234 3.040
nonbonded pdb=" O   THR A  48 "
          pdb=" NE  ARG A  80 "
   model   vdw
   4.234 3.120
nonbonded pdb=" O   THR A  14 "
          pdb=" C   GLU A  30 "
   model   vdw
   4.234 3.270
nonbonded pdb=" CD1 LEU A  44 "
          pdb=" N   VAL A  45 "
   model   vdw
   4.234 3.540
nonbonded pdb=" C   ARG A  16 "
          pdb=" O   LEU A  28 "
   model   vdw
   4.235 3.270
nonbonded pdb=" CB  ILE A  47 "
          pdb=" O   LEU A  81 "
   model   vdw
   4.235 3.470
nonbonded pdb=" CA  SER A  66 "
          pdb=" N   PHE A  68 "
   model   vdw
   4.235 3.550
nonbonded pdb=" CA  GLN A  12 "
          pdb=" OE1 GLN A  12 "
   model   vdw
   4.235 3.470
nonbonded pdb=" OE1 GLN A  31 "
          pdb=" O   TYR A  56 "
   model   vdw
   4.235 3.040
nonbonded pdb=" O   ILE A   2 "
          pdb=" CZ  PHE A  73 "
   model   vdw sym.op.
   4.235 3.340 -x+1,y+1,-z+2
nonbonded pdb=" O   GLN A  10 "
          pdb=" CB  ALA A  11 "
   model   vdw
   4.235 3.460
nonbonded pdb=" O   VAL A  84 "
          pdb=" CB  PRO A  85 "
   model   vdw
   4.236 3.440
nonbonded pdb=" N   TYR A  41 "
          pdb=" CD  PRO A  42 "
   model   vdw
   4.236 3.520
nonbonded pdb=" O   ASN A  39 "
          pdb=" CB  GLU A  40 "
   model   vdw
   4.236 3.440
nonbonded pdb=" CE1 TYR A  34 "
          pdb=" O   PRO A  42 "
   model   vdw
   4.236 3.340
nonbonded pdb=" CZ  PHE A  13 "
          pdb="O    HOH S 110 "
   model   vdw
   4.237 3.340
nonbonded pdb=" CG  ASP A  79 "
          pdb=" NH2 ARG A  82 "
   model   vdw
   4.237 3.350
nonbonded pdb=" N   GLY A  74 "
          pdb=" CA  SER A  75 "
   model   vdw
   4.237 3.550
nonbonded pdb=" N   PRO A   8 "
          pdb=" CA  SER A   9 "
   model   vdw
   4.238 3.550
nonbonded pdb=" CB  SER A  20 "
          pdb=" CB  LYS A  24 "
   model   vdw
   4.238 3.840
nonbonded pdb=" OE1 GLN A  31 "
          pdb=" CD1 LEU A  49 "
   model   vdw
   4.238 3.460
nonbonded pdb=" CD1 LEU A  76 "
          pdb=" CD1 LEU A  37 "
   model   vdw sym.op.
   4.238 3.880 -x+1,y,-z+2
nonbonded pdb=" CD1 LEU A  37 "
          pdb=" CD1 LEU A  76 "
   model   vdw sym.op.
   4.238 3.880 -x+1,y,-z+2
nonbonded pdb=" CD1 LEU A  65 "
          pdb=" CA  ILE A   2 "
   model   vdw sym.op.
   4.238 3.890 -x+1,y,-z+2
nonbonded pdb=" CA  ILE A   2 "
          pdb=" CD1 LEU A  65 "
   model   vdw sym.op.
   4.238 3.890 -x+1,y,-z+2
nonbonded pdb=" C   LEU A  65 "
          pdb=" OG  SER A  66 "
   model   vdw
   4.239 3.270
nonbonded pdb=" CG  PHE A  68 "
          pdb=" O   MSE A  77 "
   model   vdw
   4.239 3.260
nonbonded pdb=" NZ  LYS A  24 "
          pdb=" CD  ARG A  82 "
   model   vdw sym.op.
   4.240 3.520 -x+1/2,y-1/2,-z+2
nonbonded pdb=" CD  ARG A  82 "
          pdb=" NZ  LYS A  24 "
   model   vdw sym.op.
   4.240 3.520 -x+1/2,y+1/2,-z+2
nonbonded pdb=" O   TYR A  61 "
          pdb="O    HOH S  54 "
   model   vdw
   4.240 3.040
nonbonded pdb=" N   GLY A  59 "
          pdb=" CE1 TYR A  61 "
   model   vdw
   4.240 3.420
nonbonded pdb=" O   LEU A  76 "
          pdb="O    HOH S  10 "
   model   vdw sym.op.
   4.241 3.040 -x+1,y,-z+2
nonbonded pdb=" OH  TYR A  56 "
          pdb="O    HOH S 135 "
   model   vdw
   4.241 3.040
nonbonded pdb=" CG  PHE A  13 "
          pdb="O    HOH S 110 "
   model   vdw
   4.241 3.260
nonbonded pdb=" O   LEU A  37 "
          pdb=" CG  LEU A  37 "
   model   vdw
   4.242 3.470
nonbonded pdb=" CB  ASN A  39 "
          pdb=" N   TYR A  41 "
   model   vdw
   4.242 3.520
nonbonded pdb=" CD  LYS A   7 "
          pdb="O    HOH S  51 "
   model   vdw
   4.242 3.440
nonbonded pdb=" O   VAL A  43 "
          pdb=" CG2 VAL A  43 "
   model   vdw
   4.242 3.460
nonbonded pdb=" C   GLN A  72 "
          pdb=" CD1 PHE A  73 "
   model   vdw
   4.243 3.570
nonbonded pdb=" CG1 VAL A  35 "
          pdb=" O   ASP A  36 "
   model   vdw
   4.243 3.460
nonbonded pdb=" NH2 ARG A  16 "
          pdb=" C   GLY A  59 "
   model   vdw sym.op.
   4.243 3.350 x,y-1,z
nonbonded pdb=" CB  ASN A  29 "
          pdb=" CB  LEU A  49 "
   model   vdw
   4.243 3.840
nonbonded pdb=" CG2 VAL A  35 "
          pdb=" CG2 VAL A  45 "
   model   vdw
   4.243 3.880
nonbonded pdb=" O   SER A  20 "
          pdb=" CA  GLN A  22 "
   model   vdw
   4.244 3.470
nonbonded pdb=" CG1 VAL A  45 "
          pdb=" CB  LEU A  76 "
   model   vdw sym.op.
   4.244 3.860 -x+1,y,-z+2
nonbonded pdb=" OG1 THR A  15 "
          pdb=" O   LEU A  28 "
   model   vdw
   4.244 3.040
nonbonded pdb=" NE2 HIS A  64 "
          pdb=" N   LEU A  65 "
   model   vdw
   4.245 3.200
nonbonded pdb=" O   ARG A  80 "
          pdb=" CB  LEU A  81 "
   model   vdw
   4.245 3.440
nonbonded pdb=" O   LYS A  69 "
          pdb=" CB  MSE A  77 "
   model   vdw
   4.246 3.440
nonbonded pdb=" CG  LYS A   3 "
          pdb=" C   VAL A   4 "
   model   vdw
   4.246 3.670
nonbonded pdb=" OG  SER A  66 "
          pdb=" CG  ARG A  82 "
   model   vdw
   4.246 3.440
nonbonded pdb=" N   GLY A  38 "
          pdb=" CA  ASN A  39 "
   model   vdw
   4.246 3.550
nonbonded pdb=" CA  PRO A  54 "
          pdb=" O   ALA A  55 "
   model   vdw
   4.247 3.470
nonbonded pdb=" CA  TYR A  34 "
          pdb=" C   VAL A  43 "
   model   vdw
   4.247 3.700
nonbonded pdb=" O   ALA A  55 "
          pdb="O    HOH S  98 "
   model   vdw
   4.247 3.040
nonbonded pdb=" CD  ARG A  21 "
          pdb=" CE1 HIS A  64 "
   model   vdw sym.op.
   4.248 3.660 x,y-1,z
nonbonded pdb=" CA  ILE A  47 "
          pdb="O    HOH S  10 "
   model   vdw
   4.248 3.470
nonbonded pdb=" CG  TYR A  61 "
          pdb=" CD1 LEU A  83 "
   model   vdw
   4.249 3.680
nonbonded pdb=" O   SER A  17 "
          pdb=" OG  SER A  17 "
   model   vdw
   4.250 3.040
nonbonded pdb=" C   LEU A  81 "
          pdb="O    HOH S 106 "
   model   vdw
   4.250 3.270
nonbonded pdb=" CG  TYR A  56 "
          pdb=" CD1 LEU A  83 "
   model   vdw
   4.250 3.680
nonbonded pdb=" C   GLY A  38 "
          pdb="O    HOH S 123 "
   model   vdw
   4.250 3.270
nonbonded pdb=" ND1 HIS A  64 "
          pdb=" C   LEU A  65 "
   model   vdw
   4.251 3.350
nonbonded pdb=" O   PHE A  73 "
          pdb=" CG  PHE A  73 "
   model   vdw
   4.251 3.260
nonbonded pdb=" CA  ILE A   6 "
          pdb=" O   LYS A   7 "
   model   vdw
   4.252 3.470
nonbonded pdb=" N   GLY A  52 "
          pdb=" CA  GLN A  53 "
   model   vdw
   4.252 3.550
nonbonded pdb=" O   LYS A   3 "
          pdb="O    HOH S   2 "
   model   vdw
   4.253 3.040
nonbonded pdb=" C   PRO A   8 "
          pdb=" OG1 THR A  15 "
   model   vdw sym.op.
   4.253 3.270 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CG  GLU A   5 "
          pdb=" NZ  LYS A   7 "
   model   vdw
   4.254 3.520
nonbonded pdb=" CB  TYR A  41 "
          pdb=" CZ  TYR A  41 "
   model   vdw
   4.254 3.660
nonbonded pdb=" CB  ALA A  57 "
          pdb=" O   PRO A  58 "
   model   vdw
   4.255 3.460
nonbonded pdb=" CA  GLU A  51 "
          pdb=" OE1 GLU A  51 "
   model   vdw
   4.255 3.470
nonbonded pdb=" O   THR A  48 "
          pdb=" CB  LEU A  49 "
   model   vdw
   4.255 3.440
nonbonded pdb=" N   GLY A  18 "
          pdb=" C   TYR A  26 "
   model   vdw
   4.255 3.350
nonbonded pdb=" CD1 TYR A  56 "
          pdb=" CZ  TYR A  61 "
   model   vdw
   4.255 3.560
nonbonded pdb=" O   GLY A  71 "
          pdb=" CB  GLN A  72 "
   model   vdw
   4.256 3.440
nonbonded pdb=" C   GLY A  52 "
          pdb=" CD  PRO A  54 "
   model   vdw
   4.256 3.670
nonbonded pdb=" CA  ARG A  21 "
          pdb=" N   GLY A  23 "
   model   vdw
   4.256 3.550
nonbonded pdb=" CA  ALA A  55 "
          pdb="O    HOH S 134 "
   model   vdw
   4.256 3.470
nonbonded pdb=" CZ  TYR A  56 "
          pdb=" O   LEU A  83 "
   model   vdw
   4.256 3.260
nonbonded pdb=" O   GLY A  59 "
          pdb=" CD2 LEU A  60 "
   model   vdw
   4.257 3.460
nonbonded pdb=" O   CYS A  33 "
          pdb=" N   VAL A  35 "
   model   vdw
   4.257 3.120
nonbonded pdb=" OG1 THR A  62 "
          pdb=" CA  VAL A  63 "
   model   vdw
   4.258 3.470
nonbonded pdb=" CG2 VAL A  45 "
          pdb=" CG1 VAL A  70 "
   model   vdw sym.op.
   4.258 3.880 -x+1,y,-z+2
nonbonded pdb=" O   ILE A  78 "
          pdb=" CB  ASP A  79 "
   model   vdw
   4.259 3.440
nonbonded pdb=" CB  SER A  67 "
          pdb=" CE2 PHE A  68 "
   model   vdw
   4.259 3.740
nonbonded pdb=" N   THR A  14 "
          pdb=" N   GLU A  30 "
   model   vdw
   4.259 3.200
nonbonded pdb=" O   HIS A  64 "
          pdb=" CB  LEU A  65 "
   model   vdw
   4.259 3.440
nonbonded pdb=" O   SER A  67 "
          pdb=" C   ARG A  80 "
   model   vdw
   4.260 3.270
nonbonded pdb=" N   ILE A   6 "
          pdb=" N   GLY A  59 "
   model   vdw
   4.260 3.200
nonbonded pdb=" O   LEU A  65 "
          pdb=" C   SER A  67 "
   model   vdw
   4.260 3.270
nonbonded pdb=" CA  ARG A  16 "
          pdb="O    HOH S   8 "
   model   vdw
   4.260 3.470
nonbonded pdb=" OE1 GLU A  30 "
          pdb=" CG  LYS A  46 "
   model   vdw
   4.260 3.440
nonbonded pdb=" O   LYS A   3 "
          pdb=" CB  VAL A  35 "
   model   vdw
   4.261 3.470
nonbonded pdb=" CA  ASP A  36 "
          pdb=" CA  PRO A  42 "
   model   vdw
   4.261 3.900
nonbonded pdb=" C   LEU A  49 "
          pdb=" OD1 ASP A  50 "
   model   vdw
   4.261 3.270
nonbonded pdb=" CZ  ARG A  16 "
          pdb=" N   LEU A  60 "
   model   vdw sym.op.
   4.261 3.350 x,y-1,z
nonbonded pdb=" C   PRO A   8 "
          pdb=" N   ALA A  11 "
   model   vdw
   4.261 3.350
nonbonded pdb=" N   SER A  20 "
          pdb=" N   LYS A  24 "
   model   vdw
   4.263 3.200
nonbonded pdb=" CG2 ILE A  47 "
          pdb=" CG  LEU A  81 "
   model   vdw
   4.263 3.890
nonbonded pdb=" N   GLY A  18 "
          pdb=" CG  TYR A  26 "
   model   vdw
   4.263 3.340
nonbonded pdb=" O   HIS A  64 "
          pdb=" O   ARG A  82 "
   model   vdw
   4.263 3.040
nonbonded pdb=" CB  TYR A  61 "
          pdb=" CA  THR A  62 "
   model   vdw
   4.263 3.870
nonbonded pdb=" CA  GLY A  71 "
          pdb=" N   PHE A  73 "
   model   vdw
   4.264 3.520
nonbonded pdb=" C   LEU A  37 "
          pdb=" O   GLY A  38 "
   model   vdw
   4.264 3.270
nonbonded pdb=" CD1 TYR A  34 "
          pdb=" CA  LEU A  44 "
   model   vdw
   4.265 3.770
nonbonded pdb=" CG  ASN A  39 "
          pdb=" N   GLU A  40 "
   model   vdw
   4.265 3.350
nonbonded pdb=" CB  ILE A   2 "
          pdb="O    HOH S   2 "
   model   vdw
   4.265 3.470
nonbonded pdb=" O   ASP A  36 "
          pdb=" CG  LEU A  37 "
   model   vdw
   4.265 3.470
nonbonded pdb=" CD  GLN A  22 "
          pdb="O    HOH S 175 "
   model   vdw sym.op.
   4.265 3.270 -x+1/2,y-1/2,-z+2
nonbonded pdb=" O   ASN A  29 "
          pdb=" CD1 LEU A  49 "
   model   vdw
   4.266 3.460
nonbonded pdb=" C   SER A  66 "
          pdb=" O   PHE A  68 "
   model   vdw
   4.266 3.270
nonbonded pdb=" O   GLN A  12 "
          pdb=" NE2 GLN A  31 "
   model   vdw
   4.266 3.120
nonbonded pdb=" CG  LYS A   7 "
          pdb=" CD  PRO A   8 "
   model   vdw
   4.267 3.840
nonbonded pdb=" CD  PRO A   8 "
          pdb="O    HOH S 117 "
   model   vdw sym.op.
   4.267 3.440 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CA  SER A  20 "
          pdb=" NE2 GLN A  53 "
   model   vdw sym.op.
   4.267 3.550 x,y-1,z
nonbonded pdb=" OH  TYR A  56 "
          pdb=" O   LEU A  81 "
   model   vdw
   4.267 3.040
nonbonded pdb=" CA  GLU A  30 "
          pdb=" OE1 GLU A  30 "
   model   vdw
   4.268 3.470
nonbonded pdb=" O   THR A  15 "
          pdb=" C   PRO A   8 "
   model   vdw sym.op.
   4.268 3.270 -x+1/2,y-1/2,-z+1
nonbonded pdb=" C   PRO A   8 "
          pdb=" O   THR A  15 "
   model   vdw sym.op.
   4.268 3.270 -x+1/2,y+1/2,-z+1
nonbonded pdb=" N   SER A   9 "
          pdb=" O   THR A  15 "
   model   vdw sym.op.
   4.269 3.120 -x+1/2,y+1/2,-z+1
nonbonded pdb=" O   THR A  15 "
          pdb=" N   SER A   9 "
   model   vdw sym.op.
   4.269 3.120 -x+1/2,y-1/2,-z+1
nonbonded pdb=" N   GLU A  40 "
          pdb="O    HOH S 123 "
   model   vdw
   4.269 3.120
nonbonded pdb=" CA  ASP A  36 "
          pdb="O    HOH S   3 "
   model   vdw
   4.269 3.470
nonbonded pdb=" O   ARG A  16 "
          pdb=" O   SER A  17 "
   model   vdw
   4.269 3.040
nonbonded pdb=" CE  LYS A  69 "
          pdb="SE    SE Z   4 "
   model   vdw sym.op.
   4.269 3.820 x+1/2,y+3/2,z+2
nonbonded pdb=" CG  PHE A  73 "
          pdb="O    HOH S   4 "
   model   vdw
   4.269 3.260
nonbonded pdb=" C   ASN A  39 "
          pdb=" O   TYR A  41 "
   model   vdw
   4.270 3.270
nonbonded pdb=" CB  GLN A  31 "
          pdb="O    HOH S   7 "
   model   vdw
   4.270 3.440
nonbonded pdb=" C   LEU A  65 "
          pdb=" CD2 PHE A  68 "
   model   vdw
   4.270 3.570
nonbonded pdb=" O   LYS A   3 "
          pdb=" CD  LYS A   3 "
   model   vdw
   4.271 3.440
nonbonded pdb=" CA  THR A  15 "
          pdb="O    HOH S   8 "
   model   vdw
   4.272 3.470
nonbonded pdb=" CB  HIS A  64 "
          pdb=" N   SER A  66 "
   model   vdw
   4.272 3.520
nonbonded pdb=" N   THR A  15 "
          pdb=" O   LEU A  28 "
   model   vdw
   4.272 3.120
nonbonded pdb=" CA  VAL A  70 "
          pdb=" O   GLY A  71 "
   model   vdw
   4.272 3.470
nonbonded pdb=" CG1 VAL A  35 "
          pdb=" C   ASP A  36 "
   model   vdw
   4.272 3.690
nonbonded pdb=" N   CYS A  33 "
          pdb=" C   VAL A  45 "
   model   vdw
   4.272 3.350
nonbonded pdb=" CE2 TYR A  56 "
          pdb="O    HOH S  98 "
   model   vdw
   4.274 3.340
nonbonded pdb=" C   LEU A  65 "
          pdb=" O   SER A  66 "
   model   vdw
   4.274 3.270
nonbonded pdb=" CE2 TYR A  41 "
          pdb=" OH  TYR A  34 "
   model   vdw sym.op.
   4.274 3.340 -x+1,y,-z+1
nonbonded pdb=" OH  TYR A  34 "
          pdb=" CE2 TYR A  41 "
   model   vdw sym.op.
   4.274 3.340 -x+1,y,-z+1
nonbonded pdb=" CA  PRO A   8 "
          pdb=" N   GLN A  10 "
   model   vdw
   4.274 3.550
nonbonded pdb=" OG  SER A  67 "
          pdb=" C   ARG A  80 "
   model   vdw
   4.274 3.270
nonbonded pdb=" CB  ASP A  50 "
          pdb=" O   GLU A  51 "
   model   vdw
   4.274 3.440
nonbonded pdb=" N   LYS A   7 "
          pdb="O    HOH S  51 "
   model   vdw
   4.275 3.120
nonbonded pdb=" CB  ILE A   6 "
          pdb=" CE1 TYR A  61 "
   model   vdw
   4.275 3.770
nonbonded pdb=" CB  LEU A  32 "
          pdb=" CD1 LEU A  44 "
   model   vdw
   4.275 3.860
nonbonded pdb=" C   GLN A  12 "
          pdb=" CG  PHE A  13 "
   model   vdw
   4.275 3.490
nonbonded pdb=" O   ALA A  11 "
          pdb=" O   TYR A  56 "
   model   vdw
   4.276 3.040
nonbonded pdb=" CD  GLN A  10 "
          pdb=" C   CYS A  33 "
   model   vdw
   4.277 3.500
nonbonded pdb=" CA  GLU A   5 "
          pdb=" CD2 LEU A  60 "
   model   vdw
   4.278 3.890
nonbonded pdb="O    HOH S  97 "
          pdb=" NE  ARG A  80 "
   model   vdw sym.op.
   4.278 3.120 -x+1/2,y-1/2,-z+2
nonbonded pdb=" NE  ARG A  80 "
          pdb="O    HOH S  97 "
   model   vdw sym.op.
   4.278 3.120 -x+1/2,y+1/2,-z+2
nonbonded pdb=" CB  TYR A  26 "
          pdb=" CZ  TYR A  26 "
   model   vdw
   4.278 3.660
nonbonded pdb=" CD1 LEU A  49 "
          pdb=" C   PRO A  54 "
   model   vdw
   4.279 3.690
nonbonded pdb=" CB  PHE A  68 "
          pdb=" CZ  PHE A  68 "
   model   vdw
   4.279 3.740
nonbonded pdb=" CB  PHE A  73 "
          pdb=" CZ  PHE A  73 "
   model   vdw
   4.280 3.740
nonbonded pdb=" CD1 TYR A  34 "
          pdb=" CD1 LEU A  44 "
   model   vdw
   4.281 3.760
nonbonded pdb=" CE2 TYR A  61 "
          pdb="O    HOH S  14 "
   model   vdw
   4.281 3.340
nonbonded pdb=" O   GLN A  22 "
          pdb=" CG  GLN A  22 "
   model   vdw
   4.281 3.440
nonbonded pdb=" CA  GLY A  59 "
          pdb="O    HOH S  51 "
   model   vdw
   4.282 3.440
nonbonded pdb=" CA  HIS A  64 "
          pdb=" OG  SER A  67 "
   model   vdw
   4.282 3.470
nonbonded pdb=" C   LYS A   7 "
          pdb=" CA  SER A   9 "
   model   vdw
   4.283 3.700
nonbonded pdb=" CG1 VAL A  63 "
          pdb=" C   HIS A  64 "
   model   vdw
   4.283 3.690
nonbonded pdb=" C   LEU A  49 "
          pdb=" NH1 ARG A  80 "
   model   vdw
   4.284 3.350
nonbonded pdb=" CD  ARG A  21 "
          pdb=" CD  ARG A  82 "
   model   vdw sym.op.
   4.284 3.840 x,y-1,z
nonbonded pdb=" CD  ARG A  82 "
          pdb=" CD  ARG A  21 "
   model   vdw sym.op.
   4.284 3.840 x,y+1,z
nonbonded pdb=" C   ASN A  29 "
          pdb=" OD1 ASN A  29 "
   model   vdw
   4.284 3.270
nonbonded pdb=" CA  PHE A  13 "
          pdb=" C   GLU A  30 "
   model   vdw
   4.285 3.700
nonbonded pdb=" O   GLN A  31 "
          pdb=" N   CYS A  33 "
   model   vdw
   4.285 3.120
nonbonded pdb=" N   GLY A  18 "
          pdb=" CD2 TYR A  26 "
   model   vdw
   4.285 3.420
nonbonded pdb=" CA  PRO A   8 "
          pdb=" N   THR A  15 "
   model   vdw sym.op.
   4.286 3.550 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CB  TYR A  61 "
          pdb=" CZ  TYR A  61 "
   model   vdw
   4.286 3.660
nonbonded pdb=" C   LEU A  60 "
          pdb=" CD2 LEU A  60 "
   model   vdw
   4.286 3.690
nonbonded pdb=" CD1 LEU A  32 "
          pdb=" C   VAL A  45 "
   model   vdw
   4.286 3.690
nonbonded pdb=" O   PRO A  42 "
          pdb=" N   LEU A  44 "
   model   vdw
   4.287 3.120
nonbonded pdb=" C   ARG A  82 "
          pdb=" N   VAL A  84 "
   model   vdw
   4.288 3.350
nonbonded pdb=" C   SER A  27 "
          pdb=" N   ASN A  29 "
   model   vdw
   4.288 3.350
nonbonded pdb=" O   SER A  20 "
          pdb=" N   LYS A  24 "
   model   vdw
   4.288 3.120
nonbonded pdb=" CA  SER A  67 "
          pdb=" C   ARG A  80 "
   model   vdw
   4.288 3.700
nonbonded pdb=" CD1 LEU A  28 "
          pdb=" CG  PRO A  85 "
   model   vdw sym.op.
   4.289 3.860 x,y-1,z
nonbonded pdb=" CB  LEU A  32 "
          pdb=" O   VAL A  45 "
   model   vdw
   4.289 3.440
nonbonded pdb=" CB  TYR A  34 "
          pdb=" CZ  TYR A  34 "
   model   vdw
   4.289 3.660
nonbonded pdb=" N   PRO A   8 "
          pdb="O    HOH S  51 "
   model   vdw
   4.289 3.120
nonbonded pdb=" O   GLY A  71 "
          pdb=" CA  PHE A  73 "
   model   vdw
   4.289 3.470
nonbonded pdb=" N   SER A   9 "
          pdb=" OG1 THR A  15 "
   model   vdw sym.op.
   4.290 3.120 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CB  TYR A  56 "
          pdb=" CZ  TYR A  56 "
   model   vdw
   4.290 3.660
nonbonded pdb=" N   GLU A  51 "
          pdb="O    HOH S  33 "
   model   vdw
   4.290 3.120
nonbonded pdb=" CA  GLN A  31 "
          pdb=" OE1 GLN A  31 "
   model   vdw
   4.291 3.470
nonbonded pdb=" N   GLN A  10 "
          pdb=" CD  GLN A  10 "
   model   vdw
   4.291 3.350
nonbonded pdb=" O   GLN A  10 "
          pdb=" CG  GLN A  10 "
   model   vdw
   4.291 3.440
nonbonded pdb=" O   GLY A  71 "
          pdb=" C   PHE A  73 "
   model   vdw
   4.291 3.270
nonbonded pdb=" CA  GLN A  72 "
          pdb=" OE1 GLN A  72 "
   model   vdw
   4.291 3.470
nonbonded pdb=" N   GLY A  23 "
          pdb=" CA  LYS A  24 "
   model   vdw
   4.293 3.550
nonbonded pdb=" O   ALA A  11 "
          pdb=" O   GLN A  12 "
   model   vdw
   4.293 3.040
nonbonded pdb=" CZ  TYR A  41 "
          pdb=" CD1 TYR A  34 "
   model   vdw sym.op.
   4.293 3.560 -x+1,y,-z+1
nonbonded pdb=" CD1 TYR A  34 "
          pdb=" CZ  TYR A  41 "
   model   vdw sym.op.
   4.293 3.560 -x+1,y,-z+1
nonbonded pdb=" CG  ASP A  36 "
          pdb=" NE2 GLN A  72 "
   model   vdw sym.op.
   4.293 3.350 -x+1,y+1,-z+2
nonbonded pdb=" CA  VAL A  19 "
          pdb=" C   LYS A  24 "
   model   vdw
   4.293 3.700
nonbonded pdb=" CB  PHE A  13 "
          pdb=" CZ  PHE A  13 "
   model   vdw
   4.293 3.740
nonbonded pdb=" O   THR A  14 "
          pdb=" CB  ASN A  29 "
   model   vdw
   4.294 3.440
nonbonded pdb=" CB  ARG A  21 "
          pdb=" NH1 ARG A  21 "
   model   vdw
   4.294 3.520
nonbonded pdb=" N   LEU A  28 "
          pdb=" CD1 LEU A  28 "
   model   vdw
   4.294 3.540
nonbonded pdb=" C   LEU A  76 "
          pdb=" CD1 ILE A  78 "
   model   vdw sym.op.
   4.294 3.690 -x+1,y,-z+2
nonbonded pdb=" C   PRO A   8 "
          pdb=" OG  SER A   9 "
   model   vdw
   4.295 3.270
nonbonded pdb=" CB  PHE A  13 "
          pdb=" N   GLU A  30 "
   model   vdw
   4.295 3.520
nonbonded pdb=" CA  ARG A  21 "
          pdb="O    HOH S 135 "
   model   vdw sym.op.
   4.295 3.470 x,y-1,z
nonbonded pdb="O    HOH S 135 "
          pdb=" CA  ARG A  21 "
   model   vdw sym.op.
   4.295 3.470 x,y+1,z
nonbonded pdb=" O   ASN A  29 "
          pdb=" CB  THR A  48 "
   model   vdw
   4.295 3.470
nonbonded pdb=" CG  GLU A   5 "
          pdb=" N   LYS A   7 "
   model   vdw
   4.296 3.520
nonbonded pdb=" N   ARG A  21 "
          pdb=" N   GLY A  23 "
   model   vdw
   4.296 3.200
nonbonded pdb=" NZ  LYS A  69 "
          pdb="O    HOH S 160 "
   model   vdw
   4.296 3.120
nonbonded pdb=" CG2 THR A  62 "
          pdb=" O   VAL A  63 "
   model   vdw
   4.297 3.460
nonbonded pdb=" O   LYS A  24 "
          pdb=" CG  PRO A  25 "
   model   vdw
   4.298 3.440
nonbonded pdb=" N   ASP A  79 "
          pdb=" CA  ARG A  80 "
   model   vdw
   4.298 3.550
nonbonded pdb=" OD1 ASP A  36 "
          pdb=" CA  LEU A  37 "
   model   vdw
   4.299 3.470
nonbonded pdb=" N   LYS A   7 "
          pdb=" CD  PRO A   8 "
   model   vdw
   4.299 3.520
nonbonded pdb=" C   LEU A  32 "
          pdb=" CD1 LEU A  32 "
   model   vdw
   4.299 3.690
nonbonded pdb=" O   VAL A  70 "
          pdb=" CG2 VAL A  70 "
   model   vdw
   4.299 3.460
nonbonded pdb=" O   GLY A  59 "
          pdb=" CG  LEU A  60 "
   model   vdw
   4.300 3.470
nonbonded pdb=" CD1 ILE A   6 "
          pdb=" CA  CYS A  33 "
   model   vdw
   4.301 3.890
nonbonded pdb=" C   GLY A  74 "
          pdb=" N   LEU A  76 "
   model   vdw
   4.301 3.350
nonbonded pdb=" N   GLN A  22 "
          pdb=" OE1 GLN A  22 "
   model   vdw
   4.301 3.120
nonbonded pdb=" C   ASP A  36 "
          pdb=" OD2 ASP A  36 "
   model   vdw
   4.302 3.270
nonbonded pdb=" C   GLN A  22 "
          pdb="O    HOH S  97 "
   model   vdw
   4.302 3.270
nonbonded pdb=" CG  GLN A  12 "
          pdb=" N   PHE A  13 "
   model   vdw
   4.302 3.520
nonbonded pdb=" CA  SER A   9 "
          pdb=" CA  THR A  15 "
   model   vdw sym.op.
   4.302 3.900 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CA  THR A  15 "
          pdb=" CA  SER A   9 "
   model   vdw sym.op.
   4.302 3.900 -x+1/2,y-1/2,-z+1
nonbonded pdb=" CD1 TYR A  26 "
          pdb=" CD1 LEU A  28 "
   model   vdw
   4.302 3.760
nonbonded pdb=" CB  PHE A  13 "
          pdb=" CB  ASN A  29 "
   model   vdw
   4.303 3.840
nonbonded pdb=" CG2 VAL A  45 "
          pdb=" CA  LEU A  76 "
   model   vdw sym.op.
   4.303 3.890 -x+1,y,-z+2
nonbonded pdb=" CG2 VAL A  35 "
          pdb=" CD2 LEU A  81 "
   model   vdw
   4.303 3.880
nonbonded pdb=" O   SER A  17 "
          pdb=" CZ  TYR A  26 "
   model   vdw
   4.304 3.260
nonbonded pdb=" CB  LYS A   3 "
          pdb=" CB  ASP A  36 "
   model   vdw
   4.305 3.840
nonbonded pdb=" O   GLN A  12 "
          pdb=" CA  GLN A  31 "
   model   vdw
   4.307 3.470
nonbonded pdb=" CE  LYS A  24 "
          pdb=" CD  ARG A  82 "
   model   vdw sym.op.
   4.307 3.840 -x+1/2,y-1/2,-z+2
nonbonded pdb=" CD  ARG A  82 "
          pdb=" CE  LYS A  24 "
   model   vdw sym.op.
   4.307 3.840 -x+1/2,y+1/2,-z+2
nonbonded pdb=" O   SER A  27 "
          pdb=" N   ASN A  29 "
   model   vdw
   4.307 3.120
nonbonded pdb=" CG2 VAL A  45 "
          pdb=" CG2 VAL A  70 "
   model   vdw sym.op.
   4.307 3.880 -x+1,y,-z+2
nonbonded pdb=" CG2 VAL A  70 "
          pdb=" CG2 VAL A  45 "
   model   vdw sym.op.
   4.307 3.880 -x+1,y,-z+2
nonbonded pdb=" NH2 ARG A  16 "
          pdb=" CG  TYR A  61 "
   model   vdw sym.op.
   4.307 3.340 x,y-1,z
nonbonded pdb=" O   LYS A  69 "
          pdb=" CG2 VAL A  70 "
   model   vdw
   4.308 3.460
nonbonded pdb=" C   ILE A   2 "
          pdb=" OG1 THR A  62 "
   model   vdw
   4.308 3.270
nonbonded pdb=" N   PRO A   8 "
          pdb=" CG  PRO A  58 "
   model   vdw
   4.309 3.520
nonbonded pdb=" OD2 ASP A  36 "
          pdb="O    HOH S 123 "
   model   vdw
   4.309 3.040
nonbonded pdb=" NE2 GLN A  31 "
          pdb=" CA  ALA A  55 "
   model   vdw
   4.309 3.550
nonbonded pdb=" CB  PRO A   8 "
          pdb=" C   PHE A  13 "
   model   vdw sym.op.
   4.310 3.670 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CZ  ARG A  16 "
          pdb=" CB  PRO A  85 "
   model   vdw sym.op.
   4.310 3.670 x,y-1,z
nonbonded pdb=" NZ  LYS A   3 "
          pdb=" CD1 LEU A  60 "
   model   vdw
   4.311 3.540
nonbonded pdb=" N   ALA A  57 "
          pdb=" CD  PRO A  58 "
   model   vdw
   4.311 3.520
nonbonded pdb=" N   LEU A  65 "
          pdb=" CD1 LEU A  65 "
   model   vdw
   4.311 3.540
nonbonded pdb=" C   SER A  17 "
          pdb=" OH  TYR A  26 "
   model   vdw
   4.311 3.270
nonbonded pdb=" C   ASP A  36 "
          pdb=" CD2 LEU A  65 "
   model   vdw sym.op.
   4.311 3.690 -x+1,y,-z+2
nonbonded pdb=" O   ARG A  16 "
          pdb="O    HOH S  85 "
   model   vdw
   4.312 3.040
nonbonded pdb=" N   TYR A  34 "
          pdb=" O   VAL A  43 "
   model   vdw
   4.312 3.120
nonbonded pdb=" CB  LYS A  24 "
          pdb=" O   PRO A  25 "
   model   vdw
   4.312 3.440
nonbonded pdb=" CZ  ARG A  16 "
          pdb=" CA  PRO A  85 "
   model   vdw sym.op.
   4.312 3.700 x,y-1,z
nonbonded pdb=" C   PRO A  25 "
          pdb=" CG  TYR A  26 "
   model   vdw
   4.313 3.490
nonbonded pdb=" CG  TYR A  61 "
          pdb=" C   VAL A  84 "
   model   vdw
   4.313 3.490
nonbonded pdb=" NH1 ARG A  16 "
          pdb=" CB  PRO A  85 "
   model   vdw sym.op.
   4.314 3.520 x,y-1,z
nonbonded pdb=" CA  THR A  48 "
          pdb=" O   LEU A  49 "
   model   vdw
   4.315 3.470
nonbonded pdb=" CG  PHE A  13 "
          pdb=" CD1 LEU A  49 "
   model   vdw
   4.315 3.680
nonbonded pdb=" CB  CYS A  33 "
          pdb=" CA  TYR A  34 "
   model   vdw
   4.315 3.870
nonbonded pdb=" CA  HIS A  64 "
          pdb=" N   SER A  66 "
   model   vdw
   4.315 3.550
nonbonded pdb=" CE  LYS A   7 "
          pdb=" OE1 GLU A  40 "
   model   vdw sym.op.
   4.315 3.440 -x+1,y,-z+1
nonbonded pdb=" O   ILE A   6 "
          pdb=" CD  PRO A   8 "
   model   vdw
   4.316 3.440
nonbonded pdb=" O   GLN A  10 "
          pdb=" C   GLN A  12 "
   model   vdw
   4.317 3.270
nonbonded pdb=" CA  ALA A  55 "
          pdb=" C   TYR A  56 "
   model   vdw
   4.317 3.700
nonbonded pdb=" C   LEU A  44 "
          pdb=" CD2 LEU A  44 "
   model   vdw
   4.318 3.690
nonbonded pdb=" CD  LYS A  69 "
          pdb=" CG  ASP A  79 "
   model   vdw
   4.318 3.670
nonbonded pdb=" CB  PHE A  68 "
          pdb=" CG  LEU A  76 "
   model   vdw
   4.318 3.870
nonbonded pdb=" O   GLU A  40 "
          pdb=" CE1 TYR A  41 "
   model   vdw
   4.318 3.340
nonbonded pdb=" N   LEU A  49 "
          pdb=" CD1 LEU A  49 "
   model   vdw
   4.319 3.540
nonbonded pdb=" O   SER A  17 "
          pdb=" CE1 TYR A  26 "
   model   vdw
   4.319 3.340
nonbonded pdb=" O   VAL A  35 "
          pdb=" CG  LEU A  37 "
   model   vdw
   4.319 3.470
nonbonded pdb=" O   GLY A  18 "
          pdb=" CB  TYR A  26 "
   model   vdw
   4.320 3.440
nonbonded pdb=" C   GLN A  12 "
          pdb="O    HOH S   7 "
   model   vdw
   4.320 3.270
nonbonded pdb=" CZ  ARG A  21 "
          pdb=" ND1 HIS A  64 "
   model   vdw sym.op.
   4.321 3.350 x,y-1,z
nonbonded pdb=" CA  TYR A  41 "
          pdb=" CG  PRO A  42 "
   model   vdw
   4.321 3.870
nonbonded pdb=" C   PHE A  13 "
          pdb=" N   THR A  15 "
   model   vdw
   4.321 3.350
nonbonded pdb=" CG1 VAL A  63 "
          pdb=" O   ARG A  82 "
   model   vdw
   4.321 3.460
nonbonded pdb=" C   ASP A  50 "
          pdb=" OD1 ASP A  50 "
   model   vdw
   4.322 3.270
nonbonded pdb=" CD1 ILE A   6 "
          pdb=" CB  TYR A  56 "
   model   vdw
   4.323 3.860
nonbonded pdb=" CB  ASP A  79 "
          pdb=" CA  ARG A  80 "
   model   vdw
   4.323 3.870
nonbonded pdb=" NE  ARG A  82 "
          pdb=" CG  LYS A  24 "
   model   vdw sym.op.
   4.323 3.520 -x+1/2,y+1/2,-z+2
nonbonded pdb=" CG  LYS A  24 "
          pdb=" NE  ARG A  82 "
   model   vdw sym.op.
   4.323 3.520 -x+1/2,y-1/2,-z+2
nonbonded pdb=" CG  ARG A  80 "
          pdb=" NH1 ARG A  80 "
   model   vdw
   4.324 3.520
nonbonded pdb=" N   ARG A  21 "
          pdb="O    HOH S  81 "
   model   vdw
   4.324 3.120
nonbonded pdb=" ND1 HIS A  64 "
          pdb=" CA  LEU A  65 "
   model   vdw
   4.324 3.550
nonbonded pdb=" O   SER A  67 "
          pdb=" N   LYS A  69 "
   model   vdw
   4.325 3.120
nonbonded pdb=" CG  TYR A  34 "
          pdb=" O   VAL A  43 "
   model   vdw
   4.325 3.260
nonbonded pdb=" CE1 TYR A  56 "
          pdb=" CG  LEU A  83 "
   model   vdw
   4.325 3.770
nonbonded pdb=" O   LYS A  46 "
          pdb=" N   SER A  75 "
   model   vdw sym.op.
   4.325 3.120 -x+1,y,-z+2
nonbonded pdb=" CA  LEU A  49 "
          pdb=" C   ASP A  50 "
   model   vdw
   4.325 3.700
nonbonded pdb=" CB  GLN A  12 "
          pdb=" CA  PHE A  13 "
   model   vdw
   4.326 3.870
nonbonded pdb=" OG  SER A  75 "
          pdb=" O   LEU A  76 "
   model   vdw
   4.326 3.040
nonbonded pdb=" CG  ARG A  16 "
          pdb=" NH1 ARG A  16 "
   model   vdw
   4.326 3.520
nonbonded pdb=" C   ILE A   2 "
          pdb=" CD1 ILE A   2 "
   model   vdw
   4.326 3.690
nonbonded pdb=" CD  LYS A   7 "
          pdb=" N   PRO A   8 "
   model   vdw
   4.326 3.520
nonbonded pdb=" CG  GLN A  22 "
          pdb=" OE1 GLU A  51 "
   model   vdw sym.op.
   4.326 3.440 -x+1/2,y-1/2,-z+2
nonbonded pdb=" C   GLN A  12 "
          pdb=" CB  ALA A  55 "
   model   vdw
   4.326 3.690
nonbonded pdb=" O   GLU A  51 "
          pdb=" CD  GLU A  51 "
   model   vdw
   4.326 3.270
nonbonded pdb=" O   THR A  48 "
          pdb=" OG1 THR A  48 "
   model   vdw
   4.326 3.040
nonbonded pdb=" N   VAL A  19 "
          pdb=" CZ  TYR A  26 "
   model   vdw
   4.327 3.340
nonbonded pdb=" C   THR A  14 "
          pdb=" O   LEU A  28 "
   model   vdw
   4.327 3.270
nonbonded pdb=" CD1 ILE A  78 "
          pdb=" C   MSE A  77 "
   model   vdw sym.op.
   4.327 3.690 -x+1,y,-z+2
nonbonded pdb=" C   MSE A  77 "
          pdb=" CD1 ILE A  78 "
   model   vdw sym.op.
   4.327 3.690 -x+1,y,-z+2
nonbonded pdb=" CD  PRO A   8 "
          pdb=" OE2 GLU A  40 "
   model   vdw sym.op.
   4.328 3.440 -x+1,y,-z+1
nonbonded pdb=" CD1 ILE A  78 "
          pdb=" CA  MSE A  77 "
   model   vdw sym.op.
   4.328 3.890 -x+1,y,-z+2
nonbonded pdb=" CA  MSE A  77 "
          pdb=" CD1 ILE A  78 "
   model   vdw sym.op.
   4.328 3.890 -x+1,y,-z+2
nonbonded pdb=" C   ASP A  50 "
          pdb=" N   GLN A  53 "
   model   vdw
   4.328 3.350
nonbonded pdb=" C   GLY A  23 "
          pdb=" CD  PRO A  25 "
   model   vdw
   4.328 3.670
nonbonded pdb=" O   GLY A  18 "
          pdb=" O   LYS A  24 "
   model   vdw
   4.329 3.040
nonbonded pdb=" NE2 GLN A  10 "
          pdb=" CA  LEU A  32 "
   model   vdw
   4.329 3.550
nonbonded pdb=" C   ILE A   6 "
          pdb=" CG  LYS A   7 "
   model   vdw
   4.329 3.670
nonbonded pdb=" C   PHE A  13 "
          pdb=" CE1 PHE A  13 "
   model   vdw
   4.329 3.570
nonbonded pdb=" CD1 LEU A  32 "
          pdb=" N   LYS A  46 "
   model   vdw
   4.330 3.540
nonbonded pdb=" C   PRO A  42 "
          pdb=" N   LEU A  44 "
   model   vdw
   4.330 3.350
nonbonded pdb=" O   VAL A  35 "
          pdb=" O   ASP A  36 "
   model   vdw
   4.331 3.040
nonbonded pdb=" N   PHE A  68 "
          pdb=" CE2 PHE A  68 "
   model   vdw
   4.332 3.420
nonbonded pdb=" CA  SER A  20 "
          pdb=" C   ARG A  21 "
   model   vdw
   4.332 3.700
nonbonded pdb=" CG  GLN A  10 "
          pdb=" C   LEU A  32 "
   model   vdw
   4.332 3.670
nonbonded pdb=" C   VAL A  70 "
          pdb=" N   GLN A  72 "
   model   vdw
   4.332 3.350
nonbonded pdb=" CA  GLN A  53 "
          pdb=" C   PRO A  54 "
   model   vdw
   4.333 3.700
nonbonded pdb=" CA  VAL A  84 "
          pdb="O    HOH S  81 "
   model   vdw sym.op.
   4.333 3.470 x,y+1,z
nonbonded pdb=" CG  GLN A  53 "
          pdb=" N   PRO A  54 "
   model   vdw
   4.333 3.520
nonbonded pdb=" N   GLY A  38 "
          pdb="O    HOH S 123 "
   model   vdw
   4.333 3.120
nonbonded pdb=" O   LYS A  69 "
          pdb=" CB  LEU A  76 "
   model   vdw
   4.334 3.440
nonbonded pdb=" C   LEU A  65 "
          pdb=" CA  SER A  67 "
   model   vdw
   4.334 3.700
nonbonded pdb=" O   LEU A  65 "
          pdb=" CG  PHE A  68 "
   model   vdw
   4.334 3.260
nonbonded pdb=" N   SER A  67 "
          pdb=" O   ARG A  80 "
   model   vdw
   4.334 3.120
nonbonded pdb=" CA  GLY A  59 "
          pdb=" CE1 TYR A  61 "
   model   vdw
   4.334 3.740
nonbonded pdb=" CG  LYS A  46 "
          pdb=" CA  ILE A  47 "
   model   vdw
   4.334 3.870
nonbonded pdb=" CZ  TYR A  26 "
          pdb=" CD  PRO A  85 "
   model   vdw sym.op.
   4.335 3.660 x,y-1,z
nonbonded pdb=" O   SER A  67 "
          pdb=" O   MSE A  77 "
   model   vdw
   4.335 3.040
nonbonded pdb=" CG2 VAL A  45 "
          pdb=" N   LYS A  46 "
   model   vdw
   4.335 3.540
nonbonded pdb=" C   THR A  15 "
          pdb=" CG  ARG A  16 "
   model   vdw
   4.336 3.670
nonbonded pdb=" OH  TYR A  26 "
          pdb=" OH  TYR A  61 "
   model   vdw sym.op.
   4.336 3.040 x,y-1,z
nonbonded pdb=" C   LYS A   3 "
          pdb=" N   GLU A   5 "
   model   vdw
   4.336 3.350
nonbonded pdb=" CD2 TYR A  61 "
          pdb=" CA  VAL A  84 "
   model   vdw
   4.336 3.770
nonbonded pdb=" NZ  LYS A  24 "
          pdb="O    HOH S 135 "
   model   vdw sym.op.
   4.337 3.120 -x+1/2,y-1/2,-z+2
nonbonded pdb="O    HOH S 135 "
          pdb=" NZ  LYS A  24 "
   model   vdw sym.op.
   4.337 3.120 -x+1/2,y+1/2,-z+2
nonbonded pdb=" C   LEU A  37 "
          pdb=" CD2 LEU A  37 "
   model   vdw
   4.337 3.690
nonbonded pdb=" CD1 PHE A  13 "
          pdb=" CA  ASN A  29 "
   model   vdw
   4.337 3.770
nonbonded pdb=" CD  GLN A  31 "
          pdb=" C   ALA A  55 "
   model   vdw
   4.338 3.500
nonbonded pdb=" CG1 VAL A  45 "
          pdb=" CD2 LEU A  81 "
   model   vdw
   4.338 3.880
nonbonded pdb=" CZ  TYR A  41 "
          pdb=" CG  TYR A  34 "
   model   vdw sym.op.
   4.338 3.480 -x+1,y,-z+1
nonbonded pdb=" CG  TYR A  34 "
          pdb=" CZ  TYR A  41 "
   model   vdw sym.op.
   4.338 3.480 -x+1,y,-z+1
nonbonded pdb=" CG  LYS A  24 "
          pdb="O    HOH S  97 "
   model   vdw
   4.338 3.440
nonbonded pdb=" CZ  PHE A  13 "
          pdb="O    HOH S  44 "
   model   vdw
   4.338 3.340
nonbonded pdb=" CD2 TYR A  34 "
          pdb=" CD1 LEU A  44 "
   model   vdw
   4.339 3.760
nonbonded pdb=" CB  PRO A   8 "
          pdb=" CB  THR A  15 "
   model   vdw sym.op.
   4.339 3.870 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CD  GLN A  31 "
          pdb=" CD2 TYR A  56 "
   model   vdw
   4.339 3.570
nonbonded pdb=" CA  GLN A  10 "
          pdb=" OE1 GLN A  10 "
   model   vdw
   4.339 3.470
nonbonded pdb=" CG2 THR A  14 "
          pdb=" CG  PRO A  58 "
   model   vdw sym.op.
   4.339 3.860 -x+1/2,y-1/2,-z+1
nonbonded pdb="O    HOH S  97 "
          pdb=" CZ  ARG A  80 "
   model   vdw sym.op.
   4.339 3.270 -x+1/2,y-1/2,-z+2
nonbonded pdb=" CZ  ARG A  80 "
          pdb="O    HOH S  97 "
   model   vdw sym.op.
   4.339 3.270 -x+1/2,y+1/2,-z+2
nonbonded pdb=" O   ARG A  21 "
          pdb=" CG  GLN A  22 "
   model   vdw
   4.339 3.440
nonbonded pdb=" CD2 LEU A  49 "
          pdb=" O   PRO A  54 "
   model   vdw
   4.339 3.460
nonbonded pdb=" O   GLU A   5 "
          pdb=" CD1 ILE A   6 "
   model   vdw
   4.339 3.460
nonbonded pdb=" CZ  TYR A  26 "
          pdb=" CB  PRO A  85 "
   model   vdw sym.op.
   4.340 3.660 x,y-1,z
nonbonded pdb=" CA  PRO A  54 "
          pdb=" C   ALA A  55 "
   model   vdw
   4.340 3.700
nonbonded pdb=" CD1 LEU A  32 "
          pdb=" CG  LYS A  46 "
   model   vdw
   4.340 3.860
nonbonded pdb=" NE  ARG A  21 "
          pdb=" NE2 HIS A  64 "
   model   vdw sym.op.
   4.341 3.200 x,y-1,z
nonbonded pdb=" N   PHE A  13 "
          pdb=" CB  ALA A  55 "
   model   vdw
   4.341 3.540
nonbonded pdb=" CE  LYS A   3 "
          pdb=" CE1 PHE A  73 "
   model   vdw sym.op.
   4.341 3.740 -x+1,y+1,-z+2
nonbonded pdb=" C   PRO A   8 "
          pdb=" O   SER A   9 "
   model   vdw
   4.341 3.270
nonbonded pdb=" N   LYS A  69 "
          pdb=" CD1 LEU A  76 "
   model   vdw
   4.342 3.540
nonbonded pdb=" CB  TYR A  61 "
          pdb=" N   VAL A  84 "
   model   vdw
   4.343 3.520
nonbonded pdb=" C   ASN A  39 "
          pdb=" ND2 ASN A  39 "
   model   vdw
   4.343 3.350
nonbonded pdb=" N   LEU A  76 "
          pdb=" CD1 LEU A  76 "
   model   vdw
   4.343 3.540
nonbonded pdb=" CG  LYS A   7 "
          pdb=" N   PRO A   8 "
   model   vdw
   4.343 3.520
nonbonded pdb=" O   ARG A  21 "
          pdb=" O   GLN A  22 "
   model   vdw
   4.343 3.040
nonbonded pdb=" CG2 ILE A  78 "
          pdb=" CA  ARG A  80 "
   model   vdw
   4.343 3.890
nonbonded pdb=" CB  LEU A  60 "
          pdb=" CD1 PHE A  73 "
   model   vdw sym.op.
   4.344 3.740 -x+1,y+1,-z+2
nonbonded pdb=" O   VAL A  19 "
          pdb=" CD2 TYR A  26 "
   model   vdw
   4.344 3.340
nonbonded pdb=" N   SER A  27 "
          pdb=" NE2 GLN A  22 "
   model   vdw sym.op.
   4.344 3.200 -x+1/2,y+1/2,-z+2
nonbonded pdb=" NE2 GLN A  22 "
          pdb=" N   SER A  27 "
   model   vdw sym.op.
   4.344 3.200 -x+1/2,y-1/2,-z+2
nonbonded pdb=" O   ARG A  80 "
          pdb=" CZ  ARG A  82 "
   model   vdw
   4.344 3.270
nonbonded pdb=" CB  VAL A  63 "
          pdb=" CD1 LEU A  81 "
   model   vdw
   4.344 3.890
nonbonded pdb=" N   CYS A  33 "
          pdb=" CD1 LEU A  44 "
   model   vdw
   4.344 3.540
nonbonded pdb=" CE  LYS A   3 "
          pdb=" CD1 PHE A  73 "
   model   vdw sym.op.
   4.345 3.740 -x+1,y+1,-z+2
nonbonded pdb=" O   HIS A  64 "
          pdb=" ND1 HIS A  64 "
   model   vdw
   4.345 3.120
nonbonded pdb=" CG2 VAL A  35 "
          pdb=" CG1 VAL A  45 "
   model   vdw
   4.347 3.880
nonbonded pdb=" OG  SER A  20 "
          pdb=" CA  GLY A  23 "
   model   vdw
   4.347 3.440
nonbonded pdb=" CA  LYS A  69 "
          pdb=" CE  LYS A  69 "
   model   vdw
   4.347 3.870
nonbonded pdb=" O   VAL A  19 "
          pdb="O    HOH S  98 "
   model   vdw sym.op.
   4.347 3.040 x,y-1,z
nonbonded pdb=" O   SER A  67 "
          pdb=" OG  SER A  67 "
   model   vdw
   4.347 3.040
nonbonded pdb=" CA  ALA A  11 "
          pdb=" O   TYR A  56 "
   model   vdw
   4.348 3.470
nonbonded pdb=" CA  THR A  15 "
          pdb=" C   LEU A  28 "
   model   vdw
   4.348 3.700
nonbonded pdb=" C   LEU A  60 "
          pdb=" CE1 TYR A  61 "
   model   vdw
   4.348 3.570
nonbonded pdb=" O   CYS A  33 "
          pdb=" CD1 TYR A  34 "
   model   vdw
   4.349 3.340
nonbonded pdb=" C   VAL A  19 "
          pdb=" N   ARG A  21 "
   model   vdw
   4.350 3.350
nonbonded pdb=" C   GLN A  10 "
          pdb=" O   ALA A  11 "
   model   vdw
   4.350 3.270
nonbonded pdb=" CA  TYR A  61 "
          pdb=" C   VAL A  84 "
   model   vdw
   4.350 3.700
nonbonded pdb=" C   PRO A  42 "
          pdb=" CG1 VAL A  43 "
   model   vdw
   4.350 3.690
nonbonded pdb=" N   SER A  20 "
          pdb=" CE2 TYR A  26 "
   model   vdw
   4.351 3.420
nonbonded pdb=" O   GLN A  10 "
          pdb=" CA  GLN A  12 "
   model   vdw
   4.351 3.470
nonbonded pdb=" CA  ASP A  36 "
          pdb=" N   GLY A  38 "
   model   vdw
   4.351 3.550
nonbonded pdb=" OG1 THR A  62 "
          pdb=" CZ  PHE A  73 "
   model   vdw sym.op.
   4.352 3.340 -x+1,y+1,-z+2
nonbonded pdb=" CD  GLN A  72 "
          pdb="O    HOH S   2 "
   model   vdw sym.op.
   4.352 3.270 -x+1,y-1,-z+2
nonbonded pdb=" C   GLN A  31 "
          pdb=" N   CYS A  33 "
   model   vdw
   4.352 3.350
nonbonded pdb=" O   GLN A  31 "
          pdb=" CD1 ILE A  47 "
   model   vdw
   4.352 3.460
nonbonded pdb=" CA  ARG A  80 "
          pdb=" C   LEU A  81 "
   model   vdw
   4.353 3.700
nonbonded pdb=" N   GLU A  40 "
          pdb=" O   TYR A  41 "
   model   vdw
   4.353 3.120
nonbonded pdb=" O   THR A  48 "
          pdb=" NH1 ARG A  80 "
   model   vdw
   4.353 3.120
nonbonded pdb=" CA  VAL A  84 "
          pdb=" CG  PRO A  85 "
   model   vdw
   4.353 3.870
nonbonded pdb=" C   LYS A   7 "
          pdb="O    HOH S  51 "
   model   vdw
   4.353 3.270
nonbonded pdb=" O   GLN A  31 "
          pdb=" CB  LYS A  46 "
   model   vdw
   4.353 3.440
nonbonded pdb=" CB  MSE A  77 "
          pdb=" CA  ILE A  78 "
   model   vdw
   4.353 3.870
nonbonded pdb=" CZ  PHE A  73 "
          pdb="O    HOH S  54 "
   model   vdw sym.op.
   4.354 3.340 -x+1,y-1,-z+2
nonbonded pdb=" C   THR A  14 "
          pdb=" O   GLU A  30 "
   model   vdw
   4.354 3.270
nonbonded pdb=" N   PRO A   8 "
          pdb=" N   GLN A  10 "
   model   vdw
   4.355 3.200
nonbonded pdb=" O   LYS A  69 "
          pdb=" O   VAL A  70 "
   model   vdw
   4.355 3.040
nonbonded pdb=" CG  PRO A  42 "
          pdb=" N   VAL A  43 "
   model   vdw
   4.355 3.520
nonbonded pdb=" CB  ILE A   6 "
          pdb=" C   ALA A  57 "
   model   vdw
   4.356 3.700
nonbonded pdb=" C   SER A  20 "
          pdb=" O   LYS A  24 "
   model   vdw
   4.356 3.270
nonbonded pdb=" O   PHE A  13 "
          pdb=" O   THR A  14 "
   model   vdw
   4.356 3.040
nonbonded pdb=" C   GLY A  59 "
          pdb=" CD2 LEU A  60 "
   model   vdw
   4.356 3.690
nonbonded pdb=" CG  LYS A   7 "
          pdb=" CB  GLU A  40 "
   model   vdw sym.op.
   4.356 3.840 -x+1,y,-z+1
nonbonded pdb=" C   ASP A  50 "
          pdb=" CG  GLU A  51 "
   model   vdw
   4.357 3.670
nonbonded pdb=" CG2 THR A  48 "
          pdb=" CD  ARG A  80 "
   model   vdw
   4.357 3.860
nonbonded pdb=" CG1 VAL A  19 "
          pdb=" CA  SER A  20 "
   model   vdw
   4.357 3.890
nonbonded pdb=" CE1 TYR A  41 "
          pdb=" CD1 TYR A  41 "
   model   vdw sym.op.
   4.358 3.640 -x+1,y,-z+1
nonbonded pdb=" CD1 TYR A  41 "
          pdb=" CE1 TYR A  41 "
   model   vdw sym.op.
   4.358 3.640 -x+1,y,-z+1
nonbonded pdb=" CA  ARG A  16 "
          pdb=" NE  ARG A  16 "
   model   vdw
   4.359 3.550
nonbonded pdb=" O   GLY A  38 "
          pdb=" ND2 ASN A  39 "
   model   vdw
   4.360 3.120
nonbonded pdb=" CD1 TYR A  56 "
          pdb="O    HOH S  14 "
   model   vdw
   4.360 3.340
nonbonded pdb=" C   ASN A  29 "
          pdb=" N   GLN A  31 "
   model   vdw
   4.360 3.350
nonbonded pdb=" C   GLY A  18 "
          pdb=" N   SER A  20 "
   model   vdw
   4.360 3.350
nonbonded pdb=" N   LYS A  46 "
          pdb=" CA  SER A  75 "
   model   vdw sym.op.
   4.361 3.550 -x+1,y,-z+2
nonbonded pdb=" OG  SER A  17 "
          pdb=" O   GLY A  18 "
   model   vdw
   4.361 3.040
nonbonded pdb=" CB  ILE A  47 "
          pdb=" CB  LEU A  81 "
   model   vdw
   4.361 3.870
nonbonded pdb=" CA  TYR A  41 "
          pdb=" C   PRO A  42 "
   model   vdw
   4.361 3.700
nonbonded pdb=" N   LEU A  65 "
          pdb=" N   SER A  67 "
   model   vdw
   4.361 3.200
nonbonded pdb=" CG  GLN A  72 "
          pdb=" N   PHE A  73 "
   model   vdw
   4.362 3.520
nonbonded pdb=" CB  SER A  66 "
          pdb=" CD  ARG A  82 "
   model   vdw
   4.362 3.840
nonbonded pdb=" O   SER A  75 "
          pdb="SE    SE Z   3 "
   model   vdw sym.op.
   4.363 3.420 -x+1/2,y+3/2,-z+1
nonbonded pdb=" O   VAL A   4 "
          pdb=" CD1 TYR A  61 "
   model   vdw
   4.363 3.340
nonbonded pdb=" N   GLU A  30 "
          pdb="O    HOH S   8 "
   model   vdw
   4.363 3.120
nonbonded pdb=" CG1 ILE A   2 "
          pdb=" CG2 VAL A   4 "
   model   vdw
   4.364 3.860
nonbonded pdb=" O   THR A  14 "
          pdb=" C   LEU A  28 "
   model   vdw
   4.365 3.270
nonbonded pdb=" CG  LYS A  46 "
          pdb=" C   ILE A  47 "
   model   vdw
   4.366 3.670
nonbonded pdb=" O   ASP A  79 "
          pdb="O    HOH S 160 "
   model   vdw
   4.366 3.040
nonbonded pdb=" C   GLU A   5 "
          pdb=" CB  CYS A  33 "
   model   vdw
   4.367 3.670
nonbonded pdb=" C   LYS A  69 "
          pdb=" CD  LYS A  69 "
   model   vdw
   4.367 3.670
nonbonded pdb=" CA  ASN A  39 "
          pdb=" N   TYR A  41 "
   model   vdw
   4.367 3.550
nonbonded pdb=" OE1 GLN A  31 "
          pdb=" CE2 TYR A  56 "
   model   vdw
   4.367 3.340
nonbonded pdb=" O   ALA A  11 "
          pdb=" NE2 GLN A  31 "
   model   vdw
   4.367 3.120
nonbonded pdb=" OD2 ASP A  36 "
          pdb="O    HOH S   2 "
   model   vdw
   4.367 3.040
nonbonded pdb=" CG2 VAL A   4 "
          pdb=" CG1 VAL A  35 "
   model   vdw
   4.368 3.880
nonbonded pdb=" CE1 TYR A  26 "
          pdb=" CB  PRO A  85 "
   model   vdw sym.op.
   4.368 3.740 x,y-1,z
nonbonded pdb=" CB  LYS A  69 "
          pdb=" NZ  LYS A  69 "
   model   vdw
   4.368 3.520
nonbonded pdb=" CG  LYS A  69 "
          pdb=" CA  ASP A  79 "
   model   vdw
   4.368 3.870
nonbonded pdb=" CB  LYS A  69 "
          pdb=" CA  VAL A  70 "
   model   vdw
   4.369 3.870
nonbonded pdb=" CB  VAL A  43 "
          pdb=" CG2 VAL A  70 "
   model   vdw sym.op.
   4.369 3.890 -x+1,y,-z+2
nonbonded pdb=" CB  PHE A  13 "
          pdb=" CB  ALA A  55 "
   model   vdw
   4.369 3.860
nonbonded pdb=" C   SER A  20 "
          pdb="O    HOH S  81 "
   model   vdw
   4.369 3.270
nonbonded pdb=" OG  SER A  27 "
          pdb=" CA  LEU A  28 "
   model   vdw
   4.369 3.470
nonbonded pdb=" OH  TYR A  41 "
          pdb=" CD1 TYR A  34 "
   model   vdw sym.op.
   4.370 3.340 -x+1,y,-z+1
nonbonded pdb=" CD1 TYR A  34 "
          pdb=" OH  TYR A  41 "
   model   vdw sym.op.
   4.370 3.340 -x+1,y,-z+1
nonbonded pdb=" CG1 VAL A  63 "
          pdb=" CA  HIS A  64 "
   model   vdw
   4.370 3.890
nonbonded pdb=" C   GLN A  12 "
          pdb="O    HOH S 110 "
   model   vdw
   4.370 3.270
nonbonded pdb=" CD  LYS A   3 "
          pdb=" CB  ASP A  36 "
   model   vdw
   4.370 3.840
nonbonded pdb=" CD  PRO A  85 "
          pdb="O    HOH S  81 "
   model   vdw sym.op.
   4.371 3.440 x,y+1,z
nonbonded pdb=" O   THR A  14 "
          pdb=" N   ASN A  29 "
   model   vdw
   4.371 3.120
nonbonded pdb=" CG2 THR A  48 "
          pdb=" C   LEU A  49 "
   model   vdw
   4.371 3.690
nonbonded pdb=" O   LEU A  37 "
          pdb=" CG  ASN A  39 "
   model   vdw
   4.371 3.270
nonbonded pdb=" CA  ALA A  57 "
          pdb=" CG  PRO A  58 "
   model   vdw
   4.372 3.870
nonbonded pdb=" N   THR A  15 "
          pdb=" CA  SER A   9 "
   model   vdw sym.op.
   4.372 3.550 -x+1/2,y-1/2,-z+1
nonbonded pdb=" CA  SER A   9 "
          pdb=" N   THR A  15 "
   model   vdw sym.op.
   4.372 3.550 -x+1/2,y+1/2,-z+1
nonbonded pdb=" O   PHE A  13 "
          pdb=" N   THR A  15 "
   model   vdw
   4.372 3.120
nonbonded pdb=" O   THR A  15 "
          pdb=" OG1 THR A  15 "
   model   vdw
   4.372 3.040
nonbonded pdb=" CA  GLY A  74 "
          pdb="O    HOH S  25 "
   model   vdw
   4.373 3.440
nonbonded pdb=" CA  GLN A  53 "
          pdb=" CG  PRO A  54 "
   model   vdw
   4.373 3.870
nonbonded pdb=" O   GLN A  12 "
          pdb=" O   GLU A  30 "
   model   vdw
   4.373 3.040
nonbonded pdb=" C   HIS A  64 "
          pdb=" CA  SER A  66 "
   model   vdw
   4.373 3.700
nonbonded pdb=" CD  ARG A  82 "
          pdb="O    HOH S 135 "
   model   vdw
   4.374 3.440
nonbonded pdb=" OH  TYR A  56 "
          pdb=" C   LEU A  83 "
   model   vdw
   4.375 3.270
nonbonded pdb=" CD2 LEU A  49 "
          pdb=" CZ  TYR A  56 "
   model   vdw
   4.375 3.680
nonbonded pdb=" CD2 TYR A  61 "
          pdb=" C   PRO A  85 "
   model   vdw
   4.375 3.570
nonbonded pdb=" C   VAL A   4 "
          pdb=" N   ILE A   6 "
   model   vdw
   4.376 3.350
nonbonded pdb=" CA  SER A  67 "
          pdb=" CD2 PHE A  68 "
   model   vdw
   4.376 3.770
nonbonded pdb=" N   VAL A  35 "
          pdb=" CB  PRO A  42 "
   model   vdw
   4.376 3.520
nonbonded pdb=" CA  ILE A   6 "
          pdb=" N   GLY A  59 "
   model   vdw
   4.377 3.550
nonbonded pdb=" CG  ARG A  16 "
          pdb=" CD  GLU A  30 "
   model   vdw
   4.377 3.670
nonbonded pdb=" C   HIS A  64 "
          pdb=" O   ARG A  82 "
   model   vdw
   4.377 3.270
nonbonded pdb=" CZ  TYR A  61 "
          pdb="O    HOH S  85 "
   model   vdw sym.op.
   4.378 3.260 x,y+1,z
nonbonded pdb=" C   LEU A  83 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   4.378 3.690
nonbonded pdb=" CA  LYS A   7 "
          pdb=" C   PRO A   8 "
   model   vdw
   4.378 3.700
nonbonded pdb=" N   ARG A  82 "
          pdb=" CD  ARG A  82 "
   model   vdw
   4.379 3.520
nonbonded pdb=" O   LEU A  28 "
          pdb="O    HOH S   8 "
   model   vdw
   4.379 3.040
nonbonded pdb=" C   GLY A  71 "
          pdb=" O   SER A  75 "
   model   vdw
   4.379 3.270
nonbonded pdb=" C   LEU A  60 "
          pdb=" CD2 TYR A  61 "
   model   vdw
   4.380 3.570
nonbonded pdb=" CB  SER A  66 "
          pdb=" CZ  ARG A  21 "
   model   vdw sym.op.
   4.380 3.670 x,y+1,z
nonbonded pdb=" CZ  ARG A  21 "
          pdb=" CB  SER A  66 "
   model   vdw sym.op.
   4.380 3.670 x,y-1,z
nonbonded pdb=" CD  GLU A   5 "
          pdb=" O   GLY A  59 "
   model   vdw
   4.380 3.270
nonbonded pdb=" CE1 TYR A  26 "
          pdb=" CG  LEU A  28 "
   model   vdw
   4.380 3.770
nonbonded pdb=" O   ALA A  57 "
          pdb=" CA  GLY A  59 "
   model   vdw
   4.380 3.440
nonbonded pdb=" OE2 GLU A  30 "
          pdb=" OG1 THR A  48 "
   model   vdw
   4.381 3.040
nonbonded pdb=" CA  LYS A   7 "
          pdb=" CG  PRO A   8 "
   model   vdw
   4.382 3.870
nonbonded pdb=" CB  MSE A  77 "
          pdb="O    HOH S 103 "
   model   vdw sym.op.
   4.382 3.440 -x,y+1,-z+1
nonbonded pdb=" N   LEU A  60 "
          pdb=" CE1 TYR A  61 "
   model   vdw
   4.382 3.420
nonbonded pdb=" CD1 LEU A  60 "
          pdb=" CD1 PHE A  73 "
   model   vdw sym.op.
   4.382 3.760 -x+1,y+1,-z+2
nonbonded pdb=" CA  GLN A  10 "
          pdb=" N   GLN A  12 "
   model   vdw
   4.382 3.550
nonbonded pdb=" N   SER A  67 "
          pdb=" CD2 PHE A  68 "
   model   vdw
   4.384 3.420
nonbonded pdb=" OG  SER A  17 "
          pdb=" CA  SER A  27 "
   model   vdw
   4.384 3.470
nonbonded pdb=" N   LEU A  32 "
          pdb="O    HOH S 151 "
   model   vdw
   4.384 3.120
nonbonded pdb=" CG  TYR A  61 "
          pdb=" N   THR A  62 "
   model   vdw
   4.384 3.340
nonbonded pdb=" CA  ALA A  57 "
          pdb=" C   PRO A  58 "
   model   vdw
   4.384 3.700
nonbonded pdb=" CA  ASN A  39 "
          pdb=" C   GLU A  40 "
   model   vdw
   4.384 3.700
nonbonded pdb=" C   ARG A  21 "
          pdb=" O   GLN A  22 "
   model   vdw
   4.384 3.270
nonbonded pdb=" CA  LEU A  37 "
          pdb=" CD1 LEU A  65 "
   model   vdw sym.op.
   4.385 3.890 -x+1,y,-z+2
nonbonded pdb=" CA  GLU A  51 "
          pdb=" N   GLN A  53 "
   model   vdw
   4.385 3.550
nonbonded pdb=" N   ILE A  47 "
          pdb=" CD1 ILE A  47 "
   model   vdw
   4.385 3.540
nonbonded pdb=" O   PHE A  68 "
          pdb=" CG  LYS A  69 "
   model   vdw
   4.385 3.440
nonbonded pdb=" CA  TYR A  56 "
          pdb=" C   ALA A  57 "
   model   vdw
   4.386 3.700
nonbonded pdb=" CG1 VAL A  19 "
          pdb=" CD  PRO A  54 "
   model   vdw sym.op.
   4.387 3.860 x,y-1,z
nonbonded pdb=" CD  PRO A  54 "
          pdb=" CG1 VAL A  19 "
   model   vdw sym.op.
   4.387 3.860 x,y+1,z
nonbonded pdb=" CB  PRO A  54 "
          pdb=" CA  ALA A  55 "
   model   vdw
   4.387 3.870
nonbonded pdb=" CB  SER A  17 "
          pdb=" CA  GLY A  18 "
   model   vdw
   4.387 3.840
nonbonded pdb=" O   CYS A  33 "
          pdb=" N   LEU A  44 "
   model   vdw
   4.388 3.120
nonbonded pdb=" CG  LEU A  32 "
          pdb=" N   CYS A  33 "
   model   vdw
   4.388 3.550
nonbonded pdb=" O   PRO A   8 "
          pdb=" CA  ALA A  11 "
   model   vdw
   4.388 3.470
nonbonded pdb=" C   LYS A  46 "
          pdb=" N   THR A  48 "
   model   vdw
   4.388 3.350
nonbonded pdb=" O   LYS A   7 "
          pdb=" OE1 GLN A  10 "
   model   vdw
   4.388 3.040
nonbonded pdb=" CD1 TYR A  26 "
          pdb=" CG  PRO A  85 "
   model   vdw sym.op.
   4.388 3.740 x,y-1,z
nonbonded pdb=" O   TYR A  56 "
          pdb=" CD  PRO A  58 "
   model   vdw
   4.388 3.440
nonbonded pdb=" N   GLY A  71 "
          pdb="O    HOH S 103 "
   model   vdw sym.op.
   4.388 3.120 -x,y+1,-z+1
nonbonded pdb=" CG  HIS A  64 "
          pdb=" CA  LEU A  65 "
   model   vdw
   4.389 3.690
nonbonded pdb=" CA  SER A  20 "
          pdb=" N   GLN A  22 "
   model   vdw
   4.389 3.550
nonbonded pdb=" C   PRO A   8 "
          pdb=" CA  THR A  14 "
   model   vdw sym.op.
   4.389 3.700 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CB  LYS A  46 "
          pdb=" NZ  LYS A  46 "
   model   vdw
   4.390 3.520
nonbonded pdb=" CB  SER A  66 "
          pdb=" CD  ARG A  21 "
   model   vdw sym.op.
   4.390 3.840 x,y+1,z
nonbonded pdb=" CD  ARG A  21 "
          pdb=" CB  SER A  66 "
   model   vdw sym.op.
   4.390 3.840 x,y-1,z
nonbonded pdb=" CA  THR A  14 "
          pdb="O    HOH S   8 "
   model   vdw
   4.390 3.470
nonbonded pdb=" C   SER A  67 "
          pdb=" CD1 PHE A  68 "
   model   vdw
   4.390 3.570
nonbonded pdb=" N   THR A  62 "
          pdb=" N   VAL A  84 "
   model   vdw
   4.390 3.200
nonbonded pdb=" C   VAL A  19 "
          pdb="O    HOH S  81 "
   model   vdw
   4.390 3.270
nonbonded pdb=" C   LYS A   7 "
          pdb=" CG  PRO A  58 "
   model   vdw
   4.390 3.670
nonbonded pdb=" C   LEU A  76 "
          pdb=" CD2 LEU A  76 "
   model   vdw
   4.391 3.690
nonbonded pdb=" CG  GLN A  53 "
          pdb=" CD  PRO A  54 "
   model   vdw
   4.391 3.840
nonbonded pdb=" CG  PRO A   8 "
          pdb=" CZ  PHE A  13 "
   model   vdw sym.op.
   4.391 3.740 -x+1/2,y+1/2,-z+1
nonbonded pdb=" O   LEU A  37 "
          pdb="O    HOH S   3 "
   model   vdw
   4.392 3.040
nonbonded pdb=" CA  THR A  14 "
          pdb="O    HOH S 151 "
   model   vdw
   4.393 3.470
nonbonded pdb=" CG1 VAL A   4 "
          pdb=" CA  GLU A   5 "
   model   vdw
   4.393 3.890
nonbonded pdb=" CD1 PHE A  13 "
          pdb=" CA  THR A  14 "
   model   vdw
   4.393 3.770
nonbonded pdb=" CA  GLY A  38 "
          pdb="O    HOH S   3 "
   model   vdw
   4.393 3.440
nonbonded pdb=" CG  LEU A  76 "
          pdb=" CD1 ILE A  78 "
   model   vdw sym.op.
   4.394 3.890 -x+1,y,-z+2
nonbonded pdb=" O   ILE A   6 "
          pdb=" CG1 ILE A   6 "
   model   vdw
   4.394 3.440
nonbonded pdb=" CB  THR A  48 "
          pdb=" CD  ARG A  80 "
   model   vdw
   4.394 3.870
nonbonded pdb=" CA  ILE A  78 "
          pdb=" C   ASP A  79 "
   model   vdw
   4.394 3.700
nonbonded pdb=" O   ILE A   6 "
          pdb=" C   GLY A  59 "
   model   vdw
   4.394 3.270
nonbonded pdb=" O   GLY A  23 "
          pdb=" CG  PRO A  25 "
   model   vdw
   4.395 3.440
nonbonded pdb=" C   TYR A  61 "
          pdb=" CE1 PHE A  73 "
   model   vdw sym.op.
   4.396 3.570 -x+1,y+1,-z+2
nonbonded pdb=" O   THR A  14 "
          pdb=" CG  GLU A  30 "
   model   vdw
   4.396 3.440
nonbonded pdb=" CB  CYS A  33 "
          pdb=" O   VAL A  45 "
   model   vdw
   4.396 3.440
nonbonded pdb=" N   ALA A  57 "
          pdb=" CZ  TYR A  61 "
   model   vdw
   4.396 3.340
nonbonded pdb=" CA  LEU A  28 "
          pdb=" OD1 ASN A  29 "
   model   vdw
   4.397 3.470
nonbonded pdb=" CD  GLN A  31 "
          pdb=" CB  TYR A  56 "
   model   vdw
   4.397 3.670
nonbonded pdb=" OD1 ASN A  29 "
          pdb="O    HOH S  33 "
   model   vdw
   4.397 3.040
nonbonded pdb=" CB  TYR A  26 "
          pdb=" CA  SER A  27 "
   model   vdw
   4.397 3.870
nonbonded pdb=" CD2 TYR A  56 "
          pdb=" CG  LEU A  83 "
   model   vdw
   4.397 3.770
nonbonded pdb=" O   ASN A  29 "
          pdb=" N   GLN A  31 "
   model   vdw
   4.397 3.120
nonbonded pdb=" CG1 VAL A   4 "
          pdb=" O   GLU A   5 "
   model   vdw
   4.398 3.460
nonbonded pdb=" C   SER A  67 "
          pdb=" N   LYS A  69 "
   model   vdw
   4.398 3.350
nonbonded pdb=" CA  ALA A  57 "
          pdb=" O   PRO A  58 "
   model   vdw
   4.398 3.470
nonbonded pdb=" C   GLU A   5 "
          pdb=" CD  GLU A   5 "
   model   vdw
   4.398 3.500
nonbonded pdb=" CG2 VAL A   4 "
          pdb=" CD2 LEU A  81 "
   model   vdw
   4.398 3.880
nonbonded pdb="SE    SE Z   1 "
          pdb=" N   MSE A  77 "
   model   vdw sym.op.
   4.399 3.500 -x,y-1,-z+1
nonbonded pdb=" N   MSE A  77 "
          pdb="SE    SE Z   1 "
   model   vdw sym.op.
   4.399 3.500 -x,y+1,-z+1
nonbonded pdb=" C   ILE A  47 "
          pdb=" CD1 ILE A  47 "
   model   vdw
   4.399 3.690
nonbonded pdb=" CG  LYS A   7 "
          pdb=" CD  GLN A  10 "
   model   vdw
   4.399 3.670
nonbonded pdb=" CD1 TYR A  61 "
          pdb=" CD1 LEU A  83 "
   model   vdw
   4.399 3.760
nonbonded pdb=" CA  VAL A  19 "
          pdb=" O   SER A  20 "
   model   vdw
   4.400 3.470
nonbonded pdb=" CB  SER A  75 "
          pdb=" O   LEU A  76 "
   model   vdw
   4.400 3.440
nonbonded pdb=" CD  LYS A  69 "
          pdb=" CA  ASP A  79 "
   model   vdw
   4.401 3.870
nonbonded pdb=" O   ASP A  50 "
          pdb=" C   GLY A  52 "
   model   vdw
   4.402 3.270
nonbonded pdb=" O   SER A  20 "
          pdb=" O   LYS A  24 "
   model   vdw
   4.402 3.040
nonbonded pdb=" CG  PHE A  13 "
          pdb=" CG  ASN A  29 "
   model   vdw
   4.402 3.490
nonbonded pdb=" CG  LYS A  24 "
          pdb=" C   PRO A  25 "
   model   vdw
   4.403 3.670
nonbonded pdb=" C   THR A  48 "
          pdb="O    HOH S 106 "
   model   vdw
   4.404 3.270
nonbonded pdb=" CD  ARG A  16 "
          pdb=" OE1 GLU A  30 "
   model   vdw
   4.404 3.440
nonbonded pdb=" CD2 PHE A  13 "
          pdb=" CA  ALA A  55 "
   model   vdw
   4.405 3.770
nonbonded pdb=" OG  SER A  17 "
          pdb=" CA  GLY A  18 "
   model   vdw
   4.405 3.440
nonbonded pdb=" CD1 LEU A  37 "
          pdb=" C   PHE A  68 "
   model   vdw sym.op.
   4.405 3.690 -x+1,y,-z+2
nonbonded pdb=" CD  GLN A  12 "
          pdb=" CB  PRO A  58 "
   model   vdw sym.op.
   4.405 3.670 -x+1/2,y-1/2,-z+1
nonbonded pdb=" CB  ASP A  50 "
          pdb=" CA  GLU A  51 "
   model   vdw
   4.406 3.870
nonbonded pdb=" N   GLU A   5 "
          pdb=" N   TYR A  34 "
   model   vdw
   4.406 3.200
nonbonded pdb=" CD1 ILE A   6 "
          pdb=" CD1 LEU A  83 "
   model   vdw
   4.407 3.880
nonbonded pdb=" C   PHE A  13 "
          pdb="O    HOH S 151 "
   model   vdw
   4.407 3.270
nonbonded pdb=" CG1 VAL A  35 "
          pdb=" CD2 LEU A  76 "
   model   vdw sym.op.
   4.407 3.880 -x+1,y,-z+2
nonbonded pdb=" CD1 TYR A  56 "
          pdb=" OH  TYR A  61 "
   model   vdw
   4.407 3.340
nonbonded pdb=" N   TYR A  61 "
          pdb=" CE1 TYR A  61 "
   model   vdw
   4.408 3.420
nonbonded pdb=" NE2 GLN A  10 "
          pdb=" N   TYR A  34 "
   model   vdw
   4.409 3.200
nonbonded pdb=" CA  THR A  48 "
          pdb=" C   LEU A  49 "
   model   vdw
   4.409 3.700
nonbonded pdb=" CA  ASP A  50 "
          pdb=" C   GLU A  51 "
   model   vdw
   4.409 3.700
nonbonded pdb=" C   LEU A  44 "
          pdb=" N   LYS A  46 "
   model   vdw
   4.409 3.350
nonbonded pdb=" SG  CYS A  33 "
          pdb=" C   VAL A  45 "
   model   vdw
   4.409 3.630
nonbonded pdb=" C   SER A  66 "
          pdb=" CD  ARG A  82 "
   model   vdw
   4.410 3.670
nonbonded pdb=" CB  LEU A  32 "
          pdb=" CA  CYS A  33 "
   model   vdw
   4.410 3.870
nonbonded pdb=" N   GLU A  30 "
          pdb=" CD  GLU A  30 "
   model   vdw
   4.410 3.350
nonbonded pdb=" CG1 ILE A   2 "
          pdb=" O   LYS A   3 "
   model   vdw
   4.410 3.440
nonbonded pdb=" CD  LYS A  46 "
          pdb=" N   ILE A  47 "
   model   vdw
   4.411 3.520
nonbonded pdb=" CB  VAL A   4 "
          pdb=" C   TYR A  61 "
   model   vdw
   4.411 3.700
nonbonded pdb=" NE  ARG A  16 "
          pdb=" OE2 GLU A  30 "
   model   vdw
   4.411 3.120
nonbonded pdb=" O   ILE A   2 "
          pdb=" O   LYS A   3 "
   model   vdw
   4.412 3.040
nonbonded pdb=" CA  LYS A   7 "
          pdb=" CD  GLN A  10 "
   model   vdw
   4.412 3.700
nonbonded pdb=" CG1 VAL A  35 "
          pdb=" CA  ASP A  36 "
   model   vdw
   4.412 3.890
nonbonded pdb=" C   GLU A   5 "
          pdb=" CD1 ILE A   6 "
   model   vdw
   4.412 3.690
nonbonded pdb=" CD1 TYR A  34 "
          pdb=" N   VAL A  43 "
   model   vdw
   4.412 3.420
nonbonded pdb=" N   LEU A  44 "
          pdb=" CD1 LEU A  44 "
   model   vdw
   4.412 3.540
nonbonded pdb=" CG  ARG A  82 "
          pdb=" NH2 ARG A  82 "
   model   vdw
   4.412 3.520
nonbonded pdb=" C   LYS A   7 "
          pdb=" CB  GLN A  10 "
   model   vdw
   4.413 3.670
nonbonded pdb=" N   LYS A   7 "
          pdb=" CE  LYS A   7 "
   model   vdw
   4.413 3.520
nonbonded pdb=" C   GLN A  12 "
          pdb=" CD2 PHE A  13 "
   model   vdw
   4.414 3.570
nonbonded pdb=" CB  ARG A  21 "
          pdb=" NH2 ARG A  21 "
   model   vdw
   4.415 3.520
nonbonded pdb=" CB  LEU A  60 "
          pdb="O    HOH S  54 "
   model   vdw
   4.415 3.440
nonbonded pdb=" CD  LYS A   7 "
          pdb=" CB  GLU A  40 "
   model   vdw sym.op.
   4.415 3.840 -x+1,y,-z+1
nonbonded pdb=" N   LEU A  83 "
          pdb=" CD1 LEU A  83 "
   model   vdw
   4.416 3.540
nonbonded pdb=" CG1 VAL A  35 "
          pdb=" CG  LEU A  37 "
   model   vdw
   4.416 3.890
nonbonded pdb=" CB  ILE A  47 "
          pdb="O    HOH S  10 "
   model   vdw
   4.416 3.470
nonbonded pdb=" CB  LYS A   7 "
          pdb=" CA  PRO A   8 "
   model   vdw
   4.416 3.870
nonbonded pdb=" CA  LEU A  65 "
          pdb=" CD2 PHE A  68 "
   model   vdw
   4.417 3.770
nonbonded pdb=" CB  LEU A  49 "
          pdb=" CA  ASP A  50 "
   model   vdw
   4.417 3.870
nonbonded pdb=" CG1 VAL A  45 "
          pdb=" CA  SER A  75 "
   model   vdw sym.op.
   4.417 3.890 -x+1,y,-z+2
nonbonded pdb=" C   ASN A  29 "
          pdb=" CG  LEU A  49 "
   model   vdw
   4.417 3.700
nonbonded pdb=" CB  VAL A  45 "
          pdb="O    HOH S  10 "
   model   vdw
   4.417 3.470
nonbonded pdb=" CG2 ILE A  47 "
          pdb=" O   LEU A  81 "
   model   vdw
   4.417 3.460
nonbonded pdb=" N   PRO A   8 "
          pdb=" OE2 GLU A  40 "
   model   vdw sym.op.
   4.417 3.120 -x+1,y,-z+1
nonbonded pdb=" O   ARG A  16 "
          pdb=" CD1 TYR A  26 "
   model   vdw
   4.418 3.340
nonbonded pdb=" CA  PHE A  13 "
          pdb="O    HOH S 151 "
   model   vdw
   4.418 3.470
nonbonded pdb=" CB  PHE A  13 "
          pdb=" O   THR A  14 "
   model   vdw
   4.418 3.440
nonbonded pdb=" CA  ARG A  80 "
          pdb=" NH1 ARG A  82 "
   model   vdw
   4.419 3.550
nonbonded pdb=" C   VAL A  19 "
          pdb=" OG  SER A  20 "
   model   vdw
   4.419 3.270
nonbonded pdb=" O   LEU A  28 "
          pdb=" O   ASN A  29 "
   model   vdw
   4.419 3.040
nonbonded pdb=" CG2 THR A  15 "
          pdb=" CB  SER A  27 "
   model   vdw
   4.420 3.860
nonbonded pdb=" O   LYS A  46 "
          pdb="O    HOH S 106 "
   model   vdw
   4.420 3.040
nonbonded pdb=" C   GLY A  74 "
          pdb="O    HOH S   4 "
   model   vdw
   4.421 3.270
nonbonded pdb=" C   PHE A  13 "
          pdb="O    HOH S 110 "
   model   vdw
   4.421 3.270
nonbonded pdb=" CA  ASP A  50 "
          pdb=" O   GLU A  51 "
   model   vdw
   4.421 3.470
nonbonded pdb=" OE1 GLN A  12 "
          pdb=" CG  PRO A  58 "
   model   vdw sym.op.
   4.422 3.440 -x+1/2,y-1/2,-z+1
nonbonded pdb=" CB  THR A  48 "
          pdb="O    HOH S 106 "
   model   vdw
   4.422 3.470
nonbonded pdb=" CA  PHE A  73 "
          pdb=" N   SER A  75 "
   model   vdw
   4.423 3.550
nonbonded pdb=" CE2 PHE A  13 "
          pdb=" N   ALA A  55 "
   model   vdw
   4.423 3.420
nonbonded pdb=" CA  MSE A  77 "
          pdb="SE    SE Z   4 "
   model   vdw sym.op.
   4.423 3.850 x+1/2,y+3/2,z+2
nonbonded pdb=" N   VAL A   4 "
          pdb=" O   TYR A  34 "
   model   vdw
   4.424 3.120
nonbonded pdb=" CG2 ILE A  78 "
          pdb=" CA  ASP A  79 "
   model   vdw
   4.424 3.890
nonbonded pdb=" O   ASN A  39 "
          pdb="O    HOH S   3 "
   model   vdw
   4.425 3.040
nonbonded pdb=" CB  PHE A  68 "
          pdb=" CD2 LEU A  76 "
   model   vdw
   4.425 3.860
nonbonded pdb=" CG  ASP A  50 "
          pdb=" N   GLU A  51 "
   model   vdw
   4.425 3.350
nonbonded pdb=" O   ASN A  29 "
          pdb=" C   LEU A  49 "
   model   vdw
   4.425 3.270
nonbonded pdb=" O   VAL A   4 "
          pdb=" CB  LEU A  60 "
   model   vdw
   4.425 3.440
nonbonded pdb=" CE1 TYR A  34 "
          pdb=" N   LEU A  44 "
   model   vdw
   4.426 3.420
nonbonded pdb=" N   ASP A  50 "
          pdb=" NH1 ARG A  80 "
   model   vdw
   4.426 3.200
nonbonded pdb=" CB  PRO A  58 "
          pdb="O    HOH S  51 "
   model   vdw
   4.426 3.440
nonbonded pdb=" CA  GLY A  18 "
          pdb=" CG  TYR A  26 "
   model   vdw
   4.427 3.660
nonbonded pdb=" CB  ASN A  29 "
          pdb=" CG  LEU A  49 "
   model   vdw
   4.427 3.870
nonbonded pdb=" CE  LYS A   7 "
          pdb=" OH  TYR A  41 "
   model   vdw sym.op.
   4.427 3.440 -x+1,y,-z+1
nonbonded pdb=" CB  VAL A   4 "
          pdb=" CG2 VAL A  35 "
   model   vdw
   4.427 3.890
nonbonded pdb=" C   TYR A  26 "
          pdb=" N   LEU A  28 "
   model   vdw
   4.428 3.350
nonbonded pdb=" CD  GLU A  30 "
          pdb=" CG  LYS A  46 "
   model   vdw
   4.428 3.670
nonbonded pdb=" CB  VAL A  19 "
          pdb=" O   SER A  20 "
   model   vdw
   4.429 3.470
nonbonded pdb=" CA  SER A  17 "
          pdb="O    HOH S  85 "
   model   vdw
   4.429 3.470
nonbonded pdb=" CB  GLN A  31 "
          pdb=" O   LEU A  32 "
   model   vdw
   4.429 3.440
nonbonded pdb=" C   SER A  67 "
          pdb=" CB  ASP A  79 "
   model   vdw
   4.429 3.670
nonbonded pdb=" O   ARG A  82 "
          pdb=" CG  ARG A  82 "
   model   vdw
   4.429 3.440
nonbonded pdb=" CE2 TYR A  61 "
          pdb=" C   VAL A  84 "
   model   vdw
   4.430 3.570
nonbonded pdb=" CB  GLN A  12 "
          pdb=" O   PHE A  13 "
   model   vdw
   4.430 3.440
nonbonded pdb=" CZ  PHE A  13 "
          pdb=" CG  ASN A  29 "
   model   vdw
   4.430 3.570
nonbonded pdb=" CA  GLY A  18 "
          pdb=" CD1 TYR A  26 "
   model   vdw
   4.430 3.740
nonbonded pdb=" CB  PHE A  68 "
          pdb=" CA  LYS A  69 "
   model   vdw
   4.430 3.870
nonbonded pdb=" CB  GLN A  31 "
          pdb=" O   ILE A  47 "
   model   vdw
   4.432 3.440
nonbonded pdb=" C   HIS A  64 "
          pdb=" CB  SER A  67 "
   model   vdw
   4.432 3.670
nonbonded pdb=" CG  TYR A  56 "
          pdb=" CZ  TYR A  61 "
   model   vdw
   4.432 3.480
nonbonded pdb=" C   GLN A  31 "
          pdb="O    HOH S 151 "
   model   vdw
   4.432 3.270
nonbonded pdb=" OE1 GLN A  72 "
          pdb=" CB  LYS A   3 "
   model   vdw sym.op.
   4.433 3.440 -x+1,y-1,-z+2
nonbonded pdb=" CB  LYS A   3 "
          pdb=" OE1 GLN A  72 "
   model   vdw sym.op.
   4.433 3.440 -x+1,y+1,-z+2
nonbonded pdb=" CG1 VAL A  19 "
          pdb=" C   SER A  20 "
   model   vdw
   4.433 3.690
nonbonded pdb="O    HOH S  97 "
          pdb=" CD  ARG A  80 "
   model   vdw sym.op.
   4.433 3.440 -x+1/2,y-1/2,-z+2
nonbonded pdb=" CD  ARG A  80 "
          pdb="O    HOH S  97 "
   model   vdw sym.op.
   4.433 3.440 -x+1/2,y+1/2,-z+2
nonbonded pdb=" O   ARG A  21 "
          pdb=" CA  GLY A  23 "
   model   vdw
   4.433 3.440
nonbonded pdb=" CD1 TYR A  26 "
          pdb=" C   SER A  27 "
   model   vdw
   4.435 3.570
nonbonded pdb=" N   PRO A  54 "
          pdb="O    HOH S  98 "
   model   vdw
   4.435 3.120
nonbonded pdb=" CE  LYS A  69 "
          pdb=" N   VAL A  70 "
   model   vdw
   4.435 3.520
nonbonded pdb=" C   SER A  20 "
          pdb="O    HOH S 120 "
   model   vdw
   4.436 3.270
nonbonded pdb=" CA  LYS A  24 "
          pdb=" O   PRO A  25 "
   model   vdw
   4.436 3.470
nonbonded pdb=" CA  LEU A  37 "
          pdb=" N   ASN A  39 "
   model   vdw
   4.437 3.550
nonbonded pdb=" C   GLN A  22 "
          pdb=" OE1 GLN A  22 "
   model   vdw
   4.437 3.270
nonbonded pdb=" O   GLN A  12 "
          pdb="O    HOH S 151 "
   model   vdw
   4.437 3.040
nonbonded pdb=" CA  SER A  17 "
          pdb=" CE1 TYR A  26 "
   model   vdw
   4.437 3.770
nonbonded pdb=" CA  LYS A  24 "
          pdb=" C   PRO A  25 "
   model   vdw
   4.438 3.700
nonbonded pdb=" CB  TYR A  41 "
          pdb=" CA  PRO A  42 "
   model   vdw
   4.438 3.870
nonbonded pdb=" CG  LEU A  81 "
          pdb="O    HOH S  10 "
   model   vdw
   4.438 3.470
nonbonded pdb=" O   VAL A  70 "
          pdb="O    HOH S  16 "
   model   vdw
   4.438 3.040
nonbonded pdb=" CA  ILE A   6 "
          pdb=" C   LYS A   7 "
   model   vdw
   4.438 3.700
nonbonded pdb=" OG1 THR A  62 "
          pdb="SE    SE Z   5 "
   model   vdw sym.op.
   4.439 3.420 x+1/2,y+3/2,z+1
nonbonded pdb=" CG  PRO A   8 "
          pdb="O    HOH S  51 "
   model   vdw
   4.439 3.440
nonbonded pdb="SE    SE Z   4 "
          pdb="O    HOH S 160 "
   model   vdw sym.op.
   4.440 3.420 x-1/2,y-3/2,z-2
nonbonded pdb=" C   GLU A  40 "
          pdb=" OE1 GLU A  40 "
   model   vdw
   4.440 3.270
nonbonded pdb=" CG1 VAL A  84 "
          pdb=" C   PRO A  85 "
   model   vdw
   4.441 3.690
nonbonded pdb=" CG  ARG A  82 "
          pdb="O    HOH S 135 "
   model   vdw
   4.441 3.440
nonbonded pdb=" CB  LYS A  24 "
          pdb=" CA  PRO A  25 "
   model   vdw
   4.441 3.870
nonbonded pdb=" C   LYS A  24 "
          pdb=" CD  LYS A  24 "
   model   vdw
   4.441 3.670
nonbonded pdb=" C   GLY A  71 "
          pdb=" CA  PHE A  73 "
   model   vdw
   4.442 3.700
nonbonded pdb=" C   GLN A  12 "
          pdb=" N   THR A  14 "
   model   vdw
   4.442 3.350
nonbonded pdb=" CG  GLN A  31 "
          pdb=" CA  LEU A  32 "
   model   vdw
   4.442 3.870
nonbonded pdb=" C   SER A  67 "
          pdb=" N   ARG A  80 "
   model   vdw
   4.442 3.350
nonbonded pdb=" OE1 GLN A  10 "
          pdb=" CB  CYS A  33 "
   model   vdw
   4.443 3.440
nonbonded pdb=" CA  SER A  17 "
          pdb=" CA  SER A  27 "
   model   vdw
   4.443 3.900
nonbonded pdb=" CB  PHE A  13 "
          pdb=" CA  THR A  14 "
   model   vdw
   4.443 3.870
nonbonded pdb=" CG  GLN A  31 "
          pdb=" C   LEU A  32 "
   model   vdw
   4.444 3.670
nonbonded pdb=" O   PRO A   8 "
          pdb=" OG1 THR A  15 "
   model   vdw sym.op.
   4.444 3.040 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CE2 TYR A  61 "
          pdb="O    HOH S  85 "
   model   vdw sym.op.
   4.444 3.340 x,y+1,z
nonbonded pdb=" CB  PRO A   8 "
          pdb="O    HOH S 110 "
   model   vdw sym.op.
   4.444 3.440 -x+1/2,y+1/2,-z+1
nonbonded pdb=" O   ALA A  55 "
          pdb="O    HOH S  14 "
   model   vdw
   4.444 3.040
nonbonded pdb=" O   ARG A  16 "
          pdb=" CD  ARG A  16 "
   model   vdw
   4.445 3.440
nonbonded pdb=" CA  PHE A  68 "
          pdb=" N   ASP A  79 "
   model   vdw
   4.445 3.550
nonbonded pdb=" CB  ARG A  21 "
          pdb=" CG  GLN A  22 "
   model   vdw
   4.445 3.840
nonbonded pdb=" CD  LYS A  24 "
          pdb=" O   PRO A  25 "
   model   vdw
   4.445 3.440
nonbonded pdb=" C   THR A  14 "
          pdb=" CA  ASN A  29 "
   model   vdw
   4.446 3.700
nonbonded pdb=" CG2 VAL A  63 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   4.446 3.880
nonbonded pdb=" C   ALA A  11 "
          pdb=" CB  ALA A  55 "
   model   vdw
   4.447 3.690
nonbonded pdb=" CB  TYR A  61 "
          pdb=" CG  LEU A  83 "
   model   vdw
   4.447 3.870
nonbonded pdb=" CG  PHE A  68 "
          pdb=" CD2 LEU A  76 "
   model   vdw
   4.447 3.680
nonbonded pdb=" CB  LYS A  46 "
          pdb=" C   GLY A  74 "
   model   vdw sym.op.
   4.447 3.670 -x+1,y,-z+2
nonbonded pdb=" OE1 GLN A  31 "
          pdb=" CG  LEU A  49 "
   model   vdw
   4.447 3.470
nonbonded pdb=" CD1 ILE A  47 "
          pdb=" CG  LEU A  83 "
   model   vdw
   4.448 3.890
nonbonded pdb=" CB  PRO A  54 "
          pdb="O    HOH S 134 "
   model   vdw
   4.448 3.440
nonbonded pdb=" CB  TYR A  34 "
          pdb=" CG  PRO A  42 "
   model   vdw
   4.448 3.840
nonbonded pdb=" CA  VAL A   4 "
          pdb=" C   TYR A  34 "
   model   vdw
   4.448 3.700
nonbonded pdb=" N   GLY A  71 "
          pdb="SE    SE Z   1 "
   model   vdw sym.op.
   4.449 3.500 -x,y+1,-z+1
nonbonded pdb=" CB  SER A  20 "
          pdb=" CA  LYS A  24 "
   model   vdw
   4.449 3.870
nonbonded pdb=" CD2 PHE A  13 "
          pdb=" CD1 LEU A  49 "
   model   vdw
   4.449 3.760
nonbonded pdb=" CG  ARG A  80 "
          pdb=" NH2 ARG A  82 "
   model   vdw
   4.449 3.520
nonbonded pdb=" CG  LEU A  65 "
          pdb="O    HOH S   2 "
   model   vdw sym.op.
   4.450 3.470 -x+1,y,-z+2
nonbonded pdb=" CB  LYS A   7 "
          pdb=" N   GLN A  10 "
   model   vdw
   4.450 3.520
nonbonded pdb=" CE  LYS A  69 "
          pdb=" C   VAL A  70 "
   model   vdw
   4.450 3.670
nonbonded pdb=" OE1 GLN A  12 "
          pdb=" CA  PRO A  58 "
   model   vdw sym.op.
   4.451 3.470 -x+1/2,y-1/2,-z+1
nonbonded pdb=" CG2 ILE A   2 "
          pdb=" N   LYS A   3 "
   model   vdw
   4.451 3.540
nonbonded pdb=" CB  SER A  75 "
          pdb=" CA  LEU A  76 "
   model   vdw
   4.451 3.870
nonbonded pdb=" CA  GLN A  72 "
          pdb="O    HOH S   4 "
   model   vdw
   4.452 3.470
nonbonded pdb=" C   SER A  17 "
          pdb=" CD1 TYR A  26 "
   model   vdw
   4.452 3.570
nonbonded pdb=" N   ARG A  16 "
          pdb=" CD  ARG A  16 "
   model   vdw
   4.452 3.520
nonbonded pdb=" CA  PHE A  68 "
          pdb=" CA  ILE A  78 "
   model   vdw
   4.453 3.900
nonbonded pdb=" O   LYS A   3 "
          pdb=" N   GLU A   5 "
   model   vdw
   4.453 3.120
nonbonded pdb=" C   PRO A   8 "
          pdb=" C   THR A  14 "
   model   vdw sym.op.
   4.453 3.500 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CD1 TYR A  34 "
          pdb=" CB  LEU A  44 "
   model   vdw
   4.455 3.740
nonbonded pdb=" C   VAL A  35 "
          pdb=" CG1 VAL A  43 "
   model   vdw
   4.455 3.690
nonbonded pdb=" O   THR A  14 "
          pdb=" OD1 ASN A  29 "
   model   vdw
   4.455 3.040
nonbonded pdb=" CD1 ILE A   6 "
          pdb=" C   LEU A  32 "
   model   vdw
   4.456 3.690
nonbonded pdb=" CB  ALA A  57 "
          pdb=" CA  PRO A  58 "
   model   vdw
   4.456 3.890
nonbonded pdb=" NH2 ARG A  80 "
          pdb="O    HOH S 175 "
   model   vdw
   4.456 3.120
nonbonded pdb=" N   GLN A  31 "
          pdb=" CG1 ILE A  47 "
   model   vdw
   4.457 3.520
nonbonded pdb=" CG1 VAL A  84 "
          pdb=" CA  PRO A  85 "
   model   vdw
   4.457 3.890
nonbonded pdb=" C   ARG A  16 "
          pdb=" CD  ARG A  16 "
   model   vdw
   4.458 3.670
nonbonded pdb=" O   CYS A  33 "
          pdb=" CB  VAL A  45 "
   model   vdw
   4.460 3.470
nonbonded pdb=" C   SER A  20 "
          pdb=" CA  GLN A  22 "
   model   vdw
   4.460 3.700
nonbonded pdb=" CG  TYR A  61 "
          pdb=" CA  PRO A  85 "
   model   vdw
   4.462 3.690
nonbonded pdb=" NH2 ARG A  16 "
          pdb=" CB  PRO A  85 "
   model   vdw sym.op.
   4.462 3.520 x,y-1,z
nonbonded pdb=" OE1 GLN A  53 "
          pdb=" CE2 TYR A  56 "
   model   vdw
   4.463 3.340
nonbonded pdb=" CD  PRO A   8 "
          pdb=" OE1 GLU A  40 "
   model   vdw sym.op.
   4.463 3.440 -x+1,y,-z+1
nonbonded pdb=" OD1 ASP A  50 "
          pdb=" CZ  ARG A  80 "
   model   vdw
   4.463 3.270
nonbonded pdb=" OD1 ASP A  36 "
          pdb=" N   ASN A  39 "
   model   vdw
   4.463 3.120
nonbonded pdb=" CE2 TYR A  26 "
          pdb="O    HOH S  81 "
   model   vdw
   4.463 3.340
nonbonded pdb=" O   ARG A  16 "
          pdb=" CG  LEU A  28 "
   model   vdw
   4.464 3.470
nonbonded pdb=" N   ILE A  78 "
          pdb=" CD1 ILE A  78 "
   model   vdw
   4.464 3.540
nonbonded pdb=" O   GLN A  72 "
          pdb=" CD  GLN A  72 "
   model   vdw
   4.464 3.270
nonbonded pdb=" CG1 ILE A   2 "
          pdb=" C   LYS A   3 "
   model   vdw
   4.464 3.670
nonbonded pdb=" OH  TYR A  41 "
          pdb=" CD2 TYR A  34 "
   model   vdw sym.op.
   4.464 3.340 -x+1,y,-z+1
nonbonded pdb=" CD2 TYR A  34 "
          pdb=" OH  TYR A  41 "
   model   vdw sym.op.
   4.464 3.340 -x+1,y,-z+1
nonbonded pdb=" CD  GLU A  40 "
          pdb=" CB  SER A   9 "
   model   vdw sym.op.
   4.464 3.670 -x+1,y,-z+1
nonbonded pdb=" CB  SER A   9 "
          pdb=" CD  GLU A  40 "
   model   vdw sym.op.
   4.464 3.670 -x+1,y,-z+1
nonbonded pdb=" CD1 TYR A  41 "
          pdb=" CD  PRO A  42 "
   model   vdw
   4.465 3.740
nonbonded pdb=" CA  VAL A   4 "
          pdb=" CA  VAL A  35 "
   model   vdw
   4.465 3.900
nonbonded pdb=" O   LYS A   7 "
          pdb=" CA  PRO A  58 "
   model   vdw
   4.465 3.470
nonbonded pdb=" CA  SER A  75 "
          pdb=" C   LEU A  76 "
   model   vdw
   4.465 3.700
nonbonded pdb=" CD2 LEU A  76 "
          pdb=" CD2 LEU A  81 "
   model   vdw sym.op.
   4.466 3.880 -x+1,y,-z+2
nonbonded pdb=" CD2 TYR A  61 "
          pdb=" C   LEU A  83 "
   model   vdw
   4.466 3.570
nonbonded pdb=" CA  THR A  15 "
          pdb=" C   ARG A  16 "
   model   vdw
   4.467 3.700
nonbonded pdb=" CA  HIS A  64 "
          pdb=" NE2 HIS A  64 "
   model   vdw
   4.467 3.550
nonbonded pdb=" CB  THR A  62 "
          pdb=" CA  VAL A  63 "
   model   vdw
   4.468 3.900
nonbonded pdb=" C   ILE A   6 "
          pdb=" CB  PRO A  58 "
   model   vdw
   4.468 3.670
nonbonded pdb=" O   ALA A  57 "
          pdb=" CG  PRO A  58 "
   model   vdw
   4.468 3.440
nonbonded pdb=" CG  LYS A  24 "
          pdb=" CA  PRO A  25 "
   model   vdw
   4.468 3.870
nonbonded pdb=" CG2 THR A  15 "
          pdb=" N   SER A  17 "
   model   vdw
   4.469 3.540
nonbonded pdb=" CD1 LEU A  37 "
          pdb=" C   LYS A  69 "
   model   vdw sym.op.
   4.469 3.690 -x+1,y,-z+2
nonbonded pdb=" CD  LYS A   3 "
          pdb=" OD2 ASP A  36 "
   model   vdw
   4.469 3.440
nonbonded pdb=" C   LEU A  37 "
          pdb=" OD1 ASN A  39 "
   model   vdw
   4.469 3.270
nonbonded pdb=" C   TYR A  34 "
          pdb=" CB  PRO A  42 "
   model   vdw
   4.470 3.670
nonbonded pdb=" CB  THR A  15 "
          pdb="O    HOH S  34 "
   model   vdw
   4.470 3.470
nonbonded pdb=" CD1 LEU A  37 "
          pdb=" N   LYS A  69 "
   model   vdw sym.op.
   4.470 3.540 -x+1,y,-z+2
nonbonded pdb=" C   CYS A  33 "
          pdb=" O   VAL A  43 "
   model   vdw
   4.470 3.270
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" C   LYS A   7 "
   model   vdw
   4.470 3.690
nonbonded pdb=" O   LEU A  60 "
          pdb=" CE1 TYR A  61 "
   model   vdw
   4.470 3.340
nonbonded pdb=" C   ASN A  39 "
          pdb=" CA  TYR A  41 "
   model   vdw
   4.471 3.700
nonbonded pdb=" C   PRO A   8 "
          pdb="O    HOH S 117 "
   model   vdw sym.op.
   4.471 3.270 -x+1/2,y+1/2,-z+1
nonbonded pdb=" O   ASN A  29 "
          pdb=" CG  ASN A  29 "
   model   vdw
   4.472 3.270
nonbonded pdb=" CA  GLY A  52 "
          pdb=" C   GLN A  53 "
   model   vdw
   4.472 3.670
nonbonded pdb=" CB  LEU A  49 "
          pdb=" C   ASP A  50 "
   model   vdw
   4.472 3.670
nonbonded pdb=" CB  VAL A  70 "
          pdb=" O   GLY A  71 "
   model   vdw
   4.473 3.470
nonbonded pdb=" NE2 GLN A  72 "
          pdb=" CE  LYS A   3 "
   model   vdw sym.op.
   4.473 3.520 -x+1,y-1,-z+2
nonbonded pdb=" CE  LYS A   3 "
          pdb=" NE2 GLN A  72 "
   model   vdw sym.op.
   4.473 3.520 -x+1,y+1,-z+2
nonbonded pdb=" O   LEU A  44 "
          pdb=" N   LYS A  46 "
   model   vdw
   4.473 3.120
nonbonded pdb=" CA  HIS A  64 "
          pdb=" C   LEU A  65 "
   model   vdw
   4.474 3.700
nonbonded pdb=" CD1 PHE A  68 "
          pdb=" CG  LEU A  76 "
   model   vdw
   4.474 3.770
nonbonded pdb=" OE2 GLU A   5 "
          pdb=" CD2 LEU A  60 "
   model   vdw
   4.474 3.460
nonbonded pdb=" CD  LYS A   7 "
          pdb=" CG  GLU A  40 "
   model   vdw sym.op.
   4.474 3.840 -x+1,y,-z+1
nonbonded pdb=" N   GLY A  18 "
          pdb="O    HOH S  85 "
   model   vdw
   4.474 3.120
nonbonded pdb=" CA  PRO A   8 "
          pdb=" CA  THR A  14 "
   model   vdw sym.op.
   4.474 3.900 -x+1/2,y+1/2,-z+1
nonbonded pdb=" C   ASN A  29 "
          pdb="O    HOH S  33 "
   model   vdw
   4.474 3.270
nonbonded pdb=" O   ASP A  50 "
          pdb=" CA  GLY A  52 "
   model   vdw
   4.475 3.440
nonbonded pdb=" CG2 VAL A  45 "
          pdb=" C   SER A  75 "
   model   vdw sym.op.
   4.475 3.690 -x+1,y,-z+2
nonbonded pdb=" CB  PRO A   8 "
          pdb=" C   THR A  14 "
   model   vdw sym.op.
   4.475 3.670 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CB  THR A  14 "
          pdb=" O   GLU A  30 "
   model   vdw
   4.475 3.470
nonbonded pdb=" CA  VAL A  45 "
          pdb=" C   LYS A  46 "
   model   vdw
   4.475 3.700
nonbonded pdb=" CD  GLN A  31 "
          pdb=" CA  TYR A  56 "
   model   vdw
   4.476 3.700
nonbonded pdb=" O   GLY A  18 "
          pdb=" N   SER A  20 "
   model   vdw
   4.476 3.120
nonbonded pdb=" O   ASN A  39 "
          pdb=" CA  TYR A  41 "
   model   vdw
   4.476 3.470
nonbonded pdb=" O   ARG A  16 "
          pdb=" O   TYR A  26 "
   model   vdw
   4.476 3.040
nonbonded pdb=" CA  ARG A  16 "
          pdb="O    HOH S  85 "
   model   vdw
   4.476 3.470
nonbonded pdb=" CG1 ILE A   6 "
          pdb=" CB  CYS A  33 "
   model   vdw
   4.476 3.840
nonbonded pdb=" CG  TYR A  41 "
          pdb=" N   PRO A  42 "
   model   vdw
   4.476 3.340
nonbonded pdb=" CA  TYR A  61 "
          pdb=" O   THR A  62 "
   model   vdw
   4.476 3.470
nonbonded pdb=" CA  SER A  66 "
          pdb=" C   SER A  67 "
   model   vdw
   4.477 3.700
nonbonded pdb=" O   ALA A  11 "
          pdb="O    HOH S 134 "
   model   vdw
   4.477 3.040
nonbonded pdb=" O   GLY A  18 "
          pdb=" CZ  TYR A  26 "
   model   vdw
   4.477 3.260
nonbonded pdb=" CB  HIS A  64 "
          pdb=" CB  ARG A  82 "
   model   vdw
   4.477 3.840
nonbonded pdb=" C   ALA A  57 "
          pdb=" CE1 TYR A  61 "
   model   vdw
   4.477 3.570
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" OE1 GLN A  10 "
   model   vdw
   4.478 3.460
nonbonded pdb=" CB  LEU A  83 "
          pdb=" CA  VAL A  84 "
   model   vdw
   4.478 3.870
nonbonded pdb=" CA  GLU A  40 "
          pdb="O    HOH S 123 "
   model   vdw
   4.478 3.470
nonbonded pdb=" C   LEU A  28 "
          pdb=" CD2 LEU A  28 "
   model   vdw
   4.478 3.690
nonbonded pdb=" N   MSE A  77 "
          pdb=" CD1 ILE A  78 "
   model   vdw sym.op.
   4.479 3.540 -x+1,y,-z+2
nonbonded pdb=" C   GLY A  38 "
          pdb=" N   GLU A  40 "
   model   vdw
   4.480 3.350
nonbonded pdb=" CA  LYS A  69 "
          pdb=" C   VAL A  70 "
   model   vdw
   4.480 3.700
nonbonded pdb=" CA  ASN A  39 "
          pdb=" O   TYR A  41 "
   model   vdw
   4.480 3.470
nonbonded pdb=" O   ILE A  78 "
          pdb=" CG1 ILE A  78 "
   model   vdw
   4.480 3.440
nonbonded pdb=" O   GLY A  18 "
          pdb=" CD1 TYR A  26 "
   model   vdw
   4.480 3.340
nonbonded pdb=" N   LYS A  69 "
          pdb=" CD  LYS A  69 "
   model   vdw
   4.481 3.520
nonbonded pdb=" O   LEU A  60 "
          pdb=" O   PRO A  85 "
   model   vdw
   4.481 3.040
nonbonded pdb=" CB  ILE A   6 "
          pdb=" O   LYS A   7 "
   model   vdw
   4.481 3.470
nonbonded pdb=" CB  SER A  75 "
          pdb="SE    SE Z   3 "
   model   vdw sym.op.
   4.482 3.820 -x+1/2,y+3/2,-z+1
nonbonded pdb=" O   ILE A   6 "
          pdb=" N   PRO A  58 "
   model   vdw
   4.482 3.120
nonbonded pdb=" CA  TYR A  41 "
          pdb=" CE1 TYR A  41 "
   model   vdw
   4.483 3.770
nonbonded pdb=" CB  TYR A  34 "
          pdb=" CE2 TYR A  41 "
   model   vdw sym.op.
   4.483 3.740 -x+1,y,-z+1
nonbonded pdb=" CG1 ILE A   2 "
          pdb=" CA  LYS A   3 "
   model   vdw
   4.483 3.870
nonbonded pdb=" CA  PHE A  73 "
          pdb=" CE1 PHE A  73 "
   model   vdw
   4.483 3.770
nonbonded pdb=" O   ARG A  82 "
          pdb=" CG  LEU A  83 "
   model   vdw
   4.484 3.470
nonbonded pdb=" N   ASP A  36 "
          pdb="O    HOH S   2 "
   model   vdw
   4.484 3.120
nonbonded pdb=" CA  VAL A  45 "
          pdb="O    HOH S  17 "
   model   vdw
   4.485 3.470
nonbonded pdb=" CB  ASP A  36 "
          pdb=" CB  PRO A  42 "
   model   vdw
   4.486 3.840
nonbonded pdb=" CA  PHE A  68 "
          pdb=" C   MSE A  77 "
   model   vdw
   4.487 3.700
nonbonded pdb=" C   GLU A   5 "
          pdb=" OE1 GLN A  10 "
   model   vdw
   4.487 3.270
nonbonded pdb=" O   TYR A  34 "
          pdb=" CG  TYR A  34 "
   model   vdw
   4.488 3.260
nonbonded pdb=" O   LYS A  46 "
          pdb=" CD  LYS A  46 "
   model   vdw
   4.488 3.440
nonbonded pdb=" C   GLY A  52 "
          pdb=" CG  GLN A  53 "
   model   vdw
   4.488 3.670
nonbonded pdb=" O   ASP A  79 "
          pdb=" CD  ARG A  80 "
   model   vdw
   4.489 3.440
nonbonded pdb=" CA  GLY A  38 "
          pdb=" C   ASN A  39 "
   model   vdw
   4.489 3.670
nonbonded pdb=" CA  GLY A  38 "
          pdb="O    HOH S 123 "
   model   vdw
   4.489 3.440
nonbonded pdb=" N   ILE A  47 "
          pdb="O    HOH S  10 "
   model   vdw
   4.489 3.120
nonbonded pdb=" OG  SER A   9 "
          pdb=" CA  GLN A  10 "
   model   vdw
   4.489 3.470
nonbonded pdb=" CD1 ILE A  47 "
          pdb=" O   LEU A  81 "
   model   vdw
   4.489 3.460
nonbonded pdb=" CG  LYS A  24 "
          pdb=" NH1 ARG A  82 "
   model   vdw sym.op.
   4.489 3.520 -x+1/2,y-1/2,-z+2
nonbonded pdb=" C   GLN A  12 "
          pdb=" CG  GLN A  31 "
   model   vdw
   4.490 3.670
nonbonded pdb=" O   LEU A  28 "
          pdb=" CG  LEU A  28 "
   model   vdw
   4.490 3.470
nonbonded pdb=" C   LYS A   7 "
          pdb=" C   SER A   9 "
   model   vdw
   4.490 3.500
nonbonded pdb=" N   SER A  67 "
          pdb=" NH1 ARG A  82 "
   model   vdw
   4.490 3.200
nonbonded pdb=" N   LEU A  60 "
          pdb=" CD1 LEU A  60 "
   model   vdw
   4.490 3.540
nonbonded pdb=" CG  GLU A  40 "
          pdb=" N   TYR A  41 "
   model   vdw
   4.490 3.520
nonbonded pdb=" CA  GLU A   5 "
          pdb=" C   ILE A   6 "
   model   vdw
   4.490 3.700
nonbonded pdb=" CG  ARG A  80 "
          pdb=" N   LEU A  81 "
   model   vdw
   4.491 3.520
nonbonded pdb=" CD1 LEU A  49 "
          pdb=" CB  ALA A  55 "
   model   vdw
   4.491 3.880
nonbonded pdb=" CB  HIS A  64 "
          pdb=" CB  VAL A  84 "
   model   vdw
   4.492 3.870
nonbonded pdb=" CA  GLU A  51 "
          pdb="O    HOH S  33 "
   model   vdw
   4.492 3.470
nonbonded pdb=" CA  VAL A  84 "
          pdb=" O   PRO A  85 "
   model   vdw
   4.492 3.470
nonbonded pdb=" N   SER A   9 "
          pdb=" CA  THR A  15 "
   model   vdw sym.op.
   4.492 3.550 -x+1/2,y+1/2,-z+1
nonbonded pdb=" O   LYS A   7 "
          pdb=" CG  PRO A   8 "
   model   vdw
   4.492 3.440
nonbonded pdb=" C   ALA A  57 "
          pdb=" CZ  TYR A  61 "
   model   vdw
   4.493 3.490
nonbonded pdb=" CA  GLN A  31 "
          pdb=" CG1 ILE A  47 "
   model   vdw
   4.493 3.870
nonbonded pdb=" OE1 GLU A  51 "
          pdb=" CE1 HIS A  64 "
   model   vdw sym.op.
   4.493 3.260 -x+1/2,y-1/2,-z+2
nonbonded pdb=" CB  ILE A   6 "
          pdb=" N   PRO A  58 "
   model   vdw
   4.494 3.550
nonbonded pdb=" CG  ARG A  21 "
          pdb=" NH2 ARG A  21 "
   model   vdw
   4.494 3.520
nonbonded pdb=" CG2 VAL A   4 "
          pdb=" CB  VAL A  35 "
   model   vdw
   4.495 3.890
nonbonded pdb=" CA  LYS A   7 "
          pdb=" CG  GLN A  10 "
   model   vdw
   4.495 3.870
nonbonded pdb=" CG  PHE A  68 "
          pdb=" N   LYS A  69 "
   model   vdw
   4.495 3.340
nonbonded pdb=" NE2 GLN A  72 "
          pdb=" CD  LYS A   3 "
   model   vdw sym.op.
   4.496 3.520 -x+1,y-1,-z+2
nonbonded pdb=" CD  LYS A   3 "
          pdb=" NE2 GLN A  72 "
   model   vdw sym.op.
   4.496 3.520 -x+1,y+1,-z+2
nonbonded pdb=" C   ARG A  21 "
          pdb=" CA  GLY A  23 "
   model   vdw
   4.496 3.670
nonbonded pdb=" C   PRO A  58 "
          pdb="O    HOH S  51 "
   model   vdw
   4.497 3.270
nonbonded pdb=" CE1 TYR A  34 "
          pdb=" CA  LEU A  44 "
   model   vdw
   4.498 3.770
nonbonded pdb=" CD  GLN A  31 "
          pdb=" O   LEU A  32 "
   model   vdw
   4.498 3.270
nonbonded pdb=" N   GLN A  31 "
          pdb=" N   ILE A  47 "
   model   vdw
   4.498 3.200
nonbonded pdb=" CG  TYR A  34 "
          pdb=" CD1 LEU A  44 "
   model   vdw
   4.498 3.680
nonbonded pdb=" CB  GLU A  40 "
          pdb=" CA  TYR A  41 "
   model   vdw
   4.498 3.870
nonbonded pdb=" O   GLN A  22 "
          pdb=" OE1 GLN A  22 "
   model   vdw
   4.499 3.040
nonbonded pdb=" N   PHE A  13 "
          pdb=" CE2 PHE A  13 "
   model   vdw
   4.499 3.420
nonbonded pdb=" CA  GLY A  71 "
          pdb=" C   GLN A  72 "
   model   vdw
   4.499 3.670
nonbonded pdb=" CG1 ILE A   2 "
          pdb="O    HOH S   2 "
   model   vdw
   4.499 3.440
nonbonded pdb=" CA  VAL A  70 "
          pdb=" C   GLY A  71 "
   model   vdw
   4.499 3.700
nonbonded pdb=" O   VAL A   4 "
          pdb=" N   ILE A   6 "
   model   vdw
   4.499 3.120
nonbonded pdb=" C   PHE A  73 "
          pdb=" O   GLY A  74 "
   model   vdw
   4.500 3.270
nonbonded pdb=" N   SER A  20 "
          pdb=" CA  LYS A  24 "
   model   vdw
   4.500 3.550
nonbonded pdb=" CA  VAL A  35 "
          pdb=" C   ASP A  36 "
   model   vdw
   4.500 3.700
nonbonded pdb=" OG  SER A  66 "
          pdb=" NE  ARG A  82 "
   model   vdw
   4.501 3.120
nonbonded pdb=" CA  VAL A  63 "
          pdb=" O   HIS A  64 "
   model   vdw
   4.501 3.470
nonbonded pdb=" CB  ARG A  80 "
          pdb=" NE  ARG A  82 "
   model   vdw
   4.501 3.520
nonbonded pdb=" O   VAL A  35 "
          pdb=" CG2 VAL A  35 "
   model   vdw
   4.501 3.460
nonbonded pdb=" O   GLY A  38 "
          pdb=" CG  ASN A  39 "
   model   vdw
   4.501 3.270
nonbonded pdb=" CG  ASP A  79 "
          pdb=" CG  ARG A  80 "
   model   vdw
   4.502 3.670
nonbonded pdb=" CG1 VAL A   4 "
          pdb=" C   GLU A   5 "
   model   vdw
   4.502 3.690
nonbonded pdb=" O   GLY A  71 "
          pdb=" O   SER A  75 "
   model   vdw
   4.502 3.040
nonbonded pdb=" O   THR A  62 "
          pdb=" CG2 VAL A  63 "
   model   vdw
   4.502 3.460
nonbonded pdb=" C   ASN A  29 "
          pdb=" CB  LEU A  49 "
   model   vdw
   4.503 3.670
nonbonded pdb=" O   GLY A  59 "
          pdb=" O   LEU A  60 "
   model   vdw
   4.503 3.040
nonbonded pdb=" CB  TYR A  56 "
          pdb=" CA  ALA A  57 "
   model   vdw
   4.503 3.870
nonbonded pdb=" CA  SER A   9 "
          pdb=" N   ALA A  11 "
   model   vdw
   4.504 3.550
nonbonded pdb=" CB  TYR A  56 "
          pdb=" CE2 TYR A  61 "
   model   vdw
   4.504 3.740
nonbonded pdb=" CG2 VAL A  63 "
          pdb=" CD2 LEU A  81 "
   model   vdw
   4.505 3.880
nonbonded pdb=" CA  LEU A  65 "
          pdb=" C   SER A  66 "
   model   vdw
   4.505 3.700
nonbonded pdb=" CB  HIS A  64 "
          pdb=" OG  SER A  67 "
   model   vdw
   4.505 3.440
nonbonded pdb=" O   LYS A  46 "
          pdb=" N   THR A  48 "
   model   vdw
   4.505 3.120
nonbonded pdb=" CD  GLN A  12 "
          pdb=" C   PRO A  58 "
   model   vdw sym.op.
   4.506 3.500 -x+1/2,y-1/2,-z+1
nonbonded pdb=" CB  GLN A  10 "
          pdb=" CB  LEU A  32 "
   model   vdw
   4.506 3.840
nonbonded pdb=" C   ARG A  16 "
          pdb=" N   GLY A  18 "
   model   vdw
   4.507 3.350
nonbonded pdb=" CB  ALA A  55 "
          pdb=" CA  TYR A  56 "
   model   vdw
   4.507 3.890
nonbonded pdb=" C   GLN A  10 "
          pdb=" CA  GLN A  12 "
   model   vdw
   4.507 3.700
nonbonded pdb=" C   GLY A  18 "
          pdb=" CE1 TYR A  26 "
   model   vdw
   4.508 3.570
nonbonded pdb=" CB  VAL A   4 "
          pdb=" CB  TYR A  61 "
   model   vdw
   4.508 3.870
nonbonded pdb=" O   TYR A  34 "
          pdb=" O   VAL A  35 "
   model   vdw
   4.508 3.040
nonbonded pdb=" CE  LYS A  46 "
          pdb=" O   PHE A  73 "
   model   vdw sym.op.
   4.508 3.440 -x+1,y,-z+2
nonbonded pdb=" CD1 TYR A  34 "
          pdb=" CB  PRO A  42 "
   model   vdw
   4.508 3.740
nonbonded pdb=" C   VAL A  19 "
          pdb=" C   LYS A  24 "
   model   vdw
   4.509 3.500
nonbonded pdb=" CD1 ILE A  78 "
          pdb=" CD1 ILE A  78 "
   model   vdw sym.op.
   4.509 3.880 -x+1,y,-z+2
nonbonded pdb=" CD1 PHE A  68 "
          pdb=" C   MSE A  77 "
   model   vdw
   4.509 3.570
nonbonded pdb=" O   ALA A  55 "
          pdb=" CA  ALA A  57 "
   model   vdw
   4.509 3.470
nonbonded pdb=" O   LYS A   3 "
          pdb=" O   ASP A  36 "
   model   vdw
   4.509 3.040
nonbonded pdb=" CB  LEU A  49 "
          pdb="O    HOH S  33 "
   model   vdw
   4.510 3.440
nonbonded pdb=" O   CYS A  33 "
          pdb=" C   VAL A  43 "
   model   vdw
   4.510 3.270
nonbonded pdb=" O   GLN A  53 "
          pdb=" CG  GLN A  53 "
   model   vdw
   4.510 3.440
nonbonded pdb=" C   ASN A  29 "
          pdb=" CD1 LEU A  49 "
   model   vdw
   4.510 3.690
nonbonded pdb=" CG  TYR A  56 "
          pdb=" OH  TYR A  61 "
   model   vdw
   4.512 3.260
nonbonded pdb=" C   SER A  17 "
          pdb="O    HOH S  14 "
   model   vdw sym.op.
   4.512 3.270 x,y-1,z
nonbonded pdb=" N   LYS A  46 "
          pdb=" N   SER A  75 "
   model   vdw sym.op.
   4.512 3.200 -x+1,y,-z+2
nonbonded pdb=" N   ARG A  80 "
          pdb=" CD  ARG A  80 "
   model   vdw
   4.513 3.520
nonbonded pdb="O    HOH S  97 "
          pdb=" NH1 ARG A  80 "
   model   vdw sym.op.
   4.513 3.120 -x+1/2,y-1/2,-z+2
nonbonded pdb=" NH1 ARG A  80 "
          pdb="O    HOH S  97 "
   model   vdw sym.op.
   4.513 3.120 -x+1/2,y+1/2,-z+2
nonbonded pdb=" C   GLU A  51 "
          pdb=" O   GLY A  52 "
   model   vdw
   4.513 3.270
nonbonded pdb=" O   LEU A  28 "
          pdb=" CG  GLU A  30 "
   model   vdw
   4.513 3.440
nonbonded pdb=" NE2 GLN A  10 "
          pdb=" CG  TYR A  34 "
   model   vdw
   4.514 3.340
nonbonded pdb=" CD1 PHE A  68 "
          pdb=" CD1 ILE A  78 "
   model   vdw
   4.514 3.760
nonbonded pdb=" OE2 GLU A  51 "
          pdb=" CE1 HIS A  64 "
   model   vdw sym.op.
   4.514 3.260 -x+1/2,y-1/2,-z+2
nonbonded pdb=" CA  GLN A  31 "
          pdb=" O   LEU A  32 "
   model   vdw
   4.514 3.470
nonbonded pdb=" CA  PHE A  13 "
          pdb="O    HOH S 110 "
   model   vdw
   4.515 3.470
nonbonded pdb=" CA  GLU A   5 "
          pdb=" C   GLY A  59 "
   model   vdw
   4.515 3.700
nonbonded pdb=" CB  THR A  48 "
          pdb=" CZ  ARG A  80 "
   model   vdw
   4.515 3.700
nonbonded pdb=" O   VAL A   4 "
          pdb=" CG2 VAL A   4 "
   model   vdw
   4.515 3.460
nonbonded pdb=" O   ILE A  78 "
          pdb="SE    SE Z   4 "
   model   vdw sym.op.
   4.515 3.420 x+1/2,y+3/2,z+2
nonbonded pdb="SE    SE Z   4 "
          pdb=" O   ILE A  78 "
   model   vdw sym.op.
   4.515 3.420 x-1/2,y-3/2,z-2
nonbonded pdb=" CB  ILE A   6 "
          pdb=" C   PRO A  58 "
   model   vdw
   4.516 3.700
nonbonded pdb=" CB  VAL A  63 "
          pdb="O    HOH S  12 "
   model   vdw
   4.516 3.470
nonbonded pdb=" O   LEU A  81 "
          pdb=" CG  LEU A  83 "
   model   vdw
   4.516 3.470
nonbonded pdb=" O   LEU A  32 "
          pdb=" SG  CYS A  33 "
   model   vdw
   4.516 3.400
nonbonded pdb=" CZ  ARG A  16 "
          pdb=" C   PRO A  85 "
   model   vdw sym.op.
   4.516 3.500 x,y-1,z
nonbonded pdb=" CA  GLY A  23 "
          pdb=" C   LYS A  24 "
   model   vdw
   4.516 3.670
nonbonded pdb=" C   LEU A  83 "
          pdb=" N   PRO A  85 "
   model   vdw
   4.517 3.350
nonbonded pdb=" C   ARG A  80 "
          pdb=" NH1 ARG A  82 "
   model   vdw
   4.517 3.350
nonbonded pdb=" CG  PRO A  54 "
          pdb=" O   ALA A  55 "
   model   vdw
   4.518 3.440
nonbonded pdb=" O   GLU A  30 "
          pdb=" CG  GLU A  30 "
   model   vdw
   4.518 3.440
nonbonded pdb=" O   GLY A  59 "
          pdb="O    HOH S  51 "
   model   vdw
   4.518 3.040
nonbonded pdb=" CG2 ILE A   2 "
          pdb=" OG1 THR A  62 "
   model   vdw
   4.518 3.460
nonbonded pdb=" CA  LEU A  32 "
          pdb=" CB  CYS A  33 "
   model   vdw
   4.518 3.870
nonbonded pdb=" N   GLU A  30 "
          pdb=" O   ILE A  47 "
   model   vdw
   4.518 3.120
nonbonded pdb=" O   ILE A   6 "
          pdb=" CG  PRO A  58 "
   model   vdw
   4.519 3.440
nonbonded pdb=" C   LEU A  65 "
          pdb=" CD2 LEU A  65 "
   model   vdw
   4.520 3.690
nonbonded pdb=" C   SER A  66 "
          pdb=" CA  PHE A  68 "
   model   vdw
   4.520 3.700
nonbonded pdb=" C   THR A  48 "
          pdb=" CD  ARG A  80 "
   model   vdw
   4.521 3.670
nonbonded pdb=" C   TYR A  41 "
          pdb=" CD1 TYR A  41 "
   model   vdw
   4.522 3.570
nonbonded pdb=" C   LYS A  69 "
          pdb=" CE  LYS A  69 "
   model   vdw
   4.522 3.670
nonbonded pdb=" C   VAL A   4 "
          pdb=" C   TYR A  61 "
   model   vdw
   4.522 3.500
nonbonded pdb=" O   GLY A  38 "
          pdb=" N   GLU A  40 "
   model   vdw
   4.522 3.120
nonbonded pdb=" C   GLY A  18 "
          pdb=" OH  TYR A  26 "
   model   vdw
   4.523 3.270
nonbonded pdb=" CB  GLU A  30 "
          pdb="O    HOH S 151 "
   model   vdw
   4.523 3.440
nonbonded pdb=" C   LEU A  76 "
          pdb="O    HOH S  10 "
   model   vdw sym.op.
   4.523 3.270 -x+1,y,-z+2
nonbonded pdb=" CG2 THR A  14 "
          pdb=" N   THR A  15 "
   model   vdw
   4.523 3.540
nonbonded pdb=" C   PHE A  73 "
          pdb=" CD1 PHE A  73 "
   model   vdw
   4.523 3.570
nonbonded pdb=" O   ALA A  55 "
          pdb="O    HOH S  44 "
   model   vdw
   4.524 3.040
nonbonded pdb=" CG  TYR A  41 "
          pdb=" CD  PRO A  42 "
   model   vdw
   4.524 3.660
nonbonded pdb=" C   ALA A  11 "
          pdb=" N   PHE A  13 "
   model   vdw
   4.524 3.350
nonbonded pdb=" CD2 HIS A  64 "
          pdb=" CB  VAL A  84 "
   model   vdw
   4.524 3.690
nonbonded pdb=" O   VAL A  84 "
          pdb="O    HOH S  54 "
   model   vdw
   4.524 3.040
nonbonded pdb=" OG  SER A   9 "
          pdb="O    HOH S  34 "
   model   vdw sym.op.
   4.524 3.040 -x+1/2,y+1/2,-z+1
nonbonded pdb=" N   LEU A  37 "
          pdb=" CD1 LEU A  37 "
   model   vdw
   4.525 3.540
nonbonded pdb=" N   GLU A   5 "
          pdb=" O   GLY A  59 "
   model   vdw
   4.525 3.120
nonbonded pdb=" CG2 ILE A  78 "
          pdb=" O   ARG A  80 "
   model   vdw
   4.525 3.460
nonbonded pdb=" C   LEU A  60 "
          pdb=" C   PRO A  85 "
   model   vdw
   4.525 3.500
nonbonded pdb=" CB  TYR A  56 "
          pdb="O    HOH S  98 "
   model   vdw
   4.525 3.440
nonbonded pdb=" CB  ARG A  80 "
          pdb=" CG  ARG A  82 "
   model   vdw
   4.526 3.840
nonbonded pdb=" N   GLY A  71 "
          pdb=" N   MSE A  77 "
   model   vdw
   4.526 3.200
nonbonded pdb=" CB  HIS A  64 "
          pdb=" CA  LEU A  65 "
   model   vdw
   4.526 3.870
nonbonded pdb=" CA  PHE A  13 "
          pdb=" O   THR A  14 "
   model   vdw
   4.526 3.470
nonbonded pdb=" O   TYR A  41 "
          pdb=" CG  PRO A  42 "
   model   vdw
   4.526 3.440
nonbonded pdb=" CD  GLU A   5 "
          pdb=" CG  LEU A  60 "
   model   vdw
   4.526 3.700
nonbonded pdb=" CB  ARG A  16 "
          pdb=" O   LEU A  28 "
   model   vdw
   4.527 3.440
nonbonded pdb=" CD2 LEU A  37 "
          pdb=" O   LEU A  65 "
   model   vdw sym.op.
   4.527 3.460 -x+1,y,-z+2
nonbonded pdb=" N   GLN A  72 "
          pdb=" N   GLY A  74 "
   model   vdw
   4.527 3.200
nonbonded pdb=" CB  THR A  62 "
          pdb=" O   VAL A  84 "
   model   vdw
   4.528 3.470
nonbonded pdb=" CG  PHE A  13 "
          pdb=" CB  ALA A  55 "
   model   vdw
   4.528 3.680
nonbonded pdb=" O   ARG A  21 "
          pdb=" OE1 GLN A  22 "
   model   vdw
   4.528 3.040
nonbonded pdb=" O   VAL A  19 "
          pdb=" CG2 VAL A  19 "
   model   vdw
   4.529 3.460
nonbonded pdb=" C   CYS A  33 "
          pdb=" CA  LEU A  44 "
   model   vdw
   4.529 3.700
nonbonded pdb=" CG2 VAL A  43 "
          pdb=" O   LEU A  44 "
   model   vdw
   4.529 3.460
nonbonded pdb=" C   LEU A  49 "
          pdb=" CD2 LEU A  49 "
   model   vdw
   4.530 3.690
nonbonded pdb=" CA  GLU A  30 "
          pdb=" C   ILE A  47 "
   model   vdw
   4.530 3.700
nonbonded pdb=" O   VAL A  84 "
          pdb=" CG2 VAL A  84 "
   model   vdw
   4.530 3.460
nonbonded pdb=" C   GLN A  31 "
          pdb=" CD  GLN A  31 "
   model   vdw
   4.530 3.500
nonbonded pdb=" CD  GLN A  53 "
          pdb=" OH  TYR A  56 "
   model   vdw
   4.530 3.270
nonbonded pdb=" CG  ASP A  79 "
          pdb=" CA  ARG A  80 "
   model   vdw
   4.530 3.700
nonbonded pdb=" O   ARG A  80 "
          pdb=" NE  ARG A  82 "
   model   vdw
   4.531 3.120
nonbonded pdb=" CD  LYS A  24 "
          pdb=" NH1 ARG A  82 "
   model   vdw sym.op.
   4.531 3.520 -x+1/2,y-1/2,-z+2
nonbonded pdb=" C   GLN A  72 "
          pdb=" CD  GLN A  72 "
   model   vdw
   4.531 3.500
nonbonded pdb=" CA  LYS A   7 "
          pdb=" N   GLN A  10 "
   model   vdw
   4.531 3.550
nonbonded pdb=" O   TYR A  61 "
          pdb=" OG1 THR A  62 "
   model   vdw
   4.531 3.040
nonbonded pdb=" CB  SER A  66 "
          pdb=" NE  ARG A  21 "
   model   vdw sym.op.
   4.531 3.520 x,y+1,z
nonbonded pdb=" NE  ARG A  21 "
          pdb=" CB  SER A  66 "
   model   vdw sym.op.
   4.531 3.520 x,y-1,z
nonbonded pdb=" CG  ASP A  79 "
          pdb=" CB  ARG A  80 "
   model   vdw
   4.532 3.670
nonbonded pdb=" NE2 GLN A  22 "
          pdb="O    HOH S 175 "
   model   vdw sym.op.
   4.532 3.120 -x+1/2,y-1/2,-z+2
nonbonded pdb=" CG  ASP A  50 "
          pdb=" NH1 ARG A  80 "
   model   vdw
   4.532 3.350
nonbonded pdb=" CB  THR A  14 "
          pdb=" CA  THR A  15 "
   model   vdw
   4.532 3.900
nonbonded pdb=" O   VAL A  63 "
          pdb=" CG2 VAL A  63 "
   model   vdw
   4.533 3.460
nonbonded pdb=" CA  GLY A  74 "
          pdb=" O   SER A  75 "
   model   vdw
   4.533 3.440
nonbonded pdb=" N   PHE A  13 "
          pdb=" O   GLU A  30 "
   model   vdw
   4.533 3.120
nonbonded pdb=" CG1 VAL A  35 "
          pdb=" CD1 LEU A  76 "
   model   vdw sym.op.
   4.534 3.880 -x+1,y,-z+2
nonbonded pdb=" N   VAL A  45 "
          pdb=" O   GLY A  74 "
   model   vdw sym.op.
   4.534 3.120 -x+1,y,-z+2
nonbonded pdb=" C   PRO A   8 "
          pdb=" CA  GLN A  10 "
   model   vdw
   4.534 3.700
nonbonded pdb=" NZ  LYS A  24 "
          pdb=" CZ  ARG A  82 "
   model   vdw sym.op.
   4.535 3.350 -x+1/2,y-1/2,-z+2
nonbonded pdb=" CZ  ARG A  82 "
          pdb=" NZ  LYS A  24 "
   model   vdw sym.op.
   4.535 3.350 -x+1/2,y+1/2,-z+2
nonbonded pdb=" C   ARG A  16 "
          pdb=" OG  SER A  17 "
   model   vdw
   4.535 3.270
nonbonded pdb=" CE2 TYR A  26 "
          pdb=" CD  PRO A  85 "
   model   vdw sym.op.
   4.535 3.740 x,y-1,z
nonbonded pdb=" C   SER A  67 "
          pdb=" CA  ILE A  78 "
   model   vdw
   4.536 3.700
nonbonded pdb=" C   SER A  27 "
          pdb="O    HOH S  33 "
   model   vdw
   4.536 3.270
nonbonded pdb=" O   LEU A  60 "
          pdb=" O   TYR A  61 "
   model   vdw
   4.537 3.040
nonbonded pdb=" CA  LEU A  49 "
          pdb="O    HOH S  33 "
   model   vdw
   4.537 3.470
nonbonded pdb=" CA  PHE A  13 "
          pdb=" C   THR A  14 "
   model   vdw
   4.537 3.700
nonbonded pdb=" O   GLN A  53 "
          pdb=" CG  PRO A  54 "
   model   vdw
   4.537 3.440
nonbonded pdb=" N   GLN A  12 "
          pdb=" NE2 GLN A  31 "
   model   vdw
   4.537 3.200
nonbonded pdb=" O   GLN A  31 "
          pdb=" CG  LEU A  32 "
   model   vdw
   4.537 3.470
nonbonded pdb=" CA  ARG A  21 "
          pdb=" C   GLN A  22 "
   model   vdw
   4.538 3.700
nonbonded pdb=" NH2 ARG A  21 "
          pdb=" NE2 HIS A  64 "
   model   vdw sym.op.
   4.538 3.200 x,y-1,z
nonbonded pdb=" O   VAL A  19 "
          pdb=" O   LYS A  24 "
   model   vdw
   4.539 3.040
nonbonded pdb=" N   LEU A  37 "
          pdb=" CD2 LEU A  65 "
   model   vdw sym.op.
   4.539 3.540 -x+1,y,-z+2
nonbonded pdb=" N   TYR A  56 "
          pdb=" CE2 TYR A  56 "
   model   vdw
   4.539 3.420
nonbonded pdb=" CE  LYS A   3 "
          pdb=" C   GLN A  72 "
   model   vdw sym.op.
   4.539 3.670 -x+1,y+1,-z+2
nonbonded pdb=" CA  SER A  20 "
          pdb=" CD2 TYR A  26 "
   model   vdw
   4.540 3.770
nonbonded pdb=" O   SER A  66 "
          pdb=" NE  ARG A  82 "
   model   vdw
   4.540 3.120
nonbonded pdb=" O   SER A  67 "
          pdb=" CA  ARG A  80 "
   model   vdw
   4.540 3.470
nonbonded pdb=" CD1 LEU A  81 "
          pdb=" N   ARG A  82 "
   model   vdw
   4.540 3.540
nonbonded pdb=" CA  LYS A  46 "
          pdb=" CE  LYS A  46 "
   model   vdw
   4.540 3.870
nonbonded pdb=" CD1 TYR A  56 "
          pdb=" CD2 TYR A  61 "
   model   vdw
   4.540 3.640
nonbonded pdb=" CA  PRO A   8 "
          pdb="O    HOH S 117 "
   model   vdw sym.op.
   4.541 3.470 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CB  LYS A  46 "
          pdb=" CA  ILE A  47 "
   model   vdw
   4.541 3.870
nonbonded pdb=" C   GLU A  30 "
          pdb=" N   LEU A  32 "
   model   vdw
   4.541 3.350
nonbonded pdb=" CG1 VAL A  19 "
          pdb=" N   PRO A  25 "
   model   vdw
   4.541 3.540
nonbonded pdb=" O   ILE A   2 "
          pdb=" C   THR A  62 "
   model   vdw
   4.541 3.270
nonbonded pdb=" C   ASP A  79 "
          pdb=" N   LEU A  81 "
   model   vdw
   4.541 3.350
nonbonded pdb=" CB  VAL A  45 "
          pdb=" CA  LYS A  46 "
   model   vdw
   4.541 3.900
nonbonded pdb=" N   GLU A  51 "
          pdb=" CD  GLU A  51 "
   model   vdw
   4.542 3.350
nonbonded pdb=" N   LEU A  28 "
          pdb="O    HOH S  33 "
   model   vdw
   4.542 3.120
nonbonded pdb=" CA  TYR A  26 "
          pdb=" CB  SER A  27 "
   model   vdw
   4.542 3.870
nonbonded pdb=" N   ILE A   6 "
          pdb=" OE1 GLN A  10 "
   model   vdw
   4.542 3.120
nonbonded pdb=" NH1 ARG A  16 "
          pdb="O    HOH S   9 "
   model   vdw sym.op.
   4.542 3.120 x,y-1,z
nonbonded pdb=" O   ILE A  47 "
          pdb=" CD1 ILE A  47 "
   model   vdw
   4.543 3.460
nonbonded pdb=" CD1 LEU A  32 "
          pdb=" N   CYS A  33 "
   model   vdw
   4.543 3.540
nonbonded pdb=" CA  ASN A  39 "
          pdb="O    HOH S 131 "
   model   vdw
   4.543 3.470
nonbonded pdb=" CG1 ILE A  78 "
          pdb=" CE1 PHE A  68 "
   model   vdw sym.op.
   4.543 3.740 -x+1,y,-z+2
nonbonded pdb=" CE1 PHE A  68 "
          pdb=" CG1 ILE A  78 "
   model   vdw sym.op.
   4.543 3.740 -x+1,y,-z+2
nonbonded pdb=" O   PHE A  73 "
          pdb=" O   GLY A  74 "
   model   vdw
   4.543 3.040
nonbonded pdb=" CE2 TYR A  61 "
          pdb=" O   VAL A  84 "
   model   vdw
   4.544 3.340
nonbonded pdb=" CA  VAL A  63 "
          pdb=" C   HIS A  64 "
   model   vdw
   4.544 3.700
nonbonded pdb=" O   GLN A  22 "
          pdb=" NH2 ARG A  80 "
   model   vdw sym.op.
   4.544 3.120 -x+1/2,y-1/2,-z+2
nonbonded pdb=" NH2 ARG A  80 "
          pdb=" O   GLN A  22 "
   model   vdw sym.op.
   4.544 3.120 -x+1/2,y+1/2,-z+2
nonbonded pdb=" C   TYR A  34 "
          pdb=" CD1 TYR A  34 "
   model   vdw
   4.544 3.570
nonbonded pdb=" CA  GLN A  72 "
          pdb=" N   GLY A  74 "
   model   vdw
   4.544 3.550
nonbonded pdb=" CB  GLN A  31 "
          pdb=" CA  LEU A  32 "
   model   vdw
   4.545 3.870
nonbonded pdb=" C   GLY A  18 "
          pdb=" CA  PRO A  25 "
   model   vdw
   4.545 3.700
nonbonded pdb=" CG1 VAL A  45 "
          pdb=" N   ILE A  47 "
   model   vdw
   4.545 3.540
nonbonded pdb=" CA  TYR A  56 "
          pdb=" CE1 TYR A  56 "
   model   vdw
   4.546 3.770
nonbonded pdb=" C   LYS A   7 "
          pdb=" OE1 GLN A  10 "
   model   vdw
   4.546 3.270
nonbonded pdb=" CA  GLN A  12 "
          pdb=" CB  ALA A  55 "
   model   vdw
   4.546 3.890
nonbonded pdb=" NH1 ARG A  16 "
          pdb=" CA  LEU A  60 "
   model   vdw sym.op.
   4.546 3.550 x,y-1,z
nonbonded pdb=" N   ARG A  16 "
          pdb=" N   LEU A  28 "
   model   vdw
   4.546 3.200
nonbonded pdb=" C   LYS A   7 "
          pdb=" CA  GLN A  10 "
   model   vdw
   4.547 3.700
nonbonded pdb=" CB  ARG A  21 "
          pdb="O    HOH S 135 "
   model   vdw sym.op.
   4.547 3.440 x,y-1,z
nonbonded pdb="O    HOH S 135 "
          pdb=" CB  ARG A  21 "
   model   vdw sym.op.
   4.547 3.440 x,y+1,z
nonbonded pdb=" NZ  LYS A   7 "
          pdb=" OE1 GLU A  40 "
   model   vdw sym.op.
   4.547 3.120 -x+1,y,-z+1
nonbonded pdb=" CA  VAL A  84 "
          pdb=" C   PRO A  85 "
   model   vdw
   4.548 3.700
nonbonded pdb=" C   TYR A  26 "
          pdb=" OG  SER A  27 "
   model   vdw
   4.548 3.270
nonbonded pdb=" CB  THR A  48 "
          pdb=" O   LEU A  49 "
   model   vdw
   4.548 3.470
nonbonded pdb=" N   VAL A  19 "
          pdb=" O   LYS A  24 "
   model   vdw
   4.548 3.120
nonbonded pdb=" O   SER A  67 "
          pdb=" CG1 ILE A  78 "
   model   vdw
   4.548 3.440
nonbonded pdb=" O   LYS A  46 "
          pdb=" C   GLY A  74 "
   model   vdw sym.op.
   4.549 3.270 -x+1,y,-z+2
nonbonded pdb=" OG1 THR A  14 "
          pdb=" C   GLU A  30 "
   model   vdw
   4.549 3.270
nonbonded pdb=" N   SER A  20 "
          pdb=" NE2 GLN A  53 "
   model   vdw sym.op.
   4.549 3.200 x,y-1,z
nonbonded pdb=" CE  LYS A   3 "
          pdb=" CD  GLN A  72 "
   model   vdw sym.op.
   4.549 3.670 -x+1,y+1,-z+2
nonbonded pdb=" CD  GLN A  72 "
          pdb=" CE  LYS A   3 "
   model   vdw sym.op.
   4.549 3.670 -x+1,y-1,-z+2
nonbonded pdb=" NH2 ARG A  16 "
          pdb=" C   PRO A  85 "
   model   vdw sym.op.
   4.549 3.350 x,y-1,z
nonbonded pdb=" O   ILE A  78 "
          pdb="SE    SE Z   3 "
   model   vdw sym.op.
   4.550 3.420 x+1/2,y+3/2,z+1
nonbonded pdb=" CA  HIS A  64 "
          pdb=" CE1 HIS A  64 "
   model   vdw
   4.550 3.690
nonbonded pdb=" O   PHE A  73 "
          pdb=" CD1 LEU A  60 "
   model   vdw sym.op.
   4.550 3.460 -x+1,y-1,-z+2
nonbonded pdb=" CD1 LEU A  60 "
          pdb=" O   PHE A  73 "
   model   vdw sym.op.
   4.550 3.460 -x+1,y+1,-z+2
nonbonded pdb=" CZ  ARG A  16 "
          pdb=" C   LEU A  60 "
   model   vdw sym.op.
   4.550 3.500 x,y-1,z
nonbonded pdb=" CB  ILE A   2 "
          pdb="O    HOH S  12 "
   model   vdw
   4.550 3.470
nonbonded pdb=" CG  LEU A  83 "
          pdb=" N   VAL A  84 "
   model   vdw
   4.551 3.550
nonbonded pdb=" CG1 VAL A  45 "
          pdb=" C   SER A  75 "
   model   vdw sym.op.
   4.552 3.690 -x+1,y,-z+2
nonbonded pdb=" C   LYS A   3 "
          pdb="O    HOH S   2 "
   model   vdw
   4.552 3.270
nonbonded pdb=" CB  VAL A   4 "
          pdb=" CD1 LEU A  83 "
   model   vdw
   4.552 3.890
nonbonded pdb=" O   SER A  67 "
          pdb=" CD1 PHE A  68 "
   model   vdw
   4.553 3.340
nonbonded pdb=" CA  VAL A   4 "
          pdb=" C   TYR A  61 "
   model   vdw
   4.554 3.700
nonbonded pdb=" C   ASP A  79 "
          pdb="O    HOH S 160 "
   model   vdw
   4.554 3.270
nonbonded pdb=" CD1 TYR A  26 "
          pdb=" N   LEU A  28 "
   model   vdw
   4.554 3.420
nonbonded pdb=" O   LEU A  76 "
          pdb=" CG1 ILE A  78 "
   model   vdw sym.op.
   4.554 3.440 -x+1,y,-z+2
nonbonded pdb=" N   HIS A  64 "
          pdb="O    HOH S  35 "
   model   vdw
   4.555 3.120
nonbonded pdb=" O   LYS A   7 "
          pdb=" O   GLN A  10 "
   model   vdw
   4.555 3.040
nonbonded pdb=" CA  SER A  75 "
          pdb=" O   LEU A  76 "
   model   vdw
   4.555 3.470
nonbonded pdb=" CA  GLU A  40 "
          pdb=" OE2 GLU A  40 "
   model   vdw
   4.555 3.470
nonbonded pdb=" C   TYR A  61 "
          pdb=" OG1 THR A  62 "
   model   vdw
   4.555 3.270
nonbonded pdb=" O   GLU A   5 "
          pdb=" CD2 TYR A  34 "
   model   vdw
   4.556 3.340
nonbonded pdb=" CB  SER A  67 "
          pdb=" CA  PHE A  68 "
   model   vdw
   4.556 3.870
nonbonded pdb=" N   CYS A  33 "
          pdb=" N   VAL A  45 "
   model   vdw
   4.556 3.200
nonbonded pdb=" CG2 VAL A   4 "
          pdb=" O   TYR A  61 "
   model   vdw
   4.556 3.460
nonbonded pdb=" CE  LYS A  24 "
          pdb=" CG  ASP A  50 "
   model   vdw sym.op.
   4.556 3.670 -x+1/2,y-1/2,-z+2
nonbonded pdb=" CG  ASP A  50 "
          pdb=" CE  LYS A  24 "
   model   vdw sym.op.
   4.556 3.670 -x+1/2,y+1/2,-z+2
nonbonded pdb=" O   ASP A  36 "
          pdb=" OD2 ASP A  36 "
   model   vdw
   4.556 3.040
nonbonded pdb=" CD2 TYR A  56 "
          pdb=" CB  LEU A  83 "
   model   vdw
   4.556 3.740
nonbonded pdb=" O   LYS A   3 "
          pdb=" N   VAL A  35 "
   model   vdw
   4.556 3.120
nonbonded pdb=" CG  TYR A  41 "
          pdb=" CD1 TYR A  41 "
   model   vdw sym.op.
   4.557 3.560 -x+1,y,-z+1
nonbonded pdb=" CD1 TYR A  41 "
          pdb=" CG  TYR A  41 "
   model   vdw sym.op.
   4.557 3.560 -x+1,y,-z+1
nonbonded pdb=" CB  LEU A  28 "
          pdb="O    HOH S  33 "
   model   vdw
   4.557 3.440
nonbonded pdb=" CG2 THR A  15 "
          pdb=" N   LEU A  28 "
   model   vdw
   4.558 3.540
nonbonded pdb=" O   THR A  15 "
          pdb=" O   ARG A  16 "
   model   vdw
   4.558 3.040
nonbonded pdb=" CA  VAL A  45 "
          pdb=" O   LYS A  46 "
   model   vdw
   4.558 3.470
nonbonded pdb=" O   THR A  15 "
          pdb="O    HOH S   8 "
   model   vdw
   4.558 3.040
nonbonded pdb=" N   GLY A  38 "
          pdb=" CG  LEU A  65 "
   model   vdw sym.op.
   4.558 3.550 -x+1,y,-z+2
nonbonded pdb=" SG  CYS A  33 "
          pdb=" C   TYR A  34 "
   model   vdw
   4.558 3.630
nonbonded pdb=" CA  VAL A  19 "
          pdb=" C   SER A  20 "
   model   vdw
   4.559 3.700
nonbonded pdb=" N   GLY A  74 "
          pdb="O    HOH S  25 "
   model   vdw
   4.559 3.120
nonbonded pdb=" O   ALA A  57 "
          pdb=" CD1 TYR A  61 "
   model   vdw
   4.559 3.340
nonbonded pdb=" OD1 ASP A  36 "
          pdb=" C   GLY A  38 "
   model   vdw
   4.559 3.270
nonbonded pdb=" CA  GLU A  30 "
          pdb="O    HOH S   8 "
   model   vdw
   4.559 3.470
nonbonded pdb=" OG1 THR A  15 "
          pdb=" N   ARG A  16 "
   model   vdw
   4.560 3.120
nonbonded pdb=" C   THR A  62 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   4.560 3.690
nonbonded pdb=" OG  SER A  67 "
          pdb=" N   LEU A  81 "
   model   vdw
   4.561 3.120
nonbonded pdb=" CE1 TYR A  56 "
          pdb=" CD1 LEU A  83 "
   model   vdw
   4.561 3.760
nonbonded pdb=" CB  GLU A   5 "
          pdb=" CA  ILE A   6 "
   model   vdw
   4.561 3.870
nonbonded pdb=" CB  VAL A  35 "
          pdb=" CG1 VAL A  43 "
   model   vdw
   4.562 3.890
nonbonded pdb=" CB  VAL A  45 "
          pdb=" O   LYS A  46 "
   model   vdw
   4.562 3.470
nonbonded pdb=" CA  SER A  20 "
          pdb=" C   LYS A  24 "
   model   vdw
   4.562 3.700
nonbonded pdb=" CG  ASP A  50 "
          pdb="O    HOH S 175 "
   model   vdw
   4.562 3.270
nonbonded pdb=" O   LEU A  76 "
          pdb=" O   MSE A  77 "
   model   vdw
   4.563 3.040
nonbonded pdb=" CA  LEU A  28 "
          pdb=" C   ASN A  29 "
   model   vdw
   4.563 3.700
nonbonded pdb=" CG  GLU A   5 "
          pdb=" C   GLY A  59 "
   model   vdw
   4.563 3.670
nonbonded pdb=" O   LEU A  60 "
          pdb=" CG  LEU A  60 "
   model   vdw
   4.563 3.470
nonbonded pdb=" O   LEU A  49 "
          pdb=" CZ  ARG A  80 "
   model   vdw
   4.565 3.270
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" O   LEU A  32 "
   model   vdw
   4.565 3.460
nonbonded pdb=" CG  ASP A  79 "
          pdb=" CZ  ARG A  82 "
   model   vdw
   4.565 3.500
nonbonded pdb=" CD  PRO A   8 "
          pdb=" CB  PRO A  58 "
   model   vdw
   4.565 3.840
nonbonded pdb=" C   PRO A  25 "
          pdb=" CD2 TYR A  26 "
   model   vdw
   4.565 3.570
nonbonded pdb=" C   ASP A  36 "
          pdb=" O   LEU A  37 "
   model   vdw
   4.566 3.270
nonbonded pdb=" C   LYS A  46 "
          pdb=" CA  SER A  75 "
   model   vdw sym.op.
   4.566 3.700 -x+1,y,-z+2
nonbonded pdb=" O   LEU A  49 "
          pdb=" OD1 ASP A  50 "
   model   vdw
   4.566 3.040
nonbonded pdb=" C   SER A  75 "
          pdb="SE    SE Z   3 "
   model   vdw sym.op.
   4.566 3.650 -x+1/2,y+3/2,-z+1
nonbonded pdb=" O   TYR A  41 "
          pdb=" CA  VAL A  43 "
   model   vdw
   4.567 3.470
nonbonded pdb=" CB  PRO A   8 "
          pdb=" CA  SER A   9 "
   model   vdw
   4.567 3.870
nonbonded pdb=" CA  PHE A  68 "
          pdb=" CE1 PHE A  68 "
   model   vdw
   4.567 3.770
nonbonded pdb=" CG1 VAL A   4 "
          pdb=" C   TYR A  34 "
   model   vdw
   4.567 3.690
nonbonded pdb=" CA  GLY A  18 "
          pdb=" CG2 VAL A  19 "
   model   vdw
   4.567 3.860
nonbonded pdb=" O   SER A  75 "
          pdb=" CB  MSE A  77 "
   model   vdw
   4.568 3.440
nonbonded pdb=" CB  LEU A  28 "
          pdb=" CG2 THR A  48 "
   model   vdw
   4.568 3.860
nonbonded pdb=" CA  PRO A   8 "
          pdb=" C   SER A   9 "
   model   vdw
   4.568 3.700
nonbonded pdb=" N   ALA A  11 "
          pdb=" O   GLN A  12 "
   model   vdw
   4.568 3.120
nonbonded pdb=" CG1 ILE A   6 "
          pdb=" O   GLY A  59 "
   model   vdw
   4.568 3.440
nonbonded pdb=" O   VAL A  84 "
          pdb=" CG  PRO A  85 "
   model   vdw
   4.568 3.440
nonbonded pdb=" CD1 TYR A  56 "
          pdb=" CD1 LEU A  83 "
   model   vdw
   4.568 3.760
nonbonded pdb=" CB  GLN A  53 "
          pdb=" CA  PRO A  54 "
   model   vdw
   4.568 3.870
nonbonded pdb=" N   ASP A  50 "
          pdb="O    HOH S 175 "
   model   vdw
   4.568 3.120
nonbonded pdb=" CE  LYS A  24 "
          pdb=" CG  ARG A  21 "
   model   vdw sym.op.
   4.568 3.840 -x+1/2,y+1/2,-z+2
nonbonded pdb=" CG  ARG A  21 "
          pdb=" CE  LYS A  24 "
   model   vdw sym.op.
   4.568 3.840 -x+1/2,y-1/2,-z+2
nonbonded pdb=" O   TYR A  56 "
          pdb=" CG  TYR A  56 "
   model   vdw
   4.569 3.260
nonbonded pdb=" CB  VAL A  45 "
          pdb=" N   LEU A  76 "
   model   vdw sym.op.
   4.569 3.550 -x+1,y,-z+2
nonbonded pdb=" O   MSE A  77 "
          pdb=" O   ILE A  78 "
   model   vdw
   4.569 3.040
nonbonded pdb=" O   LEU A  44 "
          pdb=" O   VAL A  45 "
   model   vdw
   4.569 3.040
nonbonded pdb=" CA  ILE A  47 "
          pdb=" C   THR A  48 "
   model   vdw
   4.569 3.700
nonbonded pdb=" CA  TYR A  34 "
          pdb=" CE1 TYR A  34 "
   model   vdw
   4.570 3.770
nonbonded pdb=" CD  ARG A  16 "
          pdb=" CB  LEU A  28 "
   model   vdw
   4.570 3.840
nonbonded pdb=" OH  TYR A  56 "
          pdb="O    HOH S  98 "
   model   vdw
   4.570 3.040
nonbonded pdb=" CB  LYS A   7 "
          pdb=" CB  GLN A  10 "
   model   vdw
   4.570 3.840
nonbonded pdb=" CZ  TYR A  41 "
          pdb=" CE1 TYR A  34 "
   model   vdw sym.op.
   4.570 3.560 -x+1,y,-z+1
nonbonded pdb=" CE1 TYR A  34 "
          pdb=" CZ  TYR A  41 "
   model   vdw sym.op.
   4.570 3.560 -x+1,y,-z+1
nonbonded pdb=" CG  GLU A  30 "
          pdb=" O   ILE A  47 "
   model   vdw
   4.571 3.440
nonbonded pdb=" CA  SER A  20 "
          pdb=" N   LYS A  24 "
   model   vdw
   4.571 3.550
nonbonded pdb=" O   VAL A  35 "
          pdb=" CA  LEU A  37 "
   model   vdw
   4.571 3.470
nonbonded pdb=" CG  LEU A  32 "
          pdb=" CD1 LEU A  44 "
   model   vdw
   4.572 3.890
nonbonded pdb=" CE2 TYR A  56 "
          pdb=" N   LEU A  83 "
   model   vdw
   4.572 3.420
nonbonded pdb=" CB  ASP A  36 "
          pdb=" NE2 GLN A  72 "
   model   vdw sym.op.
   4.572 3.520 -x+1,y+1,-z+2
nonbonded pdb=" CD  PRO A  54 "
          pdb="O    HOH S  98 "
   model   vdw
   4.572 3.440
nonbonded pdb=" CB  TYR A  41 "
          pdb=" C   PRO A  42 "
   model   vdw
   4.573 3.670
nonbonded pdb=" CG  LYS A   3 "
          pdb=" O   TYR A  61 "
   model   vdw
   4.573 3.440
nonbonded pdb=" CD  LYS A  46 "
          pdb="O    HOH S  25 "
   model   vdw sym.op.
   4.573 3.440 -x+1,y,-z+2
nonbonded pdb=" CB  GLU A  51 "
          pdb=" CA  GLY A  52 "
   model   vdw
   4.573 3.840
nonbonded pdb=" O   ALA A  57 "
          pdb="O    HOH S  14 "
   model   vdw
   4.574 3.040
nonbonded pdb=" C   LEU A  81 "
          pdb=" CD2 LEU A  81 "
   model   vdw
   4.574 3.690
nonbonded pdb=" CA  TYR A  61 "
          pdb=" CA  PRO A  85 "
   model   vdw
   4.574 3.900
nonbonded pdb=" CB  PRO A  54 "
          pdb=" C   ALA A  55 "
   model   vdw
   4.575 3.670
nonbonded pdb=" CD1 TYR A  34 "
          pdb=" CA  VAL A  43 "
   model   vdw
   4.575 3.770
nonbonded pdb=" O   SER A  66 "
          pdb=" CA  PHE A  68 "
   model   vdw
   4.575 3.470
nonbonded pdb=" OG1 THR A  15 "
          pdb=" CA  SER A   9 "
   model   vdw sym.op.
   4.575 3.470 -x+1/2,y-1/2,-z+1
nonbonded pdb=" CA  SER A   9 "
          pdb=" OG1 THR A  15 "
   model   vdw sym.op.
   4.575 3.470 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CD1 LEU A  37 "
          pdb=" N   VAL A  70 "
   model   vdw sym.op.
   4.576 3.540 -x+1,y,-z+2
nonbonded pdb=" N   ALA A  11 "
          pdb=" NE2 GLN A  31 "
   model   vdw
   4.576 3.200
nonbonded pdb=" CD1 LEU A  65 "
          pdb=" CD2 PHE A  68 "
   model   vdw
   4.576 3.760
nonbonded pdb=" CZ  TYR A  26 "
          pdb="O    HOH S  14 "
   model   vdw sym.op.
   4.576 3.260 x,y-1,z
nonbonded pdb=" CB  ILE A  47 "
          pdb=" CA  THR A  48 "
   model   vdw
   4.576 3.900
nonbonded pdb=" CA  THR A  62 "
          pdb=" C   VAL A  63 "
   model   vdw
   4.576 3.700
nonbonded pdb=" O   TYR A  61 "
          pdb=" O   THR A  62 "
   model   vdw
   4.576 3.040
nonbonded pdb=" O   PRO A   8 "
          pdb=" CG2 THR A  14 "
   model   vdw sym.op.
   4.576 3.460 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CG2 ILE A  78 "
          pdb=" O   ASP A  79 "
   model   vdw
   4.576 3.460
nonbonded pdb=" CZ  TYR A  41 "
          pdb=" CB  PRO A  42 "
   model   vdw sym.op.
   4.576 3.660 -x+1,y,-z+1
nonbonded pdb=" OD1 ASP A  79 "
          pdb=" CB  ARG A  80 "
   model   vdw
   4.577 3.440
nonbonded pdb=" CG1 VAL A  43 "
          pdb=" CG2 VAL A  45 "
   model   vdw
   4.577 3.880
nonbonded pdb=" CD1 PHE A  68 "
          pdb=" CA  ILE A  78 "
   model   vdw
   4.577 3.770
nonbonded pdb=" CB  PRO A  42 "
          pdb=" CA  VAL A  43 "
   model   vdw
   4.577 3.870
nonbonded pdb=" C   HIS A  64 "
          pdb=" CE1 HIS A  64 "
   model   vdw
   4.578 3.490
nonbonded pdb=" C   MSE A  77 "
          pdb="SE    SE Z   4 "
   model   vdw sym.op.
   4.578 3.650 x+1/2,y+3/2,z+2
nonbonded pdb=" CD1 LEU A  32 "
          pdb=" CG  LEU A  44 "
   model   vdw
   4.579 3.890
nonbonded pdb=" CA  PHE A  68 "
          pdb=" CB  LYS A  69 "
   model   vdw
   4.579 3.870
nonbonded pdb=" N   ARG A  82 "
          pdb=" CA  LEU A  83 "
   model   vdw
   4.580 3.550
nonbonded pdb=" OD1 ASP A  50 "
          pdb=" NE  ARG A  80 "
   model   vdw
   4.580 3.120
nonbonded pdb=" CA  GLY A  74 "
          pdb=" C   SER A  75 "
   model   vdw
   4.580 3.670
nonbonded pdb=" C   GLN A  72 "
          pdb=" O   PHE A  73 "
   model   vdw
   4.580 3.270
nonbonded pdb=" OG1 THR A  14 "
          pdb=" OE1 GLU A  30 "
   model   vdw
   4.580 3.040
nonbonded pdb=" CB  ARG A  80 "
          pdb=" CA  LEU A  81 "
   model   vdw
   4.580 3.870
nonbonded pdb=" CG1 ILE A   6 "
          pdb=" CD1 LEU A  83 "
   model   vdw
   4.581 3.860
nonbonded pdb=" CG2 ILE A  47 "
          pdb=" N   THR A  48 "
   model   vdw
   4.581 3.540
nonbonded pdb=" CG2 VAL A  19 "
          pdb=" CA  PRO A  25 "
   model   vdw
   4.581 3.890
nonbonded pdb=" O   ARG A  16 "
          pdb=" N   GLY A  18 "
   model   vdw
   4.581 3.120
nonbonded pdb=" O   PRO A   8 "
          pdb=" CA  GLN A  10 "
   model   vdw
   4.581 3.470
nonbonded pdb=" CD2 LEU A  28 "
          pdb="O    HOH S  33 "
   model   vdw
   4.581 3.460
nonbonded pdb=" CE1 HIS A  64 "
          pdb=" CA  SER A  66 "
   model   vdw
   4.582 3.690
nonbonded pdb=" CD  GLN A  53 "
          pdb=" O   PRO A  54 "
   model   vdw
   4.582 3.270
nonbonded pdb=" O   LEU A  44 "
          pdb=" CD2 LEU A  44 "
   model   vdw
   4.582 3.460
nonbonded pdb=" C   GLU A  40 "
          pdb=" N   PRO A  42 "
   model   vdw
   4.582 3.350
nonbonded pdb=" CG2 THR A  62 "
          pdb=" O   PRO A  85 "
   model   vdw
   4.582 3.460
nonbonded pdb=" CG  LYS A   3 "
          pdb=" CZ  PHE A  73 "
   model   vdw sym.op.
   4.582 3.740 -x+1,y+1,-z+2
nonbonded pdb=" CB  PRO A  25 "
          pdb=" CA  TYR A  26 "
   model   vdw
   4.582 3.870
nonbonded pdb=" CD2 PHE A  73 "
          pdb="O    HOH S  54 "
   model   vdw sym.op.
   4.582 3.340 -x+1,y-1,-z+2
nonbonded pdb=" N   GLY A  23 "
          pdb="O    HOH S  97 "
   model   vdw
   4.582 3.120
nonbonded pdb=" OE1 GLU A  51 "
          pdb=" CB  ARG A  21 "
   model   vdw sym.op.
   4.583 3.440 -x+1/2,y+1/2,-z+2
nonbonded pdb=" CB  ARG A  21 "
          pdb=" OE1 GLU A  51 "
   model   vdw sym.op.
   4.583 3.440 -x+1/2,y-1/2,-z+2
nonbonded pdb="O    HOH S 117 "
          pdb=" CA  SER A   9 "
   model   vdw sym.op.
   4.583 3.470 -x+1/2,y-1/2,-z+1
nonbonded pdb=" CA  SER A   9 "
          pdb="O    HOH S 117 "
   model   vdw sym.op.
   4.583 3.470 -x+1/2,y+1/2,-z+1
nonbonded pdb=" N   PHE A  73 "
          pdb=" CE2 PHE A  73 "
   model   vdw
   4.583 3.420
nonbonded pdb=" O   GLU A  51 "
          pdb=" CA  GLN A  53 "
   model   vdw
   4.583 3.470
nonbonded pdb=" CA  VAL A  63 "
          pdb="O    HOH S  12 "
   model   vdw
   4.583 3.470
nonbonded pdb=" O   LYS A   7 "
          pdb=" CA  ALA A  11 "
   model   vdw
   4.584 3.470
nonbonded pdb=" CB  TYR A  61 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   4.584 3.860
nonbonded pdb=" CA  GLN A  31 "
          pdb=" C   LEU A  32 "
   model   vdw
   4.584 3.700
nonbonded pdb=" NH2 ARG A  16 "
          pdb=" CA  LEU A  60 "
   model   vdw sym.op.
   4.584 3.550 x,y-1,z
nonbonded pdb=" OG1 THR A  15 "
          pdb=" CA  ASN A  29 "
   model   vdw
   4.584 3.470
nonbonded pdb=" CD2 LEU A  49 "
          pdb=" OE1 GLN A  53 "
   model   vdw
   4.585 3.460
nonbonded pdb=" OG  SER A  67 "
          pdb=" N   PHE A  68 "
   model   vdw
   4.585 3.120
nonbonded pdb=" CE  LYS A   3 "
          pdb=" CD1 LEU A  60 "
   model   vdw
   4.585 3.860
nonbonded pdb=" O   ILE A  47 "
          pdb=" CG2 ILE A  47 "
   model   vdw
   4.585 3.460
nonbonded pdb=" O   GLN A  12 "
          pdb=" O   PHE A  13 "
   model   vdw
   4.586 3.040
nonbonded pdb=" O   GLN A  12 "
          pdb=" N   THR A  14 "
   model   vdw
   4.586 3.120
nonbonded pdb=" N   PHE A  68 "
          pdb=" O   MSE A  77 "
   model   vdw
   4.586 3.120
nonbonded pdb=" C   LYS A   3 "
          pdb=" O   TYR A  34 "
   model   vdw
   4.586 3.270
nonbonded pdb=" O   ARG A  80 "
          pdb=" CG  ARG A  80 "
   model   vdw
   4.586 3.440
nonbonded pdb=" CB  LEU A  49 "
          pdb=" O   GLN A  53 "
   model   vdw
   4.587 3.440
nonbonded pdb=" NE  ARG A  82 "
          pdb="O    HOH S 135 "
   model   vdw
   4.587 3.120
nonbonded pdb=" CB  SER A  67 "
          pdb=" N   LEU A  81 "
   model   vdw
   4.587 3.520
nonbonded pdb=" O   ILE A  47 "
          pdb=" O   THR A  48 "
   model   vdw
   4.587 3.040
nonbonded pdb="O    HOH S 175 "
          pdb=" CA  GLN A  22 "
   model   vdw sym.op.
   4.587 3.470 -x+1/2,y+1/2,-z+2
nonbonded pdb=" CA  GLN A  22 "
          pdb="O    HOH S 175 "
   model   vdw sym.op.
   4.587 3.470 -x+1/2,y-1/2,-z+2
nonbonded pdb=" CB  SER A  67 "
          pdb=" CG  PHE A  68 "
   model   vdw
   4.587 3.660
nonbonded pdb=" N   GLN A  12 "
          pdb="O    HOH S   7 "
   model   vdw
   4.587 3.120
nonbonded pdb=" CG2 THR A  48 "
          pdb=" CA  LEU A  49 "
   model   vdw
   4.587 3.890
nonbonded pdb=" OH  TYR A  56 "
          pdb=" CB  ARG A  82 "
   model   vdw
   4.587 3.440
nonbonded pdb=" O   LYS A  46 "
          pdb=" O   ILE A  47 "
   model   vdw
   4.588 3.040
nonbonded pdb=" OG  SER A  17 "
          pdb="O    HOH S  34 "
   model   vdw
   4.588 3.040
nonbonded pdb=" CZ  TYR A  56 "
          pdb=" C   LEU A  83 "
   model   vdw
   4.588 3.490
nonbonded pdb=" CB  VAL A  43 "
          pdb=" CA  LEU A  44 "
   model   vdw
   4.588 3.900
nonbonded pdb=" CG  GLU A  30 "
          pdb=" CG  LYS A  46 "
   model   vdw
   4.588 3.840
nonbonded pdb=" CA  ALA A  55 "
          pdb="O    HOH S  98 "
   model   vdw
   4.589 3.470
nonbonded pdb=" CA  THR A  15 "
          pdb=" CA  ASN A  29 "
   model   vdw
   4.589 3.900
nonbonded pdb=" CG  HIS A  64 "
          pdb=" CG2 VAL A  84 "
   model   vdw
   4.589 3.680
nonbonded pdb=" N   TYR A  61 "
          pdb=" O   VAL A  84 "
   model   vdw
   4.589 3.120
nonbonded pdb=" CG  LYS A  69 "
          pdb=" C   VAL A  70 "
   model   vdw
   4.589 3.670
nonbonded pdb=" O   LEU A  37 "
          pdb=" ND2 ASN A  39 "
   model   vdw
   4.590 3.120
nonbonded pdb=" C   GLN A  53 "
          pdb=" CD  GLN A  53 "
   model   vdw
   4.590 3.500
nonbonded pdb=" O   PRO A   8 "
          pdb=" CG  PRO A  58 "
   model   vdw
   4.590 3.440
nonbonded pdb=" O   PRO A   8 "
          pdb=" CG  PRO A   8 "
   model   vdw
   4.590 3.440
nonbonded pdb=" N   ILE A   6 "
          pdb=" CA  LYS A   7 "
   model   vdw
   4.590 3.550
nonbonded pdb=" N   LYS A  46 "
          pdb="O    HOH S  17 "
   model   vdw
   4.590 3.120
nonbonded pdb=" CD1 ILE A  78 "
          pdb=" O   MSE A  77 "
   model   vdw sym.op.
   4.591 3.460 -x+1,y,-z+2
nonbonded pdb=" O   MSE A  77 "
          pdb=" CD1 ILE A  78 "
   model   vdw sym.op.
   4.591 3.460 -x+1,y,-z+2
nonbonded pdb=" O   THR A  14 "
          pdb=" CG2 THR A  14 "
   model   vdw
   4.591 3.460
nonbonded pdb=" CA  TYR A  34 "
          pdb=" C   VAL A  35 "
   model   vdw
   4.591 3.700
nonbonded pdb=" CB  VAL A  63 "
          pdb=" O   HIS A  64 "
   model   vdw
   4.591 3.470
nonbonded pdb=" CD  GLN A  10 "
          pdb=" CA  LEU A  32 "
   model   vdw
   4.591 3.700
nonbonded pdb=" CE2 PHE A  13 "
          pdb=" CB  ALA A  55 "
   model   vdw
   4.592 3.760
nonbonded pdb=" CB  LYS A  69 "
          pdb=" CB  ASP A  79 "
   model   vdw
   4.592 3.840
nonbonded pdb=" C   LYS A  46 "
          pdb=" O   GLY A  74 "
   model   vdw sym.op.
   4.592 3.270 -x+1,y,-z+2
nonbonded pdb=" OG  SER A  27 "
          pdb=" C   LEU A  28 "
   model   vdw
   4.592 3.270
nonbonded pdb=" O   THR A  48 "
          pdb=" CZ  ARG A  80 "
   model   vdw
   4.592 3.270
nonbonded pdb=" CA  TYR A  26 "
          pdb=" CE1 TYR A  26 "
   model   vdw
   4.592 3.770
nonbonded pdb=" C   GLY A  18 "
          pdb=" CD1 TYR A  26 "
   model   vdw
   4.592 3.570
nonbonded pdb=" OH  TYR A  26 "
          pdb=" CA  PRO A  85 "
   model   vdw sym.op.
   4.593 3.470 x,y-1,z
nonbonded pdb=" CD2 TYR A  41 "
          pdb=" CG  TYR A  34 "
   model   vdw sym.op.
   4.593 3.560 -x+1,y,-z+1
nonbonded pdb=" CG  TYR A  34 "
          pdb=" CD2 TYR A  41 "
   model   vdw sym.op.
   4.593 3.560 -x+1,y,-z+1
nonbonded pdb=" C   CYS A  33 "
          pdb=" CD1 TYR A  34 "
   model   vdw
   4.593 3.570
nonbonded pdb=" CA  MSE A  77 "
          pdb=" C   ILE A  78 "
   model   vdw
   4.593 3.700
nonbonded pdb=" CD  ARG A  21 "
          pdb="O    HOH S 135 "
   model   vdw sym.op.
   4.593 3.440 x,y-1,z
nonbonded pdb="O    HOH S 135 "
          pdb=" CD  ARG A  21 "
   model   vdw sym.op.
   4.593 3.440 x,y+1,z
nonbonded pdb=" CB  GLN A  31 "
          pdb=" CD1 ILE A  47 "
   model   vdw
   4.593 3.860
nonbonded pdb=" O   TYR A  56 "
          pdb="O    HOH S 134 "
   model   vdw
   4.593 3.040
nonbonded pdb=" N   VAL A  70 "
          pdb=" CA  GLY A  71 "
   model   vdw
   4.594 3.520
nonbonded pdb=" CB  PRO A  42 "
          pdb="O    HOH S 123 "
   model   vdw
   4.594 3.440
nonbonded pdb=" CA  LYS A   7 "
          pdb=" CB  GLN A  10 "
   model   vdw
   4.594 3.870
nonbonded pdb=" CD1 ILE A   2 "
          pdb=" CB  VAL A  63 "
   model   vdw
   4.594 3.890
nonbonded pdb=" CZ  PHE A  68 "
          pdb=" CG1 ILE A  78 "
   model   vdw
   4.594 3.740
nonbonded pdb=" CG  LYS A   3 "
          pdb=" CD1 PHE A  73 "
   model   vdw sym.op.
   4.594 3.740 -x+1,y+1,-z+2
nonbonded pdb=" O   LYS A  46 "
          pdb=" N   LEU A  76 "
   model   vdw sym.op.
   4.594 3.120 -x+1,y,-z+2
nonbonded pdb=" N   LEU A  81 "
          pdb=" CA  ARG A  82 "
   model   vdw
   4.594 3.550
nonbonded pdb=" CG2 ILE A   2 "
          pdb=" N   VAL A  63 "
   model   vdw
   4.594 3.540
nonbonded pdb=" CG2 VAL A  43 "
          pdb=" CA  LEU A  44 "
   model   vdw
   4.594 3.890
nonbonded pdb=" CG  TYR A  56 "
          pdb=" CB  LEU A  83 "
   model   vdw
   4.595 3.660
nonbonded pdb=" O   ARG A  16 "
          pdb=" CB  SER A  27 "
   model   vdw
   4.595 3.440
nonbonded pdb=" CB  GLN A  53 "
          pdb=" C   PRO A  54 "
   model   vdw
   4.595 3.670
nonbonded pdb=" C   PRO A  25 "
          pdb=" N   SER A  27 "
   model   vdw
   4.595 3.350
nonbonded pdb=" CD2 LEU A  60 "
          pdb=" N   TYR A  61 "
   model   vdw
   4.595 3.540
nonbonded pdb=" CD  PRO A  54 "
          pdb=" N   ALA A  55 "
   model   vdw
   4.595 3.520
nonbonded pdb=" CG  PRO A   8 "
          pdb=" CD1 PHE A  13 "
   model   vdw sym.op.
   4.596 3.740 -x+1/2,y+1/2,-z+1
nonbonded pdb=" N   GLY A  74 "
          pdb=" O   SER A  75 "
   model   vdw
   4.596 3.120
nonbonded pdb=" CG  HIS A  64 "
          pdb=" O   ARG A  82 "
   model   vdw
   4.596 3.260
nonbonded pdb=" N   ASP A  50 "
          pdb="O    HOH S  33 "
   model   vdw
   4.596 3.120
nonbonded pdb=" SG  CYS A  33 "
          pdb=" CA  TYR A  34 "
   model   vdw
   4.596 3.830
nonbonded pdb=" CG  ASP A  50 "
          pdb=" CD  ARG A  82 "
   model   vdw
   4.597 3.670
nonbonded pdb=" CB  SER A  67 "
          pdb=" C   LEU A  81 "
   model   vdw
   4.597 3.670
nonbonded pdb=" O   LEU A  65 "
          pdb=" CE2 PHE A  68 "
   model   vdw
   4.597 3.340
nonbonded pdb=" CG  ARG A  16 "
          pdb=" CG  LEU A  28 "
   model   vdw
   4.597 3.870
nonbonded pdb=" CG2 THR A  62 "
          pdb=" C   VAL A  63 "
   model   vdw
   4.597 3.690
nonbonded pdb=" N   ILE A  47 "
          pdb="O    HOH S 106 "
   model   vdw
   4.598 3.120
nonbonded pdb=" N   LYS A   3 "
          pdb=" O   ASP A  36 "
   model   vdw
   4.598 3.120
nonbonded pdb=" O   LEU A  83 "
          pdb="O    HOH S 120 "
   model   vdw sym.op.
   4.598 3.040 x,y+1,z
nonbonded pdb=" CD1 LEU A  76 "
          pdb=" O   MSE A  77 "
   model   vdw
   4.598 3.460
nonbonded pdb=" O   ASN A  39 "
          pdb=" O   TYR A  41 "
   model   vdw
   4.598 3.040
nonbonded pdb=" C   VAL A  63 "
          pdb="O    HOH S  12 "
   model   vdw
   4.598 3.270
nonbonded pdb=" N   SER A  20 "
          pdb=" C   GLY A  23 "
   model   vdw
   4.599 3.350
nonbonded pdb=" C   GLN A  22 "
          pdb=" O   GLY A  23 "
   model   vdw
   4.599 3.270
nonbonded pdb=" O   ALA A  11 "
          pdb=" N   PHE A  13 "
   model   vdw
   4.599 3.120
nonbonded pdb=" CG  PRO A  54 "
          pdb="O    HOH S  98 "
   model   vdw
   4.599 3.440
nonbonded pdb=" C   LYS A   3 "
          pdb=" CA  VAL A  35 "
   model   vdw
   4.599 3.700
nonbonded pdb=" C   PRO A   8 "
          pdb=" CB  ALA A  11 "
   model   vdw
   4.599 3.690
nonbonded pdb=" CB  SER A  20 "
          pdb=" C   ARG A  21 "
   model   vdw
   4.600 3.670
nonbonded pdb=" CB  LYS A  69 "
          pdb=" C   VAL A  70 "
   model   vdw
   4.600 3.670
nonbonded pdb=" CB  ARG A  82 "
          pdb="O    HOH S 135 "
   model   vdw
   4.600 3.440
nonbonded pdb=" CG  TYR A  56 "
          pdb=" CE2 TYR A  61 "
   model   vdw
   4.601 3.560
nonbonded pdb=" CA  ASP A  50 "
          pdb="O    HOH S  33 "
   model   vdw
   4.601 3.470
nonbonded pdb=" CG  TYR A  56 "
          pdb=" N   ALA A  57 "
   model   vdw
   4.601 3.340
nonbonded pdb=" O   LEU A  81 "
          pdb=" O   ARG A  82 "
   model   vdw
   4.601 3.040
nonbonded pdb=" CA  SER A  67 "
          pdb=" N   ARG A  82 "
   model   vdw
   4.601 3.550
nonbonded pdb=" CB  LEU A  28 "
          pdb=" CA  ASN A  29 "
   model   vdw
   4.601 3.870
nonbonded pdb=" CB  LYS A  69 "
          pdb=" O   VAL A  70 "
   model   vdw
   4.602 3.440
nonbonded pdb=" CA  LYS A  46 "
          pdb=" CG2 ILE A  47 "
   model   vdw
   4.602 3.890
nonbonded pdb=" CA  LEU A  37 "
          pdb=" C   GLY A  38 "
   model   vdw
   4.602 3.700
nonbonded pdb=" CE  LYS A  24 "
          pdb=" CD  ARG A  21 "
   model   vdw sym.op.
   4.602 3.840 -x+1/2,y+1/2,-z+2
nonbonded pdb=" CD  ARG A  21 "
          pdb=" CE  LYS A  24 "
   model   vdw sym.op.
   4.602 3.840 -x+1/2,y-1/2,-z+2
nonbonded pdb=" OD2 ASP A  79 "
          pdb="O    HOH S 160 "
   model   vdw
   4.603 3.040
nonbonded pdb=" N   HIS A  64 "
          pdb=" CD2 HIS A  64 "
   model   vdw
   4.603 3.340
nonbonded pdb=" C   SER A  20 "
          pdb=" N   LYS A  24 "
   model   vdw
   4.603 3.350
nonbonded pdb=" C   SER A  20 "
          pdb=" C   GLN A  22 "
   model   vdw
   4.603 3.500
nonbonded pdb=" N   GLY A  18 "
          pdb="O    HOH S  14 "
   model   vdw sym.op.
   4.603 3.120 x,y-1,z
nonbonded pdb=" CG  LEU A  60 "
          pdb=" N   TYR A  61 "
   model   vdw
   4.603 3.550
nonbonded pdb=" CD1 ILE A   6 "
          pdb=" CG  GLN A  31 "
   model   vdw
   4.604 3.860
nonbonded pdb=" N   SER A   9 "
          pdb=" N   ALA A  11 "
   model   vdw
   4.604 3.200
nonbonded pdb=" CA  VAL A  43 "
          pdb=" C   LEU A  44 "
   model   vdw
   4.604 3.700
nonbonded pdb=" CA  TYR A  61 "
          pdb=" CE1 TYR A  61 "
   model   vdw
   4.604 3.770
nonbonded pdb=" C   VAL A   4 "
          pdb=" CA  TYR A  61 "
   model   vdw
   4.604 3.700
nonbonded pdb=" CB  LEU A  65 "
          pdb=" CA  SER A  66 "
   model   vdw
   4.605 3.870
nonbonded pdb=" N   LEU A  28 "
          pdb=" OD1 ASN A  29 "
   model   vdw
   4.605 3.120
nonbonded pdb=" CD1 ILE A  78 "
          pdb=" CD1 LEU A  81 "
   model   vdw
   4.605 3.880
nonbonded pdb=" N   VAL A  45 "
          pdb="O    HOH S  17 "
   model   vdw
   4.605 3.120
nonbonded pdb=" CB  THR A  15 "
          pdb=" CA  ARG A  16 "
   model   vdw
   4.605 3.900
nonbonded pdb=" CE1 PHE A  13 "
          pdb="O    HOH S 110 "
   model   vdw
   4.605 3.340
nonbonded pdb=" CA  PRO A  85 "
          pdb="O    HOH S  54 "
   model   vdw
   4.605 3.470
nonbonded pdb=" N   THR A  62 "
          pdb=" O   PRO A  85 "
   model   vdw
   4.605 3.120
nonbonded pdb=" N   ASP A  36 "
          pdb=" CA  PRO A  42 "
   model   vdw
   4.606 3.550
nonbonded pdb=" CB  GLU A  30 "
          pdb=" CA  GLN A  31 "
   model   vdw
   4.606 3.870
nonbonded pdb=" CA  SER A  17 "
          pdb=" C   TYR A  26 "
   model   vdw
   4.606 3.700
nonbonded pdb=" O   TYR A  41 "
          pdb=" CG  TYR A  41 "
   model   vdw
   4.606 3.260
nonbonded pdb=" CB  LEU A  76 "
          pdb=" CA  MSE A  77 "
   model   vdw
   4.607 3.870
nonbonded pdb=" CA  ASN A  29 "
          pdb=" CG  GLU A  30 "
   model   vdw
   4.607 3.870
nonbonded pdb=" N   THR A  48 "
          pdb=" CA  LEU A  49 "
   model   vdw
   4.607 3.550
nonbonded pdb=" CG  PRO A   8 "
          pdb=" CB  PRO A  58 "
   model   vdw
   4.607 3.840
nonbonded pdb=" CA  PHE A  68 "
          pdb=" CE2 PHE A  68 "
   model   vdw
   4.608 3.770
nonbonded pdb=" CA  PHE A  13 "
          pdb=" CE1 PHE A  13 "
   model   vdw
   4.608 3.770
nonbonded pdb=" OG  SER A  67 "
          pdb=" CD1 LEU A  81 "
   model   vdw
   4.608 3.460
nonbonded pdb=" N   VAL A  70 "
          pdb=" CD1 LEU A  76 "
   model   vdw
   4.608 3.540
nonbonded pdb=" CB  ALA A  55 "
          pdb=" C   TYR A  56 "
   model   vdw
   4.608 3.690
nonbonded pdb=" N   LEU A  37 "
          pdb=" N   ASN A  39 "
   model   vdw
   4.609 3.200
nonbonded pdb=" CD1 PHE A  13 "
          pdb="O    HOH S 110 "
   model   vdw
   4.609 3.340
nonbonded pdb=" C   ARG A  80 "
          pdb=" CA  ARG A  82 "
   model   vdw
   4.609 3.700
nonbonded pdb=" CD2 TYR A  26 "
          pdb=" CG  PRO A  85 "
   model   vdw sym.op.
   4.609 3.740 x,y-1,z
nonbonded pdb=" N   SER A  66 "
          pdb=" N   PHE A  68 "
   model   vdw
   4.609 3.200
nonbonded pdb=" CB  PHE A  13 "
          pdb=" CB  GLN A  31 "
   model   vdw
   4.609 3.840
nonbonded pdb=" NH2 ARG A  21 "
          pdb=" CG  GLN A  22 "
   model   vdw
   4.610 3.520
nonbonded pdb=" CD2 TYR A  61 "
          pdb=" CD  PRO A  85 "
   model   vdw
   4.610 3.740
nonbonded pdb=" CA  VAL A  63 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   4.610 3.890
nonbonded pdb=" CB  TYR A  61 "
          pdb=" C   THR A  62 "
   model   vdw
   4.610 3.670
nonbonded pdb=" O   TYR A  26 "
          pdb=" OG  SER A  27 "
   model   vdw
   4.610 3.040
nonbonded pdb=" CA  TYR A  61 "
          pdb=" C   THR A  62 "
   model   vdw
   4.610 3.700
nonbonded pdb=" CG2 THR A  14 "
          pdb=" CD  PRO A  58 "
   model   vdw sym.op.
   4.611 3.860 -x+1/2,y-1/2,-z+1
nonbonded pdb=" CA  LEU A  81 "
          pdb=" C   ARG A  82 "
   model   vdw
   4.611 3.700
nonbonded pdb=" CG  GLU A   5 "
          pdb=" CD  LYS A   7 "
   model   vdw
   4.611 3.840
nonbonded pdb=" CA  GLY A  23 "
          pdb=" O   LYS A  24 "
   model   vdw
   4.611 3.440
nonbonded pdb=" N   ASP A  36 "
          pdb=" CA  LEU A  37 "
   model   vdw
   4.611 3.550
nonbonded pdb=" CD  LYS A  69 "
          pdb=" OD1 ASP A  79 "
   model   vdw
   4.611 3.440
nonbonded pdb=" O   GLU A  51 "
          pdb=" O   GLY A  52 "
   model   vdw
   4.611 3.040
nonbonded pdb=" CB  GLN A  72 "
          pdb=" CD2 PHE A  73 "
   model   vdw
   4.612 3.740
nonbonded pdb=" CA  SER A  67 "
          pdb=" N   ARG A  80 "
   model   vdw
   4.612 3.550
nonbonded pdb=" CA  CYS A  33 "
          pdb=" C   TYR A  34 "
   model   vdw
   4.612 3.700
nonbonded pdb=" CD1 LEU A  65 "
          pdb=" CG1 ILE A   2 "
   model   vdw sym.op.
   4.612 3.860 -x+1,y,-z+2
nonbonded pdb=" CG1 ILE A   2 "
          pdb=" CD1 LEU A  65 "
   model   vdw sym.op.
   4.612 3.860 -x+1,y,-z+2
nonbonded pdb=" O   THR A  14 "
          pdb=" O   THR A  15 "
   model   vdw
   4.613 3.040
nonbonded pdb=" O   ASN A  29 "
          pdb=" N   THR A  48 "
   model   vdw
   4.614 3.120
nonbonded pdb=" C   VAL A  35 "
          pdb=" C   PRO A  42 "
   model   vdw
   4.614 3.500
nonbonded pdb=" O   LEU A  49 "
          pdb=" CG  LEU A  49 "
   model   vdw
   4.614 3.470
nonbonded pdb=" CA  PRO A  42 "
          pdb=" CB  VAL A  43 "
   model   vdw
   4.615 3.900
nonbonded pdb=" CG  ARG A  16 "
          pdb=" C   LEU A  28 "
   model   vdw
   4.615 3.670
nonbonded pdb=" OG1 THR A  15 "
          pdb=" CB  ASN A  29 "
   model   vdw
   4.615 3.440
nonbonded pdb=" CG  PRO A  25 "
          pdb=" N   TYR A  26 "
   model   vdw
   4.616 3.520
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" N   ALA A  11 "
   model   vdw
   4.616 3.540
nonbonded pdb=" CD2 LEU A  37 "
          pdb=" O   PHE A  68 "
   model   vdw sym.op.
   4.616 3.460 -x+1,y,-z+2
nonbonded pdb=" CG2 VAL A  63 "
          pdb=" N   HIS A  64 "
   model   vdw
   4.617 3.540
nonbonded pdb=" CA  LEU A  44 "
          pdb=" CB  VAL A  45 "
   model   vdw
   4.618 3.900
nonbonded pdb=" CA  SER A  67 "
          pdb=" CG  PHE A  68 "
   model   vdw
   4.618 3.690
nonbonded pdb=" O   ASN A  29 "
          pdb=" O   GLU A  30 "
   model   vdw
   4.618 3.040
nonbonded pdb=" CA  ILE A   6 "
          pdb=" CA  PRO A  58 "
   model   vdw
   4.618 3.900
nonbonded pdb=" O   ARG A  16 "
          pdb=" OG  SER A  27 "
   model   vdw
   4.618 3.040
nonbonded pdb=" OD1 ASP A  36 "
          pdb=" CA  PRO A  42 "
   model   vdw
   4.619 3.470
nonbonded pdb=" CD  GLN A  10 "
          pdb=" CD1 LEU A  44 "
   model   vdw
   4.619 3.690
nonbonded pdb=" O   ILE A   2 "
          pdb=" CD1 ILE A   2 "
   model   vdw
   4.620 3.460
nonbonded pdb=" CA  GLY A  59 "
          pdb=" C   LEU A  60 "
   model   vdw
   4.620 3.670
nonbonded pdb=" CB  VAL A  35 "
          pdb=" CG2 VAL A  45 "
   model   vdw
   4.620 3.890
nonbonded pdb=" O   PHE A  68 "
          pdb=" CG  PHE A  68 "
   model   vdw
   4.621 3.260
nonbonded pdb=" OE1 GLN A  31 "
          pdb=" C   TYR A  56 "
   model   vdw
   4.621 3.270
nonbonded pdb=" CB  VAL A  19 "
          pdb=" CA  SER A  20 "
   model   vdw
   4.621 3.900
nonbonded pdb=" CA  ARG A  16 "
          pdb=" O   SER A  17 "
   model   vdw
   4.621 3.470
nonbonded pdb=" O   LYS A   3 "
          pdb=" O   VAL A   4 "
   model   vdw
   4.622 3.040
nonbonded pdb=" C   ALA A  11 "
          pdb=" O   TYR A  56 "
   model   vdw
   4.622 3.270
nonbonded pdb=" CA  GLN A  10 "
          pdb=" C   ALA A  11 "
   model   vdw
   4.623 3.700
nonbonded pdb=" CG  LYS A  69 "
          pdb=" O   VAL A  70 "
   model   vdw
   4.623 3.440
nonbonded pdb=" CG  LEU A  49 "
          pdb=" N   ASP A  50 "
   model   vdw
   4.623 3.550
nonbonded pdb=" N   LYS A  69 "
          pdb=" N   MSE A  77 "
   model   vdw
   4.623 3.200
nonbonded pdb=" CA  TYR A  34 "
          pdb=" CA  LEU A  44 "
   model   vdw
   4.623 3.900
nonbonded pdb=" C   ASN A  39 "
          pdb=" C   TYR A  41 "
   model   vdw
   4.623 3.500
nonbonded pdb=" CE  LYS A  69 "
          pdb="O    HOH S 160 "
   model   vdw
   4.623 3.440
nonbonded pdb=" CG2 VAL A  84 "
          pdb="O    HOH S  81 "
   model   vdw sym.op.
   4.624 3.460 x,y+1,z
nonbonded pdb=" CB  LYS A   7 "
          pdb=" CG  GLU A  40 "
   model   vdw sym.op.
   4.625 3.840 -x+1,y,-z+1
nonbonded pdb=" CB  ASN A  39 "
          pdb="O    HOH S 123 "
   model   vdw
   4.625 3.440
nonbonded pdb=" O   SER A  66 "
          pdb=" C   PHE A  68 "
   model   vdw
   4.625 3.270
nonbonded pdb=" O   ARG A  16 "
          pdb=" OG  SER A  17 "
   model   vdw
   4.625 3.040
nonbonded pdb=" CA  LYS A   3 "
          pdb=" C   VAL A   4 "
   model   vdw
   4.625 3.700
nonbonded pdb=" C   GLU A  51 "
          pdb=" CA  GLN A  53 "
   model   vdw
   4.625 3.700
nonbonded pdb=" CB  VAL A  84 "
          pdb="O    HOH S 120 "
   model   vdw sym.op.
   4.625 3.470 x,y+1,z
nonbonded pdb=" CG  ARG A  16 "
          pdb=" CA  LEU A  28 "
   model   vdw
   4.626 3.870
nonbonded pdb=" C   HIS A  64 "
          pdb=" C   SER A  66 "
   model   vdw
   4.626 3.500
nonbonded pdb=" O   PRO A   8 "
          pdb=" C   GLN A  10 "
   model   vdw
   4.626 3.270
nonbonded pdb=" C   SER A  20 "
          pdb=" CA  GLY A  23 "
   model   vdw
   4.626 3.670
nonbonded pdb=" CA  GLU A   5 "
          pdb=" CA  LEU A  60 "
   model   vdw
   4.627 3.900
nonbonded pdb=" O   LEU A  81 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   4.627 3.460
nonbonded pdb=" CA  GLN A  12 "
          pdb=" C   PHE A  13 "
   model   vdw
   4.627 3.700
nonbonded pdb=" CA  ASP A  79 "
          pdb=" CB  ARG A  80 "
   model   vdw
   4.628 3.870
nonbonded pdb=" CA  GLY A  52 "
          pdb=" O   GLN A  53 "
   model   vdw
   4.628 3.440
nonbonded pdb=" C   ILE A   6 "
          pdb=" CD1 ILE A   6 "
   model   vdw
   4.628 3.690
nonbonded pdb=" N   GLN A  12 "
          pdb=" CD  GLN A  12 "
   model   vdw
   4.628 3.350
nonbonded pdb=" CA  GLU A  30 "
          pdb=" CB  GLN A  31 "
   model   vdw
   4.629 3.870
nonbonded pdb=" CB  LYS A   7 "
          pdb=" C   PRO A   8 "
   model   vdw
   4.629 3.670
nonbonded pdb=" C   LEU A  81 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   4.630 3.690
nonbonded pdb=" O   PRO A  54 "
          pdb=" CA  TYR A  56 "
   model   vdw
   4.630 3.470
nonbonded pdb=" NH1 ARG A  21 "
          pdb=" CE1 HIS A  64 "
   model   vdw sym.op.
   4.630 3.340 x,y-1,z
nonbonded pdb=" CB  TYR A  56 "
          pdb=" C   ALA A  57 "
   model   vdw
   4.630 3.670
nonbonded pdb=" C   TYR A  56 "
          pdb=" CD1 TYR A  56 "
   model   vdw
   4.630 3.570
nonbonded pdb=" N   VAL A  19 "
          pdb="O    HOH S  14 "
   model   vdw sym.op.
   4.630 3.120 x,y-1,z
nonbonded pdb=" CB  VAL A   4 "
          pdb=" CA  GLU A   5 "
   model   vdw
   4.630 3.900
nonbonded pdb=" N   ALA A  11 "
          pdb="O    HOH S   7 "
   model   vdw
   4.631 3.120
nonbonded pdb=" CG1 VAL A  19 "
          pdb=" CA  LYS A  24 "
   model   vdw
   4.631 3.890
nonbonded pdb=" CA  GLU A  30 "
          pdb=" CA  THR A  48 "
   model   vdw
   4.631 3.900
nonbonded pdb=" C   SER A   9 "
          pdb=" O   GLN A  10 "
   model   vdw
   4.632 3.270
nonbonded pdb=" CA  LEU A  60 "
          pdb=" CG  TYR A  61 "
   model   vdw
   4.632 3.690
nonbonded pdb=" NZ  LYS A  24 "
          pdb=" O   ARG A  21 "
   model   vdw sym.op.
   4.632 3.120 -x+1/2,y+1/2,-z+2
nonbonded pdb=" O   ARG A  21 "
          pdb=" NZ  LYS A  24 "
   model   vdw sym.op.
   4.632 3.120 -x+1/2,y-1/2,-z+2
nonbonded pdb=" CB  LYS A   3 "
          pdb=" CA  VAL A   4 "
   model   vdw
   4.632 3.870
nonbonded pdb=" CD  GLU A   5 "
          pdb=" N   ILE A   6 "
   model   vdw
   4.633 3.350
nonbonded pdb=" C   ARG A  21 "
          pdb=" CD  ARG A  21 "
   model   vdw
   4.633 3.670
nonbonded pdb=" N   TYR A  41 "
          pdb=" CE2 TYR A  41 "
   model   vdw
   4.633 3.420
nonbonded pdb=" CG  LYS A   3 "
          pdb=" CB  ASP A  36 "
   model   vdw
   4.633 3.840
nonbonded pdb=" OG1 THR A  15 "
          pdb=" OG  SER A  27 "
   model   vdw
   4.633 3.040
nonbonded pdb=" O   GLU A   5 "
          pdb=" O   ILE A   6 "
   model   vdw
   4.634 3.040
nonbonded pdb=" CB  GLU A  40 "
          pdb=" CE2 TYR A  41 "
   model   vdw
   4.634 3.740
nonbonded pdb=" C   ASN A  29 "
          pdb=" CA  THR A  48 "
   model   vdw
   4.634 3.700
nonbonded pdb=" OG1 THR A  62 "
          pdb=" C   VAL A  63 "
   model   vdw
   4.635 3.270
nonbonded pdb=" C   ASP A  50 "
          pdb=" CB  GLN A  53 "
   model   vdw
   4.635 3.670
nonbonded pdb=" C   VAL A  63 "
          pdb=" OG  SER A  67 "
   model   vdw
   4.635 3.270
nonbonded pdb=" CA  VAL A  84 "
          pdb="O    HOH S 120 "
   model   vdw sym.op.
   4.635 3.470 x,y+1,z
nonbonded pdb=" CD  ARG A  21 "
          pdb=" OE1 GLU A  51 "
   model   vdw sym.op.
   4.635 3.440 -x+1/2,y-1/2,-z+2
nonbonded pdb=" O   PHE A  73 "
          pdb="O    HOH S   4 "
   model   vdw
   4.635 3.040
nonbonded pdb=" CG  TYR A  34 "
          pdb=" N   VAL A  35 "
   model   vdw
   4.636 3.340
nonbonded pdb=" CG2 VAL A  19 "
          pdb=" N   SER A  20 "
   model   vdw
   4.636 3.540
nonbonded pdb=" O   LEU A  65 "
          pdb=" C   PHE A  68 "
   model   vdw
   4.636 3.270
nonbonded pdb=" ND1 HIS A  64 "
          pdb="O    HOH S  35 "
   model   vdw
   4.636 3.120
nonbonded pdb=" N   PHE A  68 "
          pdb=" N   ASP A  79 "
   model   vdw
   4.637 3.200
nonbonded pdb=" C   ASP A  36 "
          pdb=" CD1 LEU A  65 "
   model   vdw sym.op.
   4.637 3.690 -x+1,y,-z+2
nonbonded pdb=" CA  VAL A  45 "
          pdb=" C   GLY A  74 "
   model   vdw sym.op.
   4.637 3.700 -x+1,y,-z+2
nonbonded pdb=" C   TYR A  56 "
          pdb="O    HOH S 134 "
   model   vdw
   4.637 3.270
nonbonded pdb=" O   GLN A  31 "
          pdb=" CG2 ILE A  47 "
   model   vdw
   4.638 3.460
nonbonded pdb=" CG  PRO A  42 "
          pdb="O    HOH S 123 "
   model   vdw
   4.638 3.440
nonbonded pdb=" CA  LYS A   3 "
          pdb=" CG2 VAL A   4 "
   model   vdw
   4.638 3.890
nonbonded pdb=" CA  LEU A  76 "
          pdb=" O   MSE A  77 "
   model   vdw
   4.638 3.470
nonbonded pdb=" N   ALA A  55 "
          pdb="O    HOH S  98 "
   model   vdw
   4.638 3.120
nonbonded pdb=" CA  ALA A  11 "
          pdb=" O   GLN A  12 "
   model   vdw
   4.639 3.470
nonbonded pdb=" CD1 ILE A  78 "
          pdb=" N   ILE A  78 "
   model   vdw sym.op.
   4.639 3.540 -x+1,y,-z+2
nonbonded pdb=" N   ILE A  78 "
          pdb=" CD1 ILE A  78 "
   model   vdw sym.op.
   4.639 3.540 -x+1,y,-z+2
nonbonded pdb=" N   PRO A   8 "
          pdb="O    HOH S 117 "
   model   vdw sym.op.
   4.639 3.120 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CA  PHE A  13 "
          pdb=" CE2 PHE A  13 "
   model   vdw
   4.639 3.770
nonbonded pdb=" N   LEU A  32 "
          pdb=" O   VAL A  45 "
   model   vdw
   4.639 3.120
nonbonded pdb=" OG  SER A  66 "
          pdb=" CA  SER A  67 "
   model   vdw
   4.640 3.470
nonbonded pdb=" C   LYS A   7 "
          pdb=" CG  GLN A  10 "
   model   vdw
   4.640 3.670
nonbonded pdb=" CB  PRO A   8 "
          pdb=" CZ  PHE A  13 "
   model   vdw sym.op.
   4.640 3.740 -x+1/2,y+1/2,-z+1
nonbonded pdb=" O   LEU A  83 "
          pdb=" CG  LEU A  83 "
   model   vdw
   4.640 3.470
nonbonded pdb=" OG  SER A  20 "
          pdb=" CB  GLN A  22 "
   model   vdw
   4.640 3.440
nonbonded pdb=" CB  CYS A  33 "
          pdb=" C   TYR A  34 "
   model   vdw
   4.640 3.670
nonbonded pdb=" C   LEU A  83 "
          pdb=" CG1 VAL A  84 "
   model   vdw
   4.641 3.690
nonbonded pdb=" OG1 THR A  15 "
          pdb=" ND2 ASN A  29 "
   model   vdw
   4.641 3.120
nonbonded pdb=" CD2 LEU A  44 "
          pdb="O    HOH S  17 "
   model   vdw
   4.641 3.460
nonbonded pdb=" O   VAL A   4 "
          pdb=" CG  TYR A  61 "
   model   vdw
   4.642 3.260
nonbonded pdb=" CG1 VAL A  63 "
          pdb=" CG  LEU A  81 "
   model   vdw
   4.642 3.890
nonbonded pdb=" CD2 TYR A  41 "
          pdb=" CD2 TYR A  34 "
   model   vdw sym.op.
   4.642 3.640 -x+1,y,-z+1
nonbonded pdb=" CD2 TYR A  34 "
          pdb=" CD2 TYR A  41 "
   model   vdw sym.op.
   4.642 3.640 -x+1,y,-z+1
nonbonded pdb=" CA  ILE A   2 "
          pdb=" C   LYS A   3 "
   model   vdw
   4.642 3.700
nonbonded pdb=" CA  SER A  67 "
          pdb=" CG  ARG A  82 "
   model   vdw
   4.642 3.870
nonbonded pdb=" C   TYR A  61 "
          pdb=" N   VAL A  63 "
   model   vdw
   4.642 3.350
nonbonded pdb=" CA  ASP A  36 "
          pdb=" C   LEU A  37 "
   model   vdw
   4.643 3.700
nonbonded pdb=" CA  LYS A  46 "
          pdb=" C   ILE A  47 "
   model   vdw
   4.643 3.700
nonbonded pdb=" CA  LEU A  76 "
          pdb=" CB  MSE A  77 "
   model   vdw
   4.643 3.870
nonbonded pdb=" CA  GLU A  51 "
          pdb=" C   GLY A  52 "
   model   vdw
   4.643 3.700
nonbonded pdb=" CA  GLY A  18 "
          pdb="O    HOH S  85 "
   model   vdw
   4.643 3.440
nonbonded pdb=" CG  GLU A  30 "
          pdb=" N   GLN A  31 "
   model   vdw
   4.643 3.520
nonbonded pdb=" CB  LYS A  24 "
          pdb=" C   PRO A  25 "
   model   vdw
   4.644 3.670
nonbonded pdb=" CG  LEU A  76 "
          pdb=" CA  MSE A  77 "
   model   vdw
   4.645 3.900
nonbonded pdb=" C   VAL A  70 "
          pdb="O    HOH S  16 "
   model   vdw
   4.645 3.270
nonbonded pdb=" CG2 VAL A  19 "
          pdb=" O   LYS A  24 "
   model   vdw
   4.645 3.460
nonbonded pdb=" NH1 ARG A  21 "
          pdb=" NE2 GLN A  22 "
   model   vdw
   4.645 3.200
nonbonded pdb=" CG2 THR A  62 "
          pdb=" CB  VAL A  84 "
   model   vdw
   4.645 3.890
nonbonded pdb=" CA  TYR A  34 "
          pdb=" CE2 TYR A  34 "
   model   vdw
   4.645 3.770
nonbonded pdb=" CG  LEU A  37 "
          pdb=" CD1 LEU A  76 "
   model   vdw sym.op.
   4.646 3.890 -x+1,y,-z+2
nonbonded pdb=" CD1 LEU A  76 "
          pdb=" CG  LEU A  37 "
   model   vdw sym.op.
   4.646 3.890 -x+1,y,-z+2
nonbonded pdb=" OG1 THR A  48 "
          pdb=" N   LEU A  49 "
   model   vdw
   4.647 3.120
nonbonded pdb=" CA  GLY A  74 "
          pdb="O    HOH S   4 "
   model   vdw
   4.647 3.440
nonbonded pdb=" CA  SER A   9 "
          pdb=" CG  GLN A  10 "
   model   vdw
   4.647 3.870
nonbonded pdb=" O   LEU A  37 "
          pdb=" CA  ASN A  39 "
   model   vdw
   4.647 3.470
nonbonded pdb=" C   LEU A  60 "
          pdb=" N   THR A  62 "
   model   vdw
   4.647 3.350
nonbonded pdb=" CA  VAL A  19 "
          pdb=" N   TYR A  26 "
   model   vdw
   4.647 3.550
nonbonded pdb=" CG1 VAL A   4 "
          pdb=" CG  LEU A  83 "
   model   vdw
   4.647 3.890
nonbonded pdb=" CG2 THR A  62 "
          pdb=" CA  VAL A  63 "
   model   vdw
   4.647 3.890
nonbonded pdb=" C   ILE A   6 "
          pdb=" C   PRO A  58 "
   model   vdw
   4.648 3.500
nonbonded pdb=" CB  GLN A  53 "
          pdb="O    HOH S 135 "
   model   vdw
   4.648 3.440
nonbonded pdb=" CG1 VAL A  70 "
          pdb=" N   SER A  75 "
   model   vdw
   4.648 3.540
nonbonded pdb=" CG1 VAL A  70 "
          pdb=" C   SER A  75 "
   model   vdw
   4.648 3.690
nonbonded pdb=" CZ  TYR A  41 "
          pdb=" CD2 TYR A  34 "
   model   vdw sym.op.
   4.648 3.560 -x+1,y,-z+1
nonbonded pdb=" CD2 TYR A  34 "
          pdb=" CZ  TYR A  41 "
   model   vdw sym.op.
   4.648 3.560 -x+1,y,-z+1
nonbonded pdb=" CG1 VAL A  45 "
          pdb=" CA  LEU A  76 "
   model   vdw sym.op.
   4.649 3.890 -x+1,y,-z+2
nonbonded pdb=" CA  TYR A  61 "
          pdb=" O   PRO A  85 "
   model   vdw
   4.649 3.470
nonbonded pdb=" CA  LEU A  83 "
          pdb=" C   VAL A  84 "
   model   vdw
   4.649 3.700
nonbonded pdb=" O   SER A  75 "
          pdb=" CA  MSE A  77 "
   model   vdw
   4.649 3.470
nonbonded pdb=" O   PRO A  25 "
          pdb=" O   TYR A  26 "
   model   vdw
   4.649 3.040
nonbonded pdb=" N   TYR A  34 "
          pdb=" CE2 TYR A  34 "
   model   vdw
   4.650 3.420
nonbonded pdb=" OE2 GLU A   5 "
          pdb=" O   ILE A   6 "
   model   vdw
   4.650 3.040
nonbonded pdb=" CB  VAL A  19 "
          pdb=" C   LYS A  24 "
   model   vdw
   4.650 3.700
nonbonded pdb=" OE2 GLU A  51 "
          pdb=" CB  ARG A  21 "
   model   vdw sym.op.
   4.651 3.440 -x+1/2,y+1/2,-z+2
nonbonded pdb=" CB  ARG A  21 "
          pdb=" OE2 GLU A  51 "
   model   vdw sym.op.
   4.651 3.440 -x+1/2,y-1/2,-z+2
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" CA  LYS A   7 "
   model   vdw
   4.651 3.890
nonbonded pdb=" O   SER A  27 "
          pdb=" O   LEU A  28 "
   model   vdw
   4.651 3.040
nonbonded pdb=" CB  LEU A  76 "
          pdb=" CD1 ILE A  78 "
   model   vdw sym.op.
   4.651 3.860 -x+1,y,-z+2
nonbonded pdb=" CG  LEU A  65 "
          pdb=" CD2 LEU A  37 "
   model   vdw sym.op.
   4.652 3.890 -x+1,y,-z+2
nonbonded pdb=" CD2 LEU A  37 "
          pdb=" CG  LEU A  65 "
   model   vdw sym.op.
   4.652 3.890 -x+1,y,-z+2
nonbonded pdb=" CD  LYS A   3 "
          pdb=" N   VAL A   4 "
   model   vdw
   4.652 3.520
nonbonded pdb=" C   PRO A   8 "
          pdb=" CG  PRO A  58 "
   model   vdw
   4.653 3.670
nonbonded pdb=" CB  ILE A   6 "
          pdb=" OE1 GLN A  10 "
   model   vdw
   4.653 3.470
nonbonded pdb=" C   TYR A  34 "
          pdb=" C   VAL A  43 "
   model   vdw
   4.653 3.500
nonbonded pdb=" O   LEU A  60 "
          pdb=" O   VAL A  84 "
   model   vdw
   4.653 3.040
nonbonded pdb=" N   LYS A  69 "
          pdb=" N   ASP A  79 "
   model   vdw
   4.653 3.200
nonbonded pdb=" C   THR A  62 "
          pdb=" CA  LEU A  83 "
   model   vdw
   4.653 3.700
nonbonded pdb=" O   LYS A  46 "
          pdb=" C   SER A  75 "
   model   vdw sym.op.
   4.653 3.270 -x+1,y,-z+2
nonbonded pdb=" SG  CYS A  33 "
          pdb=" CD1 ILE A  47 "
   model   vdw
   4.653 3.820
nonbonded pdb=" N   PHE A  73 "
          pdb=" N   SER A  75 "
   model   vdw
   4.653 3.200
nonbonded pdb=" O   GLU A  40 "
          pdb=" CE2 TYR A  41 "
   model   vdw
   4.653 3.340
nonbonded pdb=" CA  PHE A  68 "
          pdb=" O   LYS A  69 "
   model   vdw
   4.654 3.470
nonbonded pdb=" O   ASP A  50 "
          pdb=" C   GLN A  53 "
   model   vdw
   4.654 3.270
nonbonded pdb=" C   LEU A  37 "
          pdb=" CA  ASN A  39 "
   model   vdw
   4.655 3.700
nonbonded pdb=" CG  TYR A  61 "
          pdb=" N   PRO A  85 "
   model   vdw
   4.655 3.340
nonbonded pdb=" C   ALA A  55 "
          pdb=" CD2 TYR A  56 "
   model   vdw
   4.656 3.570
nonbonded pdb=" CD1 ILE A   6 "
          pdb=" OE1 GLN A  31 "
   model   vdw
   4.656 3.460
nonbonded pdb=" CB  THR A  62 "
          pdb=" CE2 PHE A  73 "
   model   vdw sym.op.
   4.656 3.770 -x+1,y+1,-z+2
nonbonded pdb=" C   GLY A  38 "
          pdb=" OD1 ASN A  39 "
   model   vdw
   4.656 3.270
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" CA  GLN A  10 "
   model   vdw
   4.656 3.890
nonbonded pdb=" CA  THR A  15 "
          pdb=" O   ARG A  16 "
   model   vdw
   4.656 3.470
nonbonded pdb=" CA  THR A  14 "
          pdb=" C   THR A  15 "
   model   vdw
   4.657 3.700
nonbonded pdb=" N   SER A   9 "
          pdb=" CG2 THR A  15 "
   model   vdw sym.op.
   4.657 3.540 -x+1/2,y+1/2,-z+1
nonbonded pdb=" C   LYS A  46 "
          pdb=" CB  SER A  75 "
   model   vdw sym.op.
   4.657 3.670 -x+1,y,-z+2
nonbonded pdb=" CA  PRO A  42 "
          pdb=" C   VAL A  43 "
   model   vdw
   4.657 3.700
nonbonded pdb=" CA  LEU A  60 "
          pdb=" CB  TYR A  61 "
   model   vdw
   4.657 3.870
nonbonded pdb=" CE1 TYR A  34 "
          pdb=" C   VAL A  43 "
   model   vdw
   4.657 3.570
nonbonded pdb=" CA  LYS A  69 "
          pdb=" CD1 LEU A  76 "
   model   vdw
   4.658 3.890
nonbonded pdb=" CG  TYR A  26 "
          pdb=" CA  SER A  27 "
   model   vdw
   4.658 3.690
nonbonded pdb=" CB  PRO A  58 "
          pdb=" CA  GLY A  59 "
   model   vdw
   4.658 3.840
nonbonded pdb=" N   SER A  67 "
          pdb=" O   PHE A  68 "
   model   vdw
   4.658 3.120
nonbonded pdb=" CD1 ILE A   6 "
          pdb=" CD2 TYR A  56 "
   model   vdw
   4.659 3.760
nonbonded pdb=" CA  SER A  27 "
          pdb=" CB  LEU A  28 "
   model   vdw
   4.659 3.870
nonbonded pdb=" CG  GLN A  22 "
          pdb=" CG  GLU A  51 "
   model   vdw sym.op.
   4.659 3.840 -x+1/2,y-1/2,-z+2
nonbonded pdb=" CB  ASN A  39 "
          pdb=" C   GLU A  40 "
   model   vdw
   4.659 3.670
nonbonded pdb=" NE2 GLN A  31 "
          pdb=" O   LEU A  32 "
   model   vdw
   4.659 3.120
nonbonded pdb=" C   GLU A  30 "
          pdb=" CG  GLN A  31 "
   model   vdw
   4.659 3.670
nonbonded pdb=" CB  ALA A  57 "
          pdb=" C   PRO A  58 "
   model   vdw
   4.660 3.690
nonbonded pdb=" CB  THR A  15 "
          pdb=" OG  SER A  27 "
   model   vdw
   4.660 3.470
nonbonded pdb=" CD1 ILE A   2 "
          pdb=" CG2 VAL A   4 "
   model   vdw
   4.660 3.880
nonbonded pdb=" CA  GLN A  12 "
          pdb=" O   PHE A  13 "
   model   vdw
   4.662 3.470
nonbonded pdb=" N   THR A  62 "
          pdb=" C   PRO A  85 "
   model   vdw
   4.662 3.350
nonbonded pdb=" CB  GLN A  72 "
          pdb=" CA  PHE A  73 "
   model   vdw
   4.662 3.870
nonbonded pdb=" O   TYR A  26 "
          pdb=" N   LEU A  28 "
   model   vdw
   4.662 3.120
nonbonded pdb=" CA  GLU A  30 "
          pdb="O    HOH S 151 "
   model   vdw
   4.662 3.470
nonbonded pdb=" CA  LYS A   7 "
          pdb=" OE2 GLU A  40 "
   model   vdw sym.op.
   4.662 3.470 -x+1,y,-z+1
nonbonded pdb=" CB  ILE A   2 "
          pdb=" CG2 VAL A  63 "
   model   vdw
   4.663 3.890
nonbonded pdb=" C   GLU A  40 "
          pdb=" CE2 TYR A  41 "
   model   vdw
   4.663 3.570
nonbonded pdb=" CG2 THR A  62 "
          pdb="O    HOH S  12 "
   model   vdw
   4.663 3.460
nonbonded pdb=" CA  TYR A  61 "
          pdb=" CE2 TYR A  61 "
   model   vdw
   4.664 3.770
nonbonded pdb=" CA  LYS A  69 "
          pdb=" CG2 VAL A  70 "
   model   vdw
   4.664 3.890
nonbonded pdb=" O   VAL A  35 "
          pdb=" CB  LEU A  37 "
   model   vdw
   4.664 3.440
nonbonded pdb=" N   VAL A   4 "
          pdb=" N   TYR A  61 "
   model   vdw
   4.665 3.200
nonbonded pdb=" C   VAL A   4 "
          pdb=" CD2 LEU A  60 "
   model   vdw
   4.665 3.690
nonbonded pdb=" O   VAL A  43 "
          pdb=" CG2 VAL A  45 "
   model   vdw
   4.665 3.460
nonbonded pdb=" O   ARG A  16 "
          pdb="O    HOH S  34 "
   model   vdw
   4.665 3.040
nonbonded pdb=" CB  VAL A  63 "
          pdb=" OG  SER A  67 "
   model   vdw
   4.665 3.470
nonbonded pdb=" CG  LEU A  28 "
          pdb=" N   ASN A  29 "
   model   vdw
   4.665 3.550
nonbonded pdb=" CA  PHE A  73 "
          pdb=" C   GLY A  74 "
   model   vdw
   4.665 3.700
nonbonded pdb=" O   GLY A  71 "
          pdb=" C   GLY A  74 "
   model   vdw
   4.666 3.270
nonbonded pdb=" CA  LEU A  83 "
          pdb=" CB  VAL A  84 "
   model   vdw
   4.666 3.900
nonbonded pdb=" CD  GLU A   5 "
          pdb=" CD  LYS A   7 "
   model   vdw
   4.666 3.670
nonbonded pdb=" CB  LEU A  44 "
          pdb=" CA  VAL A  45 "
   model   vdw
   4.666 3.870
nonbonded pdb=" CA  PRO A  25 "
          pdb=" CB  TYR A  26 "
   model   vdw
   4.666 3.870
nonbonded pdb=" C   GLN A  31 "
          pdb=" CA  LYS A  46 "
   model   vdw
   4.666 3.700
nonbonded pdb=" CZ  PHE A  68 "
          pdb=" CD1 ILE A  78 "
   model   vdw
   4.666 3.760
nonbonded pdb=" CE1 TYR A  26 "
          pdb=" N   SER A  27 "
   model   vdw
   4.667 3.420
nonbonded pdb=" O   LEU A  83 "
          pdb=" O   VAL A  84 "
   model   vdw
   4.668 3.040
nonbonded pdb=" CD  LYS A  24 "
          pdb=" CD  ARG A  82 "
   model   vdw sym.op.
   4.668 3.840 -x+1/2,y-1/2,-z+2
nonbonded pdb=" CD  ARG A  82 "
          pdb=" CD  LYS A  24 "
   model   vdw sym.op.
   4.668 3.840 -x+1/2,y+1/2,-z+2
nonbonded pdb=" N   GLY A  18 "
          pdb=" N   TYR A  26 "
   model   vdw
   4.668 3.200
nonbonded pdb=" CB  LEU A  60 "
          pdb=" CA  TYR A  61 "
   model   vdw
   4.668 3.870
nonbonded pdb=" CD  GLN A  53 "
          pdb=" C   SER A  20 "
   model   vdw sym.op.
   4.668 3.500 x,y+1,z
nonbonded pdb=" C   SER A  20 "
          pdb=" CD  GLN A  53 "
   model   vdw sym.op.
   4.668 3.500 x,y-1,z
nonbonded pdb=" CG  LEU A  32 "
          pdb=" O   VAL A  45 "
   model   vdw
   4.668 3.470
nonbonded pdb=" O   LYS A   3 "
          pdb=" C   TYR A  34 "
   model   vdw
   4.669 3.270
nonbonded pdb=" CD1 PHE A  13 "
          pdb=" N   THR A  15 "
   model   vdw
   4.669 3.420
nonbonded pdb=" O   SER A  66 "
          pdb=" OG  SER A  67 "
   model   vdw
   4.669 3.040
nonbonded pdb=" SG  CYS A  33 "
          pdb=" CA  VAL A  45 "
   model   vdw
   4.670 3.830
nonbonded pdb=" CA  VAL A  70 "
          pdb=" CA  LEU A  76 "
   model   vdw
   4.670 3.900
nonbonded pdb=" C   TYR A  61 "
          pdb=" CZ  PHE A  73 "
   model   vdw sym.op.
   4.670 3.570 -x+1,y+1,-z+2
nonbonded pdb=" CB  VAL A  63 "
          pdb=" O   ARG A  82 "
   model   vdw
   4.670 3.470
nonbonded pdb=" CB  THR A  62 "
          pdb=" O   VAL A  63 "
   model   vdw
   4.670 3.470
nonbonded pdb=" CB  VAL A  35 "
          pdb=" CA  ASP A  36 "
   model   vdw
   4.671 3.900
nonbonded pdb=" C   LYS A   3 "
          pdb=" CB  ASP A  36 "
   model   vdw
   4.671 3.670
nonbonded pdb=" C   PHE A  68 "
          pdb=" CD1 PHE A  68 "
   model   vdw
   4.671 3.570
nonbonded pdb=" C   GLU A   5 "
          pdb=" CA  CYS A  33 "
   model   vdw
   4.671 3.700
nonbonded pdb=" CG2 VAL A  35 "
          pdb=" N   ASP A  36 "
   model   vdw
   4.671 3.540
nonbonded pdb=" CA  LEU A  83 "
          pdb=" O   VAL A  84 "
   model   vdw
   4.671 3.470
nonbonded pdb=" N   SER A  20 "
          pdb="O    HOH S  81 "
   model   vdw
   4.672 3.120
nonbonded pdb=" C   ARG A  21 "
          pdb=" NE2 GLN A  53 "
   model   vdw sym.op.
   4.672 3.350 x,y-1,z
nonbonded pdb=" CA  LEU A  60 "
          pdb=" O   TYR A  61 "
   model   vdw
   4.672 3.470
nonbonded pdb=" CB  PHE A  13 "
          pdb=" C   ASN A  29 "
   model   vdw
   4.673 3.670
nonbonded pdb=" N   GLN A  10 "
          pdb=" OE1 GLN A  10 "
   model   vdw
   4.673 3.120
nonbonded pdb=" CG  HIS A  64 "
          pdb=" CB  SER A  66 "
   model   vdw
   4.673 3.660
nonbonded pdb=" CE2 PHE A  73 "
          pdb="SE    SE Z   5 "
   model   vdw sym.op.
   4.673 3.720 -x+1/2,y+1/2,-z+1
nonbonded pdb=" C   GLN A  22 "
          pdb=" CD  GLN A  22 "
   model   vdw
   4.673 3.500
nonbonded pdb=" N   LYS A   3 "
          pdb=" CZ  PHE A  73 "
   model   vdw sym.op.
   4.673 3.420 -x+1,y+1,-z+2
nonbonded pdb=" N   ARG A  80 "
          pdb=" CZ  ARG A  82 "
   model   vdw
   4.673 3.350
nonbonded pdb=" N   GLU A   5 "
          pdb=" CA  TYR A  34 "
   model   vdw
   4.674 3.550
nonbonded pdb=" O   LEU A  37 "
          pdb=" CD2 LEU A  37 "
   model   vdw
   4.674 3.460
nonbonded pdb=" C   THR A  48 "
          pdb=" CD2 LEU A  49 "
   model   vdw
   4.674 3.690
nonbonded pdb=" CG1 ILE A  78 "
          pdb=" N   ASP A  79 "
   model   vdw
   4.674 3.520
nonbonded pdb=" N   LEU A  49 "
          pdb="O    HOH S  33 "
   model   vdw
   4.674 3.120
nonbonded pdb=" CD  PRO A  25 "
          pdb=" N   TYR A  26 "
   model   vdw
   4.674 3.520
nonbonded pdb=" CG2 THR A  15 "
          pdb=" C   LEU A  28 "
   model   vdw
   4.674 3.690
nonbonded pdb=" N   ILE A  78 "
          pdb="SE    SE Z   4 "
   model   vdw sym.op.
   4.675 3.500 x+1/2,y+3/2,z+2
nonbonded pdb=" OD1 ASP A  79 "
          pdb=" CA  ARG A  80 "
   model   vdw
   4.675 3.470
nonbonded pdb=" O   GLU A  30 "
          pdb=" CG  GLN A  31 "
   model   vdw
   4.675 3.440
nonbonded pdb=" O   LYS A   3 "
          pdb=" C   ASP A  36 "
   model   vdw
   4.675 3.270
nonbonded pdb=" NE2 GLN A  12 "
          pdb=" CB  PRO A  58 "
   model   vdw sym.op.
   4.675 3.520 -x+1/2,y-1/2,-z+1
nonbonded pdb=" CA  ILE A   2 "
          pdb="O    HOH S  12 "
   model   vdw
   4.676 3.470
nonbonded pdb=" CG  LYS A  69 "
          pdb=" C   MSE A  77 "
   model   vdw
   4.676 3.670
nonbonded pdb=" OH  TYR A  26 "
          pdb=" CZ  TYR A  61 "
   model   vdw sym.op.
   4.676 3.260 x,y-1,z
nonbonded pdb=" CE2 PHE A  73 "
          pdb="O    HOH S  54 "
   model   vdw sym.op.
   4.676 3.340 -x+1,y-1,-z+2
nonbonded pdb=" CB  LYS A   3 "
          pdb=" NZ  LYS A   3 "
   model   vdw
   4.677 3.520
nonbonded pdb=" NE2 GLN A  53 "
          pdb=" CE1 TYR A  56 "
   model   vdw
   4.677 3.420
nonbonded pdb=" CA  PRO A  42 "
          pdb=" O   VAL A  43 "
   model   vdw
   4.677 3.470
nonbonded pdb=" N   SER A  20 "
          pdb=" N   PRO A  25 "
   model   vdw
   4.677 3.200
nonbonded pdb=" N   GLU A  40 "
          pdb=" C   TYR A  41 "
   model   vdw
   4.677 3.350
nonbonded pdb=" O   ASP A  50 "
          pdb=" CG  ASP A  50 "
   model   vdw
   4.677 3.270
nonbonded pdb=" N   ILE A  78 "
          pdb=" CA  ASP A  79 "
   model   vdw
   4.677 3.550
nonbonded pdb=" CG2 VAL A  35 "
          pdb=" O   VAL A  43 "
   model   vdw
   4.677 3.460
nonbonded pdb=" CZ  ARG A  21 "
          pdb=" CG  GLN A  22 "
   model   vdw
   4.678 3.670
nonbonded pdb=" CB  CYS A  33 "
          pdb=" O   TYR A  34 "
   model   vdw
   4.678 3.440
nonbonded pdb=" OG  SER A  66 "
          pdb=" NH1 ARG A  82 "
   model   vdw
   4.678 3.120
nonbonded pdb=" CG  PRO A  58 "
          pdb=" N   GLY A  59 "
   model   vdw
   4.678 3.520
nonbonded pdb=" N   GLY A  71 "
          pdb=" N   SER A  75 "
   model   vdw
   4.679 3.200
nonbonded pdb=" CB  LYS A   3 "
          pdb=" O   TYR A  61 "
   model   vdw
   4.679 3.440
nonbonded pdb=" C   SER A  67 "
          pdb=" CG2 ILE A  78 "
   model   vdw
   4.679 3.690
nonbonded pdb=" CZ  ARG A  16 "
          pdb=" CZ  TYR A  61 "
   model   vdw sym.op.
   4.679 3.490 x,y-1,z
nonbonded pdb=" CB  VAL A  63 "
          pdb=" CA  HIS A  64 "
   model   vdw
   4.679 3.900
nonbonded pdb=" O   THR A  62 "
          pdb=" N   LEU A  83 "
   model   vdw
   4.679 3.120
nonbonded pdb=" NZ  LYS A  24 "
          pdb=" CB  ASP A  50 "
   model   vdw sym.op.
   4.679 3.520 -x+1/2,y-1/2,-z+2
nonbonded pdb=" CB  ASP A  50 "
          pdb=" NZ  LYS A  24 "
   model   vdw sym.op.
   4.679 3.520 -x+1/2,y+1/2,-z+2
nonbonded pdb=" CG  GLN A  22 "
          pdb=" CB  GLU A  51 "
   model   vdw sym.op.
   4.680 3.840 -x+1/2,y-1/2,-z+2
nonbonded pdb=" N   ARG A  16 "
          pdb=" CA  SER A  17 "
   model   vdw
   4.680 3.550
nonbonded pdb=" O   ASN A  39 "
          pdb=" C   TYR A  41 "
   model   vdw
   4.680 3.270
nonbonded pdb=" CB  ASP A  50 "
          pdb=" C   GLU A  51 "
   model   vdw
   4.680 3.670
nonbonded pdb=" CA  VAL A  35 "
          pdb=" N   VAL A  43 "
   model   vdw
   4.680 3.550
nonbonded pdb=" N   ASN A  29 "
          pdb=" CA  GLU A  30 "
   model   vdw
   4.681 3.550
nonbonded pdb=" CA  ARG A  16 "
          pdb=" C   SER A  17 "
   model   vdw
   4.681 3.700
nonbonded pdb=" C   GLN A  53 "
          pdb="O    HOH S  98 "
   model   vdw
   4.681 3.270
nonbonded pdb=" N   VAL A  84 "
          pdb="O    HOH S  81 "
   model   vdw sym.op.
   4.682 3.120 x,y+1,z
nonbonded pdb=" CA  THR A  15 "
          pdb="O    HOH S  34 "
   model   vdw
   4.682 3.470
nonbonded pdb=" NE2 GLN A  10 "
          pdb=" OH  TYR A  34 "
   model   vdw
   4.682 3.120
nonbonded pdb=" C   PRO A  42 "
          pdb=" CG2 VAL A  43 "
   model   vdw
   4.683 3.690
nonbonded pdb=" O   GLN A  12 "
          pdb=" CB  ALA A  55 "
   model   vdw
   4.683 3.460
nonbonded pdb=" CG2 VAL A   4 "
          pdb=" N   GLU A   5 "
   model   vdw
   4.683 3.540
nonbonded pdb=" OE2 GLU A   5 "
          pdb=" O   GLY A  59 "
   model   vdw
   4.683 3.040
nonbonded pdb=" CA  PRO A  54 "
          pdb="O    HOH S  98 "
   model   vdw
   4.684 3.470
nonbonded pdb=" O   VAL A  45 "
          pdb=" CG2 VAL A  45 "
   model   vdw
   4.684 3.460
nonbonded pdb=" CA  TYR A  41 "
          pdb=" CE2 TYR A  41 "
   model   vdw
   4.684 3.770
nonbonded pdb=" O   LEU A  65 "
          pdb=" CD2 LEU A  65 "
   model   vdw
   4.684 3.460
nonbonded pdb=" CB  GLN A  12 "
          pdb=" C   PHE A  13 "
   model   vdw
   4.684 3.670
nonbonded pdb=" CA  GLY A  18 "
          pdb=" C   VAL A  19 "
   model   vdw
   4.684 3.670
nonbonded pdb=" CB  ARG A  80 "
          pdb=" C   LEU A  81 "
   model   vdw
   4.684 3.670
nonbonded pdb=" N   GLY A  71 "
          pdb=" CB  MSE A  77 "
   model   vdw
   4.684 3.520
nonbonded pdb=" O   VAL A   4 "
          pdb=" N   LEU A  60 "
   model   vdw
   4.684 3.120
nonbonded pdb=" CG1 ILE A   6 "
          pdb=" NE2 GLN A  31 "
   model   vdw
   4.684 3.520
nonbonded pdb=" CB  GLN A  31 "
          pdb=" CD2 LEU A  49 "
   model   vdw
   4.684 3.860
nonbonded pdb=" C   VAL A   4 "
          pdb=" CB  TYR A  61 "
   model   vdw
   4.684 3.670
nonbonded pdb=" CB  VAL A  19 "
          pdb=" O   GLY A  23 "
   model   vdw
   4.685 3.470
nonbonded pdb=" CB  MSE A  77 "
          pdb=" C   ILE A  78 "
   model   vdw
   4.685 3.670
nonbonded pdb=" CB  LYS A  69 "
          pdb=" O   MSE A  77 "
   model   vdw
   4.685 3.440
nonbonded pdb=" CA  LEU A  32 "
          pdb=" C   VAL A  45 "
   model   vdw
   4.685 3.700
nonbonded pdb=" CB  VAL A  43 "
          pdb="O    HOH S   3 "
   model   vdw
   4.685 3.470
nonbonded pdb=" O   ILE A   2 "
          pdb="O    HOH S   2 "
   model   vdw
   4.686 3.040
nonbonded pdb=" O   ASP A  79 "
          pdb=" OD2 ASP A  79 "
   model   vdw
   4.686 3.040
nonbonded pdb=" OG1 THR A  14 "
          pdb=" N   GLU A  30 "
   model   vdw
   4.686 3.120
nonbonded pdb=" CA  LYS A  24 "
          pdb=" CB  PRO A  25 "
   model   vdw
   4.686 3.870
nonbonded pdb=" C   GLY A  59 "
          pdb="O    HOH S  51 "
   model   vdw
   4.687 3.270
nonbonded pdb=" O   GLU A  40 "
          pdb=" O   TYR A  41 "
   model   vdw
   4.687 3.040
nonbonded pdb=" CG1 VAL A  19 "
          pdb=" N   GLY A  23 "
   model   vdw
   4.687 3.540
nonbonded pdb=" O   GLY A  18 "
          pdb=" N   PRO A  25 "
   model   vdw
   4.687 3.120
nonbonded pdb=" C   GLN A  10 "
          pdb=" CG  GLN A  31 "
   model   vdw
   4.688 3.670
nonbonded pdb=" CA  GLN A  22 "
          pdb=" N   LYS A  24 "
   model   vdw
   4.688 3.550
nonbonded pdb=" CA  ARG A  82 "
          pdb=" C   LEU A  83 "
   model   vdw
   4.688 3.700
nonbonded pdb=" CA  ARG A  82 "
          pdb=" CG  LEU A  83 "
   model   vdw
   4.688 3.900
nonbonded pdb=" N   TYR A  41 "
          pdb="O    HOH S   3 "
   model   vdw
   4.689 3.120
nonbonded pdb=" O   GLU A  40 "
          pdb=" OE1 GLU A  40 "
   model   vdw
   4.689 3.040
nonbonded pdb=" CD  PRO A  42 "
          pdb=" CD1 TYR A  41 "
   model   vdw sym.op.
   4.689 3.740 -x+1,y,-z+1
nonbonded pdb=" CD1 TYR A  41 "
          pdb=" CD  PRO A  42 "
   model   vdw sym.op.
   4.689 3.740 -x+1,y,-z+1
nonbonded pdb=" CA  SER A  20 "
          pdb=" N   GLY A  23 "
   model   vdw
   4.690 3.550
nonbonded pdb=" C   HIS A  64 "
          pdb=" OG  SER A  66 "
   model   vdw
   4.690 3.270
nonbonded pdb=" N   ARG A  82 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   4.690 3.540
nonbonded pdb=" CB  GLU A  40 "
          pdb=" OH  TYR A  34 "
   model   vdw sym.op.
   4.691 3.440 -x+1,y,-z+1
nonbonded pdb=" OH  TYR A  34 "
          pdb=" CB  GLU A  40 "
   model   vdw sym.op.
   4.691 3.440 -x+1,y,-z+1
nonbonded pdb=" CB  TYR A  26 "
          pdb=" NE2 GLN A  22 "
   model   vdw sym.op.
   4.691 3.520 -x+1/2,y+1/2,-z+2
nonbonded pdb=" NE2 GLN A  22 "
          pdb=" CB  TYR A  26 "
   model   vdw sym.op.
   4.691 3.520 -x+1/2,y-1/2,-z+2
nonbonded pdb=" CB  LEU A  76 "
          pdb=" CD2 LEU A  81 "
   model   vdw sym.op.
   4.691 3.860 -x+1,y,-z+2
nonbonded pdb=" O   PHE A  13 "
          pdb=" CZ  PHE A  13 "
   model   vdw
   4.691 3.340
nonbonded pdb=" N   SER A  27 "
          pdb=" CA  LEU A  28 "
   model   vdw
   4.691 3.550
nonbonded pdb=" CA  ASN A  29 "
          pdb=" CB  GLU A  30 "
   model   vdw
   4.691 3.870
nonbonded pdb=" CB  LEU A  37 "
          pdb=" CG1 VAL A  43 "
   model   vdw
   4.691 3.860
nonbonded pdb=" CD  GLN A  53 "
          pdb=" CE1 TYR A  56 "
   model   vdw
   4.691 3.570
nonbonded pdb=" C   LEU A  37 "
          pdb=" CG  ASN A  39 "
   model   vdw
   4.691 3.500
nonbonded pdb=" CB  VAL A  70 "
          pdb=" O   SER A  75 "
   model   vdw
   4.691 3.470
nonbonded pdb=" N   GLY A  52 "
          pdb=" O   GLN A  53 "
   model   vdw
   4.692 3.120
nonbonded pdb=" C   LEU A  76 "
          pdb=" N   ILE A  78 "
   model   vdw
   4.692 3.350
nonbonded pdb=" C   PHE A  68 "
          pdb=" CD2 PHE A  68 "
   model   vdw
   4.692 3.570
nonbonded pdb=" CD1 ILE A  47 "
          pdb=" CD2 LEU A  49 "
   model   vdw
   4.692 3.880
nonbonded pdb=" CE1 TYR A  34 "
          pdb=" CG  LEU A  44 "
   model   vdw
   4.693 3.770
nonbonded pdb=" N   ASN A  39 "
          pdb=" O   TYR A  41 "
   model   vdw
   4.693 3.120
nonbonded pdb=" O   GLN A  31 "
          pdb=" N   LYS A  46 "
   model   vdw
   4.694 3.120
nonbonded pdb=" CA  SER A  17 "
          pdb=" CD1 TYR A  26 "
   model   vdw
   4.694 3.770
nonbonded pdb=" O   SER A  67 "
          pdb=" N   ILE A  78 "
   model   vdw
   4.694 3.120
nonbonded pdb=" OG  SER A   9 "
          pdb="O    HOH S 117 "
   model   vdw sym.op.
   4.694 3.040 -x+1/2,y+1/2,-z+1
nonbonded pdb="O    HOH S 117 "
          pdb=" OG  SER A   9 "
   model   vdw sym.op.
   4.694 3.040 -x+1/2,y-1/2,-z+1
nonbonded pdb=" O   PHE A  13 "
          pdb=" CG  PRO A  58 "
   model   vdw sym.op.
   4.694 3.440 -x+1/2,y-1/2,-z+1
nonbonded pdb=" NZ  LYS A  24 "
          pdb=" OD1 ASP A  50 "
   model   vdw sym.op.
   4.694 3.120 -x+1/2,y-1/2,-z+2
nonbonded pdb=" OD1 ASP A  50 "
          pdb=" NZ  LYS A  24 "
   model   vdw sym.op.
   4.694 3.120 -x+1/2,y+1/2,-z+2
nonbonded pdb=" CD1 TYR A  34 "
          pdb=" CG  PRO A  42 "
   model   vdw
   4.695 3.740
nonbonded pdb=" CG2 VAL A   4 "
          pdb=" CA  VAL A  35 "
   model   vdw
   4.695 3.890
nonbonded pdb=" CA  VAL A  19 "
          pdb=" N   PRO A  25 "
   model   vdw
   4.695 3.550
nonbonded pdb=" ND2 ASN A  39 "
          pdb=" N   GLU A  40 "
   model   vdw
   4.695 3.200
nonbonded pdb=" N   ILE A   6 "
          pdb=" CD1 TYR A  61 "
   model   vdw
   4.695 3.420
nonbonded pdb=" CA  LYS A  46 "
          pdb=" C   GLY A  74 "
   model   vdw sym.op.
   4.695 3.700 -x+1,y,-z+2
nonbonded pdb=" CB  THR A  48 "
          pdb=" CG  ARG A  80 "
   model   vdw
   4.696 3.870
nonbonded pdb="O    HOH S   4 "
          pdb="O    HOH S 103 "
   model   vdw sym.op.
   4.696 3.040 -x,y+1,-z+1
nonbonded pdb="O    HOH S 103 "
          pdb="O    HOH S   4 "
   model   vdw sym.op.
   4.696 3.040 -x,y-1,-z+1
nonbonded pdb=" CG  LEU A  44 "
          pdb="O    HOH S  17 "
   model   vdw
   4.696 3.470
nonbonded pdb=" N   VAL A  35 "
          pdb=" CA  VAL A  43 "
   model   vdw
   4.697 3.550
nonbonded pdb="O    HOH S 163 "
          pdb=" N   ILE A   2 "
   model   vdw sym.op.
   4.697 3.120 x,y,z
nonbonded pdb=" N   ILE A   2 "
          pdb="O    HOH S 163 "
   model   vdw sym.op.
   4.697 3.120 -x+1,y,-z+2
nonbonded pdb=" NE2 GLN A  22 "
          pdb=" C   SER A  27 "
   model   vdw sym.op.
   4.697 3.350 -x+1/2,y-1/2,-z+2
nonbonded pdb=" CB  GLN A  31 "
          pdb=" CG  LEU A  49 "
   model   vdw
   4.697 3.870
nonbonded pdb=" CA  ARG A  16 "
          pdb=" CB  SER A  17 "
   model   vdw
   4.697 3.870
nonbonded pdb=" O   GLY A  18 "
          pdb=" O   VAL A  19 "
   model   vdw
   4.698 3.040
nonbonded pdb=" O   SER A  67 "
          pdb=" CD2 PHE A  68 "
   model   vdw
   4.698 3.340
nonbonded pdb=" CZ  ARG A  16 "
          pdb=" CA  GLY A  59 "
   model   vdw sym.op.
   4.698 3.670 x,y-1,z
nonbonded pdb=" OE1 GLN A  53 "
          pdb=" CD1 TYR A  56 "
   model   vdw
   4.698 3.340
nonbonded pdb=" CB  GLU A  40 "
          pdb=" CG  TYR A  41 "
   model   vdw
   4.698 3.660
nonbonded pdb=" N   GLN A  31 "
          pdb=" CG  LYS A  46 "
   model   vdw
   4.698 3.520
nonbonded pdb=" CA  GLY A  18 "
          pdb=" CB  VAL A  19 "
   model   vdw
   4.698 3.870
nonbonded pdb=" CA  VAL A   4 "
          pdb=" CB  GLU A   5 "
   model   vdw
   4.698 3.870
nonbonded pdb=" CA  PRO A   8 "
          pdb=" OG1 THR A  15 "
   model   vdw sym.op.
   4.699 3.470 -x+1/2,y+1/2,-z+1
nonbonded pdb=" O   GLN A  72 "
          pdb=" O   PHE A  73 "
   model   vdw
   4.699 3.040
nonbonded pdb=" CA  ALA A  11 "
          pdb=" C   GLN A  12 "
   model   vdw
   4.699 3.700
nonbonded pdb=" CB  HIS A  64 "
          pdb=" CG2 VAL A  84 "
   model   vdw
   4.699 3.860
nonbonded pdb=" OG  SER A  75 "
          pdb=" C   LEU A  76 "
   model   vdw
   4.700 3.270
nonbonded pdb=" CB  LEU A  44 "
          pdb="O    HOH S  17 "
   model   vdw
   4.701 3.440
nonbonded pdb=" O   SER A  67 "
          pdb=" O   ILE A  78 "
   model   vdw
   4.701 3.040
nonbonded pdb=" CB  PRO A  42 "
          pdb="O    HOH S   3 "
   model   vdw
   4.701 3.440
nonbonded pdb=" CG  GLN A  22 "
          pdb=" CD  GLU A  51 "
   model   vdw sym.op.
   4.702 3.670 -x+1/2,y-1/2,-z+2
nonbonded pdb=" O   TYR A  61 "
          pdb=" CD1 PHE A  73 "
   model   vdw sym.op.
   4.702 3.340 -x+1,y+1,-z+2
nonbonded pdb=" OE1 GLN A  31 "
          pdb=" CD1 ILE A  47 "
   model   vdw
   4.702 3.460
nonbonded pdb=" CA  TYR A  56 "
          pdb=" CE2 TYR A  56 "
   model   vdw
   4.703 3.770
nonbonded pdb=" CA  PHE A  73 "
          pdb=" CE2 PHE A  73 "
   model   vdw
   4.703 3.770
nonbonded pdb=" N   GLY A  71 "
          pdb="SE    SE Z   4 "
   model   vdw sym.op.
   4.703 3.500 x+1/2,y+3/2,z+2
nonbonded pdb=" CD2 LEU A  49 "
          pdb=" OH  TYR A  56 "
   model   vdw
   4.703 3.460
nonbonded pdb=" CG  ARG A  16 "
          pdb=" N   LEU A  28 "
   model   vdw
   4.703 3.520
nonbonded pdb=" CA  TYR A  41 "
          pdb="O    HOH S   3 "
   model   vdw
   4.703 3.470
nonbonded pdb=" O   LEU A  60 "
          pdb=" CE2 TYR A  61 "
   model   vdw
   4.703 3.340
nonbonded pdb=" C   ALA A  55 "
          pdb="O    HOH S  44 "
   model   vdw
   4.704 3.270
nonbonded pdb=" O   ASN A  29 "
          pdb=" OG1 THR A  48 "
   model   vdw
   4.704 3.040
nonbonded pdb=" O   HIS A  64 "
          pdb=" OG  SER A  66 "
   model   vdw
   4.704 3.040
nonbonded pdb=" C   ASN A  29 "
          pdb=" O   ILE A  47 "
   model   vdw
   4.704 3.270
nonbonded pdb=" C   SER A  67 "
          pdb=" NH1 ARG A  82 "
   model   vdw
   4.704 3.350
nonbonded pdb=" CB  ARG A  82 "
          pdb=" CZ  ARG A  82 "
   model   vdw
   4.705 3.670
nonbonded pdb=" CG  LEU A  32 "
          pdb="O    HOH S 151 "
   model   vdw
   4.705 3.470
nonbonded pdb=" NH2 ARG A  21 "
          pdb=" ND1 HIS A  64 "
   model   vdw sym.op.
   4.705 3.200 x,y-1,z
nonbonded pdb=" OD1 ASP A  79 "
          pdb=" CD  ARG A  80 "
   model   vdw
   4.705 3.440
nonbonded pdb=" N   GLN A  10 "
          pdb=" CB  ALA A  11 "
   model   vdw
   4.705 3.540
nonbonded pdb=" C   VAL A  63 "
          pdb="O    HOH S  35 "
   model   vdw
   4.705 3.270
nonbonded pdb=" CD  GLU A  30 "
          pdb=" OG1 THR A  48 "
   model   vdw
   4.706 3.270
nonbonded pdb=" CB  LYS A   7 "
          pdb=" CE2 TYR A  34 "
   model   vdw
   4.706 3.740
nonbonded pdb=" CA  LEU A  44 "
          pdb=" C   VAL A  45 "
   model   vdw
   4.706 3.700
nonbonded pdb=" C   SER A  67 "
          pdb=" CA  ASP A  79 "
   model   vdw
   4.706 3.700
nonbonded pdb=" N   TYR A  34 "
          pdb=" CA  VAL A  35 "
   model   vdw
   4.706 3.550
nonbonded pdb=" CA  LYS A  46 "
          pdb=" CB  ILE A  47 "
   model   vdw
   4.707 3.900
nonbonded pdb=" O   PHE A  13 "
          pdb=" CE2 PHE A  13 "
   model   vdw
   4.707 3.340
nonbonded pdb="O    HOH S  24 "
          pdb=" CD2 TYR A  41 "
   model   vdw sym.op.
   4.707 3.340 -x+1,y,-z+1
nonbonded pdb=" CD2 TYR A  41 "
          pdb="O    HOH S  24 "
   model   vdw sym.op.
   4.707 3.340 -x+1,y,-z+1
nonbonded pdb=" C   TYR A  61 "
          pdb=" CD1 TYR A  61 "
   model   vdw
   4.707 3.570
nonbonded pdb="O    HOH S  33 "
          pdb="O    HOH S 175 "
   model   vdw
   4.707 3.040
nonbonded pdb=" CA  GLY A  71 "
          pdb=" CB  MSE A  77 "
   model   vdw
   4.707 3.840
nonbonded pdb=" CG  HIS A  64 "
          pdb=" C   LEU A  65 "
   model   vdw
   4.708 3.490
nonbonded pdb=" O   LEU A  49 "
          pdb=" CG  ASP A  50 "
   model   vdw
   4.708 3.270
nonbonded pdb=" CB  ILE A   6 "
          pdb=" CD1 TYR A  61 "
   model   vdw
   4.708 3.770
nonbonded pdb=" CA  GLN A  22 "
          pdb=" NE2 GLN A  22 "
   model   vdw
   4.709 3.550
nonbonded pdb=" CD  LYS A  69 "
          pdb=" N   ASP A  79 "
   model   vdw
   4.709 3.520
nonbonded pdb=" CA  LEU A  60 "
          pdb="O    HOH S  54 "
   model   vdw
   4.709 3.470
nonbonded pdb=" C   MSE A  77 "
          pdb="SE    SE Z   1 "
   model   vdw sym.op.
   4.709 3.650 -x,y+1,-z+1
nonbonded pdb=" CB  ARG A  16 "
          pdb=" CA  SER A  17 "
   model   vdw
   4.709 3.870
nonbonded pdb=" CA  TYR A  56 "
          pdb=" CZ  TYR A  61 "
   model   vdw
   4.710 3.690
nonbonded pdb=" CB  SER A  27 "
          pdb=" CA  LEU A  28 "
   model   vdw
   4.710 3.870
nonbonded pdb=" CD  PRO A  42 "
          pdb=" N   VAL A  43 "
   model   vdw
   4.710 3.520
nonbonded pdb=" CB  TYR A  34 "
          pdb=" CA  VAL A  35 "
   model   vdw
   4.710 3.870
nonbonded pdb=" C   ILE A   2 "
          pdb=" CZ  PHE A  73 "
   model   vdw sym.op.
   4.710 3.570 -x+1,y+1,-z+2
nonbonded pdb=" CB  PHE A  13 "
          pdb=" C   THR A  14 "
   model   vdw
   4.710 3.670
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" CA  ALA A  11 "
   model   vdw
   4.710 3.890
nonbonded pdb=" CD  GLN A  31 "
          pdb=" N   LEU A  32 "
   model   vdw
   4.711 3.350
nonbonded pdb=" O   GLY A  52 "
          pdb=" CA  PRO A  54 "
   model   vdw
   4.711 3.470
nonbonded pdb=" C   ALA A  57 "
          pdb="O    HOH S  14 "
   model   vdw
   4.711 3.270
nonbonded pdb=" N   ILE A   2 "
          pdb=" CA  LYS A   3 "
   model   vdw
   4.711 3.550
nonbonded pdb=" CA  VAL A  70 "
          pdb=" C   SER A  75 "
   model   vdw
   4.711 3.700
nonbonded pdb=" C   PRO A  58 "
          pdb=" CE1 TYR A  61 "
   model   vdw
   4.712 3.570
nonbonded pdb=" O   GLU A  30 "
          pdb=" O   GLN A  31 "
   model   vdw
   4.712 3.040
nonbonded pdb=" C   LYS A  69 "
          pdb=" CA  LEU A  76 "
   model   vdw
   4.712 3.700
nonbonded pdb=" O   TYR A  34 "
          pdb=" O   VAL A  43 "
   model   vdw
   4.712 3.040
nonbonded pdb=" CA  LYS A   3 "
          pdb=" CE  LYS A   3 "
   model   vdw
   4.712 3.870
nonbonded pdb=" CA  HIS A  64 "
          pdb=" C   ARG A  82 "
   model   vdw
   4.713 3.700
nonbonded pdb=" O   VAL A  43 "
          pdb=" CB  VAL A  45 "
   model   vdw
   4.713 3.470
nonbonded pdb=" CA  ARG A  82 "
          pdb=" CB  LEU A  83 "
   model   vdw
   4.713 3.870
nonbonded pdb=" OD1 ASN A  29 "
          pdb="O    HOH S 117 "
   model   vdw
   4.713 3.040
nonbonded pdb=" O   LYS A   7 "
          pdb=" CG  LYS A   7 "
   model   vdw
   4.713 3.440
nonbonded pdb=" O   ARG A  16 "
          pdb=" N   SER A  27 "
   model   vdw
   4.713 3.120
nonbonded pdb=" CG  PHE A  13 "
          pdb=" ND2 ASN A  29 "
   model   vdw
   4.714 3.340
nonbonded pdb=" CG  TYR A  34 "
          pdb=" CB  PRO A  42 "
   model   vdw
   4.714 3.660
nonbonded pdb=" CB  GLN A  31 "
          pdb=" CD1 LEU A  49 "
   model   vdw
   4.714 3.860
nonbonded pdb=" CA  ALA A  11 "
          pdb=" CG  PRO A  58 "
   model   vdw
   4.714 3.870
nonbonded pdb=" CB  MSE A  77 "
          pdb=" O   ILE A  78 "
   model   vdw
   4.715 3.440
nonbonded pdb=" O   GLU A  40 "
          pdb=" CG  GLU A  40 "
   model   vdw
   4.715 3.440
nonbonded pdb=" CG  TYR A  61 "
          pdb=" N   VAL A  84 "
   model   vdw
   4.715 3.340
nonbonded pdb=" CA  GLU A  40 "
          pdb=" CB  TYR A  41 "
   model   vdw
   4.715 3.870
nonbonded pdb=" CD2 LEU A  28 "
          pdb=" CZ  ARG A  80 "
   model   vdw
   4.715 3.690
nonbonded pdb=" OD1 ASP A  36 "
          pdb=" CB  PRO A  42 "
   model   vdw
   4.715 3.440
nonbonded pdb=" CB  SER A  75 "
          pdb=" C   LEU A  76 "
   model   vdw
   4.716 3.670
nonbonded pdb=" CB  VAL A  84 "
          pdb=" O   PRO A  85 "
   model   vdw
   4.716 3.470
nonbonded pdb=" CD1 LEU A  32 "
          pdb=" CD2 LEU A  44 "
   model   vdw
   4.716 3.880
nonbonded pdb=" CA  TYR A  61 "
          pdb=" CB  THR A  62 "
   model   vdw
   4.716 3.900
nonbonded pdb=" CG2 ILE A  78 "
          pdb=" CD1 LEU A  81 "
   model   vdw
   4.716 3.880
nonbonded pdb=" CA  GLU A  40 "
          pdb=" CD2 TYR A  41 "
   model   vdw
   4.716 3.770
nonbonded pdb=" CA  THR A  14 "
          pdb=" CB  THR A  15 "
   model   vdw
   4.717 3.900
nonbonded pdb=" CD  GLN A  31 "
          pdb=" C   TYR A  56 "
   model   vdw
   4.717 3.500
nonbonded pdb=" CD  ARG A  80 "
          pdb=" CZ  ARG A  82 "
   model   vdw
   4.717 3.670
nonbonded pdb=" C   LEU A  44 "
          pdb=" O   GLY A  74 "
   model   vdw sym.op.
   4.717 3.270 -x+1,y,-z+2
nonbonded pdb=" CA  SER A  67 "
          pdb=" CB  PHE A  68 "
   model   vdw
   4.717 3.870
nonbonded pdb=" N   HIS A  64 "
          pdb=" CA  LEU A  83 "
   model   vdw
   4.717 3.550
nonbonded pdb=" OE1 GLN A  12 "
          pdb=" O   PHE A  13 "
   model   vdw
   4.717 3.040
nonbonded pdb=" CA  GLY A  59 "
          pdb=" CB  LEU A  60 "
   model   vdw
   4.718 3.840
nonbonded pdb=" CA  ARG A  21 "
          pdb=" CB  GLN A  22 "
   model   vdw
   4.718 3.870
nonbonded pdb=" CA  TYR A  26 "
          pdb=" CE2 TYR A  26 "
   model   vdw
   4.718 3.770
nonbonded pdb=" O   GLU A  51 "
          pdb=" OE2 GLU A  51 "
   model   vdw
   4.718 3.040
nonbonded pdb=" OG  SER A  27 "
          pdb=" O   LEU A  28 "
   model   vdw
   4.718 3.040
nonbonded pdb=" NE2 GLN A  12 "
          pdb=" CA  GLY A  59 "
   model   vdw sym.op.
   4.718 3.520 -x+1/2,y-1/2,-z+1
nonbonded pdb=" CD  ARG A  16 "
          pdb=" CG  GLU A  30 "
   model   vdw
   4.718 3.840
nonbonded pdb=" CD1 TYR A  56 "
          pdb=" O   LEU A  83 "
   model   vdw
   4.719 3.340
nonbonded pdb=" C   PHE A  73 "
          pdb=" CA  SER A  75 "
   model   vdw
   4.719 3.700
nonbonded pdb=" CZ  ARG A  16 "
          pdb=" OE2 GLU A  30 "
   model   vdw
   4.719 3.270
nonbonded pdb=" CD  GLN A  10 "
          pdb=" N   TYR A  34 "
   model   vdw
   4.719 3.350
nonbonded pdb=" C   TYR A  61 "
          pdb=" CD2 TYR A  61 "
   model   vdw
   4.719 3.570
nonbonded pdb=" CB  PRO A  42 "
          pdb=" O   VAL A  43 "
   model   vdw
   4.719 3.440
nonbonded pdb=" C   GLU A  40 "
          pdb=" CD  GLU A  40 "
   model   vdw
   4.719 3.500
nonbonded pdb=" C   GLN A  53 "
          pdb=" OE1 GLN A  53 "
   model   vdw
   4.720 3.270
nonbonded pdb=" CB  SER A  67 "
          pdb=" CB  ARG A  82 "
   model   vdw
   4.720 3.840
nonbonded pdb=" O   ARG A  21 "
          pdb=" CG  GLN A  53 "
   model   vdw sym.op.
   4.720 3.440 x,y-1,z
nonbonded pdb=" O   GLN A  22 "
          pdb=" O   GLY A  23 "
   model   vdw
   4.721 3.040
nonbonded pdb=" CB  SER A   9 "
          pdb=" OG1 THR A  15 "
   model   vdw sym.op.
   4.722 3.440 -x+1/2,y+1/2,-z+1
nonbonded pdb=" OG1 THR A  15 "
          pdb=" CB  SER A   9 "
   model   vdw sym.op.
   4.722 3.440 -x+1/2,y-1/2,-z+1
nonbonded pdb=" CA  THR A  14 "
          pdb=" OG1 THR A  15 "
   model   vdw
   4.722 3.470
nonbonded pdb=" CG  GLN A  53 "
          pdb=" O   PRO A  54 "
   model   vdw
   4.722 3.440
nonbonded pdb=" NZ  LYS A  24 "
          pdb=" CB  ARG A  21 "
   model   vdw sym.op.
   4.722 3.520 -x+1/2,y+1/2,-z+2
nonbonded pdb=" CB  ARG A  21 "
          pdb=" NZ  LYS A  24 "
   model   vdw sym.op.
   4.722 3.520 -x+1/2,y-1/2,-z+2
nonbonded pdb=" OG1 THR A  14 "
          pdb=" CA  GLU A  30 "
   model   vdw
   4.723 3.470
nonbonded pdb=" CD  LYS A  69 "
          pdb=" N   VAL A  70 "
   model   vdw
   4.723 3.520
nonbonded pdb=" CD1 LEU A  60 "
          pdb=" CA  PHE A  73 "
   model   vdw sym.op.
   4.723 3.890 -x+1,y+1,-z+2
nonbonded pdb=" CG  LEU A  44 "
          pdb=" O   VAL A  45 "
   model   vdw
   4.723 3.470
nonbonded pdb=" C   LYS A   7 "
          pdb=" OE2 GLU A  40 "
   model   vdw sym.op.
   4.723 3.270 -x+1,y,-z+1
nonbonded pdb=" SG  CYS A  33 "
          pdb=" N   VAL A  45 "
   model   vdw
   4.723 3.480
nonbonded pdb=" CA  VAL A   4 "
          pdb=" C   GLU A   5 "
   model   vdw
   4.723 3.700
nonbonded pdb=" CZ  ARG A  21 "
          pdb=" NE2 HIS A  64 "
   model   vdw sym.op.
   4.724 3.350 x,y-1,z
nonbonded pdb=" OG  SER A   9 "
          pdb=" CB  GLN A  10 "
   model   vdw
   4.724 3.440
nonbonded pdb=" O   GLU A  30 "
          pdb=" N   LEU A  32 "
   model   vdw
   4.724 3.120
nonbonded pdb=" CD1 TYR A  41 "
          pdb=" CB  TYR A  41 "
   model   vdw sym.op.
   4.724 3.740 -x+1,y,-z+1
nonbonded pdb=" CB  TYR A  41 "
          pdb=" CD1 TYR A  41 "
   model   vdw sym.op.
   4.724 3.740 -x+1,y,-z+1
nonbonded pdb=" N   SER A  67 "
          pdb=" CD  ARG A  82 "
   model   vdw
   4.724 3.520
nonbonded pdb=" CA  LEU A  32 "
          pdb=" CA  LYS A  46 "
   model   vdw
   4.725 3.900
nonbonded pdb=" O   LYS A   7 "
          pdb=" CB  ALA A  11 "
   model   vdw
   4.725 3.460
nonbonded pdb=" O   SER A  66 "
          pdb=" O   ARG A  80 "
   model   vdw
   4.725 3.040
nonbonded pdb=" CA  PHE A  68 "
          pdb=" C   LYS A  69 "
   model   vdw
   4.725 3.700
nonbonded pdb=" N   ASN A  29 "
          pdb=" O   LEU A  49 "
   model   vdw
   4.726 3.120
nonbonded pdb=" CZ  ARG A  16 "
          pdb=" CE2 TYR A  61 "
   model   vdw sym.op.
   4.726 3.570 x,y-1,z
nonbonded pdb=" CG  ASN A  29 "
          pdb=" N   GLU A  30 "
   model   vdw
   4.726 3.350
nonbonded pdb=" CA  LEU A  81 "
          pdb=" CG  ARG A  82 "
   model   vdw
   4.726 3.870
nonbonded pdb=" CA  LEU A  76 "
          pdb=" C   MSE A  77 "
   model   vdw
   4.726 3.700
nonbonded pdb=" N   LYS A   3 "
          pdb=" CB  ASP A  36 "
   model   vdw
   4.727 3.520
nonbonded pdb=" N   ALA A  57 "
          pdb="O    HOH S 134 "
   model   vdw
   4.727 3.120
nonbonded pdb=" CG  ARG A  80 "
          pdb=" NH2 ARG A  80 "
   model   vdw
   4.727 3.520
nonbonded pdb=" C   PRO A  58 "
          pdb=" N   LEU A  60 "
   model   vdw
   4.727 3.350
nonbonded pdb=" CB  SER A   9 "
          pdb=" CA  GLN A  10 "
   model   vdw
   4.727 3.870
nonbonded pdb=" CG  LEU A  44 "
          pdb=" CA  VAL A  45 "
   model   vdw
   4.727 3.900
nonbonded pdb=" CD1 PHE A  68 "
          pdb=" CB  ILE A  78 "
   model   vdw
   4.728 3.770
nonbonded pdb=" CA  GLY A  23 "
          pdb=" CB  LYS A  24 "
   model   vdw
   4.728 3.840
nonbonded pdb=" CB  ILE A  78 "
          pdb=" CA  ASP A  79 "
   model   vdw
   4.728 3.900
nonbonded pdb=" CG2 ILE A  78 "
          pdb=" CA  LEU A  81 "
   model   vdw
   4.728 3.890
nonbonded pdb=" N   PRO A  58 "
          pdb=" OH  TYR A  61 "
   model   vdw
   4.729 3.120
nonbonded pdb=" C   ARG A  16 "
          pdb=" NE  ARG A  16 "
   model   vdw
   4.729 3.350
nonbonded pdb=" CE1 HIS A  64 "
          pdb="O    HOH S  35 "
   model   vdw
   4.729 3.260
nonbonded pdb=" CA  SER A   9 "
          pdb=" CB  GLN A  10 "
   model   vdw
   4.729 3.870
nonbonded pdb=" CA  LEU A  60 "
          pdb=" C   TYR A  61 "
   model   vdw
   4.729 3.700
nonbonded pdb=" CB  SER A  20 "
          pdb=" N   GLY A  23 "
   model   vdw
   4.730 3.520
nonbonded pdb=" CA  SER A  67 "
          pdb=" C   PHE A  68 "
   model   vdw
   4.730 3.700
nonbonded pdb=" O   HIS A  64 "
          pdb=" C   SER A  67 "
   model   vdw
   4.730 3.270
nonbonded pdb=" NZ  LYS A  24 "
          pdb=" NH2 ARG A  82 "
   model   vdw sym.op.
   4.730 3.200 -x+1/2,y-1/2,-z+2
nonbonded pdb=" NH2 ARG A  82 "
          pdb=" NZ  LYS A  24 "
   model   vdw sym.op.
   4.730 3.200 -x+1/2,y+1/2,-z+2
nonbonded pdb=" NE  ARG A  16 "
          pdb=" CB  PRO A  85 "
   model   vdw sym.op.
   4.731 3.520 x,y-1,z
nonbonded pdb=" C   PHE A  68 "
          pdb=" N   VAL A  70 "
   model   vdw
   4.731 3.350
nonbonded pdb=" C   ARG A  21 "
          pdb=" OE1 GLN A  22 "
   model   vdw
   4.731 3.270
nonbonded pdb=" N   LYS A  46 "
          pdb=" CA  ILE A  47 "
   model   vdw
   4.731 3.550
nonbonded pdb=" N   VAL A  35 "
          pdb=" CA  ASP A  36 "
   model   vdw
   4.731 3.550
nonbonded pdb=" O   ILE A   2 "
          pdb=" CG2 VAL A   4 "
   model   vdw
   4.731 3.460
nonbonded pdb=" CB  SER A  67 "
          pdb=" CD1 LEU A  81 "
   model   vdw
   4.732 3.860
nonbonded pdb=" C   GLY A  71 "
          pdb=" C   PHE A  73 "
   model   vdw
   4.732 3.500
nonbonded pdb=" NE2 GLN A  53 "
          pdb=" O   ARG A  21 "
   model   vdw sym.op.
   4.733 3.120 x,y+1,z
nonbonded pdb=" O   ARG A  21 "
          pdb=" NE2 GLN A  53 "
   model   vdw sym.op.
   4.733 3.120 x,y-1,z
nonbonded pdb=" CA  SER A  27 "
          pdb=" CG  LEU A  28 "
   model   vdw
   4.733 3.900
nonbonded pdb=" CB  ASP A  36 "
          pdb=" N   GLY A  38 "
   model   vdw
   4.733 3.520
nonbonded pdb=" O   CYS A  33 "
          pdb=" O   TYR A  34 "
   model   vdw
   4.733 3.040
nonbonded pdb=" N   LEU A  44 "
          pdb=" CA  VAL A  45 "
   model   vdw
   4.734 3.550
nonbonded pdb=" CG  LYS A  24 "
          pdb=" OD1 ASP A  50 "
   model   vdw sym.op.
   4.734 3.440 -x+1/2,y-1/2,-z+2
nonbonded pdb=" OD1 ASP A  50 "
          pdb=" CG  LYS A  24 "
   model   vdw sym.op.
   4.734 3.440 -x+1/2,y+1/2,-z+2
nonbonded pdb=" CA  GLN A  53 "
          pdb=" NE2 GLN A  53 "
   model   vdw
   4.734 3.550
nonbonded pdb=" NH1 ARG A  16 "
          pdb="O    HOH S  54 "
   model   vdw sym.op.
   4.734 3.120 x,y-1,z
nonbonded pdb=" CA  SER A   9 "
          pdb=" C   GLN A  10 "
   model   vdw
   4.734 3.700
nonbonded pdb=" CA  SER A  27 "
          pdb=" C   LEU A  28 "
   model   vdw
   4.734 3.700
nonbonded pdb=" N   TYR A  26 "
          pdb=" CE2 TYR A  26 "
   model   vdw
   4.735 3.420
nonbonded pdb=" CA  LEU A  32 "
          pdb=" O   CYS A  33 "
   model   vdw
   4.735 3.470
nonbonded pdb=" C   ARG A  16 "
          pdb=" CA  SER A  27 "
   model   vdw
   4.735 3.700
nonbonded pdb=" CA  ASN A  29 "
          pdb=" C   GLU A  30 "
   model   vdw
   4.735 3.700
nonbonded pdb=" N   THR A  14 "
          pdb=" CA  GLU A  30 "
   model   vdw
   4.735 3.550
nonbonded pdb=" CG  TYR A  61 "
          pdb=" CG  LEU A  83 "
   model   vdw
   4.735 3.690
nonbonded pdb=" CA  TYR A  34 "
          pdb=" CB  PRO A  42 "
   model   vdw
   4.735 3.870
nonbonded pdb=" C   SER A  67 "
          pdb=" CE2 PHE A  68 "
   model   vdw
   4.736 3.570
nonbonded pdb=" CA  MSE A  77 "
          pdb=" CB  ILE A  78 "
   model   vdw sym.op.
   4.736 3.900 -x+1,y,-z+2
nonbonded pdb=" CB  ILE A  78 "
          pdb=" CA  MSE A  77 "
   model   vdw sym.op.
   4.736 3.900 -x+1,y,-z+2
nonbonded pdb=" O   GLY A  71 "
          pdb=" N   SER A  75 "
   model   vdw
   4.736 3.120
nonbonded pdb=" N   SER A  20 "
          pdb=" CA  PRO A  25 "
   model   vdw
   4.736 3.550
nonbonded pdb=" CG2 VAL A  70 "
          pdb=" CD1 LEU A  76 "
   model   vdw
   4.737 3.880
nonbonded pdb=" NE2 GLN A  10 "
          pdb=" CG  LEU A  44 "
   model   vdw
   4.737 3.550
nonbonded pdb=" CA  TYR A  26 "
          pdb=" C   SER A  27 "
   model   vdw
   4.737 3.700
nonbonded pdb=" OD1 ASP A  50 "
          pdb=" N   GLU A  51 "
   model   vdw
   4.737 3.120
nonbonded pdb=" C   GLN A  31 "
          pdb=" O   VAL A  45 "
   model   vdw
   4.738 3.270
nonbonded pdb=" CG2 VAL A  45 "
          pdb=" CG  LEU A  76 "
   model   vdw sym.op.
   4.738 3.890 -x+1,y,-z+2
nonbonded pdb=" CZ  PHE A  13 "
          pdb=" OD1 ASN A  29 "
   model   vdw
   4.738 3.340
nonbonded pdb=" CB  VAL A  84 "
          pdb=" CA  PRO A  85 "
   model   vdw
   4.738 3.900
nonbonded pdb=" CA  PRO A  25 "
          pdb=" C   TYR A  26 "
   model   vdw
   4.738 3.700
nonbonded pdb=" N   VAL A  19 "
          pdb=" CA  SER A  20 "
   model   vdw
   4.738 3.550
nonbonded pdb=" O   LEU A  83 "
          pdb=" N   PRO A  85 "
   model   vdw
   4.738 3.120
nonbonded pdb=" CB  PRO A   8 "
          pdb=" CG  PRO A  58 "
   model   vdw
   4.738 3.840
nonbonded pdb=" O   GLN A  72 "
          pdb=" CD2 PHE A  73 "
   model   vdw
   4.738 3.340
nonbonded pdb=" NH1 ARG A  16 "
          pdb="O    HOH S  85 "
   model   vdw
   4.738 3.120
nonbonded pdb=" CA  SER A  20 "
          pdb=" CB  ARG A  21 "
   model   vdw
   4.738 3.870
nonbonded pdb=" CA  GLU A  40 "
          pdb=" C   TYR A  41 "
   model   vdw
   4.738 3.700
nonbonded pdb=" CG  GLU A  40 "
          pdb="O    HOH S 117 "
   model   vdw sym.op.
   4.738 3.440 x+1/2,y+1/2,z
nonbonded pdb=" OG  SER A  75 "
          pdb="O    HOH S  10 "
   model   vdw sym.op.
   4.739 3.040 -x+1,y,-z+2
nonbonded pdb=" CB  TYR A  41 "
          pdb=" CG  PRO A  42 "
   model   vdw
   4.739 3.840
nonbonded pdb=" C   PHE A  68 "
          pdb=" N   ASP A  79 "
   model   vdw
   4.739 3.350
nonbonded pdb=" CG1 VAL A  19 "
          pdb=" CA  PRO A  25 "
   model   vdw
   4.739 3.890
nonbonded pdb=" N   VAL A  19 "
          pdb=" OH  TYR A  26 "
   model   vdw
   4.739 3.120
nonbonded pdb=" C   LYS A  69 "
          pdb=" C   MSE A  77 "
   model   vdw
   4.740 3.500
nonbonded pdb=" O   GLU A  40 "
          pdb=" CZ  TYR A  41 "
   model   vdw
   4.740 3.260
nonbonded pdb=" C   LYS A   7 "
          pdb=" CA  PRO A  58 "
   model   vdw
   4.740 3.700
nonbonded pdb=" C   GLY A  18 "
          pdb=" CG1 VAL A  19 "
   model   vdw
   4.740 3.690
nonbonded pdb=" CA  LYS A   3 "
          pdb=" O   VAL A   4 "
   model   vdw
   4.740 3.470
nonbonded pdb=" C   GLY A  18 "
          pdb="O    HOH S  14 "
   model   vdw sym.op.
   4.741 3.270 x,y-1,z
nonbonded pdb=" CA  CYS A  33 "
          pdb=" CB  TYR A  34 "
   model   vdw
   4.741 3.870
nonbonded pdb=" CG  TYR A  34 "
          pdb=" C   VAL A  43 "
   model   vdw
   4.741 3.490
nonbonded pdb=" CA  GLU A  30 "
          pdb=" C   GLN A  31 "
   model   vdw
   4.742 3.700
nonbonded pdb=" CD  GLN A  31 "
          pdb="O    HOH S   7 "
   model   vdw
   4.742 3.270
nonbonded pdb=" CD  GLN A  53 "
          pdb=" CA  ARG A  21 "
   model   vdw sym.op.
   4.742 3.700 x,y+1,z
nonbonded pdb=" CA  ARG A  21 "
          pdb=" CD  GLN A  53 "
   model   vdw sym.op.
   4.742 3.700 x,y-1,z
nonbonded pdb=" O   TYR A  61 "
          pdb=" CG  TYR A  61 "
   model   vdw
   4.742 3.260
nonbonded pdb=" CA  LYS A  46 "
          pdb=" O   ILE A  47 "
   model   vdw
   4.742 3.470
nonbonded pdb=" CA  LEU A  65 "
          pdb=" CE2 PHE A  68 "
   model   vdw
   4.743 3.770
nonbonded pdb=" CB  GLU A  30 "
          pdb=" CE  LYS A  46 "
   model   vdw
   4.743 3.840
nonbonded pdb=" C   ASP A  36 "
          pdb=" CA  GLY A  38 "
   model   vdw
   4.743 3.670
nonbonded pdb=" O   ASP A  36 "
          pdb=" O   LEU A  37 "
   model   vdw
   4.743 3.040
nonbonded pdb=" CG  PHE A  68 "
          pdb=" CG  LEU A  76 "
   model   vdw
   4.743 3.690
nonbonded pdb=" O   LYS A  69 "
          pdb=" N   LEU A  76 "
   model   vdw
   4.743 3.120
nonbonded pdb=" CA  VAL A  35 "
          pdb=" CB  PRO A  42 "
   model   vdw
   4.743 3.870
nonbonded pdb=" N   LEU A  60 "
          pdb=" CA  TYR A  61 "
   model   vdw
   4.744 3.550
nonbonded pdb=" CA  GLN A  72 "
          pdb=" C   PHE A  73 "
   model   vdw
   4.744 3.700
nonbonded pdb=" CG  PHE A  68 "
          pdb=" CG1 ILE A  78 "
   model   vdw
   4.744 3.660
nonbonded pdb=" CA  ALA A  11 "
          pdb=" CD  PRO A  58 "
   model   vdw
   4.744 3.870
nonbonded pdb=" O   ASN A  29 "
          pdb=" C   ILE A  47 "
   model   vdw
   4.745 3.270
nonbonded pdb=" CA  TYR A  34 "
          pdb=" CG2 VAL A  35 "
   model   vdw
   4.745 3.890
nonbonded pdb=" N   ILE A   2 "
          pdb=" OG1 THR A  62 "
   model   vdw
   4.745 3.120
nonbonded pdb=" C   VAL A   4 "
          pdb=" O   GLY A  59 "
   model   vdw
   4.745 3.270
nonbonded pdb=" CA  VAL A  43 "
          pdb=" CB  LEU A  44 "
   model   vdw
   4.746 3.870
nonbonded pdb=" CG1 ILE A   6 "
          pdb=" O   LEU A  32 "
   model   vdw
   4.746 3.440
nonbonded pdb=" O   VAL A   4 "
          pdb=" O   GLU A   5 "
   model   vdw
   4.746 3.040
nonbonded pdb=" CD2 LEU A  37 "
          pdb=" C   PHE A  68 "
   model   vdw sym.op.
   4.746 3.690 -x+1,y,-z+2
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" CB  PRO A  58 "
   model   vdw
   4.747 3.860
nonbonded pdb=" C   SER A  67 "
          pdb=" C   ILE A  78 "
   model   vdw
   4.747 3.500
nonbonded pdb=" CB  TYR A  34 "
          pdb=" C   VAL A  43 "
   model   vdw
   4.747 3.670
nonbonded pdb=" CA  PRO A  58 "
          pdb="O    HOH S  51 "
   model   vdw
   4.747 3.470
nonbonded pdb=" N   VAL A  35 "
          pdb=" CG1 VAL A  43 "
   model   vdw
   4.747 3.540
nonbonded pdb=" N   VAL A  19 "
          pdb=" CG  TYR A  26 "
   model   vdw
   4.747 3.340
nonbonded pdb=" CG  ARG A  16 "
          pdb=" NH2 ARG A  16 "
   model   vdw
   4.747 3.520
nonbonded pdb=" N   ARG A  21 "
          pdb=" CD  ARG A  21 "
   model   vdw
   4.747 3.520
nonbonded pdb=" N   ARG A  80 "
          pdb=" CA  LEU A  81 "
   model   vdw
   4.747 3.550
nonbonded pdb=" CA  LEU A  81 "
          pdb=" CB  ARG A  82 "
   model   vdw
   4.748 3.870
nonbonded pdb=" CB  VAL A  19 "
          pdb=" CA  PRO A  25 "
   model   vdw
   4.748 3.900
nonbonded pdb=" CB  LEU A  60 "
          pdb=" CE1 PHE A  73 "
   model   vdw sym.op.
   4.748 3.740 -x+1,y+1,-z+2
nonbonded pdb=" CB  PHE A  73 "
          pdb=" OG  SER A  75 "
   model   vdw
   4.748 3.440
nonbonded pdb=" CA  GLN A  12 "
          pdb=" CB  PHE A  13 "
   model   vdw
   4.749 3.870
nonbonded pdb=" C   VAL A   4 "
          pdb=" CA  LEU A  60 "
   model   vdw
   4.749 3.700
nonbonded pdb=" N   VAL A  19 "
          pdb=" N   TYR A  26 "
   model   vdw
   4.749 3.200
nonbonded pdb=" N   LYS A  46 "
          pdb="O    HOH S  10 "
   model   vdw
   4.749 3.120
nonbonded pdb=" CB  SER A  67 "
          pdb=" O   ARG A  82 "
   model   vdw
   4.749 3.440
nonbonded pdb=" CG  GLU A  30 "
          pdb=" CE  LYS A  46 "
   model   vdw
   4.749 3.840
nonbonded pdb=" CB  PRO A   8 "
          pdb=" N   THR A  14 "
   model   vdw sym.op.
   4.749 3.520 -x+1/2,y+1/2,-z+1
nonbonded pdb=" O   PRO A   8 "
          pdb=" CD  PRO A   8 "
   model   vdw
   4.749 3.440
nonbonded pdb=" SG  CYS A  33 "
          pdb=" CD2 LEU A  81 "
   model   vdw
   4.750 3.820
nonbonded pdb=" N   VAL A  63 "
          pdb=" CA  HIS A  64 "
   model   vdw
   4.750 3.550
nonbonded pdb=" N   SER A  67 "
          pdb=" CB  ARG A  82 "
   model   vdw
   4.750 3.520
nonbonded pdb=" CB  ASN A  29 "
          pdb=" CA  GLU A  30 "
   model   vdw
   4.750 3.870
nonbonded pdb=" CG  ARG A  82 "
          pdb=" N   LEU A  83 "
   model   vdw
   4.750 3.520
nonbonded pdb=" CG  GLN A  31 "
          pdb=" CB  ALA A  55 "
   model   vdw
   4.750 3.860
nonbonded pdb=" CG2 THR A  48 "
          pdb="O    HOH S  33 "
   model   vdw
   4.751 3.460
nonbonded pdb=" O   PHE A  68 "
          pdb=" O   LYS A  69 "
   model   vdw
   4.751 3.040
nonbonded pdb=" CA  ASP A  79 "
          pdb=" C   ARG A  80 "
   model   vdw
   4.751 3.700
nonbonded pdb=" CD  LYS A  24 "
          pdb=" N   PRO A  25 "
   model   vdw
   4.751 3.520
nonbonded pdb=" N   VAL A   4 "
          pdb=" CA  GLU A   5 "
   model   vdw
   4.751 3.550
nonbonded pdb=" O   GLY A  18 "
          pdb=" CE1 TYR A  26 "
   model   vdw
   4.752 3.340
nonbonded pdb=" CG1 VAL A  70 "
          pdb="O    HOH S  17 "
   model   vdw sym.op.
   4.752 3.460 -x+1,y,-z+2
nonbonded pdb=" O   GLN A  31 "
          pdb=" C   VAL A  45 "
   model   vdw
   4.753 3.270
nonbonded pdb=" CB  PHE A  73 "
          pdb=" N   SER A  75 "
   model   vdw
   4.753 3.520
nonbonded pdb=" OD2 ASP A  36 "
          pdb=" CD  GLN A  72 "
   model   vdw sym.op.
   4.753 3.270 -x+1,y+1,-z+2
nonbonded pdb=" NH2 ARG A  21 "
          pdb=" NE2 GLN A  22 "
   model   vdw
   4.753 3.200
nonbonded pdb=" CG  LYS A  69 "
          pdb=" CA  VAL A  70 "
   model   vdw
   4.753 3.870
nonbonded pdb=" C   LEU A  28 "
          pdb=" CG  GLU A  30 "
   model   vdw
   4.753 3.670
nonbonded pdb=" N   TYR A  56 "
          pdb="O    HOH S  14 "
   model   vdw
   4.754 3.120
nonbonded pdb=" CA  PRO A   8 "
          pdb=" CB  THR A  15 "
   model   vdw sym.op.
   4.754 3.900 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CA  VAL A   4 "
          pdb=" CG2 VAL A  35 "
   model   vdw
   4.754 3.890
nonbonded pdb=" CA  ILE A  78 "
          pdb=" N   ARG A  80 "
   model   vdw
   4.754 3.550
nonbonded pdb=" CA  LYS A   3 "
          pdb=" CB  VAL A   4 "
   model   vdw
   4.754 3.900
nonbonded pdb=" NE2 GLN A  10 "
          pdb=" CG  LEU A  32 "
   model   vdw
   4.755 3.550
nonbonded pdb=" OE1 GLU A  51 "
          pdb=" NE2 HIS A  64 "
   model   vdw sym.op.
   4.755 3.120 -x+1/2,y-1/2,-z+2
nonbonded pdb=" N   THR A  15 "
          pdb=" CA  ARG A  16 "
   model   vdw
   4.755 3.550
nonbonded pdb=" CA  GLN A  72 "
          pdb=" CB  PHE A  73 "
   model   vdw
   4.756 3.870
nonbonded pdb=" O   LYS A  24 "
          pdb=" CD2 TYR A  26 "
   model   vdw
   4.756 3.340
nonbonded pdb=" OE1 GLN A  10 "
          pdb=" O   CYS A  33 "
   model   vdw
   4.756 3.040
nonbonded pdb=" CG  LEU A  32 "
          pdb=" CG  LEU A  44 "
   model   vdw
   4.756 3.900
nonbonded pdb=" CD  LYS A   3 "
          pdb=" CE1 PHE A  73 "
   model   vdw sym.op.
   4.756 3.740 -x+1,y+1,-z+2
nonbonded pdb=" CD  PRO A  58 "
          pdb=" N   GLY A  59 "
   model   vdw
   4.757 3.520
nonbonded pdb=" O   SER A  67 "
          pdb=" NH1 ARG A  82 "
   model   vdw
   4.757 3.120
nonbonded pdb=" CB  VAL A  45 "
          pdb=" C   LYS A  46 "
   model   vdw
   4.757 3.700
nonbonded pdb=" NE  ARG A  21 "
          pdb=" CG  HIS A  64 "
   model   vdw sym.op.
   4.757 3.340 x,y-1,z
nonbonded pdb=" O   VAL A  45 "
          pdb=" CG2 ILE A  47 "
   model   vdw
   4.757 3.460
nonbonded pdb=" CA  GLN A  31 "
          pdb=" CD2 LEU A  32 "
   model   vdw
   4.757 3.890
nonbonded pdb=" N   GLN A  22 "
          pdb=" N   LYS A  24 "
   model   vdw
   4.757 3.200
nonbonded pdb=" CD2 LEU A  49 "
          pdb=" CA  ALA A  55 "
   model   vdw
   4.757 3.890
nonbonded pdb=" CA  LEU A  28 "
          pdb=" CB  ASN A  29 "
   model   vdw
   4.758 3.870
nonbonded pdb=" CB  LYS A   3 "
          pdb=" CD1 PHE A  73 "
   model   vdw sym.op.
   4.758 3.740 -x+1,y+1,-z+2
nonbonded pdb=" N   GLY A  38 "
          pdb=" O   ASN A  39 "
   model   vdw
   4.758 3.120
nonbonded pdb=" C   THR A  15 "
          pdb=" C   PRO A   8 "
   model   vdw sym.op.
   4.758 3.500 -x+1/2,y-1/2,-z+1
nonbonded pdb=" C   PRO A   8 "
          pdb=" C   THR A  15 "
   model   vdw sym.op.
   4.758 3.500 -x+1/2,y+1/2,-z+1
nonbonded pdb=" O   GLU A  40 "
          pdb=" CD  PRO A  42 "
   model   vdw
   4.758 3.440
nonbonded pdb=" C   VAL A   4 "
          pdb=" C   TYR A  34 "
   model   vdw
   4.758 3.500
nonbonded pdb=" N   LYS A   7 "
          pdb=" N   GLN A  10 "
   model   vdw
   4.758 3.200
nonbonded pdb=" O   THR A  48 "
          pdb=" CA  ASP A  50 "
   model   vdw
   4.758 3.470
nonbonded pdb=" CB  ALA A  11 "
          pdb=" CA  GLN A  12 "
   model   vdw
   4.758 3.890
nonbonded pdb=" O   THR A  62 "
          pdb=" CG  LEU A  83 "
   model   vdw
   4.758 3.470
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" C   TYR A  56 "
   model   vdw
   4.758 3.690
nonbonded pdb=" CG1 ILE A  78 "
          pdb=" N   ILE A  78 "
   model   vdw sym.op.
   4.759 3.520 -x+1,y,-z+2
nonbonded pdb=" N   ILE A  78 "
          pdb=" CG1 ILE A  78 "
   model   vdw sym.op.
   4.759 3.520 -x+1,y,-z+2
nonbonded pdb=" CB  TYR A  34 "
          pdb=" CZ  TYR A  41 "
   model   vdw sym.op.
   4.759 3.660 -x+1,y,-z+1
nonbonded pdb=" CE  LYS A   7 "
          pdb=" CD  PRO A   8 "
   model   vdw
   4.759 3.840
nonbonded pdb=" CG1 ILE A   6 "
          pdb=" CZ  TYR A  61 "
   model   vdw
   4.759 3.660
nonbonded pdb=" CA  PRO A  25 "
          pdb=" O   TYR A  26 "
   model   vdw
   4.759 3.470
nonbonded pdb=" CA  GLN A  10 "
          pdb=" O   LEU A  32 "
   model   vdw
   4.759 3.470
nonbonded pdb=" OH  TYR A  26 "
          pdb=" N   PRO A  85 "
   model   vdw sym.op.
   4.759 3.120 x,y-1,z
nonbonded pdb=" C   ARG A  21 "
          pdb=" CD  GLN A  22 "
   model   vdw
   4.760 3.500
nonbonded pdb=" CB  LEU A  76 "
          pdb=" CD1 LEU A  81 "
   model   vdw sym.op.
   4.760 3.860 -x+1,y,-z+2
nonbonded pdb=" CB  ASN A  39 "
          pdb=" C   TYR A  41 "
   model   vdw
   4.760 3.670
nonbonded pdb=" CA  THR A  62 "
          pdb=" CZ  PHE A  73 "
   model   vdw sym.op.
   4.761 3.770 -x+1,y+1,-z+2
nonbonded pdb=" CB  SER A  66 "
          pdb=" CA  SER A  67 "
   model   vdw
   4.761 3.870
nonbonded pdb=" O   VAL A   4 "
          pdb=" O   TYR A  34 "
   model   vdw
   4.761 3.040
nonbonded pdb=" O   LYS A  69 "
          pdb=" CA  GLY A  71 "
   model   vdw
   4.762 3.440
nonbonded pdb=" CG  LEU A  37 "
          pdb="O    HOH S   3 "
   model   vdw
   4.762 3.470
nonbonded pdb=" CA  GLU A  40 "
          pdb=" CG  TYR A  41 "
   model   vdw
   4.762 3.690
nonbonded pdb=" OD1 ASN A  39 "
          pdb=" O   TYR A  41 "
   model   vdw
   4.762 3.040
nonbonded pdb=" CA  LYS A   7 "
          pdb=" CB  PRO A   8 "
   model   vdw
   4.762 3.870
nonbonded pdb=" ND2 ASN A  29 "
          pdb=" O   GLN A  53 "
   model   vdw
   4.762 3.120
nonbonded pdb=" N   GLU A  51 "
          pdb=" N   GLN A  53 "
   model   vdw
   4.763 3.200
nonbonded pdb=" CG  LEU A  49 "
          pdb=" O   PRO A  54 "
   model   vdw
   4.763 3.470
nonbonded pdb=" CG  TYR A  56 "
          pdb="O    HOH S  14 "
   model   vdw
   4.763 3.260
nonbonded pdb=" CA  CYS A  33 "
          pdb=" CD2 TYR A  34 "
   model   vdw
   4.763 3.770
nonbonded pdb=" CA  MSE A  77 "
          pdb=" CB  ILE A  78 "
   model   vdw
   4.764 3.900
nonbonded pdb=" CA  TYR A  34 "
          pdb=" O   VAL A  35 "
   model   vdw
   4.764 3.470
nonbonded pdb=" CA  VAL A   4 "
          pdb=" N   TYR A  61 "
   model   vdw
   4.764 3.550
nonbonded pdb=" CA  ARG A  80 "
          pdb=" CZ  ARG A  82 "
   model   vdw
   4.764 3.700
nonbonded pdb=" CA  GLU A  40 "
          pdb=" O   TYR A  41 "
   model   vdw
   4.764 3.470
nonbonded pdb=" N   LEU A  81 "
          pdb=" CG  ARG A  82 "
   model   vdw
   4.764 3.520
nonbonded pdb=" C   ASP A  50 "
          pdb=" OD2 ASP A  50 "
   model   vdw
   4.765 3.270
nonbonded pdb=" NE  ARG A  16 "
          pdb=" CD1 LEU A  28 "
   model   vdw
   4.766 3.540
nonbonded pdb=" O   LEU A  83 "
          pdb=" CD  PRO A  85 "
   model   vdw
   4.766 3.440
nonbonded pdb=" CB  LYS A   7 "
          pdb=" NE2 GLN A  10 "
   model   vdw
   4.766 3.520
nonbonded pdb=" CD1 TYR A  56 "
          pdb=" CG  LEU A  83 "
   model   vdw
   4.766 3.770
nonbonded pdb=" O   ARG A  21 "
          pdb="O    HOH S 135 "
   model   vdw sym.op.
   4.766 3.040 x,y-1,z
nonbonded pdb=" N   GLY A  71 "
          pdb=" CA  LEU A  76 "
   model   vdw
   4.767 3.550
nonbonded pdb=" SG  CYS A  33 "
          pdb=" O   TYR A  34 "
   model   vdw
   4.767 3.400
nonbonded pdb=" OG  SER A  17 "
          pdb=" N   SER A  27 "
   model   vdw
   4.767 3.120
nonbonded pdb=" NZ  LYS A  69 "
          pdb=" O   VAL A  70 "
   model   vdw
   4.767 3.120
nonbonded pdb=" CA  ILE A  47 "
          pdb=" CB  THR A  48 "
   model   vdw
   4.768 3.900
nonbonded pdb=" C   PRO A   8 "
          pdb=" OE2 GLU A  40 "
   model   vdw sym.op.
   4.768 3.270 -x+1,y,-z+1
nonbonded pdb=" CB  VAL A  70 "
          pdb=" CA  GLY A  71 "
   model   vdw
   4.769 3.870
nonbonded pdb=" CB  SER A  67 "
          pdb=" CZ  PHE A  68 "
   model   vdw
   4.769 3.740
nonbonded pdb=" O   PHE A  73 "
          pdb=" CD1 PHE A  73 "
   model   vdw
   4.770 3.340
nonbonded pdb=" C   ILE A   6 "
          pdb=" CD  PRO A   8 "
   model   vdw
   4.770 3.670
nonbonded pdb=" N   LEU A  28 "
          pdb=" CA  ASN A  29 "
   model   vdw
   4.771 3.550
nonbonded pdb=" CA  THR A  14 "
          pdb=" N   GLU A  30 "
   model   vdw
   4.771 3.550
nonbonded pdb=" O   VAL A  43 "
          pdb=" CA  VAL A  45 "
   model   vdw
   4.771 3.470
nonbonded pdb=" C   LEU A  32 "
          pdb=" CD2 LEU A  32 "
   model   vdw
   4.772 3.690
nonbonded pdb=" CZ  TYR A  34 "
          pdb=" CB  LEU A  44 "
   model   vdw
   4.772 3.660
nonbonded pdb=" CA  ARG A  82 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   4.772 3.890
nonbonded pdb=" OD1 ASP A  50 "
          pdb="O    HOH S  97 "
   model   vdw sym.op.
   4.772 3.040 -x+1/2,y+1/2,-z+2
nonbonded pdb="O    HOH S  97 "
          pdb=" OD1 ASP A  50 "
   model   vdw sym.op.
   4.772 3.040 -x+1/2,y-1/2,-z+2
nonbonded pdb=" CB  TYR A  61 "
          pdb=" CA  LEU A  83 "
   model   vdw
   4.772 3.870
nonbonded pdb=" CA  THR A  62 "
          pdb=" O   VAL A  63 "
   model   vdw
   4.772 3.470
nonbonded pdb=" CA  ALA A  11 "
          pdb=" CB  GLN A  12 "
   model   vdw
   4.772 3.870
nonbonded pdb=" CD2 LEU A  83 "
          pdb=" N   VAL A  84 "
   model   vdw
   4.773 3.540
nonbonded pdb=" CG2 THR A  15 "
          pdb=" CB  SER A  17 "
   model   vdw
   4.773 3.860
nonbonded pdb=" OD1 ASP A  36 "
          pdb=" N   PRO A  42 "
   model   vdw
   4.773 3.120
nonbonded pdb=" N   GLN A  10 "
          pdb="O    HOH S   7 "
   model   vdw
   4.773 3.120
nonbonded pdb=" CD  GLN A  53 "
          pdb=" CZ  TYR A  56 "
   model   vdw
   4.773 3.490
nonbonded pdb=" OG1 THR A  62 "
          pdb=" CE2 PHE A  73 "
   model   vdw sym.op.
   4.774 3.340 -x+1,y+1,-z+2
nonbonded pdb=" CA  ILE A   2 "
          pdb=" CB  LYS A   3 "
   model   vdw
   4.774 3.870
nonbonded pdb=" NE2 GLN A  12 "
          pdb=" N   GLY A  59 "
   model   vdw sym.op.
   4.774 3.200 -x+1/2,y-1/2,-z+1
nonbonded pdb=" CB  ILE A   6 "
          pdb=" CA  LYS A   7 "
   model   vdw
   4.774 3.900
nonbonded pdb=" CA  MSE A  77 "
          pdb=" CG1 ILE A  78 "
   model   vdw sym.op.
   4.774 3.870 -x+1,y,-z+2
nonbonded pdb=" CG1 ILE A  78 "
          pdb=" CA  MSE A  77 "
   model   vdw sym.op.
   4.774 3.870 -x+1,y,-z+2
nonbonded pdb=" CA  TYR A  41 "
          pdb=" CB  PRO A  42 "
   model   vdw
   4.774 3.870
nonbonded pdb=" C   LYS A   7 "
          pdb=" OG  SER A   9 "
   model   vdw
   4.774 3.270
nonbonded pdb=" CG2 THR A  62 "
          pdb=" C   VAL A  84 "
   model   vdw
   4.774 3.690
nonbonded pdb=" CA  GLU A   5 "
          pdb=" N   TYR A  34 "
   model   vdw
   4.774 3.550
nonbonded pdb=" O   GLN A  12 "
          pdb=" CG  GLN A  12 "
   model   vdw
   4.775 3.440
nonbonded pdb=" O   GLY A  23 "
          pdb=" CA  PRO A  25 "
   model   vdw
   4.775 3.470
nonbonded pdb=" CB  THR A  48 "
          pdb=" CA  LEU A  49 "
   model   vdw
   4.775 3.900
nonbonded pdb=" CB  PHE A  73 "
          pdb="O    HOH S  54 "
   model   vdw sym.op.
   4.775 3.440 -x+1,y-1,-z+2
nonbonded pdb=" N   ARG A  21 "
          pdb=" C   GLN A  22 "
   model   vdw
   4.775 3.350
nonbonded pdb=" OD1 ASP A  79 "
          pdb=" NH2 ARG A  82 "
   model   vdw
   4.776 3.120
nonbonded pdb=" CD  GLN A  10 "
          pdb=" O   CYS A  33 "
   model   vdw
   4.777 3.270
nonbonded pdb=" CG1 VAL A  19 "
          pdb=" CG  PRO A  54 "
   model   vdw sym.op.
   4.777 3.860 x,y-1,z
nonbonded pdb=" CA  PHE A  13 "
          pdb=" CA  GLN A  31 "
   model   vdw
   4.777 3.900
nonbonded pdb=" N   ILE A   2 "
          pdb=" CD1 LEU A  65 "
   model   vdw sym.op.
   4.777 3.540 -x+1,y,-z+2
nonbonded pdb=" NZ  LYS A   7 "
          pdb=" OH  TYR A  41 "
   model   vdw sym.op.
   4.777 3.120 -x+1,y,-z+1
nonbonded pdb=" CA  GLN A  72 "
          pdb=" CG  PHE A  73 "
   model   vdw
   4.777 3.690
nonbonded pdb=" CB  ASP A  50 "
          pdb=" CD  LYS A  24 "
   model   vdw sym.op.
   4.778 3.840 -x+1/2,y+1/2,-z+2
nonbonded pdb=" CD  LYS A  24 "
          pdb=" CB  ASP A  50 "
   model   vdw sym.op.
   4.778 3.840 -x+1/2,y-1/2,-z+2
nonbonded pdb=" CA  ARG A  80 "
          pdb=" O   LEU A  81 "
   model   vdw
   4.778 3.470
nonbonded pdb=" CA  ALA A  57 "
          pdb=" CB  PRO A  58 "
   model   vdw
   4.778 3.870
nonbonded pdb=" CB  GLN A  22 "
          pdb=" NH1 ARG A  80 "
   model   vdw sym.op.
   4.778 3.520 -x+1/2,y-1/2,-z+2
nonbonded pdb=" O   ILE A   6 "
          pdb=" O   ALA A  57 "
   model   vdw
   4.779 3.040
nonbonded pdb=" C   ILE A   6 "
          pdb=" CD  LYS A   7 "
   model   vdw
   4.779 3.670
nonbonded pdb=" CA  ARG A  82 "
          pdb=" O   LEU A  83 "
   model   vdw
   4.779 3.470
nonbonded pdb=" O   GLN A  31 "
          pdb=" CD2 LEU A  32 "
   model   vdw
   4.779 3.460
nonbonded pdb=" CD2 LEU A  76 "
          pdb=" N   MSE A  77 "
   model   vdw
   4.779 3.540
nonbonded pdb=" CG2 VAL A  70 "
          pdb=" N   GLY A  71 "
   model   vdw
   4.779 3.540
nonbonded pdb=" CB  GLU A   5 "
          pdb=" CB  TYR A  34 "
   model   vdw
   4.779 3.840
nonbonded pdb=" O   HIS A  64 "
          pdb=" N   PHE A  68 "
   model   vdw
   4.781 3.120
nonbonded pdb=" C   HIS A  64 "
          pdb=" NE2 HIS A  64 "
   model   vdw
   4.781 3.350
nonbonded pdb=" C   GLN A  10 "
          pdb=" C   GLN A  12 "
   model   vdw
   4.781 3.500
nonbonded pdb=" O   TYR A  26 "
          pdb=" CZ  TYR A  26 "
   model   vdw
   4.781 3.260
nonbonded pdb=" CB  HIS A  64 "
          pdb=" C   LEU A  83 "
   model   vdw
   4.781 3.670
nonbonded pdb=" C   ASP A  79 "
          pdb=" CD  ARG A  80 "
   model   vdw
   4.782 3.670
nonbonded pdb=" CE  LYS A  24 "
          pdb=" NH1 ARG A  82 "
   model   vdw sym.op.
   4.782 3.520 -x+1/2,y-1/2,-z+2
nonbonded pdb=" CA  VAL A  84 "
          pdb=" CB  PRO A  85 "
   model   vdw
   4.782 3.870
nonbonded pdb=" CB  ALA A  57 "
          pdb="O    HOH S  85 "
   model   vdw sym.op.
   4.782 3.460 x,y+1,z
nonbonded pdb=" CB  TYR A  61 "
          pdb=" C   PRO A  85 "
   model   vdw
   4.782 3.670
nonbonded pdb=" CB  GLN A  10 "
          pdb=" CA  LEU A  32 "
   model   vdw
   4.782 3.870
nonbonded pdb=" CB  ILE A   2 "
          pdb=" CA  LYS A   3 "
   model   vdw
   4.782 3.900
nonbonded pdb=" CA  PHE A  13 "
          pdb=" CB  GLN A  31 "
   model   vdw
   4.782 3.870
nonbonded pdb=" N   VAL A  43 "
          pdb=" CA  LEU A  44 "
   model   vdw
   4.782 3.550
nonbonded pdb=" C   VAL A  35 "
          pdb=" CG  LEU A  37 "
   model   vdw
   4.783 3.700
nonbonded pdb=" O   LYS A   7 "
          pdb=" CD  GLN A  10 "
   model   vdw
   4.783 3.270
nonbonded pdb=" CA  SER A  67 "
          pdb=" CB  ARG A  82 "
   model   vdw
   4.783 3.870
nonbonded pdb=" O   GLU A  40 "
          pdb=" N   PRO A  42 "
   model   vdw
   4.783 3.120
nonbonded pdb=" N   TYR A  61 "
          pdb=" C   PRO A  85 "
   model   vdw
   4.783 3.350
nonbonded pdb=" CB  LEU A  83 "
          pdb=" O   VAL A  84 "
   model   vdw
   4.784 3.440
nonbonded pdb=" CD  GLU A  51 "
          pdb=" CB  ARG A  21 "
   model   vdw sym.op.
   4.784 3.670 -x+1/2,y+1/2,-z+2
nonbonded pdb=" CB  ARG A  21 "
          pdb=" CD  GLU A  51 "
   model   vdw sym.op.
   4.784 3.670 -x+1/2,y-1/2,-z+2
nonbonded pdb=" CA  TYR A  34 "
          pdb=" CB  VAL A  35 "
   model   vdw
   4.784 3.900
nonbonded pdb=" O   LEU A  32 "
          pdb=" CG  LEU A  32 "
   model   vdw
   4.784 3.470
nonbonded pdb=" C   SER A  17 "
          pdb=" N   VAL A  19 "
   model   vdw
   4.784 3.350
nonbonded pdb=" CA  SER A  67 "
          pdb=" O   PHE A  68 "
   model   vdw
   4.784 3.470
nonbonded pdb=" O   PRO A  25 "
          pdb=" N   SER A  27 "
   model   vdw
   4.785 3.120
nonbonded pdb=" N   GLY A  74 "
          pdb="O    HOH S  17 "
   model   vdw sym.op.
   4.785 3.120 -x+1,y,-z+2
nonbonded pdb=" CG  ARG A  16 "
          pdb=" CG  GLU A  30 "
   model   vdw
   4.785 3.840
nonbonded pdb=" CB  GLU A   5 "
          pdb=" CE  LYS A   7 "
   model   vdw
   4.785 3.840
nonbonded pdb="O    HOH S 103 "
          pdb=" CA  GLN A  72 "
   model   vdw sym.op.
   4.785 3.470 -x,y-1,-z+1
nonbonded pdb=" CA  GLN A  72 "
          pdb="O    HOH S 103 "
   model   vdw sym.op.
   4.785 3.470 -x,y+1,-z+1
nonbonded pdb=" CA  LEU A  28 "
          pdb=" CG  ASN A  29 "
   model   vdw
   4.786 3.700
nonbonded pdb=" CB  SER A  67 "
          pdb=" CG2 ILE A  78 "
   model   vdw
   4.786 3.860
nonbonded pdb=" CA  LEU A  32 "
          pdb=" C   CYS A  33 "
   model   vdw
   4.786 3.700
nonbonded pdb=" NH2 ARG A  16 "
          pdb=" OH  TYR A  26 "
   model   vdw
   4.786 3.120
nonbonded pdb=" C   PHE A  13 "
          pdb=" C   GLU A  30 "
   model   vdw
   4.786 3.500
nonbonded pdb=" CG1 VAL A  70 "
          pdb=" CA  GLY A  71 "
   model   vdw
   4.786 3.860
nonbonded pdb=" C   GLN A  31 "
          pdb=" CG  LYS A  46 "
   model   vdw
   4.787 3.670
nonbonded pdb=" O   THR A  62 "
          pdb=" CA  HIS A  64 "
   model   vdw
   4.787 3.470
nonbonded pdb=" N   LYS A   3 "
          pdb=" CA  VAL A   4 "
   model   vdw
   4.787 3.550
nonbonded pdb=" N   VAL A  84 "
          pdb=" CA  PRO A  85 "
   model   vdw
   4.787 3.550
nonbonded pdb=" CE2 TYR A  26 "
          pdb="O    HOH S 120 "
   model   vdw
   4.788 3.340
nonbonded pdb=" C   LEU A  32 "
          pdb=" N   TYR A  34 "
   model   vdw
   4.788 3.350
nonbonded pdb=" O   LYS A   3 "
          pdb=" CG2 VAL A  35 "
   model   vdw
   4.788 3.460
nonbonded pdb=" CG  GLN A  10 "
          pdb=" N   CYS A  33 "
   model   vdw
   4.788 3.520
nonbonded pdb=" C   TYR A  56 "
          pdb=" CD2 TYR A  56 "
   model   vdw
   4.788 3.570
nonbonded pdb=" CB  LYS A   7 "
          pdb=" CD2 TYR A  34 "
   model   vdw
   4.789 3.740
nonbonded pdb=" N   THR A  15 "
          pdb=" OD1 ASN A  29 "
   model   vdw
   4.789 3.120
nonbonded pdb=" CG1 VAL A  35 "
          pdb=" N   LEU A  37 "
   model   vdw
   4.789 3.540
nonbonded pdb=" N   GLU A  30 "
          pdb=" CA  GLN A  31 "
   model   vdw
   4.789 3.550
nonbonded pdb=" CA  GLN A  53 "
          pdb=" CB  PRO A  54 "
   model   vdw
   4.789 3.870
nonbonded pdb=" C   LYS A   3 "
          pdb=" CG1 VAL A   4 "
   model   vdw
   4.790 3.690
nonbonded pdb=" O   ALA A  57 "
          pdb=" CE2 TYR A  61 "
   model   vdw
   4.790 3.340
nonbonded pdb=" O   ILE A   6 "
          pdb=" O   PRO A  58 "
   model   vdw
   4.791 3.040
nonbonded pdb=" N   LEU A  76 "
          pdb=" CA  MSE A  77 "
   model   vdw
   4.791 3.550
nonbonded pdb=" CG2 VAL A  45 "
          pdb="O    HOH S  10 "
   model   vdw
   4.791 3.460
nonbonded pdb=" C   VAL A  45 "
          pdb=" C   GLY A  74 "
   model   vdw sym.op.
   4.791 3.500 -x+1,y,-z+2
nonbonded pdb=" C   ILE A   6 "
          pdb=" CD  GLN A  10 "
   model   vdw
   4.791 3.500
nonbonded pdb=" CG  ARG A  21 "
          pdb=" CD  ARG A  82 "
   model   vdw sym.op.
   4.792 3.840 x,y-1,z
nonbonded pdb=" CD  ARG A  82 "
          pdb=" CG  ARG A  21 "
   model   vdw sym.op.
   4.792 3.840 x,y+1,z
nonbonded pdb=" C   VAL A  45 "
          pdb="O    HOH S  17 "
   model   vdw
   4.792 3.270
nonbonded pdb=" CG  LEU A  28 "
          pdb=" CG2 THR A  48 "
   model   vdw
   4.792 3.890
nonbonded pdb=" OD2 ASP A  79 "
          pdb=" CB  ARG A  80 "
   model   vdw
   4.792 3.440
nonbonded pdb=" CE1 TYR A  56 "
          pdb=" CE2 TYR A  61 "
   model   vdw
   4.792 3.640
nonbonded pdb=" CA  ILE A   6 "
          pdb=" CB  CYS A  33 "
   model   vdw
   4.793 3.870
nonbonded pdb=" N   PRO A  58 "
          pdb=" CA  GLY A  59 "
   model   vdw
   4.793 3.520
nonbonded pdb=" C   ASN A  39 "
          pdb=" OD1 ASN A  39 "
   model   vdw
   4.793 3.270
nonbonded pdb=" CA  GLY A  71 "
          pdb=" CB  GLN A  72 "
   model   vdw
   4.793 3.840
nonbonded pdb=" C   SER A  67 "
          pdb=" C   ARG A  80 "
   model   vdw
   4.793 3.500
nonbonded pdb=" N   ASP A  79 "
          pdb=" OD2 ASP A  79 "
   model   vdw
   4.793 3.120
nonbonded pdb=" C   TYR A  61 "
          pdb=" C   PRO A  85 "
   model   vdw
   4.793 3.500
nonbonded pdb=" CA  ASP A  36 "
          pdb=" CB  LEU A  37 "
   model   vdw
   4.793 3.870
nonbonded pdb=" N   HIS A  64 "
          pdb=" N   VAL A  84 "
   model   vdw
   4.793 3.200
nonbonded pdb=" CB  GLU A   5 "
          pdb=" C   ILE A   6 "
   model   vdw
   4.794 3.670
nonbonded pdb=" CB  TYR A  61 "
          pdb=" CA  PRO A  85 "
   model   vdw
   4.794 3.870
nonbonded pdb=" N   GLN A  53 "
          pdb=" CA  PRO A  54 "
   model   vdw
   4.794 3.550
nonbonded pdb=" C   THR A  14 "
          pdb=" C   ASN A  29 "
   model   vdw
   4.794 3.500
nonbonded pdb=" CD1 TYR A  34 "
          pdb="O    HOH S  24 "
   model   vdw
   4.794 3.340
nonbonded pdb=" N   SER A  17 "
          pdb=" O   TYR A  26 "
   model   vdw
   4.794 3.120
nonbonded pdb=" CB  SER A  20 "
          pdb=" CD2 TYR A  26 "
   model   vdw
   4.794 3.740
nonbonded pdb=" CB  PRO A   8 "
          pdb=" CB  PRO A  58 "
   model   vdw
   4.795 3.840
nonbonded pdb=" O   THR A  48 "
          pdb=" OD1 ASP A  50 "
   model   vdw
   4.795 3.040
nonbonded pdb=" CA  THR A  62 "
          pdb=" CB  VAL A  63 "
   model   vdw
   4.795 3.900
nonbonded pdb=" CD2 TYR A  61 "
          pdb=" CD1 LEU A  83 "
   model   vdw
   4.795 3.760
nonbonded pdb=" O   GLU A   5 "
          pdb=" CG  TYR A  34 "
   model   vdw
   4.796 3.260
nonbonded pdb=" CA  VAL A  45 "
          pdb=" CB  LYS A  46 "
   model   vdw
   4.796 3.870
nonbonded pdb=" CG  ASP A  36 "
          pdb=" CA  GLY A  38 "
   model   vdw
   4.796 3.670
nonbonded pdb=" N   ALA A  55 "
          pdb=" CA  TYR A  56 "
   model   vdw
   4.796 3.550
nonbonded pdb="O    HOH S 103 "
          pdb=" CB  GLN A  72 "
   model   vdw sym.op.
   4.797 3.440 -x,y-1,-z+1
nonbonded pdb=" CB  GLN A  72 "
          pdb="O    HOH S 103 "
   model   vdw sym.op.
   4.797 3.440 -x,y+1,-z+1
nonbonded pdb=" N   TYR A  56 "
          pdb=" CA  ALA A  57 "
   model   vdw
   4.797 3.550
nonbonded pdb=" CG1 ILE A  47 "
          pdb=" CD2 LEU A  49 "
   model   vdw
   4.797 3.860
nonbonded pdb=" NE2 GLN A  22 "
          pdb=" CD2 LEU A  28 "
   model   vdw sym.op.
   4.797 3.540 -x+1/2,y-1/2,-z+2
nonbonded pdb=" CA  PHE A  13 "
          pdb=" CB  THR A  14 "
   model   vdw
   4.797 3.900
nonbonded pdb=" CB  ARG A  82 "
          pdb=" NH1 ARG A  82 "
   model   vdw
   4.797 3.520
nonbonded pdb=" N   ARG A  16 "
          pdb=" CA  LEU A  28 "
   model   vdw
   4.798 3.550
nonbonded pdb=" N   ILE A  47 "
          pdb=" CA  THR A  48 "
   model   vdw
   4.798 3.550
nonbonded pdb=" N   ASN A  29 "
          pdb=" CG  GLU A  30 "
   model   vdw
   4.798 3.520
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" CD  GLN A  31 "
   model   vdw
   4.798 3.690
nonbonded pdb=" C   ILE A  78 "
          pdb="SE    SE Z   4 "
   model   vdw sym.op.
   4.799 3.650 x+1/2,y+3/2,z+2
nonbonded pdb=" N   GLU A   5 "
          pdb=" CD2 LEU A  60 "
   model   vdw
   4.799 3.540
nonbonded pdb=" CA  PRO A  85 "
          pdb="O    HOH S   9 "
   model   vdw
   4.799 3.470
nonbonded pdb=" CB  PHE A  13 "
          pdb=" CA  ASN A  29 "
   model   vdw
   4.799 3.870
nonbonded pdb=" C   THR A  62 "
          pdb=" CG1 VAL A  84 "
   model   vdw
   4.799 3.690
nonbonded pdb=" CB  LEU A  81 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   4.799 3.860
nonbonded pdb=" CB  VAL A  45 "
          pdb=" CB  LEU A  76 "
   model   vdw sym.op.
   4.800 3.870 -x+1,y,-z+2
nonbonded pdb=" CB  ARG A  80 "
          pdb=" O   LEU A  81 "
   model   vdw
   4.800 3.440
nonbonded pdb=" N   THR A  14 "
          pdb=" CA  THR A  15 "
   model   vdw
   4.800 3.550
nonbonded pdb=" C   TYR A  56 "
          pdb=" CD  PRO A  58 "
   model   vdw
   4.800 3.670
nonbonded pdb=" CA  GLY A  59 "
          pdb=" CD1 TYR A  61 "
   model   vdw
   4.800 3.740
nonbonded pdb=" CA  ASP A  79 "
          pdb=" CG  ARG A  80 "
   model   vdw
   4.801 3.870
nonbonded pdb=" CB  THR A  62 "
          pdb="O    HOH S  54 "
   model   vdw
   4.801 3.470
nonbonded pdb=" CB  PHE A  68 "
          pdb=" O   LYS A  69 "
   model   vdw
   4.801 3.440
nonbonded pdb=" O   TYR A  61 "
          pdb=" CG2 THR A  62 "
   model   vdw
   4.801 3.460
nonbonded pdb=" C   VAL A   4 "
          pdb=" CG  GLU A   5 "
   model   vdw
   4.801 3.670
nonbonded pdb=" CA  GLN A  72 "
          pdb=" CD2 PHE A  73 "
   model   vdw
   4.801 3.770
nonbonded pdb=" NH1 ARG A  16 "
          pdb=" CB  LEU A  60 "
   model   vdw sym.op.
   4.802 3.520 x,y-1,z
nonbonded pdb=" O   HIS A  64 "
          pdb="O    HOH S  35 "
   model   vdw
   4.802 3.040
nonbonded pdb=" O   GLY A  18 "
          pdb=" CG1 VAL A  19 "
   model   vdw
   4.802 3.460
nonbonded pdb=" CA  VAL A  19 "
          pdb=" CB  SER A  20 "
   model   vdw
   4.802 3.870
nonbonded pdb=" N   SER A  66 "
          pdb=" OG  SER A  67 "
   model   vdw
   4.802 3.120
nonbonded pdb=" C   ARG A  16 "
          pdb=" CE1 TYR A  26 "
   model   vdw
   4.803 3.570
nonbonded pdb=" C   ILE A   6 "
          pdb=" CB  GLN A  10 "
   model   vdw
   4.803 3.670
nonbonded pdb=" CB  PHE A  73 "
          pdb=" CA  GLY A  74 "
   model   vdw
   4.803 3.840
nonbonded pdb=" OE1 GLN A  72 "
          pdb=" N   LYS A   3 "
   model   vdw sym.op.
   4.804 3.120 -x+1,y-1,-z+2
nonbonded pdb=" N   LYS A   3 "
          pdb=" OE1 GLN A  72 "
   model   vdw sym.op.
   4.804 3.120 -x+1,y+1,-z+2
nonbonded pdb=" C   TYR A  41 "
          pdb=" CD2 TYR A  41 "
   model   vdw
   4.804 3.570
nonbonded pdb=" CB  ARG A  82 "
          pdb=" CA  LEU A  83 "
   model   vdw
   4.804 3.870
nonbonded pdb=" CE2 TYR A  61 "
          pdb=" CB  LEU A  83 "
   model   vdw
   4.804 3.740
nonbonded pdb=" CG  LEU A  76 "
          pdb=" C   MSE A  77 "
   model   vdw
   4.804 3.700
nonbonded pdb=" CG  LEU A  32 "
          pdb=" CD2 LEU A  44 "
   model   vdw
   4.804 3.890
nonbonded pdb=" CA  ILE A  47 "
          pdb=" OG1 THR A  48 "
   model   vdw
   4.804 3.470
nonbonded pdb=" CG2 VAL A  45 "
          pdb=" CB  VAL A  70 "
   model   vdw sym.op.
   4.804 3.890 -x+1,y,-z+2
nonbonded pdb=" CB  VAL A  70 "
          pdb=" CG2 VAL A  45 "
   model   vdw sym.op.
   4.804 3.890 -x+1,y,-z+2
nonbonded pdb=" CB  LYS A   7 "
          pdb=" CA  SER A   9 "
   model   vdw
   4.804 3.870
nonbonded pdb=" C   HIS A  64 "
          pdb=" CA  SER A  67 "
   model   vdw
   4.804 3.700
nonbonded pdb=" CD2 TYR A  61 "
          pdb=" CB  PRO A  85 "
   model   vdw
   4.805 3.740
nonbonded pdb=" CB  PHE A  13 "
          pdb=" N   GLN A  31 "
   model   vdw
   4.805 3.520
nonbonded pdb=" CA  LEU A  37 "
          pdb=" OD1 ASN A  39 "
   model   vdw
   4.805 3.470
nonbonded pdb=" O   PRO A   8 "
          pdb=" O   PHE A  13 "
   model   vdw sym.op.
   4.805 3.040 -x+1/2,y+1/2,-z+1
nonbonded pdb=" C   GLY A  18 "
          pdb=" C   PRO A  25 "
   model   vdw
   4.805 3.500
nonbonded pdb=" N   GLU A   5 "
          pdb=" CA  ILE A   6 "
   model   vdw
   4.805 3.550
nonbonded pdb=" O   SER A  66 "
          pdb=" CG  ARG A  82 "
   model   vdw
   4.806 3.440
nonbonded pdb=" O   LEU A  32 "
          pdb=" O   CYS A  33 "
   model   vdw
   4.806 3.040
nonbonded pdb=" CD  PRO A   8 "
          pdb=" CD  GLU A  40 "
   model   vdw sym.op.
   4.806 3.670 -x+1,y,-z+1
nonbonded pdb=" N   GLU A  51 "
          pdb=" CA  GLY A  52 "
   model   vdw
   4.806 3.520
nonbonded pdb=" CD1 TYR A  41 "
          pdb=" CG  PRO A  42 "
   model   vdw sym.op.
   4.806 3.740 -x+1,y,-z+1
nonbonded pdb=" CA  GLN A  31 "
          pdb=" CB  LEU A  32 "
   model   vdw
   4.807 3.870
nonbonded pdb=" C   LEU A  49 "
          pdb="O    HOH S 175 "
   model   vdw
   4.807 3.270
nonbonded pdb=" OG  SER A   9 "
          pdb=" CD  GLN A  10 "
   model   vdw
   4.807 3.270
nonbonded pdb=" CA  CYS A  33 "
          pdb=" CD1 LEU A  44 "
   model   vdw
   4.807 3.890
nonbonded pdb=" O   LYS A  46 "
          pdb=" CG1 ILE A  47 "
   model   vdw
   4.807 3.440
nonbonded pdb=" CG  TYR A  56 "
          pdb=" CE1 TYR A  61 "
   model   vdw
   4.807 3.560
nonbonded pdb=" NE2 GLN A  31 "
          pdb=" CD2 TYR A  56 "
   model   vdw
   4.807 3.420
nonbonded pdb=" CG  ASP A  36 "
          pdb=" CB  PRO A  42 "
   model   vdw
   4.807 3.670
nonbonded pdb=" CA  ARG A  21 "
          pdb=" CG  GLN A  22 "
   model   vdw
   4.807 3.870
nonbonded pdb=" N   SER A  20 "
          pdb="O    HOH S 120 "
   model   vdw
   4.808 3.120
nonbonded pdb=" C   SER A  17 "
          pdb=" CE2 TYR A  26 "
   model   vdw
   4.808 3.570
nonbonded pdb=" C   LEU A  44 "
          pdb=" CG1 VAL A  45 "
   model   vdw
   4.809 3.690
nonbonded pdb=" CB  ASP A  79 "
          pdb=" CB  ARG A  80 "
   model   vdw
   4.809 3.840
nonbonded pdb=" N   VAL A  45 "
          pdb=" CA  LYS A  46 "
   model   vdw
   4.810 3.550
nonbonded pdb=" O   ASN A  29 "
          pdb=" O   THR A  48 "
   model   vdw
   4.810 3.040
nonbonded pdb=" O   GLU A  51 "
          pdb=" CB  GLN A  53 "
   model   vdw
   4.811 3.440
nonbonded pdb=" O   PRO A  58 "
          pdb=" O   GLY A  59 "
   model   vdw
   4.811 3.040
nonbonded pdb=" NE2 GLN A  53 "
          pdb=" OH  TYR A  56 "
   model   vdw
   4.811 3.120
nonbonded pdb=" CG  LEU A  60 "
          pdb=" CD1 PHE A  73 "
   model   vdw sym.op.
   4.811 3.770 -x+1,y+1,-z+2
nonbonded pdb=" N   HIS A  64 "
          pdb=" ND1 HIS A  64 "
   model   vdw
   4.811 3.200
nonbonded pdb=" CA  LYS A  69 "
          pdb=" CB  VAL A  70 "
   model   vdw
   4.811 3.900
nonbonded pdb=" CA  VAL A  63 "
          pdb=" CB  HIS A  64 "
   model   vdw
   4.811 3.870
nonbonded pdb=" C   PRO A  58 "
          pdb=" OH  TYR A  61 "
   model   vdw
   4.811 3.270
nonbonded pdb=" CA  GLU A  30 "
          pdb=" O   GLN A  31 "
   model   vdw
   4.812 3.470
nonbonded pdb=" CG1 VAL A  70 "
          pdb=" N   GLY A  74 "
   model   vdw
   4.812 3.540
nonbonded pdb=" N   GLN A  31 "
          pdb=" CA  LEU A  32 "
   model   vdw
   4.812 3.550
nonbonded pdb=" CA  ILE A   6 "
          pdb=" CD  GLN A  10 "
   model   vdw
   4.812 3.700
nonbonded pdb=" CG  PHE A  13 "
          pdb=" O   GLU A  30 "
   model   vdw
   4.812 3.260
nonbonded pdb="O    HOH S  97 "
          pdb=" NH2 ARG A  80 "
   model   vdw sym.op.
   4.812 3.120 -x+1/2,y-1/2,-z+2
nonbonded pdb=" NH2 ARG A  80 "
          pdb="O    HOH S  97 "
   model   vdw sym.op.
   4.812 3.120 -x+1/2,y+1/2,-z+2
nonbonded pdb=" CD  PRO A   8 "
          pdb="O    HOH S 110 "
   model   vdw sym.op.
   4.813 3.440 -x+1/2,y+1/2,-z+1
nonbonded pdb=" N   ASP A  36 "
          pdb=" OD2 ASP A  36 "
   model   vdw
   4.813 3.120
nonbonded pdb=" CG2 VAL A   4 "
          pdb=" O   TYR A  34 "
   model   vdw
   4.813 3.460
nonbonded pdb=" CG  GLU A   5 "
          pdb=" CA  LYS A   7 "
   model   vdw
   4.813 3.870
nonbonded pdb=" N   GLN A  12 "
          pdb=" CB  ALA A  55 "
   model   vdw
   4.813 3.540
nonbonded pdb=" O   LEU A  81 "
          pdb=" CD2 LEU A  81 "
   model   vdw
   4.813 3.460
nonbonded pdb=" NZ  LYS A   3 "
          pdb=" OE1 GLU A   5 "
   model   vdw
   4.813 3.120
nonbonded pdb=" CG1 VAL A  70 "
          pdb=" C   GLY A  71 "
   model   vdw
   4.813 3.690
nonbonded pdb=" CG  PHE A  13 "
          pdb=" O   THR A  14 "
   model   vdw
   4.814 3.260
nonbonded pdb=" CE2 TYR A  61 "
          pdb=" CD  PRO A  85 "
   model   vdw
   4.814 3.740
nonbonded pdb=" C   GLY A  18 "
          pdb=" CA  TYR A  26 "
   model   vdw
   4.814 3.700
nonbonded pdb=" CG1 ILE A   6 "
          pdb=" N   LYS A   7 "
   model   vdw
   4.814 3.520
nonbonded pdb=" CE2 TYR A  61 "
          pdb=" CG  PRO A  85 "
   model   vdw
   4.814 3.740
nonbonded pdb=" N   LYS A  24 "
          pdb=" CD  LYS A  24 "
   model   vdw
   4.814 3.520
nonbonded pdb=" O   ASP A  50 "
          pdb=" CG  GLN A  53 "
   model   vdw
   4.815 3.440
nonbonded pdb=" CA  VAL A  35 "
          pdb=" CB  ASP A  36 "
   model   vdw
   4.815 3.870
nonbonded pdb=" CZ  ARG A  82 "
          pdb="O    HOH S  97 "
   model   vdw sym.op.
   4.815 3.270 -x+1/2,y+1/2,-z+2
nonbonded pdb="O    HOH S  97 "
          pdb=" CZ  ARG A  82 "
   model   vdw sym.op.
   4.815 3.270 -x+1/2,y-1/2,-z+2
nonbonded pdb=" O   ILE A   2 "
          pdb=" CG2 VAL A  63 "
   model   vdw
   4.816 3.460
nonbonded pdb=" CA  GLY A  71 "
          pdb=" C   SER A  75 "
   model   vdw
   4.816 3.670
nonbonded pdb=" C   CYS A  33 "
          pdb=" CE2 TYR A  34 "
   model   vdw
   4.816 3.570
nonbonded pdb=" CB  VAL A  35 "
          pdb=" CB  VAL A  45 "
   model   vdw
   4.817 3.900
nonbonded pdb=" C   TYR A  34 "
          pdb=" CD2 TYR A  34 "
   model   vdw
   4.817 3.570
nonbonded pdb=" CG  TYR A  61 "
          pdb=" C   PRO A  85 "
   model   vdw
   4.817 3.490
nonbonded pdb=" CA  PRO A  58 "
          pdb=" C   GLY A  59 "
   model   vdw
   4.817 3.700
nonbonded pdb=" O   VAL A   4 "
          pdb=" C   GLY A  59 "
   model   vdw
   4.817 3.270
nonbonded pdb=" O   TYR A  61 "
          pdb=" O   VAL A  84 "
   model   vdw
   4.817 3.040
nonbonded pdb=" CA  GLN A  10 "
          pdb=" CB  ALA A  11 "
   model   vdw
   4.817 3.890
nonbonded pdb=" ND1 HIS A  64 "
          pdb=" CB  LEU A  65 "
   model   vdw
   4.817 3.520
nonbonded pdb=" CA  LEU A  28 "
          pdb=" O   ASN A  29 "
   model   vdw
   4.818 3.470
nonbonded pdb=" CA  GLN A  22 "
          pdb=" C   GLY A  23 "
   model   vdw
   4.818 3.700
nonbonded pdb=" C   TYR A  56 "
          pdb=" CZ  TYR A  61 "
   model   vdw
   4.818 3.490
nonbonded pdb=" CA  LYS A   3 "
          pdb=" CB  ASP A  36 "
   model   vdw
   4.818 3.870
nonbonded pdb=" CB  GLN A  72 "
          pdb=" CE2 PHE A  73 "
   model   vdw
   4.818 3.740
nonbonded pdb=" CA  GLU A  51 "
          pdb=" OE2 GLU A  51 "
   model   vdw
   4.818 3.470
nonbonded pdb=" CD1 LEU A  32 "
          pdb=" CD1 LEU A  44 "
   model   vdw
   4.818 3.880
nonbonded pdb=" OG  SER A  20 "
          pdb=" CG  LYS A  24 "
   model   vdw
   4.818 3.440
nonbonded pdb=" CG  TYR A  56 "
          pdb=" CG  LEU A  83 "
   model   vdw
   4.818 3.690
nonbonded pdb=" OG  SER A  75 "
          pdb=" CA  LEU A  76 "
   model   vdw
   4.818 3.470
nonbonded pdb=" N   SER A  67 "
          pdb=" CG  ARG A  82 "
   model   vdw
   4.818 3.520
nonbonded pdb=" OD1 ASP A  50 "
          pdb=" CD  ARG A  82 "
   model   vdw
   4.819 3.440
nonbonded pdb=" CA  VAL A  70 "
          pdb=" CD1 LEU A  76 "
   model   vdw
   4.819 3.890
nonbonded pdb=" CB  ASP A  36 "
          pdb=" CA  LEU A  37 "
   model   vdw
   4.819 3.870
nonbonded pdb=" CA  GLU A   5 "
          pdb=" CB  ILE A   6 "
   model   vdw
   4.819 3.900
nonbonded pdb=" C   MSE A  77 "
          pdb=" CG1 ILE A  78 "
   model   vdw sym.op.
   4.820 3.670 -x+1,y,-z+2
nonbonded pdb=" CG1 ILE A  78 "
          pdb=" C   MSE A  77 "
   model   vdw sym.op.
   4.820 3.670 -x+1,y,-z+2
nonbonded pdb=" O   GLU A   5 "
          pdb=" CD  GLN A  10 "
   model   vdw
   4.821 3.270
nonbonded pdb=" N   THR A  62 "
          pdb=" CA  VAL A  63 "
   model   vdw
   4.821 3.550
nonbonded pdb=" O   THR A  14 "
          pdb=" O   ASN A  29 "
   model   vdw
   4.821 3.040
nonbonded pdb=" C   ILE A  78 "
          pdb=" CA  ARG A  80 "
   model   vdw
   4.821 3.700
nonbonded pdb=" CA  GLU A   5 "
          pdb=" OE2 GLU A   5 "
   model   vdw
   4.821 3.470
nonbonded pdb=" O   VAL A  35 "
          pdb=" O   PRO A  42 "
   model   vdw
   4.821 3.040
nonbonded pdb=" C   THR A  15 "
          pdb=" C   LEU A  28 "
   model   vdw
   4.821 3.500
nonbonded pdb=" C   LEU A  65 "
          pdb=" C   SER A  67 "
   model   vdw
   4.822 3.500
nonbonded pdb=" CG  ASN A  39 "
          pdb=" O   TYR A  41 "
   model   vdw
   4.822 3.270
nonbonded pdb=" C   GLU A  51 "
          pdb=" OE1 GLU A  51 "
   model   vdw
   4.822 3.270
nonbonded pdb=" C   TYR A  61 "
          pdb=" C   VAL A  84 "
   model   vdw
   4.823 3.500
nonbonded pdb=" O   ASP A  50 "
          pdb="O    HOH S 175 "
   model   vdw
   4.823 3.040
nonbonded pdb=" CA  SER A  66 "
          pdb=" O   PHE A  68 "
   model   vdw
   4.823 3.470
nonbonded pdb=" CE1 PHE A  68 "
          pdb=" CD2 LEU A  76 "
   model   vdw
   4.823 3.760
nonbonded pdb=" CB  PHE A  68 "
          pdb=" C   MSE A  77 "
   model   vdw
   4.823 3.670
nonbonded pdb=" N   GLN A  53 "
          pdb=" CD  GLN A  53 "
   model   vdw
   4.823 3.350
nonbonded pdb=" CA  SER A  20 "
          pdb=" CE2 TYR A  26 "
   model   vdw
   4.824 3.770
nonbonded pdb=" C   SER A  20 "
          pdb=" CG  ARG A  21 "
   model   vdw
   4.824 3.670
nonbonded pdb=" CA  SER A  75 "
          pdb=" CB  LEU A  76 "
   model   vdw
   4.824 3.870
nonbonded pdb=" CA  TYR A  56 "
          pdb=" CB  ALA A  57 "
   model   vdw
   4.824 3.890
nonbonded pdb=" O   LEU A  60 "
          pdb="O    HOH S   9 "
   model   vdw
   4.826 3.040
nonbonded pdb=" N   SER A  17 "
          pdb=" CA  GLY A  18 "
   model   vdw
   4.826 3.520
nonbonded pdb=" CG  HIS A  64 "
          pdb=" CB  VAL A  84 "
   model   vdw
   4.826 3.690
nonbonded pdb=" CE2 TYR A  26 "
          pdb="O    HOH S  85 "
   model   vdw
   4.826 3.340
nonbonded pdb=" CB  ASP A  50 "
          pdb=" NH1 ARG A  80 "
   model   vdw
   4.826 3.520
nonbonded pdb=" N   LEU A  81 "
          pdb="O    HOH S  10 "
   model   vdw
   4.827 3.120
nonbonded pdb=" C   PHE A  73 "
          pdb=" CD2 PHE A  73 "
   model   vdw
   4.827 3.570
nonbonded pdb=" O   GLN A  22 "
          pdb=" CD  GLN A  22 "
   model   vdw
   4.827 3.270
nonbonded pdb=" CA  THR A  62 "
          pdb=" CG2 VAL A  63 "
   model   vdw
   4.827 3.890
nonbonded pdb=" CG1 ILE A  47 "
          pdb="O    HOH S 106 "
   model   vdw
   4.827 3.440
nonbonded pdb="O    HOH S 163 "
          pdb=" CB  ILE A   2 "
   model   vdw sym.op.
   4.827 3.470 x,y,z
nonbonded pdb=" CB  ILE A   2 "
          pdb="O    HOH S 163 "
   model   vdw sym.op.
   4.827 3.470 x,y,z
nonbonded pdb="O    HOH S 163 "
          pdb=" CB  ILE A   2 "
   model   vdw sym.op.
   4.827 3.470 -x+1,y,-z+2
nonbonded pdb=" CA  LYS A  69 "
          pdb=" O   VAL A  70 "
   model   vdw
   4.827 3.470
nonbonded pdb=" CA  GLY A  74 "
          pdb=" CB  SER A  75 "
   model   vdw
   4.827 3.840
nonbonded pdb=" N   HIS A  64 "
          pdb=" CA  LEU A  65 "
   model   vdw
   4.827 3.550
nonbonded pdb=" O   GLN A  10 "
          pdb=" O   TYR A  56 "
   model   vdw
   4.828 3.040
nonbonded pdb=" N   PHE A  13 "
          pdb=" CA  THR A  14 "
   model   vdw
   4.828 3.550
nonbonded pdb=" CA  LEU A  44 "
          pdb=" O   VAL A  45 "
   model   vdw
   4.828 3.470
nonbonded pdb=" N   TYR A  41 "
          pdb=" CA  PRO A  42 "
   model   vdw
   4.828 3.550
nonbonded pdb=" CE  LYS A  24 "
          pdb=" OD1 ASP A  50 "
   model   vdw sym.op.
   4.828 3.440 -x+1/2,y-1/2,-z+2
nonbonded pdb=" OD1 ASP A  50 "
          pdb=" CE  LYS A  24 "
   model   vdw sym.op.
   4.828 3.440 -x+1/2,y+1/2,-z+2
nonbonded pdb=" CG  ARG A  80 "
          pdb=" CZ  ARG A  82 "
   model   vdw
   4.828 3.670
nonbonded pdb=" N   LYS A  24 "
          pdb=" CA  PRO A  25 "
   model   vdw
   4.828 3.550
nonbonded pdb=" OD1 ASP A  79 "
          pdb=" NE  ARG A  80 "
   model   vdw
   4.828 3.120
nonbonded pdb=" N   ASP A  50 "
          pdb=" CA  GLU A  51 "
   model   vdw
   4.829 3.550
nonbonded pdb=" CZ  TYR A  56 "
          pdb=" C   ARG A  82 "
   model   vdw
   4.829 3.490
nonbonded pdb=" N   ILE A   6 "
          pdb=" CA  GLY A  59 "
   model   vdw
   4.829 3.520
nonbonded pdb=" OE1 GLN A  12 "
          pdb=" N   GLY A  59 "
   model   vdw sym.op.
   4.829 3.120 -x+1/2,y-1/2,-z+1
nonbonded pdb=" C   LYS A  69 "
          pdb=" CG  LEU A  76 "
   model   vdw
   4.829 3.700
nonbonded pdb=" CG1 ILE A  47 "
          pdb=" CE2 TYR A  56 "
   model   vdw
   4.829 3.740
nonbonded pdb=" CB  SER A   9 "
          pdb=" C   THR A  15 "
   model   vdw sym.op.
   4.829 3.670 -x+1/2,y+1/2,-z+1
nonbonded pdb=" C   LYS A  69 "
          pdb=" CG1 VAL A  70 "
   model   vdw
   4.829 3.690
nonbonded pdb=" C   GLN A  12 "
          pdb=" CD  GLN A  31 "
   model   vdw
   4.829 3.500
nonbonded pdb=" O   PHE A  73 "
          pdb=" CA  SER A  75 "
   model   vdw
   4.830 3.470
nonbonded pdb=" CA  HIS A  64 "
          pdb=" CB  LEU A  65 "
   model   vdw
   4.830 3.870
nonbonded pdb=" CZ  TYR A  34 "
          pdb=" CG  LEU A  44 "
   model   vdw
   4.830 3.690
nonbonded pdb=" CE1 HIS A  64 "
          pdb=" CA  LEU A  65 "
   model   vdw
   4.830 3.690
nonbonded pdb=" CA  PHE A  13 "
          pdb=" CG2 THR A  14 "
   model   vdw
   4.830 3.890
nonbonded pdb=" N   LYS A  69 "
          pdb=" CA  VAL A  70 "
   model   vdw
   4.830 3.550
nonbonded pdb=" CB  ARG A  21 "
          pdb=" CB  GLN A  22 "
   model   vdw
   4.830 3.840
nonbonded pdb=" CA  TYR A  34 "
          pdb=" N   LEU A  44 "
   model   vdw
   4.831 3.550
nonbonded pdb=" NE2 HIS A  64 "
          pdb=" N   SER A  66 "
   model   vdw
   4.831 3.200
nonbonded pdb=" N   LEU A  76 "
          pdb="SE    SE Z   3 "
   model   vdw sym.op.
   4.831 3.500 -x+1/2,y+3/2,-z+1
nonbonded pdb=" NH2 ARG A  16 "
          pdb=" O   PRO A  58 "
   model   vdw sym.op.
   4.831 3.120 x,y-1,z
nonbonded pdb=" OE1 GLN A  22 "
          pdb=" CB  TYR A  26 "
   model   vdw sym.op.
   4.832 3.440 -x+1/2,y-1/2,-z+2
nonbonded pdb=" CD1 TYR A  26 "
          pdb="O    HOH S  85 "
   model   vdw
   4.832 3.340
nonbonded pdb=" OH  TYR A  56 "
          pdb=" CD1 LEU A  83 "
   model   vdw
   4.832 3.460
nonbonded pdb=" C   SER A  66 "
          pdb=" C   PHE A  68 "
   model   vdw
   4.832 3.500
nonbonded pdb=" CE2 PHE A  13 "
          pdb=" ND2 ASN A  29 "
   model   vdw
   4.832 3.420
nonbonded pdb=" N   LEU A  65 "
          pdb=" C   SER A  66 "
   model   vdw
   4.832 3.350
nonbonded pdb=" O   SER A  17 "
          pdb=" O   GLY A  18 "
   model   vdw
   4.833 3.040
nonbonded pdb=" CB  LEU A  81 "
          pdb=" CA  ARG A  82 "
   model   vdw
   4.833 3.870
nonbonded pdb=" CA  SER A  17 "
          pdb=" C   GLY A  18 "
   model   vdw
   4.833 3.700
nonbonded pdb=" N   TYR A  26 "
          pdb=" CA  SER A  27 "
   model   vdw
   4.833 3.550
nonbonded pdb=" CB  GLN A  10 "
          pdb=" CA  ALA A  11 "
   model   vdw
   4.834 3.870
nonbonded pdb=" CD1 TYR A  56 "
          pdb="O    HOH S  81 "
   model   vdw sym.op.
   4.834 3.340 x,y+1,z
nonbonded pdb=" O   TYR A  26 "
          pdb=" O   SER A  27 "
   model   vdw
   4.834 3.040
nonbonded pdb=" O   THR A  14 "
          pdb=" CG  ASN A  29 "
   model   vdw
   4.835 3.270
nonbonded pdb=" CA  PRO A  54 "
          pdb=" CB  ALA A  55 "
   model   vdw
   4.835 3.890
nonbonded pdb=" CG2 ILE A  47 "
          pdb=" CA  LEU A  81 "
   model   vdw
   4.835 3.890
nonbonded pdb=" NE2 GLN A  31 "
          pdb="O    HOH S   7 "
   model   vdw
   4.835 3.120
nonbonded pdb=" O   PRO A  58 "
          pdb=" OH  TYR A  61 "
   model   vdw
   4.835 3.040
nonbonded pdb=" CB  SER A   9 "
          pdb=" CG  GLN A  10 "
   model   vdw
   4.835 3.840
nonbonded pdb=" CG  PHE A  13 "
          pdb=" CA  THR A  14 "
   model   vdw
   4.835 3.690
nonbonded pdb=" OG  SER A  20 "
          pdb=" CB  ARG A  21 "
   model   vdw
   4.835 3.440
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" CG  PRO A  58 "
   model   vdw
   4.835 3.860
nonbonded pdb=" CB  LYS A  24 "
          pdb=" NZ  LYS A  24 "
   model   vdw
   4.835 3.520
nonbonded pdb=" OE1 GLU A   5 "
          pdb="O    HOH S  51 "
   model   vdw
   4.835 3.040
nonbonded pdb=" CA  THR A  15 "
          pdb=" CB  ARG A  16 "
   model   vdw
   4.836 3.870
nonbonded pdb=" N   SER A   9 "
          pdb=" CB  GLN A  10 "
   model   vdw
   4.836 3.520
nonbonded pdb=" O   TYR A  26 "
          pdb=" CE2 TYR A  26 "
   model   vdw
   4.836 3.340
nonbonded pdb=" CE1 HIS A  64 "
          pdb=" C   LEU A  65 "
   model   vdw
   4.836 3.490
nonbonded pdb=" CD  LYS A  69 "
          pdb=" O   VAL A  70 "
   model   vdw
   4.836 3.440
nonbonded pdb=" C   GLN A  12 "
          pdb=" NE2 GLN A  31 "
   model   vdw
   4.837 3.350
nonbonded pdb=" N   PRO A  42 "
          pdb=" CA  VAL A  43 "
   model   vdw
   4.838 3.550
nonbonded pdb=" CA  LYS A  24 "
          pdb=" NH2 ARG A  82 "
   model   vdw sym.op.
   4.838 3.550 -x+1/2,y-1/2,-z+2
nonbonded pdb=" NH2 ARG A  82 "
          pdb=" CA  LYS A  24 "
   model   vdw sym.op.
   4.838 3.550 -x+1/2,y+1/2,-z+2
nonbonded pdb=" CA  PRO A  58 "
          pdb=" O   GLY A  59 "
   model   vdw
   4.838 3.470
nonbonded pdb=" CG  LYS A  69 "
          pdb=" C   ILE A  78 "
   model   vdw
   4.839 3.670
nonbonded pdb=" O   CYS A  33 "
          pdb=" O   LEU A  44 "
   model   vdw
   4.839 3.040
nonbonded pdb=" CA  GLY A  59 "
          pdb=" O   LEU A  60 "
   model   vdw
   4.839 3.440
nonbonded pdb=" C   GLY A  23 "
          pdb=" CG  LYS A  24 "
   model   vdw
   4.839 3.670
nonbonded pdb=" CD1 ILE A   6 "
          pdb=" N   CYS A  33 "
   model   vdw
   4.839 3.540
nonbonded pdb=" N   VAL A   4 "
          pdb=" CA  THR A  62 "
   model   vdw
   4.839 3.550
nonbonded pdb=" CA  ASP A  50 "
          pdb=" CB  GLU A  51 "
   model   vdw
   4.840 3.870
nonbonded pdb=" CG1 VAL A  43 "
          pdb=" CA  LEU A  44 "
   model   vdw
   4.840 3.890
nonbonded pdb=" C   ARG A  80 "
          pdb=" CB  ARG A  82 "
   model   vdw
   4.840 3.670
nonbonded pdb=" CB  LYS A   7 "
          pdb=" CB  SER A   9 "
   model   vdw
   4.840 3.840
nonbonded pdb=" O   VAL A   4 "
          pdb=" O   LEU A  60 "
   model   vdw
   4.840 3.040
nonbonded pdb=" NH1 ARG A  21 "
          pdb=" CD  GLN A  22 "
   model   vdw
   4.840 3.350
nonbonded pdb=" CG1 VAL A   4 "
          pdb=" N   TYR A  34 "
   model   vdw
   4.840 3.540
nonbonded pdb=" CA  LEU A  60 "
          pdb=" CE1 TYR A  61 "
   model   vdw
   4.840 3.770
nonbonded pdb=" CD1 ILE A  47 "
          pdb=" CZ  TYR A  56 "
   model   vdw
   4.841 3.680
nonbonded pdb=" O   LEU A  65 "
          pdb=" CB  SER A  67 "
   model   vdw
   4.841 3.440
nonbonded pdb=" C   ASP A  36 "
          pdb=" CG  LEU A  65 "
   model   vdw sym.op.
   4.842 3.700 -x+1,y,-z+2
nonbonded pdb=" CB  SER A  67 "
          pdb=" CA  ARG A  82 "
   model   vdw
   4.842 3.870
nonbonded pdb=" CG  LYS A   7 "
          pdb=" OG  SER A   9 "
   model   vdw
   4.842 3.440
nonbonded pdb=" CA  VAL A  35 "
          pdb=" CG1 VAL A  43 "
   model   vdw
   4.842 3.890
nonbonded pdb=" C   VAL A  45 "
          pdb=" CG  LYS A  46 "
   model   vdw
   4.842 3.670
nonbonded pdb=" CA  SER A  17 "
          pdb=" O   GLY A  18 "
   model   vdw
   4.842 3.470
nonbonded pdb=" CA  THR A  48 "
          pdb=" CB  LEU A  49 "
   model   vdw
   4.843 3.870
nonbonded pdb=" N   LEU A  65 "
          pdb=" OG  SER A  66 "
   model   vdw
   4.843 3.120
nonbonded pdb=" CB  TYR A  61 "
          pdb=" N   PRO A  85 "
   model   vdw
   4.843 3.520
nonbonded pdb=" OG  SER A  66 "
          pdb=" CG  ARG A  21 "
   model   vdw sym.op.
   4.843 3.440 x,y+1,z
nonbonded pdb=" CG  ARG A  21 "
          pdb=" OG  SER A  66 "
   model   vdw sym.op.
   4.843 3.440 x,y-1,z
nonbonded pdb=" N   HIS A  64 "
          pdb=" N   LEU A  83 "
   model   vdw
   4.843 3.200
nonbonded pdb=" C   LEU A  65 "
          pdb=" CB  SER A  67 "
   model   vdw
   4.843 3.670
nonbonded pdb=" CB  GLN A  72 "
          pdb=" CG  PHE A  73 "
   model   vdw
   4.845 3.660
nonbonded pdb=" CG  LYS A  69 "
          pdb=" CG  ASP A  79 "
   model   vdw
   4.845 3.670
nonbonded pdb=" CA  ILE A  78 "
          pdb=" CB  ASP A  79 "
   model   vdw
   4.845 3.870
nonbonded pdb=" CD1 PHE A  68 "
          pdb=" CG1 ILE A  78 "
   model   vdw sym.op.
   4.845 3.740 -x+1,y,-z+2
nonbonded pdb=" CG1 ILE A  78 "
          pdb=" CD1 PHE A  68 "
   model   vdw sym.op.
   4.845 3.740 -x+1,y,-z+2
nonbonded pdb=" CD1 PHE A  68 "
          pdb=" N   ILE A  78 "
   model   vdw
   4.846 3.420
nonbonded pdb=" N   THR A  62 "
          pdb=" CA  VAL A  84 "
   model   vdw
   4.846 3.550
nonbonded pdb=" CD  LYS A  46 "
          pdb=" O   ILE A  47 "
   model   vdw
   4.846 3.440
nonbonded pdb=" O   ARG A  80 "
          pdb="O    HOH S 106 "
   model   vdw
   4.847 3.040
nonbonded pdb=" C   CYS A  33 "
          pdb=" C   LEU A  44 "
   model   vdw
   4.847 3.500
nonbonded pdb=" N   SER A   9 "
          pdb=" CG  GLN A  10 "
   model   vdw
   4.847 3.520
nonbonded pdb=" O   VAL A  35 "
          pdb=" N   PRO A  42 "
   model   vdw
   4.847 3.120
nonbonded pdb=" OD1 ASP A  36 "
          pdb=" O   ASN A  39 "
   model   vdw
   4.847 3.040
nonbonded pdb=" CA  SER A  67 "
          pdb=" CD  ARG A  82 "
   model   vdw
   4.847 3.870
nonbonded pdb=" CA  PRO A   8 "
          pdb=" CB  SER A   9 "
   model   vdw
   4.847 3.870
nonbonded pdb=" NE2 HIS A  64 "
          pdb=" OG  SER A  66 "
   model   vdw
   4.847 3.120
nonbonded pdb=" OD1 ASP A  36 "
          pdb="O    HOH S   2 "
   model   vdw
   4.848 3.040
nonbonded pdb=" CA  ASP A  36 "
          pdb="O    HOH S 123 "
   model   vdw
   4.848 3.470
nonbonded pdb=" CA  GLU A   5 "
          pdb=" CG1 ILE A   6 "
   model   vdw
   4.848 3.870
nonbonded pdb=" N   SER A  66 "
          pdb=" CB  SER A  67 "
   model   vdw
   4.848 3.520
nonbonded pdb=" CA  ARG A  80 "
          pdb=" CB  LEU A  81 "
   model   vdw
   4.848 3.870
nonbonded pdb=" O   ASP A  79 "
          pdb=" N   LEU A  81 "
   model   vdw
   4.848 3.120
nonbonded pdb=" CA  ILE A   6 "
          pdb=" CB  LYS A   7 "
   model   vdw
   4.849 3.870
nonbonded pdb=" O   GLU A   5 "
          pdb=" SG  CYS A  33 "
   model   vdw
   4.849 3.400
nonbonded pdb=" C   THR A  14 "
          pdb=" CG2 THR A  15 "
   model   vdw
   4.849 3.690
nonbonded pdb=" C   PHE A  68 "
          pdb=" C   MSE A  77 "
   model   vdw
   4.849 3.500
nonbonded pdb=" NZ  LYS A   3 "
          pdb=" CG  LEU A  60 "
   model   vdw
   4.850 3.550
nonbonded pdb=" CG  GLN A  10 "
          pdb=" CA  LEU A  32 "
   model   vdw
   4.850 3.870
nonbonded pdb=" N   ALA A  57 "
          pdb=" CA  PRO A  58 "
   model   vdw
   4.851 3.550
nonbonded pdb=" N   LEU A  49 "
          pdb=" CA  ASP A  50 "
   model   vdw
   4.851 3.550
nonbonded pdb=" N   ASN A  39 "
          pdb=" CA  GLU A  40 "
   model   vdw
   4.852 3.550
nonbonded pdb=" OE1 GLN A  12 "
          pdb=" N   PHE A  13 "
   model   vdw
   4.852 3.120
nonbonded pdb=" N   THR A  62 "
          pdb=" CG1 VAL A  84 "
   model   vdw
   4.852 3.540
nonbonded pdb=" O   ASN A  39 "
          pdb=" CG  ASN A  39 "
   model   vdw
   4.852 3.270
nonbonded pdb=" OG  SER A  17 "
          pdb=" C   GLY A  18 "
   model   vdw
   4.852 3.270
nonbonded pdb=" N   PHE A  73 "
          pdb=" CE1 PHE A  73 "
   model   vdw
   4.852 3.420
nonbonded pdb=" CB  LEU A  32 "
          pdb=" CG  LEU A  44 "
   model   vdw
   4.853 3.870
nonbonded pdb=" CB  PRO A   8 "
          pdb=" CA  THR A  15 "
   model   vdw sym.op.
   4.853 3.870 -x+1/2,y+1/2,-z+1
nonbonded pdb=" N   PRO A   8 "
          pdb=" C   SER A   9 "
   model   vdw
   4.853 3.350
nonbonded pdb=" C   TYR A  34 "
          pdb=" CG1 VAL A  35 "
   model   vdw
   4.853 3.690
nonbonded pdb=" C   GLU A  51 "
          pdb=" OE2 GLU A  51 "
   model   vdw
   4.854 3.270
nonbonded pdb=" OG1 THR A  15 "
          pdb=" C   LEU A  28 "
   model   vdw
   4.854 3.270
nonbonded pdb=" CG2 VAL A  43 "
          pdb=" C   LEU A  44 "
   model   vdw
   4.854 3.690
nonbonded pdb=" C   SER A  17 "
          pdb="O    HOH S  34 "
   model   vdw
   4.854 3.270
nonbonded pdb=" C   SER A  20 "
          pdb=" C   GLY A  23 "
   model   vdw
   4.855 3.500
nonbonded pdb=" N   GLY A  52 "
          pdb=" C   GLN A  53 "
   model   vdw
   4.855 3.350
nonbonded pdb=" N   SER A  75 "
          pdb=" CA  LEU A  76 "
   model   vdw
   4.855 3.550
nonbonded pdb=" N   PHE A  68 "
          pdb=" CE1 PHE A  68 "
   model   vdw
   4.855 3.420
nonbonded pdb=" O   TYR A  41 "
          pdb=" CB  VAL A  43 "
   model   vdw
   4.856 3.470
nonbonded pdb=" CD1 TYR A  41 "
          pdb=" N   PRO A  42 "
   model   vdw
   4.856 3.420
nonbonded pdb=" O   ILE A   2 "
          pdb=" N   THR A  62 "
   model   vdw
   4.856 3.120
nonbonded pdb=" O   SER A   9 "
          pdb=" O   GLN A  10 "
   model   vdw
   4.856 3.040
nonbonded pdb=" O   LEU A  60 "
          pdb=" CZ  TYR A  61 "
   model   vdw
   4.856 3.260
nonbonded pdb=" OE1 GLN A  10 "
          pdb=" CG  TYR A  34 "
   model   vdw
   4.856 3.260
nonbonded pdb=" CA  LEU A  49 "
          pdb=" CB  ASP A  50 "
   model   vdw
   4.857 3.870
nonbonded pdb=" CB  LEU A  37 "
          pdb=" CA  GLY A  38 "
   model   vdw
   4.857 3.840
nonbonded pdb=" CA  VAL A  63 "
          pdb=" OG  SER A  67 "
   model   vdw
   4.857 3.470
nonbonded pdb=" CG2 VAL A  45 "
          pdb=" CA  SER A  75 "
   model   vdw sym.op.
   4.857 3.890 -x+1,y,-z+2
nonbonded pdb=" C   GLU A   5 "
          pdb=" CG2 ILE A   6 "
   model   vdw
   4.857 3.690
nonbonded pdb=" N   VAL A   4 "
          pdb=" N   THR A  62 "
   model   vdw
   4.857 3.200
nonbonded pdb=" CB  TYR A  34 "
          pdb=" C   PRO A  42 "
   model   vdw
   4.858 3.670
nonbonded pdb=" O   LEU A  60 "
          pdb=" N   THR A  62 "
   model   vdw
   4.858 3.120
nonbonded pdb=" O   PRO A  42 "
          pdb=" CG2 VAL A  43 "
   model   vdw
   4.858 3.460
nonbonded pdb=" C   PHE A  73 "
          pdb=" OG  SER A  75 "
   model   vdw
   4.858 3.270
nonbonded pdb=" C   THR A  15 "
          pdb=" N   SER A   9 "
   model   vdw sym.op.
   4.859 3.350 -x+1/2,y-1/2,-z+1
nonbonded pdb=" N   SER A   9 "
          pdb=" C   THR A  15 "
   model   vdw sym.op.
   4.859 3.350 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CE2 TYR A  61 "
          pdb=" CB  PRO A  85 "
   model   vdw
   4.859 3.740
nonbonded pdb=" CA  ALA A  55 "
          pdb=" CB  TYR A  56 "
   model   vdw
   4.859 3.870
nonbonded pdb=" CG  TYR A  26 "
          pdb=" CG  PRO A  85 "
   model   vdw sym.op.
   4.859 3.660 x,y-1,z
nonbonded pdb=" CG  TYR A  41 "
          pdb=" CE1 TYR A  34 "
   model   vdw sym.op.
   4.860 3.560 -x+1,y,-z+1
nonbonded pdb=" CE1 TYR A  34 "
          pdb=" CG  TYR A  41 "
   model   vdw sym.op.
   4.860 3.560 -x+1,y,-z+1
nonbonded pdb=" N   PRO A  54 "
          pdb=" CA  ALA A  55 "
   model   vdw
   4.860 3.550
nonbonded pdb=" N   GLU A  40 "
          pdb="O    HOH S 131 "
   model   vdw
   4.861 3.120
nonbonded pdb=" CB  HIS A  64 "
          pdb=" C   LEU A  65 "
   model   vdw
   4.861 3.670
nonbonded pdb=" CB  LYS A  46 "
          pdb=" N   SER A  75 "
   model   vdw sym.op.
   4.861 3.520 -x+1,y,-z+2
nonbonded pdb=" N   ASP A  79 "
          pdb=" C   ARG A  80 "
   model   vdw
   4.862 3.350
nonbonded pdb=" CB  GLN A  31 "
          pdb=" C   LEU A  32 "
   model   vdw
   4.862 3.670
nonbonded pdb=" CB  THR A  62 "
          pdb=" CE1 PHE A  73 "
   model   vdw sym.op.
   4.862 3.770 -x+1,y+1,-z+2
nonbonded pdb=" N   PRO A  25 "
          pdb=" CA  TYR A  26 "
   model   vdw
   4.862 3.550
nonbonded pdb=" CG  GLU A   5 "
          pdb=" CG  LYS A   7 "
   model   vdw
   4.862 3.840
nonbonded pdb=" C   LYS A   3 "
          pdb=" CG1 VAL A  35 "
   model   vdw
   4.862 3.690
nonbonded pdb=" C   PRO A   8 "
          pdb=" C   GLN A  10 "
   model   vdw
   4.862 3.500
nonbonded pdb=" N   ASP A  50 "
          pdb=" CB  GLN A  53 "
   model   vdw
   4.862 3.520
nonbonded pdb=" CG  TYR A  34 "
          pdb=" O   PRO A  42 "
   model   vdw
   4.863 3.260
nonbonded pdb=" CB  ASP A  36 "
          pdb="O    HOH S 123 "
   model   vdw
   4.863 3.440
nonbonded pdb=" N   LYS A   7 "
          pdb=" CA  PRO A   8 "
   model   vdw
   4.864 3.550
nonbonded pdb=" CA  GLY A  38 "
          pdb=" CB  ASN A  39 "
   model   vdw
   4.864 3.840
nonbonded pdb=" O   ARG A  21 "
          pdb=" CD  GLN A  22 "
   model   vdw
   4.864 3.270
nonbonded pdb=" O   THR A  62 "
          pdb=" C   ARG A  82 "
   model   vdw
   4.864 3.270
nonbonded pdb=" CB  ILE A  78 "
          pdb=" C   ASP A  79 "
   model   vdw
   4.864 3.700
nonbonded pdb=" CB  SER A  17 "
          pdb=" CA  SER A  27 "
   model   vdw
   4.864 3.870
nonbonded pdb=" CE2 TYR A  41 "
          pdb=" CD  PRO A  42 "
   model   vdw sym.op.
   4.864 3.740 -x+1,y,-z+1
nonbonded pdb=" CD  PRO A  42 "
          pdb=" CE2 TYR A  41 "
   model   vdw sym.op.
   4.864 3.740 -x+1,y,-z+1
nonbonded pdb=" CG  ASP A  50 "
          pdb=" CD  ARG A  80 "
   model   vdw
   4.864 3.670
nonbonded pdb=" CA  GLY A  18 "
          pdb=" O   VAL A  19 "
   model   vdw
   4.864 3.440
nonbonded pdb=" CD  LYS A  46 "
          pdb=" OG1 THR A  48 "
   model   vdw
   4.864 3.440
nonbonded pdb=" O   ARG A  16 "
          pdb=" CD1 LEU A  28 "
   model   vdw
   4.865 3.460
nonbonded pdb=" CZ  TYR A  41 "
          pdb=" CZ  TYR A  34 "
   model   vdw sym.op.
   4.865 3.480 -x+1,y,-z+1
nonbonded pdb=" CZ  TYR A  34 "
          pdb=" CZ  TYR A  41 "
   model   vdw sym.op.
   4.865 3.480 -x+1,y,-z+1
nonbonded pdb=" C   LEU A  81 "
          pdb=" CG  LEU A  83 "
   model   vdw
   4.865 3.700
nonbonded pdb=" C   ASN A  29 "
          pdb=" C   THR A  48 "
   model   vdw
   4.865 3.500
nonbonded pdb=" O   ASP A  79 "
          pdb=" NE  ARG A  80 "
   model   vdw
   4.865 3.120
nonbonded pdb=" N   LYS A  46 "
          pdb=" CA  GLY A  74 "
   model   vdw sym.op.
   4.865 3.520 -x+1,y,-z+2
nonbonded pdb=" N   SER A  20 "
          pdb=" CA  ARG A  21 "
   model   vdw
   4.866 3.550
nonbonded pdb=" O   LEU A  32 "
          pdb=" O   VAL A  45 "
   model   vdw
   4.866 3.040
nonbonded pdb=" O   ILE A   6 "
          pdb=" CG  LYS A   7 "
   model   vdw
   4.866 3.440
nonbonded pdb=" C   ARG A  21 "
          pdb=" NE  ARG A  21 "
   model   vdw
   4.866 3.350
nonbonded pdb=" N   LYS A   3 "
          pdb=" CD  LYS A   3 "
   model   vdw
   4.866 3.520
nonbonded pdb=" CG  GLN A  72 "
          pdb=" CB  LYS A   3 "
   model   vdw sym.op.
   4.866 3.840 -x+1,y-1,-z+2
nonbonded pdb=" CB  LYS A   3 "
          pdb=" CG  GLN A  72 "
   model   vdw sym.op.
   4.866 3.840 -x+1,y+1,-z+2
nonbonded pdb=" CD  GLN A  31 "
          pdb=" CG  TYR A  56 "
   model   vdw
   4.866 3.490
nonbonded pdb=" C   VAL A   4 "
          pdb=" C   LEU A  60 "
   model   vdw
   4.867 3.500
nonbonded pdb=" O   GLU A   5 "
          pdb=" O   GLY A  59 "
   model   vdw
   4.867 3.040
nonbonded pdb=" CB  SER A  66 "
          pdb=" NH1 ARG A  82 "
   model   vdw
   4.867 3.520
nonbonded pdb=" CD2 LEU A  49 "
          pdb="O    HOH S  98 "
   model   vdw
   4.867 3.460
nonbonded pdb=" CG  LYS A   3 "
          pdb=" N   GLU A   5 "
   model   vdw
   4.867 3.520
nonbonded pdb=" CB  THR A  62 "
          pdb=" C   VAL A  63 "
   model   vdw
   4.867 3.700
nonbonded pdb=" CA  GLY A  52 "
          pdb=" CB  GLN A  53 "
   model   vdw
   4.867 3.840
nonbonded pdb=" C   GLU A  40 "
          pdb=" CE1 TYR A  41 "
   model   vdw
   4.868 3.570
nonbonded pdb=" N   MSE A  77 "
          pdb=" CA  ILE A  78 "
   model   vdw
   4.868 3.550
nonbonded pdb=" N   LEU A  60 "
          pdb=" CG  TYR A  61 "
   model   vdw
   4.869 3.340
nonbonded pdb=" N   ILE A   6 "
          pdb=" CE1 TYR A  61 "
   model   vdw
   4.869 3.420
nonbonded pdb=" C   LEU A  37 "
          pdb=" CD1 LEU A  65 "
   model   vdw sym.op.
   4.869 3.690 -x+1,y,-z+2
nonbonded pdb=" CA  ASN A  29 "
          pdb=" CD1 LEU A  49 "
   model   vdw
   4.869 3.890
nonbonded pdb=" CA  PRO A   8 "
          pdb=" C   THR A  14 "
   model   vdw sym.op.
   4.870 3.700 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CE1 TYR A  34 "
          pdb=" O   VAL A  43 "
   model   vdw
   4.870 3.340
nonbonded pdb=" CD1 ILE A   6 "
          pdb=" CD1 ILE A  47 "
   model   vdw
   4.870 3.880
nonbonded pdb=" N   PHE A  68 "
          pdb=" CA  LYS A  69 "
   model   vdw
   4.870 3.550
nonbonded pdb=" C   ILE A  47 "
          pdb=" CG2 THR A  48 "
   model   vdw
   4.870 3.690
nonbonded pdb=" CG1 ILE A  47 "
          pdb=" O   LEU A  81 "
   model   vdw
   4.870 3.440
nonbonded pdb=" O   ASN A  39 "
          pdb=" CG  GLU A  40 "
   model   vdw
   4.871 3.440
nonbonded pdb=" SG  CYS A  33 "
          pdb=" N   VAL A  35 "
   model   vdw
   4.871 3.480
nonbonded pdb=" CA  LEU A  65 "
          pdb=" CB  SER A  66 "
   model   vdw
   4.871 3.870
nonbonded pdb=" C   GLU A   5 "
          pdb=" C   GLY A  59 "
   model   vdw
   4.871 3.500
nonbonded pdb=" N   LEU A  83 "
          pdb=" CA  VAL A  84 "
   model   vdw
   4.871 3.550
nonbonded pdb=" N   GLY A  71 "
          pdb=" N   LEU A  76 "
   model   vdw
   4.872 3.200
nonbonded pdb=" CG  LYS A  24 "
          pdb=" OD2 ASP A  79 "
   model   vdw sym.op.
   4.872 3.440 -x+1/2,y-1/2,-z+2
nonbonded pdb=" CA  MSE A  77 "
          pdb=" CG1 ILE A  78 "
   model   vdw
   4.872 3.870
nonbonded pdb=" N   LEU A  37 "
          pdb="O    HOH S   2 "
   model   vdw
   4.872 3.120
nonbonded pdb=" N   LYS A  46 "
          pdb=" CD  LYS A  46 "
   model   vdw
   4.872 3.520
nonbonded pdb=" O   TYR A  34 "
          pdb=" CB  PRO A  42 "
   model   vdw
   4.872 3.440
nonbonded pdb=" O   PHE A  13 "
          pdb=" O   GLU A  30 "
   model   vdw
   4.873 3.040
nonbonded pdb=" N   ASP A  50 "
          pdb="O    HOH S 135 "
   model   vdw
   4.873 3.120
nonbonded pdb=" N   CYS A  33 "
          pdb=" CA  TYR A  34 "
   model   vdw
   4.873 3.550
nonbonded pdb=" CA  ASN A  39 "
          pdb=" CB  GLU A  40 "
   model   vdw
   4.873 3.870
nonbonded pdb=" ND1 HIS A  64 "
          pdb=" C   SER A  66 "
   model   vdw
   4.874 3.350
nonbonded pdb=" CA  GLN A  53 "
          pdb="O    HOH S  98 "
   model   vdw
   4.874 3.470
nonbonded pdb=" CD2 TYR A  61 "
          pdb=" CA  LEU A  83 "
   model   vdw
   4.874 3.770
nonbonded pdb=" N   GLU A   5 "
          pdb=" N   TYR A  61 "
   model   vdw
   4.874 3.200
nonbonded pdb=" C   VAL A  35 "
          pdb=" CG  ASP A  36 "
   model   vdw
   4.874 3.500
nonbonded pdb=" CG  TYR A  34 "
          pdb=" CG  PRO A  42 "
   model   vdw
   4.874 3.660
nonbonded pdb=" O   TYR A  56 "
          pdb=" OH  TYR A  61 "
   model   vdw
   4.875 3.040
nonbonded pdb=" C   THR A  62 "
          pdb="O    HOH S  12 "
   model   vdw
   4.875 3.270
nonbonded pdb=" O   PRO A  54 "
          pdb="O    HOH S  44 "
   model   vdw
   4.875 3.040
nonbonded pdb=" CD  GLU A  51 "
          pdb=" NE2 HIS A  64 "
   model   vdw sym.op.
   4.875 3.350 -x+1/2,y-1/2,-z+2
nonbonded pdb=" C   GLY A  18 "
          pdb=" O   LYS A  24 "
   model   vdw
   4.875 3.270
nonbonded pdb=" CB  HIS A  64 "
          pdb=" N   VAL A  84 "
   model   vdw
   4.875 3.520
nonbonded pdb=" C   ILE A   2 "
          pdb="O    HOH S  12 "
   model   vdw
   4.875 3.270
nonbonded pdb=" N   GLY A  18 "
          pdb=" CA  VAL A  19 "
   model   vdw
   4.876 3.550
nonbonded pdb=" C   ASN A  29 "
          pdb=" CA  LEU A  49 "
   model   vdw
   4.876 3.700
nonbonded pdb=" NE  ARG A  16 "
          pdb=" O   LEU A  60 "
   model   vdw sym.op.
   4.876 3.120 x,y-1,z
nonbonded pdb=" O   VAL A  45 "
          pdb=" O   GLY A  74 "
   model   vdw sym.op.
   4.876 3.040 -x+1,y,-z+2
nonbonded pdb=" O   GLN A  10 "
          pdb=" OE1 GLN A  31 "
   model   vdw
   4.876 3.040
nonbonded pdb=" CB  SER A  17 "
          pdb=" CB  SER A  27 "
   model   vdw
   4.876 3.840
nonbonded pdb=" CA  LEU A  44 "
          pdb=" CG2 VAL A  45 "
   model   vdw
   4.876 3.890
nonbonded pdb=" CB  ILE A  47 "
          pdb=" C   THR A  48 "
   model   vdw
   4.876 3.700
nonbonded pdb=" N   LEU A  32 "
          pdb=" CA  CYS A  33 "
   model   vdw
   4.877 3.550
nonbonded pdb=" C   PRO A  54 "
          pdb="O    HOH S 134 "
   model   vdw
   4.877 3.270
nonbonded pdb=" N   VAL A  35 "
          pdb=" C   PRO A  42 "
   model   vdw
   4.877 3.350
nonbonded pdb=" CA  GLY A  71 "
          pdb=" N   GLY A  74 "
   model   vdw
   4.877 3.520
nonbonded pdb=" NZ  LYS A  24 "
          pdb=" NE  ARG A  21 "
   model   vdw sym.op.
   4.877 3.200 -x+1/2,y+1/2,-z+2
nonbonded pdb=" NE  ARG A  21 "
          pdb=" NZ  LYS A  24 "
   model   vdw sym.op.
   4.877 3.200 -x+1/2,y-1/2,-z+2
nonbonded pdb=" N   GLN A  12 "
          pdb=" CA  PHE A  13 "
   model   vdw
   4.877 3.550
nonbonded pdb=" N   VAL A  63 "
          pdb=" CD2 LEU A  83 "
   model   vdw
   4.877 3.540
nonbonded pdb=" N   TYR A  61 "
          pdb=" CA  THR A  62 "
   model   vdw
   4.877 3.550
nonbonded pdb=" CZ  ARG A  16 "
          pdb=" OH  TYR A  61 "
   model   vdw sym.op.
   4.877 3.270 x,y-1,z
nonbonded pdb=" CA  ARG A  80 "
          pdb=" N   ARG A  82 "
   model   vdw
   4.878 3.550
nonbonded pdb=" CD1 ILE A   6 "
          pdb=" CG  TYR A  56 "
   model   vdw
   4.878 3.680
nonbonded pdb=" C   TYR A  34 "
          pdb=" N   VAL A  43 "
   model   vdw
   4.878 3.350
nonbonded pdb=" O   CYS A  33 "
          pdb=" CE2 TYR A  34 "
   model   vdw
   4.878 3.340
nonbonded pdb=" CB  PHE A  13 "
          pdb=" CA  GLN A  31 "
   model   vdw
   4.879 3.870
nonbonded pdb=" CG2 VAL A  35 "
          pdb=" CD2 LEU A  76 "
   model   vdw sym.op.
   4.880 3.880 -x+1,y,-z+2
nonbonded pdb=" C   ASP A  79 "
          pdb=" NH1 ARG A  82 "
   model   vdw
   4.880 3.350
nonbonded pdb=" O   THR A  62 "
          pdb=" O   LEU A  83 "
   model   vdw
   4.880 3.040
nonbonded pdb=" OE1 GLN A  12 "
          pdb="O    HOH S  51 "
   model   vdw sym.op.
   4.880 3.040 -x+1/2,y-1/2,-z+1
nonbonded pdb=" O   VAL A   4 "
          pdb=" CG  LEU A  60 "
   model   vdw
   4.880 3.470
nonbonded pdb=" CA  VAL A  63 "
          pdb=" C   ARG A  82 "
   model   vdw
   4.881 3.700
nonbonded pdb=" C   SER A   9 "
          pdb=" CA  ALA A  11 "
   model   vdw
   4.881 3.700
nonbonded pdb=" C   LEU A  49 "
          pdb=" OD2 ASP A  50 "
   model   vdw
   4.882 3.270
nonbonded pdb=" CZ  PHE A  13 "
          pdb="O    HOH S 117 "
   model   vdw
   4.882 3.340
nonbonded pdb=" CB  PHE A  13 "
          pdb=" CA  GLU A  30 "
   model   vdw
   4.882 3.870
nonbonded pdb=" O   LEU A  28 "
          pdb="O    HOH S  33 "
   model   vdw
   4.882 3.040
nonbonded pdb=" CB  ILE A   6 "
          pdb=" NE2 GLN A  31 "
   model   vdw
   4.882 3.550
nonbonded pdb=" CG  LEU A  37 "
          pdb=" O   PHE A  68 "
   model   vdw sym.op.
   4.882 3.470 -x+1,y,-z+2
nonbonded pdb=" CB  THR A  15 "
          pdb=" CG  ASN A  29 "
   model   vdw
   4.882 3.700
nonbonded pdb=" O   THR A  15 "
          pdb=" O   LEU A  28 "
   model   vdw
   4.883 3.040
nonbonded pdb=" N   LYS A   3 "
          pdb=" N   ASP A  36 "
   model   vdw
   4.883 3.200
nonbonded pdb=" CB  HIS A  64 "
          pdb=" N   LEU A  83 "
   model   vdw
   4.883 3.520
nonbonded pdb=" CD2 LEU A  28 "
          pdb=" N   ASN A  29 "
   model   vdw
   4.883 3.540
nonbonded pdb=" N   LEU A  44 "
          pdb=" CD2 LEU A  44 "
   model   vdw
   4.883 3.540
nonbonded pdb=" N   TYR A  56 "
          pdb=" CE1 TYR A  56 "
   model   vdw
   4.883 3.420
nonbonded pdb=" O   GLY A  18 "
          pdb=" O   PRO A  25 "
   model   vdw
   4.883 3.040
nonbonded pdb=" CG  PHE A  13 "
          pdb=" OD1 ASN A  29 "
   model   vdw
   4.883 3.260
nonbonded pdb=" CB  LYS A   7 "
          pdb=" NZ  LYS A   7 "
   model   vdw
   4.883 3.520
nonbonded pdb=" CA  SER A  66 "
          pdb=" CB  SER A  67 "
   model   vdw
   4.883 3.870
nonbonded pdb=" OD2 ASP A  79 "
          pdb=" CG  ARG A  80 "
   model   vdw
   4.884 3.440
nonbonded pdb=" CD  LYS A  69 "
          pdb=" OD2 ASP A  79 "
   model   vdw
   4.884 3.440
nonbonded pdb=" N   VAL A   4 "
          pdb=" CA  TYR A  61 "
   model   vdw
   4.885 3.550
nonbonded pdb=" O   PHE A  13 "
          pdb=" OG1 THR A  14 "
   model   vdw
   4.885 3.040
nonbonded pdb=" N   GLY A  74 "
          pdb=" OG  SER A  75 "
   model   vdw
   4.885 3.120
nonbonded pdb=" CB  ILE A   6 "
          pdb=" O   TYR A  56 "
   model   vdw
   4.885 3.470
nonbonded pdb=" CA  GLU A   5 "
          pdb=" C   TYR A  34 "
   model   vdw
   4.885 3.700
nonbonded pdb=" N   GLU A  40 "
          pdb=" OE2 GLU A  40 "
   model   vdw
   4.885 3.120
nonbonded pdb=" CD1 ILE A   2 "
          pdb=" CD2 PHE A  68 "
   model   vdw sym.op.
   4.886 3.760 -x+1,y,-z+2
nonbonded pdb=" CD2 PHE A  68 "
          pdb=" CD1 ILE A   2 "
   model   vdw sym.op.
   4.886 3.760 -x+1,y,-z+2
nonbonded pdb=" CD2 HIS A  64 "
          pdb=" N   SER A  66 "
   model   vdw
   4.886 3.340
nonbonded pdb=" CA  VAL A  63 "
          pdb=" CA  LEU A  83 "
   model   vdw
   4.886 3.900
nonbonded pdb=" CB  VAL A  35 "
          pdb=" CD1 LEU A  76 "
   model   vdw sym.op.
   4.886 3.890 -x+1,y,-z+2
nonbonded pdb=" O   GLY A  52 "
          pdb=" CG  GLN A  53 "
   model   vdw
   4.886 3.440
nonbonded pdb=" C   VAL A  70 "
          pdb=" C   SER A  75 "
   model   vdw
   4.886 3.500
nonbonded pdb=" CA  ILE A   2 "
          pdb=" O   LYS A   3 "
   model   vdw
   4.886 3.470
nonbonded pdb=" C   GLY A  18 "
          pdb=" C   TYR A  26 "
   model   vdw
   4.886 3.500
nonbonded pdb=" N   SER A  67 "
          pdb=" CB  PHE A  68 "
   model   vdw
   4.886 3.520
nonbonded pdb=" CG1 VAL A  43 "
          pdb=" C   LEU A  44 "
   model   vdw
   4.887 3.690
nonbonded pdb=" CG  PHE A  73 "
          pdb=" N   GLY A  74 "
   model   vdw
   4.887 3.340
nonbonded pdb=" CG  TYR A  34 "
          pdb=" CA  LEU A  44 "
   model   vdw
   4.887 3.690
nonbonded pdb=" C   ARG A  80 "
          pdb=" CG  LEU A  81 "
   model   vdw
   4.887 3.700
nonbonded pdb=" O   ASP A  79 "
          pdb=" O   ARG A  80 "
   model   vdw
   4.887 3.040
nonbonded pdb=" CB  PRO A  85 "
          pdb="O    HOH S  85 "
   model   vdw sym.op.
   4.887 3.440 x,y+1,z
nonbonded pdb=" OE1 GLU A   5 "
          pdb=" CD1 LEU A  60 "
   model   vdw
   4.888 3.460
nonbonded pdb=" OG1 THR A  62 "
          pdb=" CB  VAL A  63 "
   model   vdw
   4.888 3.470
nonbonded pdb=" O   GLY A  59 "
          pdb=" CG  TYR A  61 "
   model   vdw
   4.888 3.260
nonbonded pdb=" C   PHE A  68 "
          pdb=" CD1 LEU A  76 "
   model   vdw
   4.888 3.690
nonbonded pdb=" C   PRO A   8 "
          pdb=" O   PHE A  13 "
   model   vdw sym.op.
   4.888 3.270 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CG2 VAL A  19 "
          pdb=" CB  PRO A  25 "
   model   vdw
   4.888 3.860
nonbonded pdb=" O   ARG A  16 "
          pdb=" NE  ARG A  16 "
   model   vdw
   4.888 3.120
nonbonded pdb=" N   GLY A  59 "
          pdb=" CA  LEU A  60 "
   model   vdw
   4.888 3.550
nonbonded pdb=" CD  GLU A   5 "
          pdb=" O   ILE A   6 "
   model   vdw
   4.889 3.270
nonbonded pdb=" C   THR A  14 "
          pdb=" OD1 ASN A  29 "
   model   vdw
   4.889 3.270
nonbonded pdb=" CG1 ILE A  78 "
          pdb=" CB  ILE A  78 "
   model   vdw sym.op.
   4.889 3.870 -x+1,y,-z+2
nonbonded pdb=" CB  ILE A  78 "
          pdb=" CG1 ILE A  78 "
   model   vdw sym.op.
   4.889 3.870 -x+1,y,-z+2
nonbonded pdb=" O   ALA A  55 "
          pdb=" CG  TYR A  56 "
   model   vdw
   4.889 3.260
nonbonded pdb=" CG1 ILE A   2 "
          pdb=" O   ASP A  36 "
   model   vdw
   4.890 3.440
nonbonded pdb=" CB  THR A  15 "
          pdb=" C   LEU A  28 "
   model   vdw
   4.890 3.700
nonbonded pdb=" N   ARG A  21 "
          pdb=" NE  ARG A  21 "
   model   vdw
   4.890 3.200
nonbonded pdb=" C   GLN A  10 "
          pdb=" CD  GLN A  31 "
   model   vdw
   4.890 3.500
nonbonded pdb=" O   PHE A  68 "
          pdb=" O   MSE A  77 "
   model   vdw
   4.891 3.040
nonbonded pdb=" CB  VAL A   4 "
          pdb=" CA  TYR A  61 "
   model   vdw
   4.891 3.900
nonbonded pdb=" CA  GLU A   5 "
          pdb=" O   ILE A   6 "
   model   vdw
   4.891 3.470
nonbonded pdb=" O   ILE A  47 "
          pdb="O    HOH S 106 "
   model   vdw
   4.891 3.040
nonbonded pdb=" C   MSE A  77 "
          pdb=" CG2 ILE A  78 "
   model   vdw
   4.891 3.690
nonbonded pdb=" N   TYR A  61 "
          pdb=" CE1 PHE A  73 "
   model   vdw sym.op.
   4.891 3.420 -x+1,y+1,-z+2
nonbonded pdb=" N   GLN A  31 "
          pdb=" CA  ILE A  47 "
   model   vdw
   4.893 3.550
nonbonded pdb=" CB  SER A   9 "
          pdb=" CA  THR A  15 "
   model   vdw sym.op.
   4.893 3.870 -x+1/2,y+1/2,-z+1
nonbonded pdb=" CA  THR A  15 "
          pdb=" CB  SER A   9 "
   model   vdw sym.op.
   4.893 3.870 -x+1/2,y-1/2,-z+1
nonbonded pdb=" CG2 THR A  15 "
          pdb=" CA  SER A  27 "
   model   vdw
   4.893 3.890
nonbonded pdb=" CB  VAL A  35 "
          pdb=" CD2 LEU A  37 "
   model   vdw
   4.893 3.890
nonbonded pdb=" O   VAL A  19 "
          pdb="O    HOH S 120 "
   model   vdw
   4.893 3.040
nonbonded pdb=" N   ALA A  11 "
          pdb=" C   GLN A  12 "
   model   vdw
   4.894 3.350
nonbonded pdb=" N   GLU A  30 "
          pdb=" OE1 GLU A  30 "
   model   vdw
   4.894 3.120
nonbonded pdb="SE    SE Z   1 "
          pdb=" O   SER A  75 "
   model   vdw sym.op.
   4.894 3.420 -x,y-1,-z+1
nonbonded pdb=" O   SER A  75 "
          pdb="SE    SE Z   1 "
   model   vdw sym.op.
   4.894 3.420 -x,y+1,-z+1
nonbonded pdb=" OD1 ASP A  79 "
          pdb=" NH1 ARG A  82 "
   model   vdw
   4.894 3.120
nonbonded pdb=" CD  LYS A   3 "
          pdb=" CD  GLN A  72 "
   model   vdw sym.op.
   4.894 3.670 -x+1,y+1,-z+2
nonbonded pdb=" CD  GLN A  72 "
          pdb=" CD  LYS A   3 "
   model   vdw sym.op.
   4.894 3.670 -x+1,y-1,-z+2
nonbonded pdb=" N   SER A   9 "
          pdb=" CD  GLU A  40 "
   model   vdw sym.op.
   4.894 3.350 -x+1,y,-z+1
nonbonded pdb=" CB  THR A  15 "
          pdb=" C   ARG A  16 "
   model   vdw
   4.894 3.700
nonbonded pdb=" C   VAL A  63 "
          pdb=" CG  HIS A  64 "
   model   vdw
   4.895 3.490
nonbonded pdb=" CB  LEU A  37 "
          pdb=" CG  ASN A  39 "
   model   vdw
   4.895 3.670
nonbonded pdb=" O   GLN A  31 "
          pdb=" O   LYS A  46 "
   model   vdw
   4.895 3.040
nonbonded pdb=" C   GLN A  72 "
          pdb=" CA  GLY A  74 "
   model   vdw
   4.895 3.670
nonbonded pdb=" CD2 LEU A  76 "
          pdb=" CG  LEU A  81 "
   model   vdw sym.op.
   4.895 3.890 -x+1,y,-z+2
nonbonded pdb=" OH  TYR A  56 "
          pdb=" N   ARG A  82 "
   model   vdw
   4.895 3.120
nonbonded pdb=" CG2 ILE A   6 "
          pdb=" N   GLY A  59 "
   model   vdw
   4.895 3.540
nonbonded pdb=" O   SER A  75 "
          pdb="O    HOH S  10 "
   model   vdw sym.op.
   4.896 3.040 -x+1,y,-z+2
nonbonded pdb=" CB  TYR A  61 "
          pdb=" C   LEU A  83 "
   model   vdw
   4.896 3.670
nonbonded pdb=" CD2 LEU A  28 "
          pdb=" NH1 ARG A  80 "
   model   vdw
   4.896 3.540
nonbonded pdb=" CA  TYR A  26 "
          pdb=" NE2 GLN A  22 "
   model   vdw sym.op.
   4.896 3.550 -x+1/2,y+1/2,-z+2
nonbonded pdb=" NE2 GLN A  22 "
          pdb=" CA  TYR A  26 "
   model   vdw sym.op.
   4.896 3.550 -x+1/2,y-1/2,-z+2
nonbonded pdb=" N   VAL A  19 "
          pdb=" CA  PRO A  25 "
   model   vdw
   4.896 3.550
nonbonded pdb=" N   SER A  67 "
          pdb=" CG  PHE A  68 "
   model   vdw
   4.897 3.340
nonbonded pdb=" C   HIS A  64 "
          pdb=" CE2 PHE A  68 "
   model   vdw
   4.897 3.570
nonbonded pdb=" O   LYS A  69 "
          pdb=" CD  LYS A  69 "
   model   vdw
   4.898 3.440
nonbonded pdb=" OD1 ASP A  50 "
          pdb=" CB  ARG A  80 "
   model   vdw
   4.898 3.440
nonbonded pdb=" CZ  PHE A  13 "
          pdb=" OG1 THR A  15 "
   model   vdw
   4.898 3.340
nonbonded pdb=" C   LEU A  28 "
          pdb=" ND2 ASN A  29 "
   model   vdw
   4.898 3.350
nonbonded pdb=" OE1 GLN A  31 "
          pdb=" N   ALA A  55 "
   model   vdw
   4.898 3.120
nonbonded pdb=" N   TYR A  56 "
          pdb="O    HOH S 134 "
   model   vdw
   4.898 3.120
nonbonded pdb=" N   ILE A   6 "
          pdb=" CB  CYS A  33 "
   model   vdw
   4.899 3.520
nonbonded pdb=" CZ  ARG A  16 "
          pdb=" C   GLY A  59 "
   model   vdw sym.op.
   4.899 3.500 x,y-1,z
nonbonded pdb=" CA  TYR A  34 "
          pdb=" N   VAL A  43 "
   model   vdw
   4.899 3.550
nonbonded pdb=" CG  LEU A  49 "
          pdb=" O   GLN A  53 "
   model   vdw
   4.899 3.470
nonbonded pdb=" CA  GLN A  10 "
          pdb=" NE2 GLN A  10 "
   model   vdw
   4.900 3.550
nonbonded pdb=" CG  PRO A  85 "
          pdb="O    HOH S  85 "
   model   vdw sym.op.
   4.900 3.440 x,y+1,z

