### FINAL REPORT

**Case:** refined_start_control — refine supplied model against supplied data, report final statistics.
**Date:** 2026-07-23
**Crystal:** C 1 2 1, cell 76.08 27.97 42.36 90 103.20 90; 1 protein chain (A, res 2–85; 86-residue sequence), 5 MSE, 4 free SE substructure atoms (chain Z), 36 waters.
**Data:** data.mtz — FP/SIGFP + R-free flags, 21.33–2.59 Å, 2634 reflections (2633 in refinement, 263 free = 9.99%). Provenance in MTZ history: AutoSol SAD pipeline (`clean_fobs_freer.mtz`).

## Headline result

The supplied model was already essentially at its cross-validated minimum for this sparse
2.59 Å data. The one genuine, cross-validated improvement available was model geometry
(rotamers), delivered by a targeted Coot rebuild, followed by a parameter-restrained
refinement chosen to avoid over-fitting.

| Metric | Baseline (supplied) | Final (deposit) | Δ | Source |
|---|---|---|---|---|
| R-work | 0.1975 | **0.1938** | −0.0037 | final_molprobity.log / final_refine.log |
| R-free | 0.2417 | **0.2388** | −0.0029 | final_molprobity.log / final_refine.log |
| R-work/R-free gap | 0.044 | 0.045 | ~0 (healthy) | derived |
| Rotamer outliers | 5.48 % | **4.11 %** | −1.37 % | final_molprobity.log |
| Ramachandran outliers | 0.00 % | 0.00 % | 0 | final_molprobity.log |
| Ramachandran favored | 96.34 % | 96.34 % | 0 | final_molprobity.log |
| Clashscore | 0.75 | 0.75 | 0 | final_molprobity.log |
| C-beta deviations | 0 | 0 | 0 | final_molprobity.log |
| MolProbity score | 1.55 | **1.45** | −0.10 | final_molprobity.log |
| RMS bonds (Å) | 0.0038 | 0.0067 | +0.003 | final_molprobity.log |
| RMS angles (°) | 0.59 | 0.85 | +0.26 | final_molprobity.log |

Every headline metric is equal to or better than baseline. Geometry RMSDs rose slightly
(still well within norms: bonds <0.02 Å, angles <1°) as a consequence of the local Coot
real-space refinement of the rebuilt rotamers.

## Where it stands (calibrated)

- **The model is at the R-free minimum for this data.** With ~2,633 working reflections and
  ~2,784 parameters for individual xyz+B refinement (696 atoms), the data-to-parameter ratio
  is ≈1:1. R-free is pinned at ~0.238–0.242 regardless of protocol; it cannot be pushed lower
  by refinement. This is the defining feature of the case.
- **Reciprocal-space coordinate refinement over-fits here.** Unrestrained/auto-weight xyz
  refinement drove R-work to 0.137 (gap 0.106) while R-free did not improve and the ML
  coordinate error grew to 0.30 Å — classic over-fitting. Those runs were rejected.
- **The deposited refinement (group-B ADP, xyz frozen at the rebuilt coordinates)** keeps a
  healthy 0.045 gap and is the honest, deposit-quality product.

## Decisions and rejected alternatives

1. **Rotamer rebuild (Coot):** fixed A24 LYS (0.025→24.5%), A20 SER (0.65→4.6%),
   A27 SER (0.9→2.6%), A45 VAL (0.92→1.8%); each kept only after checking rotamer score +
   local map correlation. A84 VAL and A53 GLN were attempted but reverted (auto-fit worsened
   the rotamer / picked a low-probability density-preferred conformer); they remain sub-1%
   outliers and account for most of the residual 4.11%.
2. **Refinement protocol:** chose **group-ADP + occupancy, coordinates frozen** (refv5) as the
   deposit. Rejected: (a) optimize-weights + ordered-solvent — R-free *worsened* to 0.2479
   (scientific divergence); (b) default-weight individual xyz — gap 0.106 (over-fit);
   (c) wxc_scale=0.1 individual xyz — gap 0.084 (still over-fit); (d) individual-ADP only —
   R-free 0.2381 but gap 0.068. refv5 gives the best R-free tier with the healthiest gap.

## Remaining uncertainties / flags

- **4 free SE atoms (chain Z, occ 0.22–0.53, B 30–70, far from protein):** carried over from
  the AutoSol SAD substructure and retained as supplied for fidelity. They should be verified
  against anomalous difference density before deposition; two (Z3 occ 0.22, Z5 B 70) are weak
  and may be spurious. Not independently validated here (no anomalous data in this MTZ).
- **A84 VAL / A53 GLN** remain rotamer outliers where the density favors a low-probability
  conformer; flagged rather than forced.
- Clashscore reported as 1.51 in the phenix.refine log vs 0.75 in phenix.molprobity — the
  authoritative MolProbity value (0.75) is used above.

## Next steps (not done)

- Inspect/validate the 4 SE sites against an anomalous difference map; remove if unsupported.
- Manual inspection of A53/A84 in density; consider alt-conformers if bimodal.
- If higher-resolution or more reflections become available, individual ADP/xyz refinement
  becomes justified.

## File inventory (DEPOSIT/)

- `final_model.pdb`, `final_model.cif` — deposit model (refv5: group-ADP refinement of the
  Coot-rebuilt model). R-work 0.1938 / R-free 0.2388.
- `final_map_coeffs.mtz` — refined data + 2mFo-DFc / mFo-DFc map coefficients.
- `final_refine_params.eff` — exact refinement parameters used.
- `inputs/` — data.mtz, model_supplied.pdb, sequence.dat (unmodified inputs).
- `superseded_models/` — model_coot_rebuilt.pdb (rebuilt, pre-final-refine) and the four
  rejected/intermediate refinements (refv1–refv4), named with reason.
- `logs/` — final_refine.log, final_molprobity.log, baseline_molprobity.log,
  final_geometry.geo.

**Coot availability:** Coot was responsive throughout (coot_ping → 4); the rotamer rebuild
was completed, not skipped.
