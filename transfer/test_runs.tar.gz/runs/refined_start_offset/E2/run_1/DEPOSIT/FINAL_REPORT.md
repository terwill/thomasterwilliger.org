# FINAL REPORT — refined_start_offset (E2/run_1)

Date: 2026-07-23
Task: Refine the supplied model against the supplied data; report final statistics and where it stands, with evidence.

## Headline
The supplied model does **not** fit the supplied data at the R-free the header claims. Its
true starting R-free is **0.47**, not the REMARK-3 value of 0.24 (the header is stale — it
describes a pre-corruption model). The error is **localized to the N-terminal ~21 residues
(sequence positions 2–22, IKVEIKPSQAQFTTRSGVSRQ)**, which are mis-placed / not supported by
interpretable density. The ordered core (residues 23–85) is correct. Refinement of the
supplied model cannot repair the N-terminus. A density-modified automated rebuild recovers
the core to **R-free 0.366 with clean geometry (MolProbity 1.65, clashscore 1.0)** but cannot
build the N-terminal residues, which appear disordered/uninterpretable at 2.59 Å. The
structure is therefore **not fully solved**; the best defensible model is an incomplete
63-residue core.

## Data (source: DEPOSIT/xtriage_data.log)
- Space group C 1 2 1; cell 76.08 27.97 42.36 / 90 103.2 90.
- Resolution 21.33–2.59 Å; completeness 93.6%; ⟨I/σ⟩ 29.5 (strong).
- No twinning (L-test Z 0.944; "No twinning is suspected"). No significant tNCS.
- Anomalous flag False (native amplitudes FP,SIGFP).
- 1 molecule/ASU (solvent 45%, Matthews 2.24).
- Existing R-free set present in data.mtz (label R-free-flags, 263 test reflections). It was
  preserved and frozen throughout — never regenerated or extended.

## Metrics: baseline vs. final (each sourced)

| Model | R-work | R-free | Clashscore | Rama out | Rotamer out | MolProbity | Residues | Source |
|---|---|---|---|---|---|---|---|---|
| Supplied header (REMARK 3) — STALE | 0.1975 | 0.2401 | — | — | — | — | 84 | model.pdb REMARK 3 |
| Supplied model, as-given (initial R) | 0.4886 | 0.4717 | — | — | — | — | 84 | refine_4d93618f log (start) |
| Supplied model, refined | 0.3244 | 0.4751 | 63.8 | 9.76% | 19.18% | 4.06 | 84 | refine_4d93618f Final; molprobity_supplied_refined.log |
| **Rebuilt core, refined (BEST)** | **0.3095** | **0.3655** | **1.01** | **0.00%** | **3.64%** | **1.65** | **63 (res 23–85)** | refine_246b08c1 Final; molprobity_rebuilt_core.log |

Notes:
- Refining the supplied model dropped R-work (0.49→0.32) but R-free stayed pinned at ~0.475 —
  a ~15% R-work/R-free gap: the classic signature of a wrong model being over-fit. Its
  clashscore 63.8 and 9.8% Rama / 19.2% rotamer outliers all originate in the mis-built N-terminus.
- The rebuilt core is better on **every** metric; the residual high R-free (0.366) is due to
  ~25% of the protein (the N-terminal residues) being unmodeled, not to model errors.

## Diagnosis (evidence)
1. **Sequence register of residue naming is correct**: model residues 2–85 match reference
   sequence positions 2–85 exactly (MSE at 77). This is not a naming/frameshift relabel.
2. **Per-residue map fit** (Coot, 2mFo-DFc): N-terminal residues ~2–28 have poor main-chain
   correlation (e.g. res 10 CA-region CC 0.03, res 17 0.08) — backbone out of density —
   while residues ~29–85 fit (CC 0.5–0.78).
3. **fix_insertions_deletions (split_with_sequence)** found **no** ±1/±2 insertion/deletion
   register error to correct ("No loops fitted"); score essentially unchanged. So it is not a
   simple indel frameshift. (The thorough run then crashed on an internal Phenix bug,
   `AttributeError: ...'morph_ca_only'`, at the output stage — a program bug, not a data issue.)
4. **Autobuild (rebuild_in_place=False, density modification)** rebuilt residues 23–85 in the
   correct register (identical to the supplied core: mean CA difference 0.31 Å over 63
   residues) and **could not build residues 1–22**; it also emitted a spurious poly-Val/Gly
   fragment numbered 91–100 (beyond the 87-residue sequence), which was removed.
5. **No positive difference density** near the built N-terminus (residue 23) to guide building
   residues 2–22 (only 2 peaks >3σ in the whole cell, neither at the N-terminus). Together with
   (4), this indicates the N-terminal ~21 residues are disordered/uninterpretable at this
   resolution — not reliably buildable.

Conclusion: the "start offset" is a **mis-placement of the N-terminal ~21 residues**, not a
whole-chain frameshift and not a fixable ±1 register error. The core is correct.

## Decisions made / alternatives rejected
- **Kept the frozen R-free set** from data.mtz; did not regenerate/extend it (would invalidate cross-validation).
- **Rejected** the raw refined-supplied model as the primary deposit: R-free 0.475, clashscore 63.8, indefensible N-terminus.
- **Rejected** phenix.fix_insertions_deletions output: it found no indel to fix (and crashed); not applicable.
- **Removed** autobuild's chain U (res 91–100, poly-Val/Gly, unassignable, numbered past the sequence):
  physically indefensible. This cost ~0.018 in R-free (0.348→0.366) but is required by
  "don't model density the data don't support."
- **Did not fabricate** the N-terminal residues 2–22 in Coot: no interpretable density; automated
  density-modified tracing already failed. Building them would be over-fitting.
- Bounded-retry: fix_insertions_deletions had one symmetry failure (fixed by regenerating a
  full-cell map), one no-op quick run (reconfigured to quick=False), then an internal-bug crash.
  Per the retry policy I stopped thrashing that tool and switched approach (autobuild).

## File inventory (DEPOSIT/)
- `model_rebuilt_core.pdb` / `model_rebuilt_core_maps.mtz` — **PRIMARY** best model (res 23–85 + 17 waters + 4 Se; R-work 0.310 / R-free 0.366; MolProbity 1.65).
- `model_supplied_refined.pdb` / `model_supplied_refined_maps.mtz` — literal "refine the supplied model" result (R-work 0.324 / R-free 0.475).
- `model_supplied_input.pdb` — original supplied coordinates (provenance).
- `data.mtz`, `sequence.dat` — inputs (unchanged).
- `molprobity_rebuilt_core.log`, `molprobity_supplied_refined.log`, `xtriage_data.log` — validation/data evidence.
- `FINAL_REPORT.md` — this file.

## Remaining uncertainties
- Whether the N-terminal ~21 residues are truly disordered or ordered-but-unrecoverable from
  these phases. R-free 0.366 (vs ~0.28 expected for a complete correct model) suggests some
  ordered scattering remains unmodeled, so partial N-terminal order is plausible.
- The single very large difference peak near residue 72 was not interpreted (possible solvent
  site or Fourier ripple); it does not affect the conclusion.

## Recommended next steps
1. Obtain unbiased phases (experimental SAD is unavailable — no anomalous signal; a composite-omit
   or an AlphaFold model of this 87-residue protein docked into the map) to attempt an
   independent N-terminal trace.
2. If an AlphaFold model is available, process_predicted_model → dock_in_map → refine; compare
   R-free against the 0.366 core.
3. If the N-terminus remains uninterpretable, deposit the 63-residue core and declare residues
   1–22 disordered.

---

### FINAL REPORT
```yaml
case: refined_start_offset
run: E2/run_1
data:
  space_group: C121
  resolution_A: [21.33, 2.59]
  completeness_pct: 93.6
  mean_I_over_sigma: 29.5
  twinning: none
  anomalous: none
  copies_in_asu: 1
  rfree_flags: preserved_frozen (263 test refl, from data.mtz)
baseline:
  supplied_header_REMARK3: {r_work: 0.1975, r_free: 0.2401, note: STALE_does_not_describe_these_coordinates}
  supplied_model_initial:  {r_work: 0.4886, r_free: 0.4717, source: refine_4d93618f_log}
  supplied_model_refined:  {r_work: 0.3244, r_free: 0.4751, clashscore: 63.8, rama_out_pct: 9.76, rot_out_pct: 19.18, molprobity: 4.06, residues: 84}
final_best:
  model: model_rebuilt_core.pdb
  r_work: 0.3095
  r_free: 0.3655
  clashscore: 1.01
  rama_outliers_pct: 0.00
  rotamer_outliers_pct: 3.64
  molprobity_score: 1.65
  rms_bonds_A: 0.0030
  rms_angles_deg: 0.61
  residues_modeled: 63
  residue_range: A/23-85
  waters: 17
  se_sites: 4
  source: refine_246b08c1_Final + molprobity_rebuilt_core.log
diagnosis:
  type: N_terminal_misplacement
  affected_residues: A/2-22 (sequence positions 2-22)
  core_correct: A/23-85 (mean CA diff supplied-vs-rebuilt 0.31 A)
  is_frameshift: false
  is_fixable_indel_register: false
  n_terminus_buildable: false (no interpretable density; autobuild + fix_indels both failed)
status: NOT_SOLVED — best model is an incomplete but clean 63-residue core; N-terminal ~21 residues unmodeled
rebuild_completed: partial (core rebuilt/validated; N-terminus not built because data do not support it)
coot_available: true
files_written: DEPOSIT/
```
