# FINAL REPORT — case `refined_start_offset`

**Date:** 2026-07-23
**Data:** `data.mtz` (SeMet SAD-derived amplitudes, from an AutoSol run — per MTZ history)
**Sequence:** `sequence.dat` (87 residues)
**Supplied model:** `model.pdb` (chain A residues 2–85 + 36 waters + 4 free Se sites)

## Headline

The **supplied model does not fit the supplied data as delivered** (computed R-work **0.4009** / R-free **0.3945**), despite a PDB-header claim of R 0.198/0.240. The header values are a *fossil* inherited from a correctly-built predecessor and are **not achievable** from the supplied coordinates. The defect is a **register / "start-offset" build error localized to the N-terminal ~20 residues (2–22)**; the core (residues 23–85) is correct. No rigid-body operation (Phaser) or refinement/simulated-annealing move recovers the fit — R-free is stuck ~0.45. Rebuilding against the data (`phenix.autobuild`) removed the wrong N-terminus and recovered a fitting model.

**Best recovered model (`recovered_model.pdb`): R-work 0.2027 / R-free 0.3253** at 2.59 Å (residues 23–85 core, correct register). The residual R-free gap to the header's 0.24 is due to the **unmodeled N-terminal residues 2–22**, which are not confidently traceable in the current model-phased map at 2.6 Å (the original 0.24 used experimental SAD phases).

## Data quality (phenix.xtriage — xtriage log)
- Space group **C 1 2 1**; cell 76.08, 27.97, 42.36, 90, 103.2, 90; resolution **21.33–2.59 Å**; completeness **93.4 %**; ⟨I/σ⟩ 29.5; Wilson B **26.4 Å²**.
- **No twinning** (L-test clean). Mild, negligible anisotropy (ΔB ≈ 5 Å²). Weak/borderline tNCS (largest off-origin Patterson peak 12.6 %, p = 0.066). **1 copy / ASU** (45 % solvent).
- `R-free-flags` column present (263 free, ~10 %) — **honored throughout, never regenerated**.

## Evidence trail (each value sourced)

| Step | R-work | R-free | Source (work_dir) |
|---|---|---|---|
| PDB header (REMARK 3) — *fossil, not reproduced* | 0.1975 | 0.2401 | model.pdb |
| **Supplied model vs data (no refinement)** | **0.4009** | **0.3945** | model_vs_data_17bc63db |
| Supplied model, 3-cycle refine | 0.30 | 0.47 | refine_ca0c3bd4 |
| Phaser re-placement (LLG 321, TFZ 12.8, FRAC −0.5,−0.5,−0.5) then refine | 0.32 | 0.46 | phaser_187621df / refine_7013a1a9 |
| Simulated annealing (5000 K) | 0.27 | 0.45 | refine_f4e50bd1 |
| **Autobuild rebuild** (drops res 2–22, keeps 23–85) cycle 4 | 0.23 | 0.32 | autobuild_52f8be00 |
| Autobuild final refine | 0.2271 | 0.3222 | autobuild_52f8be00 |
| Refine + ordered solvent (`recovered_model_alt.pdb`) | 0.2102 | 0.3203 | refine_80f12255 |
| **Coot rotamer fixes + refine (`recovered_model.pdb`)** | **0.2027** | **0.3253** | refine_50aa0147 |

## Diagnosis (how we know it's a start-offset register error, not a placement offset)
1. R-work and R-free start **equal (~0.40)** → uniform misfit, not overfit.
2. Phaser 6-D search returns a **single confident solution at essentially the model's own position** — no rigid translation/rotation improves R. So the error is **internal**, not placement.
3. Simulated annealing pushes R-work to 0.27 but **R-free never drops below ~0.45** → overfitting a wrong model.
4. Per-residue map correlation is **bimodal**: core residues fit; the **N-terminal stretch (~2–18) sits in zero/negative density**.
5. Autobuild independently **deletes residues 2–22 and keeps 23–85 unchanged** (CA within 0.1–0.3 Å), dropping R-free 0.45 → 0.32 — confirming 23–85 correct, 2–22 wrong.
6. N-terminal difference/2Fo-Fc density beyond residue 23 is **weak and broken** (0.75σ→0.42→1.4σ→negative), so residues 2–22 are **not confidently buildable** from the model-phased map at 2.6 Å.

## Final model — `recovered_model.pdb` (validation from refine_50aa0147 + molprobity_a02fc041)
- **R-work 0.2027 / R-free 0.3253** (2.59 Å; R-free flags as supplied).
- MolProbity score **2.81**; clashscore 14.3; Ramachandran outliers 4.35 %; rotamer outliers 4.92 %; C-beta dev 0; RMS bonds 0.0121 Å; RMS angles 1.46°.
- Composition: chain A residues **23–85** (correct register), one **unsequenced 10-residue ordered fragment** (chain U, 2Fo-Fc corr ≈ 0.71 — real density, identity/register unassigned), 3 Se, 48 waters.
- **Missing / not modeled:** residues **2–22** (the offset N-terminus) — left unbuilt rather than fabricated into unsupported density.

## Decisions
- **Accepted:** Phaser confirmed no rigid fix exists (diagnostic, not used for final model). Autobuild rebuild accepted as the recovery route. Coot rotamer fixing accepted (better MolProbity/clash at tied R-free).
- **Rejected:** reporting the header 0.198/0.240 as achieved (not reproducible from supplied coordinates); hand-building residues 2–22 into weak/broken density (would violate physical-realism / build-only-what-data-support).
- **Preserved (competing/versioned):** `recovered_model.pdb` (primary), `recovered_model_alt.pdb` (pre-rotamer-fix, R-free 0.3203, Rama 2.9 %), `supplied_model_asis.pdb` (baseline).

## Remaining uncertainties / next steps
- **N-terminus (2–22)** unmodeled — would likely close most of the R-free gap. Best recovered with **experimental SAD phases** (the original AutoSol substructure/phases, not present in `data.mtz`): re-phase from the Se substructure → density-modify → build the N-terminus, or run `resolve_cryo_em`-style DM. Alternatively an AlphaFold model of this 87-mer via `phenix.process_predicted_model` could template the N-terminal build.
- **Chain U** 10-residue fragment is in real density but unassigned; sequence/connectivity to the main chain is undetermined.
- R-free/R-work gap (~0.12) reflects the incomplete model (24 % of the chain missing), not overfitting of the built part.

## File inventory (DEPOSIT/)
- `recovered_model.pdb` / `.cif` — **primary final model** (R 0.203/0.325).
- `recovered_model_mapcoeffs.mtz` — 2Fo-Fc / Fo-Fc coefficients for the final model.
- `recovered_model_molprobity.log` — full validation.
- `recovered_model_alt.pdb` — alternative recovered model (pre-rotamer-fix, R-free 0.3203).
- `supplied_model_asis.pdb` — supplied model, unmodified (baseline; computed R 0.401/0.395).
- `data.mtz`, `sequence.dat` — inputs used (copies, unchanged).
- `RUN_LOG.json` — machine-readable step log.
