# FINAL REPORT — refined_start_badelement

**Task:** Refine the supplied model against the supplied data; report final statistics.
**Date:** 2026-07-23
**Space group / cell (from data):** C 1 2 1; 76.08, 27.97, 42.36 Å, β=103.2° (2634 refl, 21.33–2.59 Å)
**Content:** 1 protein chain A (res 2–85, ~84 modeled), 36 waters, 4 free Se sites (chain Z).

---

## Headline result

| Metric | Supplied model | Baseline refine (element-fixed) | **FINAL (rotamer-fixed)** | Source |
|---|---|---|---|---|
| R-work | 0.1975 | 0.1901 | **0.1870** | supplied PDB header REMARK 3 / final_refine.log / final_molprobity.out |
| R-free | 0.2401 | 0.2399 | **0.2263** | same |
| R-free − R-work | 0.043 | 0.050 | **0.039** | derived |
| Rotamer outliers | (not evaluable*) | 5.48% | **0.00%** | phenix.molprobity |
| Ramachandran favored / outliers | — | 97.6% / 0.0% | **96.3% / 0.0%** | phenix.molprobity |
| Clashscore | — | 0.75 | **0.75** | phenix.molprobity |
| C-beta deviations | — | 0 | **0** | phenix.molprobity |
| MolProbity score | — | 1.39 | **0.98** | phenix.molprobity |
| RMS bonds / angles | — | 0.0036 Å / 0.62° | **0.0026 Å / 0.59°** | phenix.molprobity |

\* The supplied model could not be refined or validated as delivered — see "Blocking defect" below.

**Where it stands:** A finished, well-behaved 2.59 Å structure. R-free 0.2263 with a 0.039 R-free−R-work gap is appropriate for the resolution; geometry is tight (bonds 0.0026 Å, angles 0.59°); MolProbity 0.98 with zero Ramachandran, rotamer, C-β, and essentially zero clash outliers. One flagged uncertainty remains (the 4 free Se atoms — see below).

---

## Blocking defect found and fixed ("badelement")

`phenix.refine` on the supplied `model.pdb` failed immediately:

```
Sorry: Unknown chemical element type: "ATOM 2 CA ILE A 2 ... Xx"
```

- **Cause:** 12 backbone Cα atoms (residues A2–A13) had element field (cols 77–78) = `Xx` instead of `C`. All are alpha carbons of standard residues → element is unambiguously carbon.
- **Fix:** set those 12 element fields to ` C` on a versioned copy (`provenance_01_element_corrected_start.pdb`); originals untouched. This restored refinability with no change to coordinates (baseline refine reproduced the supplied header R-values exactly).
- Also noted (not a blocker; handled by Phenix): the supplied `model.pdb` carried an inconsistent `CRYST1` (61.23 61.23 96.50) that disagrees with the data cell. Phenix.refine correctly uses the reflection-file cell (76.08 27.97 42.36); all output models carry the correct data cell.
- Also noted: the supplied `model.pdb` reuses atom serial numbers among waters; Coot's parser silently drops the collisions. Avoided by transplanting only the fitted side chains back into the intact Phenix model rather than saving Coot's whole-model write (all 36 waters preserved).

---

## What was done (pipeline)

1. `phenix.xtriage` — no twinning, no pseudotranslation, no twin laws possible; data behave normally. No special handling needed. (R-free set already present; **preserved, not regenerated**.)
2. Element correction (Xx→C) → `phenix.refine` (individual_sites+individual_adp+occupancies, 3 macrocycles, optimized weights) → baseline: R 0.1901 / R-free 0.2399, MolProbity 1.39, 4 rotamer outliers (A2 ILE, A45 VAL, A53 GLN, A84 VAL).
3. Coot: auto-fit best rotamer for those 4 residues against the 2mFo-DFc map (kept only improved fits); all 4 → favored rotamers (0.00% outliers). Side chains transplanted into the intact Phenix model.
4. `phenix.refine` (same protocol) on the rotamer-fixed model → **FINAL: R 0.1870 / R-free 0.2263**, MolProbity 0.98. (A Phenix N/Q flip on A12 GLN also applied automatically.)
5. `phenix.molprobity` on the final model — statistics above.

---

## Decisions and rejected alternatives

- **Fixed Xx→C rather than deleting the atoms:** they are real Cα positions; deletion would break the backbone. (Chosen.)
- **Rejected keeping the first rotamer attempt** where post-fit real-space refinement drove A53/A84 back to outliers (scientific divergence) — restored and re-fit with the fit-only approach that improved all four.
- **Rejected saving Coot's whole-model output** (dropped 2 waters via serial-number collision); transplanted only the 4 side chains into the Phenix model instead.
- **Left the 4 free Se atoms in place** (see uncertainty) — removing them was not requested and barely affects R; flagged for the user's decision rather than made unilaterally.
- Kept the existing R-free flag set frozen throughout.

---

## Remaining uncertainties / flags

- **The 4 free Se atoms (chain Z) are weakly supported and of uncertain identity.** Final occupancy/B: Z1 0.48/59.4, Z3 0.21/25.2, Z4 0.34/44.4, Z5 0.60/75.9 Ų. They are isolated (Z1 sits 3.15 Å from a water; Z3/Z4/Z5 have no protein neighbor <3.6 Å), not part of MSE residues, and the data (from a SeMet SAD/AutoSol origin) contain no anomalous columns here to re-verify them. They read as leftover anomalous-substructure peaks rather than bonded selenium. **Confidence: low that all four are genuine ordered Se.** Recommend the user decide whether to (a) keep, (b) remove Z5/Z1 (highest B, likely noise), or (c) re-evaluate against an anomalous map if the original SAD data are available.
- Sequence register was not independently re-verified against density beyond the automatic checks; Ramachandran/rotamer/clash all clean, so no register problem is indicated, but this was a refine-and-polish task, not a de-novo build.
- Highest-resolution shell (3.14–2.59 Å) R-work 0.218 — normal for 2.59 Å.

## Suggested next steps (optional)

- Decide the fate of the 4 Se atoms (above); re-refine if any are removed.
- Consider adding a few ordered waters into remaining positive difference peaks and a final TLS group if desired (not required at this quality).
- `phenix.table_one` for a deposition-ready Table 1 if depositing.

---

## File inventory (DEPOSIT/)

| File | Description |
|---|---|
| `final_refined_model.pdb` / `.cif` | **Final refined model** (R 0.1870 / R-free 0.2263) |
| `final_refined_maps_and_data.mtz` | Final map coefficients + data from phenix.refine |
| `final_refine.log` | Final refinement log (source of R-factors) |
| `final_refine_parameters.eff` | Effective PHIL used for the final refinement |
| `final_refine_geometry.geo` | Final geometry restraints summary |
| `final_molprobity.out` | Final MolProbity validation |
| `data.mtz` | Input data (FP,SIGFP + R-free-flags), unmodified |
| `sequence.dat` | Input sequence, unmodified |
| `provenance_01_element_corrected_start.pdb` | Supplied model with Xx→C fix (superseded) |
| `provenance_02_rotamer_fixed_prefinal.pdb` | Element+rotamer-corrected model, pre-final-refine (superseded) |
| `FINAL_REPORT.md` | This file |

**Coot status:** responsive throughout; rotamer fitting completed as described (not skipped).
