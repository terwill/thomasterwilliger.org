# FINAL REPORT — refined_start_badelement

**Task:** Refine the supplied model against the supplied data; report final statistics.
**Data:** X-ray, 2.59 Å, space group C 1 2 1, unit cell 76.08 27.97 42.36 90 103.2 90, 2634 reflections (263 free). R-free set present in `data.mtz` and preserved throughout (never regenerated).

## What was wrong with the starting model (two defects, both corrected)
1. **Bad element (the named defect):** the Cα atoms of residues A2–A13 carried element `Xx` (invalid) instead of carbon — 12 atoms. Corrected to C.
2. **Corrupted CRYST1:** the PDB header cell (61.23 61.23 96.50 β=103.2) disagreed with the data cell (~4× volume) though both are C2. Resolved empirically: with the **data cell** + element fix, `phenix.model_vs_data` reproduced the model header (R-work 0.1975 / R-free 0.2417). The coordinates belong to the data cell; the header line was corrupted. Data cell adopted.

Both corrections are non-destructive header/scattering-factor fixes; coordinates were not altered by them.

## Final vs. baseline metrics

| Metric | Baseline (corrected input, refined optimum) | **Final (Model D)** | Source |
|---|---|---|---|
| R-work | 0.1975 | **0.1939** | refine j_462552e4a068 log; MolProbity recompute 0.1933 |
| R-free | 0.2417 | **0.2321** | refine j_462552e4a068 log; MolProbity recompute 0.2317 |
| R-free − R-work gap | 0.044 | **0.038** | derived |
| MolProbity score | 1.24 | **1.24** | molprobity j_5c31282dd392 |
| Clashscore | 1.51 | **1.51** | molprobity j_5c31282dd392 |
| Ramachandran favored / outliers | 96.3% / 0.0% | **96.3% / 0.0%** | molprobity j_5c31282dd392 |
| Rotamer outliers | 1.37% (VAL A84) | **1.37% (LYS A24)** | rotalyze / molprobity |
| Cβ deviations | 0 | **0** | molprobity j_5c31282dd392 |
| RMS bonds / angles | 0.0021 Å / 0.47° | **0.0021 Å / 0.47°** | molprobity j_5c31282dd392 |

Baseline = the element+cell-corrected input at its refined optimum (`phenix.model_vs_data`). It is the honest "before" for this already-refined model; the corrupted-as-delivered model cannot be refined meaningfully (the `Xx` element gives wrong scattering factors).

## Decisions (accepted / rejected)
- **ACCEPTED — element `Xx→C` and data-cell CRYST1.** Reproduces the header R; prerequisite for any valid refinement.
- **REJECTED — default 5-macrocycle refinement** (j_f2ac7ad6acc3): drove R-work to 0.139 but R-free to 0.244 (unchanged/worse), gap 0.105 → overfitting. With 696 atoms vs 2633 reflections, full individual refinement over-parameterizes.
- **ACCEPTED — weight-optimized refinement** (`optimize_xyz_weight`, `optimize_adp_weight`, 3 macrocycles): honest fit, gap ~0.04–0.05.
- **ACCEPTED — targeted Coot rotamer fits of terminal/flexible outliers (VAL A84, ILE A2) + re-refine:** each lowered cross-validated R-free (0.2415 → 0.2354 → 0.2321) with unchanged, excellent geometry. Rotamer choices were driven by MolProbity (geometry), then scored by R-free (no R-free leakage into model decisions).
- **REJECTED — third rotamer fix (LYS A24) + re-refine** (Model E, j_9a6bd9cc2006): R-free rose to 0.2370 (> 0.2321) and gap widened → iteration had plateaued/diverged. Kept prior best (Model D).

## Where it stands (the evidence)
The model is in excellent shape for 2.59 Å: **R-work/R-free = 0.194/0.232**, MolProbity **1.24**, clashscore **1.51**, **0** Ramachandran/Cβ outliers, tight geometry (bonds 0.0021 Å, angles 0.47°). The R-free improvement over the corrected baseline (0.2417 → 0.2321, Δ≈0.009 ≈ ~1σ given 263 free reflections) is modest but consistent across two independent MolProbity-guided rotamer corrections, with the R-free/R-work gap holding or shrinking — i.e. genuine improvement, not overfitting.

## Remaining uncertainties / limits
- **One rotamer outlier persists (LYS A24, 1.37%).** Whack-a-mole across refinements at flexible/terminal residues indicates this is near the data's noise floor at 2.59 Å; forcing it worsened R-free. Left as a documented flexible-surface outlier.
- **R-free improvement is ~1σ** given only 263 free reflections — real but not large. A conservative alternative (`alt_conservative_model.pdb`, R-free 0.2415, no Coot edits) is preserved for comparison.
- **Selenium sites:** 4 partial-occupancy Se atoms (chain Z) from the original SeMet SAD experiment were kept as supplied; not re-interpreted.
- **Waters:** 36 supplied waters retained; no ordered-solvent update was run (kept faithful to "refine the supplied model").

## Next steps (optional)
- Manual inspection of LYS A24 and the N/C-terminal residues in the 2mFo-DFc/difference maps.
- Consider `phenix.ordered_solvent` to update the water set if pursuing further.
- Verify the SeMet Se occupancies against anomalous difference density if the anomalous data are available.

## File inventory (this directory)
- `refined_model.pdb` / `.cif` — **final model (Model D)**; R-work 0.194 / R-free 0.232.
- `refined_model_map_coeffs.mtz` — 2mFo-DFc / mFo-DFc coefficients + data + R-free flags for the final model.
- `refined_model.geo`, `refined_model_refine.eff` — geometry restraints and effective PHIL (provenance).
- `alt_conservative_model.pdb` / `alt_conservative_map_coeffs.mtz` — alternative (weight-optimized, no Coot edits); R-free 0.2415.
- `data.mtz` — input data (R-free flags untouched).
- `sequence.dat` — input sequence.
- `RUN_LOG.json` — machine-readable job/decision log.
