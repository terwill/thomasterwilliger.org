#!/bin/bash
# Source this file, don't execute it:  source ./source_keys.sh

API_DIR=/dectris_data/SANPA/2026/27599/raw/rawdata_tutor_TT/
ENC_FILE="$API_DIR/workshop.enc"

# Show exactly which openssl we're using (catches PATH/version surprises)
echo "Using openssl: $(command -v openssl) -> $(openssl version)"

# --- Wait for the encrypted file to be reachable (handles NFS automount) ---
if [[ ! -r "$ENC_FILE" ]]; then
    echo -n "Waiting for key file to become available"
    for i in 1 2 3 4 5; do
        [[ -r "$ENC_FILE" ]] && break
        echo -n "."
        sleep 2
    done
    echo ""
fi
if [[ ! -r "$ENC_FILE" ]]; then
    echo "ERROR: cannot read $ENC_FILE"
    echo "  Check that the data mount is present:  ls $API_DIR"
    return 1 2>/dev/null || exit 1
fi

# --- Decrypt only if not already set ---
if [[ -n "${ANTHROPIC_API_KEY:-}" ]]; then
    echo "ANTHROPIC_API_KEY already set. Skipping decryption."
else
    # Let the student retry the password up to 3 times
    decrypted=""
    for attempt in 1 2 3; do
        read -r -s -p "Enter API Key Password: " api_password
        echo ""

        key_text=$(printf '%s' "$api_password" | \
            openssl enc -aes-256-cbc -pbkdf2 -iter 100000 -d \
            -in "$ENC_FILE" -pass stdin 2>/dev/null)

        # A real key is printable ASCII; validate before accepting it
        if [[ -n "$key_text" && "$key_text" == sk-* ]]; then
            decrypted="$key_text"
            unset api_password key_text
            break
        fi
        unset key_text
        echo "  Decryption failed (wrong password?). Attempts left: $((3 - attempt))"
    done
    unset api_password

    if [[ -n "$decrypted" ]]; then
        export ANTHROPIC_API_KEY="$decrypted"
        unset decrypted
        echo "ANTHROPIC_API_KEY set successfully."
    else
        echo "ERROR: could not decrypt after 3 attempts."
        return 1 2>/dev/null || exit 1
    fi
fi

# --- Convenience command for students: type 'start_expert_dlab' to launch ---
alias start_expert_dlab="$API_DIR/start_expert_dlab"

echo "--- API Key Verification ---"
echo "ANTHROPIC_API_KEY :  ${ANTHROPIC_API_KEY:0:4}..."

if [[ -x "$API_DIR/start_expert_dlab" ]]; then
    echo "READY TO RUN SCRIPT"
    echo "Type 'start_expert_dlab' to begin."
else
    echo "NOTE: $API_DIR/start_expert_dlab is not executable yet."
    echo "      Run once:  chmod +x $API_DIR/start_expert_dlab"
fi
echo "----------------------------"
