#!/bin/bash
# Source this file, don't execute it:  source ./setkeys.sh

API_DIR=/dectris_data/SANPA/2026/27599/raw/raw/rawdata_tutor_TT/

# --- Check if keys are already set ---
if [[ -n "${ANTHROPIC_API_KEY:-}" && -n "${GOOGLE_API_KEY:-}" && -n "${COHERE_API_KEY:-}" ]]; then
    echo "API keys are already set. Skipping decryption."
else
    # --- Keys are missing, so we need to decrypt them ---

    # Prompt for the password securely (no echo)
    read -r -s -p "Enter API Key Password: " api_password
    echo ""

    # --- 1. Anthropic Key ---
    # Pipe the password to openssl via '-pass stdin' to keep it out of process lists
    key_text=$(printf '%s' "$api_password" | \
        openssl enc -aes-256-cbc -pbkdf2 -iter 100000 -d \
        -in "$API_DIR/workshop.enc" -pass stdin)
    status=$?

    # Check if openssl succeeded (status 0) and produced output
    if [[ $status -eq 0 && -n "$key_text" ]]; then
        export ANTHROPIC_API_KEY="$key_text"
        echo "ANTHROPIC_API_KEY set successfully."
    else
        echo "FAILED to decrypt Anthropic key. Check password or file path."
    fi

    # Clear the password variable from memory for security
    unset api_password
fi

echo "--- API Key Verification ---"

# 1. Verify Anthropic Key
if [[ -n "${ANTHROPIC_API_KEY:-}" ]]; then
    start=${ANTHROPIC_API_KEY:0:4}
    echo "ANTHROPIC_API_KEY :  ${start}..."
else
    echo "ANTHROPIC_API_KEY :  [NOT SET]"
    return 1 2>/dev/null || exit 1
fi

echo "READY TO RUN SCRIPT"
echo "----------------------------"
