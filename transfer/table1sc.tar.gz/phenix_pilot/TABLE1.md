# Table 1 - per-run summary

_Numbers are **as reported by each run's own tools** unless marked independent. Every value carries a source marker (legend below), because validators disagree - a recurring finding of this project. Rows are not comparable across cases (different resolutions, methods, data types): this is a per-run report card, not a leaderboard. **Caveat:** a "discrepancy" below is only a true tool disagreement if both numbers describe the SAME model; control/intermediate refinements are excluded by name, but verify the sources before citing one._

| metric | AF_7mjs_H_PredictAndBuild | AF_bromodomain_ligand | CASP7-T0283-mr | a2u-globulin-mr | beta-blip | esterase_tNCS | gene-5-mad | nsf-d2-ligand | p9-sad | porin-twin | refined_start |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Resolution | 2.9 ^a | 2.1 ^b | — | 2.38 ^c | 3 ^d | 1.6 ^e | 21.33 – 2.59 Å ^f | 1.9 ^f | 1.74 ^g | 2.25 ^h | 2.59 ^i |
| Space group | P 1 ^j | P 31 2 1 ^k | P 65 2 2 ^l | P2 ^a | P 32 2 1 ^m | P 21 21 21 ^n | C 1 2 1 ^f | P 6 ^f | I 4 ^o | R 3 :H ^p | C 1 2 1 ^i |
| R-work (run-declared) | — | — | — | — | — | — | 0.1366 ^f | 0.1963 ^f | — | — | — |
| R-free (run-declared) | — | — | — | — | — | — | 0.218 ^f | 0.2282 ^f | — | — | — |
| R-work (refine log) | — | 0.2045 ^q | — | 0.2037 ^r | 0.2318 ^s | 0.1833 ^t | 0.1364 ^u | 0.1963 ^v | 0.231 ^w | 0.1288 ^x | 0.2036 ^y |
| R-free (refine log) | — | 0.2555 ^q | — | 0.243 ^r | 0.3137 ^s | 0.2112 ^t | 0.2179 ^u | 0.2282 ^v | 0.2462 ^w | 0.158 ^x | 0.2417 ^y |
| R-work (MolProbity) | — | 0.2045 ^b | — | 0.2037 ^c | 0.2371 ^d | 0.1716 ^e | 0.1366 ^z | 0.1963 ^{ | 0.231 ^g | 0.2265 ^h | 0.2034 ^i |
| R-free (MolProbity) | — | 0.2573 ^b | — | 0.2429 ^c | 0.3094 ^d | 0.205 ^e | 0.218 ^z | 0.2282 ^{ | 0.2462 ^g | 0.2483 ^h | 0.2411 ^i |
| R-free (recomputed, independent) | — | — | 0.5574 ^| | — | — | 0.2068 ^| | — | — | — | — | 0.2417 ^| |
| R-free (deposited) | — | 0.204 ^| | 0.238 ^| | — | 0.205 ^| | 0.188 ^| | 0.2 ^| | 0.244 ^| | 0.236 ^| | — | — |
| MolProbity score | 1.81 ^} | 1.03 ^b | — | 1.31 ^c | 2.85 ^d | 1.6 ^e | 1.82 ^f | 0.95 ^f | 1.25 ^g | 1.31 ^h | 1.55 ^i |
| Clashscore | 8.57 ^} | 2.44 ^b | — | 3.95 ^c | 11.91 ^d | 6.81 ^e | 3.05 ^z | 1.82 ^{ | 4.81 ^g | 2.66 ^h | 0.76 ^i |
| Ramachandran favored % | 100 ^} | 100 ^b | — | 97.33 ^c | 93.4 ^d | 96.54 ^e | 97.56 ^z | 97.96 ^{ | 99.11 ^g | 96.17 ^h | 96.34 ^i |
| Ramachandran outliers % | 0 ^} | 0 ^b | — | 0 ^c | 0 ^d | 0.8 ^e | 0 ^z | 0 ^{ | 0 ^g | 0 ^h | 0 ^i |
| Rotamer outliers % (MolProbity) | 2.83 ^} | 0 ^b | — | 0.87 ^c | 12.24 ^d | 0.68 ^e | 6.76 ^z | 0 ^{ | 0 ^g | 0.92 ^h | 5.48 ^i |
| Rotamer outliers % (refine log) | 3.77 ^~ | 2.25 ^q | — | 0 ^r | 6.71 ^s | 0.68 ^t | 6.76 ^u | 0.46 ^v | 0 ^w | 1.84 ^x | 5.48 ^y |
| C-beta deviations (count, MolProbity) | 0 ^} | 0 ^b | — | 0 ^c | 0 ^d | 0 ^e | 0 ^z | 0 ^{ | 0 ^g | 0 ^h | 0 ^i |
| C-beta deviations (%, refine log) | 0 ^~ | 0 ^q | — | 0 ^r | 0 ^s | 0 ^t | 1.3 ^u | 0 ^v | 0 ^w | 0 ^x | 0 ^y |
| RMS bonds | 0.0025 ^} | 0.0069 ^b | — | 0.0027 ^c | 0.0094 ^d | 0.0184 ^e | 0.0105 ^z | 0.0085 ^{ | 0.0074 ^g | 0.0087 ^h | 0.0038 ^i |
| RMS angles | 0.53 ^} | 0.82 ^b | — | 0.52 ^c | 1.14 ^d | 1.58 ^e | 1.18 ^z | 0.95 ^{ | 1.04 ^g | 0.73 ^h | 0.59 ^i |
| FOM (after DM) | — | — | — | — | — | — | 0.73 ^f | — | 0.72 ^ | — | — |
| Map-model CC_mask | 0.847 ^~ | — | — | — | — | — | 0.813 ^f | — | — | — | — |
| Twin fraction | — | — | — | — | — | — | — | 0.04 ^ | 0.03 ^ | 0.32 ^a | — |
| Science grade (vs deposited) | no-reference ^| | major ^| | critical ^| | no-reference ^| | major ^| | none ^| | none ^| | none ^| | major ^| | no-reference ^| | none ^| |
| CA-RMSD vs deposited (A) | — | 0.14 ^| | 15.83 ^| | — | 0.33 ^| | 0.1 ^| | 0.19 ^| | 0.11 ^| | 0.25 ^| | — | 0.21 ^| |
| Matched fraction | — | 0.93 ^| | 0.03 ^| | — | 0.94 ^| | 0.97 ^| | 0.94 ^| | 1 ^| | 0.82 ^| | — | 0.94 ^| |
| Coverage | — | 0 ^| | 0 ^| | — | 0.501 ^| | 0.99 ^| | 0.977 ^| | 1 ^| | 0.824 ^| | — | 0.977 ^| |

**Sources:** ^a self_analysis · ^b molprobity.out:molprobity_a0713424[model?] · ^c molprobity.out:molprobity_d92671a4[model?] · ^d molprobity.out:molprobity_0e112d45[model?] · ^e molprobity.out:molprobity_7888ee2b[model?] · ^f DEPOSIT · ^g molprobity.out:molprobity_527bf110[model?] · ^h molprobity.out:molprobity_f084ea32[model?] · ^i molprobity.log:molprobity_e22eb727[model?] · ^j molprobity.log:molprobity_34e51c10[model?] · ^k molprobity.log:molprobity_a0713424[model?] · ^l refine-log:refine_fa875369/phenix_mcp_run.log · ^m molprobity.log:molprobity_0e112d45[model?] · ^n molprobity.log:molprobity_7888ee2b[model?] · ^o molprobity.log:molprobity_527bf110[model?] · ^p molprobity.log:molprobity_f084ea32[model?] · ^q refine-log:refine_23102cb5/final_001.log · ^r refine-log:DEPOSIT/a2u_globulin_final_refine.log · ^s refine-log:DEPOSIT/beta_blip_final_refine.log · ^t refine-log:refine_c8bd3dd4/esterase_final_001.log · ^u refine-log:logs/04_final_refine.log · ^v refine-log:logs/refine_final.log · ^w refine-log:DEPOSIT/molprobity.log · ^x refine-log:DEPOSIT/refine_final.log · ^y refine-log:refine_25d1e773/final_deposit_001.log · ^z molprobity.out:molprobity_ed273a9b[model?] · ^{ molprobity.out:molprobity_92387150[model?] · ^| scores.json · ^} molprobity.out:molprobity_34e51c10[model?] · ^~ refine-log:validation/real_space_refine_primary.log · ^ refine-log:DEPOSIT/autosol.log · ^ refine-log:logs/xtriage.log

## Tool-vs-tool discrepancies (the Class-3 diagnostic)

- **AF_7mjs_H_PredictAndBuild**
  - rotamer outliers %: 3.77 (refine-log:validation/real_space_refine_primary.log) vs 2.83 (molprobity.out:molprobity_34e51c10[model?])  [MODEL UNVERIFIED - the two numbers may describe different structures]
- **AF_bromodomain_ligand**
  - rotamer outliers %: 2.25 (refine-log:refine_23102cb5/final_001.log) vs 0 (molprobity.out:molprobity_a0713424[model?])  [MODEL UNVERIFIED - the two numbers may describe different structures]
- **a2u-globulin-mr**
  - rotamer outliers %: 0 (refine-log:DEPOSIT/a2u_globulin_final_refine.log) vs 0.87 (molprobity.out:molprobity_d92671a4[model?])  [MODEL UNVERIFIED - the two numbers may describe different structures]
- **beta-blip**
  - R-work: 0.2318 (refine-log:DEPOSIT/beta_blip_final_refine.log) vs 0.2371 (molprobity.out:molprobity_0e112d45[model?])  [MODEL UNVERIFIED - the two numbers may describe different structures]
  - rotamer outliers %: 6.71 (refine-log:DEPOSIT/beta_blip_final_refine.log) vs 12.24 (molprobity.out:molprobity_0e112d45[model?])  [MODEL UNVERIFIED - the two numbers may describe different structures]
- **esterase_tNCS**
  - R-work: 0.1833 (refine-log:refine_c8bd3dd4/esterase_final_001.log) vs 0.1716 (molprobity.out:molprobity_7888ee2b[model?])  [MODEL UNVERIFIED - the two numbers may describe different structures]
  - R-free: 0.2112 (refine-log:refine_c8bd3dd4/esterase_final_001.log) vs 0.205 (molprobity.out:molprobity_7888ee2b[model?])  [MODEL UNVERIFIED - the two numbers may describe different structures]
- **gene-5-mad**
  - C-beta reported in different units - 0 count (molprobity.out:molprobity_ed273a9b[model?]) vs 1.3% (refine-log:logs/04_final_refine.log); not directly comparable
- **porin-twin**
  - R-work: 0.1288 (refine-log:DEPOSIT/refine_final.log) vs 0.2265 (molprobity.out:molprobity_f084ea32[model?])  [MODEL UNVERIFIED - the two numbers may describe different structures]
  - R-free: 0.158 (refine-log:DEPOSIT/refine_final.log) vs 0.2483 (molprobity.out:molprobity_f084ea32[model?])  [MODEL UNVERIFIED - the two numbers may describe different structures]
  - rotamer outliers %: 1.84 (refine-log:DEPOSIT/refine_final.log) vs 0.92 (molprobity.out:molprobity_f084ea32[model?])  [MODEL UNVERIFIED - the two numbers may describe different structures]
