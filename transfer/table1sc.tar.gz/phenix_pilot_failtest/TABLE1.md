# Table 1 - per-run summary

_Numbers are **as reported by each run's own tools** unless marked independent. Every value carries a source marker (legend below), because validators disagree - a recurring finding of this project. Rows are not comparable across cases (different resolutions, methods, data types): this is a per-run report card, not a leaderboard. **Caveat:** a "discrepancy" below is only a true tool disagreement if both numbers describe the SAME model; control/intermediate refinements are excluded by name, but verify the sources before citing one._

| metric | refined_start_badelement/E2 | refined_start_badelement/P2 | refined_start_control/E2 | refined_start_control/P2 | refined_start_offset/E2 | refined_start_offset/P2 |
|---|---|---|---|---|---|---|
| Resolution | 2.59 ^a | 2.59 ^b | 2.59 ^c | 2.59 ^d | 2.59 ^e | 2.59 ^f |
| Space group | C 1 2 1 ^g | C 1 2 1 ^h | C 1 2 1 ^i | C 1 2 1 ^j | C 1 2 1 ^k | C 1 2 1 ^l |
| R-work (refine log) | 0.1869 ^m | 0.1834 ^n | 0.1938 ^o | 0.1947 ^p | 0.3244 ^q | 0.2024 ^r |
| R-free (refine log) | 0.2278 ^m | 0.237 ^n | 0.2388 ^o | 0.2364 ^p | 0.4751 ^q | 0.3255 ^r |
| R-work (MolProbity) | 0.187 ^a | 0.1933 ^b | 0.1938 ^c | 0.1947 ^d | 0.3244 ^e | 0.2024 ^f |
| R-free (MolProbity) | 0.2263 ^a | 0.2317 ^b | 0.2388 ^c | 0.2364 ^d | 0.4751 ^e | 0.3255 ^f |
| MolProbity score | 0.98 ^a | 1.24 ^b | 1.45 ^c | 1.45 ^d | 4.06 ^e | 2.81 ^f |
| Clashscore | 0.75 ^a | 1.51 ^b | 0.75 ^c | 0.75 ^d | 63.78 ^e | 14.3 ^f |
| Ramachandran favored % | 96.34 ^a | 96.34 ^b | 96.34 ^c | 96.34 ^d | 73.17 ^e | 86.96 ^f |
| Ramachandran outliers % | 0 ^a | 0 ^b | 0 ^c | 0 ^d | 9.76 ^e | 4.35 ^f |
| Rotamer outliers % (MolProbity) | 0 ^a | 1.37 ^b | 4.11 ^c | 4.11 ^d | 19.18 ^e | 4.92 ^f |
| Rotamer outliers % (refine log) | 0 ^m | 0 ^n | 4.11 ^o | 4.11 ^p | 19.18 ^q | 4.92 ^r |
| C-beta deviations (count, MolProbity) | 0 ^a | 0 ^b | 0 ^c | 0 ^d | 0 ^e | 0 ^f |
| C-beta deviations (%, refine log) | 0 ^m | 0 ^n | 0 ^o | 0 ^p | 0 ^q | 0 ^r |
| RMS bonds | 0.0026 ^a | 0.0021 ^b | 0.0067 ^c | 0.0064 ^d | 0.0271 ^e | 0.0121 ^f |
| RMS angles | 0.59 ^a | 0.47 ^b | 0.85 ^c | 0.78 ^d | 2.36 ^e | 1.46 ^f |
| Science grade (vs deposited) | no-reference ^s | no-reference ^s | no-reference ^s | no-reference ^s | no-reference ^s | no-reference ^s |

**Sources:** ^a molprobity.out:molprobity_cedc6869[model?] · ^b molprobity.out:molprobity_22ff4e91[model?] · ^c molprobity.out:molprobity_e18cf052[model?] · ^d molprobity.out:molprobity_ff69548e[model?] · ^e molprobity.out:molprobity_5fd3c6b8[model?] · ^f molprobity.out:molprobity_a02fc041[model?] · ^g molprobity.log:molprobity_cedc6869[model?] · ^h molprobity.log:molprobity_22ff4e91[model?] · ^i molprobity.log:molprobity_e18cf052[model?] · ^j molprobity.log:molprobity_ff69548e[model?] · ^k molprobity.log:molprobity_5fd3c6b8[model?] · ^l molprobity.log:molprobity_a02fc041[model?] · ^m refine-log:DEPOSIT/final_refine.log · ^n refine-log:refine_53990682/phenix_mcp_run.log · ^o refine-log:logs/final_molprobity.log · ^p refine-log:DEPOSIT/log_final_scaling.log · ^q refine-log:DEPOSIT/molprobity_supplied_refined.log · ^r refine-log:DEPOSIT/recovered_model_molprobity.log · ^s scores.json

## Tool-vs-tool discrepancies (the Class-3 diagnostic)

- **refined_start_badelement/P2**
  - R-work: 0.1834 (refine-log:refine_53990682/phenix_mcp_run.log) vs 0.1933 (molprobity.out:molprobity_22ff4e91[model?])  [MODEL UNVERIFIED - the two numbers may describe different structures]
  - R-free: 0.237 (refine-log:refine_53990682/phenix_mcp_run.log) vs 0.2317 (molprobity.out:molprobity_22ff4e91[model?])  [MODEL UNVERIFIED - the two numbers may describe different structures]
  - rotamer outliers %: 0 (refine-log:refine_53990682/phenix_mcp_run.log) vs 1.37 (molprobity.out:molprobity_22ff4e91[model?])  [MODEL UNVERIFIED - the two numbers may describe different structures]
